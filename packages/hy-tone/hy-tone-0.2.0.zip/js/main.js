/* hy Tone (일러스트) — 패널
   선택 객체의 색을 색조·채도·명도·대비·색온도로 한꺼번에 조정한다.
   - 처음 조작할 때 선택의 색을 원본째 모으고(세션), 슬라이더 값은 항상 그 원본 기준으로 다시 계산 → 여러 번 만져도 색이 탁해지지 않음
   - 선택이 바뀌면 지금 결과를 확정하고 슬라이더를 0으로
   - 조정하는 동안 hy_color에 신호를 보내 최근 색 기록을 잠시 멈추게 함 */
(function () {
  'use strict';
  var VERSION = '0.2.0';
  var CEP = window.__adobe_cep__ || null;
  var T = window.HyTone;
  var $ = function (id) { return document.getElementById(id); };

  var POLL_MS = 800;
  var LIVE_MAX = 4000;          // 색 칠할 곳이 이보다 많으면 손을 뗄 때만 적용
  var STRIP_MAX = 40;
  var KEYS = ['hue', 'sat', 'light', 'contrast', 'temp'];

  var PRESETS = [
    ['톤 다운', { sat: -35, light: 8, contrast: -15 }],
    ['파스텔', { sat: -45, light: 30, contrast: -25 }],
    ['선명하게', { sat: 35, contrast: 15 }],
    ['차분하게', { sat: -55, light: -5 }],
    ['밝게', { light: 22, contrast: -8 }],
    ['어둡게', { light: -22, sat: 8, contrast: 8 }],
    ['따뜻하게', { temp: 35 }],
    ['차갑게', { temp: -35 }],
    ['빈티지', { sat: -30, temp: 25, contrast: -20, light: 5 }],
    ['흑백', { sat: -100 }]
  ];

  /* ---------- 호스트 통신 (한 번에 하나씩) ---------- */
  var chain = Promise.resolve();
  function jsx(code) {
    var p = chain.then(function () {
      return new Promise(function (res) {
        if (!CEP) { res('{"error":"일러스트레이터 안에서 열어 주세요."}'); return; }
        CEP.evalScript(code, function (r) { res(r); });
      });
    });
    chain = p.catch(function () {});
    return p;
  }
  function parse(r) { try { return JSON.parse(r); } catch (e) { return { error: String(r || '응답이 없습니다.') }; } }

  // hy_color에 "지금 색 조정 중" 신호 → 그동안 최근 색 기록을 멈춤
  var APPID = 'ILST';
  try { APPID = JSON.parse(CEP.getHostEnvironment()).appId || APPID; } catch (e) {}
  function notifyColorPanel() {
    try {
      CEP.dispatchEvent({ type: 'com.hy.tone.session', scope: 'APPLICATION', appId: APPID,
                          extensionId: 'com.hy.tone.ai.panel', data: 'busy' });
    } catch (e) {}
  }

  /* ---------- 상태 ---------- */
  var P = Object.assign({}, T.ZERO);
  var OPT = { target: 'both', neutral: 'skip', swatch: 'each', pickMode: 'all' };
  try { Object.assign(OPT, JSON.parse(localStorage.getItem('hyToneAI') || '{}')); } catch (e) {}
  function saveOpt() { try { localStorage.setItem('hyToneAI', JSON.stringify(OPT)); } catch (e) {} }

  var sess = null;          // { sig, colors, spots, total, live, pivot, dirty }
  var starting = null;      // 세션 시작 중인 promise
  var curSig = null, selN = 0;
  var dragging = false, applying = false, again = false;

  /* ---------- 표시 ---------- */
  function setStatus(msg, err) { var s = $('status'); s.textContent = msg || ''; s.className = 'status' + (err ? ' err' : ''); }

  function fmt(k, v) {
    if (!v) return '0';
    var s = (v > 0 ? '+' : '−') + Math.abs(v);
    return k === 'hue' ? s + '°' : s;
  }

  function renderValues() {
    KEYS.forEach(function (k) { $('s_' + k).value = P[k]; $('v_' + k).textContent = fmt(k, P[k]); });
    var btns = $('presets').children;
    for (var i = 0; i < btns.length; i++) btns[i].classList.toggle('on', sameAs(PRESETS[i][1]));
    $('btnRevert').disabled = !(sess && sess.dirty);
    $('btnApply').disabled = !(sess && sess.dirty);
    syncPicker();
  }
  function sameAs(pr) { return KEYS.every(function (k) { return (pr[k] || 0) === P[k]; }); }

  function inTarget(c) { return OPT.target === 'both' || (OPT.target === 'fill' ? c.nf > 0 : c.ns > 0); }

  function willChange(c) {
    if (!inTarget(c)) return false;
    if (OPT.neutral === 'skip' && c.neutral) return false;
    return true;
  }

  // 원래 색 → 바뀔 색 (견본째 모드에서 전역 견본 색은 견본 바탕색을 바꾼 뒤 틴트 적용)
  function preview(c) {
    if (T.isZero(P) || !willChange(c)) return c.rgb;
    if (c.spot && OPT.swatch === 'swatch' && sess.spotMap[c.spot]) {
      var sp = sess.spotMap[c.spot];
      if (OPT.neutral === 'skip' && sp.neutral) return c.rgb;
      var nb = T.adjust(sp.rgb, P, sess.pivot), tn = c.tint;
      return [255 - (255 - nb[0]) * tn, 255 - (255 - nb[1]) * tn, 255 - (255 - nb[2]) * tn];
    }
    return T.adjust(c.rgb, P, sess.pivot);
  }

  function renderStrip() {
    var box = $('chips');
    box.innerHTML = '';
    var list = sess ? sess.colors.filter(inTarget) : [];
    $('stripEmpty').hidden = list.length > 0;
    if (!list.length) return;
    list.slice(0, STRIP_MAX).forEach(function (c) {
      var d = document.createElement('div');
      d.className = 'chip' + (willChange(c) ? '' : ' off') + (c.k === sess.refKey ? ' ref' : '');
      d.title = (c.nf ? '칠 ' + c.nf : '') + (c.nf && c.ns ? ' · ' : '') + (c.ns ? '선 ' + c.ns : '') + (c.spot ? '\n견본: ' + c.spot : '');
      var a = document.createElement('i'), b = document.createElement('i');
      a.style.background = T.hex(c.rgb);
      b.style.background = T.hex(preview(c));
      d.appendChild(a); d.appendChild(b);
      d.addEventListener('click', function () { setRef(c); });
      box.appendChild(d);
    });
    if (list.length > STRIP_MAX) {
      var m = document.createElement('span');
      m.className = 'more'; m.textContent = '+' + (list.length - STRIP_MAX);
      box.appendChild(m);
    }
  }

  function renderInfo() {
    var t = curSig === '' ? '열린 문서 없음' : selN ? '선택 ' + selN : '선택 없음';
    if (sess) t += ' · 색 ' + sess.colors.length + '개';
    $('selInfo').textContent = t;
    var sk = sess ? sess.skip : null, parts = [];
    if (sk) {
      if (sk.gradient) parts.push('그라디언트 ' + sk.gradient);
      if (sk.pattern) parts.push('패턴 ' + sk.pattern);
      if (sk.image) parts.push('이미지 ' + sk.image);
      if (sk.symbol) parts.push('심볼 ' + sk.symbol);
      if (sk.other) parts.push('기타 ' + sk.other);
    }
    $('skipInfo').textContent = parts.length ? parts.join(' · ') + ' 건너뜀' : '';
    $('skipInfo').title = parts.length ? '그라디언트·패턴·이미지·심볼·블렌드 같은 개체는 이 버전에서 색을 바꾸지 않아요.' : '';
    var hasSpot = !!(sess && sess.spots.length);
    $('fSwatch').hidden = !hasSpot;
    $('swatchHint').textContent = OPT.swatch === 'swatch'
      ? '이 견본을 쓰는 다른 객체도 같이 바뀌어요.'
      : '선택한 객체만 일반 색으로 바뀌고 견본 연결은 풀려요.';
  }

  function renderSegs() {
    document.querySelectorAll('.seg').forEach(function (seg) {
      var k = seg.dataset.key;
      seg.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.v === OPT[k]); });
    });
  }

  function renderAll() { renderValues(); renderStrip(); renderInfo(); renderSegs(); }

  /* ---------- 세션 ---------- */
  function ensureSession() {
    if (sess && sess.sig === curSig) return Promise.resolve(sess);
    if (starting) return starting;
    starting = jsx('hyt_begin()').then(function (r) {
      starting = null;
      var d = parse(r);
      if (d.error) { setStatus(d.error, true); P = Object.assign({}, T.ZERO); renderValues(); return null; }
      d.colors.forEach(function (c) {
        c.n = c.nf + c.ns;
        c.neutral = T.isNeutral(c.rgb);
        var m = /@([\d.]+)$/.exec(c.k);
        c.tint = c.spot && m ? parseFloat(m[1]) / 100 : 1;
      });
      d.colors.sort(function (a, b) { return b.n - a.n; });
      d.spotMap = {};
      d.spots.forEach(function (s) { s.neutral = T.isNeutral(s.rgb); d.spotMap[s.name] = s; });
      d.live = d.total <= LIVE_MAX;
      d.pivot = T.pivotOf(d.colors.filter(function (c) { return !c.neutral; }));
      d.dirty = false;
      d.refKey = defaultRef(d);
      sess = d;
      curSig = d.sig; selN = d.n;
      if (!d.total) setStatus('바꿀 수 있는 색이 없어요.', true);
      else setStatus(d.live ? '' : '객체가 많아서 슬라이더에서 손을 뗄 때 적용돼요.');
      renderAll();
      return d;
    });
    return starting;
  }

  function payload() {
    var c = {}, s = {};
    if (!T.isZero(P)) {
      sess.colors.forEach(function (col) {
        if (OPT.neutral === 'skip' && col.neutral) return;
        if (col.spot && OPT.swatch === 'swatch' && sess.spotMap[col.spot]) return;   // 견본째: 아래에서 바탕색으로
        var o = T.adjust(col.rgb, P, sess.pivot);
        c[col.k] = [r2(o[0]), r2(o[1]), r2(o[2]), T.isNeutral(o) ? 1 : 0];
      });
      if (OPT.swatch === 'swatch') sess.spots.forEach(function (sp) {
        if (OPT.neutral === 'skip' && sp.neutral) return;
        var o = T.adjust(sp.rgb, P, sess.pivot);
        s[sp.name] = [r2(o[0]), r2(o[1]), r2(o[2]), 0];
      });
    }
    return { c: c, s: s, target: OPT.target, mode: OPT.swatch };
  }
  function r2(v) { return Math.round(v * 100) / 100; }

  function push() {
    if (!sess) return;
    if (applying) { again = true; return; }
    applying = true; again = false;
    notifyColorPanel();
    var zero = T.isZero(P);
    jsx('hyt_apply(' + JSON.stringify(payload()) + ')').then(function (r) {
      applying = false;
      var d = parse(r);
      if (d.error) setStatus(d.error, true);
      else {
        if (sess) sess.dirty = !zero;
        if (d.fail) setStatus(d.fail + '곳은 바꾸지 못했어요 (잠긴 레이어 등).', true);
        else if (sess && sess.live) setStatus('');
        renderValues();
      }
      if (again) push();
    });
  }

  // 값이 바뀜 → 미리보기 갱신 + (필요하면 세션 시작 후) 적용
  function changed(release) {
    renderValues();
    ensureSession().then(function (s) {
      if (!s) return;
      renderStrip();
      if (s.live || release) push();
    });
  }

  function finish(keep) {
    if (!sess) return;
    notifyColorPanel();
    var wasDirty = sess.dirty;
    sess = null;
    P = Object.assign({}, T.ZERO);
    jsx('hyt_end(' + (keep ? 'true' : 'false') + ')').then(function (r) {
      var d = parse(r);
      if (d.error) setStatus(d.error, true);
      else if (wasDirty) setStatus(keep ? '적용했어요.' : '원래 색으로 되돌렸어요.');
    });
    renderAll();
  }

  /* ---------- 선택 감시 ---------- */
  function poll() {
    if (dragging || applying || starting) return;
    jsx('hyt_sig()').then(function (r) {
      var d = parse(r);
      if (d.error) return;
      var sig = d.doc ? d.sig : '';
      selN = d.doc ? d.n : 0;
      if (sig !== curSig) {
        curSig = sig;
        if (sess) finish(true);      // 선택이 바뀌면 지금 결과를 확정하고 0부터
        else { P = Object.assign({}, T.ZERO); setStatus(''); renderAll(); }
        if (pk.open && selN > 0) ensureSession().then(function () { pk.self = false; syncPicker(); });
      } else renderInfo();
    });
  }

  /* ---------- 팔레트 (눈으로 보며 색 고르기) ----------
     기준 색 하나를 팔레트에서 고른 색으로 바꾸고, 같은 조정을 나머지 색에도 적용한다 */
  var pk = { open: false, drag: null, self: false, h: 0, s: 0, v: 0 };

  function defaultRef(d) {
    var list = d.colors.filter(function (c) { return !c.neutral && inTarget(c); });
    if (!list.length) list = d.colors.filter(function (c) { return !c.neutral; });
    return list.length ? list[0].k : null;            // 가장 많이 쓴 색
  }
  function refColor() {
    if (!sess || !sess.refKey) return null;
    for (var i = 0; i < sess.colors.length; i++) if (sess.colors[i].k === sess.refKey) return sess.colors[i];
    return null;
  }
  function setRef(c) {
    if (c.neutral) { setStatus('검정·흰색·회색은 기준 색으로 쓸 수 없어요.', true); return; }
    sess.refKey = c.k;
    pk.self = false;
    renderStrip();
    if (!pk.open) togglePicker(true); else syncPicker();
  }

  function togglePicker(open) {
    pk.open = open;
    $('picker').hidden = !open;
    $('btnPick').textContent = open ? '팔레트 닫기' : '팔레트 열기';
    $('btnPick').classList.toggle('on', open);
    if (!open) return;
    pk.self = false;
    syncPicker();
    if (selN > 0) ensureSession().then(function () { pk.self = false; syncPicker(); });
  }

  function syncPicker() {
    if (!pk.open) return;
    var c = refColor();
    $('picker').classList.toggle('dim', !c);
    $('pkSVBox').hidden = OPT.pickMode === 'hue';
    $('pkHint').textContent = sess && !c ? '바꿀 수 있는 색이 검정·흰색·회색뿐이에요.'
      : !sess ? '객체를 선택하면 가장 많이 쓴 색이 기준 색이 돼요.'
      : OPT.pickMode === 'hue' ? '기준 색의 색조만 고른 색조로 맞추고, 나머지 색도 같은 만큼 돌려요.'
      : '기준 색이 고른 색이 되도록 나머지 색도 같이 움직여요. 미리보기 칩을 누르면 기준 색이 바뀌어요.';
    if (c) {
      var to = T.isZero(P) ? c.rgb : T.adjust(c.rgb, P, sess.pivot);
      $('pkFrom').style.background = T.hex(c.rgb);
      $('pkTo').style.background = T.hex(to);
      $('pkHex').textContent = T.hex(to).toUpperCase();
      if (!pk.self && !pk.drag) {
        var hsv = T.rgbToHsv(to);
        if (hsv[1] > 0.02) pk.h = hsv[0];
        pk.s = hsv[1]; pk.v = hsv[2];
      }
    } else {
      $('pkFrom').style.background = $('pkTo').style.background = 'transparent';
      $('pkHex').textContent = '';
    }
    drawPicker();
  }

  function fit(cv, dpr) {
    var w = Math.max(1, Math.round(cv.clientWidth * dpr)), h = Math.max(1, Math.round(cv.clientHeight * dpr));
    if (cv.width !== w) cv.width = w;
    if (cv.height !== h) cv.height = h;
  }
  function drawPicker() {
    var sv = $('pkSV'), hb = $('pkH'), dpr = window.devicePixelRatio || 1, g, gr, i;
    if (!sv.getContext || !sv.getContext('2d')) return;
    if (OPT.pickMode !== 'hue') {
      fit(sv, dpr);
      g = sv.getContext('2d');
      var W = sv.width, H = sv.height;
      g.fillStyle = T.hex(T.hsvToRgb(pk.h, 1, 1)); g.fillRect(0, 0, W, H);
      gr = g.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, '#fff'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, '#000');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      var x = pk.s * W, y = (1 - pk.v) * H, r = 5 * dpr;
      g.lineWidth = 2 * dpr; g.strokeStyle = '#fff'; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.stroke();
      g.lineWidth = dpr; g.strokeStyle = 'rgba(0,0,0,.6)'; g.beginPath(); g.arc(x, y, r + 1.5 * dpr, 0, Math.PI * 2); g.stroke();
    }
    fit(hb, dpr);
    g = hb.getContext('2d');
    var HW = hb.width, HH = hb.height;
    gr = g.createLinearGradient(0, 0, HW, 0);
    for (i = 0; i <= 6; i++) gr.addColorStop(i / 6, T.hex(T.hsvToRgb(i * 60 % 360, 1, 1)));
    g.fillStyle = gr; g.fillRect(0, 0, HW, HH);
    var hx = pk.h / 360 * HW;
    g.fillStyle = '#fff'; g.fillRect(hx - 2 * dpr, 0, 4 * dpr, HH);
    g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = dpr; g.strokeRect(hx - 2 * dpr, 0.5 * dpr, 4 * dpr, HH - dpr);
  }

  function pickApply(release) {
    var c = refColor();
    if (!c) return;
    var r = T.solve(c.rgb, P, sess.pivot, T.hsvToRgb(pk.h, pk.s, pk.v), OPT.pickMode);
    P.hue = r.hue;
    if (OPT.pickMode === 'all') { P.sat = r.sat; P.light = r.light; }
    pk.self = true;
    changed(release);
  }

  function bindDrag(cv, kind) {
    function move(e, release) {
      var b = cv.getBoundingClientRect();
      var x = Math.max(0, Math.min(1, (e.clientX - b.left) / (b.width || 1)));
      var y = Math.max(0, Math.min(1, (e.clientY - b.top) / (b.height || 1)));
      if (kind === 'sv') { pk.s = x; pk.v = 1 - y; } else pk.h = x * 359.9;
      drawPicker();
      pickApply(release);
    }
    cv.addEventListener('pointerdown', function (e) {
      if (!refColor()) {
        if (selN > 0) ensureSession().then(function () { pk.self = false; syncPicker(); });
        else setStatus('색을 바꿀 객체를 선택하세요.', true);
        return;
      }
      pk.drag = kind; dragging = true;
      try { cv.setPointerCapture(e.pointerId); } catch (x) {}
      move(e, false);
    });
    cv.addEventListener('pointermove', function (e) { if (pk.drag === kind) move(e, false); });
    cv.addEventListener('pointerup', function (e) {
      if (pk.drag !== kind) return;
      pk.drag = null; dragging = false;
      move(e, true);
    });
    cv.addEventListener('lostpointercapture', function () {
      if (pk.drag !== kind) return;
      pk.drag = null; dragging = false;
      pickApply(true);
    });
  }

  $('btnPick').addEventListener('click', function () { togglePicker(!pk.open); });
  bindDrag($('pkSV'), 'sv');
  bindDrag($('pkH'), 'h');
  window.addEventListener('resize', function () { if (pk.open) drawPicker(); });

  /* ---------- 테마 ---------- */
  function theme() {
    try {
      var c = JSON.parse(CEP.getHostEnvironment()).appSkinInfo.panelBackgroundColor.color;
      var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
      var dark = (0.299 * r + 0.587 * g + 0.114 * b) < 128, st = document.documentElement.style;
      function sh(d) { return 'rgb(' + [r, g, b].map(function (v) { return Math.max(0, Math.min(255, v + d)); }).join(',') + ')'; }
      st.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
      st.setProperty('--ctl', sh(dark ? 14 : -14));
      st.setProperty('--ctl-hi', sh(dark ? 26 : -26));
      st.setProperty('--stage', sh(dark ? -10 : 10));
      st.setProperty('--fg', dark ? '#e6e6e6' : '#222');
      st.setProperty('--muted', dark ? '#9a9a9a' : '#6b6b6b');
      st.setProperty('--dot', dark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.08)');
    } catch (e) {}
  }

  /* ---------- UI 연결 ---------- */
  PRESETS.forEach(function (pr) {
    var b = document.createElement('button');
    b.textContent = pr[0];
    b.addEventListener('click', function () {
      KEYS.forEach(function (k) { P[k] = pr[1][k] || 0; });
      pk.self = false;
      changed(true);
    });
    $('presets').appendChild(b);
  });

  KEYS.forEach(function (k) {
    var s = $('s_' + k);
    s.addEventListener('pointerdown', function () { dragging = true; });
    s.addEventListener('input', function () { pk.self = false; P[k] = +s.value; changed(false); });
    s.addEventListener('change', function () { dragging = false; pk.self = false; P[k] = +s.value; changed(true); });
    s.addEventListener('dblclick', function () { pk.self = false; P[k] = 0; changed(true); });
  });
  document.addEventListener('pointerup', function () { dragging = false; });

  document.querySelectorAll('.seg').forEach(function (seg) {
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) return;
      OPT[seg.dataset.key] = b.dataset.v;
      saveOpt(); renderSegs(); renderInfo(); renderStrip();
      if (seg.dataset.key === 'pickMode') { pk.self = false; syncPicker(); return; }
      if (sess && (sess.dirty || !T.isZero(P))) push();
    });
  });

  $('btnApply').addEventListener('click', function () { finish(true); });
  $('btnRevert').addEventListener('click', function () { finish(false); });
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  try { CEP.addEventListener('com.adobe.csxs.events.ThemeColorChanged', theme); } catch (e) {}
  theme();
  renderAll();
  poll();
  setInterval(poll, POLL_MS);
  console.log('hy Tone v' + VERSION);
})();
