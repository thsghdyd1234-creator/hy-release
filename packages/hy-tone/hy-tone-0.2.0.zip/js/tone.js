/* hy Tone (일러스트) — 색 계산. OKLab/OKLCh 기준으로 색조·채도·명도·대비·색온도를 조정한다.
   패널(main.js)과 node 테스트에서 같이 쓴다. */
(function (root) {
  'use strict';

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function toLin(c) { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function toSrgb(c) { return 255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055); }

  function rgbToLab(rgb) {
    var r = toLin(rgb[0]), g = toLin(rgb[1]), b = toLin(rgb[2]);
    var l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
    var m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
    var s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
    return [0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
            1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
            0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s];
  }

  function labToLin(L, a, b) {
    var l = L + 0.3963377774 * a + 0.2158037573 * b;
    var m = L - 0.1055613458 * a - 0.0638541728 * b;
    var s = L - 0.0894841775 * a - 1.2914855480 * b;
    l = l * l * l; m = m * m * m; s = s * s * s;
    return [ 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
            -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
            -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s];
  }

  function inGamut(c) { var e = 1e-5; return c[0] >= -e && c[0] <= 1 + e && c[1] >= -e && c[1] <= 1 + e && c[2] >= -e && c[2] <= 1 + e; }

  // 명도·색조는 지키고 채도만 줄여서 sRGB 안으로 넣는다
  function lchToRgb(L, C, h) {
    L = clamp(L, 0, 1);
    var cs = Math.cos(h), sn = Math.sin(h), lin = labToLin(L, C * cs, C * sn);
    if (!inGamut(lin)) {
      var lo = 0, hi = C;
      for (var i = 0; i < 16; i++) {
        var mid = (lo + hi) / 2;
        if (inGamut(labToLin(L, mid * cs, mid * sn))) lo = mid; else hi = mid;
      }
      lin = labToLin(L, lo * cs, lo * sn);
    }
    return [clamp(toSrgb(clamp(lin[0], 0, 1)), 0, 255),
            clamp(toSrgb(clamp(lin[1], 0, 1)), 0, 255),
            clamp(toSrgb(clamp(lin[2], 0, 1)), 0, 255)];
  }

  function chroma(rgb) { var x = rgbToLab(rgb); return Math.sqrt(x[1] * x[1] + x[2] * x[2]); }
  var NEUTRAL_C = 0.015;                       // 이보다 채도가 낮으면 검정·흰색·회색으로 본다
  function isNeutral(rgb) { return chroma(rgb) < NEUTRAL_C; }

  var ZERO = { hue: 0, sat: 0, light: 0, contrast: 0, temp: 0 };
  function isZero(p) { return !p.hue && !p.sat && !p.light && !p.contrast && !p.temp; }

  /* p: hue -180~180(도), sat·light·contrast·temp -100~100
     pivot: 대비 기준 명도(선택 색들의 평균 명도) */
  function adjust(rgb, p, pivot) {
    var x = rgbToLab(rgb), L = x[0], a = x[1], b = x[2];
    if (p.temp) { var t = p.temp / 100; a += 0.012 * t; b += 0.045 * t; }      // + 따뜻하게(주황) / - 차갑게(파랑)
    var C = Math.sqrt(a * a + b * b), h = Math.atan2(b, a);
    if (p.hue) h += p.hue * Math.PI / 180;
    if (p.sat) { var s = p.sat / 100; C *= s < 0 ? 1 + s : 1 + s * 1.2; }
    if (p.contrast) { var k = p.contrast / 100; L = pivot + (L - pivot) * (k >= 0 ? 1 + k : 1 + k * 0.9); }
    if (p.light) { var q = p.light / 100; L = q > 0 ? L + (1 - L) * q * 0.9 : L * (1 + q * 0.9); }
    return lchToRgb(L, Math.max(0, C), h);
  }

  // 사용 횟수로 가중한 평균 명도 (색이 하나뿐이면 중간 명도)
  function pivotOf(list) {
    var sw = 0, sl = 0;
    list.forEach(function (c) { var w = c.n || 1; sw += w; sl += w * rgbToLab(c.rgb)[0]; });
    return list.length > 1 && sw ? sl / sw : 0.6;
  }

  function hex(rgb) {
    return '#' + rgb.slice(0, 3).map(function (v) { var s = Math.round(clamp(v, 0, 255)).toString(16); return s.length < 2 ? '0' + s : s; }).join('');
  }

  /* 팔레트에서 고른 색 → 슬라이더 값.
     기준 색(ref)이 지금 색온도·대비 설정에서 정확히 target 색이 되도록 색조(와 채도·명도)를 거꾸로 푼다.
     mode 'hue' = 색조만, 'all' = 색조·채도·명도 */
  function solve(ref, p, pivot, target, mode) {
    var x = rgbToLab(ref), L = x[0], a = x[1], b = x[2];
    if (p.temp) { var t = p.temp / 100; a += 0.012 * t; b += 0.045 * t; }
    var C0 = Math.sqrt(a * a + b * b), h0 = Math.atan2(b, a);
    var y = rgbToLab(target), Lt = y[0], Ct = Math.sqrt(y[1] * y[1] + y[2] * y[2]), ht = Math.atan2(y[2], y[1]);
    var out = { hue: p.hue };
    if (Ct > NEUTRAL_C * 0.5) {                     // 회색을 고르면 색조는 그대로 둔다
      var dh = (ht - h0) * 180 / Math.PI;
      while (dh > 180) dh -= 360;
      while (dh < -180) dh += 360;
      out.hue = Math.round(dh);
    }
    if (mode === 'all') {
      var r = C0 > 1e-4 ? Ct / C0 : 1, sv = r >= 1 ? (r - 1) / 1.2 : r - 1;
      out.sat = Math.round(clamp(sv, -1, 1) * 100);
      var L1 = L;
      if (p.contrast) { var k = p.contrast / 100; L1 = pivot + (L - pivot) * (k >= 0 ? 1 + k : 1 + k * 0.9); }
      L1 = clamp(L1, 0, 1);
      var q = Lt >= L1 ? (L1 < 0.999 ? (Lt - L1) / ((1 - L1) * 0.9) : 0) : (L1 > 0.001 ? (Lt / L1 - 1) / 0.9 : 0);
      out.light = Math.round(clamp(q, -1, 1) * 100);
    }
    return out;
  }

  // 화면용 HSV (팔레트 그리기)
  function hsvToRgb(h, s, v) {
    var f = function (n) { var k = (n + h / 60) % 6; return v * (1 - s * Math.max(0, Math.min(k, 4 - k, 1))); };
    return [f(5) * 255, f(3) * 255, f(1) * 255];
  }
  function rgbToHsv(rgb) {
    var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h *= 60; if (h < 0) h += 360;
    return [h, mx ? d / mx : 0, mx];
  }

  var api = { adjust: adjust, solve: solve, hsvToRgb: hsvToRgb, rgbToHsv: rgbToHsv, isNeutral: isNeutral, isZero: isZero, pivotOf: pivotOf, hex: hex,
              rgbToLab: rgbToLab, lchToRgb: lchToRgb, ZERO: ZERO, NEUTRAL_C: NEUTRAL_C };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.HyTone = api;
})(this);
