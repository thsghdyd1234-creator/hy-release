/* hy Tone (일러스트) — Illustrator host (ExtendScript, ES3)
   선택 객체의 칠·선·문자 색을 원본째 모아 두고, 패널이 계산한 새 색을 적용하거나 원본으로 되돌린다.
   전역 이름은 hyt_ / HYT 로 시작 (다른 hy 패널과 같은 엔진을 쓰므로 겹치지 않게) */
var HYT = null;

function hyt_q(s) {
    return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
}
function hyt_json(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v, i, out = [];
    if (t == 'number') return isFinite(v) ? String(Math.round(v * 1000) / 1000) : 'null';
    if (t == 'boolean') return v ? 'true' : 'false';
    if (t == 'string') return hyt_q(v);
    if (Object.prototype.toString.call(v) == '[object Array]') { for (i = 0; i < v.length; i++) out.push(hyt_json(v[i])); return '[' + out.join(',') + ']'; }
    for (i in v) if (v.hasOwnProperty(i)) out.push(hyt_q(i) + ':' + hyt_json(v[i]));
    return '{' + out.join(',') + '}';
}
function hyt_err(msg) { return '{"error":' + hyt_q(msg) + '}'; }
function hyt_r(n) { return Math.round(n * 100) / 100; }

/* ---------- 색 변환 ---------- */
function hyt_conv(from, v, to) {
    return app.convertSampleColor(from, v, to, ColorConvertPurpose.defaultpurpose);
}
function hyt_cmykToRGB(v) {
    try { var r = hyt_conv(ImageColorSpace.CMYK, v, ImageColorSpace.RGB); return [r[0], r[1], r[2]]; }
    catch (e) {
        var k = 1 - v[3] / 100;
        return [255 * (1 - v[0] / 100) * k, 255 * (1 - v[1] / 100) * k, 255 * (1 - v[2] / 100) * k];
    }
}
function hyt_toRGB(c) {
    var t = c.typename, v;
    if (t == 'RGBColor') return [c.red, c.green, c.blue];
    if (t == 'CMYKColor') return hyt_cmykToRGB([c.cyan, c.magenta, c.yellow, c.black]);
    if (t == 'GrayColor') { v = 255 * (1 - c.gray / 100); return [v, v, v]; }
    if (t == 'LabColor') {
        try { v = hyt_conv(ImageColorSpace.LAB, [c.l, c.a, c.b], ImageColorSpace.RGB); return [v[0], v[1], v[2]]; }
        catch (e) { return null; }
    }
    if (t == 'SpotColor') {
        var b = hyt_toRGB(c.spot.color), tn = c.tint / 100;
        if (!b) return null;
        return [255 - (255 - b[0]) * tn, 255 - (255 - b[1]) * tn, 255 - (255 - b[2]) * tn];
    }
    return null;
}
function hyt_key(c) {
    var t = c.typename;
    if (t == 'RGBColor') return 'R:' + hyt_r(c.red) + ',' + hyt_r(c.green) + ',' + hyt_r(c.blue);
    if (t == 'CMYKColor') return 'C:' + hyt_r(c.cyan) + ',' + hyt_r(c.magenta) + ',' + hyt_r(c.yellow) + ',' + hyt_r(c.black);
    if (t == 'GrayColor') return 'G:' + hyt_r(c.gray);
    if (t == 'LabColor') return 'L:' + hyt_r(c.l) + ',' + hyt_r(c.a) + ',' + hyt_r(c.b);
    if (t == 'SpotColor') return 'S:' + c.spot.name + '@' + hyt_r(c.tint);
    return null;
}

// CMYK 문서의 K 단색: K값 → 화면 밝기 표를 만들어 두고 거꾸로 찾는다 (K100 검정이 4도 검정으로 바뀌지 않게)
function hyt_kFromRGB(rgb) {
    if (!HYT.kLut) {
        HYT.kLut = [];
        for (var k = 0; k <= 100; k += 5) {
            var c = hyt_cmykToRGB([0, 0, 0, k]);
            HYT.kLut.push([k, (c[0] + c[1] + c[2]) / 3]);
        }
    }
    var y = (rgb[0] + rgb[1] + rgb[2]) / 3, L = HYT.kLut, i;
    if (y >= L[0][1]) return 0;
    for (i = 1; i < L.length; i++) {
        if (y >= L[i][1]) {
            var a = L[i - 1], b = L[i], f = (a[1] - y) / ((a[1] - b[1]) || 1);
            return a[0] + (b[0] - a[0]) * f;
        }
    }
    return 100;
}

// want: [r, g, b, 무채색이면 1]
function hyt_make(want, col) {
    var sig = want.join(',') + '|' + (col.gray ? 'g' : col.kOnly ? 'k' : 'n');
    if (HYT.cache[sig]) return HYT.cache[sig];
    var c, v, rgb = [want[0], want[1], want[2]], neutral = want[3] == 1;
    if (neutral && col.gray) {
        c = new GrayColor(); c.gray = 100 * (1 - (rgb[0] + rgb[1] + rgb[2]) / 765);
    } else if (neutral && col.kOnly && HYT.cmyk) {
        c = new CMYKColor(); c.cyan = 0; c.magenta = 0; c.yellow = 0; c.black = hyt_kFromRGB(rgb);
    } else if (HYT.cmyk) {
        c = new CMYKColor();
        try { v = hyt_conv(ImageColorSpace.RGB, rgb, ImageColorSpace.CMYK); }
        catch (e) {
            var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, k = 1 - Math.max(r, g, b), d = (1 - k) || 1;
            v = [100 * (1 - r - k) / d, 100 * (1 - g - k) / d, 100 * (1 - b - k) / d, 100 * k];
        }
        c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
    } else {
        c = new RGBColor(); c.red = rgb[0]; c.green = rgb[1]; c.blue = rgb[2];
    }
    HYT.cache[sig] = c;
    return c;
}

// 전역 견본(별색 포함)의 바탕색 — 원래 색 모드를 따른다
function hyt_makeBase(want, sp) {
    var t = sp.orig.typename, rgb = [want[0], want[1], want[2]], c, v;
    if (t == 'CMYKColor') {
        v = hyt_conv(ImageColorSpace.RGB, rgb, ImageColorSpace.CMYK);
        c = new CMYKColor(); c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
    } else if (t == 'LabColor') {
        v = hyt_conv(ImageColorSpace.RGB, rgb, ImageColorSpace.LAB);
        c = new LabColor(); c.l = v[0]; c.a = v[1]; c.b = v[2];
    } else if (t == 'GrayColor') {
        c = new GrayColor(); c.gray = 100 * (1 - (rgb[0] + rgb[1] + rgb[2]) / 765);
    } else {
        c = new RGBColor(); c.red = rgb[0]; c.green = rgb[1]; c.blue = rgb[2];
    }
    return c;
}

/* ---------- 선택 읽기 ---------- */
function hyt_id(it) {
    try { if (it.uuid) return it.uuid; } catch (e) {}
    try { return it.typename + Math.round(it.left) + ',' + Math.round(it.top); } catch (e2) { return '?'; }
}
function hyt_sigOf(doc, sel) {
    return doc.name + '|' + sel.length + '|' + hyt_id(sel[0]) + '|' + hyt_id(sel[sel.length - 1]);
}

// 패널이 주기적으로 묻는 선택 상태 (가벼워야 함)
function hyt_sig() {
    try {
        if (!app.documents.length) return '{"doc":false}';
        var doc = app.activeDocument, sel = doc.selection;
        if (!sel) return hyt_json({ doc: true, n: 0, sig: doc.name + '|0' });
        if (sel.typename == 'TextRange') return hyt_json({ doc: true, n: 0, text: true, sig: doc.name + '|text' });
        if (!sel.length) return hyt_json({ doc: true, n: 0, sig: doc.name + '|0' });
        return hyt_json({ doc: true, n: sel.length, sig: hyt_sigOf(doc, sel) });
    } catch (e) { return hyt_err(e.message); }
}

function hyt_add(ref, kind, prop, c) {
    if (!c) return;
    var t = c.typename;
    if (t == 'NoColor') return;
    if (t == 'GradientColor') { HYT.skip.gradient++; return; }
    if (t == 'PatternColor') { HYT.skip.pattern++; return; }
    var spot = null;
    if (t == 'SpotColor') {
        try { if (c.spot.colorType == ColorModel.REGISTRATION) return; } catch (e) {}
        spot = c.spot.name;
        if (!HYT.spots[spot]) {
            var base = hyt_toRGB(c.spot.color);
            if (base) { HYT.spots[spot] = { ref: c.spot, orig: c.spot.color, rgb: base, cur: 'o' }; HYT.spotOrder.push(spot); }
            else spot = null;
        }
    }
    var key = hyt_key(c), col = key ? HYT.colors[key] : null;
    if (!key) { HYT.skip.other++; return; }
    if (!col) {
        var rgb = hyt_toRGB(c);
        if (!rgb) { HYT.skip.other++; return; }
        col = HYT.colors[key] = {
            k: key, rgb: rgb, nf: 0, ns: 0, spot: spot,
            gray: t == 'GrayColor',
            kOnly: t == 'CMYKColor' && c.cyan < 0.5 && c.magenta < 0.5 && c.yellow < 0.5
        };
        HYT.order.push(key);
    }
    if (prop == 'f') col.nf++; else col.ns++;
    HYT.entries.push({ r: ref, k: kind, p: prop, key: key, orig: c, spot: spot, cur: 'o' });
}

function hyt_path(p) {
    try { if (p.clipping || p.guides) return; } catch (e) {}
    if (p.filled) hyt_add(p, 0, 'f', p.fillColor);
    if (p.stroked) hyt_add(p, 0, 's', p.strokeColor);
}

function hyt_text(tf) {
    var rs = tf.textRanges, i, r, ca;
    for (i = 0; i < rs.length; i++) {
        r = rs[i];
        if (!r.length) continue;
        ca = r.characterAttributes;
        hyt_add(r, 1, 'f', ca.fillColor);
        hyt_add(r, 1, 's', ca.strokeColor);
    }
}

function hyt_walk(it) {
    try { if (it.locked || it.hidden) return; } catch (e) {}
    var t = it.typename, i;
    if (t == 'GroupItem') { for (i = 0; i < it.pageItems.length; i++) hyt_walk(it.pageItems[i]); }
    else if (t == 'CompoundPathItem') { if (it.pathItems.length) hyt_path(it.pathItems[0]); }
    else if (t == 'PathItem') hyt_path(it);
    else if (t == 'TextFrame') hyt_text(it);
    else if (t == 'SymbolItem') HYT.skip.symbol++;
    else if (t == 'PlacedItem' || t == 'RasterItem') HYT.skip.image++;
    else HYT.skip.other++;
}

// 세션 시작: 선택의 색을 원본째 모은다
function hyt_begin() {
    try {
        if (!app.documents.length) return hyt_err('열린 문서가 없습니다.');
        var doc = app.activeDocument, sel = doc.selection, i;
        if (sel && sel.typename == 'TextRange') return hyt_err('글자 편집 중이에요. 선택 도구로 텍스트 상자를 선택하세요.');
        if (!sel || !sel.length) return hyt_err('색을 바꿀 객체를 선택하세요.');
        HYT = {
            sig: hyt_sigOf(doc, sel), cmyk: doc.documentColorSpace == DocumentColorSpace.CMYK,
            entries: [], colors: {}, order: [], spots: {}, spotOrder: [], cache: {}, kLut: null,
            skip: { gradient: 0, pattern: 0, image: 0, symbol: 0, other: 0 }
        };
        for (i = 0; i < sel.length; i++) hyt_walk(sel[i]);
        var cols = [], sps = [], c;
        for (i = 0; i < HYT.order.length; i++) {
            c = HYT.colors[HYT.order[i]];
            cols.push({ k: c.k, rgb: c.rgb, nf: c.nf, ns: c.ns, spot: c.spot });
        }
        for (i = 0; i < HYT.spotOrder.length; i++) sps.push({ name: HYT.spotOrder[i], rgb: HYT.spots[HYT.spotOrder[i]].rgb });
        return hyt_json({ sig: HYT.sig, n: sel.length, total: HYT.entries.length, cmyk: HYT.cmyk,
                          colors: cols, spots: sps, skip: HYT.skip });
    } catch (e) { HYT = null; return hyt_err('선택을 읽지 못했습니다: ' + e.message); }
}

function hyt_set(e, c) {
    if (e.k == 0) { if (e.p == 'f') e.r.fillColor = c; else e.r.strokeColor = c; }
    else { if (e.p == 'f') e.r.characterAttributes.fillColor = c; else e.r.characterAttributes.strokeColor = c; }
}

/* m = { c: {색키: [r,g,b,무채색]}, s: {견본이름: [r,g,b,무채색]}, target: 'both'|'fill'|'stroke', mode: 'each'|'swatch' }
   m.c 에 없는 색은 원본으로 되돌린다. 이미 같은 색이면 건너뛴다. */
function hyt_apply(m) {
    try {
        if (!HYT) return hyt_err('조정 중인 선택이 없습니다.');
        var es = HYT.entries, n = 0, fail = 0, i, e, want, sig, sp, name;
        var swatch = m.mode == 'swatch';
        for (i = 0; i < es.length; i++) {
            e = es[i];
            want = null;
            if ((m.target == 'both' || (m.target == 'fill') == (e.p == 'f')) && !(swatch && e.spot))
                want = m.c[e.key] || null;
            sig = want ? want.join(',') : 'o';
            if (e.cur == sig) continue;
            try { hyt_set(e, want ? hyt_make(want, HYT.colors[e.key]) : e.orig); e.cur = sig; n++; }
            catch (x) { fail++; }
        }
        for (i = 0; i < HYT.spotOrder.length; i++) {
            name = HYT.spotOrder[i]; sp = HYT.spots[name];
            want = swatch && m.s ? (m.s[name] || null) : null;
            sig = want ? want.join(',') : 'o';
            if (sp.cur == sig) continue;
            try { sp.ref.color = want ? hyt_makeBase(want, sp) : sp.orig; sp.cur = sig; n++; }
            catch (x2) { fail++; }
        }
        return hyt_json({ ok: true, n: n, fail: fail });
    } catch (err) { return hyt_err('적용하지 못했습니다: ' + err.message); }
}

// 세션 끝: keep=true 면 지금 색 그대로 확정, false 면 원본으로 되돌림
function hyt_end(keep) {
    var r = '{"ok":true}';
    if (HYT && !keep) r = hyt_apply({ c: {}, s: {}, target: 'both', mode: 'each' });
    HYT = null;
    return r;
}
