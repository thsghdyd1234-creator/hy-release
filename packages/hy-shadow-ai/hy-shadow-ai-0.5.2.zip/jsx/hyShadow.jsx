/*
 * hy Shadow AI — 일러스트레이터 그림자 엔진 (ExtendScript, ES3)
 *
 * 세 가지 그림자
 *  1) 형상 그림자 (사람·나무): 개체의 실루엣을 발끝 선(맨 아래)을 축으로 기울여 눕힌다.
 *       높이 h인 점 → (x + a·h, 바닥 + b·h),  (a, b) = 길이 × (cos 각도, sin 각도)
 *     개체와 그림자를 'hy 그림자' 그룹으로 묶어 같이 움직이고, 그림자는 그룹 안 '그림자' 묶음(곱하기)이다.
 *       선명 : 발 쪽은 진하고 끝으로 갈수록 옅은 그라디언트
 *       번짐 : 같은 모양 + 흐림 효과, 끝 쪽에서만 보이게 (발은 또렷, 끝은 흐리게)
 *     그라디언트는 세운 모양(아래→위)에 입힌 뒤 기울이므로 그림자를 따라 눕는다.
 *     방향·길이만 바뀌면 지금 기울기에서 새 기울기로 가는 변형만 한 번 한다(빠름).
 *  2) 드롭 섀도(효과): 개체를 'hy 드롭 섀도' 그룹으로 감싸고 그룹에 일러스트 드롭 섀도 효과를 (옅어짐이면 여러 겹) 넣는다.
 *     효과는 스크립트로 지울 수 없어서, 바꿀 때는 그룹을 풀고 새로 감싼다.
 *  3) 평면 그림자(벡터): 개체를 그림자 방향으로 쓸어 늘인 모양을 여러 길이로 쌓은 'hy 평면 그림자' 그룹.
 *     모양 계산은 패널(core.js, Clipper)이 하고 여기서는 실루엣을 읽어 주고 받은 모양을 그린다.
 *
 * 상태는 태그(hyShadow)에 k=v;k=v 로 남긴다. 평면 그림자를 만든 개체에는 hyShadowSrc = 그림자 id.
 * 모든 함수는 JSON 문자열을 받고 {"ok":true,…} / {"ok":false,"msg":…} 문자열을 돌려준다.
 */
var hySh = (function () {
  var TAG = 'hyShadow';
  var TAG_SRC = 'hyShadowSrc';
  var TAG_PART = 'hyShadowPart';   // 우리가 만든 조각: sg(그림자 묶음) · sharp · soft · ref
  var TAG_PREV = 'hyShadowPrev';   // 되돌리기 기준 (회차|값)
  var NAME_FORM = 'hy 그림자';
  var NAME_DROP = 'hy 드롭 섀도';
  var NAME_PLAN = 'hy 평면 그림자';
  var NAME_LAYER = 'hy 그림자';   // 평면 그림자를 모아 두는 레이어 (레이어 투명도로 한 번에 조절)
  var NAME_SG = '그림자';
  var NAME_SHARP = '선명';
  var NAME_SOFT = '번짐';
  var NAME_REF = '기준';
  var GRAD = 'hy 그림자 ';
  var NAVY = [24, 34, 56];
  var MIN_B = 0.015;

  var calCache = {};
  var flipMode = null;   // 변형 행렬 해석 방향 (null: 아직 모름)
  var blurInfo = null;   // 흐림 효과 이름 (처음 한 번 시험)

  /* ---------- 직렬화 ---------- */
  function quote(s) {
    s = String(s);
    s = s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n');
    return '"' + s + '"';
  }

  function toJSON(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t == 'number') return isFinite(v) ? String(v) : 'null';
    if (t == 'boolean') return v ? 'true' : 'false';
    if (t == 'string') return quote(v);
    var i, out = [];
    if (Object.prototype.toString.call(v) == '[object Array]') {
      for (i = 0; i < v.length; i++) out.push(toJSON(v[i]));
      return '[' + out.join(',') + ']';
    }
    for (var k in v) {
      if (v.hasOwnProperty(k)) out.push(quote(k) + ':' + toJSON(v[k]));
    }
    return '{' + out.join(',') + '}';
  }

  function parseArgs(s) {
    if (!s) return {};
    return eval('(' + s + ')');
  }

  // 걸린 시간 기록 (일러스트에서 무엇이 느린지 보려고 — 패널이 결과의 t 를 모아 둠)
  var T = { t0: 0, last: 0, parts: [] };
  function tStart() { T.t0 = T.last = new Date().getTime(); T.parts = []; }
  function tMark(name) {
    var now = new Date().getTime();
    if (T.t0) T.parts.push(name + ' ' + (now - T.last));
    T.last = now;
  }
  function tText() { return T.t0 ? (new Date().getTime() - T.t0) + 'ms: ' + T.parts.join(', ') : ''; }

  function done(obj) {
    obj.ok = true;
    if (T.t0) { obj.t = tText(); T.t0 = 0; }
    return toJSON(obj);
  }

  function fail(msg) {
    T.t0 = 0;
    return toJSON({ ok: false, msg: String(msg) });
  }

  function errText(e) {
    return e && e.message ? e.message : String(e);
  }

  function num(v, d) {
    var n = parseFloat(v);
    return isNaN(n) ? d : n;
  }

  function clamp(v, lo, hi) {
    return v < lo ? lo : (v > hi ? hi : v);
  }

  function r3(v) {
    return Math.round(v * 1000) / 1000;
  }

  function r6(v) {
    return Math.round(v * 1000000) / 1000000;
  }

  function inArr(a, v) {
    for (var i = 0; i < a.length; i++) if (a[i] == v) return true;
    return false;
  }

  /* ---------- 태그 ---------- */
  function readTag(it, name) {
    try {
      var tags = it.tags;
      for (var i = 0; i < tags.length; i++) if (tags[i].name == name) return tags[i].value;
    } catch (e) {}
    return null;
  }

  function writeTag(it, name, value) {
    var tags = it.tags, i;
    for (i = 0; i < tags.length; i++) {
      if (tags[i].name == name) {
        if (tags[i].value != value) tags[i].value = value;
        return;
      }
    }
    var t = tags.add();
    t.name = name;
    t.value = value;
  }

  function removeTag(it, name) {
    try {
      for (var i = it.tags.length - 1; i >= 0; i--) if (it.tags[i].name == name) it.tags[i].remove();
    } catch (e) {}
  }

  function packKV(o) {
    var r = [];
    for (var k in o) if (o.hasOwnProperty(k) && o[k] !== null && o[k] !== undefined) r.push(k + '=' + o[k]);
    return r.join(';');
  }

  function unpackKV(v) {
    if (!v) return null;
    var o = {};
    var parts = String(v).split(';');
    for (var j = 0; j < parts.length; j++) {
      var i = parts[j].indexOf('=');
      if (i > 0) o[parts[j].substring(0, i)] = parts[j].substring(i + 1);
    }
    return o;
  }

  function getState(it) {
    var o = unpackKV(readTag(it, TAG));
    if (!o) return null;
    var nums = ['a', 'L', 'O', 'F', 'S', 'sa', 'sb', 'R', 'H', 'Hb', 'h', 'n', 'dn', 'dist', 'size', 'fall', 'dir', 'ma', 'mb', 'mc', 'md'];
    for (var i = 0; i < nums.length; i++) if (o[nums[i]] !== undefined) o[nums[i]] = parseFloat(o[nums[i]]);
    return o;
  }

  function setState(it, st) {
    writeTag(it, TAG, packKV(st));
  }

  /* ---------- 2×2 행렬 · 변형 (hy Iso와 같은 방식) ---------- */
  // 점 (x, y) → (a·x + c·y, b·x + d·y)
  function mat(a, b, c, d) {
    return { a: a, b: b, c: c, d: d };
  }

  function apply(M, p) {
    return [M.a * p[0] + M.c * p[1], M.b * p[0] + M.d * p[1]];
  }

  function mul(M, N) { // N 먼저, 그다음 M
    return mat(M.a * N.a + M.c * N.b, M.b * N.a + M.d * N.b, M.a * N.c + M.c * N.d, M.b * N.c + M.d * N.d);
  }

  function inv(M) {
    var det = M.a * M.d - M.b * M.c;
    if (Math.abs(det) < 1e-12) throw new Error('그림자 모양이 납작해져 다시 맞출 수 없어요 — 다시 맞추기를 눌러 주세요');
    return mat(M.d / det, -M.b / det, -M.c / det, M.a / det);
  }

  function near(M, N) {
    var tol = 1e-3 * (1 + Math.abs(N.a) + Math.abs(N.b) + Math.abs(N.c) + Math.abs(N.d));
    return Math.abs(M.a - N.a) < tol && Math.abs(M.b - N.b) < tol &&
           Math.abs(M.c - N.c) < tol && Math.abs(M.d - N.d) < tol;
  }

  function aiMatrix(M) {
    var m = app.getIdentityMatrix();
    m.mValueA = M.a; m.mValueB = M.b; m.mValueC = M.c; m.mValueD = M.d;
    m.mValueTX = 0; m.mValueTY = 0;
    return m;
  }

  // 임시 패스로 "문서 원점 기준 변형"이 실제로 어떤 사상인지 잰다.
  function probe(container, M) {
    var p = container.pathItems.add();
    p.filled = false;
    p.stroked = false;
    p.setEntirePath([[0, 0], [100, 0], [0, 100]]);
    p.transform(aiMatrix(M), true, false, false, false, 100, Transformation.DOCUMENTORIGIN);
    var a0 = p.pathPoints[0].anchor, a1 = p.pathPoints[1].anchor, a2 = p.pathPoints[2].anchor;
    p.remove();
    return {
      q0: [a0[0], a0[1]],
      L: mat((a1[0] - a0[0]) / 100, (a1[1] - a0[1]) / 100, (a2[0] - a0[0]) / 100, (a2[1] - a0[1]) / 100)
    };
  }

  function flipped(M) {
    return mat(M.a, -M.b, -M.c, M.d);
  }

  // 원하는 선형 변형 L을 내려면 넘길 행렬과, 원점(0,0)이 가는 자리 q0
  function calibrate(container, L) {
    var key = [L.a, L.b, L.c, L.d].join(',');
    if (calCache[key]) return calCache[key];
    var order = flipMode === true ? [true, false] : [false, true];
    for (var i = 0; i < order.length; i++) {
      var M = order[i] ? flipped(L) : L;
      var r = probe(container, M);
      if (near(r.L, L)) {
        flipMode = order[i];
        calCache[key] = { M: M, q0: r.q0 };
        return calCache[key];
      }
    }
    throw new Error('변형 기준을 맞추지 못했어요');
  }

  // 점 x → P + L(x − P). 그라디언트도 같이 변형한다.
  function applyAbout(it, L, P) {
    var cal = calibrate(it.layer, L);
    var LP = apply(L, P);
    var dx = P[0] - LP[0] - cal.q0[0];
    var dy = P[1] - LP[1] - cal.q0[1];
    it.transform(aiMatrix(cal.M), true, false, true, false, 100, Transformation.DOCUMENTORIGIN);
    it.translate(dx, dy, true, false, true, false);
  }

  /* ---------- 그림자 계산 (core.js 와 같은 식 — 시험이 둘을 대조한다) ---------- */
  function shear(angle, lengthPct) {
    var L = Math.max(0.02, lengthPct / 100);
    var th = angle * Math.PI / 180;
    var a = L * Math.cos(th), b = L * Math.sin(th);
    if (Math.abs(a) < 1e-9) a = 0;
    if (Math.abs(b) < MIN_B) b = b < 0 ? -MIN_B : MIN_B;
    return { a: a, b: b };
  }

  // 정지점 [위치 %, 불투명도 %]. 선명 ∪ 번짐 = 1 − 흐려짐 × t (t: 발 0 → 끝 1)
  function formStops(fadePct, withBlur) {
    // 번짐은 발에서 0 → 끝으로 갈수록 (발은 또렷), 선명은 겹친 결과가 목표가 되게 맞춘다. 정지점 9개(사이는 직선).
    var F = clamp(fadePct / 100, 0, 1), sharp = [], blur = [];
    for (var i = 0; i <= 8; i++) {
      var t = i / 8, D = 1 - F * t;
      var B = withBlur ? D * t : 0;
      var S = withBlur ? (B < 0.9999 ? (D - B) / (1 - B) : 0) : D;
      sharp.push([t * 100, Math.round(S * 1000) / 10]);
      blur.push([t * 100, Math.round(B * 1000) / 10]);
    }
    return { sharp: sharp, blur: withBlur ? blur : null };
  }

  function blurRadius(softPct, lengthPct, H) {
    return clamp((softPct / 100) * (lengthPct / 100) * H, 0, 250);
  }

  /* ---------- 문서·선택 ---------- */
  function getDoc() {
    if (app.documents.length == 0) throw new Error('열린 문서가 없어요');
    return app.activeDocument;
  }

  function selItems(doc) {
    var sel = doc.selection;
    if (sel && sel.typename == 'TextRange') throw new Error('글자 편집 중이에요. Esc로 빠져나온 뒤 개체를 선택해 주세요');
    var out = [];
    if (!sel) return out;
    for (var i = 0; i < sel.length; i++) out.push(sel[i]);
    return out;
  }

  function selectOnly(doc, items) {
    doc.selection = null;
    for (var i = 0; i < items.length; i++) {
      try { items[i].selected = true; } catch (e) {}
    }
  }

  function selected(doc) {
    var s = doc.selection, out = [];
    if (!s || s.typename == 'TextRange') return out;
    for (var i = 0; i < s.length; i++) out.push(s[i]);
    return out;
  }

  function reselect(doc, items) {
    try {
      doc.selection = null;
      var arr = [];
      for (var i = 0; i < items.length; i++) if (items[i]) arr.push(items[i]);
      if (arr.length) doc.selection = arr;
    } catch (e) {}
  }

  // 같은 개체인지는 참조로 비교하지 않는다(판마다 다를 수 있음) — id·경계로 만든 열쇠로
  function keyOf(it) {
    try {
      var u = it.uuid;
      if (u) return 'u:' + u;
    } catch (e0) {}
    var s = '';
    try {
      var st = getState(it);
      if (st && st.id) s = st.id;
      var b = it.geometricBounds;
      s += '@' + it.typename + ':' + Math.round(b[0] * 10) + ',' + Math.round(b[1] * 10) + ',' + Math.round(b[2] * 10) + ',' + Math.round(b[3] * 10);
      s += ':' + it.name;
    } catch (e) {}
    return s;
  }

  function addOnce(list, keys, it) {
    var k = keyOf(it);
    if (keys[k]) return false;
    keys[k] = 1;
    list.push(it);
    return true;
  }

  function isWrapper(it) {
    return it.typename == 'GroupItem' && readTag(it, TAG) !== null;
  }

  function stopAt(it) {
    var t = it.typename;
    return t == 'Layer' || t == 'Document';
  }

  // 그 개체를 감싸는(자기 자신 포함) 우리 그룹 — 태그가 붙은 가장 가까운 조상
  function shadowOf(it) {
    var p = it;
    try {
      while (p && !stopAt(p)) {
        if (p.typename == 'GroupItem' && readTag(p, TAG) !== null) return p;
        p = p.parent;
      }
    } catch (e) {}
    return null;
  }

  function kindOf(w) {
    var st = getState(w);
    return st ? st.k : '';
  }

  function blocked(it) {
    try {
      if (it.locked || it.hidden) return true;
      var p = it.parent;
      while (p && !stopAt(p)) {
        if (p.locked || p.hidden) return true;
        p = p.parent;
      }
      var L = it.layer;
      while (L && L.typename == 'Layer') {
        if (L.locked || !L.visible) return true;
        L = L.parent;
      }
    } catch (e) {}
    return false;
  }

  function withDocCoords(fn) {
    var prev = null;
    try {
      prev = app.coordinateSystem;
      app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    } catch (e) { prev = null; }
    try {
      return fn();
    } finally {
      if (prev !== null) {
        try { app.coordinateSystem = prev; } catch (e2) {}
      }
    }
  }

  function newId() {
    return 's' + (new Date().getTime()).toString(36) + Math.floor(Math.random() * 1296).toString(36);
  }

  /* ---------- 색 ---------- */
  function isCMYK(doc) {
    try { return doc.documentColorSpace == DocumentColorSpace.CMYK; } catch (e) { return false; }
  }

  function makeColor(doc, rgb) {
    if (isCMYK(doc)) {
      var v = null;
      try { v = app.convertSampleColor(ImageColorSpace.RGB, [rgb[0], rgb[1], rgb[2]], ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose); } catch (e) {}
      if (!v || v.length < 4) {
        var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, k = 1 - Math.max(r, g, b);
        v = k >= 1 ? [0, 0, 0, 100] : [(1 - r - k) / (1 - k) * 100, (1 - g - k) / (1 - k) * 100, (1 - b - k) / (1 - k) * 100, k * 100];
      }
      var c = new CMYKColor();
      c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
      return c;
    }
    var o = new RGBColor();
    o.red = rgb[0]; o.green = rgb[1]; o.blue = rgb[2];
    return o;
  }

  function toRGB(col) {
    if (!col) return null;
    var t = col.typename, v;
    if (t == 'RGBColor') return [col.red, col.green, col.blue];
    if (t == 'CMYKColor') {
      try { v = app.convertSampleColor(ImageColorSpace.CMYK, [col.cyan, col.magenta, col.yellow, col.black], ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose); } catch (e) { v = null; }
      if (!v) { var k = col.black / 100; v = [255 * (1 - col.cyan / 100) * (1 - k), 255 * (1 - col.magenta / 100) * (1 - k), 255 * (1 - col.yellow / 100) * (1 - k)]; }
      return [v[0], v[1], v[2]];
    }
    if (t == 'GrayColor') { var g = 255 * (1 - col.gray / 100); return [g, g, g]; }
    if (t == 'SpotColor') {
      try {
        var base = toRGB(col.spot.color), tint = col.tint / 100;
        return [255 - (255 - base[0]) * tint, 255 - (255 - base[1]) * tint, 255 - (255 - base[2]) * tint];
      } catch (e2) {}
    }
    return null;
  }

  function hex2(n) {
    var s = Math.round(clamp(n, 0, 255)).toString(16);
    return s.length < 2 ? '0' + s : s;
  }

  function fromHex(h) {
    if (!h || !/^[0-9a-fA-F]{6}$/.test(h)) return null;
    return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
  }

  // 그림자 색: 검정 · 그늘색 · 고른 색(패널이 일러스트 색상 피커로 고른 hex)
  function shadowColor(doc, key, hex) {
    var rgb = [0, 0, 0];
    if (key == 'navy') rgb = NAVY;
    else if (key == 'custom') rgb = fromHex(hex) || [60, 74, 92];
    return { col: makeColor(doc, rgb), rgb: rgb, hex: hex2(rgb[0]) + hex2(rgb[1]) + hex2(rgb[2]) };
  }

  // 일러스트 색상 피커 → hex (취소하면 그대로)
  function pickColor(argStr) {
    var a = parseArgs(argStr);
    var doc = getDoc();
    var start = makeColor(doc, fromHex(a.hex) || [60, 74, 92]);
    var c = app.showColorPicker(start);
    var rgb = toRGB(c);
    if (!rgb) return fail('색을 읽지 못했어요');
    var hx = hex2(rgb[0]) + hex2(rgb[1]) + hex2(rgb[2]);
    return done({ hex: hx, changed: hx.toLowerCase() != String(a.hex || '').toLowerCase() });
  }

  /* ---------- 그라디언트 ---------- */
  function sortedStops(g) {
    var arr = [], gs = g.gradientStops, i;
    for (i = 0; i < gs.length; i++) arr.push({ s: gs[i], p: gs[i].rampPoint, i: i });
    arr.sort(function (a, b) { return a.p - b.p || a.i - b.i; });
    return arr;
  }

  // 같은 내용이면 같은 이름 → 다시 쓴다 (스와치가 늘지 않게). 이미 있는 것은 고치지 않는다.
  function gradientFor(doc, kind, stops, sc) {
    var parts = [];
    for (var i = 0; i < stops.length; i++) parts.push(Math.round(stops[i][1]));
    var name = GRAD + kind + ' ' + sc.hex + ' ' + parts.join('-');
    try { return doc.gradients.getByName(name); } catch (e) {}
    var g = doc.gradients.add();
    try { g.name = name; } catch (e1) {}
    try { g.type = GradientType.LINEAR; } catch (e2) {}
    var gs = g.gradientStops, pass, arr, ch;
    while (gs.length < stops.length) gs.add();
    while (gs.length > stops.length) gs[gs.length - 1].remove();
    for (pass = 0; pass < 4; pass++) {
      arr = sortedStops(g); ch = false;
      for (i = 0; i < stops.length; i++) {
        if (Math.abs(arr[i].p - stops[i][0]) > 0.01) { arr[i].s.rampPoint = stops[i][0]; ch = true; }
      }
      if (!ch) break;
    }
    arr = sortedStops(g);
    for (i = 0; i < stops.length; i++) {
      var s = arr[i].s;
      s.color = sc.col;
      try { s.opacity = stops[i][1]; } catch (e3) {}
      try { s.midPoint = 50; } catch (e4) {}
    }
    return g;
  }

  function paths(it) {
    if (it.typename == 'CompoundPathItem') {
      var out = [];
      for (var i = 0; i < it.pathItems.length; i++) out.push(it.pathItems[i]);
      return out;
    }
    if (it.typename == 'PathItem') return [it];
    return [];
  }

  // 칠할 대상: 복합 패스는 조각들이 칠을 같이 쓰므로 첫 조각 하나만 칠하면 된다.
  // (조각마다 칠하면 일러스트가 매번 복합 패스 전체를 다시 계산 — 조각 수백 개면 수백 × 수백 번이라 멈췄다)
  function paintTargets(it) {
    if (it.typename == 'CompoundPathItem') return it.pathItems.length ? [it.pathItems[0]] : [];
    return paths(it);
  }

  function paintSolid(it, col) {
    var ps = paintTargets(it);
    for (var i = 0; i < ps.length; i++) {
      ps[i].filled = true;
      ps[i].fillColor = col;
      ps[i].stroked = false;
    }
  }

  // 새 그라디언트를 입히면 일러스트는 경계 상자 왼쪽 가운데 → 오른쪽 가운데(길이 = 너비)로 놓는다.
  // 그라디언트만 90° 돌리고 높이만큼 늘이면 아래 가운데 → 위 가운데가 된다 (hy Gradient fit 과 같은 방법).
  function paintVertical(it, g) {
    var ps = paintTargets(it), i;
    for (i = 0; i < ps.length; i++) {
      var gc = new GradientColor();
      gc.gradient = g;
      ps[i].filled = true;
      ps[i].fillColor = gc;
      ps[i].stroked = false;
    }
    var b = it.geometricBounds;
    var w = Math.max(b[2] - b[0], 0.01), h = Math.max(b[1] - b[3], 0.01);
    it.rotate(90, false, false, true, false, Transformation.CENTER);
    var k = h / w;
    if (Math.abs(k - 1) > 1e-4) it.resize(k * 100, k * 100, false, false, true, false, 100, Transformation.CENTER);
  }

  function gradName(it) {
    var ps = paths(it);
    try {
      if (ps.length && ps[0].filled && ps[0].fillColor.typename == 'GradientColor') return ps[0].fillColor.gradient.name;
    } catch (e) {}
    return '';
  }

  // 'hy 그림자 …' 그라디언트가 많이 쌓이면, 문서 어디에서도 안 쓰는 것만 지운다.
  // (쓰는 중인 그라디언트를 지우면 일러스트가 그 칠도 없앤다 — 그래서 모든 패스를 훑고, 기호가 있으면 아예 안 지운다)
  function cleanupGradients(doc) {
    try {
      var cand = [], i;
      for (i = 0; i < doc.gradients.length; i++) {
        var g = doc.gradients[i];
        if (g.name.indexOf(GRAD) === 0) cand.push(g);
      }
      if (cand.length <= 24) return;   // 조금 쌓이는 것은 둔다 — 지우려면 문서의 모든 패스를 훑어야 해서 무거움
      try { if (doc.symbols.length > 0) return; } catch (e0) {}
      var used = {}, ps = doc.pathItems;
      for (i = 0; i < ps.length; i++) {
        var p = ps[i];
        try { if (p.filled && p.fillColor.typename == 'GradientColor') used[p.fillColor.gradient.name] = 1; } catch (e1) {}
        try { if (p.stroked && p.strokeColor.typename == 'GradientColor') used[p.strokeColor.gradient.name] = 1; } catch (e2) {}
      }
      for (i = cand.length - 1; i >= 0; i--) {
        if (!used[cand[i].name]) { try { cand[i].remove(); } catch (e3) {} }
      }
    } catch (e) {}
  }

  /* ---------- 흐림 효과 ---------- */
  function effectXML(name, key, r) {
    return '<LiveEffect name="' + name + '"><Dict data="R ' + key + ' ' + r3(r) + ' "/></LiveEffect>';
  }

  function growth(container, name, r) {
    var p = container.pathItems.rectangle(0, 0, 20, 20);
    try {
      p.stroked = false;
      p.filled = true;
      p.fillColor = makeColor(app.activeDocument, [0, 0, 0]);
      var a = p.visibleBounds;
      try { p.applyEffect(effectXML(name, 'blur', r)); } catch (e) { return 0; }
      var b = p.visibleBounds;   // app.redraw() 는 실행 취소를 여러 단계로 쪼개서 쓰지 않는다
      return (b[2] - b[0]) - (a[2] - a[0]);
    } finally {
      try { p.remove(); } catch (e3) {}
    }
  }

  // 가우시안 흐림 효과 이름은 판마다 다를 수 있어서, 반경에 따라 보이는 경계가 넓어지는 이름을 찾는다.
  // 경계로 못 알아보면(다시 그리기 전엔 경계가 안 바뀌는 판일 수 있음) 가장 그럴듯한 이름을 쓰고,
  // 효과 넣기가 오류를 내면 페더(Adobe Fuzzy Mask)로 바꾼다.
  var BLUR_NAMES = ['Adobe PSL Gaussian Blur', 'Adobe Gaussian Blur'];

  function blurKind(container) {
    if (blurInfo) return blurInfo;
    for (var i = 0; i < BLUR_NAMES.length; i++) {
      var g4 = growth(container, BLUR_NAMES[i], 4);
      if (g4 < 0.5) continue;
      var g16 = growth(container, BLUR_NAMES[i], 16);
      if (g16 > g4 + 2) {
        blurInfo = { name: BLUR_NAMES[i], key: 'blur', feather: false };
        return blurInfo;
      }
    }
    blurInfo = { name: BLUR_NAMES[0], key: 'blur', feather: false, guess: true };
    return blurInfo;
  }

  function applyBlur(it, r) {
    if (r < 0.3) return;
    var b = blurKind(it.layer);
    try {
      it.applyEffect(effectXML(b.name, b.key, r));
    } catch (e) {
      if (b.feather) throw e;
      blurInfo = { name: 'Adobe Fuzzy Mask', key: 'Radius', feather: true };
      it.applyEffect(effectXML(blurInfo.name, blurInfo.key, r));
    }
  }

  /* ---------- 실루엣 (모든 개체 → 칠한 모양 하나) ---------- */
  function first(doc) {
    var s = doc.selection;
    return (s && s.length && s.typename != 'TextRange') ? s[0] : null;
  }

  function menu(cmd) {
    app.executeMenuCommand(cmd);
  }

  function traceImage(doc, it) {
    var pi = it.trace();
    try {
      var o = pi.tracing.tracingOptions;
      try { o.tracingMode = TracingModeType.TRACINGMODEBLACKANDWHITE; } catch (e1) {}
      try { o.threshold = 240; } catch (e2) {}
      try { o.ignoreWhite = true; } catch (e3) {}
      try { o.fills = true; } catch (e4) {}
      try { o.strokes = false; } catch (e5) {}
    } catch (e) {}
    try { app.redraw(); } catch (e6) {}
    return pi.tracing.expandTracing();
  }

  // 글자·기호·이미지·플러그인 개체를 일반 도형으로. 그룹은 안쪽까지.
  function toArt(doc, it, info) {
    var t = it.typename, i;
    try { it.locked = false; } catch (e0) {}
    if (t == 'TextFrame') return it.createOutline();
    if (t == 'SymbolItem') {
      selectOnly(doc, [it]);
      it.breakLink();
      return first(doc);
    }
    if (t == 'PlacedItem' || t == 'RasterItem') {
      info.image = true;
      return traceImage(doc, it);
    }
    if (t == 'PluginItem' || t == 'MeshItem' || t == 'GraphItem' || t == 'LegacyTextItem') {
      selectOnly(doc, [it]);
      try { menu('expandStyle'); } catch (e1) {}
      return first(doc);
    }
    if (t == 'GroupItem') {
      var kids = [];
      for (i = 0; i < it.pageItems.length; i++) kids.push(it.pageItems[i]);
      for (i = 0; i < kids.length; i++) toArt(doc, kids[i], info);
    }
    return it;
  }

  function isPainted(p) {
    try { return p.filled || p.stroked || p.clipping; } catch (e) { return true; }
  }

  // 숨긴 것과 칠·획이 없는 패스(안 보이는 테두리 상자 등)는 실루엣에서 뺀다. 비게 된 그룹도.
  function dropInvisible(it) {
    var t = it.typename, i;
    if (t == 'GroupItem') {
      for (i = it.pageItems.length - 1; i >= 0; i--) {
        var c = it.pageItems[i];
        try { c.locked = false; } catch (e0) {}
        var gone = false;
        try { if (c.hidden) { c.remove(); gone = true; } } catch (e1) {}
        if (gone) continue;
        dropInvisible(c);
        try { if (c.typename == 'GroupItem' && c.pageItems.length == 0) c.remove(); } catch (e4) {}
      }
      return;
    }
    if (t == 'PathItem') {
      if (!isPainted(it)) { try { it.remove(); } catch (e2) {} }
      return;
    }
    if (t == 'CompoundPathItem') {
      if (it.pathItems.length && !isPainted(it.pathItems[0])) { try { it.remove(); } catch (e3) {} }
    }
  }

  // 복사본 안에 든 우리 그림자 조각(형상 그림자 묶음·평면 그림자)은 빼고 개체만 남긴다
  function stripParts(it) {
    if (it.typename != 'GroupItem') return;
    for (var i = it.pageItems.length - 1; i >= 0; i--) {
      var c = it.pageItems[i];
      var part = readTag(c, TAG_PART), st = c.typename == 'GroupItem' ? getState(c) : null;
      if (part == 'sg' || (st && st.k == 'plan')) { try { c.remove(); } catch (e) {} continue; }
      stripParts(c);
    }
  }

  // 모양 확장으로 생긴 이미지(그림자·광선·흐림 효과가 래스터로 풀린 것)는 실루엣에서 뺀다
  function dropRasters(it) {
    var t = it.typename;
    if (t == 'RasterItem' || t == 'PlacedItem') { try { it.remove(); } catch (e) {} return; }
    if (t == 'GroupItem') for (var i = it.pageItems.length - 1; i >= 0; i--) dropRasters(it.pageItems[i]);
  }

  function findClip(it) {
    if (it.typename != 'GroupItem') return null;
    for (var i = 0; i < it.pageItems.length; i++) {
      var r = findClip(it.pageItems[i]);
      if (r) return r;
    }
    return it.clipped ? it : null;
  }

  // 클리핑 그룹은 마스크 안쪽만 남긴다 (패스파인더 자르기). 안 되면 마스크를 풀고 마스크 패스를 지운다.
  function cropClips(doc, root) {
    for (var n = 0; n < 40; n++) {
      var g = findClip(root);
      if (!g) return;
      var ok = false;
      try {
        selectOnly(doc, [g]);
        menu('Live Pathfinder Crop');
        menu('expandStyle');
        ok = true;
      } catch (e) {}
      var still = false;
      try { still = g.typename == 'GroupItem' && g.clipped; } catch (e2) { still = false; }
      if (!ok || still) {
        try {
          g.clipped = false;
          for (var i = g.pageItems.length - 1; i >= 0; i--) {
            var c = g.pageItems[i];
            if ((c.typename == 'PathItem' && c.clipping) ||
                (c.typename == 'CompoundPathItem' && c.pathItems.length && c.pathItems[0].clipping)) c.remove();
          }
        } catch (e3) { return; }
      }
    }
  }

  function wrapInGroup(it) {
    if (it.typename == 'GroupItem' && !it.clipped) return it;
    var g = it.parent.groupItems.add();
    g.move(it, ElementPlacement.PLACEBEFORE);
    it.move(g, ElementPlacement.PLACEATEND);
    return g;
  }

  // 포함 관계로 안쪽 조각(구멍과 그 안 섬)을 지워 속을 채운다
  function ringOf(p) {
    var pts = p.pathPoints, out = [];
    for (var i = 0; i < pts.length; i++) out.push(pts[i].anchor);
    return out;
  }

  function inside(pt, ring) {
    var c = false, n = ring.length;
    for (var i = 0, j = n - 1; i < n; j = i++) {
      var xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
      if (((yi > pt[1]) != (yj > pt[1])) && (pt[0] < (xj - xi) * (pt[1] - yi) / (yj - yi) + xi)) c = !c;
    }
    return c;
  }

  function areaOf(ring) {
    var s = 0, n = ring.length;
    for (var i = 0, j = n - 1; i < n; j = i++) s += (ring[j][0] + ring[i][0]) * (ring[j][1] - ring[i][1]);
    return Math.abs(s / 2);
  }

  function fillHoles(cp) {
    if (cp.typename != 'CompoundPathItem' || cp.pathItems.length < 2) return 0;
    var n = cp.pathItems.length, rings = [], areas = [], i, j, kill = [];
    for (i = 0; i < n; i++) {
      rings.push(ringOf(cp.pathItems[i]));
      areas.push(areaOf(rings[i]));
    }
    for (i = 0; i < n; i++) {
      var pt = rings[i][0], hit = false;
      if (!pt) continue;
      for (j = 0; j < n && !hit; j++) {
        if (j == i || areas[j] <= areas[i] || rings[j].length < 3) continue;
        if (inside(pt, rings[j])) hit = true;
      }
      if (hit) kill.push(i);
    }
    for (i = kill.length - 1; i >= 0; i--) cp.pathItems[kill[i]].remove();
    return kill.length;
  }

  // 그림자 재료가 되는 개체 목록 (우리 그룹이면 안의 원래 개체만)
  function sourcesOf(it) {
    if (it.typename == 'GroupItem') {
      var st = getState(it), out = [], i;
      if (st && st.k == 'form') {
        for (i = 0; i < it.pageItems.length; i++) if (it.pageItems[i].name != NAME_SG) out.push(it.pageItems[i]);
        return out;
      }
      if (st && st.k == 'drop') {
        for (i = 0; i < it.pageItems.length; i++) out.push(it.pageItems[i]);
        return out;
      }
      if (st && st.k == 'plan') return [];
    }
    return [it];
  }

  // 메뉴 명령 뒤 선택: 없으면 그대로, 하나면 그것, 여럿이면 한 그룹으로
  function afterMenu(doc, fallback) {
    var s = selected(doc);
    if (!s.length) return fallback;
    if (s.length == 1) return s[0];
    var g = s[0].parent.groupItems.add();
    g.move(s[0], ElementPlacement.PLACEBEFORE);
    for (var i = 0; i < s.length; i++) s[i].move(g, ElementPlacement.PLACEATEND);
    return g;
  }

  function alive(it) {
    try { return !!it && !!it.typename; } catch (e) { return false; }
  }

  // 개체(들)의 복사본을 칠한 모양 하나(패스 또는 복합 패스)로. 원본은 건드리지 않는다.
  // 결과는 첫 원본과 같은 그릇(부모)에 생긴다. 중간에 실패하면 만든 것을 지운다.
  function silhouette(doc, items, holes, info) {
    var srcs = [], i;
    for (i = 0; i < items.length; i++) {
      var s = sourcesOf(items[i]);
      for (var k = 0; k < s.length; k++) srcs.push(s[k]);
    }
    if (!srcs.length) return null;
    var host = srcs[0].parent;
    var cur = host.groupItems.add();
    var touched = false;   // 선택을 우리 임시 개체로 바꾼 뒤부터는 실패 때 선택된 것도 지운다
    cur.move(srcs[0], ElementPlacement.PLACEBEFORE);
    try {
      for (i = 0; i < srcs.length; i++) {
        var d = srcs[i].duplicate();
        d.move(cur, ElementPlacement.PLACEATEND);
      }
      try { cur.hidden = false; cur.locked = false; } catch (e0) {}
      doc.selection = null;
      touched = true;
      stripParts(cur);
      toArt(doc, cur, info);
      dropInvisible(cur);
      if (!cur.pageItems.length) { cur.remove(); return null; }
      selectOnly(doc, [cur]);
      menu('expandStyle');                       // 모양 확장 (효과·브러쉬·여러 칠)
      cur = wrapInGroup(afterMenu(doc, cur));
      dropRasters(cur);
      dropInvisible(cur);
      if (!cur.pageItems.length) { cur.remove(); return null; }
      selectOnly(doc, [cur]);
      menu('OffsetPath v22');                    // 획 윤곽선 (자르기는 획을 지우므로 먼저)
      cur = wrapInGroup(afterMenu(doc, cur));
      cropClips(doc, cur);                        // 클리핑 마스크 안쪽만
      dropInvisible(cur);
      selectOnly(doc, [cur]);
      menu('Live Pathfinder Add');               // 합치기
      menu('expandStyle');
      cur = afterMenu(doc, cur);
      if (cur.typename == 'GroupItem') {
        if (cur.pageItems.length == 1 && cur.pageItems[0].typename != 'GroupItem') {
          var only = cur.pageItems[0];
          only.move(cur, ElementPlacement.PLACEBEFORE);
          cur.remove();
          cur = only;
        } else {
          selectOnly(doc, [cur]);
          menu('compoundPath');                  // 복합 패스 만들기
          cur = afterMenu(doc, cur);
        }
      }
      if (cur.typename != 'PathItem' && cur.typename != 'CompoundPathItem') throw new Error('모양을 하나로 합치지 못했어요');
      var sb = cur.geometricBounds;
      if ((cur.typename == 'CompoundPathItem' && cur.pathItems.length == 0) || sb[2] - sb[0] < 0.01 || sb[1] - sb[3] < 0.01) {
        throw new Error('그림자를 만들 모양이 없어요');
      }
      if (holes) fillHoles(cur);
      paintSolid(cur, makeColor(doc, [0, 0, 0]));
      try { cur.opacity = 100; cur.blendingMode = BlendModes.NORMAL; } catch (e2) {}
      try { cur.hidden = false; } catch (e4) {}
      return cur;
    } catch (e) {
      if (alive(cur)) { try { cur.remove(); } catch (e3) {} }
      if (touched) {
        var left = selected(doc);
        for (var q = left.length - 1; q >= 0; q--) { try { left[q].remove(); } catch (e5) {} }
      }
      throw e;
    }
  }

  /* ---------- 형상 그림자 ---------- */
  // 그림자 묶음·조각은 이름이 아니라 표시(hyShadowPart)로 찾는다 — 사용자 그룹 이름이 '그림자'여도 건드리지 않게
  function partOf(g, part) {
    for (var i = 0; i < g.pageItems.length; i++) {
      var c = g.pageItems[i];
      if (readTag(c, TAG_PART) == part) return c;
    }
    return null;
  }

  function shadowGroup(w) {
    var g = partOf(w, 'sg');
    return g && g.typename == 'GroupItem' ? g : null;
  }

  // 기준 패스: 세운 상태에서 옆(1,0) · 발(0,0) · 머리(0,H). 칠·획 없이 그림자와 같이 변형되어 지금 어떻게 놓였는지 알려 준다.
  function makeRef(sg, foot, H) {
    var r = sg.pathItems.add();
    r.setEntirePath([[foot[0] + 1, foot[1]], [foot[0], foot[1]], [foot[0], foot[1] + H]]);
    r.closed = false;
    r.filled = false;
    r.stroked = false;
    r.name = NAME_REF;
    writeTag(r, TAG_PART, 'ref');
    return r;
  }

  function readRef(sg, H) {
    var r = partOf(sg, 'ref');
    if (!r || r.typename != 'PathItem' || r.pathPoints.length < 3 || !(H > 0)) return null;
    var s = r.pathPoints[0].anchor, f = r.pathPoints[1].anchor, h = r.pathPoints[2].anchor;
    return { F: [f[0], f[1]], M: mat(s[0] - f[0], s[1] - f[1], (h[0] - f[0]) / H, (h[1] - f[1]) / H) };
  }

  // 기준 패스가 있으면 임시 패스로 재지 않는다: 변형 → 기준 패스로 발 자리를 읽어 그만큼 되돌려 옮김.
  // (재기는 해석 방향을 모를 때 한 번만 — 슬라이더를 끌 때마다 임시 패스를 만들고 지우면 일러스트가 버벅임)
  function fastAbout(sg, D, F, Mn, H) {
    if (flipMode === null) { applyAbout(sg, D, F); return; }
    sg.transform(aiMatrix(flipMode ? flipped(D) : D), true, false, true, false, 100, Transformation.DOCUMENTORIGIN);
    var r = readRef(sg, H);
    if (!r) throw new Error('그림자 기준을 읽지 못했어요');
    if (!near(r.M, Mn)) {
      // 해석이 어긋났으면 다시 재서 지금 모양 → 원하는 모양으로
      flipMode = null;
      calCache = {};
      var D2 = mul(Mn, inv(r.M));
      if (!isIdentity(D2)) applyAbout(sg, D2, r.F);
    }
    var dx = F[0] - r.F[0], dy = F[1] - r.F[1];
    if (Math.abs(dx) > 1e-6 || Math.abs(dy) > 1e-6) sg.translate(dx, dy, true, false, true, false);
  }

  function isIdentity(D) {
    return Math.abs(D.a - 1) < 1e-9 && Math.abs(D.b) < 1e-9 && Math.abs(D.c) < 1e-9 && Math.abs(D.d - 1) < 1e-9;
  }

  // 지금 기울기 (st.sa, st.sb) → 새 기울기 (na, nb).
  // 기준 패스로 지금 놓인 모양 M 을 읽는다. 마지막에 우리가 둔 모양(st.ma…)과 다르면 그 사이 사용자가 묶음을
  // 옮기거나 키우거나 뒤집은 것 → 개체도 그만큼 변형된 것으로 보고 그 개체의 그림자로 맞춘다.
  function setShear(sg, st, na, nb) {
    var Sn = mat(1, 0, na, nb), Sc = mat(1, 0, st.sa, st.sb);
    var ref = readRef(sg, st.H);
    if (!ref) {
      // 기준이 없으면 경계로 (바닥선 = 그림자 맨 아래, 앞으로 눕힌 것은 맨 위)
      if (Math.abs(na - st.sa) < 1e-7 && Math.abs(nb - st.sb) < 1e-7) return;
      var gb = sg.geometricBounds;
      var G = st.sb > 0 ? gb[3] : gb[1];
      applyAbout(sg, mat(1, 0, (na - st.sa) / st.sb, nb / st.sb), [gb[0], G]);
      st.sa = na;
      st.sb = nb;
      return;
    }
    var Mc = ref.M;
    var Ms = st.ma === undefined || isNaN(st.ma) ? Mc : mat(st.ma, st.mb, st.mc, st.md);
    var U = mul(mul(Mc, inv(Ms)), mul(inv(Sc), Ms));   // 개체에 걸린 변형
    var Mn = mul(Sn, U);
    var D = mul(Mn, inv(Mc));
    if (!isIdentity(D)) fastAbout(sg, D, ref.F, Mn, st.H);
    st.sa = na;
    st.sb = nb;
    st.ma = r6(Mn.a); st.mb = r6(Mn.b); st.mc = r6(Mn.c); st.md = r6(Mn.d);
  }

  function readP(p) {
    var c = p.color;
    return {
      angle: num(p.angle, 30),
      length: clamp(num(p.length, 70), 2, 400),
      opacity: clamp(num(p.opacity, 55), 0, 100),
      soften: clamp(num(p.soften, 8), 0, 30),
      fade: clamp(num(p.fade, 40), 0, 100),
      color: c == 'navy' || c == 'custom' ? c : 'black',
      mode: p.mode == 'normal' ? 'normal' : 'multiply',
      holes: p.holes !== false
    };
  }

  var FORM_KEYS = ['angle', 'length', 'opacity', 'fade', 'soften', 'color', 'mode'];

  // 그림자마다 저장된 값에, 지금 바꾸는 값(only)만 덮는다 — 여러 개를 골라도 다른 값은 각자 그대로
  function paramsFor(st, p, only, hex) {
    var q = { angle: st.a, length: st.L, opacity: st.O, soften: st.S, fade: st.F, color: st.c, mode: st.m, holes: st.h == 1 };
    for (var i = 0; i < only.length; i++) {
      var k = only[i];
      if (p[k] !== undefined && p[k] !== null) q[k] = p[k];
    }
    var r = readP(q);
    r.hex = st.fc || '';
    if (inArr(only, 'color') && r.color == 'custom' && hex) r.hex = hex;
    return r;
  }

  // 세운(기울이지 않은) 상태에서 칠을 새로 입힌다: 선명(그라디언트) + 번짐(그라디언트 + 흐림)
  function paintUpright(doc, sg, q, st) {
    var sharp = partOf(sg, 'sharp');
    if (!sharp) throw new Error('그림자 모양을 찾지 못했어요');
    for (var i = sg.pageItems.length - 1; i >= 0; i--) {
      if (readTag(sg.pageItems[i], TAG_PART) == 'soft') sg.pageItems[i].remove();
    }
    var b = sharp.geometricBounds;
    var Hb = Math.max(b[1] - b[3], 0.01);
    var sc = shadowColor(doc, q.color, q.hex);
    var R = blurRadius(q.soften, q.length, Hb);
    var useBlur = R >= 0.5;
    var stops = formStops(q.fade, useBlur);
    paintVertical(sharp, gradientFor(doc, 'S', stops.sharp, sc));
    tMark('선명 칠');
    if (useBlur) {
      var soft = sharp.duplicate();
      soft.name = NAME_SOFT;
      writeTag(soft, TAG_PART, 'soft');
      soft.move(sg, ElementPlacement.PLACEATEND);
      paintVertical(soft, gradientFor(doc, 'B', stops.blur, sc));
      tMark('번짐 칠');
      applyBlur(soft, R);
      tMark('흐림 효과');
    }
    st.F = q.fade; st.S = q.soften; st.c = q.color; st.fc = q.color == 'custom' ? sc.hex : '';
    st.R = useBlur ? r3(R) : 0; st.Hb = r3(Hb);
  }

  function finishLook(sg, q, st) {
    sg.opacity = q.opacity;
    try { sg.blendingMode = q.mode == 'normal' ? BlendModes.NORMAL : BlendModes.MULTIPLY; } catch (e) {}
    st.O = q.opacity;
    st.m = q.mode;
  }

  // w 안의 원래 개체로 그림자를 새로 만든다. 새 실루엣이 된 다음에 있던 그림자를 지운다.
  function buildForm(doc, w, p, hex) {
    var prev = getState(w);
    var old = shadowGroup(w);
    var subj = [], i;
    for (i = 0; i < w.pageItems.length; i++) if (readTag(w.pageItems[i], TAG_PART) != 'sg') subj.push(w.pageItems[i]);
    if (!subj.length) throw new Error('그림자를 만들 개체가 없어요');
    var info = {};
    var sil = silhouette(doc, subj, p.holes, info);
    if (!sil) throw new Error('모양을 읽지 못했어요');
    var sg = null;
    try {
      var b = sil.geometricBounds;
      var H = Math.max(b[1] - b[3], 0.01);
      sg = w.groupItems.add();
      sg.name = NAME_SG;
      writeTag(sg, TAG_PART, 'sg');
      sg.move(w, ElementPlacement.PLACEATEND);
      sil.move(sg, ElementPlacement.PLACEATBEGINNING);
      sil.name = NAME_SHARP;
      writeTag(sil, TAG_PART, 'sharp');
      makeRef(sg, [(b[0] + b[2]) / 2, b[3]], H);
      var st = { k: 'form', id: prev && prev.id ? prev.id : newId(), sa: 0, sb: 1, H: r6(H) };
      var q = readP(p);
      q.hex = hex || (prev && prev.fc) || '';
      paintUpright(doc, sg, q, st);
      var sv = shear(q.angle, q.length);
      setShear(sg, st, sv.a, sv.b);
      finishLook(sg, q, st);
      st.a = q.angle; st.L = q.length; st.h = q.holes ? 1 : 0;
      if (info.image) st.img = 1;
      setState(w, st);
    } catch (e) {
      if (alive(sg)) { try { sg.remove(); } catch (e2) {} }
      else if (alive(sil)) { try { sil.remove(); } catch (e3) {} }
      throw e;
    }
    if (old) old.remove();
    return w;
  }

  function wrap(items, name) {
    var first0 = items[0];
    var g = first0.parent.groupItems.add();
    try {
      g.move(first0, ElementPlacement.PLACEBEFORE);
      for (var i = 0; i < items.length; i++) items[i].move(g, ElementPlacement.PLACEATEND);
    } catch (e) {
      // 옮긴 것을 제자리로 돌리고 빈 그룹을 지운다
      try { for (var k = g.pageItems.length - 1; k >= 0; k--) g.pageItems[k].move(g, ElementPlacement.PLACEAFTER); } catch (e2) {}
      try { g.remove(); } catch (e3) {}
      throw e;
    }
    g.name = name;
    return g;
  }

  // 그룹을 풀어 안의 개체를 제자리에 둔다. 형상 그림자 묶음이면 그림자는 지운다.
  function unwrap(w) {
    var sg = shadowGroup(w);
    if (sg) sg.remove();
    var kids = [], i;
    for (i = 0; i < w.pageItems.length; i++) kids.push(w.pageItems[i]);
    for (i = 0; i < kids.length; i++) kids[i].move(w, ElementPlacement.PLACEBEFORE);
    w.remove();
    return kids;
  }

  // 만들다 실패한 형상 묶음 되돌리기
  function undoWrap(w) {
    try { unwrap(w); } catch (e) {}
  }

  // 선택을 형상 그림자 대상으로 나눈다: 이미 있는 그림자 / 새 개체
  function formTargets(doc, split) {
    var items = selItems(doc), ws = [], subj = [], wk = {}, sk = {}, skipped = 0, i, k;
    for (i = 0; i < items.length; i++) {
      var it = items[i], w = shadowOf(it);
      if (w) {
        var kd = kindOf(w);
        if (kd == 'form') { addOnce(ws, wk, w); continue; }
        if (kd == 'plan') { skipped++; continue; }
        // 드롭 섀도 묶음 안쪽을 고르면 묶음째로 (안에 넣으면 그림자에도 드롭 섀도가 붙음)
        if (kd == 'drop' && !isWrapper(it)) { if (!blocked(w)) addOnce(subj, sk, w); else skipped++; continue; }
      }
      if (blocked(it)) { skipped++; continue; }
      if (split && it.typename == 'GroupItem' && !it.clipped && !w && it.pageItems.length > 1) {
        for (k = 0; k < it.pageItems.length; k++) {
          var c = it.pageItems[k];
          if (!blocked(c)) addOnce(subj, sk, c); else skipped++;
        }
      } else {
        addOnce(subj, sk, it);
      }
    }
    return { ws: ws, subj: subj, skipped: skipped };
  }

  function formMake(argStr) {
    return withDocCoords(function () {
      calCache = {};
      var a = parseArgs(argStr);
      var p = readP(a.p || {});
      var doc = getDoc();
      var t = formTargets(doc, a.split == 'group');
      if (!t.ws.length && !t.subj.length) {
        return fail(t.skipped ? '잠기거나 숨긴 개체라 건너뛰었어요' : '사람·나무를 선택해 주세요');
      }
      var made = 0, refit = 0, bad = 0, lastErr = '', out = [], img = 0, i;
      for (i = 0; i < t.subj.length; i++) {
        var w = null;
        try {
          w = wrap([t.subj[i]], NAME_FORM);
          buildForm(doc, w, p, a.hex);
          if (getState(w).img) img++;
          out.push(w);
          made++;
        } catch (e) {
          bad++;
          lastErr = errText(e);
          if (w) undoWrap(w);
        }
      }
      for (i = 0; i < t.ws.length; i++) {
        try {
          buildForm(doc, t.ws[i], p, a.hex);
          out.push(t.ws[i]);
          refit++;
        } catch (e3) {
          bad++;
          lastErr = errText(e3);
        }
      }
      cleanupGradients(doc);
      reselect(doc, out);
      if (!made && !refit) return fail(lastErr || '그림자를 만들지 못했어요');
      var msg = made ? '그림자 ' + made + '개를 넣었어요' : '';
      if (refit) msg += (msg ? ' · ' : '') + refit + '개를 다시 맞췄어요';
      if (img) msg += ' · 이미지는 윤곽을 따서 만들었어요';
      if (bad) msg += ' · ' + bad + '개는 못 했어요 (' + lastErr + ')';
      if (t.skipped) msg += ' · 잠긴 ' + t.skipped + '개 건너뜀';
      return done({ made: made, refit: refit, bad: bad, msg: msg, blur: blurInfo ? blurInfo.name : '' });
    });
  }

  function formSelected(doc) {
    var items = selItems(doc), ws = [], wk = {};
    for (var i = 0; i < items.length; i++) {
      var w = shadowOf(items[i]);
      if (w && kindOf(w) == 'form') addOnce(ws, wk, w);
    }
    return ws;
  }

  function formAllInDoc(doc) {
    var out = [], gis = doc.groupItems;
    for (var i = 0; i < gis.length; i++) {
      var g = gis[i];
      if (g.name != NAME_FORM) continue;
      if (kindOf(g) == 'form') out.push(g);
    }
    return out;
  }

  // 한 그림자 고치기. 바뀐 것만: 방향·길이 → 기울기만, 진하기·혼합 → 묶음 값만, 흐려짐·번짐·색 → 칠을 새로.
  // fin(놓았을 때)이면 흐림 반경이 길이에 맞게 많이 달라졌는지도 본다. 모양을 바꿀 때마다 바로 상태를 적는다.
  // 끄는 동안(fin 아님) 방향·길이만 바꿀 때는 번짐(흐림 효과)을 잠깐 숨긴다 — 흐림은 움직일 때마다 다시 그려져 무겁다.
  // 놓으면(fin) 다시 보인다. 상태는 마지막에 한 번만 적는다.
  function softVisible(sg, on) {
    var s = partOf(sg, 'soft');
    if (s && s.hidden === on) { try { s.hidden = !on; } catch (e) {} }
  }

  function updateForm(doc, w, q, fin) {
    var sg = shadowGroup(w);
    if (!sg) return false;
    var st = getState(w);
    if (!st || !st.sb) return false;
    var dirty = false;
    var sv = shear(q.angle, q.length);
    var repaint = q.fade !== st.F || q.soften !== st.S || q.color !== st.c || (q.color == 'custom' && q.hex && q.hex != st.fc);
    if (!repaint && fin && st.S > 0) {
      var R = blurRadius(st.S, q.length, st.Hb || st.H || 0);
      if (Math.abs(R - (st.R || 0)) > Math.max(0.6, 0.35 * R)) repaint = true;   // 흐림 반경이 많이 달라졌을 때만 다시 칠함 (무거움)
    }
    tMark('읽기');
    if (!repaint) { softVisible(sg, !!fin); tMark('번짐 보임'); }
    if (!repaint && (Math.abs(sv.a - st.sa) > 1e-7 || Math.abs(sv.b - st.sb) > 1e-7)) {
      setShear(sg, st, sv.a, sv.b);
      st.a = q.angle; st.L = q.length;
      dirty = true;
      tMark('기울이기');
    }
    if (q.opacity !== st.O || q.mode !== st.m) {
      finishLook(sg, q, st);
      dirty = true;
      tMark('진하기');
    }
    if (repaint) {
      setShear(sg, st, 0, 1);
      setState(w, st);   // 세운 상태를 먼저 적어 둔다 (칠하다 멈춰도 다음에 맞게)
      tMark('세우기');
      paintUpright(doc, sg, q, st);
      tMark('다시 칠');
      setShear(sg, st, sv.a, sv.b);
      st.a = q.angle; st.L = q.length;
      dirty = true;
      tMark('기울이기');
    }
    if (dirty) { setState(w, st); tMark('기록'); }
    return true;
  }

  // 되돌리기 기준: 패널이 선택을 읽을 때마다 새 회차(sess). 그 회차에 처음 고칠 때 값을 그림자마다 남긴다.
  function rememberPrev(w, st, sess) {
    if (!sess) return;
    var cur = readTag(w, TAG_PREV);
    if (cur && cur.indexOf(sess + '|') === 0) return;
    writeTag(w, TAG_PREV, sess + '|' + packKV({ a: st.a, L: st.L, O: st.O, S: st.S, F: st.F, c: st.c, m: st.m, fc: st.fc || '' }));
  }

  function prevOf(w, sess) {
    var v = readTag(w, TAG_PREV);
    if (!v || !sess || v.indexOf(sess + '|') !== 0) return null;
    return unpackKV(v.substring(sess.length + 1));
  }

  function formLive(argStr) {
    tStart();
    return withDocCoords(function () {
      calCache = {};
      var a = parseArgs(argStr);
      var p = a.p || {};
      var only = a.only && a.only.length ? a.only : FORM_KEYS;
      var doc = getDoc();
      var ws = formSelected(doc), n = 0;
      tMark('선택' + ws.length + '개');
      for (var i = 0; i < ws.length; i++) {
        var w = ws[i], st = getState(w);
        if (!st) continue;
        if (a.what == 'restore') {
          var pv = prevOf(w, a.sess);
          if (!pv) continue;
          var q0 = readP({ angle: pv.a, length: pv.L, opacity: pv.O, soften: pv.S, fade: pv.F, color: pv.c, mode: pv.m, holes: st.h == 1 });
          q0.hex = pv.fc || '';
          if (updateForm(doc, w, q0, true)) n++;
          removeTag(w, TAG_PREV);
          continue;
        }
        rememberPrev(w, st, a.sess);
        if (updateForm(doc, w, paramsFor(st, p, only, a.hex), !!a.last)) n++;
      }
      // 그라디언트 정리(문서의 모든 패스를 훑음)는 슬라이더마다 하지 않는다 — 다시 맞추기·같은 해로·없애기 때만
      return done({ n: n });
    });
  }

  // 문서의 모든 형상 그림자를 같은 해(방향·길이)로. 다른 값은 그대로.
  function formAll(argStr) {
    return withDocCoords(function () {
      calCache = {};
      var a = parseArgs(argStr);
      var p = a.p || {};
      var doc = getDoc();
      var keep = selected(doc);
      var ws = formAllInDoc(doc), n = 0, bad = 0;
      for (var i = 0; i < ws.length; i++) {
        try {
          var st = getState(ws[i]);
          if (updateForm(doc, ws[i], paramsFor(st, p, ['angle', 'length'], ''), true)) n++;
        } catch (e) { bad++; }
      }
      cleanupGradients(doc);
      reselect(doc, keep);
      if (!ws.length) return fail('문서에 형상 그림자가 없어요');
      return done({ n: n, msg: '그림자 ' + n + '개를 같은 해로 맞췄어요' + (bad ? ' (' + bad + '개 못 함)' : '') });
    });
  }

  /* ---------- 드롭 섀도 (일러스트 효과) ---------- */
  function fx3(v) {
    var s = String(r3(v));
    return s.indexOf('e') >= 0 ? '0' : s;
  }

  function colorCode(doc, key, hex) {
    if (key != 'navy' && key != 'custom') return '';
    var sc = shadowColor(doc, key, hex), c = sc.col;
    if (c.typename == 'CMYKColor') return '1 ' + fx3(c.cyan / 100) + ' ' + fx3(c.magenta / 100) + ' ' + fx3(c.yellow / 100) + ' ' + fx3(c.black / 100);
    return '5 ' + fx3(sc.rgb[0] / 255) + ' ' + fx3(sc.rgb[1] / 255) + ' ' + fx3(sc.rgb[2] / 255);
  }

  function dropXML(e, mode, code) {
    var d = 'R horz ' + fx3(e.h) + ' R vert ' + fx3(e.v) + ' R opac ' + fx3(clamp(e.o, 0, 1)) +
            ' R blur ' + fx3(Math.max(0, e.b)) + ' R dark 100 I blnd ' + (mode == 'normal' ? 0 : 1) + ' I csrc 0 B pair 1 ';
    var x = '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + d + '"';
    if (code) x += '><Entry name="sclr" valueType="F"><Fill color="' + code + '"/></Entry></Dict>';
    else x += '/>';
    return x + '</LiveEffect>';
  }

  // 효과를 넣는다. 색을 넣은 형식이 안 먹으면 검정으로.
  function applyDrop(doc, w, a) {
    var code = colorCode(doc, a.color, a.hex), colorOk = true;
    for (var i = 0; i < a.fx.length; i++) {
      if (code && colorOk) {
        try {
          w.applyEffect(dropXML(a.fx[i], a.mode, code));
          continue;
        } catch (e) {
          colorOk = false;
        }
      }
      w.applyEffect(dropXML(a.fx[i], a.mode, ''));
    }
    return colorOk || !code;
  }

  function dropState(a, id) {
    var p = a.p || {};
    var c = a.color == 'navy' || a.color == 'custom' ? a.color : 'black';
    return {
      k: 'drop', id: id || newId(), dir: num(p.dir, -45), dist: num(p.distance, 6), size: num(p.size, 18),
      O: num(p.opacity, 28), fall: num(p.falloff, 0), c: c, fc: c == 'custom' ? (a.hex || '') : '',
      m: a.mode == 'normal' ? 'normal' : 'multiply', n: a.fx.length
    };
  }

  function dropTargets(doc) {
    var items = selItems(doc), ws = [], plain = [], wk = {}, pk = {}, skipped = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], w = shadowOf(it), kd = w ? kindOf(w) : '';
      if (kd == 'drop') { addOnce(ws, wk, w); continue; }
      if (kd == 'form') { if (!blocked(w)) addOnce(plain, pk, w); else skipped++; continue; }   // 형상 그림자 묶음은 통째로
      if (kd == 'plan') { skipped++; continue; }
      if (blocked(it)) { skipped++; continue; }
      addOnce(plain, pk, it);
    }
    return { ws: ws, plain: plain, skipped: skipped };
  }

  function parentKey(it) {
    var p = it.parent;
    if (p.typename == 'Layer') {
      var z = '';
      try { z = p.absoluteZOrderPosition; } catch (e) {}
      return 'L:' + p.name + ':' + z;
    }
    return keyOf(p);
  }

  function sameParent(items) {
    var k0 = parentKey(items[0]);
    for (var i = 1; i < items.length; i++) if (parentKey(items[i]) != k0) return false;
    return true;
  }

  function dropMake(argStr) {
    return withDocCoords(function () {
      var a = parseArgs(argStr);
      if (!a.fx || !a.fx.length) return fail('효과 값이 없어요');
      var doc = getDoc();
      var t = dropTargets(doc);
      if (a.live) t.plain = [];      // 슬라이더로 고칠 때는 이미 넣은 것만 (새로 고른 개체를 몰래 감싸지 않게)
      if (!t.ws.length && !t.plain.length) return fail(t.skipped ? '잠기거나 숨긴 개체라 건너뛰었어요' : (a.live ? '드롭 섀도를 골라 주세요' : '개체를 선택해 주세요'));
      var out = [], colorOk = true, i;
      // 이미 넣은 것: 풀고 다시 감싸 효과를 새로 (효과만 지우는 방법이 없음). id 는 그대로 — 패널이 같은 선택으로 본다.
      for (i = 0; i < t.ws.length; i++) {
        var old = getState(t.ws[i]);
        var kids = unwrap(t.ws[i]);
        var nw = wrap(kids, NAME_DROP);
        setState(nw, dropState(a, old && old.id));
        if (!applyDrop(doc, nw, a)) colorOk = false;
        out.push(nw);
      }
      if (t.plain.length) {
        var groups = [];
        if (a.unit == 'one' && t.plain.length > 1 && sameParent(t.plain)) groups.push(t.plain);
        else for (i = 0; i < t.plain.length; i++) groups.push([t.plain[i]]);
        for (i = 0; i < groups.length; i++) {
          var w = wrap(groups[i], NAME_DROP);
          setState(w, dropState(a));
          if (!applyDrop(doc, w, a)) colorOk = false;
          out.push(w);
        }
      }
      reselect(doc, out);
      var msg = a.live ? '' : '드롭 섀도 ' + out.length + '개' + (a.fx.length > 1 ? ' (' + a.fx.length + '겹)' : '');
      if (!colorOk) msg += (msg ? ' · ' : '') + '색은 검정으로 들어갔어요';
      if (!a.live) {
        // 효과는 문서 래스터 효과 해상도로 그려진다 — 72ppi 면 번짐 0 이어도 가장자리가 흐리다
        var rez = 0;
        try { rez = doc.rasterEffectSettings.resolution; } catch (eR) { rez = 0; }
        if (rez > 0 && rez < 150) msg += (msg ? ' · ' : '') + '래스터 효과 해상도가 ' + Math.round(rez) + 'ppi 라 흐려 보여요 (효과 › 문서 래스터 효과 설정)';
      }
      return done({ n: out.length, colorOk: colorOk, msg: msg });
    });
  }

  /* ---------- 평면 그림자 (벡터) ---------- */
  function flatten(p, tol) {
    var pts = p.pathPoints, n = pts.length, out = [], i;
    if (!n) return out;
    var closed = p.closed;
    var segs = closed ? n : n - 1;
    var a0 = pts[0].anchor;
    out.push(a0[0], a0[1]);
    for (i = 0; i < segs; i++) {
      var A = pts[i], B = pts[(i + 1) % n];
      var p0 = A.anchor, c1 = A.rightDirection, c2 = B.leftDirection, p3 = B.anchor;
      var dev = Math.max(lineDist(c1, p0, p3), lineDist(c2, p0, p3));
      var steps = dev < 1e-3 ? 1 : clamp(Math.ceil(Math.sqrt(0.75 * dev / tol)), 1, 48);
      for (var s = 1; s <= steps; s++) {
        var t = s / steps, u = 1 - t;
        var x = u * u * u * p0[0] + 3 * u * u * t * c1[0] + 3 * u * t * t * c2[0] + t * t * t * p3[0];
        var y = u * u * u * p0[1] + 3 * u * u * t * c1[1] + 3 * u * t * t * c2[1] + t * t * t * p3[1];
        out.push(Math.round(x * 100) / 100, Math.round(y * 100) / 100);
      }
    }
    if (closed && out.length > 2) { out.pop(); out.pop(); }
    return out;
  }

  function lineDist(c, p, q) {
    var dx = q[0] - p[0], dy = q[1] - p[1], L = Math.sqrt(dx * dx + dy * dy);
    if (L < 1e-9) return Math.sqrt((c[0] - p[0]) * (c[0] - p[0]) + (c[1] - p[1]) * (c[1] - p[1]));
    return Math.abs((c[0] - p[0]) * dy - (c[1] - p[1]) * dx) / L;
  }

  function ringsOf(it) {
    var ps = paths(it), out = [];
    for (var i = 0; i < ps.length; i++) {
      var r = flatten(ps[i], 0.15);
      if (r.length >= 6) out.push(r);
    }
    return out;
  }

  // 칠 진하기 0~1 (색 농도 반영용): 칠이 있으면 칠, 없으면 획
  function darkness(col) {
    var rgb = null;
    try { rgb = toRGB(col); } catch (e) {}
    if (!rgb) return 1;
    return clamp(1 - (0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]) / 255, 0, 1);
  }

  function densityOf(it, budget) {
    var t = it.typename, best = -1, i;
    if (budget.n-- <= 0) return -1;
    var op = 1;
    try { op = it.opacity / 100; } catch (e0) {}
    if (t == 'GroupItem') {
      for (i = 0; i < it.pageItems.length && budget.n > 0; i++) best = Math.max(best, densityOf(it.pageItems[i], budget));
      return best < 0 ? -1 : best * op;
    }
    var p = t == 'CompoundPathItem' ? (it.pathItems.length ? it.pathItems[0] : null) : (t == 'PathItem' ? it : null);
    if (!p) return 1 * op;
    try {
      if (p.filled) return darkness(p.fillColor) * op;
      if (p.stroked) return darkness(p.strokeColor) * op;
    } catch (e1) {}
    return -1;
  }

  /* ---------- 평면 그림자 모양 바로 읽기 (메뉴 명령 없이) ----------
   * 칠·획만 있는 패스·복합 패스·그룹·클리핑 그룹은 점을 바로 읽어 패널로 넘긴다 (획 두께·자르기는 패널이 Clipper 로).
   * 글자·기호·이미지·플러그인 개체가 들면 null → 예전처럼 복사해 확장(silhouette).
   * 도면 개체 수백 개를 하나씩 확장하면 메뉴 명령이 수백 번 돌아 일러스트가 멈췄다 (0.1.3, 개체 181개).
   * 모양 패널의 효과·브러쉬는 스크립트로 못 읽어서 그냥 칠·획으로 본다. */
  var SIMPLE_MAX = 20000;   // 점이 이보다 많으면 바로 읽지 않음 (스크립트로 점 읽기가 더 느려짐)

  function capOf(p) {
    try {
      if (p.strokeCap == StrokeCap.ROUNDENDCAP) return 'r';
      if (p.strokeCap == StrokeCap.PROJECTINGENDCAP) return 'p';
    } catch (e) {}
    return 'b';
  }

  function joinOf(p) {
    try {
      if (p.strokeJoin == StrokeJoin.ROUNDENDJOIN) return 'r';
      if (p.strokeJoin == StrokeJoin.BEVELENDJOIN) return 'b';
    } catch (e) {}
    return 'm';
  }

  function dashOf(p) {
    try {
      var d = p.strokeDashes, out = [];
      if (!d || !d.length) return null;
      for (var i = 0; i < d.length; i++) out.push(Number(d[i]));
      return out;
    } catch (e) { return null; }
  }

  function hasColor(c) {
    try { return !!c && c.typename != 'NoColor'; } catch (e) { return true; }
  }

  // 패스 하나(또는 복합 패스) → 칠·획 조각들
  function pathGeo(it, out, budget) {
    var ps = paths(it);
    if (!ps.length) return true;
    var p0 = ps[0], filled = false, stroked = false;
    try { filled = p0.filled && hasColor(p0.fillColor); } catch (e0) {}
    try { stroked = p0.stroked && p0.strokeWidth > 0 && hasColor(p0.strokeColor); } catch (e1) {}
    if (!filled && !stroked) return true;
    var rings = [], i;
    for (i = 0; i < ps.length; i++) {
      var n = 0;
      try { n = ps[i].pathPoints.length; } catch (e2) {}
      budget.n -= n;
      if (budget.n < 0) return false;
      var r = flatten(ps[i], 0.15);
      if (r.length >= 4) rings.push({ r: r, c: !!ps[i].closed });
    }
    if (!rings.length) return true;
    if (filled) {
      var fr = [];
      for (i = 0; i < rings.length; i++) if (rings[i].r.length >= 6) fr.push(rings[i].r);
      var eo = false;
      try { eo = !!p0.evenodd; } catch (e3) {}
      if (fr.length) out.push({ k: 'f', r: fr, eo: eo ? 1 : 0 });
    }
    if (stroked) {
      var ml = 4;
      try { ml = p0.strokeMiterLimit; } catch (e4) {}
      for (i = 0; i < rings.length; i++) {
        out.push({ k: 's', r: rings[i].r, c: rings[i].c ? 1 : 0, w: r3(p0.strokeWidth), cap: capOf(p0), j: joinOf(p0), ml: ml, d: dashOf(p0) });
      }
    }
    return true;
  }

  function isClipPath(c) {
    try {
      if (c.typename == 'PathItem') return c.clipping;
      if (c.typename == 'CompoundPathItem') return c.pathItems.length > 0 && c.pathItems[0].clipping;
    } catch (e) {}
    return false;
  }

  // 개체 → 조각 목록. 바로 못 읽는 것이 있으면 false.
  function simpleGeo(it, out, budget) {
    var t = it.typename, i;
    try { if (it.hidden) return true; } catch (e0) {}
    if (t == 'PathItem' || t == 'CompoundPathItem') {
      if (isClipPath(it)) return true;
      return pathGeo(it, out, budget);
    }
    if (t != 'GroupItem') return false;
    var st = getState(it);
    if (st && st.k == 'plan') return true;
    if (readTag(it, TAG_PART) == 'sg') return true;
    var kids = [];
    for (i = 0; i < it.pageItems.length; i++) kids.push(it.pageItems[i]);
    var clipped = false;
    try { clipped = it.clipped; } catch (e1) {}
    if (!clipped) {
      for (i = 0; i < kids.length; i++) if (!simpleGeo(kids[i], out, budget)) return false;
      return true;
    }
    var mask = null, inner = [];
    for (i = 0; i < kids.length; i++) {
      if (!mask && isClipPath(kids[i])) { mask = kids[i]; continue; }
      if (!simpleGeo(kids[i], inner, budget)) return false;
    }
    if (!mask) { for (i = 0; i < inner.length; i++) out.push(inner[i]); return true; }
    var mp = paths(mask), mr = [];
    for (i = 0; i < mp.length; i++) {
      budget.n -= mp[i].pathPoints.length;
      var r = flatten(mp[i], 0.15);
      if (r.length >= 6) mr.push(r);
    }
    if (budget.n < 0) return false;
    if (inner.length && mr.length) out.push({ k: 'c', m: mr, g: inner });
    return true;
  }

  // 그림자 재료 개체 하나 → 조각들 또는 null(확장해야 함)
  function readGeo(it) {
    var srcs = sourcesOf(it), out = [], budget = { n: SIMPLE_MAX };
    for (var i = 0; i < srcs.length; i++) if (!simpleGeo(srcs[i], out, budget)) return null;
    return out;
  }

  function uuidOf(it) {
    try { return String(it.uuid); } catch (e) { return ''; }
  }

  function planGroups(doc) {
    var out = [], gis = doc.groupItems;
    for (var i = 0; i < gis.length; i++) {
      var g = gis[i];
      if (g.name != NAME_PLAN) continue;
      var st = getState(g);
      if (st && st.k == 'plan') {
        out.push(g);
        var u = uuidOf(g);
        if (u) planIndex[st.id] = u;
      }
    }
    return out;
  }

  // 평면 그림자 그룹 찾기는 문서의 모든 그룹을 훑어야 해서 무겁다 → id → uuid 를 기억해 두고 먼저 그것으로
  var planIndex = {};

  function planById(doc, id) {
    var u = planIndex[id];
    if (u === '-') return null;   // 방금 새로 정한 id (아직 그룹 없음) — 문서를 훑지 않는다
    if (u) {
      try {
        var it = doc.getPageItemFromUuid(u);
        if (it && it.typename == 'GroupItem' && it.name == NAME_PLAN) {
          var st0 = getState(it);
          if (st0 && st0.k == 'plan' && st0.id == id) return it;
        }
      } catch (e) {}
      delete planIndex[id];
    }
    var gs = planGroups(doc);
    for (var i = 0; i < gs.length; i++) if (getState(gs[i]).id == id) return gs[i];
    return null;
  }

  // 그 그림자를 만든 개체들: uuid 로 찾고, 못 찾으면 문서를 훑어 표시로
  function planSubjects(doc, st) {
    var out = [], i;
    if (st.u) {
      var us = String(st.u).split(',');
      for (i = 0; i < us.length; i++) {
        try {
          var it = doc.getPageItemFromUuid(us[i]);
          if (it && readTag(it, TAG_SRC) == st.id) out.push(it);
        } catch (e) {}
      }
      if (out.length == us.length) return out;
    }
    out = [];
    var all = doc.pageItems;
    for (i = 0; i < all.length; i++) {
      try { if (readTag(all[i], TAG_SRC) == st.id) out.push(all[i]); } catch (e2) {}
    }
    return out;
  }

  // 선택에서 평면 그림자 대상 찾기: 이미 있는 그림자(그 그룹·그 개체)의 id 들과, 아직 그림자가 없는 개체들
  function planTargets(doc) {
    var items = selItems(doc), ids = [], known = {}, plain = [], pk = {}, skipped = 0, i;
    for (i = 0; i < items.length; i++) {
      var it = items[i], w = shadowOf(it);
      if (w && kindOf(w) == 'plan') { var gid = getState(w).id; if (!inArr(ids, gid)) ids.push(gid); continue; }
      var src = readTag(it, TAG_SRC);
      if (src && known[src] === undefined) known[src] = !!planById(doc, src);
      if (src && known[src]) { if (!inArr(ids, src)) ids.push(src); continue; }
      if (blocked(it)) { skipped++; continue; }
      addOnce(plain, pk, it);
    }
    return { ids: ids, plain: plain, skipped: skipped };
  }

  // 그림자 모양을 읽는다. 이미 있는 평면 그림자와 새 개체를 같이 고르면 첫 그림자에 합친다(따로 두 겹이 생기지 않게).
  // live(슬라이더로 고칠 때)면 이미 있는 그림자의 개체만 — 새로 고른 개체는 넣지 않는다.
  function planGather(argStr) {
    return withDocCoords(function () {
      var a = parseArgs(argStr);
      var doc = getDoc();
      var keep = selected(doc);
      var t = planTargets(doc), subj = [], sk = {}, i, k;
      var id = t.ids.length ? t.ids[0] : null, st = null;
      if (id) {
        var g0 = planById(doc, id);
        st = g0 ? getState(g0) : null;
      }
      if (a.live) {
        if (!st) return fail('평면 그림자를 골라 주세요');
        t.ids = [id];
        t.plain = [];
      }
      for (i = 0; i < t.ids.length; i++) {
        var gi = planById(doc, t.ids[i]);
        if (!gi) continue;
        var ss = planSubjects(doc, getState(gi));
        for (k = 0; k < ss.length; k++) addOnce(subj, sk, ss[k]);
      }
      for (i = 0; i < t.plain.length; i++) addOnce(subj, sk, t.plain[i]);
      if (!id) { id = newId(); planIndex[id] = '-'; }
      if (!subj.length) return fail(t.skipped ? '잠기거나 숨긴 개체라 건너뛰었어요' : '건물·벽 같은 개체를 선택해 주세요');
      var holes = !!a.holes;
      var res = [], bad = 0, lastErr = '', uu = [], slow = [], fast = 0;
      tStart();
      // 1) 칠·획만 있는 개체는 점을 바로 읽는다
      for (i = 0; i < subj.length; i++) {
        var geo = null;
        try { geo = readGeo(subj[i]); } catch (eG) { geo = null; }
        uu.push(uuidOf(subj[i]));
        if (!geo) { slow.push(subj[i]); continue; }
        if (!geo.length) { bad++; continue; }
        var d = densityOf(subj[i], { n: 40 });
        res.push({ d: d < 0 ? 1 : r3(d), g: geo });
        fast++;
      }
      tMark('바로 읽기 ' + fast);
      // 2) 나머지(글자·기호·이미지 …)는 복사해 확장 — 색 농도를 안 쓰면 한 덩어리로 한 번에
      var batches = [];
      if (slow.length && !a.density) batches.push(slow);
      else for (i = 0; i < slow.length; i++) batches.push([slow[i]]);
      for (i = 0; i < batches.length; i++) {
        try {
          var info = {};
          var sil = silhouette(doc, batches[i], holes, info);
          if (!sil) { bad += batches[i].length; continue; }
          var rings = [];
          try { rings = ringsOf(sil); } finally { try { sil.remove(); } catch (eR) {} }
          if (!rings.length) { bad += batches[i].length; continue; }
          var d2 = batches[i].length == 1 ? densityOf(batches[i][0], { n: 40 }) : 1;
          res.push({ d: d2 < 0 ? 1 : r3(d2), rings: rings });
        } catch (e) {
          bad += batches[i].length;
          lastErr = errText(e);
        }
      }
      if (slow.length) {
        tMark('확장 ' + slow.length + '개 ' + batches.length + '번');
        reselect(doc, keep);   // 확장하느라 바꾼 선택만 되돌림 (바로 읽기는 선택을 안 건드림)
      }
      if (!res.length) return fail(lastErr || '모양을 읽지 못했어요');
      return done({
        id: id, existing: !!st, p: st ? planParams(st) : null,
        subj: res, bad: bad, n: subj.length, u: uu.join(','), merge: t.ids.slice(1)
      });
    });
  }

  function planParams(st) {
    return { dir: st.dir, distance: st.dist, size: st.size, opacity: st.O, falloff: st.fall, color: st.c, mode: st.m, holes: st.h == 1, density: st.dn == 1 };
  }

  // 그 개체들 가운데 가장 아래(쌓인 순서) 것
  // absoluteZOrderPosition 은 부를 때마다 문서 전체를 훑는다 → 그릇(부모)마다 그 안 순서로 가장 아래를 고르고,
  // 그릇이 여럿일 때만 그 대표들끼리 문서 순서로 견준다 (개체 수백 개에서 수백 번 훑던 것)
  function bottomOf(items) {
    var groups = [], i, k;
    for (i = 0; i < items.length; i++) {
      var par = null;
      try { par = items[i].parent; } catch (e0) {}
      for (k = 0; k < groups.length; k++) if (groups[k].p === par) break;
      if (k == groups.length) groups.push({ p: par, best: null, z: null });
      var z = null;
      try { z = items[i].zOrderPosition; } catch (e1) { z = null; }
      var gk = groups[k];
      if (gk.best === null || (z !== null && z !== undefined && (gk.z === null || z < gk.z))) { gk.best = items[i]; gk.z = z; }
    }
    if (groups.length == 1) return groups[0].best || items[items.length - 1];
    var best = items[items.length - 1], bz = null;
    for (k = 0; k < groups.length; k++) {
      var az = null;
      try { az = groups[k].best.absoluteZOrderPosition; } catch (e2) { az = null; }
      if (az === null || az === undefined) continue;
      if (bz === null || az < bz) { bz = az; best = groups[k].best; }
    }
    return best;
  }

  // 개체가 든 맨 위 레이어
  function topLayerOf(it) {
    var p = it;
    try {
      while (p && !(p.typename == 'Layer' && p.parent.typename == 'Document')) p = p.parent;
    } catch (e) { p = null; }
    return p;
  }

  // 그림자 레이어: 없으면 만들고, 그림자를 받을 개체가 든 레이어 바로 아래로 (그래야 벽이 그림자를 덮음)
  function shadowLayer(doc, near) {
    var top = topLayerOf(near), lay = null;
    try { lay = doc.layers.getByName(NAME_LAYER); } catch (e) { lay = null; }
    if (!lay) {
      lay = doc.layers.add();
      lay.name = NAME_LAYER;
    }
    if (top && top.name != NAME_LAYER) {
      try { lay.move(top, ElementPlacement.PLACEAFTER); } catch (e2) {}
    }
    return lay;
  }

  // 잠기거나 숨긴 레이어에도 넣을 수 있게 잠깐 풀었다가 되돌린다
  function withOpenLayer(lay, fn) {
    var lk = false, vis = true;
    try { lk = lay.locked; vis = lay.visible; lay.locked = false; lay.visible = true; } catch (e) {}
    try { return fn(); } finally {
      try { lay.visible = vis; lay.locked = lk; } catch (e2) {}
    }
  }

  function planDraw(argStr) {
    return withDocCoords(function () {
      var a = parseArgs(argStr);
      var doc = getDoc();
      var keep = selected(doc);
      var g = planById(doc, a.id), i, k, j;
      // 개체: 읽을 때 받은 uuid 로(합친 것까지), 못 찾으면 그 그림자의 개체 → 지금 선택
      var subj = [], sk = {};
      var us = String(a.u || '').split(',');
      for (i = 0; i < us.length; i++) {
        if (!us[i]) continue;
        try { var it = doc.getPageItemFromUuid(us[i]); if (it) addOnce(subj, sk, it); } catch (e) {}
      }
      if (!subj.length && g) subj = planSubjects(doc, getState(g));
      if (!subj.length) {
        for (i = 0; i < keep.length; i++) {
          var kw = shadowOf(keep[i]);
          if (!(kw && kindOf(kw) == 'plan')) addOnce(subj, sk, keep[i]);
        }
      }
      if (!subj.length) return fail('그림자를 놓을 개체를 찾지 못했어요');
      tStart();
      // 고른 개체가 많으면 고칠 때마다 선택 표시를 다시 계산해서 느리다 → 그리는 동안은 선택을 비운다
      try { doc.selection = null; } catch (eS) {}
      tMark('준비 ' + subj.length + '개');
      if (g) {
        try { if (g.clipped) g.clipped = false; } catch (eC) {}
        for (i = g.pageItems.length - 1; i >= 0; i--) g.pageItems[i].remove();
      } else {
        var bottom = bottomOf(subj);
        if (a.layer) {
          // 그림자 레이어에 (레이어 투명도·숨기기로 그림자만 한 번에 다룸)
          var lay = shadowLayer(doc, bottom);
          g = withOpenLayer(lay, function () { return lay.groupItems.add(); });
        } else {
          g = bottom.parent.groupItems.add();
          g.move(bottom, ElementPlacement.PLACEAFTER);
        }
        g.name = NAME_PLAN;
      }
      var gl = g.layer, glk = false, gvis = true;
      try { glk = gl.locked; gvis = gl.visible; gl.locked = false; gl.visible = true; } catch (eL) {}
      tMark('자리');
      var p = a.p || {};
      var c = a.color == 'navy' || a.color == 'custom' ? a.color : 'black';
      var sc = shadowColor(doc, c, a.hex);
      setState(g, {
        k: 'plan', id: a.id, dir: num(p.dir, -45), dist: num(p.distance, 40), size: num(p.size, 4), O: num(p.opacity, 45),
        fall: num(p.falloff, 50), c: c, fc: c == 'custom' ? sc.hex : '', m: a.mode == 'normal' ? 'normal' : 'multiply',
        h: p.holes ? 1 : 0, dn: p.density ? 1 : 0, u: ''
      });
      planIndex[a.id] = uuidOf(g) || '';
      // 흐림은 겹마다가 아니라 묶음 전체에 한 번 (겹마다 걸면 큰 래스터를 겹 수만큼 그려서 멈췄다)
      var blurR = num(a.blur, 0), host = g;
      if (blurR >= 0.3) { host = g.groupItems.add(); host.name = '겹'; }
      var nLayers = 0, nRings = 0;
      for (k = 0; k < a.classes.length; k++) {
        var layers = a.classes[k].layers;
        for (j = 0; j < layers.length; j++) {
          var L = layers[j];
          if (!L.rings.length || L.alpha <= 0.002) continue;
          var cp = host.compoundPathItems.add();
          for (i = 0; i < L.rings.length; i++) {
            var r = L.rings[i], pts = [];
            for (var q = 0; q + 1 < r.length; q += 2) pts.push([r[q], r[q + 1]]);
            if (pts.length < 3) continue;
            var pth = cp.pathItems.add();
            pth.setEntirePath(pts);
            pth.closed = true;
            nRings++;
          }
          if (!cp.pathItems.length) { cp.remove(); continue; }
          paintSolid(cp, sc.col);
          cp.opacity = clamp(L.alpha * 100, 0, 100);
          nLayers++;
        }
      }
      tMark(nLayers + '겹 · 조각 ' + nRings);
      if (host !== g) {
        if (nLayers) { applyBlur(host, blurR); tMark('흐림 ' + blurR); }
        else host.remove();
      }
      // 벽 앞(빛 쪽)으로 번진 흐림을 자르는 클리핑 마스크 (패널이 계산한 모양)
      if (nLayers && a.clip && a.clip.length) {
        try {
          var mk = g.compoundPathItems.add();
          for (i = 0; i < a.clip.length; i++) {
            var cr = a.clip[i], cps = [];
            for (var cq = 0; cq + 1 < cr.length; cq += 2) cps.push([cr[cq], cr[cq + 1]]);
            if (cps.length < 3) continue;
            var cpth = mk.pathItems.add();
            cpth.setEntirePath(cps);
            cpth.closed = true;
          }
          if (mk.pathItems.length) {
            mk.move(g, ElementPlacement.PLACEATBEGINNING);
            g.clipped = true;
          } else mk.remove();
        } catch (eK) { try { g.clipped = false; } catch (eK2) {} }
        tMark('자르기');
      }
      try { gl.visible = gvis; gl.locked = glk; } catch (eL2) {}
      try { g.blendingMode = a.mode == 'normal' ? BlendModes.NORMAL : BlendModes.MULTIPLY; } catch (e2) {}
      var uu = [];
      for (i = 0; i < subj.length; i++) {
        try { writeTag(subj[i], TAG_SRC, a.id); } catch (e3) {}
        uu.push(uuidOf(subj[i]));
      }
      var st = getState(g);
      st.u = uu.join(',');
      setState(g, st);
      tMark('표시');
      // 합친 다른 평면 그림자는 지운다
      if (a.merge) {
        for (i = 0; i < a.merge.length; i++) {
          if (a.merge[i] == a.id) continue;
          var mg = planById(doc, a.merge[i]);
          if (mg) { try { mg.remove(); } catch (e4) {} }
        }
      }
      if (!a.live) reselect(doc, keep.length ? keep : subj);
      else reselect(doc, keep);
      return done({ layers: nLayers, msg: a.live ? '' : '평면 그림자 ' + nLayers + '겹' });
    });
  }

  /* ---------- 없애기 ---------- */
  function remove(argStr) {
    return withDocCoords(function () {
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = selItems(doc), out = [], n = 0, i, want = a.kind || 'any';
      var planIds = {}, ws = [], wk = {};
      for (i = 0; i < items.length; i++) {
        var w = shadowOf(items[i]);
        if (w) {
          var kd = kindOf(w);
          if (want != 'any' && kd != want && !(want == 'drop' && kd == 'plan')) continue;
          if (kd == 'plan') { planIds[getState(w).id] = 1; continue; }
          addOnce(ws, wk, w);
          continue;
        }
        var src = readTag(items[i], TAG_SRC);
        if (src && (want == 'any' || want == 'drop' || want == 'plan')) planIds[src] = 1;
      }
      for (i = 0; i < ws.length; i++) {
        var kids = unwrap(ws[i]);
        for (var k = 0; k < kids.length; k++) out.push(kids[k]);
        n++;
      }
      for (var id in planIds) {
        if (!planIds.hasOwnProperty(id)) continue;
        var g = planById(doc, id);
        var subj = g ? planSubjects(doc, getState(g)) : [];
        for (i = 0; i < subj.length; i++) { removeTag(subj[i], TAG_SRC); out.push(subj[i]); }
        if (g) { g.remove(); n++; }
      }
      cleanupGradients(doc);
      reselect(doc, out);
      if (!n) return fail('선택에 그림자가 없어요');
      return done({ n: n, msg: '그림자 ' + n + '개를 없앴어요' });
    });
  }

  /* ---------- 선택 상태 (패널이 1초마다 묻는다) ---------- */
  function status() {
    try {
      if (!app.documents.length) return done({ doc: false, n: 0 });
      var doc = app.activeDocument, sel = doc.selection;
      var r = { doc: true, n: 0, form: 0, drop: 0, plan: 0, plain: 0, first: {}, cm: isCMYK(doc), name: '' };
      try { r.name = doc.name; } catch (e0) {}
      if (!sel) return done(r);
      if (sel.typename == 'TextRange') { r.text = true; return done(r); }
      r.n = sel.length;
      var seen = {}, lim = Math.min(sel.length, 80), plans = null;
      for (var i = 0; i < lim; i++) {
        var it = sel[i], w = shadowOf(it);
        if (w) {
          var st = getState(w), kd = st ? st.k : '';
          var key = kd == 'plan' ? 'plan:' + st.id : keyOf(w);
          if (seen[key]) continue;
          seen[key] = 1;
          if (kd == 'form' || kd == 'drop' || kd == 'plan') r[kd]++;
          if (kd && !r.first[kd]) r.first[kd] = st;
          continue;
        }
        var src = readTag(it, TAG_SRC);
        if (src) {
          if (!plans) plans = {};
          if (plans[src] === undefined) {
            var pg = planById(doc, src);
            plans[src] = pg ? getState(pg) : null;
          }
          if (plans[src]) {
            if (!seen['plan:' + src]) {
              seen['plan:' + src] = 1;
              r.plan++;
              if (!r.first.plan) r.first.plan = plans[src];
            }
            continue;
          }
        }
        r.plain++;
      }
      if (sel.length > lim) r.plain += sel.length - lim;
      addNative(r);
      return done(r);
    } catch (e) {
      return done({ doc: true, n: 0, err: errText(e) });
    }
  }

  // 눈금자 단위 (패널이 거리를 이 단위로 보여 줌). f = 1단위가 몇 pt
  function unitInfo(doc) {
    var u = 'pt', f = 1;
    try {
      var r = doc.rulerUnits;
      if (r == RulerUnits.Millimeters) { u = 'mm'; f = 72 / 25.4; }
      else if (r == RulerUnits.Centimeters) { u = 'cm'; f = 72 / 2.54; }
      else if (r == RulerUnits.Inches) { u = 'in'; f = 72; }
      else if (r == RulerUnits.Pixels) { u = 'px'; f = 1; }
      else if (r == RulerUnits.Picas) { u = 'pc'; f = 12; }
    } catch (e) {}
    return { u: u, f: f };
  }

  // 아트보드 짧은 변 (프리셋 크기 맞춤) · 단위
  function docInfo() {
    try {
      var doc = getDoc();
      var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
      var un = unitInfo(doc);
      return done({ w: Math.abs(ab[2] - ab[0]), h: Math.abs(ab[1] - ab[3]), cm: isCMYK(doc), u: un.u, f: un.f, name: doc.name });
    } catch (e) {
      return fail(errText(e));
    }
  }

  /* ---------- hy Shadow 플러그인 (AIP 라이브 효과) ----------
   * 플러그인이 있으면 형상·평면 그림자를 라이브 효과로 (개체를 옮기거나 고치면 그림자가 따라옴, 래스터 흐림 없음).
   * 패널 ↔ 플러그인은 app.sendScriptMessage("hyShadow", 요청, JSON) — 플러그인이 없으면 예전 스크립트 방식. */
  var nativeOk = null;   // null: 아직 모름

  function nativeSend(selector, body) {
    if (nativeOk === false) return null;
    var out = null;
    try {
      out = app.sendScriptMessage('hyShadow', selector, body ? toJSON(body) : '');
    } catch (e) {
      nativeOk = false;
      return null;
    }
    if (out === undefined || out === null || out === '') { if (selector == 'ping') nativeOk = false; return null; }
    nativeOk = true;
    return String(out);
  }

  function nativePing() {
    nativeOk = null;
    var out = nativeSend('ping', null);
    var r = out ? parseArgs(out) : null;
    return done({ found: !!(r && r.ok), version: r && r.data ? r.data.version : '' });
  }

  function nativeCall(argStr) {
    var a = parseArgs(argStr);
    var out = nativeSend(a.sel, a.body || null);
    if (!out) return fail('hy Shadow 플러그인이 없어요 (허브에서 hy Shadow 플러그인 설치)');
    return out;
  }

  // 선택 상태에 플러그인 효과 수와 첫 효과 값 (패널 슬라이더에 넣는 모양으로)
  function addNative(r) {
    if (!nativeOk || !r.n) return;
    var out = nativeSend('info', null), info = null;
    try { info = out ? parseArgs(out) : null; } catch (e) { info = null; }
    if (!info || !info.ok || !info.data) return;
    var d = info.data;
    r.nform = d.form || 0;
    r.nplan = d.plan || 0;
    r.plain = Math.max(0, r.plain - r.nform - r.nplan);
    var p = d.p || {};
    var key = 'n' + d.kind + ':' + r.nform + ':' + r.nplan + ':' + toJSON(p).length;
    if (d.kind == 'form') {
      r.first.nform = { id: key, a: p.angle, L: p.length, O: p.opacity, F: p.fade, S: p.soften, c: p.c, fc: p.hex, m: p.mode, h: p.holes ? 1 : 0 };
    } else if (d.kind == 'plan') {
      r.first.nplan = { id: key, dir: p.dir, dist: p.distance, size: p.size, O: p.opacity, fall: p.falloff, c: p.c, fc: p.hex, m: p.mode, h: p.holes ? 1 : 0 };
    }
  }

  function ping() {
    return done({ msg: 'ready', docs: app.documents.length, blur: blurInfo ? blurInfo.name : '' });
  }

  // 진입점 오류는 늘 {ok:false,msg} 로 — CEP 는 던진 오류를 "EvalScript error." 로만 돌려줘서 이유가 사라진다
  function guard(fn) {
    return function (s) {
      try { return fn(s); } catch (e) { return fail(errText(e)); }
    };
  }

  return {
    ping: guard(ping),
    status: guard(status),
    docInfo: guard(docInfo),
    pickColor: guard(pickColor),
    formMake: guard(formMake),
    formLive: guard(formLive),
    formAll: guard(formAll),
    dropMake: guard(dropMake),
    planGather: guard(planGather),
    planDraw: guard(planDraw),
    remove: guard(remove),
    nativePing: guard(nativePing),
    nativeCall: guard(nativeCall),
    _test: {
      shear: shear, formStops: formStops, blurRadius: blurRadius, packKV: packKV, unpackKV: unpackKV,
      dropXML: dropXML, flatten: flatten, fillHoles: fillHoles,
      resetBlur: function () { blurInfo = null; }, blurInfo: function () { return blurInfo; }
    }
  };
})();
