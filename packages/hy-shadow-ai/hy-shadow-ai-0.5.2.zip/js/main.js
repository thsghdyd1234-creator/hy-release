/* hy Shadow AI 패널 */
(function () {
  'use strict';

  var H = window.HYSH;
  var STORE = 'hyShadowAI.v1';

  var DEF = {
    tab: 'form',
    form: { angle: 30, length: 70, opacity: 55, fade: 40, soften: 8, color: 'black', hex: '3c4a5c', mode: 'multiply', holes: true, split: 'item', live: false },
    drop: { method: 'plan', dir: -45, distance: 6, size: 18, opacity: 28, falloff: 0, color: 'black', hex: '3c4a5c', mode: 'multiply', unit: 'each', holes: false, density: false, layer: true, flat: false, preset: 'soft' },
    open: { form: false, drop: false },
    native: true          // hy Shadow 플러그인이 있으면 라이브 효과로
  };

  var state = load();
  var doc = { f: 1, u: 'pt', factor: 1, name: '' };   // f: 1단위 = f pt
  var sel = null;          // 마지막 선택 상태 (엔진 status)
  var selSig = '';
  var orig = null;         // 선택을 읽었을 때 값 (되돌리기)
  var planCache = {};      // 평면 그림자 id → 읽어 둔 모양 {subj, u}
  var dragging = false;
  var sess = '';
  var nat = false;         // hy Shadow 플러그인(AIP)이 깔려 있는지           // 선택을 읽은 회차 — 엔진이 그림자마다 '고치기 전 값'을 이 회차로 남긴다 (되돌리기)

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function load() {
    var s = {};
    try { s = JSON.parse(localStorage.getItem(STORE)) || {}; } catch (e) { s = {}; }
    var out = clone(DEF);
    if (s.tab === 'form' || s.tab === 'drop') out.tab = s.tab;
    if (typeof s.native === 'boolean') out.native = s.native;
    ['form', 'drop', 'open'].forEach(function (g) {
      if (!s[g]) return;
      for (var k in out[g]) if (s[g][k] !== undefined && typeof s[g][k] === typeof out[g][k]) out[g][k] = s[g][k];
    });
    return out;
  }
  function save() { try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (e) {} }

  function $(id) { return document.getElementById(id); }
  function all(q, root) { return Array.prototype.slice.call((root || document).querySelectorAll(q)); }

  /* ---------- 아래 도움말 ---------- */
  var helpMsgTimer = null;
  function say(msg, kind) {
    var el = $('helpMsg');
    el.textContent = msg || '';
    el.className = 'msg' + (kind ? ' ' + kind : '');
    clearTimeout(helpMsgTimer);
    if (kind === 'ok') helpMsgTimer = setTimeout(function () { el.className = 'msg'; }, 3000);
  }
  document.addEventListener('mouseover', function (e) {
    var t = e.target.closest ? e.target.closest('[data-tip]') : null;
    var f = $('help');
    if (t) { $('helpTip').textContent = t.getAttribute('data-tip'); f.classList.add('hover'); }
    else f.classList.remove('hover');
  });
  document.addEventListener('mouseleave', function () { $('help').classList.remove('hover'); });

  /* ---------- 엔진 부르기 (한 번에 하나, 실시간은 마지막 것만) ---------- */
  var busy = false, pending = null;
  function setBusy(b) { busy = b; document.body.classList.toggle('busy', b); }

  // 걸린 시간 (개발용 — 도움말 줄을 Shift+클릭하면 복사)
  var times = [];
  function copyTimes() {
    var txt = times.join('\n') || '(아직 없음)';
    var ta = document.createElement('textarea');
    ta.value = txt; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    say('걸린 시간 ' + times.length + '줄을 복사했어요', 'ok');
  }

  function call(fn, args, cb) {
    var script = 'hySh.' + fn + '(' + JSON.stringify(JSON.stringify(args || {})) + ')';
    var t0 = Date.now();
    CEP.evalScript(script, function (res) {
      var r;
      try { r = JSON.parse(res); } catch (e) { r = { ok: false, msg: res && res !== 'undefined' ? String(res) : '일러스트 쪽 응답이 없어요' }; }
      if (fn !== 'status') {
        times.push(fn + (args && args.last ? '(놓음)' : '') + ' ' + (Date.now() - t0) + 'ms' + (r.t ? ' — 엔진 ' + r.t : ''));
        if (times.length > 20) times.shift();
      }
      if (cb) cb(r);
    });
  }

  // 사용자가 누른 작업: 앞 작업이 끝나면 바로
  function run(fn, args, cb) {
    pending = null;
    if (busy) { setTimeout(function () { run(fn, args, cb); }, 60); return; }
    setBusy(true);
    call(fn, args, function (r) {
      setBusy(false);
      if (!r.ok) say(r.msg || '실패했어요', 'err');
      else if (r.msg) say(r.msg, 'ok');
      if (cb) cb(r);
      pump();
      poll(true);
    });
  }

  // 여러 번 부르는 작업(평면 그림자: 읽기 → 그리기)을 한 작업처럼
  function runJob(go, cb) {
    pending = null;
    if (busy) { setTimeout(function () { runJob(go, cb); }, 60); return; }
    setBusy(true);
    go(function (r) {
      setBusy(false);
      if (!r.ok) say(r.msg || '실패했어요', 'err');
      if (cb) cb(r);
      pump();
      poll(true);
    });
  }

  // 실시간 반영: 진행 중이면 마지막 요청만 남겨 두었다가
  function live(job) {
    pending = job;
    pump();
  }
  function pump() {
    if (busy || !pending) return;
    var job = pending;
    pending = null;
    setBusy(true);
    job.go(function (r) {
      setBusy(false);
      if (r && !r.ok) say(r.msg || '반영하지 못했어요', 'err');
      pump();
    });
  }

  /* ---------- 슬라이더 ---------- */
  var SL = {
    form: [
      { k: 'angle', box: 'formDir', lab: '각도', min: -180, max: 180, unit: '°', tip: '그림자가 눕는 방향 — 90°는 뒤로, -90°는 앞으로' },
      { k: 'length', box: 'formDir', lab: '길이', min: 5, max: 250, unit: '%', tip: '키에 대한 그림자 길이 (해가 낮을수록 길게)' },
      { k: 'opacity', box: 'formLook', lab: '진하기', min: 0, max: 100, unit: '%', tip: '그림자 전체 불투명도' },
      { k: 'fade', box: 'formLook', lab: '흐려짐', min: 0, max: 100, unit: '%', tip: '발에서 멀어질수록 옅어지는 정도', paint: true },
      { k: 'soften', box: 'formLook', lab: '끝 번짐', min: 0, max: 30, unit: '', tip: '발은 또렷하게, 끝은 흐리게 — 0이면 흐림 없이', paint: true }
    ],
    drop: [
      { k: 'dir', box: 'dropDir', lab: '각도', min: -180, max: 180, unit: '°', tip: '그림자가 떨어지는 방향' },
      { k: 'distance', box: 'dropSize', lab: '거리', min: 0, max: 500, unit: 'len', curve: 'sq', tip: '개체에서 그림자까지 (평면은 그림자 길이)' },
      { k: 'size', box: 'dropSize', lab: '번짐', min: 0, max: 144, unit: 'len', curve: 'sq', tip: '그림자 가장자리 흐림' },
      { k: 'opacity', box: 'dropSize', lab: '진하기', min: 0, max: 100, unit: '%', tip: '그림자 불투명도' },
      { k: 'falloff', box: 'dropSize', lab: '옅어짐', min: 0, max: 100, unit: '%', tip: '멀어질수록 옅게 — 여러 겹으로 쌓아요 (벽 그림자)' }
    ]
  };
  var rows = {};   // 'form.angle' → {el, range, val, spec}

  function maxOf(spec) {
    if (spec.unit !== 'len') return spec.max;
    return Math.max(60, Math.round(spec.max * Math.max(0.5, doc.factor)));
  }
  function toPos(spec, v) {
    var mx = maxOf(spec);
    if (spec.curve === 'sq') return Math.round(Math.sqrt(H.clamp(v / mx, 0, 1)) * 1000);
    return v;
  }
  function fromPos(spec, pos) {
    if (spec.curve === 'sq') { var t = pos / 1000; return Math.round(maxOf(spec) * t * t * 10) / 10; }
    return Number(pos);
  }
  function fmt(spec, v) {
    if (spec.unit === 'len') {
      var x = v / doc.f;
      return (x < 10 ? x.toFixed(1) : Math.round(x)) + ' ' + doc.u;
    }
    return Math.round(v) + spec.unit;
  }

  function buildSliders() {
    ['form', 'drop'].forEach(function (g) {
      SL[g].forEach(function (spec) {
        var box = $(spec.box);
        var row = document.createElement('div');
        row.className = 'srow';
        row.setAttribute('data-tip', spec.tip + ' · 값을 두 번 누르면 기본값');
        var lab = document.createElement('span'); lab.className = 'lab'; lab.textContent = spec.lab;
        var range = document.createElement('input'); range.type = 'range';
        if (spec.curve === 'sq') { range.min = 0; range.max = 1000; range.step = 1; }
        else { range.min = spec.min; range.max = spec.max; range.step = 1; }
        var val = document.createElement('em'); val.className = 'val';
        row.appendChild(lab); row.appendChild(range); row.appendChild(val);
        box.appendChild(row);
        var key = g + '.' + spec.k;
        rows[key] = { el: row, range: range, val: val, spec: spec, g: g };
        range.addEventListener('input', function () { onSlide(g, spec, fromPos(spec, range.value), false); });
        range.addEventListener('change', function () { onSlide(g, spec, fromPos(spec, range.value), true); });
        range.addEventListener('pointerdown', function () { dragging = true; });
        range.addEventListener('pointerup', function () { dragging = false; setTimeout(settle, 0); });
        range.addEventListener('wheel', function (e) {
          e.preventDefault();
          var step = spec.curve === 'sq' ? 10 : 1;
          var pos = Number(range.value) + (e.deltaY < 0 ? step : -step);
          range.value = H.clamp(pos, Number(range.min), Number(range.max));
          onSlide(g, spec, fromPos(spec, range.value), true);
        }, { passive: false });
        val.addEventListener('dblclick', function () {
          onSlide(g, spec, DEF[g][spec.k], true);
        });
      });
    });
  }

  function paintRow(r) {
    var v = state[r.g][r.spec.k];
    r.range.value = toPos(r.spec, v);
    var lo = Number(r.range.min), hi = Number(r.range.max);
    r.range.style.setProperty('--p', ((Number(r.range.value) - lo) / (hi - lo) * 100) + '%');
    r.val.textContent = fmt(r.spec, v);
  }

  // 끄다가 그대로 두거나 제자리로 돌아와 놓으면 'change' 가 안 온다 → 잠깐 멈추거나 손을 떼면 놓은 것으로
  var idleT = null, idleGo = null;
  function settle() {
    clearTimeout(idleT); idleT = null;
    var go = idleGo; idleGo = null;
    if (go) go();
  }

  // idle: 끄던 손을 잠깐 멈춤 (아직 안 놓음) — 무거운 그림자는 정말 놓을 때만 고친다
  function onSlide(g, spec, v, final, idle) {
    clearTimeout(idleT); idleT = null; idleGo = null;
    if (!final) {
      idleGo = function () { onSlide(g, spec, state[g][spec.k], true, true); };
      idleT = setTimeout(settle, 450);
    }
    state[g][spec.k] = v;
    if (g === 'drop') { state.drop.preset = ''; renderPresets(); }
    paintRow(rows[g + '.' + spec.k]);
    renderPreview(g);
    if (spec.k === 'angle' || spec.k === 'dir') renderCompass(g);
    if (final && !idle) { save(); dragging = false; }
    markChanged();
    if (g === 'form') applyForm(spec.k === 'angle' || spec.k === 'length' ? ['angle', 'length'] : [spec.k], final, spec.paint, idle);
    else applyDrop(final, idle);
  }

  /* ---------- 나침반 · 미리보기 ---------- */
  function renderCompass(g) {
    var a = g === 'form' ? state.form.angle : state.drop.dir;
    $(g === 'form' ? 'formAngleBig' : 'dropAngleBig').textContent = Math.round(a) + '°';
    all('#' + g + 'Compass button').forEach(function (b) {
      b.classList.toggle('on', Math.abs(H.norm180(Number(b.getAttribute('data-a')) - a)) < 0.5);
    });
  }

  function bindCompass(g) {
    all('#' + g + 'Compass button').forEach(function (b) {
      b.addEventListener('click', function () {
        var a = Number(b.getAttribute('data-a'));
        var spec = SL[g][0];
        onSlide(g, spec, a, true);
      });
    });
  }

  // 작은 사람 (발끝 0,0 · 키 44, y 위쪽)
  var FIG = [
    circlePts(0, 39, 5, 14),
    [[-5, 18], [5, 18], [5.5, 33], [-5.5, 33]],
    [[-4.6, 0], [-1, 0], [-0.6, 19], [-4.2, 19]],
    [[1, 0], [4.6, 0], [4.2, 19], [0.6, 19]],
    [[-8.2, 20], [-6, 20], [-5, 32], [-6.4, 32]],
    [[6, 20], [8.2, 20], [6.4, 32], [5, 32]]
  ];
  function circlePts(cx, cy, r, n) {
    var p = [];
    for (var i = 0; i < n; i++) { var t = i / n * Math.PI * 2; p.push([cx + r * Math.cos(t), cy + r * Math.sin(t)]); }
    return p;
  }
  function polyStr(pts, fx) {
    return pts.map(function (p) { var q = fx(p); return q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' ');
  }
  function shadowCss(c, hex) {
    if (c === 'navy') return '#182238';
    if (c === 'custom') return '#' + (hex || '3c4a5c');
    return '#000';
  }

  function renderPreview(g) {
    var svg = $(g === 'form' ? 'formPreview' : 'dropPreview');
    var s = '';
    if (g === 'form') {
      var f = state.form, sv = H.shear(f.angle, f.length);
      var ox = 75, oy = sv.b < 0 ? 50 : 66;          // 앞으로 눕으면 바닥선을 올려 그림자가 보이게
      var O = f.opacity / 100, Oe = O * (1 - f.fade / 100);
      var tipx = ox + sv.a * 44, tipy = oy - sv.b * 44;
      var blur = f.soften / 30 * 2.4 * f.length / 100;
      // 진하기·흐려짐은 발 → 끝 그라디언트 마스크로
      s += '<defs><linearGradient id="pgw" gradientUnits="userSpaceOnUse" x1="' + ox + '" y1="' + oy + '" x2="' + tipx.toFixed(1) + '" y2="' + tipy.toFixed(1) + '">' +
        '<stop offset="0" stop-color="#fff" stop-opacity="' + O.toFixed(3) + '"/><stop offset="1" stop-color="#fff" stop-opacity="' + Oe.toFixed(3) + '"/></linearGradient>' +
        '<mask id="pm" maskUnits="userSpaceOnUse" x="-40" y="-40" width="230" height="166"><rect x="-40" y="-40" width="230" height="166" fill="url(#pgw)"/></mask>' +
        '<filter id="pb" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="' + blur.toFixed(2) + '"/></filter></defs>';
      s += '<line class="ground" x1="0" y1="' + oy + '" x2="150" y2="' + oy + '"/>';
      var shadow = function (p) { return [ox + p[0] + sv.a * p[1], oy - sv.b * p[1]]; };
      s += '<g mask="url(#pm)"><g fill="' + shadowCss(f.color, f.hex) + '"' + (blur > 0.15 ? ' filter="url(#pb)"' : '') + '>';
      FIG.forEach(function (pts) { s += '<polygon points="' + polyStr(pts, shadow) + '"/>'; });
      s += '</g></g>';
      var fig = function (p) { return [ox + p[0], oy - p[1]]; };
      FIG.forEach(function (pts) { s += '<polygon class="fig" points="' + polyStr(pts, fig) + '"/>'; });
      svg.innerHTML = s;
      return;
    }
    var d = state.drop, k = 0.5 / Math.max(0.5, doc.factor);
    var bx = 55, by = 26, bw = 40, bh = 30;
    var dc = shadowCss(d.color, d.hex);
    s += '<defs><filter id="db" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="' + Math.min(8, d.size * k / 2).toFixed(2) + '"/></filter></defs>';
    if (d.method === 'plan') {
      var sq = [[bx, 86 - by - bh, bx + bw, 86 - by - bh, bx + bw, 86 - by, bx, 86 - by]];
      var layers = H.planLayers([{ rings: sq, d: 1 }], { dir: d.dir, distance: d.distance * k * 1.6, size: 0, opacity: d.opacity, falloff: d.falloff, holes: false })[0].layers;
      layers.forEach(function (L) {
        L.rings.forEach(function (r) {
          var pts = [];
          for (var i = 0; i < r.length; i += 2) pts.push([r[i], 86 - r[i + 1]]);
          s += '<polygon fill="' + dc + '" fill-opacity="' + L.alpha.toFixed(3) + '" points="' + polyStr(pts, function (p) { return p; }) + '"' + (d.size > 0.5 ? ' filter="url(#db)"' : '') + '/>';
        });
      });
    } else {
      H.dropStack({ dir: d.dir, distance: d.distance, size: d.size, opacity: d.opacity, falloff: d.falloff }).forEach(function (e) {
        s += '<rect x="' + (bx + e.h * k).toFixed(1) + '" y="' + (by + e.v * k).toFixed(1) + '" width="' + bw + '" height="' + bh + '" fill="' + dc + '" fill-opacity="' + e.o.toFixed(3) + '"' + (e.b > 0.5 ? ' filter="url(#db)"' : '') + '/>';
      });
    }
    s += '<rect class="box" x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="1"/>';
    svg.innerHTML = s;
  }

  /* ---------- 고르기 단추들 ---------- */
  function bindSeg(id, get, set) {
    all('#' + id + ' button').forEach(function (b) {
      b.addEventListener('click', function () { set(b.getAttribute('data-v') || b.getAttribute('data-c')); renderAll(); });
    });
  }
  function renderSeg(id, v) {
    all('#' + id + ' button').forEach(function (b) {
      b.classList.toggle('on', (b.getAttribute('data-v') || b.getAttribute('data-c')) === v);
    });
  }
  function bindCheck(id, g, k, after) {
    $(id).addEventListener('click', function () {
      state[g][k] = !state[g][k];
      save();
      renderAll();
      if (after) after();
    });
  }

  function renderPresets() {
    all('#presets button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-p') === state.drop.preset); });
  }

  function buildPresets() {
    var box = $('presets');
    H.PRESETS.forEach(function (p) {
      var b = document.createElement('button');
      b.textContent = p.label;
      b.setAttribute('data-p', p.id);
      b.setAttribute('data-tip', '값만 바꿔요 — 고른 그림자는 바로, 새로 넣기는 아래 단추로');
      b.addEventListener('click', function () {
        var v = H.presetValues(p.id, doc.factor);
        state.drop.distance = v.distance; state.drop.size = v.size; state.drop.opacity = v.opacity; state.drop.falloff = v.falloff;
        state.drop.preset = p.id;
        save();
        renderAll();
        markChanged();
        applyDrop(true);   // 넣지는 않음 (0.5.1 — 개체를 많이 고른 채 누르면 바로 넣어져 멈췄음)
      });
      box.appendChild(b);
    });
  }

  function renderAll() {
    $('pane-form').classList.toggle('hidden', state.tab !== 'form');
    $('pane-drop').classList.toggle('hidden', state.tab !== 'drop');
    all('#tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === state.tab); });
    for (var key in rows) paintRow(rows[key]);
    renderCompass('form'); renderCompass('drop');
    renderSeg('formColor', state.form.color);
    $('swCustomForm').style.background = '#' + state.form.hex;
    $('swCustomDrop').style.background = '#' + state.drop.hex;
    renderSeg('formSplit', state.form.split);
    renderSeg('formMode', state.form.mode);
    renderSeg('dropColor', state.drop.color);
    renderSeg('dropMethod', state.drop.method);
    renderSeg('dropMode', state.drop.mode);
    renderSeg('dropUnit', state.drop.unit);
    $('formHoles').setAttribute('data-on', state.form.holes ? '1' : '0');
    all('.native-only').forEach(function (el) { el.classList.toggle('hidden', !nat); });
    all('.native-opt').forEach(function (el) { el.setAttribute('data-on', state.native ? '1' : '0'); });
    all('.old-only').forEach(function (el) { el.classList.toggle('hidden', useNative()); });
    $('formLive').setAttribute('data-on', state.form.live ? '1' : '0');
    $('dropHoles').setAttribute('data-on', state.drop.holes ? '1' : '0');
    $('dropDensity').setAttribute('data-on', state.drop.density ? '1' : '0');
    $('dropLayer').setAttribute('data-on', state.drop.layer ? '1' : '0');
    $('pane-drop').setAttribute('data-method', state.drop.method);
    $('foldForm').classList.toggle('open', !!state.open.form);
    $('foldDrop').classList.toggle('open', !!state.open.drop);
    renderPresets();
    renderPreview('form'); renderPreview('drop');
    renderTarget();
  }

  /* ---------- 선택 읽기 ---------- */
  function renderTarget() {
    var name = $('tName'), dot = $('tDot'), card = $('target');
    var btn = state.tab === 'form' ? $('btnForm') : $('btnDrop');
    var parts = [], has = false, plain = 0;
    if (!sel) { name.textContent = '일러스트레이터와 연결 중…'; dot.className = 'tdot'; card.classList.remove('on'); return; }
    if (!sel.doc) { name.textContent = '열린 문서가 없어요'; dot.className = 'tdot'; card.classList.remove('on'); return; }
    if (sel.text) { name.textContent = '글자 편집 중 — Esc 로 나와 주세요'; dot.className = 'tdot'; card.classList.remove('on'); return; }
    if (state.tab === 'form') {
      if (sel.form) { parts.push('그림자 ' + sel.form); has = true; }
      if (sel.nform) { parts.push('그림자 효과 ' + sel.nform); has = true; }
      plain = sel.plain + sel.drop;
      if (plain) parts.push('개체 ' + plain);
      if (sel.plan) parts.push('평면 그림자 ' + sel.plan);
      btn.textContent = sel.form && !plain ? '다시 맞추기' : '그림자 넣기';
      if (sel.nform && !sel.form && !plain) btn.textContent = '그림자 넣기';
    } else {
      if (sel.drop) { parts.push('드롭 섀도 ' + sel.drop); has = true; }
      if (sel.plan) { parts.push('평면 그림자 ' + sel.plan); has = true; }
      if (sel.nplan) { parts.push('평면 그림자 효과 ' + sel.nplan); has = true; }
      plain = sel.plain + sel.form;
      if (plain) parts.push('개체 ' + plain);
      btn.textContent = state.drop.method === 'plan' ? '평면 그림자 넣기' : (sel.drop && !plain ? '다시 맞추기' : '드롭 섀도 넣기');
    }
    name.textContent = parts.length ? parts.join(' · ') + (has && !plain ? ' — 값이 바로 바뀌어요' : '') : '선택한 것이 없어요';
    dot.className = 'tdot' + (has ? ' has' : (plain ? ' plain' : ''));
    card.classList.toggle('on', parts.length > 0);
  }

  function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

  // 고른 그림자의 값을 패널로 (값이 다르면)
  function loadFromSelection() {
    if (!sel || !sel.first) return;
    var f = sel.first, changed = false;
    if (state.tab === 'form' && (f.form || f.nform)) {
      var st = f.form || f.nform, F = state.form;
      var nv = { angle: num(st.a, F.angle), length: num(st.L, F.length), opacity: num(st.O, F.opacity), fade: num(st.F, F.fade), soften: num(st.S, F.soften), color: st.c || F.color, mode: st.m || F.mode };
      if (st.c === 'custom' && st.fc) nv.hex = st.fc;
      for (var k in nv) if (F[k] !== nv[k]) { F[k] = nv[k]; changed = true; }
    } else if (state.tab === 'drop' && (f.drop || f.plan || f.nplan)) {
      var ds = f.drop || f.plan || f.nplan, D = state.drop;
      var dv = { method: f.drop ? 'fx' : 'plan', dir: num(ds.dir, D.dir), distance: num(ds.dist, D.distance), size: num(ds.size, D.size), opacity: num(ds.O, D.opacity), falloff: num(ds.fall, D.falloff), color: ds.c || D.color, mode: ds.m || D.mode };
      if (ds.c === 'custom' && ds.fc) dv.hex = ds.fc;
      if (f.plan && !f.drop) { dv.holes = ds.h == 1; dv.density = ds.dn == 1; }
      if (f.nplan && !f.drop && !f.plan) dv.holes = ds.h == 1;
      for (var j in dv) if (D[j] !== dv[j]) { D[j] = dv[j]; changed = true; }
      if (changed) D.preset = '';
    }
    orig = clone(state);
    sess = 'p' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);
    $('btnRevert').classList.remove('show');
    if (changed) { save(); renderAll(); }
  }

  // 되돌리기: 형상 그림자는 그림자마다 엔진이 남긴 값으로(여러 개여도 각자), 드롭·평면은 하나만 골랐을 때만
  function markChanged() {
    if (!orig || !sel) return;
    var g = state.tab;
    var ok = g === 'form' ? (sel.form + (sel.nform || 0)) > 0 : (sel.drop + sel.plan + (sel.nplan || 0)) === 1;
    $('btnRevert').classList.toggle('show', ok && JSON.stringify(orig[g]) !== JSON.stringify(state[g]));
  }

  // 무엇을 골랐는지만 (값은 넣지 않음 — 슬라이더로 바꿀 때마다 새 선택으로 보면 되돌리기 기준이 사라짐)
  function signature(r) {
    var f = r.first || {};
    var id = function (s) { return s ? s.id || '?' : ''; };
    return [r.doc, r.name, r.n, r.form, r.drop, r.plan, r.plain, r.text, id(f.form), id(f.drop), id(f.plan), r.nform, r.nplan, id(f.nform), id(f.nplan)].join('|');
  }

  var pollTimer = null, pollGen = 0;
  function poll(now) {
    clearTimeout(pollTimer);
    var gen = ++pollGen;   // 새로 부르면 앞 고리는 멈춘다 (확인이 겹쳐 두 배로 돌지 않게)
    var go = function () {
      if (gen !== pollGen) return;
      if (busy || dragging || pending || document.hidden) { pollTimer = setTimeout(go, 600); return; }
      call('status', {}, function (r) {
        if (gen !== pollGen) return;
        if (r && r.ok !== false) {
          var sig = signature(r);
          var docChanged = r.name !== doc.name;
          sel = r;
          if (docChanged) { doc.name = r.name; planCache = {}; readDoc(); }
          if (sig !== selSig) {
            selSig = sig;
            planCache = {};
            autoTab();
            loadFromSelection();
          }
          renderTarget();
        }
        pollTimer = setTimeout(go, 900);
      });
    };
    pollTimer = setTimeout(go, now ? 30 : 0);
  }

  // 지금 탭의 그림자는 없고 다른 쪽 그림자만 골랐으면 그 탭으로
  function autoTab() {
    if (!sel || !sel.n) return;
    var formSide = (sel.form + (sel.nform || 0)) > 0, dropSide = (sel.drop + sel.plan + (sel.nplan || 0)) > 0;
    if (state.tab === 'form' && !formSide && dropSide && !sel.plain) setTab('drop');
    else if (state.tab === 'drop' && !dropSide && formSide && !sel.plain) setTab('form');
  }

  function setTab(t) {
    state.tab = t;
    save();
    renderAll();
  }

  function readDoc() {
    call('docInfo', {}, function (r) {
      if (!r.ok) return;
      doc.f = r.f || 1; doc.u = r.u || 'pt';
      doc.factor = H.docFactor(r.w, r.h);
      renderAll();
    });
  }

  /* ---------- hy Shadow 플러그인 (라이브 효과) ---------- */
  function useNative() { return nat && state.native; }

  // 고른 그림자가 이만큼 넘으면 끄는 동안에는 문서를 안 고침 (일러스트가 개체마다 다시 그려서 멈춤)
  var HEAVY = { native: 40, form: 20, fx: 12 }, heavySaid = 0;
  function heavyNote(what) {
    if (Date.now() - heavySaid < 4000) return;
    heavySaid = Date.now();
    say(what + ' — 손을 놓으면 한 번에 바뀌어요');
  }

  function rgbOf(c, hex) {
    if (c === 'custom' && /^[0-9a-f]{6}$/i.test(hex || '')) return [parseInt(hex.substr(0, 2), 16), parseInt(hex.substr(2, 2), 16), parseInt(hex.substr(4, 2), 16)];
    return (H.COLORS[c] || H.COLORS.black).slice();
  }

  function nativeForm() {
    var f = state.form;
    return { angle: f.angle, length: f.length, opacity: f.opacity, fade: f.fade, soften: f.soften, holes: f.holes,
      color: rgbOf(f.color, f.hex), mode: f.mode, c: f.color, hex: f.hex };
  }

  function nativePlan() {
    var d = state.drop;
    return { dir: d.dir, distance: d.distance, size: d.size, opacity: d.opacity, falloff: d.falloff, holes: d.holes,
      color: rgbOf(d.color, d.hex), mode: d.mode, c: d.color, hex: d.hex };
  }

  // 슬라이더 키 → 플러그인 값 키 (색은 칩·hex·rgb 를 같이)
  function nativeKeys(only) {
    var out = [];
    (only || []).forEach(function (k) {
      if (k === 'color') out.push('color', 'c', 'hex');
      else out.push(k);
    });
    return out;
  }

  function nativeUpdate(kind, only) {
    var p = kind === 'form' ? nativeForm() : nativePlan();
    live({ go: function (done) { call('nativeCall', { sel: 'update', body: { kind: kind, p: p, only: nativeKeys(only) } }, done); } });
  }

  function nativeApply(kind) {
    var p = kind === 'form' ? nativeForm() : nativePlan();
    say(kind === 'form' ? '그림자 넣는 중…' : '평면 그림자 넣는 중…');
    run('nativeCall', { sel: 'apply', body: { kind: kind, p: p } }, function (r) {
      selSig = '';
      // 플러그인이 하나도 못 넣었으면(예: 0.1.0 이 레이어째 고른 것을 못 받음) 스크립트 방식으로 넣는다
      if (r && !r.ok && !r.n && /오류|못 함/.test(r.msg || '')) {
        say((kind === 'form' ? '그림자' : '평면 그림자') + '를 플러그인이 못 넣어서 스크립트로 넣는 중…', 'warn');
        if (kind === 'form') run('formMake', formArgs(), function () { selSig = ''; });
        else runJob(function (done) { gatherThenDraw(false, done); }, function (q) {
          if (q.ok) say(q.msg || '평면 그림자를 넣었어요', 'ok');
          selSig = '';
        });
      }
    });
  }

  function checkNative() {
    call('nativePing', {}, function (r) {
      nat = !!(r && r.ok && r.found);
      renderAll();
    });
  }

  /* ---------- 형상 그림자 ---------- */
  function formArgs() {
    var f = state.form;
    return { p: { angle: f.angle, length: f.length, opacity: f.opacity, fade: f.fade, soften: f.soften, color: f.color, mode: f.mode, holes: f.holes }, hex: f.hex };
  }

  // only: 바꾼 값만 그림자에 (여러 그림자를 골라도 다른 값은 각자 그대로)
  function applyForm(only, final, paintOnly, idle) {
    // 플러그인 효과는 고칠 때 일러스트가 다시 그리기만 해서 가볍다 → 끄는 동안에도 바로 (많으면 놓을 때만)
    if (sel && sel.nform && nat) {
      if (sel.nform <= HEAVY.native || (final && !idle)) nativeUpdate('form', only);
      else heavyNote('그림자 효과 ' + sel.nform + '개');
      if (!sel.form) return;
    }
    if (!sel || !sel.form) return;
    if (sel.form > HEAVY.form && (!final || idle)) { heavyNote('그림자 ' + sel.form + '개'); return; }
    if (paintOnly && !final) return;     // 흐려짐·번짐은 놓았을 때만 (칠을 새로 해야 해서)
    // 끄는 동안은 패널 미리보기만, 놓거나 잠깐 멈추면 문서에 (일러스트는 고칠 때마다 화면을 다시 그려서 끌기를 못 따라감)
    if (!final && !state.form.live) return;
    var a = formArgs();
    a.only = only;
    a.last = !!final;
    a.sess = sess;
    live({ go: function (done) { call('formLive', a, done); } });
  }

  function makeForm() {
    if (useNative() && !(sel && sel.form)) { nativeApply('form'); return; }
    var a = formArgs();
    a.split = state.form.split;
    say(sel && sel.form && !(sel.plain + sel.drop) ? '다시 맞추는 중…' : '그림자 만드는 중…');
    run('formMake', a, function () { selSig = ''; });
  }

  /* ---------- 드롭 섀도 · 평면 그림자 ---------- */
  function dropP() {
    var d = state.drop;
    return { dir: d.dir, distance: d.distance, size: d.size, opacity: d.opacity, falloff: d.falloff, holes: d.holes, density: d.density };
  }
  function fxArgs() {
    var p = dropP();
    return { p: p, fx: H.dropStack(p), color: state.drop.color, hex: state.drop.hex, mode: state.drop.mode, unit: state.drop.unit };
  }

  function drawPlan(id, cache, isLive, done) {
    var p = dropP();
    var classes = H.planLayers(cache.subj, p);
    call('planDraw', {
      id: id, u: cache.u, merge: cache.merge || [], p: p, classes: classes, clip: H.planClip(classes, p), blur: H.planBlur(p),
      color: state.drop.color, hex: state.drop.hex, mode: state.drop.mode, live: !!isLive, layer: !!state.drop.layer
    }, done);
  }

  function gatherThenDraw(isLive, done) {
    // 색 농도를 안 쓰면 확장해야 하는 개체를 한 덩어리로 한 번에 읽는다 (농도 반영을 바꾸면 다시 읽음)
    call('planGather', { holes: false, density: !!state.drop.density, live: !!isLive }, function (g) {
      if (!g.ok) { done(g); return; }
      planCache[g.id] = { subj: g.subj, u: g.u, merge: isLive ? [] : g.merge };
      drawPlan(g.id, planCache[g.id], isLive, function (r) {
        planCache[g.id].merge = [];
        if (r.ok && g.bad) r.msg = (r.msg ? r.msg + ' · ' : '') + g.bad + '개는 모양을 못 읽었어요';
        done(r);
      });
    });
  }

  // 드롭 섀도(효과를 풀고 다시 감쌈)·평면 그림자(모양을 새로 그림)는 무거워서 놓았을 때만 — 끄는 동안은 패널 미리보기
  function applyDrop(final, idle) {
    if (sel && sel.nplan && nat && state.drop.method === 'plan') {
      if (sel.nplan <= HEAVY.native || (final && !idle)) nativeUpdate('plan', ['dir', 'distance', 'size', 'opacity', 'falloff', 'holes', 'color', 'mode']);
      else heavyNote('평면 그림자 효과 ' + sel.nplan + '개');
      return;
    }
    if (!sel || !final) return;
    if (state.drop.method === 'fx' && sel.drop > HEAVY.fx) {
      say('드롭 섀도 ' + sel.drop + '개 — 개체마다 효과를 다시 그려서 바로 고치지 않아요. 값을 다 정한 뒤 [다시 맞추기]', 'warn');
      return;
    }
    if (idle && state.drop.method === 'fx' && sel.drop > 1) return;
    if (state.drop.method === 'fx' && sel.drop) {
      var a = fxArgs();
      a.live = true;
      live({ go: function (done) { call('dropMake', a, done); } });
    } else if (state.drop.method === 'plan' && sel.plan) {
      var id = sel.first && sel.first.plan ? sel.first.plan.id : null;
      live({
        go: function (done) {
          if (id && planCache[id]) drawPlan(id, planCache[id], true, done);
          else gatherThenDraw(true, done);
        }
      });
    }
  }

  // 효과(일러스트 드롭 섀도)는 개체마다 래스터 효과라 개체가 많으면 오래 걸리거나 멈춘다 → 한 번 더 눌러야 넣음
  var BIG_FX = 40, bigAsk = 0;
  function bigOk() {
    if (state.drop.method !== 'fx' || !sel || (sel.n || 0) <= BIG_FX) return true;
    if (Date.now() - bigAsk < 6000) { bigAsk = 0; return true; }
    bigAsk = Date.now();
    say('개체 ' + sel.n + '개 — 드롭 섀도 효과는 개체마다 그려서 오래 걸려요. 한 번 더 누르면 넣어요 (배치도는 \'벡터 (평면)\'이 가벼워요)', 'warn');
    return false;
  }

  function makeDrop() {
    if (!bigOk()) return;
    if (state.drop.method === 'plan' && useNative() && !(sel && sel.plan)) {
      if (sel && sel.drop) run('remove', { kind: 'drop' }, function (r) { if (r.ok) nativeApply('plan'); });
      else nativeApply('plan');
      return;
    }
    var other = state.drop.method === 'fx' ? sel && sel.plan : sel && sel.drop;
    var go = function () {
      if (state.drop.method === 'fx') {
        run('dropMake', fxArgs(), function () { selSig = ''; });
      } else {
        say('평면 그림자 만드는 중…');
        runJob(function (done) { gatherThenDraw(false, done); }, function (r) {
          if (r.ok) say(r.msg || '평면 그림자를 넣었어요', 'ok');
          selSig = '';
        });
      }
    };
    // 다른 방식의 그림자를 골랐으면 그것을 풀고 새 방식으로
    if (other) run('remove', { kind: 'drop' }, function (r) { if (r.ok) go(); });
    else go();
  }

  // 색 칩: '고른 색'은 누를 때마다 일러스트 색상 피커로 (취소하면 그대로)
  function pickIf(g, v, after) {
    if (v !== 'custom') {
      state[g].color = v;
      save(); renderAll(); markChanged(); after();
      return;
    }
    if (busy) return;
    call('pickColor', { hex: state[g].hex }, function (r) {
      if (!r.ok) { say(r.msg || '색을 고르지 못했어요', 'err'); return; }
      var changed = state[g].color !== 'custom' || r.hex !== state[g].hex;
      state[g].hex = r.hex;
      state[g].color = 'custom';
      save(); renderAll();
      if (changed) { markChanged(); after(); }
    });
  }

  /* ---------- 단추 ---------- */
  function bind() {
    all('#tabs button').forEach(function (b) {
      b.addEventListener('click', function () { setTab(b.getAttribute('data-tab')); selSig = ''; poll(true); });
    });
    bindCompass('form'); bindCompass('drop');
    bindSeg('formColor', null, function (v) { pickIf('form', v, function () { applyForm(['color'], true, true); }); });
    bindSeg('formSplit', null, function (v) { state.form.split = v; save(); });
    bindSeg('formMode', null, function (v) { state.form.mode = v; save(); markChanged(); applyForm(['mode'], true); });
    bindSeg('dropColor', null, function (v) { pickIf('drop', v, function () { applyDrop(true); }); });
    bindSeg('dropMethod', null, function (v) { state.drop.method = v; save(); });
    bindSeg('dropMode', null, function (v) { state.drop.mode = v; save(); markChanged(); applyDrop(true); });
    bindSeg('dropUnit', null, function (v) { state.drop.unit = v; save(); });
    bindCheck('formHoles', 'form', 'holes', function () { if (sel && sel.form) makeForm(); });
    bindCheck('formLive', 'form', 'live');
    $('helpMsg').addEventListener('click', function (e) { if (e.shiftKey) copyTimes(); });
    bindCheck('dropHoles', 'drop', 'holes', function () { markChanged(); applyDrop(true); });
    bindCheck('dropDensity', 'drop', 'density', function () { planCache = {}; markChanged(); applyDrop(true); });
    bindCheck('dropLayer', 'drop', 'layer');
    all('.native-opt').forEach(function (el) {
      el.addEventListener('click', function () { state.native = !state.native; save(); renderAll(); });
    });
    all('.fold-head').forEach(function (h) {
      h.addEventListener('click', function () {
        var g = h.parentNode.id === 'foldForm' ? 'form' : 'drop';
        state.open[g] = !state.open[g];
        save();
        renderAll();
      });
    });
    $('btnForm').addEventListener('click', makeForm);
    $('btnAll').addEventListener('click', function () { run('formAll', formArgs()); });
    $('btnFormRemove').addEventListener('click', function () { removeBoth('form'); });
    $('btnDrop').addEventListener('click', makeDrop);
    $('btnDropRemove').addEventListener('click', function () { removeBoth('drop'); });
    $('btnRevert').addEventListener('click', function () {
      if (!orig) return;
      var g = state.tab;
      state[g] = clone(orig[g]);
      save();
      renderAll();
      $('btnRevert').classList.remove('show');
      if (g === 'form' && sel && sel.nform && nat) nativeUpdate('form', ['angle', 'length', 'opacity', 'fade', 'soften', 'color', 'mode', 'holes']);
      if (g === 'form') { if (sel && sel.form) run('formLive', { what: 'restore', sess: sess, last: true }); }
      else applyDrop(true);
    });
  }

  // 플러그인 효과와 예전(스크립트) 그림자를 함께 없앤다
  function removeBoth(g) {
    var nk = g === 'form' ? 'form' : 'plan';
    var hasNative = sel && (g === 'form' ? sel.nform : sel.nplan) && nat;
    var hasOld = sel && (g === 'form' ? sel.form : (sel.drop + sel.plan));
    if (hasNative) {
      run('nativeCall', { sel: 'remove', body: { kind: nk } }, function () {
        if (hasOld) run('remove', { kind: g }, function () { selSig = ''; });
        else selSig = '';
      });
    } else run('remove', { kind: g }, function () { selSig = ''; });
  }

  /* ---------- 테마 ---------- */
  function applyTheme() {
    var env = CEP.hostEnv();
    if (!env || !env.appSkinInfo) return;
    var c = env.appSkinInfo.panelBackgroundColor.color;
    var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
    var root = document.documentElement;
    var light = (0.299 * r + 0.587 * g + 0.114 * b) > 140;
    root.setAttribute('data-theme', light ? 'light' : 'dark');
    function shade(d) {
      return 'rgb(' + [r, g, b].map(function (v) { return Math.max(0, Math.min(255, v + d)); }).join(',') + ')';
    }
    root.style.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
    root.style.setProperty('--c1', shade(light ? -22 : 14));
    root.style.setProperty('--c2', shade(light ? -34 : 26));
    root.style.setProperty('--c3', shade(light ? -12 : -10));
  }

  /* ---------- 시작 ---------- */
  buildSliders();
  buildPresets();
  bind();
  applyTheme();
  CEP.on('com.adobe.csxs.events.ThemeColorChanged', applyTheme);
  renderAll();
  // manifest 의 ScriptPath 가 안 불렸을 때를 대비해 직접 불러온다
  CEP.evalScript('typeof hySh', function (t) {
    var start = function () { readDoc(); checkNative(); poll(true); };
    if (t === 'object' || !CEP.available) { start(); return; }
    var p = CEP.extensionPath();
    if (!p) { start(); return; }
    CEP.evalScript('$.evalFile(' + JSON.stringify(p + '/jsx/hyShadow.jsx') + ')', function () {
      CEP.evalScript('typeof hySh', function (t2) {
        if (t2 !== 'object') { say('그림자 엔진을 읽지 못했어요 — 패널을 닫았다 다시 열거나 허브에서 다시 설치해 주세요', 'err'); return; }
        start();
      });
    });
  });
  if (!CEP.available) say('일러스트레이터 안에서 열어 주세요', 'err');
})();
