/*
 * hy Shadow AI — 계산 (일러스트 의존성 없음). 패널(window.HYSH)과 Node 시험(require)이 같이 쓴다.
 *
 *  · 형상 그림자: 기울이기 벡터, 그라디언트 정지점(선명·번짐 두 겹) — 엔진(hyShadow.jsx)과 같은 식, 시험이 대조한다
 *  · 드롭 섀도(효과): 프리셋, 옅어짐 = 일러스트 드롭 섀도 여러 겹 (포토샵 hy Shadow 와 같은 쌓기)
 *  · 평면 그림자(벡터): 개체를 그림자 방향으로 쓸어 늘인 모양(민코프스키 합)을 여러 길이로 쌓아,
 *    가장 가까운 벽에서 멀수록 옅게. 벽에 붙은 겹은 또렷, 긴 겹일수록 흐리게.
 *
 * 좌표는 일러스트 문서 좌표(y 위쪽, pt). 방향 각도는 화면 기준(0° 오른쪽, 90° 위, -90° 아래).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./clipper.js'));
  else root.HYSH = factory(root.ClipperLib);
})(this, function (CL) {
  'use strict';

  var MIN_B = 0.015;
  var COLORS = { black: [0, 0, 0], navy: [24, 34, 56] };

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
  function norm180(a) {
    a = ((a % 360) + 360) % 360;
    return a > 180 ? a - 360 : a;
  }

  /* ---------- 형상 그림자 ---------- */
  function shear(angle, lengthPct) {
    var L = Math.max(0.02, lengthPct / 100);
    var th = angle * Math.PI / 180;
    var a = L * Math.cos(th), b = L * Math.sin(th);
    if (Math.abs(a) < 1e-9) a = 0;
    if (Math.abs(b) < MIN_B) b = b < 0 ? -MIN_B : MIN_B;
    return { a: a, b: b };
  }

  // 정지점 [위치 %, 불투명도 %]. 모양 안에서 선명 ∪ 번짐 = 1 − 흐려짐 × t (t: 발 0 → 끝 1)
  function formStops(fadePct, withBlur) {
    // 번짐은 발에서 0 → 끝으로 갈수록 (발은 또렷), 선명은 겹친 결과가 목표가 되게 맞춘다. 정지점 9개(사이는 직선).
    var F = clamp(fadePct / 100, 0, 1), sharp = [], blur = [];
    for (var i = 0; i <= 8; i++) {
      var t = i / 8, D = 1 - F * t;
      var B = withBlur ? D * t : 0;
      var S = withBlur ? (B < 0.9999 ? (D - B) / (1 - B) : 0) : D;
      sharp.push([t * 100, Math.round(S * 1000) / 10]);
      blur.push([t * 100, Math.round(B * 1000) / 10]);
    }
    return { sharp: sharp, blur: withBlur ? blur : null };
  }

  function blurRadius(softPct, lengthPct, H) {
    return clamp((softPct / 100) * (lengthPct / 100) * H, 0, 250);
  }

  // 정지점 사이 불투명도 (일러스트처럼 직선 보간)
  function stopAt(stops, tPct) {
    if (tPct <= stops[0][0]) return stops[0][1];
    for (var i = 1; i < stops.length; i++) {
      if (tPct <= stops[i][0]) {
        var a = stops[i - 1], b = stops[i], u = (tPct - a[0]) / (b[0] - a[0]);
        return a[1] + (b[1] - a[1]) * u;
      }
    }
    return stops[stops.length - 1][1];
  }

  /* ---------- 드롭 섀도 (효과) ---------- */
  // 짧은 변 1000pt 아트보드 기준 값. 실제로는 아트보드 크기에 맞춰 곱한다.
  var PRESETS = [
    { id: 'soft',     label: '은은하게',   distance: 6,  size: 18, opacity: 28, falloff: 0 },
    { id: 'crisp',    label: '또렷하게',   distance: 4,  size: 3,  opacity: 55, falloff: 0 },
    { id: 'float',    label: '붕 뜬',      distance: 22, size: 40, opacity: 32, falloff: 0 },
    { id: 'long',     label: '긴 그림자',  distance: 42, size: 12, opacity: 35, falloff: 0 },
    { id: 'flat',     label: '다이어그램', distance: 9,  size: 0,  opacity: 22, falloff: 0 },
    { id: 'text',     label: '글자용',     distance: 2,  size: 4,  opacity: 60, falloff: 0 },
    { id: 'wall',     label: '벽 그림자',  distance: 30, size: 10, opacity: 50, falloff: 70 },
    { id: 'longfade', label: '길게 옅게',  distance: 80, size: 20, opacity: 45, falloff: 100 },
    { id: 'contact',  label: '바닥 닿음',  distance: 10, size: 8,  opacity: 60, falloff: 90 }
  ];

  function docFactor(w, h) {
    var s = Math.min(Number(w) || 1000, Number(h) || 1000);
    return clamp(s / 1000, 0.3, 8);
  }

  function presetValues(id, factor) {
    var p = null;
    for (var i = 0; i < PRESETS.length; i++) if (PRESETS[i].id === id) p = PRESETS[i];
    if (!p) return null;
    var f = factor || 1;
    return {
      distance: Math.round(p.distance * f * 10) / 10,
      size: clamp(Math.round(p.size * f * 10) / 10, 0, 250),
      opacity: p.opacity,
      falloff: p.falloff
    };
  }

  var MAX_STACK = 10;
  var STACK_K = 2;   // 얇은 벽에서 한 지점을 대략 몇 겹이 덮는지 (진하기 보정)

  function stackCount(p) {
    if (!(p.falloff > 0) || p.distance < 3) return 1;
    return clamp(Math.ceil(p.distance / 5), 3, MAX_STACK);
  }

  // 패널 값 → 일러스트 드롭 섀도 효과 목록 [{h, v, b, o}] (h·v·b pt, o 0~1).
  // 가까운 겹은 짧고 진하고 또렷하게, 먼 겹일수록 길고 옅고 흐리게.
  function dropStack(p) {
    var th = p.dir * Math.PI / 180, ux = Math.cos(th), uy = -Math.sin(th);   // 효과의 세로 이동은 아래가 +
    var O = clamp(p.opacity / 100, 0, 1);
    var n = stackCount(p), out = [], i;
    var make = function (d, b, o) {
      return { h: round3(d * ux), v: round3(d * uy), b: round3(Math.max(0, b)), o: round3(clamp(o, 0, 1)) };
    };
    if (n === 1) return [make(p.distance, p.size, O)];
    var F = clamp((p.falloff || 0) / 100, 0, 1), spacing = p.distance / n;
    for (i = 1; i <= n; i++) {
      var t = i / n;
      var w = 1 - F * (i - 1) / (n - 1);
      out.push(make(p.distance * t, Math.max(spacing * 0.9, p.size * (0.3 + 0.7 * t)), 1 - Math.pow(1 - O * w, 1 / STACK_K)));
    }
    return out;
  }

  function round3(v) { return Math.round(v * 1000) / 1000; }

  /* ---------- 평면 그림자 (벡터) ---------- */
  var SCALE = 100;   // Clipper 정수 좌표 = pt × 100

  function toPath(flat) {
    var p = [];
    for (var i = 0; i + 1 < flat.length; i += 2) p.push({ X: Math.round(flat[i] * SCALE), Y: Math.round(flat[i + 1] * SCALE) });
    return p;
  }

  function fromPath(path) {
    var f = [];
    for (var i = 0; i < path.length; i++) f.push(path[i].X / SCALE, path[i].Y / SCALE);
    return f;
  }

  function union(paths, fill) {
    var c = new CL.Clipper(), out = new CL.Paths();
    c.AddPaths(paths, CL.PolyType.ptSubject, true);
    c.Execute(CL.ClipType.ctUnion, out, fill, fill);
    return out;
  }

  // 한 개체의 고리들(짝홀 규칙) → 칠한 영역. holes=false 면 구멍을 지우고 바깥 윤곽만.
  function solidOf(rings, fillHoles) {
    var paths = [];
    for (var i = 0; i < rings.length; i++) {
      var p = toPath(rings[i]);
      if (p.length >= 3) paths.push(p);
    }
    if (!paths.length) return [];
    var c = new CL.Clipper(), tree = new CL.PolyTree();
    c.AddPaths(paths, CL.PolyType.ptSubject, true);
    c.Execute(CL.ClipType.ctUnion, tree, CL.PolyFillType.pftEvenOdd, CL.PolyFillType.pftEvenOdd);
    if (!fillHoles) return CL.Clipper.PolyTreeToPaths(tree);
    var outers = [];
    (function walk(node) {
      var kids = node.Childs();
      for (var k = 0; k < kids.length; k++) {
        if (!kids[k].IsHole()) outers.push(kids[k].Contour());
        walk(kids[k]);
      }
    })(tree);
    return union(outers, CL.PolyFillType.pftNonZero);
  }

  // 점선: 펼친 선(x,y,…)을 대시 길이대로 끊어 열린 조각들로
  function dashPieces(flat, closed, dash) {
    var pts = [], i;
    for (i = 0; i + 1 < flat.length; i += 2) pts.push([flat[i], flat[i + 1]]);
    if (closed && pts.length) pts.push(pts[0]);
    var total = 0;
    for (i = 0; i < dash.length; i++) total += Math.max(0, dash[i]);
    if (total <= 0.01 || pts.length < 2) return [{ r: flat, c: closed }];
    var di = 0, left = dash[0], on = true, cur = [pts[0]], out = [];
    for (i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i];
      var seg = Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1])), t = 0;
      var guard = 0;
      while (seg - t > left && guard++ < 100000) {
        t += left;
        var q = [a[0] + (b[0] - a[0]) * t / seg, a[1] + (b[1] - a[1]) * t / seg];
        if (on) { cur.push(q); out.push(cur); }
        on = !on;
        cur = [q];
        di = (di + 1) % dash.length;
        left = Math.max(0.01, dash[di]);
      }
      left -= seg - t;
      cur.push(b);
    }
    if (on && cur.length > 1) out.push(cur);
    var res = [];
    for (i = 0; i < out.length; i++) {
      var f = [];
      for (var k = 0; k < out[i].length; k++) f.push(out[i][k][0], out[i][k][1]);
      res.push({ r: f, c: false });
    }
    return res;
  }

  var CAPS = { b: 'etOpenButt', r: 'etOpenRound', p: 'etOpenSquare' };
  var JOINS = { m: 'jtMiter', r: 'jtRound', b: 'jtSquare' };

  function strokePaths(g) {
    var w = Math.max(0, Number(g.w) || 0);
    if (w <= 0) return [];
    var pieces = g.d && g.d.length ? dashPieces(g.r, !!g.c, g.d) : [{ r: g.r, c: !!g.c }];
    var co = new CL.ClipperOffset(Math.max(1, Number(g.ml) || 4), 0.25 * SCALE), sol = new CL.Paths();
    for (var i = 0; i < pieces.length; i++) {
      var path = toPath(pieces[i].r);
      if (path.length < 2) continue;
      var end = pieces[i].c && path.length >= 3 ? CL.EndType.etClosedLine : CL.EndType[CAPS[g.cap] || 'etOpenButt'];
      co.AddPath(path, CL.JoinType[JOINS[g.j] || 'jtMiter'], end);
    }
    co.Execute(sol, w / 2 * SCALE);
    return sol;
  }

  function geoPaths(list) {
    var all = [], i, k;
    for (i = 0; i < list.length; i++) {
      var g = list[i], part = [];
      if (g.k === 'f') {
        var fp = [];
        for (k = 0; k < g.r.length; k++) { var p = toPath(g.r[k]); if (p.length >= 3) fp.push(p); }
        if (fp.length) part = union(fp, g.eo ? CL.PolyFillType.pftEvenOdd : CL.PolyFillType.pftNonZero);
      } else if (g.k === 's') {
        part = strokePaths(g);
      } else if (g.k === 'c') {
        var inner = geoPaths(g.g), mask = [];
        for (k = 0; k < g.m.length; k++) { var mp = toPath(g.m[k]); if (mp.length >= 3) mask.push(mp); }
        if (inner.length && mask.length) {
          var c = new CL.Clipper();
          part = new CL.Paths();
          c.AddPaths(inner, CL.PolyType.ptSubject, true);
          c.AddPaths(mask, CL.PolyType.ptClip, true);
          c.Execute(CL.ClipType.ctIntersection, part, CL.PolyFillType.pftNonZero, CL.PolyFillType.pftNonZero);
        }
      }
      // Clipper 결과는 바깥 고리가 한쪽, 구멍이 반대쪽 방향 → 그대로 모아 0이 아닌 감김으로 합치면 구멍도 맞음
      for (k = 0; k < part.length; k++) if (part[k].length >= 3) all.push(part[k]);
    }
    return all.length ? union(all, CL.PolyFillType.pftNonZero) : [];
  }

  /**
   * 엔진이 바로 읽은 조각(칠 f · 획 s · 클리핑 c) → 칠한 영역 고리들 (x,y,… 펼친 배열)
   */
  function geoRings(list) {
    var ps = geoPaths(list || []), out = [];
    for (var i = 0; i < ps.length; i++) if (ps[i].length >= 3) out.push(fromPath(ps[i]));
    return out;
  }

  function positive(path) {
    if (!CL.Clipper.Orientation(path)) path.reverse();
    return path;
  }

  // 영역 P 를 v 만큼 쓸어 늘인 모양 = P ∪ (P+v) ∪ 모든 변의 평행사변형 (구멍 쪽도 그대로 맞음, 0이 아닌 감김 규칙)
  function sweep(solid, vx, vy) {
    var dx = Math.round(vx * SCALE), dy = Math.round(vy * SCALE);
    if (!dx && !dy) return solid.slice();
    var all = [], i, k;
    for (i = 0; i < solid.length; i++) {
      var r = solid[i], moved = [];
      all.push(r);
      for (k = 0; k < r.length; k++) moved.push({ X: r[k].X + dx, Y: r[k].Y + dy });
      all.push(moved);
      for (k = 0; k < r.length; k++) {
        var a = r[k], b = r[(k + 1) % r.length];
        var cross = (b.X - a.X) * dy - (b.Y - a.Y) * dx;
        if (cross === 0) continue;
        all.push(positive([
          { X: a.X, Y: a.Y }, { X: b.X, Y: b.Y },
          { X: b.X + dx, Y: b.Y + dy }, { X: a.X + dx, Y: a.Y + dy }
        ]));
      }
    }
    var out = union(all, CL.PolyFillType.pftNonZero);
    return CL.Clipper.CleanPolygons(out, 0.05 * SCALE);
  }

  // 옅어짐: 0이면 끝까지 같은 진하기, 1이면 끝에서 0 (포토샵 평면 그림자와 같은 곡선)
  function weight(t, F) {
    return Math.pow(Math.max(0, 1 - F * clamp(t, 0, 1)), 1.2);
  }

  function layerCount(p) {
    var F = clamp((p.falloff || 0) / 100, 0, 1);
    if (F <= 0 || p.distance < 3) return 1;
    // 흐림은 묶음 전체에 한 번만 걸어서(0.3.0) 겹 사이 계단을 겹 수로 줄인다 — 겹은 벡터라 가볍다
    return clamp(Math.round(4 + 12 * F), 4, 16);
  }

  /**
   * 평면 그림자 묶음 전체에 거는 흐림 반경 (pt). 겹마다 흐림을 걸면 일러스트가 겹 수만큼 큰 래스터를 그려서 멈췄다.
   * 번짐 값, 여러 겹이면 겹 사이 계단이 안 보일 만큼(겹 간격 × 0.5) 중 큰 것. p.flat(흐림 없이) 이면 0.
   */
  function planBlur(p) {
    if (p.flat) return 0;
    var n = layerCount(p), L = Math.max(0, p.distance), R = Math.max(0, p.size || 0);
    var b = n === 1 ? R : Math.max(R, 0.5 * L / n);
    return b < 0.3 ? 0 : round3(b);
  }

  // 겹 i (길이 L·i/n) 의 불투명도: 거리 구간 i 를 덮는 겹 i..n 을 합친 진하기가 목표와 같게 (바깥 겹부터)
  function layerAlphas(p, n) {
    var O = clamp(p.opacity / 100, 0, 1), F = clamp((p.falloff || 0) / 100, 0, 1);
    var al = new Array(n), A = 0;
    for (var i = n; i >= 1; i--) {
      var T = O * weight((i - 0.5) / n, F);
      if (n === 1) T = O;
      var a = A >= 0.9999 ? 0 : 1 - (1 - T) / (1 - A);
      a = clamp(a, 0, 1);
      al[i - 1] = a;
      A = 1 - (1 - a) * (1 - A);
    }
    return al;
  }

  /**
   * 평면 그림자 겹 계산.
   * @param subj [{rings:[[x,y,x,y,…],…], d: 0~1 진하기}]
   * @param p    {dir, distance(pt), size(번짐 pt), opacity %, falloff %, holes, density}
   * @return     [{d, layers:[{rings, alpha 0~1, len}]}]  — 진하기 묶음마다, 긴 겹부터 (흐림은 planBlur — 묶음 전체에 한 번)
   */
  function planLayers(subj, p) {
    var classes = {}, order = [], i, k;
    for (i = 0; i < subj.length; i++) {
      var d = p.density ? Math.round(clamp(subj[i].d == null ? 1 : subj[i].d, 0, 1) * 10) / 10 : 1;
      if (d <= 0) continue;
      var key = String(d);
      if (!classes[key]) { classes[key] = { d: d, paths: [] }; order.push(key); }
      var s = solidOf(subj[i].g ? geoRings(subj[i].g) : subj[i].rings, !!p.holes);
      for (k = 0; k < s.length; k++) classes[key].paths.push(s[k]);
    }
    var n = layerCount(p), alphas = layerAlphas(p, n);
    var th = p.dir * Math.PI / 180, ux = Math.cos(th), uy = Math.sin(th);
    var L = Math.max(0, p.distance);
    var out = [];
    order.sort(function (a, b) { return Number(b) - Number(a); });
    for (i = 0; i < order.length; i++) {
      var cls = classes[order[i]];
      if (!cls.paths.length) continue;
      var solid = union(cls.paths, CL.PolyFillType.pftNonZero);
      var layers = [];
      for (k = n; k >= 1; k--) {
        var Li = L * k / n;
        var shape = sweep(solid, ux * Li, uy * Li);
        var rings = [];
        for (var q = 0; q < shape.length; q++) if (shape[q].length >= 3) rings.push(fromPath(shape[q]));
        var a = n === 1 ? clamp(p.opacity / 100, 0, 1) : alphas[k - 1];
        layers.push({ rings: rings, alpha: round3(a * cls.d), len: round3(Li) });
      }
      out.push({ d: cls.d, layers: layers });
    }
    return out;
  }

  /**
   * 평면 그림자 자르는 모양 (클리핑 마스크).
   * 겹마다 건 흐림은 사방으로 번져서 벽의 빛 받는 쪽(그림자 반대쪽)에도 옅은 테두리가 생긴다.
   * 가장 긴 겹의 모양을 그림자 방향 ±35° 부채꼴(반지름 = 가장 큰 흐림 × 1.5)로만 늘인 것 안쪽만 남겨,
   * 벽 앞(빛 쪽)으로 번진 것을 자른다. 다른 벽의 그림자가 닿는 곳은 그 그림자 모양 안이라 그대로 남는다.
   * @param classes planLayers 결과  @return 고리들 (없으면 [] — 자르지 않음)
   */
  var CLIP_HALF = 35, CLIP_GROW = 1.5;
  function planClip(classes, p) {
    var all = [], maxBlur = planBlur(p), i, k;
    for (i = 0; i < classes.length; i++) {
      var ls = classes[i].layers;
      if (!ls.length) continue;
      for (k = 0; k < ls[0].rings.length; k++) { var pth = toPath(ls[0].rings[k]); if (pth.length >= 3) all.push(pth); }
    }
    if (!all.length || maxBlur < 0.3) return [];
    var Rv = (maxBlur * CLIP_GROW + 0.5) * SCALE;
    var th = p.dir * Math.PI / 180, fan = [{ X: 0, Y: 0 }];
    for (k = 0; k <= 8; k++) {
      var a = th + (-CLIP_HALF + 2 * CLIP_HALF * k / 8) * Math.PI / 180;
      fan.push({ X: Math.round(Math.cos(a) * Rv), Y: Math.round(Math.sin(a) * Rv) });
    }
    var region = union(all, CL.PolyFillType.pftNonZero);
    var grown = CL.Clipper.MinkowskiSum(fan, region, true);
    var out = [];
    for (i = 0; i < grown.length; i++) if (grown[i].length >= 3) out.push(fromPath(CL.Clipper.CleanPolygon(grown[i], 0.05 * SCALE)));
    return out;
  }

  // 겹친 결과 진하기 (시험·미리보기용): 거리 구간마다 덮는 겹의 합성
  function compositeAt(alphas, i) {
    var A = 0;
    for (var j = i; j < alphas.length; j++) A = 1 - (1 - alphas[j]) * (1 - A);
    return A;
  }

  /* ---------- 미리보기 그림 (패널 나침반 안 작은 사람) ---------- */
  function previewShadow(angle, lengthPct, H) {
    var s = shear(angle, lengthPct);
    return { x: s.a * H, y: s.b * H };
  }

  return {
    COLORS: COLORS, PRESETS: PRESETS, MIN_B: MIN_B, SCALE: SCALE,
    clamp: clamp, norm180: norm180,
    shear: shear, formStops: formStops, blurRadius: blurRadius, stopAt: stopAt,
    docFactor: docFactor, presetValues: presetValues, stackCount: stackCount, dropStack: dropStack,
    solidOf: solidOf, sweep: sweep, geoRings: geoRings, dashPieces: dashPieces, union: union, toPath: toPath, fromPath: fromPath,
    layerCount: layerCount, layerAlphas: layerAlphas, weight: weight, planLayers: planLayers, planClip: planClip, planBlur: planBlur, compositeAt: compositeAt,
    previewShadow: previewShadow
  };
});
