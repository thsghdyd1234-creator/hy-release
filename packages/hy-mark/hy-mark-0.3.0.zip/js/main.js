/* hy 축열 (hy Mark) 패널 — 고르기는 전부 클릭(썸네일·칩), 계산은 core.js, 일러스트 일은 jsx/hyMark.jsx */
(function () {
  'use strict';
  var H = window.HYMARK, CEP = window.CEP;
  var KEY = 'hyMark.v1';
  var ENGINE_V = '0.3.0';

  function $(id) { return document.getElementById(id); }
  function all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function escH(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }

  /* ---------- 설정 (공통 값은 두 탭이 같이 씀) ---------- */
  function split(st) {
    var c = {}, k = {}, key;
    for (key in st) { if (!has(st, key) || key === 'kind' || key === 'v') continue; if (H.COMMON_KEYS.indexOf(key) >= 0) c[key] = st[key]; else k[key] = st[key]; }
    return [c, k];
  }
  function load() {
    var s = null;
    try { s = JSON.parse(localStorage.getItem(KEY)); } catch (e) { s = null; }
    var g = split(H.defaults('grid')), l = split(H.defaults('level'));
    var out = { tab: 'grid', common: g[0], grid: g[1], level: l[1],
      folds: { foldLooks: true, foldSize: true, foldLine: true, foldColor: false, foldGEst: false, foldLEst: false },
      recent: { grid: [], level: [] },          // 모두 같게에 적었던 값 (칩으로 다시 고르기)
      memo: { dim: 'tick' } }, k;               // 값을 적어서 간격 숫자가 켜질 때 쓸 모양 (마지막에 쓰던 것)
    if (s && typeof s === 'object') {
      if (s.tab === 'level') out.tab = 'level';
      ['common', 'grid', 'level', 'folds'].forEach(function (part) {
        if (s[part] && typeof s[part] === 'object') for (k in s[part]) if (has(s[part], k) && has(out[part], k)) out[part][k] = s[part][k];
      });
      // 0.1 은 축척을 레벨 설정에 적었다 → 공통 값으로
      if (s.level && typeof s.level === 'object' && s.level.scale > 0 && !(s.common && s.common.scale > 0)) out.common.scale = Number(s.level.scale);
      if (s.recent && typeof s.recent === 'object') ['grid', 'level'].forEach(function (kd) {
        if (Object.prototype.toString.call(s.recent[kd]) === '[object Array]') out.recent[kd] = s.recent[kd].filter(function (v) { return typeof v === 'number' && isFinite(v) && v >= 100 && v < 1e6; }).slice(0, 4);
      });
      if (s.memo && typeof s.memo === 'object' && s.memo.dim !== 'none' && H.GRID_DIMS.some(function (d) { return d.id === s.memo.dim; })) out.memo.dim = s.memo.dim;
    }
    return out;
  }
  var S = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { } }
  function cur(kind) {
    kind = kind || S.tab;
    var st = { kind: kind }, k;
    for (k in S.common) st[k] = S.common[k];
    for (k in S[kind]) st[k] = S[kind][k];
    return H.normalize(st);
  }
  function isCommon(k) { return H.COMMON_KEYS.indexOf(k) >= 0; }
  function get(k) { return isCommon(k) ? S.common[k] : S[S.tab][k]; }

  /* ---------- 글자 재기 (패널 글꼴로) ---------- */
  var mctx = null, capCache = {};
  try { mctx = document.createElement('canvas').getContext('2d'); } catch (e) { mctx = null; }
  function cssFont(fam) {
    return (fam ? '"' + String(fam).replace(/"/g, '') + '", ' : '"Myriad Pro", ') + '"Pretendard", "Malgun Gothic", "Segoe UI", sans-serif';
  }
  function makeM(fam) {
    if (!mctx || !mctx.measureText) return H.BUILTIN;
    var css = cssFont(fam), cap = capCache[css];
    if (cap == null) {
      cap = 0.71;
      try { mctx.font = '500 100px ' + css; var m = mctx.measureText('H'); if (m.actualBoundingBoxAscent > 40 && m.actualBoundingBoxAscent < 90) cap = m.actualBoundingBoxAscent / 100; } catch (e) { }
      capCache[css] = cap;
    }
    return { cap: cap, measure: function (s, size, bold) { mctx.font = (bold ? '700 ' : '500 ') + '100px ' + css; return mctx.measureText(String(s)).width * size / 100; } };
  }
  function svgOpt(fam) { return { font: cssFont(fam).replace(/"/g, ''), wr: 500, wb: 700 }; }

  /* ---------- 상태줄 ---------- */
  var statusTimer = null;
  function status(msg, kind) {
    var e = $('status');
    e.textContent = msg || '';
    e.className = 'status' + (kind ? ' ' + kind : '');
    clearTimeout(statusTimer);
    if (kind === 'ok') statusTimer = setTimeout(function () { e.className = 'status'; }, 2500);
  }

  /* ---------- 일러스트에 시키기 (차례대로) ---------- */
  function parse(res) {
    try { return JSON.parse(decodeURIComponent(res)); }
    catch (e) { return { ok: false, msg: res === 'EvalScript error.' ? '스크립트 오류가 났어요. 일러스트레이터를 다시 시작해 주세요' : String(res || '응답이 없어요') }; }
  }
  function evalJ(fn, arg, cb) {
    CEP.evalScript(fn + '(' + (arg === undefined ? '' : JSON.stringify(String(arg))) + ')', function (res) { cb(parse(res)); });
  }
  function enc(obj) {
    return encodeURIComponent(JSON.stringify(obj, function (k, v) { return typeof v === 'number' ? Math.round(v * 1000) / 1000 : v; }));
  }
  var tasks = [], busy = false, busyTimer = null;
  function setBusy(on) {
    if (on) { if (!busyTimer && !document.body.classList.contains('busy')) busyTimer = setTimeout(function () { busyTimer = null; document.body.classList.add('busy'); }, 180); }
    else { clearTimeout(busyTimer); busyTimer = null; document.body.classList.remove('busy'); }
  }
  function enqueue(key, quiet, task) {
    if (key) tasks = tasks.filter(function (t) { return t.key !== key; });
    tasks.push({ key: key, quiet: quiet, task: task });
    pump();
  }
  function pump() {
    document.body.setAttribute('data-jobs', String(tasks.length + (busy ? 1 : 0)));
    if (busy || !tasks.length) return;
    var t = tasks.shift();
    busy = true;
    if (!t.quiet) setBusy(true);
    var finished = false;
    function done() {
      if (finished) return;
      finished = true; busy = false;
      if (!tasks.some(function (x) { return !x.quiet; })) setBusy(false);
      pump();
    }
    try { t.task(done); } catch (e) { status('패널 오류: ' + e.message, 'err'); done(); }
  }

  /* ---------- 테마 색 (썸네일이 패널 색으로 그려지게) ---------- */
  function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
  function toHex(c) {
    if (/^#[0-9a-f]{6}$/i.test(c)) return c;
    var m = /rgba?\((\d+)[,\s]+(\d+)[,\s]+(\d+)/.exec(c);
    if (!m) return '#888888';
    return '#' + [m[1], m[2], m[3]].map(function (v) { var h = Number(v).toString(16); return h.length < 2 ? '0' + h : h; }).join('');
  }
  var TH = null;
  function readTheme() { TH = { fg: toHex(cssVar('--fg')), tile: toHex(cssVar('--c3')), on: toHex(cssVar('--tile-on')), onInk: toHex(cssVar('--tile-on-ink')) }; }

  /* ---------- 미리보기 · 썸네일 ---------- */
  function renderStage() {
    var st = cur(), ovS = sampleOv(st.kind), stage = $('stage');
    // 고른 레벨 묶음이 미리보기(3개)보다 길면 셋째 줄은 맨 위가 아니다 → RF 로 적지 않는다 (값은 그 묶음의 아래 세 줄 그대로)
    if (st.kind === 'level' && valMode('level') === 'one' && bound.level.res.n > 3) st.rf = false;
    var sc = H.sample(st, makeM(st.font), { ov: ovS });
    var bg = st.paper || (H.lum(st.ink) > 0.55 ? '#20242B' : '#FFFFFF');
    if (st.paper && Math.abs(H.lum(st.paper) - H.lum(st.ink)) < 0.08) bg = H.lum(st.ink) > 0.5 ? '#20242B' : '#FFFFFF';   // 종이색 = 잉크색이면 안 보이니까
    stage.style.background = bg;
    var o = svgOpt(st.font), w = stage.clientWidth || 250, h = stage.clientHeight || 112;
    o.pad = st.size * H.PT * 0.42; o.box = [w, h]; o.M = makeM(st.font);
    stage.innerHTML = H.toSVG(sc.items, o);
  }
  // 기호 하나를 정해진 크기 창 가운데에 (칸마다 배율이 같게)
  function thumbSVG(kind, over, on, vw, vh) {
    var st = cur(kind), M = makeM(st.font);
    st.ink = on ? TH.onInk : TH.fg; st.paper = on ? TH.on : TH.tile; st.size = 7; st.sw = 0.62; st.lw = 80; st.lc = 'ink';
    var sc = over && over.dim !== undefined ? H.dimThumb(st, over.dim, M) : H.thumb(st, over, M), b = H.bounds(sc.items, M), S7 = 7 * H.PT, W = vw * S7, Hh = vh * S7;
    var cx = b.x + b.w / 2, cy = b.y + b.h / 2;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + [cx - W / 2, cy - Hh / 2, W, Hh].map(function (v) { return v.toFixed(2); }).join(' ') + '" preserveAspectRatio="xMidYMid meet">' + H.itemsSVG(sc.items, svgOpt(st.font)) + '</svg>';
  }
  function fillThumbs(box, list, kind, key, vw, vh, overOf, nameEl) {
    var val = S[kind][key], html = '';
    list.forEach(function (it) {
      var on = it.id === val;
      html += '<button class="tile' + (on ? ' on' : '') + '" data-v="' + it.id + '" title="' + it.name + '">' + thumbSVG(kind, overOf(it), on, vw, vh) + '</button>';
    });
    box.innerHTML = html;
    if (nameEl) nameEl.textContent = H.byId(list, val).name;
  }
  function renderThumbs() {
    if (!TH) readTheme();
    if (S.tab === 'grid') {
      var shape = H.byId(H.GRID_SHAPES, S.grid.shape), closed = !!shape.closed;
      fillThumbs($('gShapes'), H.GRID_SHAPES, 'grid', 'shape', 2.45, 2.2, function (it) { return { shape: it.id }; }, $('gShapeName'));
      fillThumbs($('gFinishes'), H.GRID_FINISHES, 'grid', 'finish', 2.05, 1.95, function (it) { return { finish: it.id, shape: closed ? shape.id : 'circle' }; }, $('gFinishName'));
      $('gFinishes').classList.toggle('off', !closed);
      $('gFinishHint').textContent = closed ? '' : shape.name + ' 모양은 표현 없이 선과 글자로만 그려요';
      if (!closed) $('gFinishName').textContent = '';
      fillThumbs($('gDims'), H.GRID_DIMS, 'grid', 'dim', 3.25, 1.5, function (it) { return { dim: it.id }; }, $('gDimName'));
    } else {
      fillThumbs($('lHeads'), H.LEVEL_HEADS, 'level', 'head', 3.05, 2.0, function (it) { return { head: it.id }; }, $('lHeadName'));
    }
    renderLooks();
  }
  // 추천 조합: 그 조합의 색으로 그린 작은 종이
  function renderLooks() {
    var kind = S.tab, html = '';
    H.LOOKS.forEach(function (lk) {
      var st = cur(kind), k, M = makeM(st.font);
      for (k in lk.common) st[k] = lk.common[k];
      for (k in lk[kind]) st[k] = lk[kind][k];
      st.size = 7; st.sw = 0.62; st.ts = 100;
      var sc = H.sample(st, M, kind === 'grid' ? { n: 2, len: 0.7 * 7 * H.PT, dim: false, turn: false } : { n: 1, len: 1.5 * 7 * H.PT }), b = H.bounds(sc.items, M), S7 = 7 * H.PT;
      var W = (kind === 'grid' ? 4.7 : 4.9) * S7, Hh = W * 40 / 78, cx = b.x + b.w / 2, cy = b.y + b.h / 2;
      html += '<button class="look" data-v="' + lk.id + '" title="' + lk.name + ' — 모양·선·색을 한 번에"><span class="card" style="background:' + st.paper + '">' +
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + [cx - W / 2, cy - Hh / 2, W, Hh].map(function (v) { return v.toFixed(2); }).join(' ') + '" preserveAspectRatio="xMidYMid meet">' +
        H.itemsSVG(sc.items, svgOpt(st.font)) + '</svg></span><span class="nm">' + lk.name + '</span></button>';
    });
    $('looks').innerHTML = html;
  }
  function applyLook(id) {
    var lk = H.byId(H.LOOKS, id), k, keys = [];
    for (k in lk.common) { S.common[k] = lk.common[k]; keys.push(k); }
    for (k in lk[S.tab]) { S[S.tab][k] = lk[S.tab][k]; keys.push(k); }
    save();
    renderAll();
    if (editing()) { keys.forEach(function (key) { pendingKeys[key] = 1; }); enqueue('edit', false, editTask); }
    status(lk.name + ' 조합을 골랐어요', 'ok');
  }

  /* ---------- 컨트롤 그리기 ---------- */
  var SLIDERS = {
    size: { lab: '기호 크기', min: 3, max: 20, step: 0.5, unit: 'mm', dec: 1 },
    sw: { lab: '선 굵기', min: 0.1, max: 3, step: 0.05, unit: 'pt', dec: 2 },
    ts: { lab: '글자 크기', min: 60, max: 160, step: 5, unit: '%', dec: 0 },
    len: { lab: '길이', min: 0, max: 300, step: 1, unit: 'mm', dec: 0 },
    lw: { lab: '굵기', min: 30, max: 150, step: 5, unit: '%', dec: 0 },
    ds: { lab: '무늬 간격', min: 50, max: 250, step: 5, unit: '%', dec: 0 },
    gap: { lab: '띄우기', min: 0, max: 10, step: 0.5, unit: 'mm', dec: 1 },
    dgap: { lab: '기호에서', min: 0, max: 30, step: 0.5, unit: 'mm', dec: 1 }
  };
  var SCALES = [50, 100, 200, 300, 500, 600];
  var FMTS = [{ v: 'mm', t: '+3,600' }, { v: 'm', t: '+3.6m' }, { v: 'elmm', t: 'EL +3,600' }, { v: 'elm', t: 'EL +3.600' }];
  var ROUNDS = [1, 10, 50, 100];
  var DFMTS = [{ v: 'c', t: '8,400' }, { v: 'n', t: '8400' }, { v: 'm', t: '8.4m' }, { v: 'u', t: '8.4' }];
  var NMS = [{ v: 'FL', t: '1FL' }, { v: 'F', t: '1F' }, { v: 'L', t: 'L1' }, { v: 'KR', t: '1층' }, { v: '', t: '없음' }];
  var INKS = ['#1A1A1A', '#4D5560', '#1E3A5F', '#B4232A', '#FFFFFF'];
  var ACCENTS = ['#E8452C', '#F5A623', '#2F7DF6', '#11A683', '#8B5CF6', '#1A1A1A'];
  var PAPERS = ['#FFFFFF', ''];
  var FONT_CANDS = [
    { fam: 'Pretendard', ps: ['Pretendard-Regular', 'Pretendard-Medium'] },
    { fam: 'SUIT', ps: ['SUIT-Regular', 'SUIT-Medium'] },
    { fam: 'Noto Sans KR', ps: ['NotoSansKR-Regular', 'NotoSansKR-Medium'] },
    { fam: 'Noto Sans CJK KR', ps: ['NotoSansCJKkr-Regular'] },
    { fam: 'Inter', ps: ['Inter-Regular'] },
    { fam: 'Helvetica Neue', ps: ['HelveticaNeue'] },
    { fam: 'Futura', ps: ['Futura-Medium'] },
    { fam: 'Bahnschrift', ps: ['Bahnschrift'] },
    { fam: 'Roboto', ps: ['Roboto-Regular'] },
    { fam: 'Montserrat', ps: ['Montserrat-Regular'] },
    { fam: 'Arial', ps: ['ArialMT'] },
    { fam: 'Malgun Gothic', ps: ['MalgunGothic'] }
  ];
  var fontsHere = ['Pretendard', 'Arial'];

  function fmtNum(v, dec) { var s = Number(v).toFixed(dec); return dec ? s.replace(/\.?0+$/, '') : s; }
  function buildSliders() {
    all('.srow[data-s]').forEach(function (row) {
      var k = row.getAttribute('data-s'), sp = SLIDERS[k];
      row.innerHTML = '<span class="lab">' + sp.lab + '</span><button class="nudge" data-d="-1" title="조금 줄이기 (Shift: 크게)">−</button>' +
        '<input type="range" min="' + sp.min + '" max="' + sp.max + '" step="' + sp.step + '">' +
        '<button class="nudge" data-d="1" title="조금 늘리기 (Shift: 크게)">+</button><input class="num" spellcheck="false" title="숫자를 직접 적어도 돼요"><span class="unit">' + sp.unit + '</span>';
      var range = row.querySelector('input[type=range]'), num = row.querySelector('.num');
      range.addEventListener('input', function () { setKey(k, Number(range.value), { live: true }); });
      range.addEventListener('change', function () { setKey(k, Number(range.value)); });
      num.addEventListener('change', function () { var v = parseFloat(String(num.value).replace(',', '.')); if (isNaN(v)) { renderControls(); return; } setKey(k, v); });
      num.addEventListener('keydown', function (e) { if (e.key === 'Enter') num.blur(); });
      all('.nudge', row).forEach(function (b) {
        b.addEventListener('click', function (e) { setKey(k, Math.round((Number(get(k)) + Number(b.getAttribute('data-d')) * sp.step * (e.shiftKey ? 10 : 1)) * 1000) / 1000); });
      });
    });
  }
  function chipHTML(list, valOf, textOf, cur) {
    return list.map(function (it) { var v = valOf(it); return '<button class="chip' + (String(v) === String(cur) ? ' on' : '') + '" data-v="' + v + '">' + textOf(it) + '</button>'; }).join('');
  }
  function segMark(id, val) { all('button', $(id)).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-v') === String(val)); }); }
  function checkMark(id, on) { $(id).setAttribute('data-on', on ? '1' : '0'); }
  function swatches(boxId, list, curVal, key) {
    var box = $(boxId), lab = box.querySelector('.lab'), html = '', found = false;
    list.forEach(function (c) {
      var on = String(c).toUpperCase() === String(curVal).toUpperCase();
      if (on) found = true;
      if (c === '') html += '<button class="sw none' + (on ? ' on' : '') + '" data-v="" title="바탕 없음 (뒤가 비쳐 보임)" style="--mark:' + TH.fg + '"></button>';
      else html += '<button class="sw' + (on ? ' on' : '') + '" data-v="' + c + '" title="' + c + '" style="background:' + c + ';--mark:' + (H.lum(c) > 0.45 ? '#111' : '#fff') + '"></button>';
    });
    if (!found && curVal) html += '<button class="sw on" data-v="' + curVal + '" title="' + curVal + '" style="background:' + curVal + ';--mark:' + (H.lum(curVal) > 0.45 ? '#111' : '#fff') + '"></button>';
    html += '<button class="sw pick" data-pick="' + key + '" title="다른 색 고르기"></button>';
    box.innerHTML = '';
    box.appendChild(lab);
    box.insertAdjacentHTML('beforeend', html);
  }
  function linePatternSeg() {
    var pats = { center: '9 2 1.6 2', solid: '', dash: '4.5 2.5', dot: '0.01 3', none: null };
    $('lp').innerHTML = H.LINE_PATTERNS.map(function (p) {
      var d = pats[p.id], inner = d === null ? '<path d="M9 5h12" stroke="currentColor" stroke-width="1.2" opacity=".35" stroke-dasharray="1 2"/><path d="M11 1.5l8 7" stroke="currentColor" stroke-width="1.2"/>'
        : '<path d="M1 5h28" stroke="currentColor" stroke-width="' + (p.id === 'dot' ? 1.8 : 1.3) + '"' + (d ? ' stroke-dasharray="' + d + '"' : '') + (p.id === 'dot' ? ' stroke-linecap="round"' : '') + '/>';
      return '<button data-v="' + p.id + '" title="' + p.name + '"><svg viewBox="0 0 30 10">' + inner + '</svg></button>';
    }).join('');
  }
  function renderControls() {
    var st = cur(), k;
    document.body.setAttribute('data-tab', S.tab);
    all('#tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === S.tab); });
    all('.srow[data-s]').forEach(function (row) {
      k = row.getAttribute('data-s');
      var sp = SLIDERS[k], v = st[k], range = row.querySelector('input[type=range]'), num = row.querySelector('.num');
      if (v === undefined) return;
      range.value = Math.max(sp.min, Math.min(sp.max, v));
      if (document.activeElement !== num) num.value = fmtNum(v, sp.dec);
    });
    segMark('lp', st.lp); segMark('lc', st.lc);
    checkMark('flip', st.flip); checkMark('align', st.align);
    if (S.tab === 'grid') {
      segMark('gNum', st.num);
      $('gStart').querySelector('output').textContent = st.start;
      checkMark('gSwap', st.swap); checkMark('gRev', st.rev); checkMark('both', st.both); checkMark('turn', st.turn);
      $('lineHint').textContent = st.lp === 'none' ? '축선 없음: 기존 선에 붙일 때 원래 선을 그대로 둬요' : '기존 선에 붙이면 길이 대신 그 선을 그대로 따라 그려요';
      $('gDimOpts').classList.toggle('gone', st.dim === 'none');
      $('gScale').innerHTML = chipHTML(SCALES, function (v) { return v; }, function (v) { return '1/' + v; }, st.scale);
      if (document.activeElement !== $('gScaleNum')) $('gScaleNum').value = st.scale;
      $('gFmt').innerHTML = chipHTML(DFMTS, function (o) { return o.v; }, function (o) { return o.t; }, st.dfmt);
      $('gRound').innerHTML = chipHTML(ROUNDS, function (v) { return v; }, function (v) { return v + ' mm'; }, st.dround);
      checkMark('dtot', st.dtot);
      $('gEstNote').textContent = '1/' + st.scale + ' · ' + st.dround + ' mm';
    } else {
      segMark('lLayout', st.layout); segMark('lContent', st.content); segMark('lHc', st.hc);
      $('lScale').innerHTML = chipHTML(SCALES, function (v) { return v; }, function (v) { return '1/' + v; }, st.scale);
      if (document.activeElement !== $('lScaleNum')) $('lScaleNum').value = st.scale;
      $('lFmt').innerHTML = chipHTML(FMTS, function (o) { return o.v; }, function (o) { return o.t; }, st.fmt);
      $('lRound').innerHTML = chipHTML(ROUNDS, function (v) { return v; }, function (v) { return v + ' mm'; }, st.round);
      $('lNm').innerHTML = chipHTML(NMS, function (o) { return o.v; }, function (o) { return o.t; }, st.nm);
      $('lBase').querySelector('output').textContent = st.base;
      checkMark('lGl', st.gl); checkMark('lRf', st.rf);
      $('lEstNote').textContent = '1/' + st.scale + ' · ' + st.round + ' mm';
      $('lineHint').textContent = (st.align ? '점은 높이만 읽어요 — 좌우는 첫 점에 맞추고 선 길이는 모두 같아요' : '기호는 찍은 자리 그대로, 선 길이는 모두 같아요') + ' · 기존 선에 붙이면 그 선을 그대로 따라요';
    }
    swatches('swInk', INKS, st.ink, 'ink');
    swatches('swAccent', ACCENTS, st.accent, 'accent');
    swatches('swPaper', PAPERS, st.paper, 'paper');
    var fl = fontsHere.slice();
    if (st.font && fl.indexOf(st.font) < 0) fl.unshift(st.font);
    $('fonts').innerHTML = fl.map(function (f) { return '<button class="chip' + (f === st.font ? ' on' : '') + '" data-v="' + escH(f) + '" style="font-family:' + escH(cssFont(f).replace(/"/g, "'")) + '">' + escH(f) + '</button>'; }).join('') +
      '<button class="chip' + (st.font === '' ? ' on' : '') + '" data-v="" title="문서의 기본 글꼴 그대로">문서 기본</button>';
    all('.fold').forEach(function (f) { f.classList.toggle('open', !!S.folds[f.id]); });
  }
  function renderAll() { renderControls(); renderThumbs(); renderStage(); renderSel(); renderVals(); }

  /* ---------- 값 바꾸기 ---------- */
  var pendingKeys = {};
  function setKey(k, v, opt) {
    opt = opt || {};
    if (H.LIMITS[k] && typeof v === 'number') v = Math.max(H.LIMITS[k][0], Math.min(H.LIMITS[k][1], v));
    if (isCommon(k)) S.common[k] = v; else S[S.tab][k] = v;
    if (k === 'dim' && v !== 'none') S.memo.dim = v;
    save();
    if (opt.live) { renderStage(); all('.srow[data-s="' + k + '"] .num').forEach(function (n) { n.value = fmtNum(v, SLIDERS[k].dec); }); return; }
    renderControls(); renderThumbs(); renderStage(); renderVals();
    if (editing()) { pendingKeys[k] = 1; enqueue('edit', false, editTask); }
  }
  function bindSeg(id, key) { $(id).addEventListener('click', function (e) { var b = e.target.closest('button'); if (b && has(b.dataset, 'v')) setKey(key, b.dataset.v); }); }
  function bindChips(id, key, num) { $(id).addEventListener('click', function (e) { var b = e.target.closest('button'); if (b && has(b.dataset, 'v')) setKey(key, num ? Number(b.dataset.v) : b.dataset.v); }); }
  function bindCheck(id, key) { $(id).addEventListener('click', function () { setKey(key, !get(key)); }); }
  function bindStepper(id, key) { $(id).addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) setKey(key, Math.round(Number(get(key)) + Number(b.dataset.d))); }); }
  function bindTiles(id, key) { $(id).addEventListener('click', function (e) { var b = e.target.closest('.tile'); if (b) setKey(key, b.dataset.v); }); }

  /* ---------- 선택 읽기 ---------- */
  var sel = null, editSig = '', prefer = 'auto', lastPeek = 0, adoptNext = false, penArmed = false;
  function editing() { return !!(sel && sel.doc && sel.marks > 0); }
  function srcMode() {
    if (!sel || !sel.doc || sel.marks > 0 || !sel.paths) return null;
    var mode = prefer === 'points' || prefer === 'lines' ? prefer : (sel.paths === 1 ? 'points' : 'lines');
    if (mode === 'lines' && !sel.lines) mode = 'points';
    return mode;
  }
  function renderSel() {
    var t = '', sub = '', bar = $('selbar'), make = $('btnMake'), pf = $('btnPrefer'), word = S.tab === 'grid' ? '축열' : '레벨';
    bar.classList.remove('edit');
    pf.classList.remove('show');
    make.disabled = true;
    make.textContent = word + ' 만들기';
    if (!CEP.available) { t = '일러스트레이터 안에서 열어 주세요'; }
    else if (!sel) { t = '선택을 읽는 중…'; }
    else if (!sel.doc) { t = '문서를 열어 주세요'; }
    else if (sel.marks > 0) {
      bar.classList.add('edit');
      var parts = [];
      if (sel.grid) parts.push('축열 ' + sel.grid + '묶음');
      if (sel.level) parts.push('레벨 ' + sel.level + '묶음');
      t = parts.join(' · ') + ' 고치는 중';
      sub = (S.tab === 'grid' ? sel.grid : sel.level) ? '고르면 바로 바뀌어요' : '이 탭에서는 크기·색·글꼴만 바뀌어요';
      make.textContent = '다시 그리기';
      make.disabled = false;
    } else {
      var mode = srcMode();
      if (!mode) { t = '기호 넣을 자리를 정해 주세요'; sub = '[점 찍기]로 자리마다 클릭 · 또는 기존 선을 선택'; }
      else {
        var n = mode === 'points' ? sel.pts : sel.lines;
        t = (mode === 'points' ? '점 ' : '선 ') + n + '개';
        sub = mode === 'points' ? word + ' ' + n + '개를 만들 수 있어요' : '선 끝마다 ' + word + ' 기호를 붙여요';
        make.textContent = word + ' ' + n + '개 만들기';
        make.disabled = n < 1;
        if (mode === 'points' && sel.lines >= 1 && sel.pts === sel.paths * 2) { pf.textContent = '선으로 보기'; pf.title = '패스마다 선 하나로 보고 끝에 기호를 붙여요'; pf.classList.add('show'); }
        else if (mode === 'lines' && sel.pts > 0) { pf.textContent = '점으로 보기'; pf.title = '패스의 점마다 기호를 하나씩 놓아요'; pf.classList.add('show'); }
      }
    }
    $('selText').textContent = t;
    $('selSub').textContent = sub;
  }
  function loadFrom(stateEnc) {
    var state;
    try { state = JSON.parse(decodeURIComponent(stateEnc)); } catch (e) { return; }
    if (!state || !state.st) return;
    var st = H.normalize(state.st), parts = split(st), k;
    S.tab = st.kind;
    for (k in parts[0]) if (has(S.common, k)) S.common[k] = parts[0][k];
    for (k in parts[1]) if (has(S[st.kind], k)) S[st.kind][k] = parts[1][k];
    save();
  }
  // deep = 고른 묶음의 기준점 · 글자도 다시 읽는다 (도면에서 점을 옮겼거나 숫자를 손으로 고쳤을 수 있을 때 — 패널로 돌아온 순간)
  function refreshSel(deep) {
    if (!CEP.available) { renderSel(); renderVals(); return; }
    enqueue('peek', true, function (done) {
      evalJ('hyMark_peek', undefined, function (r) {
        lastPeek = Date.now();
        if (!r.ok) { done(); return; }
        var before = sel ? [sel.doc, sel.marks, sel.paths, sel.pts, sel.lines].join() : '';
        sel = r;
        if ([sel.doc, sel.marks, sel.paths, sel.pts, sel.lines].join() !== before) prefer = 'auto';
        var sig = sel.marks ? sel.marks + '|' + sel.first : '', fresh = sig !== editSig && !adoptNext;
        if (sig && fresh) { loadFrom(sel.first); renderAll(); }
        if (!sig) { bound = { grid: null, level: null }; multiBase = { grid: '', level: '' }; pendingOps = []; }
        else if (fresh) { bound = { grid: null, level: null }; multiBase = { grid: '', level: '' }; pendingOps = []; readVals(); }
        else if (deep && Date.now() - lastRead > 600) readVals();
        editSig = sig; adoptNext = false;
        renderSel(); renderVals();
        done();
      });
    });
  }
  function maybeRefresh() { if (!busy && !tasks.length && Date.now() - lastPeek > 1200) refreshSel(); }

  /* ---------- 만들기 · 고치기 ---------- */
  var CUT_MSG = '만들었지만 묶음이 너무 커서 설정을 다 적지 못했어요 — 나중에 고치려면 더 적게 나눠 만들어 주세요';
  var LOST_MSG = '적은 값을 넣을 묶음이 골라져 있지 않아요 — 묶음을 다시 고르고 적어 주세요';
  function newId() { return Date.now().toString(36) + Math.floor(Math.random() * 1679616).toString(36); }
  // id 는 다시 그려도 그대로 둔다 — 값을 이어서 적는 동안 '어느 묶음의 칸'인지가 바뀌지 않게
  function groupOf(st, res, mode, ov, id) {
    var word = st.kind === 'grid' ? '축열' : '레벨', state = { v: 1, st: st, mode: mode, auto: res.auto, ov: ov || {}, skel: res.skel.data };
    return { kind: st.kind, id: id || newId(), name: 'hy ' + word + ' (' + res.n + ')', items: res.items, names: res.names, skel: res.skel,
      stateEnc: encodeURIComponent(JSON.stringify(state)), font: st.font };
  }
  function makeTask(done) {
    evalJ('hyMark_source', prefer, function (r) {
      if (!r.ok) { status(r.msg, 'err'); done(); return; }
      var st = cur(), kind = st.kind, src = r.mode === 'lines' ? { mode: 'lines', lines: r.lines } : { mode: 'points', pts: r.pts };
      var ov = pendOv(kind), res = H.build(st, src, makeM(st.font), ov);          // 미리 적어 둔 값(모두 같게 · 차례로)을 처음부터 넣는다
      if (!res.n) { status('기호를 놓을 자리가 없어요', 'err'); done(); return; }
      var G = groupOf(st, res, src.mode, ov);
      var payload = { groups: [G], srcMode: r.mode, removeSrc: r.mode === 'points' || st.lp !== 'none' };
      evalJ('hyMark_apply', enc(payload), function (r2) {
        if (!r2.ok) status(r2.msg, 'err');
        else if (r2.cut) status(CUT_MSG, 'err');
        else if (st.kind === 'level' && src.mode === 'points' && st.align && res.snap > Math.max(1, 0.2 * st.size) * H.PT) {
          // 좌우가 눈에 띄게 다른 점을 한 줄로 당겼으면 알려 준다 — 일부러 다르게 찍은 것일 수 있다 (맞춤은 만든 뒤에도 끌 수 있음)
          status('레벨 ' + res.n + '개 · 좌우는 첫 점에 맞췄어요 — 찍은 자리 그대로 두려면 한 줄로 맞춤을 끄세요', 'tip');
        } else status((st.kind === 'grid' ? '축열 ' : '레벨 ') + res.n + '개를 만들었어요', 'ok');
        if (r2.ok) {
          // 만든 묶음이 고른 채로 남으니 그 칸을 바로 보여 준다 (선택을 다시 읽을 때까지 기다리지 않고)
          if (pend[kind].base) noteRecent(kind, pend[kind].base);
          pend[kind] = { base: '', seq: [] };
          bound = { grid: null, level: null };
          bound[kind] = { id: G.id, count: 1, st: st, mode: res.skel.mode, ov: ov, res: res,
            src: res.skel.mode === 'lines' ? { mode: 'lines', lines: res.skel.data } : { mode: 'points', pts: res.skel.data } };
          sel = { ok: true, doc: 1, marks: 1, grid: kind === 'grid' ? 1 : 0, level: kind === 'level' ? 1 : 0, first: G.stateEnc };
          editSig = '1|' + G.stateEnc;
          lastRead = Date.now();
          renderSel(); renderVals(); renderStage();
        }
        adoptNext = true;
        // [점 찍기]로 펜을 들었으면 선택 도구로 돌아간다 — 고른 채 남은 기호를 펜이 건드리지 않게, 바로 끌어 옮길 수 있게
        if (r2.ok && penArmed) { penArmed = false; evalJ('hyMark_tool', 'select', function () { done(); refreshSel(); }); return; }
        done();
        refreshSel();
      });
    });
  }
  function stateOf(g) {
    var state;
    try { state = JSON.parse(decodeURIComponent(g.state)); } catch (e) { state = null; }
    return state && state.st ? state : null;
  }
  // 묶음의 지금 자리: 기준 패스, 지워졌으면 만들 때 자리 + 옮긴 만큼
  function srcOf(g, state) {
    var mode = g.mode || state.mode || 'points', skel = g.skel;
    if (!skel) {
      var dx = g.cur[0] - g.pos[0], dy = g.cur[1] - g.pos[1];
      mode = state.mode || 'points';
      skel = (state.skel || []).map(function (p) { return mode === 'lines' ? [p[0] + dx, p[1] - dy, p[2] + dx, p[3] - dy] : [p[0] + dx, p[1] - dy]; });
    }
    if (!skel.length) return null;
    return { mode: mode, src: mode === 'lines' ? { mode: 'lines', lines: skel } : { mode: 'points', pts: skel } };
  }
  // 고른 묶음을 다시 그린다. 모양 · 크기처럼 설정을 바꿨으면(또는 [다시 그리기]) 고른 묶음 모두,
  // 값만 적었으면 그 값이 들어간 묶음만 — 값을 이어 적는 동안 상관없는 묶음까지 매번 다시 그리지 않게
  function editTask(done) {
    var keys = pendingKeys, ops = pendingOps, k0, all = redrawAll;
    pendingKeys = {}; pendingOps = []; redrawAll = false;
    for (k0 in keys) if (has(keys, k0)) all = true;
    evalJ('hyMark_read', 'keep', function (r) {
      if (!r.ok) { status(r.msg, 'err'); done(); readVals(); return; }
      if (!r.groups.length) { if (ops.length) status(LOST_MSG, 'err'); done(); refreshSel(); return; }
      var groups = [], lost = 0, binds = [], put = 0;
      r.groups.forEach(function (g, i) {
        var state = stateOf(g), k;
        if (!state) { lost++; return; }
        var st = H.normalize(state.st), kind = st.kind;
        for (k in keys) { if (isCommon(k)) st[k] = S.common[k]; else if (kind === S.tab && has(S[kind], k)) st[k] = S[kind][k]; }
        st = H.normalize(st);
        var so = srcOf(g, state);
        if (!so) { lost++; return; }
        var ov = H.overridesFrom(kind, state.auto || [], g.texts || [], state.ov);
        // 패널에서 적은 값 (문서에서 손으로 고친 글자보다 나중이니 이쪽이 이긴다)
        var mine = ops.filter(function (o) { return o.kind === kind && (o.id == null || o.id === g.id); });
        if (mine.length) { H.applyValueOps(kind, ov, mine); put++; }
        var res = H.build(st, so.src, makeM(st.font), ov);
        binds.push({ id: g.id, kind: kind, st: st, mode: so.mode, src: so.src, ov: ov, res: res });
        if (!all && !mine.length) return;
        var G = groupOf(st, res, so.mode, ov, g.id);
        G.replace = i; G.oldId = g.id;
        groups.push(G);
      });
      if (!groups.length) {
        if (all) status('다시 그릴 수 있는 기호가 없어요', 'err');
        else { rebind(binds); renderVals(); renderStage(); if (ops.length) status(LOST_MSG, 'err'); }          // 값을 적은 묶음이 더는 골라져 있지 않다 → 지금 고른 묶음 그대로 보여 준다
        sayAfterEdit = '';
        done();
        return;
      }
      // tok: 방금 읽은 그 묶음을 고친다 — 그사이 도면을 눌러 선택이 풀렸어도 (적던 값이 사라지지 않게)
      evalJ('hyMark_apply', enc({ groups: groups, removeSrc: false, tok: r.tok || 0 }), function (r2) {
        if (!r2.ok) status(r2.msg, 'err');
        else if (r2.cut) status(CUT_MSG, 'err');
        else if (lost) status(groups.length + '묶음 고침 · ' + lost + '묶음은 못 읽음', 'err');
        else if (ops.length && !put) status(LOST_MSG, 'err');
        else status(sayAfterEdit || '', sayAfterEdit ? 'ok' : '');
        sayAfterEdit = '';
        adoptNext = true;
        if (r2.ok) { rebind(binds); lastRead = Date.now(); renderVals(); renderStage(); }
        done();
        if (r2.ok) refreshSel(); else { refreshSel(); readVals(); }          // 못 고쳤으면 문서에 있는 대로 다시 읽어 칸을 맞춘다
      });
    });
  }

  /* ---------- 값 적기 (간격 · 층고) ----------
     일러스트 도면은 치수가 딱 떨어지지 않아서 숫자는 대부분 적어 넣는다. 그래서:
       ① 모두 같게 — 값 하나로 모든 칸을 채우고
       ② 다른 칸만 따로 적는다 (그 칸만 바뀜. 레벨은 층고를 ±0 부터 차례로 더한 값이 된다)
       ③ 아무것도 안 적은 칸만 도면에서 잰 거리 × 축척으로 어림(≈)
     만들기 전에는 ① 만 미리 적어 둘 수 있고(만들 때 들어감), 만든 뒤에는 고른 묶음의 칸이 나온다.
     적은 값은 묶음에 같이 적혀서(손댄 글자 기록 ov 의 s · h · B0 · B1) 크기 · 모양을 바꿔도, 파일을 다시 열어도 남는다. */
  var bound = { grid: null, level: null };              // 고른 묶음 (종류마다 첫 묶음): { id, count, st, mode, src, ov, res }
  var pend = { grid: { base: '', seq: [] }, level: { base: '', seq: [] } };      // 만들기 전에 적어 둔 값
  var multiBase = { grid: '', level: '' };              // 여러 묶음을 골랐을 때 방금 넣은 값 (칸에 보여 주기만)
  var pendingOps = [], lastRead = 0, drawing = false, redrawAll = false;
  var PRESETS = { grid: [8400, 6000, 7200, 9000], level: [3600, 3000, 3300, 4200, 4500] };
  function valMode(kind) {
    if (!editing()) return 'pre';
    var n = sel[kind] || 0;
    if (!n) return 'other';
    if (n > 1) return 'multi';
    return bound[kind] ? 'one' : 'wait';
  }
  function plain(v) { return v >= 100 ? String(v) : v + 'mm'; }          // 칩 값(mm) → 적는 글자 (100 미만은 m 로 읽히지 않게 단위를 붙임)
  function noteRecent(kind, text) {
    var v = H.parseVal(text);
    if (v == null || v < 100 || v >= 1e6) return;
    v = Math.round(v);
    S.recent[kind] = [v].concat(S.recent[kind].filter(function (x) { return x !== v; })).slice(0, 4);
    save();
  }
  function chipVals(kind) {
    var out = S.recent[kind].slice(0, 3), i, pre = PRESETS[kind];
    for (i = 0; i < pre.length && out.length < 5; i++) if (out.indexOf(pre[i]) < 0) out.push(pre[i]);
    return out.sort(function (a, b) { return a - b; });
  }
  function pendOv(kind) {
    var p = pend[kind], ops = [];
    if (p.base) ops.push({ t: 'base', ser: 'all', text: p.base });
    p.seq.forEach(function (tx, i) { ops.push({ t: 'cell', k: i, text: tx }); });
    return H.applyValueOps(kind, {}, ops);
  }
  // 위 미리보기에 넣을 값: 만들기 전에는 적어 둔 값 그대로, 묶음 하나를 고쳤으면 그 묶음의 앞 칸 값(도면에 들어간 그대로)
  function sampleOv(kind) {
    var m = valMode(kind);
    if (m === 'pre') return pendOv(kind);
    if (m === 'multi') return multiBase[kind] ? { B0: { v: multiBase[kind] }, B1: { v: multiBase[kind] } } : null;
    if (m !== 'one') return null;
    var cells = bound[kind].res.spanInfo, ov = {}, n = 0;
    cells.forEach(function (c) {
      if (c.ser !== cells[0].ser || n >= 3) return;
      var tx = c.mm != null ? plain(c.mm) : c.text;
      ov[n++] = kind === 'grid' ? { s: tx } : { h: tx };
    });
    return n ? ov : null;
  }
  function rebuild(b) { b.res = H.build(b.st, b.src, makeM(b.st.font), b.ov); }
  function bindFrom(groups) {
    var nb = { grid: null, level: null }, counts = { grid: 0, level: 0 };
    groups.forEach(function (g) {
      var state = stateOf(g);
      if (!state) return;
      var st = H.normalize(state.st), kind = st.kind, so;
      counts[kind]++;
      if (nb[kind] || !(so = srcOf(g, state))) return;
      nb[kind] = { id: g.id, st: st, mode: so.mode, src: so.src, ov: H.overridesFrom(kind, state.auto || [], g.texts || [], state.ov) };
      rebuild(nb[kind]);
    });
    rebindDone(nb, counts);
  }
  function rebind(list) {
    var nb = { grid: null, level: null }, counts = { grid: 0, level: 0 };
    list.forEach(function (x) { counts[x.kind]++; if (!nb[x.kind]) nb[x.kind] = x; });
    rebindDone(nb, counts);
  }
  // 아직 문서에 안 넣은 값(다음 고치기를 기다리는 것)은 칸에 미리 보여 준다 — 이어서 적는 동안 앞 칸이 잠깐 옛 값으로 돌아가 보이지 않게
  function rebindDone(nb, counts) {
    ['grid', 'level'].forEach(function (kind) {
      var b = nb[kind];
      if (!b) return;
      b.count = counts[kind];
      var mine = pendingOps.filter(function (o) { return o.kind === kind && (o.id == null || o.id === b.id); });
      if (mine.length) { H.applyValueOps(kind, b.ov, mine); rebuild(b); }
    });
    bound = nb;
  }
  function readVals() {
    enqueue('vals', true, function (done) {
      evalJ('hyMark_read', undefined, function (r) {
        lastRead = Date.now();
        if (r.ok && editing()) { bindFrom(r.groups || []); renderVals(); renderStage(); }
        done();
      });
    });
  }
  function pushOps(kind, ops, say) {
    var mode = valMode(kind), b = bound[kind], id = mode === 'one' ? b.id : null;
    ops.forEach(function (o) { o.kind = kind; o.id = id; pendingOps.push(o); });
    if (mode === 'one') { H.applyValueOps(kind, b.ov, ops); rebuild(b); }          // 패널 칸은 기다리지 않고 바로
    if (say) sayAfterEdit = say;
    renderVals(); renderStage();
    enqueue('edit', false, editTask);
  }
  // 값을 적었는데 간격 숫자가 꺼져 있으면 켠다 (마지막에 쓰던 모양으로)
  function wakeDims(kind) {
    if (kind !== 'grid' || cur('grid').dim !== 'none') return false;
    setKey('dim', S.memo.dim || 'tick');
    return true;
  }

  function valsVM(kind) {
    var mode = valMode(kind), st = cur(kind), b = bound[kind], vm = { kind: kind, mode: mode, off: kind === 'grid' && st.dim === 'none', sers: [], marks: [], clear: 0, st: st };
    if (mode === 'one' && b.res.sums.length) {
      b.res.sums.forEach(function (sm) {
        vm.sers.push({ ser: sm.ser, base: sm.base, sum: sm, cells: vm.off ? [] : b.res.spanInfo.filter(function (c) { return c.ser === sm.ser; }) });
      });
      if (kind === 'level') vm.marks = b.res.marksInfo;
      b.res.spanInfo.forEach(function (c) { if (c.typed != null || c.hand != null) vm.clear++; });
      vm.marks.forEach(function (m) { if (m.handV) vm.clear++; });
      if (vm.off) vm.clear = 0;
    } else if (mode !== 'other') {
      vm.sers.push({ ser: 'all', base: mode === 'pre' ? pend[kind].base || null : mode === 'multi' ? multiBase[kind] || null : null, sum: null, cells: [] });
    }
    vm.sig = [kind, mode === 'wait' ? 'pre' : mode, vm.sers.map(function (x) { return x.ser + ':' + x.cells.length; }).join(','), vm.marks.length].join('|');
    return vm;
  }
  function valsHTML(vm) {
    var grid = vm.kind === 'grid', html = '';
    vm.sers.forEach(function (sv) {
      html += '<div class="vser" data-ser="' + sv.ser + '">';
      if (grid && sv.cells.length) html += '<div class="vhead"><span class="vname"></span><span class="vsum">합계 <b></b></span></div>';
      html += '<div class="vbase"><span class="lab">' + (grid ? '모두 같게' : '층고 모두') + '</span>' +
        '<input class="vin" data-role="base" data-ser="' + sv.ser + '" spellcheck="false" autocomplete="off" title="' +
        (grid ? '모든 간격을 이 값으로 채워요. 다른 칸만 아래에서 따로 고치면 돼요 (8400 · 8.4 둘 다 돼요)' : '층고가 모두 같을 때: ±0 부터 이만큼씩 더해 가요. 다른 층만 아래에서 따로 고치면 돼요') + '">' +
        '<span class="unit">' + (grid ? 'mm' : 'mm 씩') + '</span></div><div class="chips vchips" data-ser="' + sv.ser + '"></div>';
      if (grid && sv.cells.length) {
        html += '<div class="vcells">' + sv.cells.map(function (c) {
          return '<div class="vcell"><span class="cn"></span><input class="vin" data-role="cell" data-k="' + c.k + '" data-ser="' + sv.ser + '" spellcheck="false" autocomplete="off">' +
            '<button class="vdot" tabindex="-1" data-clear-k="' + c.k + '" title="이 칸에 따로 적은 값 지우기"></button></div>';
        }).join('') + '</div>';
      }
      if (!grid && vm.marks.length) {
        var rows = '', i;
        for (i = 0; i < vm.marks.length; i++) {          // 아래층부터 (화면에서는 CSS 가 뒤집어 위가 높은 층) — Tab 도 위층으로 간다
          rows += '<button class="mk" tabindex="-1" data-i="' + i + '"><b></b><i></i><span></span></button>';
          if (i + 1 < vm.marks.length) rows += '<div class="sp"><button class="vdot" tabindex="-1" data-clear-k="' + i + '" title="이 층에 따로 적은 층고 지우기"></button>' +
            '<input class="vin" data-role="cell" data-k="' + i + '" data-ser="0" spellcheck="false" autocomplete="off"></div>';
        }
        html += '<div class="ruler">' + rows + '</div>';
      }
      html += '</div>';
    });
    html += '<div class="vseq gone"></div><div class="vfoot"><button class="link gone" tabindex="-1" data-clear-all="1"></button><p class="hint"></p></div>';
    return html;
  }
  // 칸에 값 넣기. 지금 글자를 적고 있는 칸(포커스가 있고, 마지막으로 넣어 준 값에서 달라진 칸)은 건드리지 않는다
  function setIn(inp, val, ph) {
    var was = inp.getAttribute('data-was') || '';
    if (inp.value !== val && (document.activeElement !== inp || inp.value === was)) { inp.value = val; inp.removeAttribute('data-raw'); }
    inp.setAttribute('data-was', val);
    if (inp.getAttribute('placeholder') !== ph) inp.setAttribute('placeholder', ph);
  }
  function setText(node, text) { if (node && node.textContent !== text) node.textContent = text; }
  function patchVals(box, vm) {
    var grid = vm.kind === 'grid', st = vm.st, hint = '', seq = '', anyAuto = false;
    vm.sers.forEach(function (sv) {
      var blk = box.querySelector('.vser[data-ser="' + sv.ser + '"]');
      if (!blk) return;
      var baseMm = sv.base != null ? H.parseVal(sv.base) : null;
      setIn(blk.querySelector('input[data-role="base"]'), sv.base != null ? H.valText(sv.base) : '', grid ? '예: 8400' : '예: 3600');
      var chips = chipVals(vm.kind).map(function (v) {
        return '<button class="chip' + (baseMm === v ? ' on' : '') + '" tabindex="-1" data-base="' + v + '" data-ser="' + sv.ser + '" title="' + (baseMm === v ? '한 번 더 누르면 지워요' : '모두 ' + H.mmText(v) + ' 로') + '">' + H.mmText(v) + '</button>';
      }).join(''), cbox = blk.querySelector('.vchips');
      if (cbox.getAttribute('data-html') !== chips) { cbox.innerHTML = chips; cbox.setAttribute('data-html', chips); }
      if (grid && sv.cells.length) {
        setText(blk.querySelector('.vname'), '');
        blk.querySelector('.vname').innerHTML = escH(sv.cells[0].a) + ' → ' + escH(sv.cells[sv.cells.length - 1].b) + '<i> · ' + sv.cells.length + '칸</i>';
        setText(blk.querySelector('.vsum b'), H.mmText(sv.sum.mm) + (sv.sum.exact ? '' : ' ?'));
      }
      sv.cells.forEach(function (c) {
        var inp = blk.querySelector('input[data-role="cell"][data-k="' + c.k + '"]');
        if (!inp) return;
        var state = c.hand != null ? 'hand' : c.typed != null ? 'typed' : c.base != null ? 'base' : 'auto', cell = inp.parentNode;
        if (state === 'auto') anyAuto = true;
        setIn(inp, state === 'hand' ? c.hand : state === 'typed' ? H.valText(c.typed) : '', state === 'base' ? H.valText(c.base) : '≈ ' + H.mmText(c.autoMm));
        cell.className = (grid ? 'vcell ' : 'sp ') + state;
        if (grid) setText(cell.querySelector('.cn'), c.a + '–' + c.b);
        cell.setAttribute('title', state === 'hand' ? '도면에서 직접 고친 글자예요' : state === 'typed' ? '이 칸만 따로 적었어요' : state === 'base' ? '모두 같게 값 — 적으면 이 칸만 바뀌어요' : '도면에서 어림한 값 — 적으면 이 칸만 바뀌어요');
      });
    });
    all('.mk', box).forEach(function (row) {
      var m = vm.marks[Number(row.getAttribute('data-i'))];
      if (!m) return;
      setText(row.querySelector('b'), m.n || '·');
      setText(row.querySelector('span'), m.v);
      row.className = 'mk' + (m.base ? ' zero' : '') + (m.handV ? ' hand' : '');
      row.setAttribute('title', m.base ? '여기가 ±0 이에요' : '누르면 이 자리가 ±0 이 돼요' + (m.handV ? ' · 값은 도면에서 직접 고친 글자예요' : ''));
    });
    // 한 줄 안내
    var word = grid ? '간격' : '층고';
    if (vm.mode === 'other') hint = (grid ? '축열' : '레벨') + ' 묶음을 고르면 여기서 값을 적어요';
    else if (vm.off) hint = '간격 숫자가 꺼져 있어요 — 값을 적으면 켜져요';
    else if (vm.mode === 'pre' || vm.mode === 'wait') {
      var p = pend[vm.kind];
      if (p.seq.length) seq = '만들 때 차례로 <b>' + p.seq.map(function (t) { return escH(H.valText(t)); }).join(' · ') + '</b> <button class="link" data-clear-seq="1" title="차례로 넣을 값 지우기">지우기</button>';
      else if (!grid && p.base && H.parseVal(p.base) != null) {
        // 수열처럼: ±0 자리에서 층고만큼씩. 고른 점이 있으면 그 개수만큼 (다섯 개까지 보여 줌)
        var h = H.parseVal(p.base), mode0 = srcMode(), cnt = mode0 ? (mode0 === 'points' ? sel.pts : sel.lines) : 0, shown = cnt >= 2 ? Math.min(cnt, 5) : 4, terms = [], i0;
        var bi = cnt >= 2 ? Math.max(0, Math.min(cnt - 1, st.base - 1)) : Math.max(0, Math.min(shown - 1, st.base - 1));
        for (i0 = 0; i0 < shown; i0++) terms.push('<b>' + escH(H.fmtValue((i0 - bi) * h, st.fmt)) + '</b>');
        seq = terms.join(' → ') + (cnt >= 2 && cnt <= 5 ? '' : ' …');
      }
      hint = grid ? '만들 때 모든 간격에 넣어요 · 만든 뒤 칸마다 고쳐요' : '±0 부터 층고만큼씩 더해요 · 만든 뒤 층마다 고쳐요';
    } else if (vm.mode === 'multi') hint = '묶음 ' + sel[vm.kind] + '개의 모든 칸에 들어가요 · 칸마다 고치려면 하나만 골라 주세요';
    else if (!vm.sers.length || !vm.sers[0].cells.length) hint = (grid ? '축선' : '점') + '이 둘 이상이어야 ' + word + ' 칸이 생겨요';
    else if (anyAuto) hint = grid ? '≈ 는 도면에서 어림한 값 — 적으면 그 칸만 바뀌어요' : '≈ 는 도면에서 어림한 층고 — 적으면 위 레벨이 따라 올라가요';
    else hint = grid ? '띄어서 여러 값을 적으면 차례로 들어가요 (6000 8400*2)' : '층고를 고치면 위 레벨이 따라 올라가요 · 이름 줄을 누르면 거기가 ±0';
    setText(box.querySelector('.vfoot .hint'), hint);
    var sq = box.querySelector('.vseq');
    if (sq) { if (sq.getAttribute('data-html') !== seq) { sq.innerHTML = seq; sq.setAttribute('data-html', seq); } sq.classList.toggle('gone', !seq); }
    var cl = box.querySelector('[data-clear-all]');
    if (cl) { setText(cl, '따로 적은 ' + vm.clear + '칸 지우기'); cl.classList.toggle('gone', !vm.clear); cl.setAttribute('title', '칸마다 따로 적은 값을 지워요 (모두 같게 값은 그대로)'); }
  }
  function renderVals() {
    var kind = S.tab, box = $(kind === 'grid' ? 'gVals' : 'lVals'), vm = valsVM(kind);
    box.classList.toggle('wait', vm.mode === 'wait');
    if (box.getAttribute('data-sig') !== vm.sig) {
      drawing = true;          // 칸을 새로 짜는 동안 사라지는 칸이 내는 focusout 은 값으로 받지 않는다
      try { box.innerHTML = valsHTML(vm); } finally { drawing = false; }
      box.setAttribute('data-sig', vm.sig);
    }
    patchVals(box, vm);
    if (kind === 'level') {
      var b = bound.level;
      $('lValueNote').textContent = vm.mode === 'one' && b.res.sums.length ? b.res.n + '개 · 전체 ' + b.res.sums[0].text : '';
    }
  }
  // 그 칸 다음(step > 0) · 앞 칸으로. 축열은 같은 줄(가로 · 세로)의 다음 간격, 레벨은 위층
  function cellInputs(box, ser) {
    return all('input[data-role="cell"]', box).filter(function (i) { return ser == null || ser === 'all' || i.getAttribute('data-ser') === String(ser); })
      .sort(function (a, b) { return Number(a.getAttribute('data-k')) - Number(b.getAttribute('data-k')); });
  }
  function moveFrom(inp, step) {
    var box = inp.closest('.vals'), list = cellInputs(box, inp.getAttribute('data-ser')), base = inp.getAttribute('data-role') === 'base', at = base ? -1 : list.indexOf(inp);
    var to = list[step > 1 ? Math.min(at + step, list.length - 1) : at + step];          // 여러 칸을 채웠으면 그다음 칸, 끝까지 채웠으면 마지막 칸
    if ((base && step < 0) || to === inp) to = null;
    if (!to) return false;
    to.focus();
    try { to.select(); } catch (e) { }
    return true;
  }
  function numericAll(list) { return list.every(function (t) { return H.parseVal(t) != null; }); }
  var NUM_MSG = '층고는 숫자로 적어 주세요 (예: 3600 · 3.6)';
  // 돌려주는 값: -1 = 못 넣음(그대로 둠) · 0 = 바뀐 것 없음 · n = 넣은 칸 수
  // keep = 적던 글자를 칸에 그대로 둔다 (커서가 패널 밖으로 나갈 때 미리 넣는 경우 — 돌아와서 이어 적을 수 있게). 그 글자는 data-raw 에 적어 다시 넣지 않는다
  function commitInput(inp, keep) {
    var kind = S.tab, role = inp.getAttribute('data-role'), was = inp.getAttribute('data-was') || '', now = String(inp.value).replace(/^\s+|\s+$/g, '');
    if (now === was) return 0;
    if (inp.getAttribute('data-raw') === now) {          // 이미 넣은 글자 그대로
      if (!keep && role === 'base') noteRecent(kind, now);
      return 0;
    }
    if (now !== '' && H.valText(now) === was && H.splitVals(now, 9).length < 2) { if (!keep) inp.value = was; return 0; }          // 8400 ↔ 8,400 처럼 같은 값
    var n = role === 'base' ? commitBase(kind, inp.getAttribute('data-ser'), now, keep) : commitCell(kind, Number(inp.getAttribute('data-k')), now);
    if (n < 0) return -1;
    if (keep) inp.setAttribute('data-raw', now);
    else if (inp.parentNode) { inp.value = inp.getAttribute('data-was') || ''; inp.removeAttribute('data-raw'); }          // 넣은 값을 정리된 글자로 (8.4 → 8,400). 다음에 이 칸을 떠날 때 또 넣지 않게
    return n;
  }
  // 칸을 떠날 때: 적던 값을 넣고(못 넣는 글자면 되돌리고) 칸 글자를 정리한다
  function leaveInput(inp) {
    commitInput(inp);
    inp.value = inp.getAttribute('data-was') || '';
    inp.removeAttribute('data-raw');
  }
  function commitBase(kind, ser, text, quiet) {
    var mode = valMode(kind), vals = H.splitVals(text, 400), b = bound[kind];
    if (mode === 'other' || mode === 'wait') return -1;
    if (kind === 'level' && vals.length && !numericAll(vals)) { status(NUM_MSG, 'err'); return -1; }
    if (vals.length > 1) {          // 여러 값 = 첫 칸부터 차례로
      if (mode === 'multi') { status('여러 묶음에는 값 하나만 넣을 수 있어요 — 차례로 넣으려면 묶음 하나만 골라 주세요', 'err'); return -1; }
      if (mode === 'pre') {
        pend[kind].seq = vals;
        wakeDims(kind);
        status('만들 때 첫 칸부터 차례로 넣어요 (' + vals.length + '칸)', 'ok');
        renderVals();
        return vals.length;
      }
      var ks = b.res.spanInfo.filter(function (c) { return ser === 'all' || String(c.ser) === String(ser); }).map(function (c) { return c.k; }).slice(0, vals.length);
      if (!ks.length) return -1;
      wakeDims(kind);
      pushOps(kind, ks.map(function (k, i) { return { t: 'cell', k: k, text: vals[i] }; }), '첫 칸부터 ' + ks.length + '칸에 차례로 넣었어요');
      return ks.length;
    }
    var tx = vals.length ? vals[0] : '';
    if (tx) { if (!quiet) noteRecent(kind, tx); wakeDims(kind); }          // quiet: 아직 적는 중일 수 있는 값은 최근 값으로 남기지 않는다
    if (mode === 'pre') {
      pend[kind].base = tx;
      if (tx) pend[kind].seq = [];
      renderVals(); renderStage();
      return 1;
    }
    if (mode === 'multi') {          // 여러 묶음: 칸이 안 보이니 따로 적은 값까지 모두 이 값으로
      multiBase[kind] = tx;
      pushOps(kind, tx ? [{ t: 'wipe' }, { t: 'base', ser: 'all', text: tx }] : [{ t: 'base', ser: 'all', text: '' }],
        tx ? '묶음 ' + sel[kind] + '개의 ' + (kind === 'grid' ? '간격을 모두 ' : '층고를 모두 ') + H.valText(tx) + ' 로 맞췄어요' : '모두 같게 값을 지웠어요');
      return 1;
    }
    // 가로 · 세로 두 무리가 있는 묶음만 무리마다 따로, 아니면 한 값 (B0 · B1 을 같이 둔다)
    pushOps(kind, [{ t: 'base', ser: b.res.sums.length > 1 && ser !== 'all' ? Number(ser) : 'all', text: tx }],
      tx ? (kind === 'grid' ? '간격을 모두 ' : '층고를 모두 ') + H.valText(tx) + ' 로 맞췄어요' : '모두 같게 값을 지웠어요');
    return 1;
  }
  function commitCell(kind, k, text) {
    var b = bound[kind];
    if (valMode(kind) !== 'one') return -1;
    var me = null, i;
    for (i = 0; i < b.res.spanInfo.length; i++) if (b.res.spanInfo[i].k === k) me = b.res.spanInfo[i];
    if (!me) return -1;
    var after = b.res.spanInfo.filter(function (c) { return c.ser === me.ser && c.k >= k; }).map(function (c) { return c.k; });
    var vals = H.splitVals(text, after.length);
    if (kind === 'level' && vals.length && !numericAll(vals)) { status(NUM_MSG, 'err'); return -1; }
    if (vals.length > 1) {
      pushOps(kind, vals.map(function (t, j) { return { t: 'cell', k: after[j], text: t }; }), vals.length + '칸에 차례로 넣었어요');
      return vals.length;
    }
    pushOps(kind, [{ t: 'cell', k: k, text: vals.length ? vals[0] : '' }]);
    return 1;
  }
  function clearVals(kind) {
    var b = bound[kind];
    if (valMode(kind) !== 'one') return;
    var ks = b.res.spanInfo.filter(function (c) { return c.typed != null || c.hand != null; }).map(function (c) { return c.k; });
    var vs = (b.res.marksInfo || []).filter(function (m) { return m.handV; }).map(function (m) { return m.i; });
    pushOps(kind, [{ t: 'clear', ks: ks, vs: vs, ts: kind === 'grid' ? [0, 1] : [] }], '따로 적은 값을 지웠어요');
  }
  function bindVals(id) {
    var box = $(id);
    box.addEventListener('keydown', function (e) {
      var inp = e.target;
      if (!inp.classList || !inp.classList.contains('vin')) return;
      if (e.isComposing || e.keyCode === 229) return;
      var cell = inp.getAttribute('data-role') === 'cell', level = S.tab === 'level';
      if (e.key === 'Enter') {
        e.preventDefault();
        var n = commitInput(inp);
        if (n < 0) return;
        if (e.shiftKey) { moveFrom(inp, -1); return; }
        if (!moveFrom(inp, Math.max(1, n))) { if (cell) { try { inp.select(); } catch (e2) { } } else inp.blur(); }
      } else if (e.key === 'Escape') {
        inp.value = inp.getAttribute('data-was') || '';
        inp.removeAttribute('data-raw');
        inp.blur();
      } else if (cell && level && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {          // 레벨 자는 위가 높은 층
        e.preventDefault();
        if (commitInput(inp) >= 0) moveFrom(inp, e.key === 'ArrowUp' ? 1 : -1);
      } else if (cell && level && e.key === 'Tab') {
        if (commitInput(inp) >= 0 && moveFrom(inp, e.shiftKey ? -1 : 1)) e.preventDefault();
      }
    });
    // 칸을 누르면 안의 값을 통째로 고른다 (바로 새 값을 적게). 나중에 타이머로 고르면 이미 적기 시작한 글자를 덮을 수 있어서 누르는 그 순간에 한다
    box.addEventListener('mousedown', function (e) {
      var inp = e.target;
      if (!inp.classList || !inp.classList.contains('vin') || document.activeElement === inp) return;
      e.preventDefault();
      inp.focus();
      try { inp.select(); } catch (e2) { }
    });
    box.addEventListener('focusout', function (e) {
      var inp = e.target;
      if (drawing || !inp.classList || !inp.classList.contains('vin')) return;
      leaveInput(inp);
    });
    box.addEventListener('click', function (e) {
      var kind = S.tab, t = e.target, btn = t.closest ? t.closest('button') : null;
      if (btn && has(btn.dataset, 'base')) {
        var blk = btn.closest('.vser'), cur0 = blk.querySelector('input[data-role="base"]').getAttribute('data-was') || '', v = Number(btn.dataset.base);
        commitBase(kind, btn.dataset.ser, H.parseVal(cur0) === v ? '' : plain(v));
      } else if (btn && has(btn.dataset, 'clearK')) {
        if (valMode(kind) === 'one') pushOps(kind, [{ t: 'cell', k: Number(btn.dataset.clearK), text: '' }]);
      } else if (btn && has(btn.dataset, 'clearAll')) clearVals(kind);
      else if (btn && has(btn.dataset, 'clearSeq')) { pend[kind].seq = []; renderVals(); }
      else if (btn && btn.classList.contains('mk')) setKey('base', Number(btn.dataset.i) + 1);
      else if (t.classList && t.classList.contains('cn')) { var i2 = t.parentNode.querySelector('input'); if (i2) i2.focus(); }
    });
  }

  /* ---------- 실제 길이로 축척 맞추기 ----------
     축척을 모르는 도면에서: 첫 간격(레벨은 맨 아래 두 점 사이)의 실제 길이를 적으면 축척 = 실제 길이 ÷ 종이 위 길이.
     자리는 고친 묶음의 기준점, 없으면 지금 고른 점 · 선에서 읽는다 (문서는 안 바꿈 — 바뀐 축척은 여느 값처럼 반영) */
  var sayAfterEdit = '';
  function firstSpan(st, src) {
    var res = H.build(st, src, makeM(st.font), null);
    return res.spanInfo.length ? res.spanInfo[0].dist : 0;
  }
  function calibrate(kind, text) {
    var mm = parseFloat(String(text).replace(/,/g, ''));
    if (!(mm > 0)) { status('실제 길이를 숫자로 적어 주세요 (예: ' + (kind === 'grid' ? '8400' : '3600') + ')', 'err'); return; }
    enqueue('cal', false, function (done) {
      function finish(spanPt) {
        if (!(spanPt > 0.01)) { status(kind === 'grid' ? '간격을 잴 축선이 둘 이상 있어야 해요' : '높이를 잴 점이 둘 이상 있어야 해요', 'err'); done(); return; }
        var sc = Math.round(mm / (spanPt / H.PT) * 1000) / 1000;
        if (sc < H.LIMITS.scale[0] || sc > H.LIMITS.scale[1]) { status('축척이 1/' + sc + ' 로 나와요 — 적은 길이를 다시 확인해 주세요', 'err'); done(); return; }
        $(kind === 'grid' ? 'gCal' : 'lCal').value = '';
        var msg = '축척을 1/' + sc + ' 로 맞췄어요';
        if (editing()) sayAfterEdit = msg;
        done();
        setKey('scale', sc);
        if (!editing()) status(msg, 'ok');
      }
      if (editing()) {
        evalJ('hyMark_read', undefined, function (r) {
          if (!r.ok) { status(r.msg, 'err'); done(); return; }
          var span = 0, found = false;
          (r.groups || []).some(function (g) {
            var state;
            try { state = JSON.parse(decodeURIComponent(g.state)); } catch (e) { state = null; }
            if (!state || !state.st) return false;
            var st = H.normalize(state.st);
            if (st.kind !== kind) return false;
            found = true;
            var so = srcOf(g, state);
            span = so ? firstSpan(st, so.src) : 0;
            return span > 0.01;
          });
          if (!found) { status('고른 묶음에 ' + (kind === 'grid' ? '축열' : '레벨') + ' 기호가 없어요', 'err'); done(); return; }
          finish(span);
        });
      } else {
        evalJ('hyMark_source', prefer, function (r) {
          if (!r.ok) { status('잴 자리가 없어요 — 점 · 선이나 만든 기호를 먼저 골라 주세요', 'err'); done(); return; }
          finish(firstSpan(cur(kind), r.mode === 'lines' ? { mode: 'lines', lines: r.lines } : { mode: 'points', pts: r.pts }));
        });
      }
    });
  }

  /* ---------- 테마 ---------- */
  function applyTheme() {
    var env = CEP.hostEnv(), root = document.documentElement;
    if (env && env.appSkinInfo) {
      var c = env.appSkinInfo.panelBackgroundColor.color, r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
      var light = (0.299 * r + 0.587 * g + 0.114 * b) > 140;
      root.setAttribute('data-theme', light ? 'light' : 'dark');
      var shade = function (d) { return 'rgb(' + [r, g, b].map(function (v) { return Math.max(0, Math.min(255, v + d)); }).join(',') + ')'; };
      root.style.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
      root.style.setProperty('--c1', shade(light ? -22 : 14));
      root.style.setProperty('--c2', shade(light ? -34 : 26));
      root.style.setProperty('--c3', shade(light ? -12 : -10));
    }
    readTheme();
  }

  /* ---------- 시작 ---------- */
  buildSliders();
  linePatternSeg();
  applyTheme();
  CEP.on('com.adobe.csxs.events.ThemeColorChanged', function () { applyTheme(); renderAll(); });

  all('#tabs button').forEach(function (b) {
    b.addEventListener('click', function () { S.tab = b.getAttribute('data-tab'); save(); renderAll(); });
  });
  bindTiles('gShapes', 'shape'); bindTiles('gFinishes', 'finish'); bindTiles('lHeads', 'head'); bindTiles('gDims', 'dim');
  $('looks').addEventListener('click', function (e) { var b = e.target.closest('.look'); if (b) applyLook(b.dataset.v); });
  bindSeg('gNum', 'num'); bindSeg('lLayout', 'layout'); bindSeg('lContent', 'content'); bindSeg('lHc', 'hc'); bindSeg('lp', 'lp'); bindSeg('lc', 'lc');
  bindStepper('gStart', 'start'); bindStepper('lBase', 'base');
  bindCheck('gSwap', 'swap'); bindCheck('gRev', 'rev'); bindCheck('lGl', 'gl'); bindCheck('lRf', 'rf');
  bindCheck('flip', 'flip'); bindCheck('both', 'both'); bindCheck('turn', 'turn'); bindCheck('align', 'align'); bindCheck('dtot', 'dtot');
  bindChips('lScale', 'scale', true); bindChips('lFmt', 'fmt'); bindChips('lRound', 'round', true); bindChips('lNm', 'nm'); bindChips('fonts', 'font');
  bindChips('gScale', 'scale', true); bindChips('gFmt', 'dfmt'); bindChips('gRound', 'dround', true);
  [['gCal', 'gCalBtn', 'grid'], ['lCal', 'lCalBtn', 'level']].forEach(function (c) {
    $(c[0]).addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); calibrate(c[2], this.value); } });
    $(c[1]).addEventListener('click', function () { calibrate(c[2], $(c[0]).value); });
  });
  ['lScaleNum', 'gScaleNum'].forEach(function (id) {
    $(id).addEventListener('change', function () { var v = parseFloat(this.value); if (v > 0) setKey('scale', v); else renderControls(); });
    $(id).addEventListener('keydown', function (e) { if (e.key === 'Enter') this.blur(); });
  });
  ['swInk', 'swAccent', 'swPaper'].forEach(function (id) {
    var key = id === 'swInk' ? 'ink' : id === 'swAccent' ? 'accent' : 'paper';
    $(id).addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) return;
      if (has(b.dataset, 'pick')) {
        enqueue(null, false, function (done) {
          evalJ('hyMark_pickColor', get(key) || '#FFFFFF', function (r) { if (r.ok && r.hex) setKey(key, r.hex); else if (!r.ok) status(r.msg, 'err'); done(); });
        });
      } else setKey(key, b.dataset.v);
    });
  });
  all('.fold-head').forEach(function (hd) {
    hd.addEventListener('click', function () { var f = hd.parentNode; S.folds[f.id] = !S.folds[f.id]; save(); f.classList.toggle('open', !!S.folds[f.id]); });
  });
  bindVals('gVals'); bindVals('lVals');
  $('btnPrefer').addEventListener('click', function () { prefer = srcMode() === 'points' ? 'lines' : 'points'; renderSel(); });
  $('btnPen').addEventListener('click', function () {
    enqueue(null, false, function (done) {
      evalJ('hyMark_tool', 'pen', function (r) {
        penArmed = !!r.ok;
        status(r.ok ? '기호 넣을 자리마다 한 번씩 클릭한 뒤 [만들기]' : (r.msg || '펜 도구(P)로 점을 찍어 주세요'), r.ok ? '' : 'err');
        done();
      });
    });
  });
  $('btnMake').addEventListener('click', function () {
    if (editing()) { redrawAll = true; enqueue('edit', false, editTask); }
    else enqueue('make', false, makeTask);
  });
  $('btnPick').addEventListener('click', function () {
    enqueue(null, false, function (done) {
      evalJ('hyMark_pickFrom', undefined, function (r) {
        if (!r.ok) { status(r.msg, 'err'); done(); return; }
        var got = [];
        if (r.stroke || r.fill) { setKey('ink', r.stroke || r.fill); got.push('색'); }
        if (r.font) { setKey('font', r.font); got.push('글꼴 ' + r.font); }
        status(got.join(' · ') + ' 가져왔어요', 'ok');
        done();
      });
    });
  });
  document.addEventListener('mousemove', maybeRefresh);
  window.addEventListener('focus', maybeRefresh);
  // 도면에서 점을 찍고 패널로 돌아오는 순간에는 바로 다시 읽는다 ([만들기]가 늦게 켜지지 않게)
  document.documentElement.addEventListener('mouseenter', function () { if (!busy && !tasks.length && Date.now() - lastPeek > 250) refreshSel(true); });
  window.addEventListener('resize', function () { renderStage(); });
  // 값을 적다가 커서가 패널 밖으로 나가면 그때 넣는다. 도면을 누른 뒤(패널이 포커스를 잃은 뒤)에 넣으면 이미 선택이 풀려
  // 넣을 묶음을 못 찾기 때문 — 나가는 순간에는 아직 골라져 있다. 적던 글자는 칸에 그대로 둔다 (돌아와서 이어 적을 수 있게)
  function typing() { var a = document.activeElement; return a && a.classList && a.classList.contains('vin') && !drawing ? a : null; }
  document.documentElement.addEventListener('mouseleave', function () { var a = typing(); if (a) commitInput(a, true); });
  // 패널 창이 포커스를 잃을 때도 (다른 창으로 갔을 때 · 칸을 떠날 때와 같게)
  window.addEventListener('blur', function () { var a = typing(); if (a) leaveInput(a); });

  renderAll();

  if (CEP.available) {
    // manifest 의 ScriptPath 가 안 불렸거나 예전 판이 남아 있으면(업데이트 직후) 직접 불러온다
    CEP.evalScript('typeof hyMark_ping == "function" ? hyMark_ping() : ""', function (t) {
      var v = parse(t).v || '';
      function start() {
        evalJ('hyMark_hasFonts', enc(FONT_CANDS), function (r) {
          if (r.ok && r.fonts) {
            fontsHere = r.fonts.slice(0, 7);
            // 기본 글꼴(Pretendard)이 이 PC 에 없으면 문서 기본 글꼴로 — 없는 글꼴이 골라진 것처럼 보이지 않게
            if (fontsHere.indexOf('Pretendard') < 0 && S.common.font === 'Pretendard') { S.common.font = ''; save(); }
            renderAll();
          }
        });
        refreshSel();
      }
      if (v === ENGINE_V) { start(); return; }
      var p = CEP.extensionPath();
      if (!p) { start(); return; }
      CEP.evalScript('$.evalFile(' + JSON.stringify(p + '/jsx/hyMark.jsx') + ')', function () { start(); });
    });
  }
  window.__hyMarkPanel = { state: function () { return S; }, cur: cur, refresh: refreshSel, bound: function () { return bound; }, pend: function () { return pend; } };
})();
