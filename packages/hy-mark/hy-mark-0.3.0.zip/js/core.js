/* hy Mark 엔진 — 축열·레벨 기호 장면 만들기
   패널 미리보기 · 일러스트 출력(jsx 가 이 장면을 그대로 그림) · 시험이 같은 코드를 쓴다.
   좌표는 화면 방향(y 아래), 단위 pt. 장면 = 패스(pts: [앵커x, y, 들어오는 핸들 x, y, 나가는 핸들 x, y]) + 글자(기준선 자리). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.HYMARK = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '0.3.0';
  var PT = 72 / 25.4;          // 1 mm = 2.8346 pt
  var K = 0.5522847498;        // 원을 베지어 넷으로 그릴 때 핸들 길이

  /* ================= 색 ================= */
  function rgbOf(hex) {
    var n = parseInt(String(hex || '').replace('#', ''), 16);
    if (isNaN(n)) n = 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function hexOf(r, g, b) {
    function h(v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? '0' : '') + v.toString(16); }
    return ('#' + h(r) + h(g) + h(b)).toUpperCase();
  }
  function mix(a, b, t) {
    var A = rgbOf(a), B = rgbOf(b);
    return hexOf(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t);
  }
  function lum(hex) {
    var c = rgbOf(hex), v = [0, 0, 0];
    for (var i = 0; i < 3; i++) { var s = c[i] / 255; v[i] = s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4); }
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
  }
  // 칠한 면 위 글자색: 종이색이 충분히 대비되면 종이색, 아니면 흰색·검정 중 잘 보이는 쪽
  function onColor(fill, paper) {
    var lf = lum(fill);
    if (paper) { var lp = lum(paper), hi = Math.max(lf, lp), lo = Math.min(lf, lp); if ((hi + 0.05) / (lo + 0.05) >= 3) return paper; }
    return lf > 0.42 ? '#141414' : '#FFFFFF';
  }

  /* ================= 글자 폭 (기본: Pretendard 표) ================= */
  var ADV = {"r":{"d":[0.6172,0.4482,0.5947,0.624,0.6348,0.6064,0.623,0.5596,0.6182,0.623],"u":[0.6689,0.625,0.7031,0.6904,0.5752,0.5586,0.7168,0.7109,0.251,0.5254,0.6357,0.5371,0.8623,0.7148,0.7354,0.6104,0.7354,0.6162,0.6143,0.6221,0.7061,0.6689,0.9434,0.6367,0.6543,0.6094],"l":[0.543,0.5977,0.541,0.5977,0.5605,0.3477,0.5889,0.5742,0.2314,0.2314,0.5303,0.2314,0.8486,0.5703,0.5742,0.5889,0.5889,0.3633,0.5098,0.3496,0.5674,0.54,0.791,0.5254,0.54,0.5244],"s":{" ":0.2441,",":0.2676,".":0.2637,":":0.2637,"/":0.3467,"(":0.3574,")":0.3574,"[":0.3574,"]":0.3574,"+":0.6357,"-":0.4385,"\u2212":0.6357,"\u00b1":0.6357,"=":0.6357,"\u00b7":0.2637,"%":0.8945,"#":0.6074,"&":0.6221,"_":0.4346,"'":0.2002,"\"":0.3779}},"b":{"d":[0.6602,0.4688,0.6104,0.6387,0.6572,0.627,0.6426,0.5752,0.6436,0.6426],"u":[0.7178,0.6367,0.7236,0.7012,0.5889,0.5625,0.7324,0.7197,0.2656,0.5469,0.6631,0.5459,0.8828,0.709,0.7529,0.623,0.7539,0.6318,0.6299,0.6426,0.7041,0.7178,0.999,0.6855,0.6953,0.6406],"l":[0.5576,0.6113,0.5635,0.6113,0.5742,0.3672,0.6084,0.5996,0.2568,0.2568,0.5576,0.2568,0.8789,0.5977,0.5898,0.6084,0.6084,0.3896,0.5391,0.3701,0.5967,0.5625,0.8193,0.5508,0.5625,0.5488],"s":{" ":0.2305,",":0.2871,".":0.2822,":":0.2822,"/":0.3711,"(":0.3896,")":0.3896,"[":0.3896,"]":0.3896,"+":0.6533,"-":0.4492,"\u2212":0.6533,"\u00b1":0.6533,"=":0.6533,"\u00b7":0.2822,"%":0.96,"#":0.624,"&":0.6484,"_":0.4561,"'":0.1973,"\"":0.376}}};   // Pretendard Medium(r)·Bold(b) 글자 폭 (em)
  function builtinMeasure(s, size, bold) {
    var t = bold ? ADV.b : ADV.r, w = 0;
    s = String(s);
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i), c = s.charCodeAt(i);
      if (c >= 48 && c <= 57) w += t.d[c - 48];
      else if (c >= 65 && c <= 90) w += t.u[c - 65];
      else if (c >= 97 && c <= 122) w += t.l[c - 97];
      else if (t.s[ch] != null) w += t.s[ch];
      else if (c >= 0x1100) w += 0.864;       // 한글·한자
      else w += 0.6;
    }
    return w * size;
  }
  var BUILTIN = { cap: 0.707, measure: builtinMeasure };

  /* ================= 기하 ================= */
  function C(x, y) { return [x, y, x, y, x, y]; }                    // 모서리 점
  function unit(x, y) { var l = Math.sqrt(x * x + y * y); return l < 1e-9 ? [1, 0] : [x / l, y / l]; }

  function circlePts(cx, cy, r) {
    var k = K * r;
    return [
      [cx + r, cy, cx + r, cy - k, cx + r, cy + k],
      [cx, cy + r, cx + k, cy + r, cx - k, cy + r],
      [cx - r, cy, cx - r, cy + k, cx - r, cy - k],
      [cx, cy - r, cx - k, cy - r, cx + k, cy - r]
    ];
  }
  // 초타원(스쿼클): 변 가운데 네 점 + 긴 핸들 → 모서리가 곡률까지 부드럽게 이어진 둥근 사각
  function superPts(cx, cy, a, k) {
    var h = a * k;
    return [
      [cx + a, cy, cx + a, cy - h, cx + a, cy + h],
      [cx, cy + a, cx + h, cy + a, cx - h, cy + a],
      [cx - a, cy, cx - a, cy + h, cx - a, cy - h],
      [cx, cy - a, cx - h, cy - a, cx + h, cy - a]
    ];
  }
  function rrectPts(cx, cy, hw, hh, r) {
    r = Math.max(0, Math.min(r, hw, hh));
    if (r < 1e-6) return [C(cx - hw, cy - hh), C(cx + hw, cy - hh), C(cx + hw, cy + hh), C(cx - hw, cy + hh)];
    var k = K * r, x0 = cx - hw, x1 = cx + hw, y0 = cy - hh, y1 = cy + hh;
    var pts = [
      [x0 + r, y0, x0 + r - k, y0, x0 + r, y0], [x1 - r, y0, x1 - r, y0, x1 - r + k, y0],
      [x1, y0 + r, x1, y0 + r - k, x1, y0 + r], [x1, y1 - r, x1, y1 - r, x1, y1 - r + k],
      [x1 - r, y1, x1 - r + k, y1, x1 - r, y1], [x0 + r, y1, x0 + r, y1, x0 + r - k, y1],
      [x0, y1 - r, x0, y1 - r + k, x0, y1 - r], [x0, y0 + r, x0, y0 + r, x0, y0 + r - k]
    ];
    // 반지름이 변을 다 쓰면(캡슐) 겹친 점을 뺀다
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i], q = out[out.length - 1];
      if (q && Math.abs(q[0] - p[0]) < 1e-6 && Math.abs(q[1] - p[1]) < 1e-6) { q[4] = p[4]; q[5] = p[5]; }
      else out.push(p);
    }
    var a = out[0], z = out[out.length - 1];
    if (out.length > 1 && Math.abs(a[0] - z[0]) < 1e-6 && Math.abs(a[1] - z[1]) < 1e-6) { a[2] = z[2]; a[3] = z[3]; out.pop(); }
    return out;
  }
  function polyPts(list) { var o = []; for (var i = 0; i < list.length; i++) o.push(C(list[i][0], list[i][1])); return o; }
  // 정다각형: 변까지 거리(내접원)를 inset 만큼 줄인다. rot = 첫 꼭짓점 각도
  function ngon(n, Rc, rot, inset) {
    var cs = Math.cos(Math.PI / n), a = Rc * cs - (inset || 0), R2 = Math.max(0.01, a / cs), o = [];
    for (var i = 0; i < n; i++) { var t = rot + i * 2 * Math.PI / n; o.push([R2 * Math.cos(t), R2 * Math.sin(t)]); }
    return o;
  }
  // 볼록 다각형을 안쪽으로 d 만큼
  function offsetPoly(p, d) {
    if (!d) return p;
    var n = p.length, area = 0, i;
    for (i = 0; i < n; i++) { var a0 = p[i], b0 = p[(i + 1) % n]; area += a0[0] * b0[1] - b0[0] * a0[1]; }
    var sg = area > 0 ? 1 : -1, lines = [];
    for (i = 0; i < n; i++) {
      var a = p[i], b = p[(i + 1) % n], e = unit(b[0] - a[0], b[1] - a[1]);
      var nx = -e[1] * sg, ny = e[0] * sg;                     // 안쪽 법선
      lines.push([a[0] + nx * d, a[1] + ny * d, e[0], e[1]]);
    }
    var o = [];
    for (i = 0; i < n; i++) {
      var L1 = lines[(i + n - 1) % n], L2 = lines[i], den = L1[2] * L2[3] - L1[3] * L2[2];
      if (Math.abs(den) < 1e-9) { o.push([L2[0], L2[1]]); continue; }
      var t = ((L2[0] - L1[0]) * L2[3] - (L2[1] - L1[1]) * L2[2]) / den;
      o.push([L1[0] + L1[2] * t, L1[1] + L1[3] * t]);
    }
    return o;
  }
  // 핀(물방울): 원 + +x 쪽 뾰족한 꼬리. tipK = 꼬리 끝 거리 / 반지름
  function dropPts(r, tipK) {
    var d = r * tipK, phi = Math.acos(1 / tipK), a0 = phi, a1 = 2 * Math.PI - phi, segs = 4, da = (a1 - a0) / segs;
    var h = 4 / 3 * Math.tan(da / 4) * r, pts = [C(d, 0)], i;
    for (i = 0; i <= segs; i++) {
      var a = a0 + da * i, x = r * Math.cos(a), y = r * Math.sin(a), tx = -Math.sin(a), ty = Math.cos(a);
      pts.push([x, y, i === 0 ? x : x - tx * h, i === 0 ? y : y - ty * h, i === segs ? x : x + tx * h, i === segs ? y : y + ty * h]);
    }
    return pts;
  }
  function mapPts(pts, fn) {
    var o = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i], a = fn(p[0], p[1]), l = fn(p[2], p[3]), r = fn(p[4], p[5]);
      o.push([a[0], a[1], l[0], l[1], r[0], r[1]]);
    }
    return o;
  }
  function rotPts(pts, ang) {
    if (!ang) return pts;
    var c = Math.cos(ang), s = Math.sin(ang);
    return mapPts(pts, function (x, y) { return [x * c - y * s, x * s + y * c]; });
  }
  function movePts(pts, dx, dy) { return mapPts(pts, function (x, y) { return [x + dx, y + dy]; }); }
  // 베지어를 꺾은선으로 (닫힌 패스)
  function flatten(pts, closed, seg) {
    var o = [], n = pts.length, m = closed ? n : n - 1;
    seg = seg || 12;
    for (var i = 0; i < m; i++) {
      var a = pts[i], b = pts[(i + 1) % n];
      var straight = a[4] === a[0] && a[5] === a[1] && b[2] === b[0] && b[3] === b[1];
      o.push([a[0], a[1]]);
      if (!straight) {
        for (var k = 1; k < seg; k++) {
          var t = k / seg, u = 1 - t;
          o.push([u * u * u * a[0] + 3 * u * u * t * a[4] + 3 * u * t * t * b[2] + t * t * t * b[0],
                  u * u * u * a[1] + 3 * u * u * t * a[5] + 3 * u * t * t * b[3] + t * t * t * b[1]]);
        }
      }
    }
    if (!closed) o.push([pts[n - 1][0], pts[n - 1][1]]);
    return o;
  }
  function perimeter(poly, closed) {
    var L = 0, n = poly.length, m = closed ? n : n - 1;
    for (var i = 0; i < m; i++) { var a = poly[i], b = poly[(i + 1) % n]; L += Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1])); }
    return L;
  }
  // 원점에서 (ux, uy) 방향으로 나갈 때 닫힌 꺾은선과 만나는 가장 먼 거리
  function rayExit(poly, ux, uy) {
    var best = 0, n = poly.length;
    for (var i = 0; i < n; i++) {
      var a = poly[i], b = poly[(i + 1) % n], ex = b[0] - a[0], ey = b[1] - a[1], den = ux * ey - uy * ex;
      if (Math.abs(den) < 1e-12) continue;
      var t = (a[0] * ey - a[1] * ex) / den, s = (a[0] * uy - a[1] * ux) / den;
      if (t > 0 && s >= -1e-9 && s <= 1 + 1e-9 && t > best) best = t;
    }
    return best;
  }
  // 높이 y 에서 가운데(x = 0)를 낀 안쪽 반폭
  function halfSpanAt(poly, y) {
    var xr = Infinity, xl = -Infinity, n = poly.length;
    for (var i = 0; i < n; i++) {
      var a = poly[i], b = poly[(i + 1) % n];
      if ((a[1] - y) * (b[1] - y) > 0 || a[1] === b[1]) continue;
      var x = a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]);
      if (x >= 0 && x < xr) xr = x;
      if (x <= 0 && x > xl) xl = x;
    }
    if (xr === Infinity || xl === -Infinity) return 0;
    return Math.min(xr, -xl);
  }

  /* ================= 장면 조각 ================= */
  function P(pts, o) {
    return { t: 'path', pts: pts, closed: o.closed !== false, fill: o.fill || null, stroke: o.stroke || null, sw: o.sw || 0,
      cap: o.cap || 'butt', join: o.join || 'round', dash: o.dash || null, dashOff: o.dashOff || 0, gi: o.gi == null ? -1 : o.gi, name: o.name || '' };
  }
  function LN(x0, y0, x1, y1, o) { o.closed = false; return P([C(x0, y0), C(x1, y1)], o); }
  function T(x, y, s, o) {
    return { t: 'text', x: x, y: y, s: String(s), size: o.size, bold: !!o.bold, fill: o.fill, align: o.align || 'left',
      gi: o.gi == null ? -1 : o.gi, name: o.name || '', role: o.role || '', idx: o.idx == null ? -1 : o.idx, runs: o.runs || null, rot: o.rot || 0 };
  }

  /* 선 무늬: 끝이 어중간하게 잘리지 않게 길이에 맞춰 조금 늘이거나 줄인다 (긴 선으로 시작해 긴 선으로 끝) */
  function fitDash(kind, L, S, scale) {
    var k = (scale || 100) / 100, pat, cap = 'butt';
    if (kind === 'center') pat = [0.9 * S * k, 0.11 * S * k, 0.11 * S * k, 0.11 * S * k];
    else if (kind === 'dash') pat = [0.27 * S * k, 0.17 * S * k];
    else if (kind === 'dot') { pat = [0.01, 0.17 * S * k]; cap = 'round'; }
    else return { dash: null, cap: 'butt' };
    var a = pat[0], per = 0, i;
    for (i = 0; i < pat.length; i++) per += pat[i];
    if (L < a * 1.35 && kind !== 'dot') return { dash: null, cap: 'butt' };
    var n = Math.max(1, Math.round((L - a) / per)), f = L / (n * per + a), out = [];
    for (i = 0; i < pat.length; i++) out.push(kind === 'dot' && i === 0 ? pat[i] : Math.round(pat[i] * f * 1000) / 1000);
    return { dash: out, cap: cap };
  }
  // 닫힌 외곽의 점선: 둘레를 딱 나누고(다각형은 변마다 같은 개수), at = 조각 가운데가 올 자리(둘레 따라 잰 거리)
  function fitDashClosed(perim, dash, gap, sides, att, at) {
    var n;
    if (sides) {
      var k = Math.max(1, Math.round(perim / sides / (dash + gap)));
      if (att === 'side' && k % 2) k += 1;                 // 변 가운데에도 조각이 오게 짝수
      n = sides * k;
    } else n = Math.max(6, Math.round(perim / (dash + gap)));
    var f = perim / (n * (dash + gap)), d = dash * f, g = gap * f, per = d + g;
    var off = ((d / 2 - (at || 0)) % per + per) % per;
    return { dash: [Math.round(d * 1000) / 1000, Math.round(g * 1000) / 1000], off: Math.round(off * 1000) / 1000 };
  }
  // 원점에서 (ux, uy) 로 나가 외곽과 만나는 자리까지 둘레를 따라 잰 거리
  function arcAtRay(poly, ux, uy) {
    var best = 0, at = 0, acc = 0, n = poly.length;
    for (var i = 0; i < n; i++) {
      var a = poly[i], b = poly[(i + 1) % n], ex = b[0] - a[0], ey = b[1] - a[1], len = Math.sqrt(ex * ex + ey * ey), den = ux * ey - uy * ex;
      if (Math.abs(den) > 1e-12) {
        var t = (a[0] * ey - a[1] * ex) / den, sv = (a[0] * uy - a[1] * ux) / den;
        if (t > 0 && sv >= -1e-9 && sv <= 1 + 1e-9 && t > best) { best = t; at = acc + len * Math.max(0, Math.min(1, sv)); }
      }
      acc += len;
    }
    return at;
  }

  /* ================= 목록 (패널이 썸네일로 보여 주는 순서) ================= */
  var GRID_SHAPES = [
    { id: 'circle', name: '원', closed: 1, k: 0.47 },
    { id: 'hex', name: '육각', closed: 1, rot: 1, k: 0.42, sides: 6, att: 'vertex' },
    { id: 'oct', name: '팔각', closed: 1, k: 0.45, sides: 8, att: 'side' },
    { id: 'square', name: '사각', closed: 1, k: 0.45, sides: 4, att: 'side' },
    { id: 'rsquare', name: '둥근 사각', closed: 1, k: 0.46 },
    { id: 'diamond', name: '마름모', closed: 1, rot: 1, k: 0.38, sides: 4, att: 'vertex' },
    { id: 'pill', name: '캡슐', closed: 1, auto: 1 },
    { id: 'drop', name: '핀', closed: 1, rot: 1, k: 0.46 },
    { id: 'tag', name: '태그', closed: 1, rot: 1, auto: 1 },
    { id: 'corners', name: '코너', auto: 1 },
    { id: 'bracket', name: '괄호', auto: 1 },
    { id: 'bar', name: '막대', auto: 1 },
    { id: 'dot', name: '도트', auto: 1 },
    { id: 'plain', name: '글자만', auto: 1 }
  ];
  var GRID_FINISHES = [
    { id: 'line', name: '선' },
    { id: 'bold', name: '굵게' },
    { id: 'double', name: '이중' },
    { id: 'dash', name: '점선' },
    { id: 'ticks', name: '눈금' },
    { id: 'solid', name: '면' },
    { id: 'badge', name: '배지' },
    { id: 'cline', name: '색 선' },
    { id: 'soft', name: '틴트' },
    { id: 'accent', name: '포인트' },
    { id: 'shadow', name: '그림자' },
    { id: 'spot', name: '점 포인트' }
  ];
  var LEVEL_HEADS = [
    { id: 'tri', name: '삼각' },
    { id: 'trifill', name: '채운 삼각' },
    { id: 'trihalf', name: '반 채움' },
    { id: 'shelf', name: '선반' },
    { id: 'arrow', name: '화살촉' },
    { id: 'target', name: '표적' },
    { id: 'cross', name: '십자 원' },
    { id: 'dot', name: '도트' },
    { id: 'tick', name: '틱' },
    { id: 'slash', name: '사선' },
    { id: 'bar', name: '밑줄' },
    { id: 'diamond', name: '마름모' },
    { id: 'tag', name: '태그', label: 1 },
    { id: 'pill', name: '캡슐', label: 1 },
    { id: 'box', name: '박스', label: 1 },
    { id: 'flag', name: '깃발' }
  ];
  var LEVEL_LAYOUTS = [
    { id: 'in', name: '안쪽' },
    { id: 'out', name: '바깥쪽' },
    { id: 'split', name: '위·아래' }
  ];
  var LINE_PATTERNS = [
    { id: 'center', name: '일점쇄선' },
    { id: 'solid', name: '실선' },
    { id: 'dash', name: '파선' },
    { id: 'dot', name: '점선' },
    { id: 'none', name: '없음' }
  ];
  // 축열 사이 간격 숫자 (치수) 모양
  var GRID_DIMS = [
    { id: 'none', name: '없음' },
    { id: 'tick', name: '사선' },
    { id: 'dot', name: '점' },
    { id: 'arrow', name: '화살표' },
    { id: 'bar', name: '끝선' },
    { id: 'cut', name: '선 사이' },
    { id: 'pill', name: '캡슐' },
    { id: 'link', name: '기호 사이' },
    { id: 'num', name: '숫자만' }
  ];
  var NUM_SCHEMES = { x: ['X#', 'Y#'], n: ['#', 'A'], a: ['A', '#'] };
  // 추천 조합: 한 번에 고르는 모양 + 선 + 색 (크기·굵기·글꼴은 건드리지 않음)
  var LOOKS = [
    { id: 'draft', name: '도면 기본', common: { ink: '#1A1A1A', paper: '#FFFFFF', accent: '#E8452C' },
      grid: { shape: 'circle', finish: 'line', lp: 'center', lc: 'ink' }, level: { head: 'trihalf', layout: 'in', hc: 'ink', lp: 'solid', lc: 'ink' } },
    { id: 'mono', name: '모노 볼드', common: { ink: '#1A1A1A', paper: '#FFFFFF', accent: '#E8452C' },
      grid: { shape: 'circle', finish: 'solid', lp: 'solid', lc: 'soft' }, level: { head: 'tag', layout: 'in', hc: 'ink', lp: 'solid', lc: 'soft' } },
    { id: 'point', name: '포인트', common: { ink: '#1A1A1A', paper: '#FFFFFF', accent: '#E8452C' },
      grid: { shape: 'hex', finish: 'accent', lp: 'dash', lc: 'accent' }, level: { head: 'trifill', layout: 'split', hc: 'accent', lp: 'solid', lc: 'ink' } },
    { id: 'minimal', name: '미니멀', common: { ink: '#1A1A1A', paper: '#FFFFFF', accent: '#E8452C' },
      grid: { shape: 'bar', finish: 'line', lp: 'solid', lc: 'soft' }, level: { head: 'bar', layout: 'in', hc: 'ink', lp: 'solid', lc: 'soft' } },
    { id: 'graphic', name: '그래픽', common: { ink: '#1A1A1A', paper: '#FFFFFF', accent: '#FFC629' },
      grid: { shape: 'rsquare', finish: 'shadow', lp: 'dot', lc: 'ink' }, level: { head: 'pill', layout: 'in', hc: 'ink', lp: 'dot', lc: 'ink' } },
    { id: 'dark', name: '어두운 바탕', common: { ink: '#F2F2F2', paper: '#14181F', accent: '#5FD1C3' },
      grid: { shape: 'circle', finish: 'double', lp: 'center', lc: 'ink' }, level: { head: 'target', layout: 'out', hc: 'ink', lp: 'center', lc: 'ink' } }
  ];

  function byId(list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return list[0]; }

  /* ================= 설정 ================= */
  // scale(도면 축척 1/N)은 축열의 간격 숫자와 레벨 값이 같이 쓴다
  var COMMON = { size: 7, sw: 0.5, ts: 100, ink: '#1A1A1A', accent: '#E8452C', paper: '#FFFFFF', font: 'Pretendard', scale: 100 };
  var GRID = { shape: 'circle', finish: 'line', num: 'x', swap: false, start: 1, rev: false,
    dim: 'none', dgap: 6, dtot: false, dround: 100, dfmt: 'c',
    lp: 'center', lw: 70, lc: 'ink', ds: 100, len: 40, gap: 0, flip: false, both: false, align: true, turn: false };
  var LEVEL = { head: 'trihalf', layout: 'in', content: 'nv', hc: 'ink',
    base: 1, round: 100, fmt: 'mm', nm: 'FL', gl: false, rf: true,
    lp: 'solid', lw: 70, lc: 'ink', ds: 100, len: 30, flip: false, align: true };
  var COMMON_KEYS = ['size', 'sw', 'ts', 'ink', 'accent', 'paper', 'font', 'scale'];
  var LIMITS = { size: [2, 30], sw: [0.05, 6], ts: [50, 200], lw: [20, 200], ds: [40, 300], len: [0, 2000], gap: [0, 50], start: [0, 999], base: [1, 99], scale: [1, 100000], round: [1, 1000],
    dgap: [0, 80], dround: [1, 1000] };

  function copy(o) { var r = {}; for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) r[k] = o[k]; return r; }
  function defaults(kind) {
    var r = copy(COMMON), k = kind === 'level' ? LEVEL : GRID;
    for (var key in k) r[key] = k[key];
    r.kind = kind === 'level' ? 'level' : 'grid';
    r.v = 1;
    return r;
  }
  function hexOk(v) { return typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v); }
  // 모르는 값·범위 밖 값은 기본값으로 (저장된 상태가 낡았어도 그릴 수 있게)
  // 글꼴 이름은 문서(묶음에 적힌 설정 · 고른 글자)에서도 온다 — 패널 화면에 그대로 들어가므로 태그 · 따옴표 같은 글자는 뺀다
  function cleanFont(s) {
    return String(s == null ? '' : s).replace(/[<>"'`&\\;{}\u0000-\u001F\u007F]/g, '').replace(/\s+/g, ' ').replace(/^ | $/g, '').slice(0, 64);
  }
  function normalize(st) {
    var kind = st && st.kind === 'level' ? 'level' : 'grid', d = defaults(kind), r = {}, k;
    for (k in d) {
      var v = st ? st[k] : undefined, dv = d[k];
      if (v === undefined || v === null) { r[k] = dv; continue; }
      if (typeof dv === 'number') {
        v = Number(v);
        if (isNaN(v)) v = dv;
        if (LIMITS[k]) v = Math.max(LIMITS[k][0], Math.min(LIMITS[k][1], v));
        r[k] = v;
      } else if (typeof dv === 'boolean') r[k] = !!v;
      else r[k] = String(v);
    }
    if (!hexOk(r.ink)) r.ink = d.ink;
    if (!hexOk(r.accent)) r.accent = d.accent;
    if (r.paper !== '' && !hexOk(r.paper)) r.paper = d.paper;
    r.font = cleanFont(r.font);
    if (kind === 'grid') {
      r.shape = byId(GRID_SHAPES, r.shape).id; r.finish = byId(GRID_FINISHES, r.finish).id;
      if (!NUM_SCHEMES[r.num]) r.num = 'x';
      r.start = Math.round(r.start);
      r.dim = byId(GRID_DIMS, r.dim).id;
      if (r.dfmt !== 'n' && r.dfmt !== 'm' && r.dfmt !== 'u') r.dfmt = 'c';
    } else {
      r.head = byId(LEVEL_HEADS, r.head).id; r.layout = byId(LEVEL_LAYOUTS, r.layout).id;
      if (r.content !== 'nv' && r.content !== 'n' && r.content !== 'v') r.content = 'nv';
      if (r.hc !== 'accent') r.hc = 'ink';
      if (r.fmt !== 'm' && r.fmt !== 'elmm' && r.fmt !== 'elm') r.fmt = 'mm';
      if (r.nm !== 'F' && r.nm !== 'L' && r.nm !== 'KR' && r.nm !== '') r.nm = 'FL';
      r.base = Math.round(r.base);
    }
    r.lp = byId(LINE_PATTERNS, r.lp).id;
    if (r.lc !== 'accent' && r.lc !== 'soft') r.lc = 'ink';
    r.kind = kind; r.v = 1;
    return r;
  }

  /* ================= 번호·이름·값 ================= */
  function alpha(n) {
    var s = '';
    n = Math.max(1, Math.round(n));
    while (n > 0) { var r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26); }
    return s;
  }
  function seqLabel(fmt, n) { return fmt === 'A' ? alpha(n) : fmt.replace('#', String(n)); }
  function gridLabels(st, marks) {
    var pair = NUM_SCHEMES[st.num] || NUM_SCHEMES.x, cnt = [0, 0], tot = [0, 0], out = [], i;
    if (st.swap) pair = [pair[1], pair[0]];
    for (i = 0; i < marks.length; i++) tot[marks[i].ser]++;
    for (i = 0; i < marks.length; i++) {
      var s = marks[i].ser, k = cnt[s]++;
      if (st.rev) k = tot[s] - 1 - k;
      out.push(seqLabel(pair[s], st.start + k));
    }
    return out;
  }
  function group3(n) { var s = String(n), o = ''; while (s.length > 3) { o = ',' + s.slice(-3) + o; s = s.slice(0, -3); } return s + o; }
  // 간격 숫자: c = 8,400 · n = 8400 · m = 8.4m · u = 8.4 (m, 단위 없이)
  function fmtSpan(mm, fmt) {
    var v = Math.max(0, Math.round(mm));
    if (fmt === 'm' || fmt === 'u') { var s = (v / 1000).toFixed(3).replace(/0+$/, ''); if (/\.$/.test(s)) s += '0'; return fmt === 'm' ? s + 'm' : s; }
    return fmt === 'n' ? String(v) : group3(v);
  }
  // 손으로 적은 값 읽기 → mm (숫자가 아니면 null). 8400 · 8,400 · 8.4m · 8.4 모두 8400.
  // 단위가 없으면 100 이상은 mm, 100 미만은 m 로 읽는다 (간격 · 층고에 100 mm 미만은 없으니까). 단위를 붙이면 그대로 (50mm · 120m)
  function parseVal(text) {
    var t = String(text == null ? '' : text).replace(/\s+/g, ''), m = /^(\d[\d,]*(?:\.\d+)?|\.\d+)(mm|m)?$/i.exec(t);
    if (!m) return null;
    var v = parseFloat(m[1].replace(/,/g, '')), u = (m[2] || '').toLowerCase();
    if (!isFinite(v) || !(v > 0)) return null;
    if (u === 'm' || (u === '' && v < 100)) v *= 1000;
    return Math.round(v * 1000) / 1000;
  }
  // 적은 값이 숫자면 고른 표기로, 아니면 적은 글자 그대로
  function fmtTyped(raw, fmt) { var v = parseVal(raw); return v != null ? fmtSpan(v, fmt) : String(raw); }
  // 패널에 보여 줄 글자: 숫자면 mm 로 8,400 처럼, 아니면 적은 글자 그대로
  function mmText(mm) { return group3(Math.round(mm)); }
  function valText(raw) { var v = parseVal(raw); return v != null ? mmText(v) : String(raw == null ? '' : raw); }
  // 한 칸에 여러 값을 적었을 때 칸마다 나눈다 (room = 채울 수 있는 칸 수):
  //   '8400 8400 6000' · '8400, 6000' · '8400,8400,6000' · '8400+6000' · '8400*3 6000' · '3@8400' · 'EQ*3'
  // 쉼표는 앞이 한두 자리 숫자고 뒤가 꼭 세 자리일 때만 천 단위(8,400 · 12,000)로 읽고, 아니면 값을 나누는 표시로 읽는다
  function splitVals(text, room) {
    var out = [], t = String(text == null ? '' : text).replace(/\s*([*x×@])\s*/gi, '$1').replace(/^\s+|\s+$/g, '');
    if (!t || !(room > 0)) return out;
    function push(val, n) { for (var q = 0; q < n && out.length < room; q++) out.push(val); }
    function one(p) {
      var m, cnt = /^\d{1,2}$/;
      if ((m = /^(.+?)[*x×](.+)$/i.exec(p))) {
        if (cnt.test(m[2]) && Number(m[2]) > 0 && (parseVal(m[1]) != null || !/\d/.test(m[1]))) return push(m[1], Number(m[2]));        // 8400*3 · EQ*3
        if (cnt.test(m[1]) && Number(m[1]) > 0 && parseVal(m[2]) != null) return push(m[2], Number(m[1]));                              // 3*8400
      }
      if ((m = /^(\d{1,2})@(.+)$/.exec(p)) && Number(m[1]) > 0 && parseVal(m[2]) != null) return push(m[2], Number(m[1]));             // 3@8400
      push(p, 1);
    }
    var toks = t.split(/[\s\/;+]+/), i, j;
    for (i = 0; i < toks.length && out.length < room; i++) {
      var tok = toks[i];
      if (!tok) continue;
      if (tok.indexOf(',') < 0) { one(tok); continue; }
      var parts = tok.split(',');
      for (j = 0; j < parts.length && out.length < room; j++) {
        var cur = parts[j];
        if (cur === '') continue;
        if (j + 1 < parts.length && /(^|[*x×@])\d{1,2}$/i.test(cur) && /^\d{3}(\D.*)?$/.test(parts[j + 1])) { cur += ',' + parts[j + 1]; j++; }
        one(cur);
      }
    }
    return out;
  }
  // 패널에서 적은 값을 손댄 글자 기록(ov)에 넣는다. ops = [{t:'base', ser, text} | {t:'cell', k, text} | {t:'clear', ks, vs, ts}]
  //   base  모두 같게 (ser: 0 · 1 · 그 밖 = 둘 다, text 가 비면 지움)
  //   cell  k 번째 칸 (축열 = 간격 s · 레벨 = 층고 h, text 가 비면 지움). 그 칸을 문서에서 손으로 고친 글자(d)는 지운다 — 나중에 적은 쪽이 이긴다
  //   clear ks 칸의 적은 값 · 손댄 글자, vs 레벨 값(v), ts 전체 길이(t) 를 지움
  //   wipe  칸마다 적은 값 · 손으로 고친 숫자를 모두 지움 (번호 · 이름 글자와 모두 같게 값은 그대로)
  function applyValueOps(kind, ov, ops) {
    var key = kind === 'level' ? 'h' : 's', i, j;
    ov = ov || {};
    function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
    function cell(k) { if (!ov[k] || typeof ov[k] !== 'object') ov[k] = {}; return ov[k]; }
    function tidy(k) { var c = ov[k], q; if (!c) return; for (q in c) if (own(c, q)) return; delete ov[k]; }
    function drop(k, names) { var c = ov[k], q; if (!c || typeof c !== 'object') return; for (q = 0; q < names.length; q++) delete c[names[q]]; tidy(k); }
    for (i = 0; i < (ops || []).length; i++) {
      var op = ops[i], tx = op.text == null ? '' : String(op.text).replace(/^\s+|\s+$/g, '');
      if (op.t === 'base') {
        var sers = kind === 'level' ? [0] : (op.ser === 1 || op.ser === '1' ? [1] : op.ser === 0 || op.ser === '0' ? [0] : [0, 1]);
        for (j = 0; j < sers.length; j++) { if (tx === '') delete ov['B' + sers[j]]; else ov['B' + sers[j]] = { v: tx }; }
      } else if (op.t === 'cell' && op.k != null && Number(op.k) >= 0) {
        var c = cell(Number(op.k));
        if (tx === '') delete c[key]; else c[key] = tx;
        if (kind !== 'level') delete c.d;
        tidy(Number(op.k));
      } else if (op.t === 'clear') {
        for (j = 0; j < (op.ks || []).length; j++) drop(op.ks[j], kind === 'level' ? ['h'] : ['s', 'd']);
        for (j = 0; j < (op.vs || []).length; j++) drop(op.vs[j], ['v']);
        for (j = 0; j < (op.ts || []).length; j++) drop(op.ts[j], ['t']);
      } else if (op.t === 'wipe') {
        var keys = [], q2;
        for (q2 in ov) if (own(ov, q2) && /^\d+$/.test(q2)) keys.push(q2);
        for (j = 0; j < keys.length; j++) drop(keys[j], kind === 'level' ? ['h', 'v'] : ['s', 'd', 't']);
      }
    }
    return ov;
  }
  function fmtValue(mm, fmt) {
    var v = Math.round(mm), sign = v > 0 ? '+' : v < 0 ? '−' : '±', a = Math.abs(v), body;
    if (fmt === 'm' || fmt === 'elm') {
      var m = a / 1000;
      if (fmt === 'elm') body = m.toFixed(3);
      else { body = m.toFixed(3).replace(/0+$/, ''); if (/\.$/.test(body)) body += '0'; }
      if (a === 0 && fmt === 'm') body = '0';
    } else body = group3(a);
    var s = sign + body;
    if (fmt === 'm') s += 'm';
    if (fmt === 'elmm' || fmt === 'elm') s = 'EL ' + s;
    return s;
  }
  // rel = 기준(±0)에서 몇 번째 위인지 (0 = 기준, 음수 = 지하). top = 맨 위 점인지
  function levelName(st, rel, top, nAbove) {
    var nm = st.nm;
    if (!nm) return '';
    var gl = !!st.gl, floor = gl ? rel : rel + 1;            // GL 기준이면 그 위가 1층
    if (gl && rel === 0) return 'GL';
    if (rel < 0) {
      var b = -rel;
      return nm === 'KR' ? '지하' + b + '층' : nm === 'L' ? 'B' + b : 'B' + b + nm;
    }
    if (top && st.rf && nAbove >= 2) return nm === 'KR' ? '지붕' : nm === 'FL' ? 'RFL' : 'RF';
    return nm === 'KR' ? floor + '층' : nm === 'L' ? 'L' + floor : floor + nm;
  }

  /* ================= 축열 ================= */
  function orthoSnap(v) {
    var a = Math.atan2(v[1], v[0]) * 180 / Math.PI, q = Math.round(a / 90) * 90;
    if (Math.abs(a - q) <= 5) { var r = q * Math.PI / 180; return [Math.round(Math.cos(r)), Math.round(Math.sin(r))]; }
    return v;
  }
  function preferDown(u) { return (u[1] < -1e-6 || (Math.abs(u[1]) <= 1e-6 && u[0] < 0)) ? [-u[0], -u[1]] : u; }
  function serOf(u) { return Math.abs(u[1]) >= Math.abs(u[0]) ? 0 : 1; }     // 0 = 세로선, 1 = 가로선

  function gridMarks(st, src) {
    var marks = [], i;
    if (src.mode === 'lines') {
      for (i = 0; i < src.lines.length; i++) {
        var l = src.lines[i], d = unit(l[2] - l[0], l[3] - l[1]), u0 = preferDown(d);
        var headA = (u0[0] === d[0] && u0[1] === d[1]), p = headA ? [l[0], l[1]] : [l[2], l[3]], q = headA ? [l[2], l[3]] : [l[0], l[1]];
        var mid = [(l[0] + l[2]) / 2, (l[1] + l[3]) / 2], key = mid[0] * u0[1] - mid[1] * u0[0];
        var mk = { mode: 'ln', ser: serOf(u0), key: key, src: i };
        if (st.flip) { mk.p = q; mk.q = p; mk.u = [-u0[0], -u0[1]]; } else { mk.p = p; mk.q = q; mk.u = u0; }
        marks.push(mk);
      }
      marks.sort(function (a, b) { return a.ser - b.ser || a.key - b.key || a.src - b.src; });
      return marks;
    }
    var pts = src.pts, n = pts.length, v = [1, 0];
    if (n > 1) {
      var dx = pts[n - 1][0] - pts[0][0], dy = pts[n - 1][1] - pts[0][1];
      if (dx * dx + dy * dy > 1e-9) v = orthoSnap(unit(dx, dy));
    }
    var u = preferDown([-v[1], v[0]]);
    if (st.flip) u = [-u[0], -u[1]];
    for (i = 0; i < n; i++) {
      var c = [pts[i][0], pts[i][1]], raw = [pts[i][0], pts[i][1]];
      if (st.align && n > 1) { var t = (c[0] - pts[0][0]) * v[0] + (c[1] - pts[0][1]) * v[1]; c = [pts[0][0] + v[0] * t, pts[0][1] + v[1] * t]; }
      marks.push({ mode: 'pt', c: c, raw: raw, u: u, ser: serOf(u), src: i });
    }
    return marks;
  }

  // 머리 모양의 외곽(베지어). u = 선이 나가는 방향, inset = 안쪽으로 줄이기
  function gridHull(env, u, inset) {
    var R = env.R, id = env.shape.id, ang = Math.atan2(u[1], u[0]), pts;
    inset = inset || 0;
    if (id === 'circle') return circlePts(0, 0, Math.max(0.01, R - inset));
    if (id === 'hex') pts = polyPts(ngon(6, R * 1.1, 0, inset));
    else if (id === 'oct') return polyPts(ngon(8, R * 1.06, Math.PI / 8, inset));
    else if (id === 'square') return polyPts(ngon(4, R * 0.9 * Math.SQRT2, Math.PI / 4, inset));
    else if (id === 'rsquare') return superPts(0, 0, Math.max(0.01, R * 0.97 - inset), 0.83);
    else if (id === 'diamond') pts = polyPts(ngon(4, R * 1.24, 0, inset));
    else if (id === 'pill') return rrectPts(0, 0, Math.max(0.01, env.hw - inset), Math.max(0.01, env.hh - inset), Math.max(0.01, env.hh - inset));
    else if (id === 'drop') pts = dropPts(Math.max(0.01, R * 0.94 - inset), 1.6);
    else if (id === 'tag') {
      var d = env.tagDims(u), A = d[0], Cw = d[1], ap = Cw * 0.4;
      pts = polyPts(offsetPoly([[-A / 2, -Cw / 2], [A / 2, -Cw / 2], [A / 2 + ap, 0], [A / 2, Cw / 2], [-A / 2, Cw / 2]], inset));
    } else return circlePts(0, 0, Math.max(0.01, R - inset));
    return rotPts(pts, ang);
  }

  function gridEnv(st, labels, M, dirs) {
    var S = st.size * PT, R = S / 2, w = st.sw, shape = byId(GRID_SHAPES, st.shape), fin = shape.closed ? st.finish : 'line';
    var bold = fin === 'solid' || fin === 'accent' || fin === 'badge' || fin === 'bold';
    var paper = st.paper || null, white = paper || '#FFFFFF';
    var env = { st: st, S: S, R: R, w: w, shape: shape, fin: fin, bold: bold, paper: paper, white: white, M: M };
    function maxW(f) { var m = 0; for (var i = 0; i < labels.length; i++) m = Math.max(m, M.measure(labels[i], f, bold)); return m; }
    env.maxW = maxW;
    // 표현마다 굵기·안쪽 여유
    env.wo = fin === 'bold' ? Math.max(2.6 * w, 0.085 * R) : fin === 'double' ? 1.9 * w : w;       // 바깥 선 굵기
    env.outer = (env.wo - w) / 2;                                                                  // 바깥 크기를 다른 표현과 같게
    env.wi = 0.75 * w;
    env.dblIn = env.outer + Math.max(0.085 * R, 1.1 * w) + env.wo / 2 + env.wi / 2;
    env.badgeIn = Math.max(0.19 * R, 2.4 * w);
    var fitIn = fin === 'double' ? env.dblIn + env.wi / 2 : fin === 'badge' ? env.badgeIn : fin === 'bold' ? env.outer + env.wo / 2 : (fin === 'solid' || fin === 'accent') ? 0 : w / 2;
    var ts = st.ts / 100;
    if (shape.auto) {
      var f = 0.42 * S;
      env.f0 = f; env.f = f * ts;
      var tw = maxW(env.f), cap = M.cap * env.f;
      env.tw = tw; env.cap = cap;
      if (shape.id === 'pill') { env.hh = Math.max(0.42 * S, cap / 2 + 0.2 * S); env.hw = Math.max(env.hh * 1.45, tw / 2 + env.hh * 0.62); }
      if (shape.id === 'tag') {
        var px = 0.2 * S, py = 0.21 * S, minD = 0.84 * S;
        env.tagDims = function (u) {
          var ax = Math.abs(u[0]), ay = Math.abs(u[1]);
          return [Math.max(minD, ax * (tw + 2 * px) + ay * (cap + 2 * py)), Math.max(minD, ay * (tw + 2 * px) + ax * (cap + 2 * py))];
        };
      }
      if (shape.id === 'corners') { env.hy = Math.max(0.42 * S, cap / 2 + 0.2 * S); env.hx = Math.max(env.hy, tw / 2 + 0.2 * S); }
      if (shape.id === 'bracket') { env.hy = Math.max(0.4 * S, cap / 2 + 0.17 * S); env.hx = Math.max(0.3 * S, tw / 2 + 0.15 * S); }
    } else {
      // 가장 넓은 번호가 모양 안에 들어가는 글자 크기 (묶음 전체가 같은 크기)
      var f0 = shape.k * S, minF = 0.2 * S, pad = 0.085 * S;
      for (var di = 0; di < dirs.length; di++) {
        var poly = flatten(gridHull(env, dirs[di], fitIn), true, 12), ff = f0;
        for (var it = 0; it < 40; it++) {
          var cp = M.cap * ff, half = Math.min(halfSpanAt(poly, -cp / 2), halfSpanAt(poly, cp / 2));
          if (maxW(ff) <= 2 * (half - pad) || ff <= minF) break;
          ff *= 0.96;
        }
        f0 = Math.min(f0, Math.max(minF, ff));
      }
      env.f0 = f0; env.f = f0 * ts; env.cap = M.cap * env.f; env.tw = maxW(env.f);
    }
    return env;
  }

  // 기호 돌리기(turn): 축선이 옆으로 뻗으면 기호를 글자째 90° 돌린다 (글자는 아래에서 위로 읽힘 — 세로 줄 간격 숫자와 같은 쪽).
  // 세로 축선용 기호를 그대로 그린 다음(headDir = 그때의 축선 방향) 가운데를 축으로 돌리므로 핀 · 태그 · 캡슐도 모양째 돈다
  function headTurned(st, u) { return !!st.turn && Math.abs(u[0]) > 0.92; }
  function headDir(st, u) { return headTurned(st, u) ? [-u[1], u[0]] : u; }
  function gridHead(items, env, c, u, label, gi, idx) {
    if (!headTurned(env.st, u)) return gridHead0(items, env, c, u, label, gi, idx);
    var local = [], exit, i, it;
    env.turned = true;
    try { exit = gridHead0(local, env, [0, 0], headDir(env.st, u), label, gi, idx); } finally { env.turned = false; }
    function tr(x, y) { return [c[0] + y, c[1] - x]; }           // 화면에서 반시계 90°
    for (i = 0; i < local.length; i++) {
      it = local[i];
      if (it.t === 'text') { var q = tr(it.x, it.y); it.x = q[0]; it.y = q[1]; it.rot = (it.rot || 0) - 90; }
      else it.pts = mapPts(it.pts, tr);
      items.push(it);
    }
    return exit;
  }
  // 머리 하나. 돌려주는 값 = 가운데에서 선이 시작할 자리까지 거리
  function gridHead0(items, env, c, u, label, gi, idx) {
    var st = env.st, R = env.R, w = env.w, ink = st.ink, acc = st.accent, paper = env.paper, white = env.white, id = env.shape.id, fin = env.fin;
    var f = env.f, cap = env.cap, tfill = ink, exit, H, i;
    function at(pts) { return movePts(pts, c[0], c[1]); }
    // 화면 기준 방향(그림자는 오른쪽 아래 · 점은 오른쪽 위)을 돌리기 전 자리로 — 돌린 뒤에도 같은 쪽에 오게
    function scr(v) { return env.turned ? [-v[1], v[0]] : v; }
    function label_(x, y, align, fill) {
      items.push(T(x, y, label, { size: f, bold: env.bold, fill: fill || tfill, align: align || 'center', gi: gi, role: 'l', idx: idx, name: label }));
    }
    if (env.shape.closed) {
      H = gridHull(env, u, env.outer);
      var poly = flatten(H, true, 12);
      exit = rayExit(poly, u[0], u[1]) + env.wo / 2;
      if (fin === 'solid' || fin === 'accent') {
        var col = fin === 'accent' ? acc : ink;
        items.push(P(at(H), { fill: col, stroke: col, sw: w, gi: gi, name: '머리' }));
        tfill = onColor(col, paper);
      } else if (fin === 'double') {
        items.push(P(at(H), { fill: paper, stroke: ink, sw: env.wo, gi: gi, name: '머리' }));
        items.push(P(at(gridHull(env, u, env.dblIn)), { stroke: ink, sw: env.wi, gi: gi, name: '안쪽 선' }));
      } else if (fin === 'badge') {
        items.push(P(at(H), { fill: paper, stroke: ink, sw: w, gi: gi, name: '머리' }));
        items.push(P(at(gridHull(env, u, env.badgeIn)), { fill: ink, gi: gi, name: '속' }));
        tfill = onColor(ink, paper);
      } else if (fin === 'shadow') {
        var off = 0.17 * R, so = scr([off, off]);
        items.push(P(movePts(H, c[0] + so[0], c[1] + so[1]), { fill: acc, gi: gi, name: '그림자' }));
        items.push(P(at(H), { fill: white, stroke: ink, sw: w, gi: gi, name: '머리' }));
      } else if (fin === 'soft') {
        items.push(P(at(H), { fill: mix(acc, white, 0.86), stroke: acc, sw: w, gi: gi, name: '머리' }));
      } else if (fin === 'bold') {
        items.push(P(at(H), { fill: paper, stroke: ink, sw: env.wo, gi: gi, name: '머리' }));
      } else if (fin === 'dash') {
        var dd = fitDashClosed(perimeter(poly, true), Math.max(0.2 * R, 2.2 * w), Math.max(0.14 * R, 1.6 * w), env.shape.sides, env.shape.att, arcAtRay(poly, u[0], u[1]));
        items.push(P(at(H), { fill: paper, stroke: ink, sw: w, dash: dd.dash, dashOff: dd.off, gi: gi, name: '머리' }));
      } else if (fin === 'cline') {
        items.push(P(at(H), { fill: paper, stroke: acc, sw: w, gi: gi, name: '머리' }));
      } else if (fin === 'spot') {
        items.push(P(at(H), { fill: paper, stroke: ink, sw: w, gi: gi, name: '머리' }));
        var sd = scr([0.7071, -0.7071]), se = rayExit(poly, sd[0], sd[1]), sr = Math.max(0.23 * R, 2.2 * w);
        items.push(P(movePts(circlePts(0, 0, sr), c[0] + sd[0] * se, c[1] + sd[1] * se), { fill: acc, stroke: white, sw: Math.max(0.07 * R, 0.9 * w), gi: gi, name: '점' }));
      } else {
        items.push(P(at(H), { fill: paper, stroke: ink, sw: w, gi: gi, name: '머리' }));
        if (fin === 'ticks') {
          var dirs4 = [[1, 0], [0, 1], [-1, 0], [0, -1]], tl = 0.3 * R;
          for (i = 0; i < 4; i++) {
            var dv = dirs4[i];
            if (dv[0] * u[0] + dv[1] * u[1] > 0.98) continue;            // 축선이 나가는 쪽은 선이 대신함
            var e0 = rayExit(poly, dv[0], dv[1]) + w / 2;
            items.push(LN(c[0] + dv[0] * e0, c[1] + dv[1] * e0, c[0] + dv[0] * (e0 + tl), c[1] + dv[1] * (e0 + tl), { stroke: ink, sw: w, gi: gi, name: '눈금' }));
          }
        }
      }
      label_(c[0], c[1] + cap / 2);
      return exit;
    }
    // 열린 모양
    var hx = env.hx, hy = env.hy, vx = -u[1], vy = u[0];
    if (id === 'corners') {
      var arm = Math.min(0.24 * env.S, hy * 0.62), wc = 1.15 * w, sx = [-1, 1, 1, -1], sy = [-1, -1, 1, 1];
      for (i = 0; i < 4; i++) {
        items.push(P([C(c[0] + sx[i] * (hx - arm), c[1] + sy[i] * hy), C(c[0] + sx[i] * hx, c[1] + sy[i] * hy), C(c[0] + sx[i] * hx, c[1] + sy[i] * (hy - arm))],
          { closed: false, stroke: ink, sw: wc, join: 'miter', gi: gi, name: '코너' }));
      }
      label_(c[0], c[1] + cap / 2);
      return rayExit([[-hx, -hy], [hx, -hy], [hx, hy], [-hx, hy]], u[0], u[1]) + wc / 2;
    }
    if (id === 'bracket') {
      var ret = 0.13 * env.S, wb = 1.15 * w;
      for (i = -1; i <= 1; i += 2) {
        items.push(P([C(c[0] + i * (hx - ret), c[1] - hy), C(c[0] + i * hx, c[1] - hy), C(c[0] + i * hx, c[1] + hy), C(c[0] + i * (hx - ret), c[1] + hy)],
          { closed: false, stroke: ink, sw: wb, join: 'miter', gi: gi, name: '괄호' }));
      }
      label_(c[0], c[1] + cap / 2);
      return rayExit([[-hx, -hy], [hx, -hy], [hx, hy], [-hx, hy]], u[0], u[1]) + wb / 2;
    }
    // 막대·도트·글자만: 글자는 선 반대쪽에
    var tg, bw = 0, rd = 0;
    if (id === 'bar') {
      bw = Math.max(2.8 * w, 0.075 * env.S);
      var bl = Math.max(0.78 * env.S, 0);
      items.push(LN(c[0] - vx * bl / 2, c[1] - vy * bl / 2, c[0] + vx * bl / 2, c[1] + vy * bl / 2, { stroke: ink, sw: bw, gi: gi, name: '막대' }));
      tg = bw / 2 + 0.15 * env.S; exit = bw / 2;
    } else if (id === 'dot') {
      rd = Math.max(0.1 * env.S, 1.6 * w);
      items.push(P(at(circlePts(0, 0, rd)), { fill: ink, gi: gi, name: '도트' }));
      tg = rd + 0.15 * env.S; exit = rd * 0.6;
    } else { tg = 0.12 * env.S; exit = 0; }
    var ax = Math.abs(u[0]), ay = Math.abs(u[1]);
    if (ax > 0.92) {            // 가로선: 글자를 옆에, 정렬로 붙임 (폭 계산 오차와 상관없이 간격이 일정)
      label_(c[0] - u[0] * tg, c[1] + cap / 2, u[0] > 0 ? 'right' : 'left');
    } else {
      var myW = env.M.measure(label, f, env.bold), ext = ax * myW / 2 + ay * cap / 2;
      label_(c[0] - u[0] * (tg + ext), c[1] - u[1] * (tg + ext) + cap / 2, 'center');
    }
    return exit;
  }

  function lineStyle(st, S) {
    var white = st.paper || '#FFFFFF';
    return { color: st.lc === 'accent' ? st.accent : st.lc === 'soft' ? mix(st.ink, white, 0.55) : st.ink, w: Math.max(0.05, st.sw * st.lw / 100) };
  }

  // 머리가 읽는 방향(r)으로 차지하는 반 폭 — 기호 사이를 잇는 선이 시작할 자리
  function lateralExt(probe, r) {
    var m = 0, i, j;
    for (i = 0; i < probe.length; i++) {
      var it = probe[i];
      if (it.t !== 'path') continue;
      var fl = flatten(it.pts, it.closed, 8), e = it.stroke ? it.sw / 2 : 0;
      for (j = 0; j < fl.length; j++) m = Math.max(m, Math.abs(fl[j][0] * r[0] + fl[j][1] * r[1]) + e);
    }
    return m;
  }
  // 치수 한 줄. pts = 읽는 방향 순서의 자리들, labels = 사이마다 글자, ends = (기호 사이) 머리 가운데에서 선이 시작할 자리까지 거리
  // o = { r: 읽는 방향, n: 글자 위쪽, rot, S, w, col, ink, paper, M, fs, gi }
  function dimRow(items, pts, labels, id, o, role, idx0, ends) {
    var r = o.r, n = o.n, S = o.S, w = o.w, fs = o.fs, M = o.M, cap = M.cap * fs, N = pts.length, k, i;
    var ext = 0.2 * S, above = 0.07 * S + w / 2, center = -cap / 2, pad = 0.13 * S, bh = 0.15 * S, rd = Math.max(0.062 * S, 1.4 * w);
    function at(p, a, b) { return [p[0] + r[0] * a + n[0] * b, p[1] + r[1] * a + n[1] * b]; }      // p 에서 읽는 방향으로 a, 위로 b
    function line(a, b, sw, nm) { items.push(LN(a[0], a[1], b[0], b[1], { stroke: o.col, sw: sw || w, gi: o.gi, name: nm || '치수선' })); }
    function txt(p, s, idx, up) {
      var q = at(p, 0, up);
      items.push(T(q[0], q[1], s, { size: fs, fill: o.ink, align: 'center', gi: o.gi, role: role, idx: idx, rot: o.rot, name: s }));
    }
    function dot(p) { items.push(P(movePts(circlePts(0, 0, rd), p[0], p[1]), { fill: o.col, gi: o.gi, name: '점' })); }
    function dist(a, b) { return (b[0] - a[0]) * r[0] + (b[1] - a[1]) * r[1]; }
    function mid(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; }
    if (id === 'num') { for (k = 0; k < N - 1; k++) txt(mid(pts[k], pts[k + 1]), labels[k], idx0 + k, center); return; }
    if (id === 'link') {
      for (k = 0; k < N - 1; k++) {
        var a = at(pts[k], ends[k], 0), b = at(pts[k + 1], -ends[k + 1], 0), len = dist(a, b), m = mid(a, b), tw = M.measure(labels[k], fs, false);
        if (len <= 0.02 * S) { txt(mid(pts[k], pts[k + 1]), labels[k], idx0 + k, above); continue; }
        if (len >= tw + 2 * pad + 0.3 * S) { line(a, at(m, -tw / 2 - pad, 0)); line(at(m, tw / 2 + pad, 0), b); txt(m, labels[k], idx0 + k, center); }
        else { line(a, b); txt(m, labels[k], idx0 + k, above); }
      }
      return;
    }
    var A = pts[0], B = pts[N - 1];
    if (id === 'tick' || id === 'dot') line(at(A, -ext, 0), at(B, ext, 0));
    else if (id === 'bar') line(A, B);
    for (k = 0; k < N - 1; k++) {
      var p = pts[k], q = pts[k + 1], L = dist(p, q), c = mid(p, q), tw2 = M.measure(labels[k], fs, false), idx = idx0 + k;
      if (id === 'arrow') {
        var al = 0.27 * S, ah = 0.085 * S;
        if (L >= 3.2 * al) {
          var p1 = at(p, al, ah), p2 = at(p, al, -ah), q1 = at(q, -al, ah), q2 = at(q, -al, -ah);
          items.push(P([C(p[0], p[1]), C(p1[0], p1[1]), C(p2[0], p2[1])], { fill: o.col, gi: o.gi, name: '화살촉' }));
          items.push(P([C(q[0], q[1]), C(q1[0], q1[1]), C(q2[0], q2[1])], { fill: o.col, gi: o.gi, name: '화살촉' }));
          line(at(p, al * 0.8, 0), at(q, -al * 0.8, 0));
        } else { line(p, q); dot(p); dot(q); }                     // 너무 좁으면 화살촉 대신 점
        txt(c, labels[k], idx, above);
      } else if (id === 'cut') {
        if (L >= tw2 + 2 * pad + 0.36 * S) { line(p, at(c, -tw2 / 2 - pad, 0)); line(at(c, tw2 / 2 + pad, 0), q); txt(c, labels[k], idx, center); }
        else { line(p, q); txt(c, labels[k], idx, above); }
      } else if (id === 'pill') {
        var hh = cap / 2 + 0.11 * S, hw = Math.max(tw2 / 2 + 0.16 * S, hh * 1.25);
        if (L >= 2 * hw + 0.3 * S) {
          line(p, at(c, -hw, 0)); line(at(c, hw, 0), q);
          items.push(P(movePts(rotPts(rrectPts(0, 0, hw, hh, hh), o.rot * Math.PI / 180), c[0], c[1]), { fill: o.paper, stroke: o.col, sw: w, gi: o.gi, name: '캡슐' }));
          txt(c, labels[k], idx, center);
        } else { line(p, q); txt(c, labels[k], idx, above); }
      } else txt(c, labels[k], idx, above);                       // 사선 · 점 · 끝선
    }
    for (i = 0; i < N; i++) {
      var e = pts[i];
      if (id === 'tick') {
        var h = 0.12 * S, t0 = at(e, -h, -h), t1 = at(e, h, h);
        items.push(LN(t0[0], t0[1], t1[0], t1[1], { stroke: o.col, sw: Math.max(2 * w, 0.034 * S), gi: o.gi, name: '사선' }));
      } else if (id === 'dot' || id === 'pill') dot(e);
      else if (id === 'bar') line(at(e, 0, -bh), at(e, 0, bh), Math.max(2.8 * w, 0.055 * S), '끝선');      // 축선과 겹치는 자리라 굵게 해야 보인다
      else if (id === 'cut') line(at(e, 0, -bh), at(e, 0, bh), null, '끝선');
    }
  }
  // 축열 사이 간격 숫자. 세로선 무리 · 가로선 무리마다 한 줄(전체 길이를 켜면 두 줄).
  // 칸의 글자 = 문서에서 손으로 고친 글자(ov[k].d) > 패널에서 그 칸에 적은 값(ov[k].s) > 모두 같게(ov.B0 · ov.B1 의 v — 무리마다) > 거리 × 축척(칸마다 반올림).
  // 일러스트 도면은 치수가 딱 떨어지지 않아서 대부분 적은 값을 쓴다 — 거리로 어림한 값은 아무것도 안 적었을 때만.
  // 전체 길이 = 칸에 보이는 값의 합 (숫자가 아닌 칸은 어림한 값으로). auto 에는 '도구가 스스로 적는 글자'(적은 값 포함)를 남겨서 문서에서 손댄 글자만 가려낸다.
  // 번호: 간격 글자는 d(무리를 이어 0, 1, 2 …), 전체 길이는 t(무리 0, 1)
  function gridDims(st, marks, info, env, M, ov, ls, unitScale, names) {
    var S = env.S, items = [], autoD = [], autoT = [], spanInfo = [], sums = [], gi = marks.length, sers = [[], []], i, s;
    for (i = 0; i < marks.length; i++) sers[marks[i].ser ? 1 : 0].push(i);
    var fs = 0.3 * S * st.ts / 100, cap = M.cap * fs, kmm = unitScale != null ? unitScale : st.scale / PT, rnd = Math.max(1, st.dround);
    var pitch = cap + 0.42 * S, dN = 0, tN = 0;
    for (s = 0; s < 2; s++) {
      var ids = sers[s];
      if (ids.length < 2) continue;
      var ux = 0, uy = 0;
      for (i = 0; i < ids.length; i++) { ux += info[ids[i]].u[0]; uy += info[ids[i]].u[1]; }
      var U = unit(ux, uy), r = [-U[1], U[0]];
      if (r[0] < -1e-6 || (Math.abs(r[0]) <= 1e-6 && r[1] > 0)) r = [-r[0], -r[1]];            // 읽는 방향: 왼 → 오, 세로면 아래 → 위
      var n = [r[1], -r[0]], rot = Math.atan2(r[1], r[0]) * 180 / Math.PI;
      if (Math.abs(rot) < 0.01) rot = 0;
      var along = function (q) { return q[0] * r[0] + q[1] * r[1]; }, deep = function (q) { return q[0] * U[0] + q[1] * U[1]; };
      var order = ids.slice().sort(function (a, b) { return along(info[a].c) - along(info[b].c) || a - b; });
      var R0 = -Infinity;
      for (i = 0; i < order.length; i++) R0 = Math.max(R0, deep(info[order[i]].a));
      R0 += st.dgap * PT;
      var rowPts = function (R) {
        var out = [];
        for (var j = 0; j < order.length; j++) {
          var I = info[order[j]], den = I.u[0] * U[0] + I.u[1] * U[1], tt = (R - deep(I.a)) / (Math.abs(den) < 1e-6 ? 1 : den);
          out.push([I.a[0] + I.u[0] * tt, I.a[1] + I.u[1] * tt]);
        }
        return out;
      };
      var draw = st.dim !== 'none', link = st.dim === 'link', withTot = draw && st.dtot && order.length > 2;
      var Pb = rowPts(R0 + (withTot && !link ? pitch : 0)), labels = [], idx0 = dN, sumMm = 0, sumExact = true;
      var bEnt = ov && ov['B' + s], baseRaw = bEnt && bEnt.v != null && String(bEnt.v) !== '' ? String(bEnt.v) : null;
      for (i = 0; i < Pb.length - 1; i++) {
        var dist = along(Pb[i + 1]) - along(Pb[i]), autoMm = Math.round(dist * kmm / rnd) * rnd, autoTx = fmtSpan(autoMm, st.dfmt);
        var e = ov && ov[dN] ? ov[dN] : null, typed = e && e.s != null && String(e.s) !== '' ? String(e.s) : null, hand = e && e.d != null ? String(e.d) : null;
        var own = typed != null ? typed : baseRaw, ownTx = own != null ? fmtTyped(own, st.dfmt) : autoTx;      // 도구가 스스로 적는 글자
        var text = hand != null ? hand : ownTx, mm = hand != null ? parseVal(hand) : own != null ? parseVal(own) : autoMm;      // 숫자로 못 읽으면 null
        autoD[dN] = ownTx;
        spanInfo.push({ k: dN, ser: s, a: names[order[i]], b: names[order[i + 1]], dist: dist, auto: autoTx, autoMm: autoMm,
          typed: typed, base: typed == null ? baseRaw : null, hand: hand, text: text, mm: mm });
        labels.push(text);
        sumMm += mm != null ? mm : autoMm;
        if (mm == null) sumExact = false;
        dN++;
      }
      var o = { r: r, n: n, rot: rot, S: S, w: ls.w, col: ls.color, ink: st.ink, paper: env.paper, M: M, fs: fs, gi: gi };
      if (!draw) { /* 간격 숫자를 꺼 뒀으면 그리지 않고 칸 정보만 */ }
      else if (link) {
        // 머리끼리 잇기는 머리가 한 줄에 서 있을 때만 — 아니면 '선 사이' 모양으로
        var cs = [], es = [], lo = Infinity, hi = -Infinity;
        for (i = 0; i < order.length; i++) {
          var I2 = info[order[i]], dc = deep(I2.c);
          lo = Math.min(lo, dc); hi = Math.max(hi, dc);
          cs.push(I2.c); es.push(lateralExt(I2.probe, r) + 0.1 * S);
        }
        if (hi - lo <= 0.03 * S) dimRow(items, cs, labels, 'link', o, 'd', idx0, es);
        else dimRow(items, Pb, labels, 'cut', o, 'd', idx0, null);
      } else dimRow(items, Pb, labels, st.dim, o, 'd', idx0, null);
      var tv = fmtSpan(sumMm, st.dfmt);
      sums.push({ ser: s, k0: idx0, n: Pb.length - 1, text: tv, mm: sumMm, exact: sumExact, base: baseRaw });
      if (withTot) {
        var Pt = rowPts(R0);
        autoT[tN] = tv;
        dimRow(items, [Pt[0], Pt[Pt.length - 1]], [ov && ov[tN] && ov[tN].t != null ? String(ov[tN].t) : tv], link ? 'cut' : st.dim, o, 't', tN, null);
      }
      tN++;
    }
    return { items: items, d: autoD, t: autoT, spanInfo: spanInfo, sums: sums };
  }

  function buildGrid(st, src, M, ov, opt) {
    var marks = gridMarks(st, src), auto = gridLabels(st, marks), labels = auto.slice(), i, items = [], S = st.size * PT, info = [];
    if (ov) for (i = 0; i < labels.length; i++) if (ov[i] && ov[i].l != null) labels[i] = String(ov[i].l);
    var dirs = [], seen = {};
    for (i = 0; i < marks.length; i++) {
      var u = marks[i].u, key = Math.round(u[0] * 1000) + ',' + Math.round(u[1] * 1000);
      if (!seen[key]) { seen[key] = 1; dirs.push(headDir(st, u)); }
      // 반대쪽 머리(양끝)도 같은 글자 크기가 되게 같이 본다
      var kk = (-Math.round(u[0] * 1000)) + ',' + (-Math.round(u[1] * 1000));
      if (!seen[kk]) { seen[kk] = 1; dirs.push(headDir(st, [-u[0], -u[1]])); }
    }
    if (!dirs.length) dirs.push([0, 1]);
    var env = gridEnv(st, labels, M, dirs), ls = lineStyle(st, S), gap = st.gap * PT, L = st.len * PT, skel = [], lineItems = [], headItems = [], snap = 0;
    for (i = 0; i < marks.length; i++) {
      var m = marks[i], uu = m.u, c, c2, a, b, probe = [];
      // 선이 붙는 자리(exit)는 머리를 한 번 그려 봐야 안다
      var exit = gridHead(probe, env, [0, 0], uu, labels[i], i, i);
      if (m.mode === 'ln') {
        a = m.p; b = m.q;
        c = [a[0] - uu[0] * (gap + exit), a[1] - uu[1] * (gap + exit)];
        skel.push([a[0], a[1], b[0], b[1]]);
      } else {
        c = m.c;
        a = [c[0] + uu[0] * (exit + gap), c[1] + uu[1] * (exit + gap)];
        b = [a[0] + uu[0] * L, a[1] + uu[1] * L];
        // 기준점은 찍은 자리 그대로 적는다 — '한 줄로 맞춤'을 나중에 꺼도 찍은 자리로 돌아갈 수 있게 (맞춤은 그릴 때마다 다시 계산)
        skel.push([m.raw[0], m.raw[1]]);
        snap = Math.max(snap, Math.sqrt((c[0] - m.raw[0]) * (c[0] - m.raw[0]) + (c[1] - m.raw[1]) * (c[1] - m.raw[1])));
      }
      info.push({ c: c, a: a, u: uu, probe: probe });
      var len = Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]));
      if (st.lp !== 'none' && len > 0.01) {
        var fd = fitDash(st.lp, len, S, st.ds);
        lineItems.push(LN(a[0], a[1], b[0], b[1], { stroke: ls.color, sw: st.lp === 'dot' ? Math.max(ls.w, 0.06 * S) : ls.w, dash: fd.dash, cap: fd.cap, gi: i, name: '축선' }));
      }
      gridHead(headItems, env, c, uu, labels[i], i, i);
      if (st.both && (m.mode === 'ln' || L > 0.01)) {
        var back = [-uu[0], -uu[1]], ex2 = gridHead([], env, [0, 0], back, labels[i], i, i);
        c2 = [b[0] + uu[0] * (gap + ex2), b[1] + uu[1] * (gap + ex2)];
        gridHead(headItems, env, c2, back, labels[i], i, i);
      }
    }
    var names = [], autoArr = autoWrap(auto, 'l'), dimItems = [], spanInfo = [], sums = [];
    for (i = 0; i < labels.length; i++) names.push(labels[i]);
    if (marks.length > 1) {
      var dm = gridDims(st, marks, info, env, M, ov, ls, opt && opt.unitScale, labels);
      spanInfo = dm.spanInfo; sums = dm.sums;                    // 칸 정보는 간격 숫자를 꺼 둔 때도 (패널이 칸을 보여 주고 축척을 잴 수 있게)
      if (st.dim !== 'none') {
        dimItems = dm.items;
        for (i = 0; i < dm.d.length; i++) if (dm.d[i] != null && autoArr[i]) autoArr[i].d = dm.d[i];
        for (i = 0; i < dm.t.length; i++) if (dm.t[i] != null && autoArr[i]) autoArr[i].t = dm.t[i];
        if (dimItems.length) names.push('간격 숫자');
      }
    }
    items = lineItems.concat(dimItems, headItems);
    return { kind: 'grid', items: items, auto: autoArr, names: names, n: marks.length, snap: snap, spanInfo: spanInfo, sums: sums,
      skel: { mode: src.mode === 'lines' ? 'lines' : 'points', data: skel }, order: marks.map(function (m) { return m.src; }) };
  }
  function autoWrap(list, role) { var o = []; for (var i = 0; i < list.length; i++) { var e = {}; e[role] = list[i]; o.push(e); } return o; }

  /* ================= 레벨 ================= */
  function levelMarks(st, src) {
    var marks = [], i, d = st.flip ? -1 : 1;
    if (src.mode === 'lines') {
      for (i = 0; i < src.lines.length; i++) {
        // 왼쪽 끝 고르기: 세로로 선 선(x 가 같음)은 아래쪽 끝을 왼쪽으로 친다 — 끝점 순서와 상관없이 늘 같은 답
        var l = src.lines[i], aLeft = l[0] < l[2] || (l[0] === l[2] && l[1] >= l[3]), lp = aLeft ? [l[0], l[1]] : [l[2], l[3]], rp = aLeft ? [l[2], l[3]] : [l[0], l[1]];
        var o = d > 0 ? lp : rp, e = d > 0 ? rp : lp;
        marks.push({ mode: 'ln', o: o, e: e, d: d, len: Math.abs(e[0] - o[0]), src: i });
      }
    } else {
      var pts = src.pts, x0 = pts.length ? pts[0][0] : 0;
      for (i = 0; i < pts.length; i++) marks.push({ mode: 'pt', o: [st.align ? x0 : pts[i][0], pts[i][1]], rx: pts[i][0], d: d, len: st.len * PT, src: i });
    }
    marks.sort(function (a, b) { return b.o[1] - a.o[1] || a.src - b.src; });          // 아래(낮은 레벨)부터
    return marks;
  }
  // 레벨 값 = ±0 자리에서 층고를 차례로 더해 간 것 (수열처럼). 층고 = 그 칸에 적은 값(ov[k].h) > 모두 같게(ov.B0.v) > 점 사이 거리 × 축척(칸마다 반올림).
  // 칸마다 반올림해서 더하므로 조금씩 어긋나게 그린 도면도 3,600 · 7,200 · 10,800 처럼 떨어진다
  function levelTexts(st, marks, unitScale, ov) {
    var n = marks.length, bi = Math.max(0, Math.min(n - 1, st.base - 1)), out = [], i, hs = [], spanInfo = [], total = 0;
    var k = unitScale != null ? unitScale : st.scale / PT, rd = Math.max(1, st.round);                   // pt → 실제 mm
    var bEnt = ov && ov.B0, baseRaw = bEnt && bEnt.v != null && parseVal(bEnt.v) != null ? String(bEnt.v) : null;
    for (i = 0; i + 1 < n; i++) {
      var dist = marks[i].o[1] - marks[i + 1].o[1], autoMm = Math.round(dist * k / rd) * rd;
      var e = ov && ov[i] ? ov[i] : null, typed = e && e.h != null && parseVal(e.h) != null ? String(e.h) : null;
      var own = typed != null ? typed : baseRaw, mm = own != null ? parseVal(own) : autoMm;
      hs.push(mm); total += mm;
      spanInfo.push({ k: i, ser: 0, dist: dist, auto: group3(Math.round(autoMm)), autoMm: autoMm, typed: typed, base: typed == null ? baseRaw : null, hand: null, text: group3(Math.round(mm)), mm: mm });
    }
    var vals = [];
    vals[bi] = 0;
    for (i = bi + 1; i < n; i++) vals[i] = vals[i - 1] + hs[i - 1];
    for (i = bi - 1; i >= 0; i--) vals[i] = vals[i + 1] - hs[i];
    for (i = 0; i < n; i++) out.push({ n: levelName(st, i - bi, i === n - 1, n - 1 - bi), v: fmtValue(vals[i], st.fmt), mm: vals[i] });
    out.spanInfo = spanInfo;
    out.sums = n > 1 ? [{ ser: 0, k0: 0, n: n - 1, text: group3(Math.round(total)), mm: total, exact: true, base: baseRaw }] : [];
    return out;
  }

  function buildLevel(st, src, M, ov, opt) {
    var marks = levelMarks(st, src), texts = levelTexts(st, marks, opt && opt.unitScale, ov), auto = [], i, items = [], skel = [], snap = 0;
    var S = st.size * PT, w = st.sw, ink = st.ink, paper = st.paper || null, white = paper || '#FFFFFF', hcol = st.hc === 'accent' ? st.accent : ink;
    var ls = lineStyle(st, S), f = 0.4 * S * st.ts / 100, cap = M.cap * f, gapX = 0.17 * S, head = byId(LEVEL_HEADS, st.head), lay = st.layout;
    var tgap = ls.w / 2 + 0.12 * S, names = [];
    var marksInfo = [], baseIdx = Math.max(0, Math.min(texts.length - 1, st.base - 1));
    for (i = 0; i < texts.length; i++) {
      auto.push({ n: texts[i].n, v: texts[i].v });
      var hn = !!(ov && ov[i] && ov[i].n != null), hv = !!(ov && ov[i] && ov[i].v != null);
      if (hn) texts[i].n = String(ov[i].n);
      if (hv) texts[i].v = String(ov[i].v);
      marksInfo.push({ i: i, n: texts[i].n, v: texts[i].v, mm: texts[i].mm, handN: hn, handV: hv, base: i === baseIdx });
    }
    var showN = st.content !== 'v', showV = st.content !== 'n';
    // 묶음 전체에서 가장 넓은 글자 (라벨 상자·밑줄 길이를 같게)
    function wN(s) { return s ? M.measure(s, f, true) : 0; }
    function wV(s) { return s ? M.measure(s, f, false) : 0; }
    var sp = M.measure(' ', f, false), maxMain = 0, maxLine = 0, maxN = 0, maxV = 0;
    for (i = 0; i < texts.length; i++) {
      var tn = showN ? texts[i].n : '', tv = showV ? texts[i].v : '';
      maxMain = Math.max(maxMain, M.measure(tv || tn, f, true));          // 라벨 안 글자는 굵게
      maxN = Math.max(maxN, wN(tn)); maxV = Math.max(maxV, wV(tv));
      maxLine = Math.max(maxLine, wN(tn) + (tn && tv ? sp : 0) + wV(tv));
    }
    var lineItems = [], headItems = [], textItems = [];
    for (i = 0; i < marks.length; i++) {
      var m = marks[i], d = m.d, ox = m.o[0], oy = m.o[1], gi = i;
      var name = showN ? texts[i].n : '', val = showV ? texts[i].v : '';
      names.push((texts[i].n || '') + (texts[i].n && texts[i].v ? ' ' : '') + (texts[i].v || ''));
      // 점으로 만든 기준은 찍은 순서 · 찍은 자리 그대로 — 맞춤을 꺼도 켜도 같은 점에서 다시 계산한다 (첫 점 = 처음 찍은 점)
      if (m.mode === 'ln') skel.push([m.o[0], m.o[1], m.e[0], m.e[1]]);
      else { skel[m.src] = [m.rx, m.o[1]]; snap = Math.max(snap, Math.abs(m.o[0] - m.rx)); }
      (function () {
        function X(x) { return ox + d * x; }
        function Y(y) { return oy + y; }
        function mp(pts) { return mapPts(pts, function (x, y) { return [X(x), Y(y)]; }); }
        function al(a) { return d > 0 ? a : (a === 'left' ? 'right' : a === 'right' ? 'left' : a); }
        function hp(pts, o) { o.gi = gi; headItems.push(P(mp(pts), o)); }
        function hl(x0, y0, x1, y1, o) { o.gi = gi; o.closed = false; headItems.push(P(mp([C(x0, y0), C(x1, y1)]), o)); }
        function txt(x, y, s, o) { o.gi = gi; o.idx = i; o.size = f; o.align = al(o.align || 'left'); textItems.push(T(X(x), Y(y), s, o)); }
        // 이름(굵게) + 값 한 줄
        function lineText(x, y, align, fill) {
          if (!name && !val) return 0;
          var s = name + (name && val ? ' ' : '') + val, runs = null, role = name && val ? 'nv' : name ? 'n' : 'v';
          if (name && val) runs = [{ n: name.length, bold: true }, { n: s.length - name.length, bold: false }];
          txt(x, y, s, { bold: !val, fill: fill || ink, align: align, role: role, runs: runs, name: s });
          return wN(name) + (name && val ? sp : 0) + wV(val);
        }
        var hin = 0, hout = 0, tail = 0, vmode = 'above', lineFrom = null, lineTo = null, r, bw, h, triLift = 0;
        var id = head.id;
        if (id === 'tri' || id === 'trifill' || id === 'trihalf' || id === 'shelf' || id === 'arrow') {
          bw = 0.27 * S; h = 0.468 * S;
          // 뾰족한 끝(마이터)이 선을 뚫고 나가지 않게, 획의 바깥 끝이 선에 닿도록 그만큼 올린다
          var hsw = id === 'arrow' ? Math.max(1.25 * w, 0.03 * S) : w, up = hsw / (2 * Math.sin(Math.atan2(bw, h)));
          triLift = up;
          var tri = [C(-bw, -h - up), C(bw, -h - up), C(0, -up)];
          if (id === 'tri' || id === 'shelf') hp(tri, { fill: paper, stroke: hcol, sw: w, join: 'miter', name: '기호' });
          else if (id === 'trifill') hp(tri, { fill: hcol, stroke: hcol, sw: w, join: 'miter', name: '기호' });
          else if (id === 'trihalf') {
            hp(tri, { fill: paper, stroke: hcol, sw: w, join: 'miter', name: '기호' });
            hp([C(-bw, -h - up), C(0, -h - up), C(0, -up)], { fill: hcol, name: '반 채움' });
          } else hp([C(-bw, -h - up), C(0, -up), C(bw, -h - up)], { closed: false, stroke: hcol, sw: hsw, join: 'miter', cap: 'round', name: '기호' });
          hin = bw; hout = bw; tail = bw + 0.15 * S; vmode = id === 'shelf' ? 'shelf' : 'above';
        } else if (id === 'target' || id === 'cross') {
          r = 0.25 * S; var arm = r + 0.14 * S, k = K * r;
          hp(circlePts(0, 0, r), { fill: paper, stroke: hcol, sw: w, name: '기호' });
          if (id === 'target') {
            hp([C(0, 0), [-r, 0, -r, 0, -r, -k], [0, -r, -k, -r, 0, -r]], { fill: hcol, name: '사분면' });
            hp([C(0, 0), [r, 0, r, 0, r, k], [0, r, k, r, 0, r]], { fill: hcol, name: '사분면' });
          }
          hl(0, -arm, 0, arm, { stroke: hcol, sw: w, name: '십자' });
          hl(-arm, 0, arm, 0, { stroke: hcol, sw: w, name: '십자' });
          hin = r; hout = arm; tail = -arm; vmode = 'center';
        } else if (id === 'dot') {
          r = Math.max(0.105 * S, 1.6 * w);
          hp(circlePts(0, 0, r), { fill: hcol, name: '기호' });
          hin = r; hout = r; tail = 0; vmode = 'center';
        } else if (id === 'tick') {
          hl(0, -0.27 * S, 0, 0.27 * S, { stroke: hcol, sw: Math.max(1.5 * w, 0.03 * S), name: '기호' });
          hin = 0.02 * S; hout = 0.22 * S; tail = 0.22 * S; vmode = 'center';
        } else if (id === 'slash') {
          var q = 0.19 * S;
          hl(-q, q, q, -q, { stroke: hcol, sw: Math.max(2.6 * w, 0.06 * S), name: '기호' });
          hin = q * 0.6; hout = 0.3 * S; tail = 0.3 * S; vmode = 'center';
        } else if (id === 'diamond') {
          r = 0.25 * S;
          hp([C(-r, 0), C(0, -r), C(r, 0), C(0, r)], { fill: paper, stroke: hcol, sw: w, join: 'miter', name: '기호' });
          hp([C(-r, 0), C(0, -r), C(0, r)], { fill: hcol, name: '반 채움' });
          hin = r; hout = r; tail = 0; vmode = 'center';
        } else if (id === 'flag') {
          var ph = 0.84 * S, fw = 0.4 * S, fh = 0.36 * S;
          hl(0, 0, 0, -ph, { stroke: hcol, sw: Math.max(1.2 * w, 0.028 * S), name: '깃대' });
          hp([C(0, -ph), C(fw, -ph + fh / 2), C(0, -ph + fh)], { fill: hcol, stroke: hcol, sw: Math.max(1.2 * w, 0.028 * S), join: 'miter', name: '깃발' });
          hp(circlePts(0, 0, Math.max(0.055 * S, 1.2 * w)), { fill: hcol, name: '발' });
          hin = 0.05 * S; hout = 0.08 * S; tail = 0.16 * S; vmode = 'above';
        } else if (id === 'bar') {
          vmode = 'bar';
        } else if (head.label) {
          vmode = 'label';
        }

        var tw = wN(name) + (name && val ? sp : 0) + wV(val), barW = Math.max(3 * w, 0.085 * S);
        /* ---- 글자 · 선 자리 ---- */
        if (vmode === 'above' || vmode === 'center') {
          var x0 = -tail, yIn = -tgap;
          if (lay === 'out') {
            if (vmode === 'center') { lineText(-(hout + gapX), cap / 2, 'right'); }
            else { lineText(-(hout + gapX * 0.9), yIn, 'right'); x0 = -(hout + gapX * 0.9 + maxLine + 0.12 * S); }
          } else if (lay === 'split' && name && val) {
            txt(hin + gapX, yIn, name, { bold: true, fill: ink, role: 'n', name: name });
            txt(hin + gapX, tgap + cap, val, { fill: ink, role: 'v', name: val });
          } else lineText(hin + gapX, yIn, 'left');
          lineFrom = id === 'diamond' ? 0.25 * S : id === 'dot' ? 0 : x0; lineTo = m.len;
        } else if (vmode === 'shelf') {
          var sy = -(0.468 * S + triLift), sgap = 0.3 * w + 0.11 * S, sw2 = (lay === 'split' && name && val ? Math.max(maxN, maxV) : maxLine) + 0.14 * S, bw2 = 0.27 * S;
          if (lay === 'out') {
            hl(bw2, sy, -(bw2 + gapX + sw2), sy, { stroke: hcol, sw: w, name: '선반' });
            lineText(-(bw2 + gapX), sy - sgap, 'right');
          } else {
            hl(-bw2, sy, bw2 + gapX + sw2, sy, { stroke: hcol, sw: w, name: '선반' });
            if (lay === 'split' && name && val) {
              txt(bw2 + gapX, sy - sgap, name, { bold: true, fill: ink, role: 'n', name: name });
              txt(bw2 + gapX, sy + sgap + cap, val, { fill: ink, role: 'v', name: val });
            } else lineText(bw2 + gapX, sy - sgap, 'left');
          }
          lineFrom = -(bw2 + 0.15 * S); lineTo = m.len;
        } else if (vmode === 'bar') {
          var bl = Math.max(0.9 * S, (lay === 'split' && name && val ? Math.max(maxN, maxV) : maxLine) + 0.1 * S), ty = -(barW / 2 + 0.115 * S);
          if (lay === 'out') {
            hl(-bl, 0, 0, 0, { stroke: hcol, sw: barW, name: '밑줄' });
            lineText(0, ty, 'right');
            lineFrom = 0; lineTo = m.len;
          } else {
            hl(0, 0, bl, 0, { stroke: hcol, sw: barW, name: '밑줄' });
            if (lay === 'split' && name && val) {
              txt(0, ty, name, { bold: true, fill: ink, role: 'n', name: name });
              txt(0, barW / 2 + 0.115 * S + cap, val, { fill: ink, role: 'v', name: val });
            } else lineText(0, ty, 'left');
            lineFrom = Math.min(bl, m.len); lineTo = m.len;
          }
        } else if (vmode === 'label') {
          var hL = 0.66 * S, mainS = val || name, mainRole = val ? 'v' : 'n', px = 0.25 * S, bwid = Math.max(maxMain + 2 * px, hL * 1.1), wd, cx;
          if (id === 'tag') {
            var tip = 0.32 * hL; wd = tip + bwid; cx = -(tip + bwid / 2);
            hp([C(-wd, -hL / 2), C(-tip, -hL / 2), C(0, 0), C(-tip, hL / 2), C(-wd, hL / 2)], { fill: hcol, stroke: hcol, sw: w, name: '라벨' });
            if (mainS) txt(cx, cap / 2, mainS, { bold: true, fill: onColor(hcol, paper), align: 'center', role: mainRole, name: mainS });
          } else if (id === 'pill') {
            wd = Math.max(hL * 1.5, maxMain + hL * 0.78); cx = -wd / 2;
            hp(rrectPts(cx, 0, wd / 2, hL / 2, hL / 2), { fill: paper, stroke: hcol, sw: w, name: '라벨' });
            if (mainS) txt(cx, cap / 2, mainS, { bold: true, fill: st.hc === 'accent' ? hcol : ink, align: 'center', role: mainRole, name: mainS });
          } else {
            var tab = 0.13 * S; wd = tab + bwid; cx = -bwid / 2;
            hp([C(-wd, -hL / 2), C(0, -hL / 2), C(0, hL / 2), C(-wd, hL / 2)], { fill: paper, stroke: hcol, sw: w, join: 'miter', name: '라벨' });
            hp([C(-wd, -hL / 2), C(-bwid, -hL / 2), C(-bwid, hL / 2), C(-wd, hL / 2)], { fill: hcol, name: '색 띠' });
            if (mainS) txt(cx, cap / 2, mainS, { bold: true, fill: ink, align: 'center', role: mainRole, name: mainS });
          }
          if (name && val) {            // 라벨 밖 이름
            if (lay === 'out') txt(-(wd + gapX), cap / 2, name, { bold: true, fill: ink, align: 'right', role: 'n', name: name });
            else if (lay === 'split') txt(gapX, tgap + cap, name, { bold: true, fill: ink, role: 'n', name: name });
            else txt(gapX, -tgap, name, { bold: true, fill: ink, role: 'n', name: name });
          }
          lineFrom = id === 'tag' ? 0 : w / 2; lineTo = m.len;
        }
        /* ---- 레벨선 ---- */
        if (st.lp !== 'none' && lineTo != null) {
          var a = [X(lineFrom), oy], b;
          if (m.mode === 'ln') b = [m.e[0], m.e[1]];
          else b = [X(lineTo), oy];
          var len = Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]));
          if (len > 0.01 && d * (b[0] - a[0]) > 0) {
            var fd = fitDash(st.lp, len, S, st.ds);
            lineItems.push(LN(a[0], a[1], b[0], b[1], { stroke: ls.color, sw: st.lp === 'dot' ? Math.max(ls.w, 0.06 * S) : ls.w, dash: fd.dash, cap: fd.cap, gi: gi, name: '레벨선' }));
          }
        }
      })();
    }
    items = lineItems.concat(headItems, textItems);
    for (i = 0; i < texts.spanInfo.length; i++) { texts.spanInfo[i].a = texts[i].n || String(i + 1); texts.spanInfo[i].b = texts[i + 1].n || String(i + 2); }      // 칸 양쪽 이름 (아래 → 위)
    return { kind: 'level', items: items, auto: auto, names: names, n: marks.length, snap: snap, spanInfo: texts.spanInfo, sums: texts.sums, marksInfo: marksInfo,
      skel: { mode: src.mode === 'lines' ? 'lines' : 'points', data: skel }, order: marks.map(function (m) { return m.src; }), values: texts.map(function (t) { return t.mm; }) };
  }

  function build(st, src, M, ov, opt) {
    st = normalize(st);
    M = M || BUILTIN;
    return st.kind === 'level' ? buildLevel(st, src, M, ov, opt) : buildGrid(st, src, M, ov, opt);
  }

  /* ================= 견본 장면 (미리보기·썸네일) ================= */
  // 패널 위 미리보기: 지금 설정 그대로, 자리만 견본
  function sample(st, M, opt) {
    st = normalize(st);
    opt = opt || {};
    var S = st.size * PT, n = opt.n || (st.kind === 'level' ? 3 : 4), pts = [], i, s2 = copy(st);
    if (st.kind === 'level') {
      var stepY = Math.max(1.5 * S, 0);
      for (i = 0; i < n; i++) pts.push([0, -i * stepY]);
      s2.len = (opt.len != null ? opt.len : 3.6 * S) / PT; s2.align = true;
      return build(s2, { mode: 'points', pts: pts }, M, opt.ov || null, { unitScale: (opt.step || 3600) / stepY });
    }
    var stepX = Math.max(1.75 * S, 0);
    if (opt.turn === false) s2.turn = false;
    // 기호 돌리기를 켰으면 견본도 옆으로 뻗는 축선으로 (돌린 모습이 보이게)
    for (i = 0; i < n; i++) pts.push(s2.turn ? [0, -i * stepX] : [i * stepX, 0]);
    s2.len = (opt.len != null ? opt.len : 2.1 * S) / PT; s2.gap = Math.min(st.gap, 2); s2.flip = false; s2.both = false;
    if (opt.dim === false) s2.dim = 'none';
    if (s2.dim !== 'none' && opt.len == null) {                    // 간격 숫자가 축선 안에 들어오게 견본 축선을 늘인다
      var need = s2.dgap * PT + (s2.dtot ? 0.3 * S * s2.ts / 100 * (M || BUILTIN).cap + 0.42 * S : 0) + 0.55 * S;
      if (s2.dim !== 'link' || s2.dtot) s2.len = Math.max(s2.len, need / PT);
    }
    return build(s2, { mode: 'points', pts: pts }, M, opt.ov || null, { unitScale: (opt.span || 8400) / stepX });
  }
  // 간격 숫자 모양 썸네일: 축선 둘 사이의 치수 하나 ('기호 사이'는 작은 기호 둘)
  function dimThumb(st, id, M) {
    var s2 = copy(normalize(st)), S7 = 7 * PT, step = 2.5 * S7, link = id === 'link';
    s2.dim = id; s2.shape = link ? 'circle' : 'plain'; s2.finish = 'line'; s2.size = link ? 3.4 : 7; s2.ts = link ? 205 : 100;
    s2.gap = 0; s2.flip = false; s2.both = false; s2.dtot = false; s2.dfmt = 'c'; s2.align = true;
    s2.lp = link ? 'none' : (s2.lp === 'none' ? 'none' : 'solid'); s2.len = 1.05 * 7; s2.dgap = 0.55 * 7;
    var res = build(s2, { mode: 'points', pts: [[0, 0], [step, 0]] }, M, null, { unitScale: 8400 / step }), out = [], i;
    for (i = 0; i < res.items.length; i++) { var it = res.items[i]; if (!(it.t === 'text' && it.role === 'l')) out.push(it); }      // 번호 글자는 빼고
    res.items = out;
    return res;
  }
  // 썸네일: 기호 하나. over = 이 썸네일만 바꿀 값
  function thumb(st, over, M) {
    var s2 = copy(normalize(st)), k;
    for (k in over) s2[k] = over[k];
    var S = s2.size * PT;
    s2.gap = 0; s2.flip = false; s2.both = false; s2.ts = 100;
    if (s2.kind === 'level') {
      s2.len = 1.3 * S / PT; s2.content = 'v'; s2.base = 1; s2.fmt = 'mm'; s2.lp = s2.lp === 'none' ? 'none' : 'solid';
      return build(s2, { mode: 'points', pts: [[0, 0]] }, M, null);
    }
    s2.len = 0.6 * S / PT; s2.lp = s2.lp === 'none' ? 'none' : 'solid'; s2.rev = false;
    return build(s2, { mode: 'points', pts: [[0, 0]] }, M, null);
  }

  /* ================= 범위 · SVG ================= */
  function bounds(items, M) {
    M = M || BUILTIN;
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, i, j;
    function add(x, y) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    for (i = 0; i < items.length; i++) {
      var it = items[i];
      if (it.t === 'path') {
        var e = it.stroke ? it.sw / 2 : 0, fl = flatten(it.pts, it.closed, 8);
        for (j = 0; j < fl.length; j++) { add(fl[j][0] - e, fl[j][1] - e); add(fl[j][0] + e, fl[j][1] + e); }
      } else {
        var w = 0;
        if (it.runs) { var pos = 0; for (j = 0; j < it.runs.length; j++) { w += M.measure(it.s.substr(pos, it.runs[j].n), it.size, it.runs[j].bold); pos += it.runs[j].n; } }
        else w = M.measure(it.s, it.size, it.bold);
        var xa = it.align === 'center' ? it.x - w / 2 : it.align === 'right' ? it.x - w : it.x, ya = it.y - M.cap * it.size, yb = it.y + 0.06 * it.size;
        if (it.rot) {
          var ang = it.rot * Math.PI / 180, cs = Math.cos(ang), sn = Math.sin(ang), cr = [[xa, ya], [xa + w, ya], [xa + w, yb], [xa, yb]];
          for (j = 0; j < 4; j++) { var ddx = cr[j][0] - it.x, ddy = cr[j][1] - it.y; add(it.x + ddx * cs - ddy * sn, it.y + ddx * sn + ddy * cs); }
        } else { add(xa, ya); add(xa + w, yb); }
      }
    }
    if (x0 === Infinity) return { x: 0, y: 0, w: 0, h: 0 };
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function n3(v) { return String(Math.round(v * 1000) / 1000); }
  function pathD(pts, closed) {
    var d = 'M' + n3(pts[0][0]) + ' ' + n3(pts[0][1]), n = pts.length, m = closed ? n : n - 1;
    for (var i = 0; i < m; i++) {
      var a = pts[i], b = pts[(i + 1) % n];
      if (a[4] === a[0] && a[5] === a[1] && b[2] === b[0] && b[3] === b[1]) { if (!(closed && i === n - 1)) d += 'L' + n3(b[0]) + ' ' + n3(b[1]); }
      else d += 'C' + n3(a[4]) + ' ' + n3(a[5]) + ' ' + n3(b[2]) + ' ' + n3(b[3]) + ' ' + n3(b[0]) + ' ' + n3(b[1]);
    }
    return d + (closed ? 'Z' : '');
  }
  // o: { font: CSS 글꼴 목록, wr: 보통 굵기, wb: 굵은 굵기 }
  function itemsSVG(items, o) {
    o = o || {};
    var out = '', fam = o.font || 'Pretendard, "Noto Sans KR", "Malgun Gothic", Arial, sans-serif', wr = o.wr || 500, wb = o.wb || 700;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (it.t === 'path') {
        out += '<path d="' + pathD(it.pts, it.closed) + '" fill="' + (it.fill || 'none') + '"';
        if (it.stroke) {
          out += ' stroke="' + it.stroke + '" stroke-width="' + n3(it.sw) + '" stroke-linejoin="' + (it.join === 'miter' ? 'miter' : 'round') + '" stroke-miterlimit="10"';
          if (it.cap && it.cap !== 'butt') out += ' stroke-linecap="' + it.cap + '"';
          if (it.dash) out += ' stroke-dasharray="' + it.dash.join(' ') + '"' + (it.dashOff ? ' stroke-dashoffset="' + n3(it.dashOff) + '"' : '');
        }
        out += '/>';
      } else {
        var anchor = it.align === 'center' ? 'middle' : it.align === 'right' ? 'end' : 'start';
        out += '<text x="' + n3(it.x) + '" y="' + n3(it.y) + '" font-family=\'' + fam + '\' font-size="' + n3(it.size) + '" text-anchor="' + anchor + '" fill="' + it.fill + '"' +
          (it.rot ? ' transform="rotate(' + n3(it.rot) + ' ' + n3(it.x) + ' ' + n3(it.y) + ')"' : '');
        if (it.runs) {
          out += ' xml:space="preserve">';
          var pos = 0;
          for (var j = 0; j < it.runs.length; j++) {
            out += '<tspan font-weight="' + (it.runs[j].bold ? wb : wr) + '">' + esc(it.s.substr(pos, it.runs[j].n)) + '</tspan>';
            pos += it.runs[j].n;
          }
          out += '</text>';
        } else out += ' font-weight="' + (it.bold ? wb : wr) + '">' + esc(it.s) + '</text>';
      }
    }
    return out;
  }
  // 장면 하나를 여백을 둔 SVG 로. o.box = [w, h] 면 그 비율 상자 가운데에 맞춤
  function toSVG(items, o) {
    o = o || {};
    var b = bounds(items, o.M), pad = o.pad == null ? 2 : o.pad, x = b.x - pad, y = b.y - pad, w = b.w + pad * 2, h = b.h + pad * 2;
    if (o.box) {
      var r = o.box[0] / o.box[1];
      if (w / h < r) { var nw = h * r; x -= (nw - w) / 2; w = nw; } else { var nh = w / r; y -= (nh - h) / 2; h = nh; }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + n3(x) + ' ' + n3(y) + ' ' + n3(w) + ' ' + n3(h) + '"' +
      (o.attrs ? ' ' + o.attrs : '') + '>' + (o.bg ? '<rect x="' + n3(x) + '" y="' + n3(y) + '" width="' + n3(w) + '" height="' + n3(h) + '" fill="' + o.bg + '"/>' : '') + itemsSVG(items, o) + '</svg>';
  }

  /* ================= 고친 글자 찾기 =================
     문서에서 읽은 글자(texts: [{i, r, s}])와 자동 글자(auto)를 견줘, 사용자가 손으로 고친 것만 남긴다.
     prev = 지난번까지 기억한 고친 글자. 같은 번호의 글자가 둘(양끝 기호)이면 지난번과 달라진 쪽이 사용자가 고친 것. */
  function overridesFrom(kind, auto, texts, prev) {
    var ov = {}, k, i, groups = {}, order = [];
    if (prev) for (k in prev) if (Object.prototype.hasOwnProperty.call(prev, k)) ov[k] = copy(prev[k]);
    for (i = 0; i < texts.length; i++) {
      var key = texts[i].i + '|' + texts[i].r;
      if (!groups[key]) { groups[key] = []; order.push(key); }
      groups[key].push(String(texts[i].s));
    }
    function pickChanged(list, base) { for (var j = 0; j < list.length; j++) if (list[j] !== base) return list[j]; return base; }
    function put(cur, role, val, autoVal) { if (val !== autoVal) cur[role] = val; else delete cur[role]; }
    for (i = 0; i < order.length; i++) {
      var parts = order[i].split('|'), idx = parts[0], role = parts[1], a = auto[idx], list = groups[order[i]];
      if (!a) continue;
      var cur = ov[idx] || {};
      if (kind === 'grid') {
        if ((role === 'l' || role === 'd' || role === 't') && a[role] != null) put(cur, role, pickChanged(list, cur[role] != null ? cur[role] : a[role]), a[role]);
      } else if (role === 'n' || role === 'v') {
        put(cur, role, pickChanged(list, cur[role] != null ? cur[role] : a[role]), a[role]);
      } else if (role === 'nv') {
        var bn = cur.n != null ? cur.n : a.n, bv = cur.v != null ? cur.v : a.v, s = pickChanged(list, bn + ' ' + bv);
        if (s !== bn + ' ' + bv) {
          var nn, vv, sp;
          if (s.indexOf(bn + ' ') === 0) { nn = bn; vv = s.slice(bn.length + 1); }                                   // 값만 고침
          else if (s.length > bv.length && s.lastIndexOf(' ' + bv) === s.length - bv.length - 1) { nn = s.slice(0, s.length - bv.length - 1); vv = bv; }   // 이름만 고침
          else { sp = s.indexOf(' '); nn = sp < 0 ? s : s.slice(0, sp); vv = sp < 0 ? '' : s.slice(sp + 1); }
          put(cur, 'n', nn, a.n); put(cur, 'v', vv, a.v);
        }
      }
      var has = false;
      for (k in cur) if (Object.prototype.hasOwnProperty.call(cur, k)) has = true;
      if (has) ov[idx] = cur; else delete ov[idx];
    }
    return ov;
  }

  return {
    VERSION: VERSION, PT: PT, BUILTIN: BUILTIN,
    GRID_SHAPES: GRID_SHAPES, GRID_FINISHES: GRID_FINISHES, GRID_DIMS: GRID_DIMS, LEVEL_HEADS: LEVEL_HEADS, LEVEL_LAYOUTS: LEVEL_LAYOUTS, LINE_PATTERNS: LINE_PATTERNS, LOOKS: LOOKS,
    COMMON_KEYS: COMMON_KEYS, LIMITS: LIMITS,
    defaults: defaults, normalize: normalize, build: build, sample: sample, thumb: thumb, dimThumb: dimThumb,
    bounds: bounds, toSVG: toSVG, itemsSVG: itemsSVG, overridesFrom: overridesFrom, parseVal: parseVal, splitVals: splitVals, fmtTyped: fmtTyped, valText: valText, mmText: mmText, applyValueOps: applyValueOps,
    gridLabels: gridLabels, fmtValue: fmtValue, fmtSpan: fmtSpan, levelName: levelName, alpha: alpha,
    mix: mix, lum: lum, onColor: onColor, byId: byId, copy: copy,
    _geo: { flatten: flatten, rayExit: rayExit, halfSpanAt: halfSpanAt, offsetPoly: offsetPoly, fitDash: fitDash, circlePts: circlePts, rrectPts: rrectPts, dropPts: dropPts, ngon: ngon }
  };
});
