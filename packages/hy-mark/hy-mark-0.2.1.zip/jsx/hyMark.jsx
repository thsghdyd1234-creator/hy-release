﻿/* hy 축열 (hy Mark) host (ExtendScript, ES3)
   패널(js/core.js)이 계산한 장면을 일러스트 패스·포인트 글자로 그린다. 계산은 여기서 하지 않는다.
   기호 묶음(그룹)의 note 에 설정을 적어 두고, 묶음 안의 '기준' 패스(칠·획 없음)가 찍은 점 자리를 들고 다닌다
   — 묶음을 옮기거나 키워도 기준 패스가 같이 움직여서, 스타일을 바꿀 때 지금 자리에서 다시 그린다.
   note: hyMark1|<id>|<만들 때 position x,y>|<encodeURIComponent(JSON 상태)>
   ES3: 예약어(final · native · double · class …)를 이름·속성으로 쓰지 말 것.
   ExtendScript 는 표준과 다르게 읽는 곳이 있다 (Node 시험은 표준대로 읽어서 못 잡는다 — test/estk.js 가 문법으로 막음):
     a ? b : c ? d : e  →  (a ? b : c) ? d : e   ·   a || b && c  →  (a || b) && c
   그래서 ?: 안에 ?: 를 넣지 않고(if 로 쓴다), && 와 || 를 섞을 때는 괄호를 친다.
   0.2.0 은 글자 맞춤을 ?: 두 번으로 골라서 가운데 맞춤 글자가 실제 일러스트에서 오른쪽 맞춤이 됐다. */

var HYM_V = '0.2.1';
var HYM_PREFIX = 'hyMark1|';
var HYM_SKEL = 'hyMarkS';
var HYM_TEXT = 'hyMarkT|';
var HYM_SCAN = 600;          // 선택에서 살펴볼 개수 상한 (전체 선택처럼 수천 개가 골라져도 패널이 안 멈추게)
var HYM_ROOTS = 80;          // 한 번에 찾는 기호 묶음 상한 (고치기는 60묶음까지)
var hyMark_cut = 0;          // 이번 그리기에서 설정(note)이 잘려 적힌 묶음 수
// 마지막 hyMark_read 가 읽은 묶음들. 바로 이어지는 hyMark_apply(같은 tok)가 이것을 고친다 —
// 패널에서 값을 적고 도면을 누르면 읽기와 고치기 사이에 선택이 풀리는데, 그래도 적던 값이 그 묶음에 들어가게.
// 한 번 쓰면 비운다 (오래된 개체 참조를 들고 있지 않게)
var hyMark_stash = null;
var hyMark_tok = 0;

/* ---------- 주고받기 ---------- */
function hyMark_dec(s) { return eval('(' + decodeURIComponent(s) + ')'); }

function hyMark_q(s) {
  var o = '"', i, c, ch;
  s = String(s);
  for (i = 0; i < s.length; i++) {
    c = s.charCodeAt(i); ch = s.charAt(i);
    if (ch === '"') o += '\\"';
    else if (ch === '\\') o += '\\\\';
    else if (c === 10) o += '\\n';
    else if (c === 13) o += '\\r';
    else if (c === 9) o += '\\t';
    else if (c < 32 || c > 126) { var h = c.toString(16); while (h.length < 4) h = '0' + h; o += '\\u' + h; }
    else o += ch;
  }
  return o + '"';
}
function hyMark_str(v) {
  var i, a, k;
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number') return isFinite(v) ? String(Math.round(v * 10000) / 10000) : 'null';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'string') return hyMark_q(v);
  if (Object.prototype.toString.call(v) === '[object Array]') {
    a = [];
    for (i = 0; i < v.length; i++) a.push(hyMark_str(v[i]));
    return '[' + a.join(',') + ']';
  }
  a = [];
  for (k in v) { if (v.hasOwnProperty(k)) a.push(hyMark_q(k) + ':' + hyMark_str(v[k])); }
  return '{' + a.join(',') + '}';
}
function hyMark_ret(o) { return encodeURIComponent(hyMark_str(o)); }

// 진입점 감싸기: 오류도 {ok:false,msg} 로 (CEP 는 던진 오류를 'EvalScript error.' 로만 돌려준다)
function hyMark_guard(fn) {
  var prevCS = null, out;
  try {
    try { prevCS = app.coordinateSystem; app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM; } catch (e0) { prevCS = null; }
    out = fn();
  } catch (e) {
    out = { ok: false, msg: String(e && e.message ? e.message : e) + (e && e.line ? ' (' + e.line + '줄)' : '') };
  }
  try { if (prevCS !== null) app.coordinateSystem = prevCS; } catch (e1) { }
  return hyMark_ret(out);
}

function hyMark_ping() { return hyMark_ret({ ok: true, v: HYM_V }); }

/* ---------- 색 ---------- */
function hyMark_rgb(hex) {
  var c = new RGBColor(), n = parseInt(String(hex).replace('#', ''), 16);
  if (isNaN(n)) n = 0;
  c.red = (n >> 16) & 255; c.green = (n >> 8) & 255; c.blue = n & 255;
  return c;
}
function hyMark_hex2(v) { var h = Math.max(0, Math.min(255, Math.round(v))).toString(16); return h.length < 2 ? '0' + h : h; }
function hyMark_hexOf(col) {
  var t, r, g, b, k, out;
  if (!col) return null;
  try { t = col.typename; } catch (e) { return null; }
  if (t === 'RGBColor') return ('#' + hyMark_hex2(col.red) + hyMark_hex2(col.green) + hyMark_hex2(col.blue)).toUpperCase();
  if (t === 'GrayColor') { k = 255 * (1 - col.gray / 100); return ('#' + hyMark_hex2(k) + hyMark_hex2(k) + hyMark_hex2(k)).toUpperCase(); }
  if (t === 'CMYKColor') {
    try {
      out = app.convertSampleColor(ImageColorSpace.CMYK, [col.cyan, col.magenta, col.yellow, col.black], ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
      return ('#' + hyMark_hex2(out[0]) + hyMark_hex2(out[1]) + hyMark_hex2(out[2])).toUpperCase();
    } catch (e2) {
      r = 255 * (1 - col.cyan / 100) * (1 - col.black / 100); g = 255 * (1 - col.magenta / 100) * (1 - col.black / 100); b = 255 * (1 - col.yellow / 100) * (1 - col.black / 100);
      return ('#' + hyMark_hex2(r) + hyMark_hex2(g) + hyMark_hex2(b)).toUpperCase();
    }
  }
  if (t === 'SpotColor') { try { return hyMark_hexOf(col.spot.color); } catch (e3) { return null; } }
  return null;
}

/* ---------- 글꼴 (GRAPH 와 같은 방식: 패밀리 이름 → 보통·굵은 글꼴) ---------- */
function hyMark_fontIndex() {
  if ($.global.__hyMarkFontIdx) return $.global.__hyMarkFontIdx;
  var idx = {}, tf = app.textFonts, i, n, f, fam, k;
  for (i = 0, n = tf.length; i < n; i++) {
    f = tf[i];
    try { fam = f.family; } catch (e) { continue; }
    if (!fam) continue;
    k = '_' + fam;
    if (!idx[k]) idx[k] = [];
    idx[k].push(f);
  }
  $.global.__hyMarkFontIdx = idx;
  return idx;
}
function hyMark_pickStyle(fonts, bold) {
  var pref = bold ? ['bold', 'semibold', 'demibold', 'extrabold', 'heavy', 'black', 'medium']
                  : ['medium', 'regular', 'normal', 'book', 'roman', 'light'];
  var p, i, st;
  for (p = 0; p < pref.length; p++) {
    for (i = 0; i < fonts.length; i++) {
      st = '';
      try { st = String(fonts[i].style).toLowerCase().replace(/[\s_-]/g, ''); } catch (e) { }
      if (st === pref[p]) return fonts[i];
    }
  }
  return fonts[0];
}
function hyMark_font(fam, bold) {
  if (!fam) return null;
  var key = (bold ? 'b|' : 'r|') + fam, cache, found = null, base, cands, c, ix;
  if (!$.global.__hyMarkFontCache) $.global.__hyMarkFontCache = {};
  cache = $.global.__hyMarkFontCache;
  if (cache[key] !== undefined) return cache[key];
  base = String(fam).replace(/\s+/g, '');
  cands = bold ? [base + '-Bold', base + '-SemiBold', base + 'Bold'] : [base + '-Medium', base + '-Regular', base, base + 'Regular'];
  for (c = 0; c < cands.length && !found; c++) {
    try { found = app.textFonts.getByName(cands[c]); } catch (e) { found = null; }
  }
  if (!found) {
    ix = hyMark_fontIndex()['_' + fam];
    if (ix && ix.length) found = hyMark_pickStyle(ix, bold);
  }
  cache[key] = found;
  return found;
}
// 패널의 글꼴 칩: 이 PC 에 있는 것만 (PostScript 이름으로 빨리 확인)
function hyMark_hasFonts(enc) {
  return hyMark_guard(function () {
    var list = hyMark_dec(enc), out = [], i, j, ok;
    for (i = 0; i < list.length; i++) {
      ok = false;
      for (j = 0; j < list[i].ps.length && !ok; j++) {
        try { if (app.textFonts.getByName(list[i].ps[j])) ok = true; } catch (e) { ok = false; }
      }
      if (ok) out.push(list[i].fam);
    }
    return { ok: true, fonts: out };
  });
}

/* ---------- 그리기 ---------- */
function hyMark_pt(x, y) { return [x, -y]; }          // 장면(y 아래) → 문서(y 위)

function hyMark_mkPath(container, pts, closed) {
  var p = container.pathItems.add(), anchors = [], i, q, pp, hasL, hasR;
  for (i = 0; i < pts.length; i++) anchors.push(hyMark_pt(pts[i][0], pts[i][1]));
  p.setEntirePath(anchors);
  for (i = 0; i < pts.length; i++) {
    q = pts[i];
    hasL = !(q[2] === q[0] && q[3] === q[1]); hasR = !(q[4] === q[0] && q[5] === q[1]);
    if (!hasL && !hasR) continue;
    pp = p.pathPoints[i];
    pp.pointType = hasL && hasR ? PointType.SMOOTH : PointType.CORNER;
    pp.leftDirection = hyMark_pt(q[2], q[3]);
    pp.rightDirection = hyMark_pt(q[4], q[5]);
  }
  p.closed = !!closed;
  return p;
}
// 꺾은선 하나 (기준 패스). 점 하나짜리가 setEntirePath 로 안 만들어지는 판이면 점을 하나씩 넣는다
function hyMark_poly(container, anchors) {
  var p = container.pathItems.add(), i, pp;
  try { p.setEntirePath(anchors); }
  catch (e) {
    for (i = 0; i < anchors.length; i++) {
      pp = p.pathPoints.add();
      pp.anchor = anchors[i]; pp.leftDirection = anchors[i]; pp.rightDirection = anchors[i];
      pp.pointType = PointType.CORNER;
    }
  }
  return p;
}
// 선 끝 모양 · 글자 맞춤 고르기 — ?: 를 겹쳐 쓰지 말 것 (머리말: ExtendScript 는 왼쪽부터 묶는다)
function hyMark_capOf(c) {
  if (c === 'round') return StrokeCap.ROUNDENDCAP;
  if (c === 'square') return StrokeCap.PROJECTINGENDCAP;
  return StrokeCap.BUTTENDCAP;
}
function hyMark_justOf(a) {
  if (a === 'center') return Justification.CENTER;
  if (a === 'right') return Justification.RIGHT;
  return Justification.LEFT;
}
function hyMark_style(item, it) {
  if (it.fill) { item.filled = true; item.fillColor = hyMark_rgb(it.fill); }
  else item.filled = false;
  if (it.stroke) {
    item.stroked = true;
    item.strokeColor = hyMark_rgb(it.stroke);
    item.strokeWidth = it.sw || 1;
    item.strokeCap = hyMark_capOf(it.cap);
    item.strokeJoin = it.join === 'miter' ? StrokeJoin.MITERENDJOIN : StrokeJoin.ROUNDENDJOIN;
    try { item.strokeMiterLimit = 10; } catch (e) { }
    item.strokeDashes = it.dash ? it.dash : [];
    if (it.dash) { try { item.strokeDashOffset = it.dashOff || 0; } catch (e2) { } }
  } else item.stroked = false;
  try { item.fillOverprint = false; item.strokeOverprint = false; } catch (e3) { }
}
function hyMark_text(parent, it, fam, doc) {
  var a = hyMark_pt(it.x, it.y), X = a[0], Y = a[1], tf, tr, ca, f, fb, pos, r, c, run, cha, an;
  try { tf = parent.textFrames.pointText([X, Y]); }
  catch (e) {            // 묶음에 바로 못 넣는 판이면 그 묶음이 있는 레이어에 만들어 옮긴다
    var host = null;
    try { host = parent.layer; } catch (e0) { host = null; }
    if (!host) host = doc.activeLayer;
    tf = host.textFrames.pointText([X, Y]);
    tf.move(parent, ElementPlacement.PLACEATBEGINNING);
  }
  tf.contents = it.s;
  tr = tf.textRange; ca = tr.characterAttributes;
  ca.size = it.size;
  f = hyMark_font(fam, it.bold);
  if (f) { try { ca.textFont = f; } catch (e2) { } }
  ca.fillColor = hyMark_rgb(it.fill || '#000000');
  try { ca.strokeColor = new NoColor(); } catch (e3) { }
  try { ca.tracking = 0; ca.horizontalScale = 100; ca.verticalScale = 100; ca.baselineShift = 0; } catch (e4) { }
  tr.paragraphAttributes.justification = hyMark_justOf(it.align);
  if (it.runs) {            // 이름만 굵게
    pos = 0;
    for (r = 0; r < it.runs.length; r++) {
      run = it.runs[r];
      fb = hyMark_font(fam, run.bold);
      if (fb) {
        for (c = 0; c < run.n; c++) {
          try { cha = tf.textRange.characters[pos + c].characterAttributes; cha.textFont = fb; } catch (e5) { }
        }
      }
      pos += run.n;
    }
  }
  // 돌린 글자(세로 치수): 장면의 rot 은 화면에서 시계 방향 +, 일러스트 rotate 는 반시계 + 라 부호를 뒤집는다.
  // 가운데를 축으로 돌기 때문에 기준점이 밀린다 → 바로 아래에서 기준점을 제자리로 옮긴다
  if (it.rot) { try { tf.rotate(-it.rot); } catch (e8) { } }
  try {
    an = tf.anchor;
    if (Math.abs(an[0] - X) > 0.01 || Math.abs(an[1] - Y) > 0.01) tf.translate(X - an[0], Y - an[1]);
  } catch (e6) { }
  try { tf.name = it.name || it.s; } catch (e7) { }
  if (it.role) tf.note = HYM_TEXT + it.idx + '|' + it.role;
  return tf;
}

// 묶음 하나를 parent 안에 그린다. G: {kind, id, name, items, names, skel:{mode,data}, stateEnc, font}
function hyMark_drawOne(doc, parent, G) {
  var root = parent.groupItems.add(), subs = {}, i, it, cont, sk, sp, d, rp, n = 0;
  root.name = G.name || 'hy 축열';
  // 기준 패스 (칠·획 없음): 찍은 점·선 자리. 스타일을 바꿀 때 여기서 지금 자리를 읽는다
  sk = root.groupItems.add();
  sk.name = '기준 (지우지 마세요)';
  sk.note = HYM_SKEL + '|' + G.skel.mode;
  d = G.skel.data;
  if (G.skel.mode === 'lines') {
    for (i = 0; i < d.length; i++) {
      sp = hyMark_poly(sk, [hyMark_pt(d[i][0], d[i][1]), hyMark_pt(d[i][2], d[i][3])]);
      sp.filled = false; sp.stroked = false; sp.name = String(i);
    }
  } else {
    var anchors = [];
    for (i = 0; i < d.length; i++) anchors.push(hyMark_pt(d[i][0], d[i][1]));
    sp = hyMark_poly(sk, anchors);
    sp.filled = false; sp.stroked = false; sp.name = 'points';
  }
  for (i = 0; i < G.items.length; i++) {
    it = G.items[i];
    cont = root;
    if (it.gi >= 0) {
      if (!subs['g' + it.gi]) { subs['g' + it.gi] = root.groupItems.add(); subs['g' + it.gi].name = (G.names && G.names[it.gi]) ? G.names[it.gi] : String(it.gi + 1); }
      cont = subs['g' + it.gi];
    }
    if (it.t === 'text') hyMark_text(cont, it, G.font, doc);
    else {
      var p = hyMark_mkPath(cont, it.pts, it.closed);
      hyMark_style(p, it);
      if (it.name) { try { p.name = it.name; } catch (e) { } }
    }
    n++;
  }
  rp = root.position;
  var noteStr = HYM_PREFIX + G.id + '|' + (Math.round(rp[0] * 1000) / 1000) + ',' + (Math.round(rp[1] * 1000) / 1000) + '|' + G.stateEnc;
  root.note = noteStr;
  // 설정이 다 적혔는지 확인 (아주 큰 묶음에서 일러스트가 잘라 적으면 나중에 못 고친다 — 패널이 알림)
  try { if (String(root.note).length !== noteStr.length) hyMark_cut++; } catch (e2) { }
  return root;
}

/* ---------- 찾기 ---------- */
function hyMark_selection(doc) {
  var s;
  try { s = doc.selection; } catch (e) { return []; }
  if (!s || typeof s === 'string') return [];
  try { if (s.typename === 'TextRange') return []; } catch (e2) { }
  if (s.length === undefined) return [];
  return s;
}
function hyMark_isRoot(it) {
  try { return it.typename === 'GroupItem' && String(it.note).indexOf(HYM_PREFIX) === 0; } catch (e) { return false; }
}
function hyMark_rootOf(it) {
  var n;
  for (n = 0; it && n < 60; n++) {
    if (hyMark_isRoot(it)) return it;
    try { it = it.parent; } catch (e) { return null; }
    try { if (!it || it.typename === 'Layer' || it.typename === 'Document') return null; } catch (e2) { return null; }
  }
  return null;
}
function hyMark_same(a, b) {
  try { if (a.uuid && b.uuid) return a.uuid === b.uuid; } catch (e) { }
  return a == b;
}
// 선택에 든 기호 묶음 (겹치지 않게, 선택 순서대로).
// 고른 것이 기호 묶음 안이면 그 묶음, 보통 그룹이면 그 안에 든 기호 묶음들 (여러 묶음을 그룹으로 묶어 둔 것도 고칠 수 있게)
function hyMark_roots(doc) {
  var sel = hyMark_selection(doc), out = [], i, r, n = Math.min(sel.length, HYM_SCAN), budget = 3000;
  function push(g) {
    var j;
    for (j = 0; j < out.length; j++) { if (hyMark_same(out[j], g)) return; }
    out.push(g);
  }
  function down(g, depth) {
    var kids, k;
    if (depth > 5 || out.length >= HYM_ROOTS) return;
    try { kids = g.groupItems; } catch (e) { return; }
    for (k = 0; k < kids.length && out.length < HYM_ROOTS && budget > 0; k++) {
      budget--;
      if (hyMark_isRoot(kids[k])) push(kids[k]);
      else down(kids[k], depth + 1);
    }
  }
  for (i = 0; i < n && out.length < HYM_ROOTS; i++) {
    r = hyMark_rootOf(sel[i]);
    if (r) { push(r); continue; }
    try { if (sel[i].typename === 'GroupItem') down(sel[i], 0); } catch (e2) { }
  }
  return out;
}
function hyMark_parseNote(note) {
  var p = String(note).split('|'), pos = String(p[2] || '0,0').split(',');
  return { id: p[1], pos: [parseFloat(pos[0]) || 0, parseFloat(pos[1]) || 0], state: p[3] || '' };
}
// 선택에서 점·선으로 쓸 패스 (기호 묶음 안은 빼고, 보통 그룹 안은 들어감)
function hyMark_paths(doc) {
  var sel = hyMark_selection(doc), out = [], i, n = Math.min(sel.length, HYM_SCAN);
  function walk(it, depth) {
    var t, k, kids;
    if (out.length >= 400) return;
    try { t = it.typename; } catch (e) { return; }
    if (t === 'PathItem') {
      try { if (it.guides || it.clipping) return; } catch (e2) { }
      out.push(it);
    } else if (t === 'GroupItem' && depth < 6 && !hyMark_isRoot(it)) {
      kids = it.pageItems;
      for (k = 0; k < kids.length; k++) walk(kids[k], depth + 1);
    }
  }
  for (i = 0; i < n; i++) { if (!hyMark_rootOf(sel[i])) walk(sel[i], 0); }
  return out;
}
function hyMark_lineOf(p) {
  var pp = p.pathPoints, n = pp.length, a, b;
  if (n < 2) return null;
  try { if (p.closed) return null; } catch (e) { }
  a = pp[0].anchor; b = pp[n - 1].anchor;
  if (Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) < 0.5) return null;
  return [a[0], -a[1], b[0], -b[1]];
}

/* ---------- 패널 진입점 ---------- */
// 선택을 가볍게 읽기 (문서를 바꾸지 않음)
function hyMark_peek() {
  return hyMark_guard(function () {
    if (!app.documents.length) return { ok: true, doc: 0 };
    var doc = app.activeDocument, roots = hyMark_roots(doc), paths, i, nPts = 0, nLines = 0, first = null, kinds = { grid: 0, level: 0 }, info;
    for (i = 0; i < roots.length; i++) {
      // 묶음에 적힌 설정은 문서에서 온 글이라 여기서 실행(eval)하지 않는다 — 종류만 글자로 확인하고, 풀기는 패널이 JSON 으로
      info = hyMark_parseNote(roots[i].note);
      if (String(info.state).indexOf('%22st%22%3A') < 0) continue;
      kinds[String(info.state).indexOf('%22kind%22%3A%22level%22') >= 0 ? 'level' : 'grid']++;
      if (!first) first = info.state;
    }
    if (kinds.grid + kinds.level) return { ok: true, doc: 1, marks: kinds.grid + kinds.level, grid: kinds.grid, level: kinds.level, first: first };
    paths = hyMark_paths(doc);
    for (i = 0; i < paths.length; i++) {
      nPts += paths[i].pathPoints.length;
      if (hyMark_lineOf(paths[i])) nLines++;
    }
    return { ok: true, doc: 1, marks: 0, paths: paths.length, pts: nPts, lines: nLines };
  });
}

// 만들 재료 읽기. prefer: 'auto' | 'points' | 'lines'
function hyMark_source(prefer) {
  return hyMark_guard(function () {
    if (!app.documents.length) return { ok: false, msg: '열린 문서가 없어요' };
    var doc = app.activeDocument, paths = hyMark_paths(doc), mode, i, j, pp, a, l, pts = [], lines = [];
    if (!paths.length) return { ok: false, msg: '펜으로 점을 찍은 패스나 기존 선을 선택해 주세요' };
    mode = prefer === 'points' || prefer === 'lines' ? prefer : (paths.length === 1 ? 'points' : 'lines');
    if (mode === 'lines') {
      for (i = 0; i < paths.length; i++) { l = hyMark_lineOf(paths[i]); if (l) lines.push(l); }
      if (!lines.length) mode = 'points';
    }
    if (mode === 'points') {
      for (i = 0; i < paths.length; i++) {
        pp = paths[i].pathPoints;
        for (j = 0; j < pp.length; j++) { a = pp[j].anchor; pts.push([a[0], -a[1]]); }
      }
      if (pts.length > 300) return { ok: false, msg: '점이 너무 많아요 (' + pts.length + '개) — 300개까지' };
      return { ok: true, mode: 'points', pts: pts };
    }
    if (lines.length > 300) return { ok: false, msg: '선이 너무 많아요 (' + lines.length + '개) — 300개까지' };
    return { ok: true, mode: 'lines', lines: lines };
  });
}

// 그리기: {groups:[{kind,id,name,items,names,skel,stateEnc,font, replace?, oldId?}], srcMode, removeSrc}
// replace = 지금 선택한 기호 묶음 중 몇 번째를 바꿀지 (고치기). 없으면 새로 만든다.
// removeSrc = 재료로 쓴 패스(점 찍은 패스 · 축선으로 다시 그린 원래 선)를 지운다 — 쓰지 않은 패스는 그대로 둔다
function hyMark_apply(enc) {
  return hyMark_guard(function () {
    if (!app.documents.length) return { ok: false, msg: '열린 문서가 없어요' };
    var P = hyMark_dec(enc), doc = app.activeDocument, roots = null, now = null, srcPaths = [], used = [], made = [], parents = [], gone = {}, wasSel = [], keepSel = true, stash = hyMark_stash, i, j, G, old, parent, root, info, par, dup, at;
    hyMark_cut = 0;
    hyMark_stash = null;
    for (i = 0; i < P.groups.length; i++) {
      if (P.groups[i].replace != null) {
        now = hyMark_roots(doc);
        roots = (P.tok && stash && stash.tok === P.tok) ? stash.roots : now;
        break;
      }
    }
    if (P.srcMode) {
      srcPaths = hyMark_paths(doc);
      for (i = 0; i < srcPaths.length; i++) { if (P.srcMode === 'points' || hyMark_lineOf(srcPaths[i])) used.push(srcPaths[i]); }
    }
    for (i = 0; i < P.groups.length; i++) {
      G = P.groups[i];
      old = null;
      if (G.replace != null) {
        old = roots[G.replace];
        if (!old) return { ok: false, msg: '선택이 바뀌었어요 — 다시 선택해 주세요' };
        try { info = hyMark_parseNote(old.note); parent = old.parent; }
        catch (e0) { return { ok: false, msg: '고치려던 묶음이 없어졌어요 — 다시 선택해 주세요' }; }
        if (G.oldId && info.id !== G.oldId) return { ok: false, msg: '선택이 바뀌었어요 — 다시 선택해 주세요' };
        // 지금도 골라져 있는 묶음인가 (읽은 뒤 선택이 풀렸으면 다시 그린 뒤에도 고르지 않는다)
        at = -1;
        for (j = 0; j < now.length; j++) { if (hyMark_same(now[j], old)) { at = j; break; } }
        if (at < 0) keepSel = false; else gone['n' + at] = 1;
        wasSel[i] = at >= 0;
      } else {
        parent = null;
        if (used.length) { try { parent = used[0].layer; } catch (e) { parent = null; } }
        if (!parent) parent = doc.activeLayer;
        if (parent.locked || !parent.visible) return { ok: false, msg: '잠겼거나 숨긴 레이어예요 — 레이어를 풀고 다시 해 주세요' };
      }
      root = hyMark_drawOne(doc, parent, G);
      if (old) { root.move(old, ElementPlacement.PLACEBEFORE); old.remove(); }
      made.push(root);
    }
    if (P.removeSrc && used.length) {
      for (i = 0; i < used.length; i++) {          // 비게 될 수 있는 그룹을 적어 둔다
        try { par = used[i].parent; } catch (e2) { par = null; }
        if (!par) continue;
        try { if (par.typename !== 'GroupItem') continue; } catch (e3) { continue; }
        dup = false;
        for (j = 0; j < parents.length; j++) { if (hyMark_same(parents[j], par)) { dup = true; break; } }
        if (!dup) parents.push(par);
      }
      for (i = used.length - 1; i >= 0; i--) { try { used[i].remove(); } catch (e4) { } }
      for (i = 0; i < parents.length; i++) { try { if (parents[i].pageItems.length === 0) parents[i].remove(); } catch (e5) { } }
    }
    // 다시 그린 묶음 + (일부만 다시 그렸으면) 손대지 않은 나머지 묶음도 고른 채로 둔다.
    // 고치던 묶음이 그사이 선택에서 빠졌으면(도면을 눌러 선택을 풀었거나 다른 것을 골랐으면) 선택은 건드리지 않는다
    if (keepSel) {
      try {
        doc.selection = null;
        for (i = 0; i < made.length; i++) made[i].selected = true;
        if (now) { for (i = 0; i < now.length; i++) { if (!gone['n' + i]) { try { now[i].selected = true; } catch (e7) { } } } }
      } catch (e6) { }
    } else {          // 골라져 있던 묶음만 다시 고른다 (나머지 선택은 그대로)
      for (i = 0; i < made.length; i++) { if (wasSel[i]) { try { made[i].selected = true; } catch (e8) { } } }
    }
    return { ok: true, n: made.length, cut: hyMark_cut, kept: keepSel ? 1 : 0 };
  });
}

// 선택한 기호 묶음 읽기 (고치기 전): 상태 + 지금 기준점 자리 + 지금 글자.
// keep = 'keep' 이면 읽은 묶음을 기억하고 번호(tok)를 준다 — 바로 이어서 hyMark_apply 로 고칠 때만 쓴다 (그냥 읽기는 기억하지 않음)
function hyMark_read(keep) {
  return hyMark_guard(function () {
    if (!app.documents.length) return { ok: false, msg: '열린 문서가 없어요' };
    var doc = app.activeDocument, roots = hyMark_roots(doc), out = [], i, j, k, r, info, kids, sk, mode, data, sp, pp, texts, tfs, nt, parts, cur, a, b, arr, t;
    if (roots.length > 60) return { ok: false, msg: '한 번에 60묶음까지 고칠 수 있어요 (' + roots.length + '묶음 선택됨)' };
    for (i = 0; i < roots.length; i++) {
      r = roots[i];
      info = hyMark_parseNote(r.note);
      sk = null; mode = ''; data = null;
      kids = r.groupItems;
      for (j = 0; j < kids.length; j++) {
        try { if (String(kids[j].note).indexOf(HYM_SKEL) === 0) { sk = kids[j]; break; } } catch (e) { }
      }
      if (sk) {
        mode = String(sk.note).split('|')[1] || 'points';
        sp = sk.pathItems;
        data = [];
        if (mode === 'lines') {
          arr = [];
          for (j = 0; j < sp.length; j++) {
            pp = sp[j].pathPoints;
            if (pp.length < 2) continue;
            a = pp[0].anchor; b = pp[pp.length - 1].anchor;
            arr.push({ k: parseInt(sp[j].name, 10) || 0, v: [a[0], -a[1], b[0], -b[1]] });
          }
          arr.sort(function (x, y) { return x.k - y.k; });
          for (j = 0; j < arr.length; j++) data.push(arr[j].v);
        } else if (sp.length) {
          pp = sp[0].pathPoints;
          for (j = 0; j < pp.length; j++) { a = pp[j].anchor; data.push([a[0], -a[1]]); }
        }
        if (!data.length) data = null;
      }
      // 지금 글자 (사용자가 손으로 고친 것을 지키려고)
      texts = [];
      kids = r.groupItems;
      for (j = -1; j < kids.length; j++) {
        try { tfs = j < 0 ? r.textFrames : kids[j].textFrames; } catch (e2) { continue; }
        for (k = 0; k < tfs.length; k++) {
          t = tfs[k];
          try { nt = String(t.note); } catch (e3) { continue; }
          if (nt.indexOf(HYM_TEXT) !== 0) continue;
          parts = nt.split('|');
          texts.push({ i: parseInt(parts[1], 10), r: parts[2] || '', s: String(t.contents) });
        }
      }
      cur = r.position;
      out.push({ id: info.id, state: info.state, pos: info.pos, cur: [cur[0], cur[1]], mode: mode, skel: data, texts: texts });
    }
    if (keep === 'keep') {
      hyMark_tok++;
      hyMark_stash = { tok: hyMark_tok, roots: roots };
      return { ok: true, groups: out, tok: hyMark_tok };
    }
    hyMark_stash = null;
    return { ok: true, groups: out };
  });
}

/* ---------- 색·글꼴 가져오기, 도구 ---------- */
function hyMark_pickColor(hex) {
  return hyMark_guard(function () {
    var c = app.showColorPicker(hyMark_rgb(hex || '#000000')), h = hyMark_hexOf(c);
    if (!h) return { ok: false, msg: '색을 읽지 못했어요' };
    return { ok: true, hex: h };
  });
}
// 선택한 개체에서 칠·획 색과 글꼴을 읽는다
function hyMark_pickFrom() {
  return hyMark_guard(function () {
    if (!app.documents.length) return { ok: false, msg: '열린 문서가 없어요' };
    var doc = app.activeDocument, s, it, out = { ok: true }, ca, i, t;
    try { s = doc.selection; } catch (e) { s = null; }
    if (s && s.typename === 'TextRange') {
      ca = s.characterAttributes;
      try { out.font = ca.textFont.family; } catch (e2) { }
      try { out.fill = hyMark_hexOf(ca.fillColor); } catch (e3) { }
      return out;
    }
    s = hyMark_selection(doc);
    if (!s.length) return { ok: false, msg: '색이나 글꼴을 가져올 개체를 선택해 주세요' };
    for (i = 0; i < s.length && i < 20; i++) {
      it = s[i];
      try { t = it.typename; } catch (e4) { continue; }
      if (t === 'TextFrame') {
        try { ca = it.textRange.characterAttributes; if (!out.font) out.font = ca.textFont.family; if (!out.fill) out.fill = hyMark_hexOf(ca.fillColor); } catch (e5) { }
      } else if (t === 'PathItem') {
        try { if (it.filled && !out.fill) out.fill = hyMark_hexOf(it.fillColor); } catch (e6) { }
        try { if (it.stroked && !out.stroke) out.stroke = hyMark_hexOf(it.strokeColor); } catch (e7) { }
      }
    }
    if (!out.font && !out.fill && !out.stroke) return { ok: false, msg: '읽을 수 있는 색·글꼴이 없어요 (패스나 글자를 선택)' };
    return out;
  });
}
function hyMark_tool(name) {
  return hyMark_guard(function () {
    if (!app.documents.length) return { ok: false, msg: '열린 문서가 없어요' };
    if (name === 'pen') { try { app.activeDocument.selection = null; } catch (e) { } }
    try { app.selectTool(name === 'pen' ? 'Adobe Pen Tool' : 'Adobe Select Tool'); }
    catch (e2) { return { ok: false, msg: name === 'pen' ? '펜 도구(P)를 직접 골라 점을 찍어 주세요' : '' }; }
    return { ok: true };
  });
}
