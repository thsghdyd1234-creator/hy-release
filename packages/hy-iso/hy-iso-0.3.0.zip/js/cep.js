/* CEP 최소 연결부 — CSInterface.js 대신 필요한 것만 */
(function (global) {
  'use strict';
  var bridge = global.__adobe_cep__;

  function hostEnv() {
    try { return JSON.parse(bridge.getHostEnvironment()); } catch (e) { return null; }
  }

  function extensionPath() {
    try {
      var p = decodeURI(bridge.getSystemPath('extension'));
      return /^file:\/\/\/[A-Za-z]:/.test(p) ? p.replace('file:///', '') : p.replace('file://', '');
    } catch (e) { return ''; }
  }

  global.CEP = {
    available: !!bridge,
    evalScript: function (script, cb) {
      if (!bridge) { if (cb) cb('{"ok":false,"msg":"일러스트레이터 안에서 열어 주세요"}'); return; }
      bridge.evalScript(script, cb || function () {});
    },
    hostEnv: hostEnv,
    extensionPath: extensionPath,
    on: function (type, fn) {
      if (bridge && bridge.addEventListener) bridge.addEventListener(type, fn);
    }
  };
})(window);
