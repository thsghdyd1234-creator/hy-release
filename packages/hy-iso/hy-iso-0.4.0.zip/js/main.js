/* hy Iso 패널 */
(function () {
  'use strict';

  var D = Math.PI / 180;
  function dir(deg, len) { return [len * Math.cos(deg * D), len * Math.sin(deg * D)]; }

  // 투영값: X축·Y축이 수평선에서 올라가는 각도, Z축 각도(90 = 수직), 축별 길이 비율
  var PRESETS = {
    iso:  { x: 30, y: 30, z: 90, lx: 1, ly: 1, lz: 1 },
    ob45: { x: 45, y: 45, z: 90, lx: 1, ly: 1, lz: 1 },
    ob30: { x: 30, y: 60, z: 90, lx: 1, ly: 1, lz: 1 }
  };
  var KEYS = ['x', 'y', 'z', 'lx', 'ly', 'lz'];

  var STORE = 'hyIso.state.v1';
  var defaults = {
    proj: PRESETS.iso, link: true, live: false, mine: [], read: null,
    mode: 'unit', patterns: true, outline: false,
    order: 'lr', ref: [0.5, 0.5], gap: 60, conn: true,
    explodeOpen: false, fineOpen: true
  };
  var state = load();

  function load() {
    var s = {};
    try { s = JSON.parse(localStorage.getItem(STORE)) || {}; } catch (e) { s = {}; }
    var out = {};
    for (var k in defaults) out[k] = (s[k] !== undefined) ? s[k] : defaults[k];
    // 0.1.x 저장값 옮기기 (preset 이름 → 투영값)
    if (!s.proj && s.preset) {
      if (PRESETS[s.preset]) out.proj = PRESETS[s.preset];
      else if (s.preset === 'read' && s.read && s.read.deg) out.proj = projFromRead(s.read);
    }
    out.proj = copyProj(out.proj);
    out.live = false; // 미리보기는 늘 꺼진 채로 시작
    return out;
  }
  function save() {
    try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (e) {}
  }
  function copyProj(p) {
    var o = {};
    KEYS.forEach(function (k) { o[k] = Number(p[k]); });
    return o;
  }
  function sameProj(a, b) {
    return KEYS.every(function (k) { return Math.abs(a[k] - b[k]) < 1e-6; });
  }
  function projFromRead(r) {
    var l = r.lens || [1, 1, 1];
    return { x: r.deg.x, y: r.deg.y, z: r.deg.z, lx: l[0], ly: l[1], lz: l[2] };
  }

  function $(id) { return document.getElementById(id); }
  function all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function axesOf(p) {
    return {
      ex: dir(p.x, p.lx),
      ey: dir(180 - p.y, p.ly),
      ez: dir(p.z, p.lz)
    };
  }
  function axes() { return axesOf(state.proj); }

  /* ---------- 실행 ---------- */
  var statusTimer = null;
  function status(msg, kind) {
    var el = $('status');
    el.textContent = msg || '';
    el.className = 'status' + (kind ? ' ' + kind : '');
    clearTimeout(statusTimer);
    if (kind === 'ok') statusTimer = setTimeout(function () { el.className = 'status'; }, 2500);
  }

  function run(fn, args, cb) {
    document.body.classList.add('busy');
    var script = 'hyIso.' + fn + '(' + JSON.stringify(JSON.stringify(args || {})) + ')';
    CEP.evalScript(script, function (res) {
      document.body.classList.remove('busy');
      var r;
      try { r = JSON.parse(res); } catch (e) {
        r = { ok: false, msg: res === 'EvalScript error.' ? '스크립트 오류가 났어요. 일러스트레이터를 다시 시작해 주세요' : String(res) };
      }
      status(r.msg, r.ok ? 'ok' : 'err');
      if (cb) cb(r);
    });
  }

  function common() {
    return { axes: axes(), patterns: state.patterns, outline: !!state.outline };
  }

  /* ---------- 투영 ---------- */
  var SL = {
    x:  { min: 0,   max: 60,  step: 0.5,  unit: '°' },
    y:  { min: 0,   max: 60,  step: 0.5,  unit: '°' },
    z:  { min: 60,  max: 120, step: 0.5,  unit: '°' },
    lx: { min: 0.3, max: 1.5, step: 0.01, unit: '' },
    ly: { min: 0.3, max: 1.5, step: 0.01, unit: '' },
    lz: { min: 0.3, max: 1.5, step: 0.01, unit: '' }
  };
  function fmtVal(k, v) {
    if (k === 'z' && Math.abs(v - 90) < 1e-6) return '수직';
    return SL[k].unit ? (Math.round(v * 10) / 10) + '°' : v.toFixed(2);
  }

  function renderProj() {
    var p = state.proj;
    KEYS.forEach(function (k) {
      var el = $('sl-' + k);
      el.value = p[k];
      $('v-' + k).textContent = fmtVal(k, p[k]);
    });
    all('#presets button[data-p]').forEach(function (b) {
      var id = b.getAttribute('data-p');
      var q = id === 'read' ? (state.read ? projFromRead(state.read) : null) : PRESETS[id];
      b.classList.toggle('on', !!q && sameProj(q, p));
    });
    $('presetRead').disabled = !state.read;
    $('linkXY').setAttribute('data-on', state.link ? '1' : '0');
    renderMine();
    drawCube();
  }

  // 패널 안 미리보기 육면체 (윗면·좌면·우면)
  function drawCube() {
    var A = axes();
    function P(x, y, z) {
      return [x * A.ex[0] + y * A.ey[0] + z * A.ez[0], -(x * A.ex[1] + y * A.ey[1] + z * A.ez[1])];
    }
    var pts = {
      o: P(0, 0, 0), x: P(1, 0, 0), y: P(0, 1, 0), xy: P(1, 1, 0),
      z: P(0, 0, 1), xz: P(1, 0, 1), yz: P(0, 1, 1), xyz: P(1, 1, 1)
    };
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (var k in pts) {
      minX = Math.min(minX, pts[k][0]); maxX = Math.max(maxX, pts[k][0]);
      minY = Math.min(minY, pts[k][1]); maxY = Math.max(maxY, pts[k][1]);
    }
    var W = 120, H = 96, pad = 10;
    var sc = Math.min((W - 2 * pad) / Math.max(maxX - minX, 1e-6), (H - 2 * pad) / Math.max(maxY - minY, 1e-6));
    var ox = (W - (maxX - minX) * sc) / 2 - minX * sc, oy = (H - (maxY - minY) * sc) / 2 - minY * sc;
    function S(n) { return (pts[n][0] * sc + ox).toFixed(1) + ',' + (pts[n][1] * sc + oy).toFixed(1); }
    function poly(ns, cls) { return '<polygon class="' + cls + '" points="' + ns.map(S).join(' ') + '"/>'; }
    // 보이는 면: 윗면(z=1), 우면(y=0), 좌면(x=0)
    var svg = poly(['z', 'xz', 'xyz', 'yz'], 'cf top') +
              poly(['o', 'x', 'xz', 'z'], 'cf right') +
              poly(['o', 'y', 'yz', 'z'], 'cf left');
    $('cube').innerHTML = svg;
  }

  // 슬라이더
  var liveTimer = null;
  function onProjChanged(final) {
    save();
    renderProj();
    if (state.live && final) {
      clearTimeout(liveTimer);
      liveTimer = setTimeout(function () { run('reproject', common()); }, 30);
    }
  }
  KEYS.forEach(function (k) {
    var el = $('sl-' + k);
    el.min = SL[k].min; el.max = SL[k].max; el.step = SL[k].step;
    function set() {
      var v = Number(el.value);
      if (state.link && (k === 'x' || k === 'y')) { state.proj.x = v; state.proj.y = v; }
      else if (state.link && (k === 'lx' || k === 'ly')) { state.proj.lx = v; state.proj.ly = v; }
      else state.proj[k] = v;
    }
    el.addEventListener('input', function () { set(); onProjChanged(false); });
    el.addEventListener('change', function () { set(); onProjChanged(true); });
    // 값 글자 더블클릭 → 프리셋 값(등각)으로 되돌리기
    $('v-' + k).addEventListener('dblclick', function () {
      state.proj[k] = PRESETS.iso[k];
      if (state.link && (k === 'x' || k === 'y')) state.proj.x = state.proj.y = PRESETS.iso[k];
      if (state.link && (k === 'lx' || k === 'ly')) state.proj.lx = state.proj.ly = PRESETS.iso[k];
      onProjChanged(true);
    });
  });
  all('.nudge').forEach(function (b) {
    b.addEventListener('click', function () {
      var k = b.getAttribute('data-k'), d = Number(b.getAttribute('data-d'));
      var v = Math.max(SL[k].min, Math.min(SL[k].max, Math.round((state.proj[k] + d) * 100) / 100));
      $('sl-' + k).value = v;
      if (state.link && (k === 'x' || k === 'y')) { state.proj.x = v; state.proj.y = v; }
      else if (state.link && (k === 'lx' || k === 'ly')) { state.proj.lx = v; state.proj.ly = v; }
      else state.proj[k] = v;
      onProjChanged(true);
    });
  });

  $('linkXY').addEventListener('click', function () {
    state.link = !state.link;
    if (state.link) { state.proj.y = state.proj.x; state.proj.ly = state.proj.lx; }
    onProjChanged(true);
  });

  all('#presets button[data-p]').forEach(function (b) {
    b.addEventListener('click', function () {
      var id = b.getAttribute('data-p');
      if (id === 'read') {
        if (!state.read) return;
        state.proj = copyProj(projFromRead(state.read));
      } else {
        state.proj = copyProj(PRESETS[id]);
      }
      if (state.proj.x !== state.proj.y || state.proj.lx !== state.proj.ly) state.link = false;
      onProjChanged(true);
    });
  });

  $('btnRead').addEventListener('click', function () {
    run('readAngles', {}, function (r) {
      if (!r.ok) return;
      state.read = { deg: r.deg, lens: r.lens, ortho: r.ortho };
      state.proj = copyProj(projFromRead(state.read));
      state.link = false;
      onProjChanged(true);
    });
  });

  // 내 프리셋
  function renderMine() {
    var box = $('mine');
    box.innerHTML = '';
    state.mine.forEach(function (m, i) {
      var b = document.createElement('button');
      b.className = 'chip' + (sameProj(m.proj, state.proj) ? ' on' : '');
      b.title = 'X ' + fmtVal('x', m.proj.x) + ' · Y ' + fmtVal('y', m.proj.y) + ' · Z ' + fmtVal('z', m.proj.z) +
        ' · 길이 ' + [m.proj.lx, m.proj.ly, m.proj.lz].map(function (v) { return v.toFixed(2); }).join(':') + '\n우클릭: 지우기';
      b.textContent = m.name;
      b.addEventListener('click', function () {
        state.proj = copyProj(m.proj);
        state.link = state.proj.x === state.proj.y && state.proj.lx === state.proj.ly;
        onProjChanged(true);
      });
      b.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        state.mine.splice(i, 1);
        save();
        renderMine();
        status('내 프리셋을 지웠어요', 'ok');
      });
      box.appendChild(b);
    });
    var add = document.createElement('button');
    add.className = 'chip add';
    add.title = '지금 값을 내 프리셋으로 저장';
    add.textContent = '+ 저장';
    add.addEventListener('click', function () {
      for (var i = 0; i < state.mine.length; i++) {
        if (sameProj(state.mine[i].proj, state.proj)) { status('이미 저장된 값이에요', 'err'); return; }
      }
      var n = 1;
      var names = state.mine.map(function (m) { return m.name; });
      while (names.indexOf('내 각도 ' + n) >= 0) n++;
      state.mine.push({ name: '내 각도 ' + n, proj: copyProj(state.proj) });
      save();
      renderMine();
      status('내 프리셋에 저장했어요 (우클릭으로 지우기)', 'ok');
    });
    box.appendChild(add);
  }

  // 세부 조정 접기
  function renderFine() { $('secFine').classList.toggle('open', !!state.fineOpen); }
  $('foldFine').addEventListener('click', function () {
    state.fineOpen = !state.fineOpen;
    save();
    renderFine();
  });
  renderFine();

  // 선택에 실시간 반영 (미리보기)
  function renderLive() {
    $('optLive').setAttribute('data-on', state.live ? '1' : '0');
    $('liveBar').classList.toggle('show', !!state.live);
  }
  $('optLive').addEventListener('click', function () {
    if (!state.live) {
      state.live = true;
      renderLive();
      run('previewBegin', {}, function (r) {
        if (r.ok && r.n) run('reproject', common());
      });
    } else {
      endLive(false);
    }
  });
  function endLive(cancel) {
    state.live = false;
    renderLive();
    run('previewEnd', { cancel: cancel, patterns: state.patterns });
  }
  $('btnLiveOk').addEventListener('click', function () { endLive(false); });
  $('btnLiveCancel').addEventListener('click', function () { endLive(true); });
  renderLive();

  /* ---------- 면에 눕히기 ---------- */
  all('.plane').forEach(function (b) {
    b.addEventListener('click', function () {
      var a = common();
      a.plane = b.getAttribute('data-plane');
      a.mode = state.mode;
      run('fold', a);
    });
  });
  $('rotCcw').addEventListener('click', function () { var a = common(); a.dir = 1; run('rotate', a); });
  $('rotCw').addEventListener('click', function () { var a = common(); a.dir = -1; run('rotate', a); });
  $('btnUnfold').addEventListener('click', function () { run('unfold', common()); });
  $('btnRefold').addEventListener('click', function () { run('refold', common()); });

  function bindSeg(id, key) {
    var btns = all('#' + id + ' button');
    function render() {
      btns.forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-v') === state[key]); });
    }
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        state[key] = b.getAttribute('data-v');
        save();
        render();
      });
    });
    render();
  }

  function bindCheck(id, key) {
    var b = $(id);
    function render() { b.setAttribute('data-on', state[key] ? '1' : '0'); }
    b.addEventListener('click', function () {
      state[key] = !state[key];
      save();
      render();
    });
    render();
  }

  bindSeg('mode', 'mode');
  bindCheck('optPatterns', 'patterns');
  bindCheck('optOutline', 'outline');

  /* ---------- 층별 분해 (기본 접힘) ---------- */
  function renderFold() {
    $('secExplode').classList.toggle('open', !!state.explodeOpen);
  }
  $('foldExplode').addEventListener('click', function () {
    state.explodeOpen = !state.explodeOpen;
    save();
    renderFold();
  });
  renderFold();

  bindSeg('order', 'order');
  bindCheck('optConn', 'conn');

  var refGrid = $('ref');
  var REF_TIPS = ['왼쪽 위', '위 가운데', '오른쪽 위', '왼쪽 가운데', '가운데', '오른쪽 가운데', '왼쪽 아래', '아래 가운데', '오른쪽 아래'];
  for (var i = 0; i < 9; i++) {
    (function (i) {
      var b = document.createElement('button');
      b.title = REF_TIPS[i] + ' 기준으로 층 맞춤';
      b.addEventListener('click', function () {
        state.ref = [(i % 3) / 2, Math.floor(i / 3) / 2];
        save();
        renderRef();
      });
      refGrid.appendChild(b);
    })(i);
  }
  function renderRef() {
    all('#ref button').forEach(function (b, i) {
      var r = [(i % 3) / 2, Math.floor(i / 3) / 2];
      b.classList.toggle('on', r[0] === state.ref[0] && r[1] === state.ref[1]);
    });
  }
  renderRef();

  var gap = $('gap');
  function renderGap() {
    gap.value = state.gap;
    $('gapVal').textContent = state.gap + ' pt';
  }
  gap.addEventListener('input', function () {
    state.gap = Number(gap.value);
    $('gapVal').textContent = state.gap + ' pt';
  });
  gap.addEventListener('change', save);
  all('.steps button').forEach(function (b) {
    b.addEventListener('click', function () {
      state.gap = Math.max(0, Math.min(2000, state.gap + Number(b.getAttribute('data-d'))));
      if (state.gap > Number(gap.max)) gap.max = state.gap;
      save();
      renderGap();
    });
  });
  renderGap();

  $('btnExplode').addEventListener('click', function () {
    var a = common();
    a.order = state.order;
    a.ref = state.ref;
    a.gap = state.gap;
    a.connectors = state.conn;
    run('explode', a);
  });
  $('btnRegap').addEventListener('click', function () {
    var a = common();
    a.gap = state.gap;
    a.connectors = state.conn;
    run('regap', a);
  });

  /* ---------- 테마 ---------- */
  function applyTheme() {
    var env = CEP.hostEnv();
    if (!env || !env.appSkinInfo) return;
    var c = env.appSkinInfo.panelBackgroundColor.color;
    var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
    var root = document.documentElement;
    var light = (0.299 * r + 0.587 * g + 0.114 * b) > 140;
    root.setAttribute('data-theme', light ? 'light' : 'dark');
    function shade(d) {
      return 'rgb(' + [r, g, b].map(function (v) { return Math.max(0, Math.min(255, v + d)); }).join(',') + ')';
    }
    root.style.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
    root.style.setProperty('--c1', shade(light ? -22 : 14));
    root.style.setProperty('--c2', shade(light ? -34 : 26));
    root.style.setProperty('--c3', shade(light ? -12 : -10));
  }
  applyTheme();
  CEP.on('com.adobe.csxs.events.ThemeColorChanged', applyTheme);

  /* ---------- 시작 ---------- */
  renderProj();
  // manifest의 ScriptPath가 안 불렸을 때를 대비해 직접 불러온다
  CEP.evalScript('typeof hyIso', function (t) {
    if (t === 'object') return;
    var p = CEP.extensionPath();
    if (!p) return;
    CEP.evalScript('$.evalFile(' + JSON.stringify(p + '/jsx/hyIso.jsx') + ')', function () {});
  });
})();
