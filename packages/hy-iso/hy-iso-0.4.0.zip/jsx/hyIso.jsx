/*
 * hy Iso — 아이소 면 붙이기 (Illustrator ExtendScript, ES3)
 *
 * 평평한 요소(텍스트·아이콘·화살표·조닝 면·평면도)를 아이소/액소 면에 눕힌다.
 * 3D 정보를 만들지 않고, 면마다 2×2 선형 변형만 적용한다.
 *
 * 축 규칙 (화면 좌표, y 위쪽)
 *   ex : 3D X축 — 오른쪽 위로 올라가는 방향
 *   ey : 3D Y축 — 왼쪽 위로 올라가는 방향
 *   ez : 3D Z축 — 위쪽
 *   윗면 = (ex, ey), 우면 = (ex, ez), 좌면 = (-ey, ez)
 *
 * 각 객체에는 태그(hyIso)로 상태를 남긴다:
 *   s  : f(눕힘) / u(펼침)
 *   pl : top/left/right,  r : 면 안 회전(90° 단위)
 *   ax : 축 6개 값,  L : 현재 면 행렬 a,b,c,d
 *   pv : 변형 기준점(이 점은 눕히기·펼치기에서 움직이지 않음)
 *   rf : 저장 시점의 위치 기준(텍스트는 기준선 시작점, 그 외는 경계 좌상단) — 이동량 추적용
 *   fb : 평면 상태 경계(기준점 기준 상대값) — 연결선 계산용
 *   k, sid : 층별 분해에서의 층 번호, 묶음 id
 */
var hyIso = (function () {
  var TAG = 'hyIso';
  var TAG_STACK = 'hyIsoStack';
  var TAG_CONN = 'hyIsoConn';
  var calCache = {};
  var flipMode = null; // 변형 행렬 해석 방향 (null: 아직 모름)

  /* ---------- 직렬화 ---------- */
  function quote(s) {
    s = String(s);
    s = s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n');
    return '"' + s + '"';
  }

  function toJSON(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t == 'number') return isFinite(v) ? String(v) : 'null';
    if (t == 'boolean') return v ? 'true' : 'false';
    if (t == 'string') return quote(v);
    var i, out = [];
    if (v instanceof Array) {
      for (i = 0; i < v.length; i++) out.push(toJSON(v[i]));
      return '[' + out.join(',') + ']';
    }
    for (var k in v) {
      if (v.hasOwnProperty(k)) out.push(quote(k) + ':' + toJSON(v[k]));
    }
    return '{' + out.join(',') + '}';
  }

  function parseArgs(s) {
    if (!s) return {};
    return eval('(' + s + ')');
  }

  function done(obj) {
    obj.ok = true;
    return toJSON(obj);
  }

  function fail(msg) {
    return toJSON({ ok: false, msg: String(msg) });
  }

  /* ---------- 2×2 행렬 ---------- */
  // 점 (x, y) → (a·x + c·y, b·x + d·y)
  function mat(a, b, c, d) {
    return { a: a, b: b, c: c, d: d };
  }

  function mul(M, N) { // N 먼저, 그다음 M
    return mat(M.a * N.a + M.c * N.b, M.b * N.a + M.d * N.b,
               M.a * N.c + M.c * N.d, M.b * N.c + M.d * N.d);
  }

  function inv(M) {
    var det = M.a * M.d - M.b * M.c;
    if (Math.abs(det) < 1e-12) throw new Error('면 행렬이 뒤집을 수 없는 상태예요');
    return mat(M.d / det, -M.b / det, -M.c / det, M.a / det);
  }

  function apply(M, p) {
    return [M.a * p[0] + M.c * p[1], M.b * p[0] + M.d * p[1]];
  }

  function near(M, N) {
    var tol = 1e-3 * (1 + Math.abs(N.a) + Math.abs(N.b) + Math.abs(N.c) + Math.abs(N.d));
    return Math.abs(M.a - N.a) < tol && Math.abs(M.b - N.b) < tol &&
           Math.abs(M.c - N.c) < tol && Math.abs(M.d - N.d) < tol;
  }

  var ROT = [mat(1, 0, 0, 1), mat(0, 1, -1, 0), mat(-1, 0, 0, -1), mat(0, -1, 1, 0)];

  function axesFromArgs(ax) {
    return { ex: [ax.ex[0], ax.ex[1]], ey: [ax.ey[0], ax.ey[1]], ez: [ax.ez[0], ax.ez[1]] };
  }

  function axesToArr(ax) {
    return [ax.ex[0], ax.ex[1], ax.ey[0], ax.ey[1], ax.ez[0], ax.ez[1]];
  }

  function axesFromArr(a) {
    return { ex: [a[0], a[1]], ey: [a[2], a[3]], ez: [a[4], a[5]] };
  }

  function planeMatrix(axes, plane, rot) {
    var u, v;
    if (plane == 'top') {
      u = axes.ex; v = axes.ey;
    } else if (plane == 'right') {
      u = axes.ex; v = axes.ez;
    } else if (plane == 'left') {
      u = [-axes.ey[0], -axes.ey[1]]; v = axes.ez;
    } else {
      throw new Error('알 수 없는 면: ' + plane);
    }
    var r = ((rot % 4) + 4) % 4;
    return mul(mat(u[0], u[1], v[0], v[1]), ROT[r]);
  }

  /* ---------- 일러스트 변형 ---------- */
  function aiMatrix(M) {
    var m = app.getIdentityMatrix();
    m.mValueA = M.a; m.mValueB = M.b; m.mValueC = M.c; m.mValueD = M.d;
    m.mValueTX = 0; m.mValueTY = 0;
    return m;
  }

  // 임시 패스로 "문서 원점 기준 변형"이 실제로 어떤 사상인지 측정한다.
  function probe(container, M) {
    var p = container.pathItems.add();
    p.filled = false;
    p.stroked = false;
    p.setEntirePath([[0, 0], [100, 0], [0, 100]]);
    p.transform(aiMatrix(M), true, false, false, false, 1, Transformation.DOCUMENTORIGIN);
    var a0 = p.pathPoints[0].anchor, a1 = p.pathPoints[1].anchor, a2 = p.pathPoints[2].anchor;
    p.remove();
    return {
      q0: [a0[0], a0[1]],
      L: mat((a1[0] - a0[0]) / 100, (a1[1] - a0[1]) / 100, (a2[0] - a0[0]) / 100, (a2[1] - a0[1]) / 100)
    };
  }

  function flipped(M) {
    return mat(M.a, -M.b, -M.c, M.d);
  }

  // 원하는 선형 변형 L을 내기 위해 넘길 행렬과, 원점(0,0)이 가는 위치 q0
  function calibrate(container, L) {
    var key = [L.a, L.b, L.c, L.d].join(',');
    if (calCache[key]) return calCache[key];
    var order = flipMode === true ? [true, false] : [false, true];
    for (var i = 0; i < order.length; i++) {
      var M = order[i] ? flipped(L) : L;
      var r = probe(container, M);
      if (near(r.L, L)) {
        flipMode = order[i];
        calCache[key] = { M: M, q0: r.q0 };
        return calCache[key];
      }
    }
    throw new Error('변형 기준을 맞추지 못했어요');
  }

  function collectPaths(it, out) {
    var t = it.typename, i;
    if (t == 'PathItem') {
      out.push(it);
    } else if (t == 'CompoundPathItem') {
      for (i = 0; i < it.pathItems.length; i++) out.push(it.pathItems[i]);
    } else if (t == 'GroupItem') {
      for (i = 0; i < it.pageItems.length; i++) collectPaths(it.pageItems[i], out);
    }
  }

  // 선 두께·점선 간격은 다이어그램에서 일정해야 하므로 변형 뒤 되돌린다.
  function saveStrokes(it) {
    var ps = [], r = [];
    collectPaths(it, ps);
    for (var i = 0; i < ps.length; i++) {
      try {
        if (ps[i].stroked) r.push([ps[i], ps[i].strokeWidth, ps[i].strokeDashes]);
      } catch (e) {}
    }
    return r;
  }

  function sameArr(a, b) {
    if (!a || !b || a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) if (Math.abs(a[i] - b[i]) > 1e-4) return false;
    return true;
  }

  function restoreStrokes(r) {
    for (var i = 0; i < r.length; i++) {
      try {
        var p = r[i][0];
        if (Math.abs(p.strokeWidth - r[i][1]) > 1e-4) p.strokeWidth = r[i][1];
        if (r[i][2] && r[i][2].length && !sameArr(p.strokeDashes, r[i][2])) p.strokeDashes = r[i][2];
      } catch (e) {}
    }
  }

  // 점 x → P + L(x − P) + extra
  function applyAbout(it, L, P, opt, extra) {
    var cal = calibrate(it.layer, L);
    var LP = apply(L, P);
    var dx = P[0] - LP[0] - cal.q0[0] + (extra ? extra[0] : 0);
    var dy = P[1] - LP[1] - cal.q0[1] + (extra ? extra[1] : 0);
    var pat = !!opt.patterns;
    var strokes = saveStrokes(it);
    it.transform(aiMatrix(cal.M), true, pat, true, pat, 1, Transformation.DOCUMENTORIGIN);
    it.translate(dx, dy, true, pat, true, pat);
    restoreStrokes(strokes);
  }

  /* ---------- 경계·기준 ---------- */
  function boundsOf(it) {
    try {
      if (it.typename == 'GroupItem' && it.clipped) {
        for (var i = 0; i < it.pageItems.length; i++) {
          var c = it.pageItems[i];
          if (c.typename == 'PathItem' && c.clipping) return c.geometricBounds;
          if (c.typename == 'CompoundPathItem' && c.pathItems.length && c.pathItems[0].clipping) return c.geometricBounds;
        }
      }
    } catch (e) {}
    return it.geometricBounds;
  }

  function centerOf(b) {
    return [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
  }

  function refPoint(it) {
    if (it.typename == 'TextFrame') {
      try {
        var a = it.anchor;
        if (a && a.length == 2) return [a[0], a[1]];
      } catch (e) {}
    }
    var b = boundsOf(it);
    return [b[0], b[1]];
  }

  /* ---------- 태그 ---------- */
  function readTag(it, name) {
    try {
      var tags = it.tags;
      for (var i = 0; i < tags.length; i++) if (tags[i].name == name) return tags[i].value;
    } catch (e) {}
    return null;
  }

  function writeTag(it, name, value) {
    try {
      var tags = it.tags;
      for (var i = tags.length - 1; i >= 0; i--) if (tags[i].name == name) tags[i].remove();
    } catch (e) {}
    var t = it.tags.add();
    t.name = name;
    t.value = value;
  }

  function numArr(str) {
    var p = str.split(','), r = [];
    for (var i = 0; i < p.length; i++) r.push(parseFloat(p[i]));
    return r;
  }

  function packState(s) {
    return [
      's=' + s.s, 'pl=' + s.pl, 'r=' + s.r,
      'ax=' + s.ax.join(','),
      'L=' + [s.L.a, s.L.b, s.L.c, s.L.d].join(','),
      'pv=' + s.pv.join(','), 'rf=' + s.rf.join(','),
      'fb=' + (s.fb ? s.fb.join(',') : '0,0,0,0'),
      'k=' + s.k, 'sid=' + s.sid
    ].join(';');
  }

  function unpackState(v) {
    if (!v) return null;
    var s = { r: 0, k: -1, sid: '' };
    var parts = v.split(';');
    for (var j = 0; j < parts.length; j++) {
      var i = parts[j].indexOf('=');
      if (i < 0) continue;
      var key = parts[j].substring(0, i), val = parts[j].substring(i + 1);
      if (key == 's' || key == 'pl' || key == 'sid') {
        s[key] = val;
      } else if (key == 'r' || key == 'k') {
        s[key] = parseInt(val, 10);
      } else if (key == 'L') {
        var n = numArr(val);
        s.L = mat(n[0], n[1], n[2], n[3]);
      } else {
        s[key] = numArr(val);
      }
    }
    if (!s.L || !s.pv || !s.rf || !s.ax) return null;
    return s;
  }

  function getState(it) {
    return unpackState(readTag(it, TAG));
  }

  function setState(it, s) {
    writeTag(it, TAG, packState(s));
  }

  function packKV(o) {
    var r = [];
    for (var k in o) if (o.hasOwnProperty(k)) r.push(k + '=' + (o[k] instanceof Array ? o[k].join(',') : o[k]));
    return r.join(';');
  }

  function unpackKV(v) {
    var o = {};
    if (!v) return null;
    var parts = v.split(';');
    for (var j = 0; j < parts.length; j++) {
      var i = parts[j].indexOf('=');
      if (i >= 0) o[parts[j].substring(0, i)] = parts[j].substring(i + 1);
    }
    return o;
  }

  // 마지막 저장 이후 객체가 옮겨졌다면 그만큼 기준점도 옮긴다.
  function curPivot(it, s) {
    var rf = refPoint(it);
    return [s.pv[0] + rf[0] - s.rf[0], s.pv[1] + rf[1] - s.rf[1]];
  }

  /* ---------- 선택 ---------- */
  function getDoc() {
    if (app.documents.length == 0) throw new Error('열린 문서가 없어요');
    return app.activeDocument;
  }

  function getTargets(doc) {
    var sel = doc.selection;
    if (sel && sel.typename == 'TextRange') throw new Error('텍스트 편집 중이에요. Esc로 빠져나온 뒤 객체를 선택해 주세요');
    if (!sel || !sel.length) throw new Error('선택된 객체가 없어요');
    var out = [];
    for (var i = 0; i < sel.length; i++) out.push(sel[i]);
    return out;
  }

  function isStack(it) {
    return it.typename == 'GroupItem' && readTag(it, TAG_STACK) !== null;
  }

  // 태그가 붙은 객체를 찾는다. 그룹 안쪽까지 내려가되, 태그를 찾으면 거기서 멈춘다.
  function findTagged(it, out) {
    if (readTag(it, TAG) !== null) {
      out.push(it);
      return true;
    }
    var found = false;
    if (it.typename == 'GroupItem') {
      for (var i = 0; i < it.pageItems.length; i++) {
        if (findTagged(it.pageItems[i], out)) found = true;
      }
    }
    return found;
  }

  function stackOf(it) {
    var p = it;
    while (p && p.typename != 'Layer' && p.typename != 'Document') {
      if (isStack(p)) return p;
      p = p.parent;
    }
    return null;
  }

  function groupItems(items, name) {
    var first = items[0];
    var g = first.parent.groupItems.add();
    g.move(first, ElementPlacement.PLACEBEFORE);
    for (var i = 0; i < items.length; i++) items[i].move(g, ElementPlacement.PLACEATEND);
    g.name = name;
    return g;
  }

  function reselect(doc, items) {
    try {
      doc.selection = null;
      var arr = [];
      for (var i = 0; i < items.length; i++) if (items[i]) arr.push(items[i]);
      doc.selection = arr;
    } catch (e) {}
  }

  var PLANE_KO = { top: '윗면', left: '좌면', right: '우면' };

  /* ---------- hy Arrow 화살표 ---------- */
  // hy Arrow 플러그인 화살표는 선에 붙은 라이브 효과라, 선을 눕혀도 화살촉은 늘 똑바로 다시 그려진다.
  // 그래서 눕히기 전에 모양 확장 + 획 윤곽선으로 도형으로 바꿔 화살촉·몸통까지 같이 눕게 한다.
  var arrowPlugin = null;   // hy Arrow 플러그인이 있는지 (한 번만 확인)
  function hasArrowPlugin() {
    if (arrowPlugin === null) {
      try { arrowPlugin = String(app.sendScriptMessage('hyArrow', 'ping', '')).indexOf('"ok":true') >= 0; }
      catch (e) { arrowPlugin = false; }
    }
    return arrowPlugin;
  }
  // it(또는 그 안)에 hy Arrow 효과가 붙은 선이 있는지 — 플러그인에 물어본다
  function hasArrowIn(doc, it) {
    try {
      doc.selection = null;
      it.selected = true;
      return String(app.sendScriptMessage('hyArrow', 'info', '')).indexOf('"native":true') >= 0;
    } catch (e) { return false; }
  }
  function arrowToShape(doc, it) {
    try { if (!it.closed && it.filled) it.filled = false; } catch (e0) {}   // 열린 선의 칠은 끝끼리 이은 면이 됨
    doc.selection = null;
    it.selected = true;
    app.executeMenuCommand('expandStyle');           // 모양 확장: 화살촉·몸통이 실제 도형으로
    var sel = doc.selection;
    if (!sel || !sel.length) return it;
    var r = sel[0];
    doc.selection = null;
    r.selected = true;
    app.executeMenuCommand('OffsetPath v22');        // 획 윤곽선: 몸통도 면처럼 같이 기울어지게
    sel = doc.selection;
    if (sel && sel.length) r = sel[0];
    try { r.name = 'hy Arrow (도형)'; } catch (e1) {}
    return r;
  }
  /* ---------- 획을 면으로 ---------- */
  // 획은 변형해도 두께·점선 조각 모양이 그대로라 면을 따라 눕지 않는다. 윤곽선으로 바꾸면 같이 기울어진다.
  function hasStroke(it) {
    try {
      if (it.typename == 'PathItem') return it.stroked && it.strokeWidth > 0;
      if (it.typename == 'CompoundPathItem') return it.pathItems.length > 0 && hasStroke(it.pathItems[0]);
      if (it.typename == 'GroupItem') {
        for (var i = 0; i < it.pageItems.length; i++) if (hasStroke(it.pageItems[i])) return true;
      }
    } catch (e) {}
    return false;
  }
  function outlineStrokes(doc, it) {
    doc.selection = null;
    it.selected = true;
    app.executeMenuCommand('OffsetPath v22');   // 획 윤곽선 (점선은 조각마다 면이 됨)
    var sel = doc.selection;
    if (!sel || !sel.length) return it;
    if (sel.length == 1) return sel[0];
    var arr = [];
    for (var i = 0; i < sel.length; i++) arr.push(sel[i]);
    return groupItems(arr, 'hy Iso');
  }

  // 화살표를 찾아 도형으로 바꾸고 바뀐 객체를 돌려준다. 그룹은 화살표가 든 쪽으로만 내려간다.
  function convertArrows(doc, it, cnt) {
    if (!hasArrowIn(doc, it)) return it;
    if (it.typename == 'GroupItem') {
      var kids = [], i;
      for (i = 0; i < it.pageItems.length; i++) kids.push(it.pageItems[i]);
      for (i = 0; i < kids.length; i++) convertArrows(doc, kids[i], cnt);
      return it;
    }
    if (it.typename == 'PathItem') { cnt.n++; return arrowToShape(doc, it); }
    return it;
  }

  /* ---------- 눕히기 ---------- */
  function foldOne(it, plane, axes, opt) {
    var s = getState(it), L, P, b;
    if (s && s.s == 'f') {
      P = curPivot(it, s);
      L = planeMatrix(axes, plane, s.r);
      applyAbout(it, mul(L, inv(s.L)), P, opt, null);
    } else {
      b = boundsOf(it);
      P = s ? curPivot(it, s) : centerOf(b);
      if (!s) s = { r: 0, k: -1, sid: '' };
      L = planeMatrix(axes, plane, s.r);
      s.fb = [b[0] - P[0], b[1] - P[1], b[2] - P[0], b[3] - P[1]];
      applyAbout(it, L, P, opt, null);
    }
    s.s = 'f';
    s.pl = plane;
    s.ax = axesToArr(axes);
    s.L = L;
    s.pv = P;
    s.rf = refPoint(it);
    setState(it, s);
  }

  function unfoldOne(it, opt) {
    var s = getState(it);
    if (!s || s.s != 'f') return false;
    var P = curPivot(it, s);
    applyAbout(it, inv(s.L), P, opt, null);
    s.s = 'u';
    s.pv = P;
    s.rf = refPoint(it);
    setState(it, s);
    return true;
  }

  function refoldOne(it, opt) {
    var s = getState(it);
    if (!s || s.s != 'u') return false;
    foldOne(it, s.pl, axesFromArr(s.ax), opt);
    return true;
  }

  function rotateOne(it, dir, opt) {
    var s = getState(it);
    if (!s || s.s != 'f') return false;
    var P = curPivot(it, s);
    var r = (((s.r + dir) % 4) + 4) % 4;
    var L = planeMatrix(axesFromArr(s.ax), s.pl, r);
    applyAbout(it, mul(L, inv(s.L)), P, opt, null);
    s.r = r;
    s.L = L;
    s.pv = P;
    s.rf = refPoint(it);
    setState(it, s);
    return true;
  }

  // 선택을 "이미 눕힌 것"과 "새것"으로 나눈다.
  // allowStacks: 분해 묶음을 통째로 골랐을 때 안의 층들까지 대상으로 삼을지 (펼치기·다시 눕히기)
  function split(items, allowStacks) {
    var tagged = [], fresh = [], stacks = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (isStack(it) || stackOf(it.parent)) {
        if (readTag(it, TAG) !== null) tagged.push(it);
        else if (allowStacks && isStack(it)) findTagged(it, tagged);
        else stacks++;
        continue;
      }
      var found = [];
      if (findTagged(it, found)) {
        for (var j = 0; j < found.length; j++) tagged.push(found[j]);
      } else {
        fresh.push(it);
      }
    }
    return { tagged: tagged, fresh: fresh, stacks: stacks };
  }

  function fold(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = getTargets(doc);
      var axes = axesFromArgs(a.axes);
      var opt = { patterns: a.patterns !== false };
      var sp = split(items, false);
      var keep = [], g = null, i, j, n = 0, arrows = { n: 0 }, outlined = 0;
      function swap(list, k, now) {
        var was = list[k];
        if (now === was) return;
        list[k] = now;
        for (var q = 0; q < items.length; q++) if (items[q] === was) items[q] = now;
      }

      if (sp.fresh.length && hasArrowPlugin()) {
        for (i = 0; i < sp.fresh.length; i++) {
          var was = sp.fresh[i], now = convertArrows(doc, was, arrows);
          if (now !== was) {
            sp.fresh[i] = now;
            for (j = 0; j < items.length; j++) if (items[j] === was) items[j] = now;
          }
        }
      }

      if (a.outline) {
        // 새것은 바로 윤곽선으로. 이미 눕힌 것은 펼친 뒤 윤곽선으로 바꾸고 상태를 옮겨 다시 눕힌다.
        for (i = 0; i < sp.fresh.length; i++) {
          if (hasStroke(sp.fresh[i])) { swap(sp.fresh, i, outlineStrokes(doc, sp.fresh[i])); outlined++; }
        }
        for (i = 0; i < sp.tagged.length; i++) {
          var tg = sp.tagged[i];
          if (!hasStroke(tg)) continue;
          unfoldOne(tg, opt);
          var st = getState(tg), nw = outlineStrokes(doc, tg);
          if (nw !== tg && st) setState(nw, st);
          swap(sp.tagged, i, nw);
          outlined++;
        }
      }
      for (i = 0; i < sp.tagged.length; i++) {
        foldOne(sp.tagged[i], a.plane, axes, opt);
        n++;
      }
      if (sp.fresh.length > 1 && a.mode != 'each') {
        g = groupItems(sp.fresh, 'hy Iso');
        foldOne(g, a.plane, axes, opt);
        n++;
      } else {
        for (i = 0; i < sp.fresh.length; i++) {
          foldOne(sp.fresh[i], a.plane, axes, opt);
          n++;
        }
      }
      // 선택 유지: 새로 묶은 것은 묶음으로, 나머지는 원래대로
      for (i = 0; i < items.length; i++) {
        var grouped = false;
        if (g) for (j = 0; j < sp.fresh.length; j++) if (sp.fresh[j] === items[i]) grouped = true;
        if (!grouped) keep.push(items[i]);
      }
      if (g) keep.push(g);
      reselect(doc, keep);
      if (!n) return fail(sp.stacks ? '분해 묶음은 면을 바꿀 수 없어요. 층을 하나씩 선택해 주세요' : '눕힐 객체가 없어요');
      return done({ msg: PLANE_KO[a.plane] + '에 눕혔어요' + (n > 1 ? ' (' + n + '개)' : '') +
        (arrows.n ? ' · 화살표 ' + arrows.n + '개는 도형으로 바꿔 눕힘' : '') +
        (outlined ? ' · 획을 면으로 바꿈' : '') });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  function rotate(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = getTargets(doc);
      var opt = { patterns: a.patterns !== false };
      var sp = split(items, false), n = 0;
      for (var i = 0; i < sp.tagged.length; i++) if (rotateOne(sp.tagged[i], a.dir, opt)) n++;
      reselect(doc, items);
      if (!n) {
        if (sp.stacks) return fail('분해 묶음은 층을 하나씩 선택해서 돌려 주세요');
        return fail(sp.fresh.length ? '먼저 면에 눕혀 주세요' : '눕힌 상태인 객체가 없어요 (펼친 상태면 다시 눕힌 뒤 회전)');
      }
      return done({ msg: '면 안에서 90° 돌렸어요' + (n > 1 ? ' (' + n + '개)' : '') });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  function unfold(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = getTargets(doc);
      var opt = { patterns: a.patterns !== false };
      var sp = split(items, true), n = 0;
      for (var i = 0; i < sp.tagged.length; i++) if (unfoldOne(sp.tagged[i], opt)) n++;
      reselect(doc, items);
      if (!n) return fail(sp.tagged.length ? '이미 펼친 상태예요' : 'hy Iso로 눕힌 객체가 아니에요');
      return done({ msg: '평면으로 펼쳤어요' + (n > 1 ? ' (' + n + '개)' : '') + ' — 수정 후 다시 눕히기' });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  function refold(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = getTargets(doc);
      var opt = { patterns: a.patterns !== false };
      var sp = split(items, true), n = 0;
      for (var i = 0; i < sp.tagged.length; i++) if (refoldOne(sp.tagged[i], opt)) n++;
      reselect(doc, items);
      if (!n) return fail(sp.tagged.length ? '이미 눕힌 상태예요' : '펼쳐 둔 객체가 없어요');
      return done({ msg: '원래 면으로 다시 눕혔어요' + (n > 1 ? ' (' + n + '개)' : '') });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  /* ---------- 층별 분해 ---------- */
  function connColor(doc) {
    var c;
    if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
      c = new CMYKColor();
      c.cyan = 0; c.magenta = 0; c.yellow = 0; c.black = 60;
    } else {
      c = new RGBColor();
      c.red = 110; c.green = 110; c.blue = 110;
    }
    return c;
  }

  // 층 k의 경계 모서리에서 위층 높이까지 수직 점선
  function drawConnector(doc, floorItem, s, gap, sid) {
    var P = curPivot(floorItem, s);
    var ez = axesFromArr(s.ax).ez;
    var fb = s.fb;
    var corners = [[fb[0], fb[1]], [fb[2], fb[1]], [fb[2], fb[3]], [fb[0], fb[3]]];
    var cg = floorItem.parent.groupItems.add();
    cg.name = 'hy Iso 연결선';
    for (var j = 0; j < 4; j++) {
      var q = apply(s.L, corners[j]);
      var A = [P[0] + q[0], P[1] + q[1]];
      var B = [A[0] + gap * ez[0], A[1] + gap * ez[1]];
      var p = cg.pathItems.add();
      p.setEntirePath([A, B]);
      p.filled = false;
      p.stroked = true;
      p.strokeWidth = 0.5;
      p.strokeDashes = [3, 2];
      p.strokeColor = connColor(doc);
    }
    cg.move(floorItem, ElementPlacement.PLACEBEFORE);
    writeTag(cg, TAG_CONN, packKV({ k: s.k, sid: sid }));
    return cg;
  }

  function explode(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = getTargets(doc);
      var i, k;
      if (items.length < 2) throw new Error('층이 될 객체를 2개 이상 선택해 주세요 (층마다 그룹으로 묶어서)');
      if (items.length > 40) throw new Error('선택이 ' + items.length + '개예요. 층마다 그룹으로 묶은 뒤 선택해 주세요');
      for (i = 0; i < items.length; i++) {
        if (isStack(items[i]) || stackOf(items[i].parent)) throw new Error('이미 분해한 묶음이 섞여 있어요');
      }
      var axes = axesFromArgs(a.axes);
      var opt = { patterns: a.patterns !== false };
      var gap = Number(a.gap) || 0;
      var rx = a.ref ? a.ref[0] : 0.5, ry = a.ref ? a.ref[1] : 0.5;
      var rot = a.rot || 0;

      for (i = 0; i < items.length; i++) {
        var st = getState(items[i]);
        if (st && st.s == 'f') unfoldOne(items[i], opt);
      }

      var arr = [];
      for (i = 0; i < items.length; i++) {
        var b = boundsOf(items[i]);
        arr.push({ it: items[i], b: b, c: centerOf(b) });
      }
      var order = a.order || 'lr';
      arr.sort(function (p, q) {
        if (order == 'tb') return q.c[1] - p.c[1];
        if (order == 'bt') return p.c[1] - q.c[1];
        return p.c[0] - q.c[0];
      });

      var refOf = function (b) {
        return [b[0] + rx * (b[2] - b[0]), b[1] + ry * (b[3] - b[1])];
      };

      var L = planeMatrix(axes, 'top', rot);
      var R = refOf(arr[0].b);
      var sid = 'S' + (new Date()).getTime();
      var host = arr[0].it;
      var g = host.parent.groupItems.add();
      g.move(host, ElementPlacement.PLACEBEFORE);
      g.name = 'hy Iso 분해';

      var states = [];
      for (k = 0; k < arr.length; k++) {
        var e = arr[k];
        var r = refOf(e.b);
        var off = apply(L, [e.c[0] - r[0], e.c[1] - r[1]]);
        var target = [R[0] + k * gap * axes.ez[0] + off[0], R[1] + k * gap * axes.ez[1] + off[1]];
        applyAbout(e.it, L, e.c, opt, [target[0] - e.c[0], target[1] - e.c[1]]);
        e.it.move(g, ElementPlacement.PLACEATBEGINNING);
        var s = {
          s: 'f', pl: 'top', r: rot, ax: axesToArr(axes), L: L, pv: target,
          fb: [e.b[0] - e.c[0], e.b[1] - e.c[1], e.b[2] - e.c[0], e.b[3] - e.c[1]],
          k: k, sid: sid
        };
        s.rf = refPoint(e.it);
        setState(e.it, s);
        states.push(s);
      }
      if (a.connectors !== false) {
        for (k = 0; k < arr.length - 1; k++) drawConnector(doc, arr[k].it, states[k], gap, sid);
      }
      writeTag(g, TAG_STACK, packKV({ sid: sid, gap: gap, n: arr.length }));
      reselect(doc, [g]);
      return done({ msg: arr.length + '개 층으로 분해했어요 (간격 ' + gap + 'pt)' });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  function regap(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var items = getTargets(doc);
      var stacks = [], i, j;
      for (i = 0; i < items.length; i++) {
        var st = stackOf(items[i]);
        if (!st) continue;
        var dup = false;
        for (j = 0; j < stacks.length; j++) if (stacks[j] === st) dup = true;
        if (!dup) stacks.push(st);
      }
      if (!stacks.length) throw new Error('분해 묶음(hy Iso 분해)을 선택해 주세요');
      var gap = Number(a.gap) || 0;
      var pat = a.patterns !== false;

      for (i = 0; i < stacks.length; i++) {
        var g = stacks[i];
        var info = unpackKV(readTag(g, TAG_STACK));
        var oldGap = parseFloat(info.gap) || 0;
        var dg = gap - oldGap;
        var floors = [];
        for (j = g.pageItems.length - 1; j >= 0; j--) {
          var c = g.pageItems[j];
          if (readTag(c, TAG_CONN) !== null) {
            c.remove();
            continue;
          }
          var s = getState(c);
          if (s && s.sid == info.sid && s.k >= 0) floors.push({ it: c, s: s });
        }
        for (j = 0; j < floors.length; j++) {
          var f = floors[j];
          var ez = axesFromArr(f.s.ax).ez;
          if (f.s.k > 0 && dg !== 0) f.it.translate(dg * f.s.k * ez[0], dg * f.s.k * ez[1], true, pat, true, pat);
        }
        if (a.connectors !== false) {
          floors.sort(function (p, q) { return p.s.k - q.s.k; });
          for (j = 0; j < floors.length - 1; j++) {
            if (floors[j].s.s == 'f') drawConnector(doc, floors[j].it, floors[j].s, gap, info.sid);
          }
        }
        info.gap = gap;
        writeTag(g, TAG_STACK, packKV(info));
      }
      reselect(doc, stacks);
      return done({ msg: '층 간격을 ' + gap + 'pt로 바꿨어요' });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  /* ---------- 그림에서 각도 읽기 ---------- */
  function collectSegs(it, segs, budget) {
    if (budget.n <= 0) return;
    var t = it.typename, i;
    if (t == 'GroupItem') {
      for (i = 0; i < it.pageItems.length; i++) collectSegs(it.pageItems[i], segs, budget);
    } else if (t == 'CompoundPathItem') {
      for (i = 0; i < it.pathItems.length; i++) collectSegs(it.pathItems[i], segs, budget);
    } else if (t == 'PathItem') {
      budget.n--;
      var pts = it.pathPoints, n = pts.length;
      var last = it.closed ? n : n - 1;
      for (i = 0; i < last; i++) {
        var p = pts[i], q = pts[(i + 1) % n];
        var pa = p.anchor, qa = q.anchor, pr = p.rightDirection, ql = q.leftDirection;
        var straight = Math.abs(pr[0] - pa[0]) + Math.abs(pr[1] - pa[1]) < 0.01 &&
                       Math.abs(ql[0] - qa[0]) + Math.abs(ql[1] - qa[1]) < 0.01;
        if (!straight) continue;
        var dx = qa[0] - pa[0], dy = qa[1] - pa[1];
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5) continue;
        var ang = Math.atan2(dy, dx) * 180 / Math.PI;
        if (ang < 0) ang += 180;
        if (ang >= 180) ang -= 180;
        segs.push([ang, len]);
      }
    }
  }

  function peak(segs, lo, hi) {
    var bins = [], i, best = -1, bw = 0;
    for (i = 0; i < 180; i++) bins.push(0);
    for (i = 0; i < segs.length; i++) bins[Math.floor(segs[i][0]) % 180] += segs[i][1];
    for (i = 0; i < 180; i++) {
      if (i + 0.5 <= lo || i + 0.5 >= hi) continue;
      var w = bins[i] + 0.5 * ((i > 0 ? bins[i - 1] : 0) + (i < 179 ? bins[i + 1] : 0));
      if (w > bw) { bw = w; best = i; }
    }
    if (best < 0) return null;
    var sw = 0, sa = 0;
    for (i = 0; i < segs.length; i++) {
      if (Math.abs(segs[i][0] - (best + 0.5)) <= 2) { sw += segs[i][1]; sa += segs[i][0] * segs[i][1]; }
    }
    return sw > 0 ? { ang: sa / sw, w: sw } : null;
  }

  // 평행 투영이면 세 축이 화면에 보이는 각도만으로 축별 축소율이 정해진다.
  function axisLengths(tx, ty, tz) {
    var r = Math.PI / 90; // 2θ
    var cx = Math.cos(tx * r), sx = Math.sin(tx * r);
    var cy = Math.cos(ty * r), sy = Math.sin(ty * r);
    var cz = Math.cos(tz * r), sz = Math.sin(tz * r);
    var det = cy * sz - cz * sy;
    if (Math.abs(det) < 1e-6) return null;
    var qy = (-cx * sz + cz * sx) / det;
    var qz = (-cy * sx + cx * sy) / det;
    if (!(qy > 0) || !(qz > 0)) return null;
    var s = Math.sqrt(3 / (1 + qy + qz));
    return [s, Math.sqrt(qy) * s, Math.sqrt(qz) * s];
  }

  function readAngles() {
    try {
      var doc = getDoc();
      var items = getTargets(doc);
      var segs = [], budget = { n: 4000 };
      for (var i = 0; i < items.length; i++) collectSegs(items[i], segs, budget);
      if (segs.length < 2) throw new Error('직선이 부족해요. 액소 그림의 모서리 선들을 선택해 주세요');
      var px = peak(segs, 1, 80), py = peak(segs, 100, 179), pz = peak(segs, 80, 100);
      if (!px || !py) throw new Error('오른쪽 위·왼쪽 위로 가는 모서리 선이 모두 있어야 해요');
      var total = 0;
      for (i = 0; i < segs.length; i++) total += segs[i][1];
      var tz = (pz && pz.w > total * 0.02) ? pz.ang : 90;
      var lens = axisLengths(px.ang, py.ang, tz);
      var ortho = !!lens;
      if (!lens) lens = [1, 1, 1];
      var d = Math.PI / 180;
      var axes = {
        ex: [lens[0] * Math.cos(px.ang * d), lens[0] * Math.sin(px.ang * d)],
        ey: [lens[1] * Math.cos(py.ang * d), lens[1] * Math.sin(py.ang * d)],
        ez: [lens[2] * Math.cos(tz * d), lens[2] * Math.sin(tz * d)]
      };
      return done({
        axes: axes,
        deg: { x: px.ang, y: 180 - py.ang, z: tz },
        lens: lens,
        ortho: ortho,
        zFound: tz != 90 || !!pz,
        msg: ortho ? '각도를 읽었어요' : '평행 투영 비율이 아니라서 축 길이는 1:1:1로 뒀어요'
      });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  /* ---------- 투영 미리보기 (이미 눕힌 객체를 새 축으로 다시 눕힘) ---------- */
  var TAG_PREV = 'hyIsoPrev';

  function taggedSelection() {
    var doc = getDoc();
    var items = getTargets(doc);
    var sp = split(items, true), out = [];
    for (var i = 0; i < sp.tagged.length; i++) {
      var s = getState(sp.tagged[i]);
      if (s && s.s == 'f') out.push(sp.tagged[i]);
    }
    return { doc: doc, items: items, list: out };
  }

  // 미리보기 시작: 지금 축을 기억해 둔다 (취소할 때 되돌릴 값)
  function previewBegin() {
    try {
      var t = taggedSelection();
      for (var i = 0; i < t.list.length; i++) {
        if (readTag(t.list[i], TAG_PREV) === null) writeTag(t.list[i], TAG_PREV, getState(t.list[i]).ax.join(','));
      }
      return done({ n: t.list.length, msg: t.list.length ? '미리보기 중 — 슬라이더를 놓으면 반영돼요' : '눕힌 객체를 선택하면 바로 반영돼요' });
    } catch (e) {
      return done({ n: 0, msg: '눕힌 객체를 선택하면 바로 반영돼요' });
    }
  }

  function reproject(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var axes = axesFromArgs(a.axes);
      var opt = { patterns: a.patterns !== false };
      var t = taggedSelection();
      for (var i = 0; i < t.list.length; i++) {
        var it = t.list[i];
        if (readTag(it, TAG_PREV) === null) writeTag(it, TAG_PREV, getState(it).ax.join(','));
        foldOne(it, getState(it).pl, axes, opt);
      }
      reselect(t.doc, t.items);
      if (!t.list.length) return fail('눕힌 객체를 선택해 주세요');
      return done({ n: t.list.length, msg: '새 각도로 다시 눕혔어요' + (t.list.length > 1 ? ' (' + t.list.length + '개)' : '') });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  function clearPrev(it) {
    try {
      for (var i = it.tags.length - 1; i >= 0; i--) if (it.tags[i].name == TAG_PREV) it.tags[i].remove();
    } catch (e) {}
  }

  // 문서 전체에서 미리보기 표시가 남은 객체를 찾는다 (선택이 바뀌어도 되돌릴 수 있게)
  function collectPrev(container, out) {
    for (var i = 0; i < container.pageItems.length; i++) {
      var it = container.pageItems[i];
      if (readTag(it, TAG_PREV) !== null) out.push(it);
      else if (it.typename == 'GroupItem') collectPrev(it, out);
    }
  }

  function previewEnd(argStr) {
    try {
      calCache = {};
      var a = parseArgs(argStr);
      var doc = getDoc();
      var opt = { patterns: a.patterns !== false };
      var list = [], i;
      for (i = 0; i < doc.layers.length; i++) collectPrev(doc.layers[i], list);
      var n = 0;
      for (i = 0; i < list.length; i++) {
        var it = list[i];
        if (a.cancel) {
          var s = getState(it);
          var prev = numArr(readTag(it, TAG_PREV));
          if (s && prev.length == 6) {
            if (s.s == 'f') foldOne(it, s.pl, axesFromArr(prev), opt);
            else { s.ax = prev; setState(it, s); }
            n++;
          }
        }
        clearPrev(it);
      }
      return done({ msg: a.cancel ? (n ? '미리보기 전 각도로 되돌렸어요' : '미리보기를 껐어요') : '지금 각도로 확정했어요' });
    } catch (e) {
      return fail(e.message || e);
    }
  }

  function ping() {
    return done({ msg: 'ready', docs: app.documents.length });
  }

  return {
    fold: fold,
    rotate: rotate,
    unfold: unfold,
    refold: refold,
    explode: explode,
    regap: regap,
    readAngles: readAngles,
    previewBegin: previewBegin,
    reproject: reproject,
    previewEnd: previewEnd,
    ping: ping,
    _test: { planeMatrix: planeMatrix, axisLengths: axisLengths, mul: mul, inv: inv, apply: apply, packState: packState, unpackState: unpackState }
  };
})();
