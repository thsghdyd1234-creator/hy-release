/*  hy Halftone v1.0 — 선택 영역 안에 하프톤 도트 생성, 강조 패스(찢김 선) 주변 점 크기 제어
    패널 호출:
      hyHalftone_preview(json) / hyHalftone_run(json) / hyHalftone_cancel()
      hyHalftone_read() / hyHalftone_selInfo()
      hyHalftone_tag(json "area"|"emph") / hyHalftone_untag()
      hyHalftone_makeTear(json)
    결과 그룹: 이름 "hyHalftone" ( [clip] + dots ),
      note = {v, bounds:[L,T,R,B], cfg, emph:[{pts,closed}]}  → 그룹만 선택해도 재생성 가능
    태그(이름): 영역 "hyH_area", 강조 패스 "hyH_emph_1".."hyH_emph_N", 자동 찢김 선은 note "hyH_tear"
    내부 좌표: 영역 좌상단 원점, y 아래 방향(SVG와 동일). 일러 좌표 x = L + x, y = T - y
    생성 방식: 점들을 PDF(문서 색공간 그대로: CMYK는 k, RGB는 rg)로 써서 groupItems.createFromFile 로
              한 번에 가져옴 → 색이 정확하고 수천 개도 1초 안팎. 실패하면 SVG, 그것도 실패하면 DOM(4000개 제한)
    색상 모드: solid(색상 A) / area(영역 채우기 색 — 단색이면 그 색, 그라데이션이면 점 위치에서 샘플링, 밝기 보정)
              / gradient(색상 A→B, 기준: emph 강조 가중치 · size 점 크기 · pos 위치(선형 각도 / 방사형 중심))
              시작·끝·중간점은 두 색 그라데이션과 영역 그라데이션 샘플링 모두에 적용
    자르기: clip 클리핑 마스크 / cut 실제로 자르기(경계에 걸친 점만 Pathfinder Crop, 미리보기는 클립으로 표시)
            / none 자르지 않음(중심이 영역 모양 안인 점만). 영역 밖 점은 clip·cut에서 미리 버림
*/

var HYH_NAME = "hyHalftone";
var HYH_PV   = "hyHalftone_preview";
var HYH_AREA = "hyH_area";
var HYH_EMPH = "hyH_emph_";
var HYH_TEAR = "hyH_tear";
var HYH_MM   = 2.834645669;
var HYH_MAX_TAGS = 40;
var HYH_MAX_DOTS = 60000;
var HYH_STATE = { hidden: [] };

/* ============================================================ 공통 */
function hyH_parse(s) { return eval("(" + s + ")"); }

function hyH_json(v) {
    var t = typeof v, i, a;
    if (v === null || v === undefined) return "null";
    if (t === "number") return isFinite(v) ? String(Math.round(v * 1000) / 1000) : "0";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") {
        return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "").replace(/\n/g, "\\n") + '"';
    }
    if (v instanceof Array || Object.prototype.toString.call(v) === "[object Array]") {
        a = [];
        for (i = 0; i < v.length; i++) a.push(hyH_json(v[i]));
        return "[" + a.join(",") + "]";
    }
    a = [];
    for (var k in v) if (v.hasOwnProperty(k) && typeof v[k] !== "function") a.push('"' + k + '":' + hyH_json(v[k]));
    return "{" + a.join(",") + "}";
}

function hyH_num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }
function hyH_clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
function hyH_dist(p, q) { var dx = p[0] - q[0], dy = p[1] - q[1]; return Math.sqrt(dx * dx + dy * dy); }
function hyH_close(p, q) { return Math.abs(p[0] - q[0]) < 0.01 && Math.abs(p[1] - q[1]) < 0.01; }

/* Park–Miller 난수 (시드 고정 → 같은 결과) */
function hyH_lcg(seed) {
    var s = Math.floor(Math.abs(hyH_num(seed, 1))) % 2147483646 + 1;
    return function () { s = (s * 48271) % 2147483647; return (s - 1) / 2147483646; };
}

/* 패널에서 온 설정 정규화 (단위: mm, %, 도) */
function hyH_cfg(raw) {
    var c = raw || {};
    return {
        spacing:    hyH_clamp(hyH_num(c.spacing, 3), 0.3, 200),
        angle:      hyH_num(c.angle, 0),
        stagger:    !!c.stagger,
        shape:      c.shape || "circle",
        colorMode:  c.colorMode || "solid",
        color:      c.color || "#000000",
        color2:     c.color2 || "#2d8ceb",
        gradBy:     c.gradBy || "emph",
        areaShift:  hyH_clamp(hyH_num(c.areaShift, 0), -100, 100),
        maxScale:   hyH_clamp(hyH_num(c.maxScale, 105), 10, 300),
        minDot:     hyH_clamp(hyH_num(c.minDot, 0.15), 0, 50),
        gamma:      hyH_clamp(hyH_num(c.gamma, 1), 0.1, 5),
        tone:       c.tone || "radial",
        t0:         hyH_clamp(hyH_num(c.t0, 5), 0, 100),
        t1:         hyH_clamp(hyH_num(c.t1, 95), 0, 100),
        toneAngle:  hyH_num(c.toneAngle, 90),
        toneCx:     hyH_clamp(hyH_num(c.toneCx, 50), -200, 300),
        toneCy:     hyH_clamp(hyH_num(c.toneCy, 50), -200, 300),
        intensity:  hyH_clamp(hyH_num(c.intensity, 90), -100, 100),
        radius:     hyH_clamp(hyH_num(c.radius, 4), 0.1, 1000),
        falloff:    c.falloff || "smooth",
        emphMode:   c.emphMode || "band",
        jitterPos:  hyH_clamp(hyH_num(c.jitterPos, 0), 0, 100),
        jitterSize: hyH_clamp(hyH_num(c.jitterSize, 0), 0, 100),
        seed:       Math.floor(hyH_num(c.seed, 7)),
        cutMode:    (c.cutMode === "clip" || c.cutMode === "cut" || c.cutMode === "none") ? c.cutMode : (c.clip === false ? "none" : "clip"),
        gradType:   c.gradType === "radial" ? "radial" : "linear",
        gradAngle:  hyH_num(c.gradAngle, 90),
        gradCx:     hyH_clamp(hyH_num(c.gradCx, 50), -200, 300),
        gradCy:     hyH_clamp(hyH_num(c.gradCy, 50), -200, 300),
        gradStart:  hyH_clamp(hyH_num(c.gradStart, 0), 0, 100),
        gradEnd:    hyH_clamp(hyH_num(c.gradEnd, 100), 0, 100),
        gradMid:    hyH_clamp(hyH_num(c.gradMid, 50), 1, 99),
        delArea:    !!c.delArea,
        delEmph:    !!c.delEmph
    };
}

/* ============================================================ 색 (작업 공간 ws = "cmyk"|"rgb", 값은 0~1 배열) */
function hyH_hexToRgb(hex) {
    var h = String(hex || "#000000").replace("#", "");
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16);
    if (isNaN(r) || isNaN(g) || isNaN(b)) return [0, 0, 0];
    return [r / 255, g / 255, b / 255];
}
function hyH_rgb2cmyk(v) {
    var k = 1 - Math.max(v[0], v[1], v[2]);
    if (k >= 0.999) return [0, 0, 0, 1];
    return [(1 - v[0] - k) / (1 - k), (1 - v[1] - k) / (1 - k), (1 - v[2] - k) / (1 - k), k];
}
function hyH_cmyk2rgb(v) { return [(1 - v[0]) * (1 - v[3]), (1 - v[1]) * (1 - v[3]), (1 - v[2]) * (1 - v[3])]; }
function hyH_toWS(v, space, ws) { if (space === ws) return v; return ws === "cmyk" ? hyH_rgb2cmyk(v) : hyH_cmyk2rgb(v); }
function hyH_hexWS(hex, ws) { return hyH_toWS(hyH_hexToRgb(hex), "rgb", ws); }
function hyH_lerpCol(a, b, t) { var o = []; for (var i = 0; i < a.length; i++) o.push(a[i] + (b[i] - a[i]) * t); return o; }
/* amt > 0 밝게(흰색 쪽), amt < 0 어둡게 (CMYK는 K만 올려 색상 유지) */
function hyH_shiftCol(v, ws, amt) {
    var i, o = [];
    if (!amt) return v;
    if (amt > 0) { for (i = 0; i < v.length; i++) o.push(ws === "cmyk" ? v[i] * (1 - amt) : v[i] + (1 - v[i]) * amt); return o; }
    var a = -amt;
    if (ws === "cmyk") return [v[0], v[1], v[2], v[3] + (1 - v[3]) * a];
    for (i = 0; i < 3; i++) o.push(v[i] * (1 - a));
    return o;
}
/* 일러 색 객체 → ws 배열 (지원 안 하는 종류면 null) */
function hyH_colFromIll(col, ws) {
    if (!col) return null;
    var t = col.typename;
    if (t === "CMYKColor") return hyH_toWS([col.cyan / 100, col.magenta / 100, col.yellow / 100, col.black / 100], "cmyk", ws);
    if (t === "RGBColor") return hyH_toWS([col.red / 255, col.green / 255, col.blue / 255], "rgb", ws);
    if (t === "GrayColor") return hyH_toWS([0, 0, 0, col.gray / 100], "cmyk", ws);
    if (t === "SpotColor") { var base = hyH_colFromIll(col.spot.color, ws); return base ? hyH_shiftCol(base, ws, 1 - col.tint / 100) : null; }
    if (t === "LabColor") return hyH_toWS([0, 0, 0, 1 - col.l / 100], "cmyk", ws);
    return null;
}
function hyH_colToIll(v, ws) {
    if (ws === "cmyk") { var c = new CMYKColor(); c.cyan = v[0] * 100; c.magenta = v[1] * 100; c.yellow = v[2] * 100; c.black = v[3] * 100; return c; }
    var r = new RGBColor(); r.red = v[0] * 255; r.green = v[1] * 255; r.blue = v[2] * 255; return r;
}
function hyH_colToHex(v, ws) {
    var rgb = hyH_toWS(v, ws, "rgb"), s = "#";
    for (var i = 0; i < 3; i++) { var h = Math.round(hyH_clamp(rgb[i], 0, 1) * 255).toString(16); s += (h.length < 2 ? "0" : "") + h; }
    return s;
}
function hyH_colToPdf(v, ws) {
    var o = [];
    for (var i = 0; i < v.length; i++) o.push(hyH_clamp(v[i], 0, 1).toFixed(3));
    return o.join(" ") + (ws === "cmyk" ? " k" : " rg");
}
/* 영역의 채우기 색 객체 (그룹이면 안에서 처음 채워진 패스) */
function hyH_fillOf(item) {
    var t = item.typename, i, r;
    if (t === "PathItem") return item.filled ? item.fillColor : null;
    if (t === "CompoundPathItem") return (item.pathItems.length && item.pathItems[0].filled) ? item.pathItems[0].fillColor : null;
    if (t === "GroupItem") { for (i = 0; i < item.pageItems.length; i++) { r = hyH_fillOf(item.pageItems[i]); if (r) return r; } }
    return null;
}
/* → { solid:[..] } | { grad:{radial, stops:[{t,col}], ox, oy, ang, len} } | null   (origin·angle·length는 문서 좌표) */
function hyH_areaColor(item, ws) {
    try {
        var fc = hyH_fillOf(item);
        if (!fc) return null;
        if (fc.typename === "GradientColor") {
            var gr = fc.gradient, stops = [], i;
            for (i = 0; i < gr.gradientStops.length; i++) {
                var st = gr.gradientStops[i], c = hyH_colFromIll(st.color, ws);
                if (c) stops.push({ t: st.rampPoint / 100, col: c });
            }
            if (!stops.length) return null;
            stops.sort(function (a, b) { return a.t - b.t; });
            return { grad: { radial: gr.type === GradientType.RADIAL, stops: stops,
                             ox: fc.origin[0], oy: fc.origin[1], ang: fc.angle, len: Math.max(fc.length, 0.01) } };
        }
        var c1 = hyH_colFromIll(fc, ws);
        return c1 ? { solid: c1 } : null;
    } catch (e) { return null; }
}
/* 문서 좌표 (px,py)에서 그라데이션 색 샘플링 */
/* 시작·끝·중간점 → t 재매핑 함수 (끝 < 시작이면 반전) */
function hyH_remapFn(cfg) {
    var a = cfg.gradStart / 100, b = cfg.gradEnd / 100, m = cfg.gradMid / 100;
    var ex = Math.log(0.5) / Math.log(m);
    return function (t) {
        var u = (b === a) ? (t >= a ? 1 : 0) : (t - a) / (b - a);
        u = hyH_clamp(u, 0, 1);
        return (ex === 1) ? u : Math.pow(u, ex);
    };
}
function hyH_sampleGrad(g, px, py, remap) {
    var t;
    if (g.radial) { var dx = px - g.ox, dy = py - g.oy; t = Math.sqrt(dx * dx + dy * dy) / g.len; }
    else { var a = g.ang * Math.PI / 180; t = ((px - g.ox) * Math.cos(a) + (py - g.oy) * Math.sin(a)) / g.len; }
    t = hyH_clamp(t, 0, 1);
    if (remap) t = remap(t);
    var s = g.stops, n = s.length, i;
    if (t <= s[0].t) return s[0].col;
    if (t >= s[n - 1].t) return s[n - 1].col;
    for (i = 0; i + 1 < n; i++) {
        if (t >= s[i].t && t <= s[i + 1].t) {
            var span = s[i + 1].t - s[i].t;
            return span > 0 ? hyH_lerpCol(s[i].col, s[i + 1].col, (t - s[i].t) / span) : s[i].col;
        }
    }
    return s[n - 1].col;
}

/* ============================================================ 선택·대상 찾기 */
function hyH_selection(doc) {
    var sel = doc.selection, out = [];
    if (!sel || typeof sel.length !== "number") return out;
    for (var i = 0; i < sel.length; i++) if (sel[i] && sel[i].typename) out.push(sel[i]);
    return out;
}
function hyH_isGroupNamed(it, name) { return it.typename === "GroupItem" && it.name === name; }
function hyH_isPathLike(it) { return it.typename === "PathItem" || it.typename === "CompoundPathItem"; }
function hyH_isClosed(it) {
    if (it.typename === "PathItem") return it.closed;
    if (it.typename === "CompoundPathItem") return it.pathItems.length > 0 && it.pathItems[0].closed;
    return false;
}
function hyH_bboxArea(it) { var b = it.geometricBounds; return Math.abs((b[2] - b[0]) * (b[1] - b[3])); }
function hyH_byName(doc, name) { try { return doc.pageItems.getByName(name); } catch (e) { return null; } }
function hyH_canBeArea(it) {
    var t = it.typename;
    if (hyH_isPathLike(it)) return hyH_isClosed(it);
    return t === "GroupItem" || t === "PlacedItem" || t === "RasterItem" || t === "TextFrame" || t === "SymbolItem";
}

/*  r = { area, areaFrom, emph[], emphFrom, existing, preview }
    우선순위: 선택 안의 태그된 것 → 선택 안의 태그 안 된 것(가장 큰 닫힌 도형=영역, 나머지 패스=강조)
              → 문서에서 태그 이름으로 찾기 → (호출부에서) 기존 그룹 note */
function hyH_resolve(doc) {
    var sel = hyH_selection(doc), i, it, miss;
    var r = { area: null, areaFrom: "", emph: [], emphFrom: "", existing: null, preview: null };
    var loose = [];
    for (i = 0; i < sel.length; i++) {
        it = sel[i];
        if (hyH_isGroupNamed(it, HYH_NAME)) { r.existing = it; continue; }
        if (hyH_isGroupNamed(it, HYH_PV))   { r.preview = it; continue; }
        if (it.name === HYH_AREA) { r.area = it; r.areaFrom = "tag"; continue; }
        if (String(it.name).indexOf(HYH_EMPH) === 0) { r.emph.push(it); r.emphFrom = "tag"; continue; }
        loose.push(it);
    }
    if (!r.area && loose.length) {
        var best = -1, bi = -1;
        for (i = 0; i < loose.length; i++) {
            if (!hyH_canBeArea(loose[i])) continue;
            var a = hyH_bboxArea(loose[i]);
            if (a > best) { best = a; bi = i; }
        }
        if (bi >= 0) { r.area = loose[bi]; r.areaFrom = "sel"; loose.splice(bi, 1); }
    }
    if (r.emph.length === 0) {
        for (i = 0; i < loose.length; i++) {
            if (hyH_isPathLike(loose[i]) || loose[i].typename === "GroupItem") { r.emph.push(loose[i]); r.emphFrom = "sel"; }
        }
    }
    if (!r.area) { it = hyH_byName(doc, HYH_AREA); if (it) { r.area = it; r.areaFrom = "tag"; } }
    if (r.emph.length === 0) {
        for (i = 1, miss = 0; i <= HYH_MAX_TAGS && miss < 4; i++) {   // 번호가 비면 4개까지만 건너뜀
            it = hyH_byName(doc, HYH_EMPH + i);
            if (it) { r.emph.push(it); r.emphFrom = "tag"; miss = 0; } else miss++;
        }
    }
    return r;
}

function hyH_noteData(g) {
    if (!g) return null;
    try { var n = String(g.note); if (n.charAt(0) !== "{") return null; return hyH_parse(n); } catch (e) { return null; }
}

function hyH_targetLayer(doc, r) {
    var cand = [], i;
    try { if (r.existing) cand.push(r.existing.layer); } catch (e1) {}
    try { if (r.area) cand.push(r.area.layer); } catch (e2) {}
    cand.push(doc.activeLayer);
    for (i = 0; i < cand.length; i++) {
        var l = cand[i];
        if (l && !l.locked && l.visible) return l;
    }
    throw new Error("대상 레이어가 잠겨 있거나 숨겨져 있습니다.");
}

/* ============================================================ 패스 → 폴리라인 (내부 좌표) */
function hyH_flattenInto(it, out, L, T, tol) {
    var t = it.typename, i, j;
    if (t === "GroupItem") { for (i = 0; i < it.pageItems.length; i++) hyH_flattenInto(it.pageItems[i], out, L, T, tol); return; }
    if (t === "CompoundPathItem") { for (i = 0; i < it.pathItems.length; i++) hyH_flattenInto(it.pathItems[i], out, L, T, tol); return; }
    if (t !== "PathItem") return;
    var pp = it.pathPoints, n = pp.length;
    if (n < 2) return;
    var pts = [], segs = it.closed ? n : n - 1;
    for (i = 0; i < segs; i++) {
        var a = pp[i], b = pp[(i + 1) % n];
        var p0 = a.anchor, p1 = a.rightDirection, p2 = b.leftDirection, p3 = b.anchor;
        if (i === 0) pts.push([p0[0] - L, T - p0[1]]);
        if (hyH_close(p0, p1) && hyH_close(p2, p3)) {
            pts.push([p3[0] - L, T - p3[1]]);
        } else {
            var len = hyH_dist(p0, p1) + hyH_dist(p1, p2) + hyH_dist(p2, p3);
            var k = Math.max(3, Math.min(64, Math.ceil(len / tol)));
            for (j = 1; j <= k; j++) {
                var u = j / k, mu = 1 - u;
                var x = mu * mu * mu * p0[0] + 3 * mu * mu * u * p1[0] + 3 * mu * u * u * p2[0] + u * u * u * p3[0];
                var y = mu * mu * mu * p0[1] + 3 * mu * mu * u * p1[1] + 3 * mu * u * u * p2[1] + u * u * u * p3[1];
                pts.push([x - L, T - y]);
            }
        }
    }
    out.push({ pts: pts, closed: it.closed ? true : false });
}

/* ============================================================ 거리 계산 (버킷 인덱스) */
function hyH_segDist(x, y, s) {
    var dx = s[2] - s[0], dy = s[3] - s[1], l2 = dx * dx + dy * dy, t = 0;
    if (l2 > 0) t = hyH_clamp(((x - s[0]) * dx + (y - s[1]) * dy) / l2, 0, 1);
    var ex = x - (s[0] + t * dx), ey = y - (s[1] + t * dy);
    return Math.sqrt(ex * ex + ey * ey);
}
function hyH_buildIndex(segs, cell) {
    var idx = { cell: cell, map: {} }, i, gx, gy;
    for (i = 0; i < segs.length; i++) {
        var s = segs[i];
        var x0 = Math.floor(Math.min(s[0], s[2]) / cell), x1 = Math.floor(Math.max(s[0], s[2]) / cell);
        var y0 = Math.floor(Math.min(s[1], s[3]) / cell), y1 = Math.floor(Math.max(s[1], s[3]) / cell);
        for (gx = x0; gx <= x1; gx++) for (gy = y0; gy <= y1; gy++) {
            var k = gx + "," + gy;
            if (!idx.map[k]) idx.map[k] = [];
            idx.map[k].push(s);
        }
    }
    return idx;
}
/* 반경 R 안의 최단 거리, 없으면 Infinity (cell >= R 이면 3x3 탐색으로 정확) */
function hyH_nearDist(idx, x, y, R) {
    var gx = Math.floor(x / idx.cell), gy = Math.floor(y / idx.cell), best = Infinity, n = Math.ceil(R / idx.cell);
    for (var i = gx - n; i <= gx + n; i++) for (var j = gy - n; j <= gy + n; j++) {
        var arr = idx.map[i + "," + j];
        if (!arr) continue;
        for (var k = 0; k < arr.length; k++) { var d = hyH_segDist(x, y, arr[k]); if (d < best) best = d; }
    }
    return best;
}
function hyH_inPoly(x, y, pts) {
    var inside = false, n = pts.length;
    for (var i = 0, j = n - 1; i < n; j = i++) {
        var yi = pts[i][1], yj = pts[j][1];
        if ((yi > y) !== (yj > y)) {
            var xx = pts[i][0] + (y - yi) * (pts[j][0] - pts[i][0]) / (yj - yi);
            if (x < xx) inside = !inside;
        }
    }
    return inside;
}

/* ============================================================ 점 계산 */
function hyH_extent(shape, dia, s, ang) {
    if (shape === "circle") return [dia / 2, dia / 2];
    var a = ang + (shape === "diamond" ? Math.PI / 4 : 0);
    var w = (shape === "line") ? s * 1.02 : dia, h = dia;
    var c = Math.abs(Math.cos(a)), sn = Math.abs(Math.sin(a));
    return [w / 2 * c + h / 2 * sn, w / 2 * sn + h / 2 * c];
}

/* cc(색 컨텍스트) = { ws, mode, A, B, by, areaCol, shift, L, T } */
function hyH_computeDots(W, H, cfg, polys, cc) {
    var s = Math.max(cfg.spacing * HYH_MM, 0.5);
    var ang = -cfg.angle * Math.PI / 180;               // 일러 기준(반시계 +) → 내부 좌표(y 아래)
    var ca = Math.cos(ang), sa = Math.sin(ang);
    var cx = W / 2, cy = H / 2;
    var rowStep = cfg.stagger ? s * Math.sqrt(3) / 2 : s;
    var corners = [[0, 0], [W, 0], [0, H], [W, H]], i, j;
    var umin = Infinity, umax = -Infinity, vmin = Infinity, vmax = -Infinity;
    for (i = 0; i < 4; i++) {
        var rx = corners[i][0] - cx, ry = corners[i][1] - cy;
        var u = rx * ca + ry * sa, v = -rx * sa + ry * ca;
        if (u < umin) umin = u; if (u > umax) umax = u; if (v < vmin) vmin = v; if (v > vmax) vmax = v;
    }
    umin -= s; umax += s; vmin -= s; vmax += s;
    var est = ((umax - umin) / s + 1) * ((vmax - vmin) / rowStep + 1);
    if (est > HYH_MAX_DOTS) throw new Error("점이 너무 많습니다(약 " + Math.round(est) + "개). 간격을 늘려 주세요.");

    /* 강조 인덱스 */
    var segs = [], closedPolys = [], p, k;
    for (i = 0; i < polys.length; i++) {
        p = polys[i].pts;
        for (k = 0; k + 1 < p.length; k++) segs.push([p[k][0], p[k][1], p[k + 1][0], p[k + 1][1]]);
        if (polys[i].closed && p.length > 2) { segs.push([p[p.length - 1][0], p[p.length - 1][1], p[0][0], p[0][1]]); closedPolys.push(p); }
    }
    var R = Math.max(cfg.radius * HYH_MM, 0.01), I = cfg.intensity / 100;
    var useE = segs.length > 0 && I !== 0;
    var idx = useE ? hyH_buildIndex(segs, Math.max(R, 2)) : null;
    var inside = cfg.emphMode === "inside" && closedPolys.length > 0;

    /* 톤 */
    var t0 = cfg.t0 / 100, t1 = cfg.t1 / 100, tone = cfg.tone, g = cfg.gamma;
    var dxL = 0, dyL = 0, extL = 1, rcx = 0, rcy = 0, rmax = 1;
    if (tone === "linear") {
        var phi = cfg.toneAngle * Math.PI / 180;
        dxL = Math.cos(phi); dyL = -Math.sin(phi);           // 일러 그라디언트 각도 규칙 (90 = 아래→위)
        extL = (Math.abs(W * dxL) + Math.abs(H * dyL)) / 2;
        if (extL < 0.001) extL = 0.001;
    } else if (tone === "radial") {
        rcx = cfg.toneCx / 100 * W; rcy = cfg.toneCy / 100 * H;
        for (i = 0; i < 4; i++) { var dd = hyH_dist([rcx, rcy], corners[i]); if (dd > rmax) rmax = dd; }
    }

    var rnd = hyH_lcg(cfg.seed);
    var jp = cfg.jitterPos / 100 * s, js = cfg.jitterSize / 100;
    var maxDia = s * cfg.maxScale / 100, minDot = cfg.minDot * HYH_MM;
    var margin = (cfg.cutMode === "none") ? 0.001 : s;   // 자르지 않음이면 중심이 영역 안인 점만 (모양 판정은 hyH_classify)
    var remap = hyH_remapFn(cfg);
    var gLin = cfg.gradType !== "radial", gdx = 0, gdy = 0, gext = 1, gcx = 0, gcy = 0, grmax = 1;
    if (gLin) {
        var gph = cfg.gradAngle * Math.PI / 180;
        gdx = Math.cos(gph); gdy = -Math.sin(gph);
        gext = Math.max((Math.abs(W * gdx) + Math.abs(H * gdy)) / 2, 0.001);
    } else {
        gcx = cfg.gradCx / 100 * W; gcy = cfg.gradCy / 100 * H;
        for (var gi = 0; gi < 4; gi++) { var gd = hyH_dist([gcx, gcy], corners[gi]); if (gd > grmax) grmax = gd; }
    }
    var dots = [], bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
    var row = 0, v2;
    for (v2 = vmin; v2 <= vmax; v2 += rowStep, row++) {
        var uStart = umin + ((cfg.stagger && (row % 2)) ? s / 2 : 0);
        for (var u2 = uStart; u2 <= umax; u2 += s) {
            var x = cx + u2 * ca - v2 * sa, y = cy + u2 * sa + v2 * ca;
            var ox = (rnd() * 2 - 1) * jp, oy = (rnd() * 2 - 1) * jp, sz = 1 + (rnd() * 2 - 1) * js;
            x += ox; y += oy;
            if (x < -margin || x > W + margin || y < -margin || y > H + margin) continue;

            var t, qPos;
            if (tone === "uniform") { t = t0; qPos = hyH_clamp(1 - y / H, 0, 1); }
            else if (tone === "linear") {
                var q = ((x - cx) * dxL + (y - cy) * dyL + extL) / (2 * extL);
                qPos = hyH_clamp(q, 0, 1); t = t0 + (t1 - t0) * qPos;
            } else {
                var q2 = hyH_dist([x, y], [rcx, rcy]) / rmax;
                qPos = hyH_clamp(q2, 0, 1); t = t0 + (t1 - t0) * qPos;
            }
            t = hyH_clamp(t, 0, 1);
            if (g !== 1) t = Math.pow(t, g);

            var w = 0;
            if (useE) {
                var d = hyH_nearDist(idx, x, y, R);
                if (inside && d > 0) {
                    for (k = 0; k < closedPolys.length; k++) if (hyH_inPoly(x, y, closedPolys[k])) { d = 0; break; }
                }
                var qq = 1 - d / R;
                if (qq > 0) {
                    if (cfg.falloff === "linear") w = qq;
                    else if (cfg.falloff === "gauss") w = Math.exp(-4.5 * (d / R) * (d / R));
                    else w = qq * qq * (3 - 2 * qq);
                }
            }
            var sizeRaw = hyH_clamp(t + I * w, 0, 1), size = sizeRaw * sz;
            var dia = maxDia * size;
            if (dia < minDot || dia <= 0) continue;
            var col;
            if (cc.mode === "area" && cc.areaCol) {
                col = cc.areaCol.solid ? cc.areaCol.solid : hyH_sampleGrad(cc.areaCol.grad, cc.L + x, cc.T - y, remap);
                if (cc.shift) col = hyH_shiftCol(col, cc.ws, cc.shift);
            } else if (cc.mode === "gradient") {
                var ct;
                if (cc.by === "size") ct = sizeRaw;
                else if (cc.by === "emph") ct = w;
                else if (gLin) ct = ((x - cx) * gdx + (y - cy) * gdy + gext) / (2 * gext);
                else ct = hyH_dist([x, y], [gcx, gcy]) / grmax;
                col = hyH_lerpCol(cc.A, cc.B, remap(hyH_clamp(ct, 0, 1)));
            } else col = cc.A;
            var ext = hyH_extent(cfg.shape, dia, s, ang);
            if (x - ext[0] < bx0) bx0 = x - ext[0]; if (x + ext[0] > bx1) bx1 = x + ext[0];
            if (y - ext[1] < by0) by0 = y - ext[1]; if (y + ext[1] > by1) by1 = y + ext[1];
            dots.push([x, y, dia, col]);
        }
    }
    return { dots: dots, bx0: bx0, by0: by0, bx1: bx1, by1: by1, s: s, ang: ang };
}

/* ============================================================ SVG 생성 → 가져오기 */
function hyH_svg(W, H, res, cfg, ws) {
    var a = ['<svg xmlns="http://www.w3.org/2000/svg" width="' + W.toFixed(3) + 'pt" height="' + H.toFixed(3) + 'pt" viewBox="0 0 ' + W.toFixed(3) + ' ' + H.toFixed(3) + '">',
             '<rect x="0" y="0" width="' + W.toFixed(3) + '" height="' + H.toFixed(3) + '" fill="none" stroke="none"/>'];
    var col, shape = cfg.shape, rot = -cfg.angle, d, x, y, dia, i;
    var dots = res.dots;
    for (i = 0; i < dots.length; i++) {
        d = dots[i]; x = d[0].toFixed(2); y = d[1].toFixed(2); dia = d[2]; col = hyH_colToHex(d[3], ws);
        if (shape === "circle") {
            a.push('<circle cx="' + x + '" cy="' + y + '" r="' + (dia / 2).toFixed(2) + '" fill="' + col + '"/>');
        } else {
            var w = (shape === "line") ? res.s * 1.02 : dia, h = dia;
            var r2 = rot + (shape === "diamond" ? 45 : 0);
            a.push('<rect x="' + (d[0] - w / 2).toFixed(2) + '" y="' + (d[1] - h / 2).toFixed(2) + '" width="' + w.toFixed(2) + '" height="' + h.toFixed(2) + '" fill="' + col + '"' +
                   (r2 ? ' transform="rotate(' + r2.toFixed(2) + ' ' + x + ' ' + y + ')"' : '') + '/>');
        }
    }
    a.push('</svg>');
    return a.join("\n");
}

/* PDF 1.4 한 페이지 — 좌표는 좌하단 원점(y 위), 색은 문서 색공간 그대로 */
function hyH_pdf(W, H, res, cfg, ws) {
    var K = 0.5522847498, c = [], i, k, d, last = "", dots = res.dots;
    var f2 = function (n) { return n.toFixed(2); };
    c.push("q");
    c.push("0 0 " + f2(W) + " " + f2(H) + " re W n");
    for (i = 0; i < dots.length; i++) {
        d = dots[i];
        var x = d[0], y = H - d[1], dia = d[2], cs = hyH_colToPdf(d[3], ws);
        if (cs !== last) { c.push(cs); last = cs; }
        if (cfg.shape === "circle") {
            var r = dia / 2, kr = r * K;
            c.push(f2(x + r) + " " + f2(y) + " m");
            c.push(f2(x + r) + " " + f2(y + kr) + " " + f2(x + kr) + " " + f2(y + r) + " " + f2(x) + " " + f2(y + r) + " c");
            c.push(f2(x - kr) + " " + f2(y + r) + " " + f2(x - r) + " " + f2(y + kr) + " " + f2(x - r) + " " + f2(y) + " c");
            c.push(f2(x - r) + " " + f2(y - kr) + " " + f2(x - kr) + " " + f2(y - r) + " " + f2(x) + " " + f2(y - r) + " c");
            c.push(f2(x + kr) + " " + f2(y - r) + " " + f2(x + r) + " " + f2(y - kr) + " " + f2(x + r) + " " + f2(y) + " c");
            c.push("f");
        } else {
            var w = (cfg.shape === "line") ? res.s * 1.02 : dia, h = dia;
            var a = (cfg.angle + (cfg.shape === "diamond" ? 45 : 0)) * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
            var hw = w / 2, hh = h / 2, pts = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
            for (k = 0; k < 4; k++) {
                var px = x + pts[k][0] * ca - pts[k][1] * sa, py = y + pts[k][0] * sa + pts[k][1] * ca;
                c.push(f2(px) + " " + f2(py) + (k === 0 ? " m" : " l"));
            }
            c.push("h f");
        }
    }
    c.push("Q");
    var content = c.join("\n");
    var objs = [null,
        "<< /Type /Catalog /Pages 2 0 R >>",
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + f2(W) + " " + f2(H) + "] /Contents 4 0 R /Resources << /ProcSet [/PDF] >> >>",
        "<< /Length " + content.length + " >>\nstream\n" + content + "\nendstream"];
    var out = "%PDF-1.4\n", off = [];
    for (i = 1; i <= 4; i++) { off[i] = out.length; out += i + " 0 obj\n" + objs[i] + "\nendobj\n"; }
    var xref = out.length;
    out += "xref\n0 5\n0000000000 65535 f \n";
    for (i = 1; i <= 4; i++) { var o = String(off[i]); while (o.length < 10) o = "0" + o; out += o + " 00000 n \n"; }
    out += "trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n";
    return out;
}

function hyH_importFile(doc, layer, text, ext, binary) {
    var f = new File(Folder.temp.fsName + "/hyHalftone_" + new Date().getTime() + "." + ext);
    f.encoding = binary ? "BINARY" : "UTF-8"; f.lineFeed = "Unix";
    if (!f.open("w")) throw new Error("임시 파일을 만들 수 없습니다.");
    f.write(text); f.close();
    var lvl = app.userInteractionLevel, g = null;
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    try { g = layer.groupItems.createFromFile(f); } catch (e) { g = null; }
    app.userInteractionLevel = lvl;
    try { f.remove(); } catch (e2) {}
    return g;
}

/* 가져온 그룹을 영역 위치에 맞춤 (보조 사각형이 살아있으면 전체 박스 기준, 아니면 점 박스 기준) */
function hyH_align(g, res, L, T, W, H) {
    var bw = res.bx1 - res.bx0, bh = res.by1 - res.by0;
    var tol = 1.0 + 0.005 * Math.max(W, H);
    var gb = g.geometricBounds, gw = gb[2] - gb[0], gh = gb[1] - gb[3];
    var full = Math.abs(gw - W) < tol && Math.abs(gh - H) < tol;
    var fit = Math.abs(gw - bw) < tol && Math.abs(gh - bh) < tol;
    if (!full && !fit && gw > 0 && gh > 0) {
        var scF = W / gw, scD = bw / gw;
        var useFull = Math.abs(gh * scF - H) <= Math.abs(gh * scD - bh);
        var sc = (useFull ? scF : scD) * 100;
        g.resize(sc, sc, true, true, true, true, sc, Transformation.TOPLEFT);
        gb = g.geometricBounds;
        full = useFull; fit = !useFull;
    }
    var tx = full ? (L - gb[0]) : (L + res.bx0 - gb[0]);
    var ty = full ? (T - gb[1]) : (T - res.by0 - gb[1]);
    g.translate(tx, ty);
}

/* 가져오기 과정에서 생긴 클립·보조 사각형 제거 */
function hyH_cleanImport(g) {
    var i;
    function strip(grp) {
        if (grp.typename !== "GroupItem") return;
        if (grp.clipped) {
            for (i = grp.pageItems.length - 1; i >= 0; i--) { try { if (grp.pageItems[i].clipping) grp.pageItems[i].remove(); } catch (e) {} }
            try { grp.clipped = false; } catch (e1) {}
        }
        for (i = 0; i < grp.pageItems.length; i++) strip(grp.pageItems[i]);
    }
    strip(g);
    function helper(grp) {
        for (var k = grp.pageItems.length - 1; k >= 0; k--) {
            var it = grp.pageItems[k];
            if (it.typename === "GroupItem") { if (helper(it)) return true; continue; }
            if (it.typename === "PathItem" && !it.filled && !it.stroked && it.pathPoints.length === 4) { it.remove(); return true; }
        }
        return false;
    }
    helper(g);
}

function hyH_recolor(it, col) {
    var t = it.typename, i;
    if (t === "GroupItem") { for (i = 0; i < it.pageItems.length; i++) hyH_recolor(it.pageItems[i], col); return; }
    if (t === "CompoundPathItem") { for (i = 0; i < it.pathItems.length; i++) hyH_recolor(it.pathItems[i], col); return; }
    if (t === "PathItem" && !it.clipping) { it.filled = true; it.fillColor = col; it.stroked = false; }
}

/* SVG 가져오기 실패 시 DOM으로 직접 그리기 */
function hyH_drawDOM(doc, layer, res, cfg, L, T) {
    var dots = res.dots;
    if (dots.length > 4000) throw new Error("SVG 가져오기에 실패했고, 점이 " + dots.length + "개라 직접 그리기엔 너무 많습니다. 간격을 늘려 주세요.");
    var ws = (doc.documentColorSpace === DocumentColorSpace.CMYK) ? "cmyk" : "rgb";
    var g = layer.groupItems.add(), cache = {}, i, d, it, col;
    for (i = 0; i < dots.length; i++) {
        d = dots[i];
        var key = d[3].join(","); col = cache[key] || (cache[key] = hyH_colToIll(d[3], ws));
        var x = L + d[0], y = T - d[1], dia = d[2];
        if (cfg.shape === "circle") {
            it = g.pathItems.ellipse(y + dia / 2, x - dia / 2, dia, dia);
        } else {
            var w = (cfg.shape === "line") ? res.s * 1.02 : dia;
            it = g.pathItems.rectangle(y + dia / 2, x - w / 2, w, dia);
            var rot = cfg.angle + (cfg.shape === "diamond" ? 45 : 0);
            if (rot) it.rotate(rot, true, true, true, true, Transformation.CENTER);
        }
        it.filled = true; it.fillColor = col; it.stroked = false;
    }
    return g;
}

/* 점 경계 반지름(보수적) */
function hyH_dotRad(shape, dia, s) {
    if (shape === "circle") return dia / 2;
    var w = (shape === "line") ? s * 1.02 : dia;
    return Math.sqrt(w * w + dia * dia) / 2;
}
function hyH_inRings(x, y, rings) {
    var c = 0;
    for (var i = 0; i < rings.length; i++) if (hyH_inPoly(x, y, rings[i])) c++;
    return (c % 2) === 1;                                  // 짝홀 규칙 → 복합 패스 구멍 처리
}
/* 영역 모양 기준으로 점 분류: inner(완전히 안) / edge(경계에 걸침), 완전히 밖은 버림.
   centerOnly면 중심이 안쪽인 점을 전부 inner로 */
function hyH_classify(dots, areaPoly, cfg, s, centerOnly) {
    var segs = [], rings = [], i, k, p, out = { inner: [], edge: [] };
    for (i = 0; i < areaPoly.length; i++) {
        p = areaPoly[i].pts;
        if (!p || p.length < 3) continue;
        rings.push(p);
        for (k = 0; k < p.length; k++) { var q = p[(k + 1) % p.length]; segs.push([p[k][0], p[k][1], q[0], q[1]]); }
    }
    if (!rings.length) { out.inner = dots; return out; }
    var idx = hyH_buildIndex(segs, Math.max(s * 2, 4));
    for (i = 0; i < dots.length; i++) {
        var d = dots[i], inside = hyH_inRings(d[0], d[1], rings);
        if (centerOnly) { if (inside) out.inner.push(d); continue; }
        var rad = hyH_dotRad(cfg.shape, d[2], s) + 0.3;   // 곡선 평탄화 오차 여유
        var dist = hyH_nearDist(idx, d[0], d[1], rad);
        if (dist >= rad) { if (inside) out.inner.push(d); }
        else out.edge.push(d);
    }
    return out;
}
/* 점 목록의 박스 (가져오기 정렬용) */
function hyH_resOf(dots, cfg, s, ang) {
    var bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
    for (var i = 0; i < dots.length; i++) {
        var d = dots[i], e = hyH_extent(cfg.shape, d[2], s, ang);
        if (d[0] - e[0] < bx0) bx0 = d[0] - e[0]; if (d[0] + e[0] > bx1) bx1 = d[0] + e[0];
        if (d[1] - e[1] < by0) by0 = d[1] - e[1]; if (d[1] + e[1] > by1) by1 = d[1] + e[1];
    }
    return { dots: dots, bx0: bx0, by0: by0, bx1: bx1, by1: by1, s: s, ang: ang };
}
/* 영역 모양 패스를 parent 맨 위에 만듦: 영역 패스 복제, 아니면 저장된 폴리곤으로 */
function hyH_makeShape(parent, area, areaIsPath, areaPoly, L, T) {
    var c, i, k;
    if (areaIsPath) c = area.duplicate(parent, ElementPlacement.PLACEATBEGINNING);
    else {
        var rings = [];
        for (i = 0; i < areaPoly.length; i++) if (areaPoly[i].pts && areaPoly[i].pts.length > 2) rings.push(areaPoly[i].pts);
        var toDoc = function (p) { var o = []; for (k = 0; k < p.length; k++) o.push([L + p[k][0], T - p[k][1]]); return o; };
        if (rings.length === 1) { c = parent.pathItems.add(); c.setEntirePath(toDoc(rings[0])); c.closed = true; }
        else {
            c = parent.compoundPathItems.add();
            for (i = 0; i < rings.length; i++) { var pi = c.pathItems.add(); pi.setEntirePath(toDoc(rings[i])); pi.closed = true; }
        }
        c.move(parent, ElementPlacement.PLACEATBEGINNING);
    }
    c.name = ""; c.note = "";
    hyH_unstyle(c);
    return c;
}
function hyH_setClip(grp, c) {
    if (c.typename === "CompoundPathItem") { for (var i = 0; i < c.pathItems.length; i++) c.pathItems[i].clipping = true; }
    else c.clipping = true;
    grp.clipped = true;
}
function hyH_hasNamed(it, name) {
    try {
        if (it.name === name) return true;
        if (it.typename === "GroupItem") for (var i = 0; i < it.pageItems.length; i++) if (hyH_hasNamed(it.pageItems[i], name)) return true;
    } catch (e) {}
    return false;
}
function hyH_removeUnfilled(it) {
    var t = it.typename, i;
    if (t === "GroupItem") {
        for (i = it.pageItems.length - 1; i >= 0; i--) hyH_removeUnfilled(it.pageItems[i]);
        if (it.pageItems.length === 0 && it.parent && it.parent.typename === "GroupItem") { try { it.remove(); } catch (e0) {} }
        return;
    }
    if (t === "PathItem" && !it.filled && !it.stroked && !it.clipping) { try { it.remove(); } catch (e1) {} }
}
/* 그룹 맨 위 shp 로 Pathfinder Crop → 확장. 실패하면 null */
function hyH_crop(doc, grp, shp, bounds) {
    shp.name = "hyH_cropShape";
    try {
        doc.selection = null;
        grp.selected = true;
        app.executeMenuCommand("Live Pathfinder Crop");
        app.executeMenuCommand("expandStyle");
    } catch (e) { return null; }
    var sel = hyH_selection(doc);
    if (sel.length !== 1) return null;
    var out = sel[0];
    if (hyH_hasNamed(out, "hyH_cropShape")) return null;       // 효과가 안 먹음
    var b = out.geometricBounds, tol = 0.6;
    if (b[0] < bounds[0] - tol || b[1] > bounds[1] + tol || b[2] > bounds[2] + tol || b[3] < bounds[3] - tol) return null;
    hyH_removeUnfilled(out);
    return out;
}
/* 점 목록 → 가져온 그룹 (PDF → SVG → DOM) */
function hyH_importDots(doc, layer, W, H, dots, cfg, ws, s, ang, L, T, uniform) {
    var res = hyH_resOf(dots, cfg, s, ang);
    var g = hyH_importFile(doc, layer, hyH_pdf(W, H, res, cfg, ws), "pdf", true), via = "pdf";
    if (!g) { g = hyH_importFile(doc, layer, hyH_svg(W, H, res, cfg, ws), "svg", false); via = "svg"; }
    if (g) {
        hyH_align(g, res, L, T, W, H);
        hyH_cleanImport(g);
        /* SVG 경로는 RGB→CMYK 변환이 끼므로(검정→리치블랙) 단색이면 정확한 색으로 다시 칠함 */
        if (via === "svg" && ws === "cmyk" && uniform) hyH_recolor(g, hyH_colToIll(dots[0][3], ws));
        return g;
    }
    return hyH_drawDOM(doc, layer, res, cfg, L, T);
}

function hyH_findClip(grp) {
    try {
        if (!grp || grp.typename !== "GroupItem" || !grp.clipped) return null;
        for (var i = 0; i < grp.pageItems.length; i++) {
            var it = grp.pageItems[i];
            if (it.typename === "PathItem" && it.clipping) return it;
            if (it.typename === "CompoundPathItem" && it.pathItems.length && it.pathItems[0].clipping) return it;
        }
    } catch (e) {}
    return null;
}

function hyH_unstyle(it) {
    var t = it.typename, i;
    if (t === "CompoundPathItem") { for (i = 0; i < it.pathItems.length; i++) hyH_unstyle(it.pathItems[i]); return; }
    if (t === "PathItem") { it.filled = false; it.stroked = false; }
}

/* ============================================================ 생성 본체 */
/* 미리보기 때 숨긴 원본을 다시 보이게 하고, 아직 유효한 참조를 돌려줌 (선택이 풀려도 계속 쓰기 위해) */
function hyH_restoreHidden() {
    var out = { area: null, emph: [] };
    for (var i = 0; i < HYH_STATE.hidden.length; i++) {
        var h = HYH_STATE.hidden[i];
        try {
            h.it.hidden = false;
            var chk = h.it.geometricBounds;               // 삭제된 참조면 여기서 예외
            if (chk && h.kind === "area") out.area = h.it; else if (chk) out.emph.push(h.it);
        } catch (e) {}
    }
    HYH_STATE.hidden = [];
    return out;
}

function hyH_build(rawCfg, isPreview) {
    if (app.documents.length === 0) throw new Error("열린 문서가 없습니다.");
    var doc = app.activeDocument, cfg = hyH_cfg(rawCfg), i, k, warns = [];
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    var savedSel = hyH_selection(doc);
    var prev = hyH_restoreHidden();

    var r = hyH_resolve(doc);
    if (!r.area && prev.area) { r.area = prev.area; r.areaFrom = "sel"; }
    if (r.emph.length === 0 && prev.emph.length) { r.emph = prev.emph; r.emphFrom = "sel"; }
    var oldPv = r.preview || hyH_byName(doc, HYH_PV);
    var note = hyH_noteData(r.existing) || hyH_noteData(oldPv);
    var b;
    if (r.area) b = r.area.geometricBounds;
    else if (note && note.bounds) b = note.bounds;
    else throw new Error("영역을 선택하거나 [영역 지정]으로 지정해 주세요.");
    var L = b[0], T = b[1], W = b[2] - b[0], H = b[1] - b[3];
    if (W < 1 || H < 1) throw new Error("영역이 너무 작습니다.");

    var polys = [];
    var tol = Math.max(cfg.spacing * HYH_MM / 2, 0.5);
    if (r.emph.length) { for (i = 0; i < r.emph.length; i++) hyH_flattenInto(r.emph[i], polys, L, T, tol); }
    else if (note && note.emph) polys = note.emph;

    /* 영역 모양 (내부 좌표): 영역 패스 → 저장된 모양 → 기존 그룹의 클립 패스 → 사각형 */
    var areaIsPath = !!(r.area && hyH_isPathLike(r.area)), areaPoly = null, storePoly = false;
    if (areaIsPath) { areaPoly = []; hyH_flattenInto(r.area, areaPoly, L, T, 0.25); storePoly = true; }
    else if (!r.area && note && note.areaPoly && note.areaPoly.length) { areaPoly = note.areaPoly; storePoly = true; }
    else if (!r.area) {
        var cs = hyH_findClip(r.existing) || hyH_findClip(oldPv);
        if (cs) { areaPoly = []; try { hyH_flattenInto(cs, areaPoly, L, T, 0.25); storePoly = areaPoly.length > 0; } catch (eF) { areaPoly = null; } }
    }
    if (!areaPoly || !areaPoly.length) { areaPoly = [{ pts: [[0, 0], [W, 0], [W, H], [0, H]], closed: true }]; storePoly = false; }

    /* 색 */
    var ws = (doc.documentColorSpace === DocumentColorSpace.CMYK) ? "cmyk" : "rgb";
    var areaCol = r.area ? hyH_areaColor(r.area, ws) : ((note && note.areaCol) ? note.areaCol : null);
    if (cfg.colorMode === "area" && !areaCol) warns.push("영역에 채우기 색이 없어 대체 색을 썼습니다");
    var cc = { ws: ws, mode: cfg.colorMode, A: hyH_hexWS(cfg.color, ws), B: hyH_hexWS(cfg.color2, ws),
               by: cfg.gradBy, areaCol: areaCol, shift: cfg.areaShift / 100, L: L, T: T };
    var uniform = cfg.colorMode === "solid" || (cfg.colorMode === "area" && !(areaCol && areaCol.grad));

    var res = hyH_computeDots(W, H, cfg, polys, cc);
    var cls = hyH_classify(res.dots, areaPoly, cfg, res.s, cfg.cutMode === "none");
    var total = cls.inner.length + cls.edge.length;
    if (total === 0) throw new Error("생성된 점이 없습니다. 톤(크기)이나 최소 점 크기를 확인해 주세요.");
    var mode = cfg.cutMode;
    if (mode === "cut" && isPreview) { mode = "clip"; warns.push("미리보기는 클리핑으로 표시, 적용하면 실제로 자릅니다"); }

    if (oldPv) { try { oldPv.remove(); } catch (e0) {} }
    var layer = hyH_targetLayer(doc, r), g, shp;

    if (mode === "cut") {
        g = layer.groupItems.add();
        if (cls.inner.length) hyH_importDots(doc, layer, W, H, cls.inner, cfg, ws, res.s, res.ang, L, T, uniform).move(g, ElementPlacement.PLACEATEND);
        if (cls.edge.length) {
            var eg = hyH_importDots(doc, layer, W, H, cls.edge, cfg, ws, res.s, res.ang, L, T, uniform);
            shp = hyH_makeShape(eg, r.area, areaIsPath, areaPoly, L, T);
            var sb = shp.geometricBounds, bnd = [sb[0], sb[1], sb[2], sb[3]];
            var cut = hyH_crop(doc, eg, shp, bnd);
            if (cut) cut.move(g, ElementPlacement.PLACEATEND);
            else {
                warns.push("실제로 자르기에 실패해 클리핑 마스크로 대신했습니다");
                var sel0 = hyH_selection(doc);
                for (i = 0; i < sel0.length; i++) { try { if (sel0[i] !== g) sel0[i].remove(); } catch (eR) {} }
                try { eg.remove(); } catch (eR2) {}
                hyH_importDots(doc, layer, W, H, cls.edge, cfg, ws, res.s, res.ang, L, T, uniform).move(g, ElementPlacement.PLACEATEND);
                hyH_setClip(g, hyH_makeShape(g, r.area, areaIsPath, areaPoly, L, T));
            }
        }
    } else {
        g = hyH_importDots(doc, layer, W, H, cls.inner.concat(cls.edge), cfg, ws, res.s, res.ang, L, T, uniform);
        if (mode === "clip") { try { hyH_setClip(g, hyH_makeShape(g, r.area, areaIsPath, areaPoly, L, T)); } catch (e2) {} }
    }

    /* 위치(레이어 순서) */
    try {
        if (r.existing) g.move(r.existing, ElementPlacement.PLACEBEFORE);
        else if (r.area) g.move(r.area, ElementPlacement.PLACEBEFORE);
        else if (g.layer !== layer) g.move(layer, ElementPlacement.PLACEATBEGINNING);
    } catch (e1) {}

    /* note 저장 (그룹만 남아도 재생성 가능) */
    var round = function (list) {
        var out = [];
        for (var a = 0; a < list.length; a++) {
            var pp = list[a].pts, arr = [];
            for (k = 0; k < pp.length; k++) arr.push([Math.round(pp[k][0] * 10) / 10, Math.round(pp[k][1] * 10) / 10]);
            out.push({ pts: arr, closed: !!list[a].closed });
        }
        return out;
    };
    g.name = isPreview ? HYH_PV : HYH_NAME;
    g.note = hyH_json({ v: 2, bounds: [L, T, b[2], b[3]], cfg: cfg, emph: round(polys),
                        areaPoly: storePoly ? round(areaPoly) : null, areaCol: areaCol });

    /* 원본 처리 */
    if (isPreview) {
        if (cfg.delArea && r.area) { r.area.hidden = true; HYH_STATE.hidden.push({ it: r.area, kind: "area" }); }
        if (cfg.delEmph) for (i = 0; i < r.emph.length; i++) { r.emph[i].hidden = true; HYH_STATE.hidden.push({ it: r.emph[i], kind: "emph" }); }
    } else {
        if (r.existing) { try { r.existing.remove(); } catch (e3) {} }
        if (cfg.delArea && r.area) { try { r.area.remove(); } catch (e4) {} r.area = null; }
        if (cfg.delEmph) { for (i = 0; i < r.emph.length; i++) { try { r.emph[i].remove(); } catch (e5) {} } r.emph = []; }
    }

    /* 선택 복원 (영역·강조 패스가 계속 선택돼 있어야 슬라이더 연속 조작이 됨) */
    try {
        var keep = [];
        if (isPreview) {
            for (i = 0; i < savedSel.length; i++) {
                var it = savedSel[i];
                try { if (it.name !== HYH_PV && it.name !== HYH_AREA && String(it.name).indexOf(HYH_EMPH) !== 0 && !it.hidden) keep.push(it); } catch (e6) {}
            }
        } else keep.push(g);
        try { if (r.area && !r.area.hidden) keep.push(r.area); } catch (e8) {}
        for (i = 0; i < r.emph.length; i++) { try { if (!r.emph[i].hidden) keep.push(r.emph[i]); } catch (e9) {} }
        doc.selection = keep;
    } catch (e7) {}
    app.redraw();
    return total + (warns.length ? ";" + warns.join(" / ") : "");
}

/* ============================================================ 패널 API */
function hyHalftone_preview(json) {
    try { return "OK:" + hyH_build(hyH_parse(json), true); }
    catch (e) { return "ERR:" + e.message; }
}
function hyHalftone_run(json) {
    try { return "OK:" + hyH_build(hyH_parse(json), false); }
    catch (e) { return "ERR:" + e.message; }
}
function hyHalftone_cancel() {
    try {
        if (app.documents.length === 0) return "OK:0";
        var doc = app.activeDocument, pv = hyH_byName(doc, HYH_PV), n = 0;
        while (pv) { pv.remove(); n++; pv = hyH_byName(doc, HYH_PV); if (n > 50) break; }
        hyH_restoreHidden();
        app.redraw();
        return "OK:" + n;
    } catch (e) { return "ERR:" + e.message; }
}
function hyHalftone_read() {
    try {
        if (app.documents.length === 0) return "ERR:열린 문서가 없습니다.";
        var sel = hyH_selection(app.activeDocument);
        for (var i = 0; i < sel.length; i++) {
            if (hyH_isGroupNamed(sel[i], HYH_NAME) || hyH_isGroupNamed(sel[i], HYH_PV)) {
                var n = hyH_noteData(sel[i]);
                if (n && n.cfg) return "OK:" + hyH_json(hyH_cfg(n.cfg));
            }
        }
        return "ERR:선택한 것 중 hyHalftone 그룹이 없습니다.";
    } catch (e) { return "ERR:" + e.message; }
}
/* 패널 상태 표시용 (가벼움: 선택 + 태그 이름 조회만) */
function hyHalftone_selInfo() {
    try {
        if (app.documents.length === 0) return "OK:" + hyH_json({ doc: false });
        var doc = app.activeDocument, r = hyH_resolve(doc);
        var note = hyH_noteData(r.existing) || hyH_noteData(r.preview);
        var kind = "", fill = "none";
        if (r.area) {
            var t = r.area.typename;
            kind = (t === "PathItem" || t === "CompoundPathItem") ? "패스" : (t === "GroupItem" ? "그룹" : (t === "TextFrame" ? "텍스트" : "이미지"));
            try { var fc = hyH_fillOf(r.area); if (fc) fill = (fc.typename === "GradientColor") ? "gradient" : "solid"; } catch (eF) {}
        } else if (note && note.areaCol) fill = note.areaCol.grad ? "gradient" : "solid";
        return "OK:" + hyH_json({
            doc: true,
            area: r.area ? kind : "", areaFrom: r.areaFrom, areaFill: fill,
            areaNote: (!r.area && note && note.bounds) ? true : false,
            emph: r.emph.length, emphFrom: r.emphFrom,
            emphNote: (r.emph.length === 0 && note && note.emph) ? note.emph.length : 0,
            existing: !!r.existing, preview: !!r.preview
        });
    } catch (e) { return "ERR:" + e.message; }
}

/* 태그 지정: "area" = 선택 1개를 영역으로, "emph" = 선택한 패스들을 강조 패스로 (기존 태그는 교체) */
function hyHalftone_tag(json) {
    try {
        if (app.documents.length === 0) return "ERR:열린 문서가 없습니다.";
        var kind = hyH_parse(json), doc = app.activeDocument, sel = hyH_selection(doc), i, it, n = 0;
        if (kind === "area") {
            var pick = null;
            for (i = 0; i < sel.length; i++) if (hyH_canBeArea(sel[i]) && !hyH_isGroupNamed(sel[i], HYH_NAME) && !hyH_isGroupNamed(sel[i], HYH_PV)) { pick = sel[i]; break; }
            if (!pick) return "ERR:영역으로 쓸 닫힌 도형(또는 그룹·이미지)을 하나 선택해 주세요.";
            it = hyH_byName(doc, HYH_AREA); while (it) { it.name = ""; it = hyH_byName(doc, HYH_AREA); }
            if (String(pick.name).indexOf(HYH_EMPH) === 0) pick.name = "";
            pick.name = HYH_AREA;
            return "OK:1";
        }
        for (i = 1; i <= HYH_MAX_TAGS; i++) { it = hyH_byName(doc, HYH_EMPH + i); while (it) { it.name = ""; it = hyH_byName(doc, HYH_EMPH + i); } }
        for (i = 0; i < sel.length; i++) {
            it = sel[i];
            if (!(hyH_isPathLike(it) || it.typename === "GroupItem")) continue;
            if (hyH_isGroupNamed(it, HYH_NAME) || hyH_isGroupNamed(it, HYH_PV) || it.name === HYH_AREA) continue;
            if (n >= HYH_MAX_TAGS) break;
            n++; it.name = HYH_EMPH + n;
        }
        if (n === 0) return "ERR:강조 패스로 쓸 패스를 선택해 주세요.";
        return "OK:" + n;
    } catch (e) { return "ERR:" + e.message; }
}
function hyHalftone_untag() {
    try {
        if (app.documents.length === 0) return "ERR:열린 문서가 없습니다.";
        var doc = app.activeDocument, it, i, n = 0;
        it = hyH_byName(doc, HYH_AREA); while (it) { it.name = ""; n++; it = hyH_byName(doc, HYH_AREA); }
        for (i = 1; i <= HYH_MAX_TAGS; i++) { it = hyH_byName(doc, HYH_EMPH + i); while (it) { it.name = ""; n++; it = hyH_byName(doc, HYH_EMPH + i); } }
        return "OK:" + n;
    } catch (e) { return "ERR:" + e.message; }
}

/* ============================================================ 찢김 선 생성
   json: { dir:"h"|"v"|"d1"|"d2", pos:0~100(%), segs:정수, amp:mm, seed:정수, keep:bool }
   영역 위에 지그재그 열린 패스를 만들고 강조 패스로 태그. 영역이 태그 안 돼 있으면 같이 태그. */
function hyHalftone_makeTear(json) {
    try {
        if (app.documents.length === 0) return "ERR:열린 문서가 없습니다.";
        var p = hyH_parse(json) || {}, doc = app.activeDocument, i;
        app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
        var r = hyH_resolve(doc);
        var note = hyH_noteData(r.existing) || hyH_noteData(r.preview || hyH_byName(doc, HYH_PV));
        var b;
        if (r.area) b = r.area.geometricBounds;
        else if (note && note.bounds) b = note.bounds;
        else return "ERR:먼저 영역(닫힌 도형)을 선택해 주세요.";
        var L = b[0], T = b[1], W = b[2] - b[0], H = b[1] - b[3];

        var dir = p.dir || "d1", pos = hyH_clamp(hyH_num(p.pos, 50), 0, 100) / 100;
        var n = Math.max(2, Math.min(200, Math.round(hyH_num(p.segs, 16))));
        var amp = Math.max(0, hyH_num(p.amp, 5)) * HYH_MM;
        var rnd = hyH_lcg(hyH_num(p.seed, 11));
        var A, B;
        if (dir === "h")       { A = [0, H * pos]; B = [W, H * pos]; }
        else if (dir === "v")  { A = [W * pos, 0]; B = [W * pos, H]; }
        else if (dir === "d1") { A = [0, H * (pos - 0.25)]; B = [W, H * (pos + 0.25)]; }
        else                   { A = [0, H * (pos + 0.25)]; B = [W, H * (pos - 0.25)]; }
        var dx = B[0] - A[0], dy = B[1] - A[1], len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1) return "ERR:영역이 너무 작습니다.";
        var nx = -dy / len, ny = dx / len, pts = [];
        for (i = 0; i <= n; i++) {
            var q = i / n, off = 0, along = 0;
            if (i > 0 && i < n) {
                off = amp * (0.35 + 0.65 * rnd()) * ((i % 2) ? 1 : -1);
                along = (rnd() * 2 - 1) * 0.4 * len / n;
            }
            var x = A[0] + dx * q + nx * off + dx / len * along;
            var y = A[1] + dy * q + ny * off + dy / len * along;
            pts.push([L + x, T - y]);
        }

        /* 이전 자동 생성 선 제거 (keep이 아니면) */
        if (!p.keep) {
            for (i = 1; i <= HYH_MAX_TAGS; i++) {
                var old = hyH_byName(doc, HYH_EMPH + i);
                if (old && String(old.note) === HYH_TEAR) { try { old.remove(); } catch (e0) {} }
            }
        }
        var layer = hyH_targetLayer(doc, r);
        var path = layer.pathItems.add();
        path.setEntirePath(pts);
        path.closed = false; path.filled = false; path.stroked = true; path.strokeWidth = 0.5;
        var wsT = (doc.documentColorSpace === DocumentColorSpace.CMYK) ? "cmyk" : "rgb";
        path.strokeColor = hyH_colToIll(hyH_hexWS("#ff3b30", wsT), wsT);
        path.note = HYH_TEAR;
        try { if (r.area) path.move(r.area, ElementPlacement.PLACEBEFORE); } catch (e1) {}

        /* 태그: 다음 빈 번호 */
        var idx = 1;
        while (idx <= HYH_MAX_TAGS && hyH_byName(doc, HYH_EMPH + idx)) idx++;
        path.name = HYH_EMPH + Math.min(idx, HYH_MAX_TAGS);
        if (r.area && r.area.name !== HYH_AREA) {
            var prev = hyH_byName(doc, HYH_AREA); while (prev) { prev.name = ""; prev = hyH_byName(doc, HYH_AREA); }
            r.area.name = HYH_AREA;
        }
        try { doc.selection = r.area ? [r.area, path] : [path]; } catch (e2) {}
        app.redraw();
        return "OK:" + (n + 1);
    } catch (e) { return "ERR:" + e.message; }
}
