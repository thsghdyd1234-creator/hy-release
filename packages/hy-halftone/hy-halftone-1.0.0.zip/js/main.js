/* hy Halftone 패널 — jsx/halftone.jsx 의 hyHalftone_* 함수를 호출
   설정 키(단위: mm / % / 도)는 JSX hyH_cfg 와 동일. 마지막 설정은 localStorage 에 저장 */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var LS_KEY = "hyHalftone.cfg.v1";
  var DEFAULTS = {
    spacing: 3, angle: 0, stagger: false, shape: "circle", maxScale: 105, minDot: 0.15, gamma: 1,
    colorMode: "solid", color: "#000000", color2: "#2d8ceb", gradBy: "emph", areaShift: 0,
    gradType: "linear", gradAngle: 90, gradCx: 50, gradCy: 50, gradStart: 0, gradEnd: 100, gradMid: 50,
    tone: "radial", t0: 5, t1: 95, toneAngle: 90, toneCx: 50, toneCy: 50,
    intensity: 90, radius: 4, falloff: "smooth", emphMode: "band",
    jitterPos: 0, jitterSize: 0, seed: 7,
    cutMode: "clip", delArea: false, delEmph: false, live: true,
    tearDir: "d1", tearPos: 50, tearSegs: 16, tearAmp: 5, tearSeed: 11, tearKeep: false
  };
  var CFG_KEYS = ["spacing", "angle", "stagger", "shape", "maxScale", "minDot", "gamma",
                  "colorMode", "color", "color2", "gradBy", "areaShift",
                  "gradType", "gradAngle", "gradCx", "gradCy", "gradStart", "gradEnd", "gradMid",
                  "tone", "t0", "t1", "toneAngle", "toneCx", "toneCy",
                  "intensity", "radius", "falloff", "emphMode", "jitterPos", "jitterSize", "seed",
                  "cutMode", "delArea", "delEmph"];
  var busy = false, pending = null, timer = null, lastStatus = "", previewShown = false, suppress = false;

  /* ---------- JSX 호출 ---------- */
  function jsx(fn, arg, cb) {
    var code = fn + "(" + (arg === undefined ? "" : JSON.stringify(JSON.stringify(arg))) + ")";
    if (!window.__adobe_cep__) { cb && cb("ERR:CEP 환경이 아닙니다."); return; }
    window.__adobe_cep__.evalScript(code, function (res) { cb && cb(res === undefined || res === null ? "" : String(res)); });
  }
  function parseRes(res) {
    if (res.indexOf("OK:") === 0) return { ok: true, val: res.substr(3) };
    if (res.indexOf("ERR:") === 0) return { ok: false, val: res.substr(4) };
    return { ok: false, val: res || "응답이 없습니다. (jsx 로드 실패?)" };
  }
  function msg(text, cls) { var m = $("msg"); m.textContent = text || ""; m.className = "msg" + (cls ? " " + cls : ""); }

  /* ---------- 컨트롤 ---------- */
  var ctrls = {};                                        // key -> { get(), set(v) }

  function buildSlider(host) {
    var key = host.getAttribute("data-slider"), unit = host.getAttribute("data-unit") || "";
    var min = host.getAttribute("data-min"), max = host.getAttribute("data-max"), step = host.getAttribute("data-step");
    host.className = "sl"; host.id = "sl_" + key;
    host.innerHTML = '<label>' + host.getAttribute("data-label") + '</label>' +
      '<input type="range" min="' + min + '" max="' + max + '" step="' + step + '">' +
      '<input type="number" min="' + min + '" max="' + max + '" step="' + step + '">' +
      '<span class="unit">' + unit + '</span>';
    var r = host.children[1], n = host.children[2];
    var clampNum = function (v) { v = parseFloat(v); if (isNaN(v)) v = parseFloat(min); return Math.min(parseFloat(max), Math.max(parseFloat(min), v)); };
    r.addEventListener("input", function () { n.value = r.value; onChange(key); });
    n.addEventListener("change", function () { n.value = clampNum(n.value); r.value = n.value; onChange(key); });
    ctrls[key] = {
      get: function () { return parseFloat(n.value); },
      set: function (v) { v = clampNum(v); r.value = v; n.value = v; },
      host: host
    };
  }
  function bindSelect(key) {
    var el = $(key);
    el.addEventListener("change", function () { onChange(key); });
    ctrls[key] = { get: function () { return el.value; }, set: function (v) { el.value = v; } };
  }
  function bindCheck(key) {
    var el = $(key);
    el.addEventListener("change", function () { onChange(key); });
    ctrls[key] = { get: function () { return el.checked; }, set: function (v) { el.checked = !!v; } };
  }
  function bindNumber(key) {
    var el = $(key);
    el.addEventListener("change", function () { onChange(key); });
    ctrls[key] = { get: function () { var v = parseFloat(el.value); return isNaN(v) ? 0 : v; }, set: function (v) { el.value = v; } };
  }
  function bindColor(key, hexId) {
    var el = $(key), hex = $(hexId);
    el.addEventListener("input", function () { hex.textContent = el.value; updateGradBar(); });
    el.addEventListener("change", function () { hex.textContent = el.value; onChange(key); });
    ctrls[key] = { get: function () { return el.value; }, set: function (v) { el.value = v; hex.textContent = v; } };
  }

  function getAll() { var o = {}; for (var k in ctrls) o[k] = ctrls[k].get(); return o; }
  function getCfg() { var o = {}; for (var i = 0; i < CFG_KEYS.length; i++) o[CFG_KEYS[i]] = ctrls[CFG_KEYS[i]].get(); return o; }
  function setAll(obj) {
    suppress = true;
    for (var k in obj) if (ctrls[k] && obj[k] !== undefined && obj[k] !== null) ctrls[k].set(obj[k]);
    suppress = false;
    updateToneRows(); updateColorRows();
  }
  function save() { try { localStorage.setItem(LS_KEY, JSON.stringify(getAll())); } catch (e) {} }
  function load() {
    var o = {};
    try { o = JSON.parse(localStorage.getItem(LS_KEY) || "{}") || {}; } catch (e) { o = {}; }
    var merged = {};
    for (var k in DEFAULTS) merged[k] = (o[k] !== undefined) ? o[k] : DEFAULTS[k];
    if (o.cutMode === undefined && o.clip === false) merged.cutMode = "none";      // 이전 버전 설정 이어받기
    setAll(merged);
  }

  /* 톤 모드에 따라 보이는 행 바꾸기 */
  function updateToneRows() {
    var mode = ctrls.tone.get();
    var show = function (key, on, label) {
      var h = ctrls[key].host; h.className = "sl" + (on ? "" : " off");
      if (label) h.children[0].textContent = label;
    };
    show("t0", true, mode === "uniform" ? "크기" : (mode === "radial" ? "중심" : "시작"));
    show("t1", mode !== "uniform", mode === "radial" ? "가장자리" : "끝");
    show("toneAngle", mode === "linear");
    show("toneCx", mode === "radial");
    show("toneCy", mode === "radial");
  }

  /* 색상 모드에 따라 보이는 행 바꾸기 */
  function updateColorRows() {
    var m = ctrls.colorMode.get(), grad = m === "gradient", pos = grad && ctrls.gradBy.get() === "pos";
    var lin = ctrls.gradType.get() !== "radial";
    var sl = function (key, on) { ctrls[key].host.className = "sl" + (on ? "" : " off"); };
    $("rowColorA").children[0].textContent = grad ? "색상 A" : (m === "area" ? "대체 색" : "색상");
    $("rowColorB").style.display = grad ? "" : "none";
    $("rowGradBy").style.display = grad ? "" : "none";
    sl("areaShift", m === "area");
    $("rowGradType").style.display = pos ? "" : "none";
    sl("gradAngle", pos && lin);
    sl("gradCx", pos && !lin);
    sl("gradCy", pos && !lin);
    sl("gradStart", m !== "solid");                  // 영역 채우기가 그라데이션일 때도 범위 적용
    sl("gradEnd", m !== "solid");
    sl("gradMid", m !== "solid");
    $("gradBar").style.display = grad ? "" : "none";
    updateGradBar();
  }
  /* 시작·끝·중간점을 CSS 색 힌트로 표시 (CSS 힌트도 같은 거듭제곱 곡선) */
  function updateGradBar() {
    var bar = $("gradBar"); if (!bar || !ctrls.gradStart) return;
    var a = ctrls.color.get(), b = ctrls.color2.get();
    var s = ctrls.gradStart.get(), e = ctrls.gradEnd.get(), m = ctrls.gradMid.get() / 100, css;
    if (e >= s) css = a + " " + s + "%, " + (s + (e - s) * m).toFixed(1) + "%, " + b + " " + e + "%";
    else css = b + " " + e + "%, " + (e + (s - e) * (1 - m)).toFixed(1) + "%, " + a + " " + s + "%";
    bar.style.background = "linear-gradient(90deg, " + css + ")";
  }

  /* ---------- 미리보기 ---------- */
  function onChange(key) {
    if (suppress) return;
    if (key === "tone") updateToneRows();
    if (key === "colorMode" || key === "gradBy" || key === "gradType" || key.indexOf("grad") === 0 || key.indexOf("color") === 0) updateColorRows();
    save();
    if (key === "live") { if (!ctrls.live.get()) cancelPreview(); else schedulePreview(); return; }
    if (key.indexOf("tear") === 0) return;         // 찢김 선 옵션은 버튼으로만
    if (ctrls.live.get()) schedulePreview();
  }
  function schedulePreview() {
    clearTimeout(timer);
    timer = setTimeout(runPreview, 180);
  }
  function runPreview() {
    if (busy) { pending = "preview"; return; }
    busy = true; pending = null;
    jsx("hyHalftone_preview", getCfg(), function (res) {
      busy = false;
      var r = parseRes(res);
      if (r.ok) { previewShown = true; var pv = r.val.split(";"); msg("미리보기 · 점 " + pv[0] + "개" + (pv[1] ? " · " + pv[1] : "")); }
      else msg(r.val, "err");
      if (pending === "preview") runPreview();
      else if (pending === "run") runApply();
      else if (pending === "cancel") cancelPreview();
    });
  }
  function cancelPreview() {
    if (busy) { pending = "cancel"; return; }
    busy = true; pending = null;
    jsx("hyHalftone_cancel", undefined, function (res) {
      busy = false; previewShown = false;
      var r = parseRes(res);
      msg(r.ok ? "" : r.val, r.ok ? "" : "err");
      if (pending === "preview") runPreview();
      refreshStatus();
    });
  }
  function runApply() {
    if (busy) { pending = "run"; return; }
    busy = true; pending = null;
    clearTimeout(timer);
    jsx("hyHalftone_run", getCfg(), function (res) {
      busy = false; previewShown = false;
      var r = parseRes(res);
      var rv = r.val.split(";");
      msg(r.ok ? "생성 완료 · 점 " + rv[0] + "개 (그룹 hyHalftone)" + (rv[1] ? " · " + rv[1] : "") : r.val, r.ok ? "ok" : "err");
      refreshStatus();
    });
  }

  /* ---------- 상태 ---------- */
  function refreshStatus() {
    if (busy) return;
    jsx("hyHalftone_selInfo", undefined, function (res) {
      var r = parseRes(res);
      if (!r.ok) { setStatus(r.val, true); return; }
      var s; try { s = JSON.parse(r.val); } catch (e) { return; }
      if (!s.doc) { setStatus("열린 문서가 없습니다.", true); return; }
      var from = function (f) { return f === "tag" ? "지정" : (f === "sel" ? "선택" : ""); };
      var fillTxt = s.areaFill === "gradient" ? " · 그라데이션 채우기" : (s.areaFill === "solid" ? " · 단색 채우기" : " · 채우기 없음");
      var a = s.area ? "<b>영역</b> " + s.area + " (" + from(s.areaFrom) + ")" + fillTxt
            : (s.areaNote ? "<b>영역</b> 저장된 좌표" + fillTxt : "<b>영역 없음</b> — 닫힌 도형을 선택하세요");
      var e = s.emph ? "<b>강조 패스</b> " + s.emph + "개 (" + from(s.emphFrom) + ")"
            : (s.emphNote ? "<b>강조 패스</b> 저장된 선 " + s.emphNote + "개" : "<b>강조 패스</b> 없음");
      var g = s.existing ? "<br>hyHalftone 그룹 선택됨 → 적용하면 교체" : "";
      setStatus(a + " · " + e + g, !s.area && !s.areaNote);
    });
  }
  function setStatus(html, warn) {
    if (html === lastStatus) return;
    lastStatus = html;
    var el = $("status"); el.innerHTML = html; el.className = "status" + (warn ? " warn" : "");
  }

  /* ---------- 버튼 ---------- */
  function tag(kind) {
    jsx("hyHalftone_tag", kind, function (res) {
      var r = parseRes(res);
      msg(r.ok ? (kind === "area" ? "영역을 지정했습니다." : "강조 패스 " + r.val + "개를 지정했습니다.") : r.val, r.ok ? "ok" : "err");
      lastStatus = ""; refreshStatus();
      if (r.ok && ctrls.live.get()) schedulePreview();
    });
  }
  function makeTear() {
    if (busy) { msg("잠시 후 다시 눌러 주세요."); return; }
    busy = true;
    var p = { dir: ctrls.tearDir.get(), pos: ctrls.tearPos.get(), segs: ctrls.tearSegs.get(),
              amp: ctrls.tearAmp.get(), seed: ctrls.tearSeed.get(), keep: ctrls.tearKeep.get() };
    jsx("hyHalftone_makeTear", p, function (res) {
      busy = false;
      var r = parseRes(res);
      if (r.ok) {
        msg("찢김 선을 만들었습니다. 패스를 직접 다듬어도 됩니다.", "ok");
        ctrls.tearSeed.set(ctrls.tearSeed.get() + 1); save();          // 다음 클릭은 다른 모양
        lastStatus = ""; refreshStatus();
        if (ctrls.live.get()) schedulePreview();
      } else msg(r.val, "err");
    });
  }
  function readSettings() {
    jsx("hyHalftone_read", undefined, function (res) {
      var r = parseRes(res);
      if (!r.ok) { msg(r.val, "err"); return; }
      try { setAll(JSON.parse(r.val)); save(); msg("설정을 불러왔습니다.", "ok"); }
      catch (e) { msg("설정을 읽을 수 없습니다.", "err"); }
    });
  }

  /* ---------- 초기화 ---------- */
  function init() {
    var hosts = document.querySelectorAll("[data-slider]");
    for (var i = 0; i < hosts.length; i++) buildSlider(hosts[i]);
    ["shape", "tone", "falloff", "emphMode", "tearDir", "colorMode", "gradBy", "gradType", "cutMode"].forEach(bindSelect);
    ["stagger", "delArea", "delEmph", "live", "tearKeep"].forEach(bindCheck);
    ["seed", "tearSeed"].forEach(bindNumber);
    bindColor("color", "colorHex"); bindColor("color2", "color2Hex");

    var sel = $("preset"), presets = window.HY_HALFTONE_PRESETS || [];
    sel.innerHTML = '<option value="">— 선택 —</option>';
    for (var p = 0; p < presets.length; p++) sel.innerHTML += '<option value="' + p + '">' + presets[p].name + '</option>';
    sel.addEventListener("change", function () {
      if (sel.value === "") return;
      var c = presets[parseInt(sel.value, 10)].cfg, merged = {};
      for (var k in c) merged[k] = c[k];
      setAll(merged); save();
      if (ctrls.live.get()) schedulePreview();
    });

    $("btnTagArea").addEventListener("click", function () { tag("area"); });
    $("btnTagEmph").addEventListener("click", function () { tag("emph"); });
    $("btnUntag").addEventListener("click", function () {
      jsx("hyHalftone_untag", undefined, function (res) { var r = parseRes(res); msg(r.ok ? "지정을 해제했습니다." : r.val, r.ok ? "" : "err"); lastStatus = ""; refreshStatus(); });
    });
    $("btnTear").addEventListener("click", makeTear);
    $("btnRun").addEventListener("click", runApply);
    $("btnCancel").addEventListener("click", function () { clearTimeout(timer); cancelPreview(); msg("취소했습니다."); });
    $("btnRead").addEventListener("click", readSettings);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") { clearTimeout(timer); cancelPreview(); msg("취소했습니다."); } });

    load();
    refreshStatus();
    setInterval(refreshStatus, 1200);
  }
  init();
})();
