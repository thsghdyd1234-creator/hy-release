(defun c:P2B ( / refBlk blkName ss i ent vlaEnt minPt maxPt minPtLst maxPtLst insPt )
  (vl-load-com)
  
  ;; 1. 기준이 되는 원본 블록 선택
  (prompt "\n기준이 될 기둥 블록을 선택하세요: ")
  (setq refBlk (car (entsel)))
  
  (if (and refBlk (= (cdr (assoc 0 (entget refBlk))) "INSERT"))
    (progn
      ;; 선택한 블록의 이름 추출
      (setq blkName (cdr (assoc 2 (entget refBlk))))
      (princ (strcat "\n기준 블록 [" blkName "] 인식 완료."))

      ;; 2. 교체할 폴리선(정사각형)들 일괄 선택
      (prompt "\n블록으로 교체할 정사각형(폴리선)들을 드래그하여 선택하세요: ")
      (if (setq ss (ssget '((0 . "LWPOLYLINE"))))
        (progn
          (setq i 0)
          ;; 선택된 폴리선 개수만큼 반복 작업 시작
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (setq vlaEnt (vlax-ename->vla-object ent))

            ;; 3. 폴리선의 Bounding Box(외곽 테두리)를 구해서 정확한 중심점(Center) 계산
            (vla-getboundingbox vlaEnt 'minPt 'maxPt)
            (setq minPtLst (vlax-safearray->list minPt))
            (setq maxPtLst (vlax-safearray->list maxPt))
            (setq insPt (list (/ (+ (car minPtLst) (car maxPtLst)) 2.0)
                              (/ (+ (cadr minPtLst) (cadr maxPtLst)) 2.0)
                              0.0))

            ;; 4. 계산된 중심점 좌표에 기준 블록 삽입
            (entmake (list '(0 . "INSERT")
                           (cons 2 blkName)
                           (cons 10 insPt)))

            ;; 5. 원래 폴리선 삭제
            (entdel ent)

            (setq i (1+ i))
          )
          (princ (strcat "\n[완료] 총 " (itoa i) "개의 폴리선을 기둥 블록으로 바꿨습니다."))
        )
        (princ "\n선택된 폴리선이 없습니다.")
      )
    )
    (princ "\n블록을 정확히 선택하지 않았습니다. 명령을 종료합니다.")
  )
  (princ)
)