;;; ==============================================================================
;;;  P2B — 폴리선으로 그린 기둥을 기준 기둥 블록으로 바꾸기
;;;
;;;  기준 블록을 클릭하고 폴리선을 고르면, 닫힌 폴리선 중 크기가 기준 블록과 비슷한 것(가로·세로 ±10%,
;;;  90° 돌아간 것도)만 그 자리(상자 가운데)에 기준 블록의 복사본을 놓고 폴리선을 지운다.
;;;   · 복사본이라 레이어·축척·속성·동적 블록 설정이 기준 블록과 같다. 블록 기준점이 모서리여도 맞는 자리에 놓인다.
;;;   · 크기가 다른 폴리선(벽·실 외곽 등)은 그대로 두고 끝에 골라 둔다. 잠긴 레이어는 빠진다.
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun p2b:box (o / a b)
  (vla-GetBoundingBox o 'a 'b)
  (list (vlax-safearray->list a) (vlax-safearray->list b)))

(defun p2b:mid (bx) (mapcar '(lambda (a b) (/ (+ a b) 2.0)) (car bx) (cadr bx)))
(defun p2b:dim (bx) (list (- (car (cadr bx)) (car (car bx))) (- (cadr (cadr bx)) (cadr (car bx)))))

(defun p2b:near (a b) (<= (abs (- a b)) (* 0.1 (max a b))))

(defun c:P2B ( / *error* doc undo_open sel base bb bd ss i e o pb pd c mv rot n skip)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n기준 기둥 블록을 클릭하세요: "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n기준 블록을 고르지 않았습니다."))
    ((/= (cdr (assoc 0 (entget (car sel)))) "INSERT") (princ "\n[주의] 블록이 아닙니다."))
    ((progn (setq base (vlax-ename->vla-object (car sel)) bb (p2b:box base) bd (p2b:dim bb))
            (prompt "\n블록으로 바꿀 기둥 폴리선을 고르세요 (크기가 다른 폴리선은 그대로 둠, 잠긴 레이어는 빠짐): ")
            (null (setq ss (ssget "_:L" '((0 . "LWPOLYLINE"))))))
     (princ "\n고른 폴리선이 없습니다."))
    (T
     (vla-StartUndoMark doc)
     (setq undo_open T i 0 n 0 skip (ssadd))
     (while (< i (sslength ss))
       (setq e (ssname ss i) o (vlax-ename->vla-object e) pb (p2b:box o) pd (p2b:dim pb) rot nil)
       (cond
         ((not (or (= (vla-get-Closed o) :vlax-true)
                   (equal (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o) 1e-4)))
          (ssadd e skip))
         ((and (p2b:near (car pd) (car bd)) (p2b:near (cadr pd) (cadr bd))) (setq rot 0.0))
         ((and (p2b:near (car pd) (cadr bd)) (p2b:near (cadr pd) (car bd)) (not (p2b:near (car bd) (cadr bd))))
          (setq rot (/ pi 2)))
         (T (ssadd e skip)))
       (if rot
         (progn
           (setq c (list (car (p2b:mid pb)) (cadr (p2b:mid pb)) (caddr (p2b:mid bb))) mv (vla-Copy base))   ; 높이는 그대로
           (vla-Move mv (vlax-3d-point (p2b:mid bb)) (vlax-3d-point c))
           (if (/= rot 0.0) (vla-Rotate mv (vlax-3d-point c) rot))
           (vla-Delete o)
           (setq n (1+ n))))
       (setq i (1+ i)))
     (vla-EndUndoMark doc)
     (setq undo_open nil)
     (princ (strcat "\n[완료] 폴리선 " (itoa n) "개를 [" (vla-get-EffectiveName base) "] 블록으로 바꿨습니다."))
     (if (> (sslength skip) 0)
       (progn
         (sssetfirst nil skip)
         (princ (strcat "\n[알림] 크기가 다르거나 열린 폴리선 " (itoa (sslength skip)) "개는 그대로 두고 골라 두었습니다."))))))
  (princ))

(princ)
