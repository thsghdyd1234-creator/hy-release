(defun c:FSA (/ ss tol i ent ed p1 p2 ang angDeg rem90 count epsilon skewed_ss)
  ;; FSA: Find Skewed Angles (미세하게 틀어진 선 찾기)
  (setq epsilon 1e-6) ; 정확한 직교(0, 90, 180, 270)를 빼기 위한 아주 작은 오차값
  
  ;; 허용 오차 입력 (기본값 0.1도)
  (setq tol (getreal "\n검출할 최대 허용 오차 각도를 입력하세요 (기본값: 0.1도): "))
  (if (not tol) (setq tol 0.1))

  (prompt (strcat "\n직교에서 " (rtos tol 2 4) "도 이내로 틀어진 선을 찾는 중..."))

  ;; 선(LINE) 객체만 선택
  (if (setq ss (ssget '((0 . "LINE"))))
    (progn
      (setq i 0 count 0)
      (setq skewed_ss (ssadd))
      
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq ed (entget ent))
        (setq p1 (cdr (assoc 10 ed)))
        (setq p2 (cdr (assoc 11 ed)))
        
        ;; 각도 계산 및 90도 단위 나머지 연산
        (setq ang (angle p1 p2))
        (setq angDeg (* 180.0 (/ ang pi)))
        (setq rem90 (rem angDeg 90.0))

        ;; 정확한 직교는 빼고, 오차 범위 안의 각도인지 판별
        (if (and
              (> rem90 epsilon)
              (< rem90 (- 90.0 epsilon))
              (or (<= rem90 tol) (>= rem90 (- 90.0 tol)))
            )
          (progn
            (ssadd ent skewed_ss)
            (setq count (1+ count))
          )
        )
        (setq i (1+ i))
      )
      
      ;; 결과 출력 및 객체 그립(선택)
      (if (> count 0)
        (progn
          (sssetfirst nil skewed_ss)
          (prompt (strcat "\n[주의] 총 " (itoa count) "개의 틀어진 선을 찾아 선택했습니다."))
        )
        (prompt "\n선택한 영역에 틀어진 선이 없습니다.")
      )
    )
    (prompt "\n선택된 선(LINE) 객체가 없습니다.")
  )
  (princ)
)