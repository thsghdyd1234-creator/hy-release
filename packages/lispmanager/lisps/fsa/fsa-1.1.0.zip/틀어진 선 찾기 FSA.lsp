;;; ==============================================================================
;;;  FSA — 직교에서 살짝 틀어진 선 찾기
;;;
;;;  허용 각도(기본 0.1° · 기억)를 정하고 선·폴리선을 고르면, 수평·수직에서 그 각도 안으로 틀어진 것을 골라 둔다.
;;;  각도는 지금 UCS 기준 (WR 로 돌려 둔 화면에서는 그 화면의 수평·수직). 정확히 직교인 것은 빼고,
;;;  폴리선은 직선 구간 중 하나라도 틀어졌으면 고른다.
;;; ==============================================================================

;; 두 점(월드) 방향이 직교에서 얼마나 벗어났는지 (도, 0 ~ 45)
(defun fsa:off (p q / a r)
  (setq a (angle (trans p 0 1) (trans q 0 1)) r (rem (* 180.0 (/ a pi)) 90.0))
  (min r (- 90.0 r)))

(defun fsa:bad (d tol) (and (> d 1e-6) (<= d tol)))

(defun c:FSA ( / tol ss i e ed typ o n k p q hit out)
  (vl-load-com)
  (setq tol (if (getenv "HyFsaTol") (atof (getenv "HyFsaTol")) 0.1))
  (initget 6)
  (setq tol (cond ((getreal (strcat "\n찾을 최대 틀어짐 각도(도) <" (rtos tol 2 4) ">: "))) (tol)))
  (setenv "HyFsaTol" (rtos tol 2 8))
  (prompt "\n검사할 선·폴리선을 고르세요: ")
  (if (null (setq ss (ssget '((0 . "LINE,LWPOLYLINE")))))
    (princ "\n고른 객체가 없습니다.")
    (progn
      (setq out (ssadd) i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) ed (entget e) typ (cdr (assoc 0 ed)) hit nil)
        (if (= typ "LINE")
          (setq hit (fsa:bad (fsa:off (cdr (assoc 10 ed)) (cdr (assoc 11 ed))) tol))
          (progn
            (setq o (vlax-ename->vla-object e) n (fix (+ 0.5 (vlax-curve-getEndParam o))) k 0)
            (while (and (not hit) (< k n))
              (if (equal (vla-GetBulge o k) 0.0 1e-12)
                (progn (setq p (vlax-curve-getPointAtParam o k) q (vlax-curve-getPointAtParam o (1+ k)))
                       (if (> (distance p q) 1e-9) (setq hit (fsa:bad (fsa:off p q) tol)))))
              (setq k (1+ k)))))
        (if hit (ssadd e out))
        (setq i (1+ i)))
      (if (> (sslength out) 0)
        (progn (sssetfirst nil out)
               (princ (strcat "\n[주의] 직교에서 " (rtos tol 2 4) "° 안으로 틀어진 것 " (itoa (sslength out)) "개를 골라 두었습니다.")))
        (princ "\n[완료] 틀어진 선이 없습니다."))))
  (princ))

(princ)
