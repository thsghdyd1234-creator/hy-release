;;; =====================================================================
;;;  hy Layer Export  v0.6.2          명령: HLE
;;;
;;;  캐드에서 플롯하듯 영역을 정하면 레이어별로 나눠
;;;  일러스트레이터 / 포토샵 레이어로 넘긴다.
;;;
;;;  흐름
;;;    1. 영역 지정 (플롯 창처럼 두 점, 또는 F 로 도곽 블록 클릭 — hy CAD 도곽은 종이 끝 범위 · 축척까지)
;;;    2. 영역 안 레이어 수집 (블록 내부 · 속성 포함)  -> job.json
;;;    3. 설정 창(exe) 실행, 닫힐 때까지 대기            -> settings.lsp
;;;       (설정 창이 PDF 창이 안 열리는 플로터 사본 hy Layer Export.pc3 를 플로터 폴더에 만듦 — 0.6.2~)
;;;    4. 선가중치 임시 적용 -> 레이어별 PDF 플롯 -> 원상 복구
;;;    5. result.json 작성 -> 조립(exe --assemble) 실행
;;;
;;;  YGN CAD 내보내기 창(1.23.0~)은 묻지 않고 도곽마다 부른다:
;;;    (hle:run-preset '("ai" "1A" "1B"))  — 글 = 도곽 블록 핸들, 숫자 넷 = 영역 상자
;;;
;;;  색은 캐드에서 건드리지 않는다. 흑백(monochrome)으로 플롯한 뒤
;;;  일러스트/포토샵 쪽에서 지정한 색을 입힌다.
;;;  두께는 출력하는 동안만 객체 · 레이어 선가중치로 — 'CTB대로'(0.5.0~)면 객체마다 원래 색의
;;;  CTB 펜 두께를 넣어서, 흑백으로 뽑아도 그 CTB 로 뽑은 두께와 같다.
;;;
;;;  필요: AutoCAD 2021 이상(유니코드 AutoLISP), DWG To PDF.pc3, 모형 탭
;;;        hy 허브의 hy Layer Export (설정 창 · 조립 프로그램)
;;; =====================================================================
(vl-load-com)

(setq *hle-version* "0.6.4")

;; 설정 창 실행 파일을 직접 지정하려면 아래 줄의 주석을 풀고 경로를 넣는다.
;; .exe 또는 개발용 .pyw 모두 가능
;; (setq *hle-exe* "D:\\hy\\hy_layer_export\\hy_layer_export.exe")

(setq hle:PC3          "DWG To PDF.pc3"
      hle:QUIET-PC3    "hy Layer Export.pc3"   ; 0.6.2~ 설정 창이 만드는 사본 ('뷰어에 결과 표시' · '도면층 정보 포함'만 끔)
      hle:FRAME-LAYER  "HLE__FRAME"
      hle:LW-BYLAYER   -1
      hle:LW-BYBLOCK   -2
      hle:LW-CTB       -10    ; 설정 창의 'CTB대로' (객체마다 원래 색의 펜 두께)
      hle:PLOT-WINDOW  4      ; acWindow
      hle:ROT-0        0      ; ac0degrees
      hle:MM           1)     ; acMillimeters

;;; ---------------------------------------------------------------------
;;; 문자열 · 파일 유틸
;;; ---------------------------------------------------------------------
(defun hle:split (s d / i out)
  (while (setq i (vl-string-search d s))
    (setq out (cons (substr s 1 i) out)
          s   (substr s (+ i 1 (strlen d)))))
  (reverse (cons s out)))

(defun hle:mkdirs (path / cur)
  (foreach p (hle:split path "\\")
    (setq cur (if cur (strcat cur "\\" p) p))
    (if (and (/= p "") (not (vl-file-directory-p cur)))
      (vl-mkdir cur)))
  path)

(defun hle:slash (p) (vl-string-translate "\\" "/" p))

(defun hle:jstr (s / out i c)
  (setq out "" i 1)
  (while (<= i (strlen s))
    (setq c (substr s i 1)
          i (1+ i)
          out (strcat out (cond ((= c "\\") "\\\\")
                                ((= c "\"") "\\\"")
                                (t c)))))
  (strcat "\"" out "\""))

(defun hle:jnum (x)
  (if (= (type x) 'INT) (itoa x) (rtos x 2 6)))

;; AutoCAD 2021+ 는 인코딩 인자를 받는다. 구버전이면 기본 인코딩으로.
(defun hle:open (path mode / f)
  (setq f (vl-catch-all-apply 'open (list path mode "utf8")))
  (if (or (vl-catch-all-error-p f) (null f))
    (open path mode)
    f))

(defun hle:read-file (path / f ln out)
  (if (and (findfile path) (setq f (hle:open path "r")))
    (progn
      (setq out "")
      (while (setq ln (read-line f)) (setq out (strcat out ln " ")))
      (close f)
      out)))

(defun hle:opt (key lst) (cdr (assoc key lst)))

;;; ---------------------------------------------------------------------
;;; 상태 저장 · 복구
;;; ---------------------------------------------------------------------
(defun hle:setvar (name val)
  (if (not (assoc name *hle-sysvars*))
    (setq *hle-sysvars* (cons (cons name (getvar name)) *hle-sysvars*)))
  (setvar name val))

(defun hle:try (fn obj args) (vl-catch-all-apply fn (cons obj args)))

(defun hle:layers-save ( / out)
  (vlax-for l *hle-layers*
    (setq out (cons (list l
                          (vla-get-LayerOn l)
                          (vla-get-Lock l)
                          (vla-get-Plottable l)
                          (vla-get-Lineweight l))
                    out)))
  out)

(defun hle:layers-restore (st)
  (foreach s st
    (hle:try 'vla-put-LayerOn    (nth 0 s) (list (nth 1 s)))
    (hle:try 'vla-put-Plottable  (nth 0 s) (list (nth 3 s)))
    (hle:try 'vla-put-Lineweight (nth 0 s) (list (nth 4 s))))
  ;; 잠금은 마지막에
  (foreach s st (hle:try 'vla-put-Lock (nth 0 s) (list (nth 2 s)))))

;; 모형 탭 페이지 설정 백업
(defun hle:pc-save (lo / n d ll ur)
  (vl-catch-all-apply 'vla-GetCustomScale (list lo 'n 'd))
  (vl-catch-all-apply 'vla-GetWindowToPlot (list lo 'll 'ur))
  (list (vla-get-ConfigName lo)            ; 0
        (vla-get-CanonicalMediaName lo)    ; 1
        (vla-get-PaperUnits lo)            ; 2
        (vla-get-PlotRotation lo)          ; 3
        (vla-get-PlotType lo)              ; 4
        (vla-get-UseStandardScale lo)      ; 5
        (vla-get-StandardScale lo)         ; 6
        n d                                ; 7 8
        (vla-get-CenterPlot lo)            ; 9
        (vla-get-PlotOrigin lo)            ; 10
        (vla-get-PlotWithLineweights lo)   ; 11
        (vla-get-PlotWithPlotStyles lo)    ; 12
        (vla-get-StyleSheet lo)            ; 13
        ll ur))                            ; 14 15

(defun hle:pc-restore (lo s)
  (hle:try 'vla-put-ConfigName lo (list (nth 0 s)))
  (hle:try 'vla-RefreshPlotDeviceInfo lo nil)
  (hle:try 'vla-put-CanonicalMediaName lo (list (nth 1 s)))
  (hle:try 'vla-put-PaperUnits lo (list (nth 2 s)))
  (hle:try 'vla-put-PlotRotation lo (list (nth 3 s)))
  (hle:try 'vla-put-StyleSheet lo (list (nth 13 s)))
  (hle:try 'vla-put-PlotWithPlotStyles lo (list (nth 12 s)))
  (hle:try 'vla-put-PlotWithLineweights lo (list (nth 11 s)))
  (if (and (nth 7 s) (nth 8 s))
    (hle:try 'vla-SetCustomScale lo (list (nth 7 s) (nth 8 s))))
  (hle:try 'vla-put-UseStandardScale lo (list (nth 5 s)))
  (if (= (nth 5 s) :vlax-true)
    (hle:try 'vla-put-StandardScale lo (list (nth 6 s))))
  (hle:try 'vla-put-CenterPlot lo (list (nth 9 s)))
  (hle:try 'vla-put-PlotOrigin lo (list (nth 10 s)))
  (if (and (nth 14 s) (nth 15 s))
    (hle:try 'vla-SetWindowToPlot lo (list (nth 14 s) (nth 15 s))))
  (hle:try 'vla-put-PlotType lo (list (nth 4 s))))

;; 여러 번 불러도 안전하다
(defun hle:cleanup ()
  (foreach u *hle-lw-undo*
    (vl-catch-all-apply 'vla-put-Lineweight (list (car u) (cdr u))))
  (setq *hle-lw-undo* nil
        *hle-lw-seen* nil
        *hle-ctbw* nil *hle-ctbmode* nil *hle-ovr* nil)
  (foreach o *hle-hidden* (vl-catch-all-apply 'vla-put-Visible (list o :vlax-true)))
  (setq *hle-hidden* nil)
  (foreach o *hle-frame-objs* (vl-catch-all-apply 'vla-delete (list o)))
  (setq *hle-frame-objs* nil)
  (if *hle-lay-state*
    (progn (hle:layers-restore *hle-lay-state*) (setq *hle-lay-state* nil)))
  (if *hle-frame-layer*
    (progn (vl-catch-all-apply 'vla-delete (list *hle-frame-layer*))
           (setq *hle-frame-layer* nil)))
  (if (and *hle-layout* *hle-pc-state*)
    (progn (hle:pc-restore *hle-layout* *hle-pc-state*)
           (setq *hle-pc-state* nil)))
  (if *hle-plot* (vl-catch-all-apply 'vla-put-QuietErrorMode (list *hle-plot* :vlax-false)))
  (if *hle-undo-open*
    (progn (vl-catch-all-apply 'vla-EndUndoMark (list *hle-doc*))
           (setq *hle-undo-open* nil)))
  (foreach sv *hle-sysvars* (vl-catch-all-apply 'setvar (list (car sv) (cdr sv))))
  (setq *hle-sysvars* nil))

;;; ---------------------------------------------------------------------
;;; 레이어 수집 (블록 내부 · 속성 · 치수 포함)
;;; ---------------------------------------------------------------------
(defun hle:cnt-add (lay / a)
  (if (setq a (assoc lay *hle-cnt*))
    (setq *hle-cnt* (subst (cons lay (1+ (cdr a))) a *hle-cnt*))
    (setq *hle-cnt* (cons (cons lay 1) *hle-cnt*))))

;; 레이어마다 객체가 뽑힐 색 번호 모음 — 설정 창이 'CTB대로' 칸에 그 색들의 펜 두께를 보여 줌
(defun hle:col-add (lay aci / a)
  (setq a (assoc lay *hle-cols*))
  (cond
    ((null a) (setq *hle-cols* (cons (list lay aci) *hle-cols*)))
    ((not (member aci (cdr a))) (setq *hle-cols* (subst (append a (list aci)) a *hle-cols*)))))

;; 블록 안 0번 레이어 객체는 블록이 놓인 레이어를 따른다
(defun hle:eff-layer (lay parent)
  (if (and parent (= (strcase lay) "0")) parent lay))

;; 레이어 색 번호 (트루컬러면 캐드가 함께 적어 둔 가까운 색 번호)
(defun hle:layer-aci (name / td)
  (if (setq td (tblsearch "LAYER" name)) (abs (cdr (assoc 62 td))) 7))

;; 객체가 실제로 뽑힐 색 번호 — ByLayer 는 (블록 안 0번이면 블록이 놓인) 레이어 색, ByBlock 은 감싼 블록의 색(맨 위면 7)
(defun hle:eff-color (ed lay pcol / c)
  (setq c (cond ((cdr (assoc 62 ed))) (256)))
  (cond
    ((= c 256) (hle:layer-aci lay))
    ((= c 0) (cond (pcol) (7)))
    (t (abs c))))

(defun hle:scan-ent (e parent pcol / ed typ lay col a ad alay)
  (setq ed  (entget e)
        typ (cdr (assoc 0 ed))
        lay (hle:eff-layer (cdr (assoc 8 ed)) parent)
        col (hle:eff-color ed lay pcol))
  (hle:cnt-add lay)
  (hle:col-add lay col)
  (cond
    ((= typ "INSERT")
     (if (= 1 (cdr (assoc 66 ed)))
       (progn
         (setq a (entnext e))
         (while (and a (= (cdr (assoc 0 (setq ad (entget a)))) "ATTRIB"))
           (setq alay (hle:eff-layer (cdr (assoc 8 ad)) lay))
           (hle:cnt-add alay)
           (hle:col-add alay (hle:eff-color ad alay col))
           (setq a (entnext a)))))
     (hle:scan-block (cdr (assoc 2 ed)) lay col))
    ((= typ "DIMENSION")
     (if (assoc 2 ed) (hle:scan-block (cdr (assoc 2 ed)) lay col)))))

(defun hle:scan-block (bname eff pcol / key e typ)
  (setq key (strcat (strcase bname) "|" (strcase eff) "|" (itoa pcol)))
  (if (and (not (member key *hle-seen*))
           (setq e (tblobjname "BLOCK" bname)))
    (progn
      (setq *hle-seen* (cons key *hle-seen*))
      (while (and (setq e (entnext e))
                  (/= (setq typ (cdr (assoc 0 (entget e)))) "ENDBLK"))
        (if (not (member typ '("ATTRIB" "SEQEND" "ATTDEF")))
          (hle:scan-ent e eff pcol))))))

(defun hle:layer-visible-p (name / td)
  (and (setq td (tblsearch "LAYER" name))
       (> (cdr (assoc 62 td)) 0)              ; 꺼진 레이어는 색 번호가 음수
       (zerop (logand 1 (cdr (assoc 70 td)))) ; 동결 아님
       (/= (strcase name) "DEFPOINTS")
       (/= (strcase name) "YGN-아래층")      ; YGN CAD 아래층 실루엣 (참고선)
       (/= (strcase name) "YGN-줄자")))      ; YGN CAD 줄자 (1.92.0~ TT — 출력 안 하는 안내선)

;; YGN CAD 아래층 실루엣 (1.38.0~) — 윗층 도곽에 깐 회색 참고선 (레이어 YGN-아래층 · 블록 설명 'YGN 아래층'). 잠긴 레이어라도 걸침 선택에 걸려서 뺀다
;;   이름 없는 블록(*U)만 블록 설명을 봄 — 레이어 이름을 바꿔도 걸리게
(defun hle:under-p (e / ed nm b)
  (setq ed (entget e))
  (or (= (strcase (cdr (assoc 8 ed))) "YGN-아래층")
      (= (strcase (cdr (assoc 8 ed))) "YGN-줄자")   ; YGN CAD 줄자 (1.92.0~ TT) — 무한선이라 모든 영역에 걸림
      (and (= (cdr (assoc 0 ed)) "INSERT")
           (setq nm (cdr (assoc 2 ed)))
           (wcmatch nm "`*U*")
           (setq b (vl-catch-all-apply 'vla-item (list (vla-get-Blocks (vla-get-ActiveDocument (vlax-get-acad-object))) nm)))
           (not (vl-catch-all-error-p b))
           (= (vl-catch-all-apply 'vla-get-Comments (list b)) "YGN 아래층"))))

;; 결과: ((이름 객체수 선가중치 레이어색 (객체가 뽑힐 색 ...)) ...)
(defun hle:collect (ss / i out lw)
  (setq *hle-cnt* nil *hle-cols* nil *hle-seen* nil i 0)
  (repeat (sslength ss)
    (if (not (hle:under-p (ssname ss i))) (hle:scan-ent (ssname ss i) nil nil))
    (setq i (1+ i)))
  (foreach c *hle-cnt*
    (if (hle:layer-visible-p (car c))
      (progn
        (setq lw (cdr (assoc 370 (entget (tblobjname "LAYER" (car c))))))
        (setq out (cons (list (car c) (cdr c) (if lw lw -3) (hle:layer-aci (car c))
                              (cdr (assoc (car c) *hle-cols*)))
                        out)))))
  (setq *hle-cnt* nil *hle-cols* nil *hle-seen* nil)
  out)

;;; ---------------------------------------------------------------------
;;; 선가중치 임시 정리 (블록 정의 안쪽까지. 외부참조 · 치수 · 표 블록은 제외) — 끝나면 hle:cleanup 이 되돌림
;;;  'CTB대로' 레이어가 있으면 (0.5.0~, 호용 '색을 검정으로 바꿔 내보내는 건 맞지만 원래 색을 못 읽어서 두께가 모두 같게'):
;;;    객체마다 원래 색의 CTB 펜 두께를 선가중치로 — 흑백(monochrome, 펜 = 객체 선가중치)으로 뽑아도 그 CTB 의 두께
;;;      색 ByLayer → ByLayer (레이어 선가중치를 출력 때 레이어 색의 펜 두께로)
;;;      색 ByBlock → ByBlock (블록 안. 맨 위는 색 7 처럼)
;;;      색 번호    → 그 색의 펜 두께. 펜이 '객체 선가중치'면 원래 두께 그대로
;;;    두께를 정한 레이어(설정 창에서 mm 를 고른 것)의 객체는 ByLayer (레이어 선가중치 = 고른 두께)
;;;  아니면 (옛 설정 창 · CTB 없음) 예전처럼 모두 ByLayer
;;; ---------------------------------------------------------------------
;; 설정 창이 고른 두께 → 정리 규칙. layers = ((이름 r g b 선가중치) ...), ctbw = ((색 번호 . 1/100 mm) ...)
(defun hle:lw-prepare (layers ctbw)
  (setq *hle-ctbw* ctbw
        *hle-ctbmode* (vl-some (function (lambda (L) (= (nth 4 L) hle:LW-CTB))) layers)
        *hle-ovr* (mapcar (function (lambda (L) (strcase (car L))))
                          (vl-remove-if (function (lambda (L) (= (nth 4 L) hle:LW-CTB))) layers))))

;; 색 번호의 펜 두께 (nil = '객체 선가중치' 펜 · CTB 없음)
(defun hle:pen (aci) (cdr (assoc aci *hle-ctbw*)))

;; 레이어의 원래 선가중치 (내보내기 전에 저장해 둔 것)
(defun hle:layer-lw0 (name / u r)
  (setq u (strcase name))
  (foreach st *hle-lay-state*
    (if (and (null r) (= (strcase (vla-get-Name (car st))) u)) (setq r (nth 4 st))))
  (cond (r) (-3)))

;; 출력할 때 그 레이어의 선가중치 — 'CTB대로'면 레이어 색의 펜 두께('객체 선가중치' 펜이면 원래 것), 아니면 고른 두께
(defun hle:layer-plot-lw (L)
  (if (= (nth 4 L) hle:LW-CTB)
    (cond ((hle:pen (hle:layer-aci (car L)))) ((hle:layer-lw0 (car L))))
    (nth 4 L)))

;; 객체 선가중치를 무엇으로 (nil = 그대로). top = 블록 정의 밖.
;; 블록 안 0번 레이어 객체는 블록이 놓인 레이어를 따르므로 정의만 봐서는 레이어를 모른다 (known = nil)
;; 객체의 색 번호(256 ByLayer · 0 ByBlock)와 레이어 — entget 이 안 되는 것(속성 등)은 vla 로
(defun hle:obj-color-layer (obj / en ed c)
  (setq en (vl-catch-all-apply 'vlax-vla-object->ename (list obj)))
  (if (and (not (vl-catch-all-error-p en)) en (setq ed (entget en)))
    (list (cond ((cdr (assoc 62 ed))) (256)) (cdr (assoc 8 ed)))
    (progn
      (setq c (vl-catch-all-apply 'vla-get-Color (list obj)))
      (list (if (numberp c) c 256) (vla-get-Layer obj)))))

(defun hle:lw-want (obj top / cl c lay known)
  (setq cl    (hle:obj-color-layer obj)
        c     (car cl)
        lay   (strcase (cadr cl))
        known (or top (/= lay "0")))
  (cond
    ((not *hle-ctbmode*) hle:LW-BYLAYER)
    ((and known (member lay *hle-ovr*)) hle:LW-BYLAYER)
    ((= c 256)
     (if (or (not known) (hle:pen (hle:layer-aci lay))) hle:LW-BYLAYER))
    ((and (= c 0) (not top)) hle:LW-BYBLOCK)
    ((hle:pen (if (= c 0) 7 (abs c))))
    ;; 그 색 펜이 '객체 선가중치'인데 레이어를 따르던 객체 — 레이어 선가중치가 펜 두께로 바뀌므로 원래 레이어 두께로 못 박음
    ((and known (= (vla-get-Lineweight obj) hle:LW-BYLAYER) (hle:pen (hle:layer-aci lay)))
     (hle:layer-lw0 lay))))

(defun hle:lw-set (obj top / lw want)
  (if (and (vlax-property-available-p obj 'Lineweight t)
           (setq want (hle:lw-want obj top))
           (not (vl-catch-all-error-p (setq lw (vl-catch-all-apply 'vla-get-Lineweight (list obj)))))
           (/= lw want)
           (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Lineweight (list obj want)))))
    (setq *hle-lw-undo* (cons (cons obj lw) *hle-lw-undo*))))

(defun hle:lw-obj (obj top / on)
  (hle:lw-set obj top)
  (setq on (vla-get-ObjectName obj))
  (if (wcmatch on "AcDbBlockReference,AcDbMInsertBlock")
    (progn
      (if (= (vla-get-HasAttributes obj) :vlax-true)
        (foreach a (vlax-invoke obj 'GetAttributes) (hle:lw-set a nil)))
      (hle:lw-block (vla-get-Name obj)))))

(defun hle:lw-block (bn / blk)
  (if (and (not (member (strcase bn) *hle-lw-seen*))
           (not (wcmatch bn "`*D*,`*T*")))
    (progn
      (setq *hle-lw-seen* (cons (strcase bn) *hle-lw-seen*))
      (setq blk (vl-catch-all-apply 'vla-item (list (vla-get-Blocks *hle-doc*) bn)))
      (if (and (not (vl-catch-all-error-p blk))
               (= (vla-get-IsXRef blk) :vlax-false))
        (vlax-for o blk (hle:lw-obj o nil))))))

(defun hle:lw-ss (ss / i)
  (setq *hle-lw-seen* nil i 0)
  (repeat (sslength ss)
    (hle:lw-obj (vlax-ename->vla-object (ssname ss i)) t)
    (setq i (1+ i))))

;;; ---------------------------------------------------------------------
;;; 플롯 설정
;;; ---------------------------------------------------------------------
(defun hle:pt2 (x y)
  (vlax-make-variant
    (vlax-safearray-fill (vlax-make-safearray vlax-vbDouble '(0 . 1)) (list x y))))

;; "ISO_full_bleed_A3_(420.00_x_297.00_MM)" -> (420.0 297.0)
(defun hle:parse-mm (nm / a s x)
  (if (and (wcmatch (strcase nm) "*_MM)")
           (setq a (vl-string-position (ascii "(") nm nil t)))
    (progn
      (setq s (substr nm (+ a 2) (- (strlen nm) a 5)))
      (if (setq x (vl-string-search "_x_" s))
        (list (atof (substr s 1 x)) (atof (substr s (+ x 4))))))))

;; 회전 방향과 상관없이 들어가도록 짧은 변이 출력 긴 변보다 큰 용지 중
;; 여백 없는(full bleed) 용지를 우선, 그중 가장 작은 것
(defun hle:pick-media (lo need / names wh mn ar fb usable best)
  (setq names (vl-catch-all-apply
                (function (lambda ()
                  (vlax-safearray->list
                    (vlax-variant-value (vla-GetCanonicalMediaNames lo)))))
                nil))
  (if (vl-catch-all-error-p names) (setq names nil))
  (foreach nm names
    (if (setq wh (hle:parse-mm nm))
      (progn
        (setq mn     (min (car wh) (cadr wh))
              ar     (* (car wh) (cadr wh))
              fb     (wcmatch (strcase nm) "*FULL_BLEED*")
              usable (if fb mn (- mn 30.0)))
        (if (and (>= usable need)
                 (or (null best)
                     (and fb (not (cadr best)))
                     (and (eq fb (cadr best)) (< ar (caddr best)))))
          (setq best (list nm fb ar))))))
  (car best))

(defun hle:mono-style (lo / want names)
  (setq want (if (= (getvar "PSTYLEMODE") 1) "MONOCHROME.CTB" "MONOCHROME.STB"))
  (setq names (vl-catch-all-apply
                (function (lambda ()
                  (vlax-safearray->list
                    (vlax-variant-value (vla-GetPlotStyleTableNames lo)))))
                nil))
  (if (not (vl-catch-all-error-p names))
    (car (vl-remove-if-not (function (lambda (n) (= (strcase n) want))) names))))

;; 출력 장치 (0.6.2~ — 호용 2026-11-02 '내보내기 할 때마다 레이어 갯수만큼 pdf 창이 열려버려서'):
;; DWG To PDF.pc3 의 PDF 옵션 '뷰어에 결과 표시'(처음엔 켜짐)는 PDF 를 뽑을 때마다 PDF 창을 연다. 이 옵션은 PC3 파일에만 있어
;; 리습 · 플롯 API 로는 못 끈다 — 설정 창(hy Layer Export 0.5.2~)이 그 옵션과 '도면층 정보 포함'만 끈 사본을 플로터 폴더에 만들고
;; settings.lsp 의 "pc3" 로 알려 준다. 캐드가 그 장치를 받으면 그 이름, 아니면 nil (→ DWG To PDF.pc3).
(defun hle:try-device (lo want / names hit r)
  (if (and (= (type want) 'STR) (/= want ""))
    (progn
      (hle:try 'vla-RefreshPlotDeviceInfo lo nil)        ; 방금 만든 PC3 도 보이게 플로터 폴더를 다시 읽음
      (setq names (vl-catch-all-apply
                    (function (lambda () (vlax-safearray->list (vlax-variant-value (vla-GetPlotDeviceNames lo)))))))
      (if (not (vl-catch-all-error-p names))
        (setq hit (car (vl-remove-if-not (function (lambda (n) (= (strcase n) (strcase want)))) names))))
      (if (not hit) (setq hit want))
      (setq r (vl-catch-all-apply 'vla-put-ConfigName (list lo hit)))
      (if (and (not (vl-catch-all-error-p r))
               (= (strcase (vla-get-ConfigName lo)) (strcase hit)))
        hit))))

;; 사본을 못 쓰면 PDF 창이 열릴 수 있는 까닭 한 줄
(defun hle:device-note (settings want dev / why)
  (if (= (strcase dev) (strcase hle:PC3))
    (cond
      ((and want (= (strcase want) (strcase hle:PC3))))   ; 원본 PC3 의 '뷰어에 결과 표시'가 이미 꺼져 있음
      (want
       (princ (strcat "\n[알림] " want " 를 캐드가 받지 않아 " hle:PC3 " 로 뽑습니다 — 레이어마다 PDF 창이 열릴 수 있습니다.")))
      ((setq why (hle:opt "pc3_err" settings))
       (princ (strcat "\n[알림] PDF 창을 끄지 못했습니다 (" why ") — 레이어마다 PDF 창이 열릴 수 있습니다.")))
      (t
       (princ "\n[알림] hy 허브에서 hy Layer Export 를 업데이트하면 레이어마다 PDF 창이 열리지 않습니다.")))))

;; want = 설정 창이 만든 장치 (없으면 nil)
;; 결과: (용지이름 흑백여부 출력폭mm 출력높이mm 장치)
(defun hle:setup-plot (lo box unit-mm scale want / wmm hmm media mono d1 d2 dev)
  (setq wmm (/ (* (- (nth 2 box) (nth 0 box)) unit-mm) scale)
        hmm (/ (* (- (nth 3 box) (nth 1 box)) unit-mm) scale))
  (if (not (setq dev (hle:try-device lo want)))
    (progn (vla-put-ConfigName lo hle:PC3)
           (setq dev hle:PC3)))
  (vla-RefreshPlotDeviceInfo lo)
  (if (not (setq media (hle:pick-media lo (+ (max wmm hmm) 2.0))))
    (progn
      (alert (strcat "출력 크기 " (rtos wmm 2 0) " x " (rtos hmm 2 0)
                     " mm 가 " dev " 의 가장 큰 용지보다 큽니다.\n"
                     "축척을 키우거나 영역을 줄이세요."))
      (exit)))
  (vla-put-CanonicalMediaName lo media)
  (vla-put-PaperUnits lo hle:MM)
  (vla-put-PlotRotation lo hle:ROT-0)
  (if (setq mono (hle:mono-style lo))
    (progn (vla-put-StyleSheet lo mono)
           (vla-put-PlotWithPlotStyles lo :vlax-true))
    (vla-put-PlotWithPlotStyles lo :vlax-false))
  (vla-put-PlotWithLineweights lo :vlax-true)
  (vla-SetCustomScale lo unit-mm scale)          ; 용지 unit-mm : 도면 scale
  (vla-put-UseStandardScale lo :vlax-false)
  (vla-put-CenterPlot lo :vlax-true)
  ;; 창은 화면 좌표(DCS)로 — 평면 보기면 월드와 같은 방향
  (setq d1 (trans (list (nth 0 box) (nth 1 box) 0.0) 0 2)
        d2 (trans (list (nth 2 box) (nth 3 box) 0.0) 0 2))
  (vla-SetWindowToPlot lo (hle:pt2 (min (car d1) (car d2)) (min (cadr d1) (cadr d2)))
                          (hle:pt2 (max (car d1) (car d2)) (max (cadr d1) (cadr d2))))
  (vla-put-PlotType lo hle:PLOT-WINDOW)
  (list media (if mono t nil) wmm hmm dev))

;; 기준 프레임: 영역 전체를 채운 SOLID + 왼쪽 아래 작은 표식
;; 조립 단계에서 이걸로 정확한 영역과 회전 방향을 찾는다
(defun hle:make-frame (box / x1 y1 x2 y2 s lay)
  (setq x1 (nth 0 box) y1 (nth 1 box) x2 (nth 2 box) y2 (nth 3 box)
        s  (* 0.08 (min (- x2 x1) (- y2 y1))))
  (setq lay (vla-Add *hle-layers* hle:FRAME-LAYER)
        *hle-frame-layer* lay)
  (hle:try 'vla-put-Freeze lay '(:vlax-false))
  (hle:try 'vla-put-Lock lay '(:vlax-false))
  (hle:try 'vla-put-Plottable lay '(:vlax-true))
  (hle:try 'vla-put-Lineweight lay '(0))
  (foreach q (list (list x1 y1 x2 y2)
                   (list x1 y1 (+ x1 s) (+ y1 s)))
    (if (entmake (list '(0 . "SOLID")
                       (cons 8 hle:FRAME-LAYER)
                       '(62 . 7)
                       (list 10 (nth 0 q) (nth 1 q) 0.0)
                       (list 11 (nth 2 q) (nth 1 q) 0.0)
                       (list 12 (nth 0 q) (nth 3 q) 0.0)
                       (list 13 (nth 2 q) (nth 3 q) 0.0)))
      (setq *hle-frame-objs* (cons (vlax-ename->vla-object (entlast)) *hle-frame-objs*)))))

;; 그 레이어만 켜고 출력함 — 나머지는 끄고 '출력 안 함'(Plottable 끔). 끝나면 hle:cleanup 이 둘 다 되돌림.
;; 0.6.1~ (호용 2026-11-02 '일러스트는 모든 객체가 모든 레이어에 · 포토샵은 모든 레이어가 검은 사각 박스'):
;;   DWG To PDF 는 '레이어 정보 포함'(기본)이면 꺼진 레이어도 PDF 에 숨김 레이어로 넣는다 (Autodesk 지원 문서).
;;   끄기만 하면 레이어 PDF 마다 도면 전체 + 기준 프레임(검은 SOLID)이 숨어 들어가 자르는 단계에서 다 보였다.
;;   '출력 안 함' 레이어는 아예 뽑히지 않는다. 블록 안 객체는 자기 레이어를 따르므로(0번 레이어 것은 블록 레이어)
;;   블록이 놓인 레이어가 '출력 안 함'이어도 그 레이어 객체는 뽑힌다 — 끄기와 같고, 동결과 다르다.
(defun hle:only-on (name / u on)
  (setq u (strcase name))
  (vlax-for l *hle-layers*
    (setq on (if (= (strcase (vla-get-Name l)) u) :vlax-true :vlax-false))
    (vl-catch-all-apply 'vla-put-LayerOn (list l on))
    (vl-catch-all-apply 'vla-put-Plottable (list l on))))

(defun hle:plot-to (fname / r)
  (if (findfile fname) (vl-file-delete fname))
  (setq r (vl-catch-all-apply 'vla-PlotToFile (list *hle-plot* fname)))
  (and (not (vl-catch-all-error-p r)) (findfile fname)))

;;; ---------------------------------------------------------------------
;;; 내보내기 본체
;;; settings: (("target" . "ai") ("scale" . 100.0) ("unit_mm" . 1.0)
;;;            ("dpi" . 300) ("ctbw" (색 . 1/100mm) ...) ("layers" (이름 r g b 선가중치) ...))
;;;            선가중치 -10 = CTB대로 (0.5.0~, hy Layer Export 0.4.0 이 씀)
;;;            ("pc3" . "hy Layer Export.pc3") 또는 ("pc3_err" . "까닭") — 0.6.2~ (hy Layer Export 0.5.2 가 씀)
;;; 결과: (완료목록 실패목록 frame경로 setup)
;;; ---------------------------------------------------------------------
(defun hle:export (box ss settings jobdir frames / scale unit-mm layers lo setup want ok frame i n lay fname done failed rest keep o)
  (setq scale   (float (hle:opt "scale" settings))
        unit-mm (float (hle:opt "unit_mm" settings))
        layers  (hle:opt "layers" settings)
        n       (length layers))
  (hle:setvar "BACKGROUNDPLOT" 0)
  (hle:setvar "FILLMODE" 1)
  (vla-StartUndoMark *hle-doc*)
  (setq *hle-undo-open* t)
  (vla-put-QuietErrorMode *hle-plot* :vlax-true)

  (setq *hle-lay-state* (hle:layers-save))
  (vlax-for l *hle-layers* (hle:try 'vla-put-Lock l '(:vlax-false)))

  ;; 도곽 빼기 — 출력하는 동안 도곽 블록을 숨기고, 도곽에만 있던 레이어는 뽑지 않음 (끝나면 hle:cleanup 이 다시 보이게)
  (if (and frames (hle:opt "skip_frame" settings))
    (progn
      (foreach e frames
        (setq o (vlax-ename->vla-object e))
        (if (and (= (vla-get-Visible o) :vlax-true)
                 (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Visible (list o :vlax-false)))))
          (setq *hle-hidden* (cons o *hle-hidden*))))
      (setq rest (hle:ss-minus ss frames)
            keep (if rest (mapcar (function (lambda (c) (strcase (car c)))) (hle:collect rest))))
      (if rest (setq ss rest))
      (princ (strcat "\n도곽 " (itoa (length frames)) "개를 빼고 내보냅니다."))))

  (princ "\n선가중치를 정리하는 중...")
  (hle:lw-prepare layers (hle:opt "ctbw" settings))
  (hle:lw-ss ss)

  (setq lo (vla-get-ActiveLayout *hle-doc*)
        *hle-layout* lo
        *hle-pc-state* (hle:pc-save lo)
        want (hle:opt "pc3" settings)
        setup (hle:setup-plot lo box unit-mm scale want))
  (hle:device-note settings want (nth 4 setup))

  (hle:make-frame box)
  (hle:only-on hle:FRAME-LAYER)
  (setq frame (strcat jobdir "\\frame.pdf"))
  (princ "\n기준 프레임을 출력하는 중...")
  (setq ok (hle:plot-to frame))
  ;; 사본으로 못 뽑으면 DWG To PDF.pc3 로 다시 (용지 · 창도 다시 맞춤)
  (if (and (not ok) (/= (strcase (nth 4 setup)) (strcase hle:PC3)))
    (progn
      (princ (strcat "\n[알림] " (nth 4 setup) " 로 뽑지 못해 " hle:PC3 " 로 다시 뽑습니다 — 레이어마다 PDF 창이 열릴 수 있습니다."))
      (setq setup (hle:setup-plot lo box unit-mm scale nil)
            ok    (hle:plot-to frame))))
  (if (not ok)
    (progn (alert (strcat "기준 프레임 PDF 출력에 실패했습니다.\n" hle:PC3 " 가 있는지 확인하세요."))
           (exit)))

  (setq i 0)
  (foreach L layers
    (setq i (1+ i)
          lay (vl-catch-all-apply 'vla-item (list *hle-layers* (car L))))
    (princ (strcat "\n  (" (itoa i) "/" (itoa n) ") " (car L)))
    (cond
      ((and frames (hle:opt "skip_frame" settings) (not (member (strcase (car L)) keep)))
       (princ "  — 도곽에만 있는 레이어, 건너뜀"))
      ((vl-catch-all-error-p lay)
       (setq failed (cons (car L) failed)))
      (t
        (hle:try 'vla-put-Lineweight lay (list (hle:layer-plot-lw L)))
        (hle:try 'vla-put-Plottable lay '(:vlax-true))
        (hle:only-on (car L))
        (setq fname (strcat jobdir "\\L" (if (< i 10) "0" "") (itoa i) ".pdf"))
        (if (hle:plot-to fname)
          (setq done (cons (list (car L) fname (list (nth 1 L) (nth 2 L) (nth 3 L)) (hle:layer-plot-lw L)) done))
          (setq failed (cons (car L) failed))))))
  (list (reverse done) (reverse failed) frame setup))

;;; ---------------------------------------------------------------------
;;; JSON 쓰기
;;; ---------------------------------------------------------------------
;; 옵션 › 파일 › 프린터 지원 파일 경로의 폴더들 (; 로 여럿 — 있는 폴더만)
(defun hle:pref-dirs (getter / dirs out)
  (setq dirs (vl-catch-all-apply
               (function (lambda () (apply getter (list (vla-get-Files (vla-get-Preferences (vlax-get-acad-object)))))))))
  (if (= (type dirs) 'STR)
    (foreach d (hle:split dirs ";")
      (setq d (vl-string-right-trim "\\/ " (vl-string-left-trim " " d)))
      (if (and (/= d "") (vl-file-directory-p d) (not (member d out)))
        (setq out (cons d out)))))
  (reverse out))

;; 출력 스타일 폴더들 (플롯 스타일 테이블 검색 경로)
(defun hle:ctb-dirs () (hle:pref-dirs 'vla-get-PrinterStyleSheetPath))

;; 플로터 폴더들 (프린터 구성 검색 경로) — 0.6.2~ 설정 창이 DWG To PDF.pc3 옆에 PDF 창이 안 열리는 사본을 만듦
(defun hle:pc3-dirs () (hle:pref-dirs 'vla-get-PrinterConfigPath))

(defun hle:pc3-src (dirs / found p)
  (foreach d dirs
    (if (and (not found) (findfile (setq p (strcat d "\\" hle:PC3))))
      (setq found (findfile p))))
  found)

;; 두께에 쓸 출력 스타일(CTB) 파일 (0.4.0~ — 호용 '내보내기 할 때 ctb 정보에 맞춰 두께값을 잡아 주면'):
;; YGN CAD 내보내기 창이 고른 것(*hle-ctb* — 전체 경로) → 없으면 모형 탭 페이지 설정의 CTB 를 출력 스타일 폴더에서 찾음.
;; 결과: (경로 . "export"|"page") 또는 nil — 설정 창은 export > 지난번 고른 것 > page 순으로 고름
(defun hle:ctb-path ( / nm p found)
  (if (and (= (type *hle-ctb*) 'STR) (findfile *hle-ctb*))
    (cons (findfile *hle-ctb*) "export")
    (progn
      (setq nm (vl-catch-all-apply
                 (function (lambda () (vla-get-StyleSheet (vla-item (vla-get-Layouts (vla-get-ActiveDocument (vlax-get-acad-object))) "Model"))))))
      (if (and (= (type nm) 'STR) (wcmatch (strcase nm) "*.CTB"))
        (foreach d (hle:ctb-dirs)
          (if (and (not found) (findfile (setq p (strcat d "\\" nm))))
            (setq found (findfile p)))))
      (if found (cons found "page")))))

;; 글 목록 → JSON 배열 속
(defun hle:jlist (lst)
  (if lst (substr (apply 'strcat (mapcar (function (lambda (x) (strcat ", " x))) lst)) 3) ""))

(defun hle:write-job (path jobdir dwg box layers scale target nframes / f n i ctb pdirs psrc)
  (setq ctb   (hle:ctb-path)
        pdirs (hle:pc3-dirs)
        psrc  (hle:pc3-src pdirs))
  (setq f (hle:open path "w") n (length layers) i 0)
  (write-line "{" f)
  (write-line "  \"version\": 1," f)
  (write-line (strcat "  \"lisp_version\": " (hle:jstr *hle-version*) ",") f)
  (write-line (strcat "  \"dwg\": " (hle:jstr (hle:slash dwg)) ",") f)
  (write-line (strcat "  \"job_dir\": " (hle:jstr (hle:slash jobdir)) ",") f)
  (write-line (strcat "  \"insunits\": " (itoa (getvar "INSUNITS")) ",") f)
  (write-line (strcat "  \"window\": [" (hle:jnum (nth 0 box)) ", " (hle:jnum (nth 1 box)) ", "
                      (hle:jnum (nth 2 box)) ", " (hle:jnum (nth 3 box)) "],") f)
  (if scale (write-line (strcat "  \"scale\": " (hle:jnum scale) ",") f))   ; hy CAD 도곽을 고르면 그 축척 (설정 창 기본값)
  (if target (write-line (strcat "  \"target\": " (hle:jstr target) ",") f))   ; 내보내기 창에서 고른 보낼 곳 (설정 창이 먼저 고름)
  (if ctb (write-line (strcat "  \"ctb\": " (hle:jstr (hle:slash (car ctb))) ", \"ctb_from\": " (hle:jstr (cdr ctb)) ",") f))   ; 두께 기준 (설정 창이 색마다 펜 두께를 읽음)
  (write-line (strcat "  \"ctb_dirs\": [" (hle:jlist (mapcar (function (lambda (d) (hle:jstr (hle:slash d)))) (hle:ctb-dirs))) "],") f)   ; 설정 창의 CTB 목록
  (write-line "  \"ctb_mode\": true," f)
  ;; 0.6.2~ PDF 창이 안 열리는 사본을 만들 원본 · 플로터 폴더 · 사본 이름 (설정 창이 만들고 settings.lsp "pc3" 로 알려 줌)
  (if psrc (write-line (strcat "  \"pc3_src\": " (hle:jstr (hle:slash psrc)) ",") f))
  (write-line (strcat "  \"pc3_dirs\": [" (hle:jlist (mapcar (function (lambda (d) (hle:jstr (hle:slash d)))) pdirs)) "],") f)
  (write-line (strcat "  \"pc3_quiet\": " (hle:jstr hle:QUIET-PC3) ",") f)
  (write-line (strcat "  \"frames\": " (itoa (if nframes nframes 0)) ",") f)   ; 0.6.0~ 영역 안 도곽 블록 수 (설정 창의 '도곽 빼기')   ; 0.5.0~ 'CTB대로'(객체마다 원래 색의 펜 두께)를 받을 수 있음
  (write-line "  \"layers\": [" f)
  (foreach L layers
    (setq i (1+ i))
    (write-line (strcat "    {\"name\": " (hle:jstr (car L))
                        ", \"count\": " (itoa (cadr L))
                        ", \"lw\": " (itoa (caddr L))
                        ", \"aci\": " (itoa (cadddr L))
                        ", \"acis\": [" (hle:jlist (mapcar 'itoa (nth 4 L))) "]}"
                        (if (< i n) "," "")) f))
  (write-line "  ]" f)
  (write-line "}" f)
  (close f)
  path)

(defun hle:write-result (path jobdir dwg settings res / f done failed setup n i)
  (setq done (nth 0 res) failed (nth 1 res) setup (nth 3 res)
        f (hle:open path "w") n (length done) i 0)
  (write-line "{" f)
  (write-line "  \"version\": 1," f)
  (write-line (strcat "  \"dwg\": " (hle:jstr (hle:slash dwg)) ",") f)
  (write-line (strcat "  \"job_dir\": " (hle:jstr (hle:slash jobdir)) ",") f)
  (write-line (strcat "  \"target\": " (hle:jstr (hle:opt "target" settings)) ",") f)
  (write-line (strcat "  \"dpi\": " (hle:jnum (hle:opt "dpi" settings)) ",") f)
  (write-line (strcat "  \"mono\": " (if (nth 1 setup) "true" "false") ",") f)
  (write-line (strcat "  \"media\": " (hle:jstr (nth 0 setup)) ",") f)
  (write-line (strcat "  \"device\": " (hle:jstr (nth 4 setup)) ",") f)   ; 0.6.2~ 뽑은 장치 (조립 기록에)
  (write-line (strcat "  \"paper_mm\": [" (hle:jnum (nth 2 setup)) ", " (hle:jnum (nth 3 setup)) "],") f)
  (write-line (strcat "  \"frame\": " (hle:jstr (hle:slash (nth 2 res))) ",") f)
  (write-line "  \"layers\": [" f)
  (foreach L done
    (setq i (1+ i))
    (write-line (strcat "    {\"name\": " (hle:jstr (nth 0 L))
                        ", \"pdf\": " (hle:jstr (hle:slash (nth 1 L)))
                        ", \"color\": [" (itoa (nth 0 (nth 2 L))) ", " (itoa (nth 1 (nth 2 L))) ", " (itoa (nth 2 (nth 2 L))) "]"
                        ", \"lw\": " (itoa (nth 3 L)) "}"
                        (if (< i n) "," "")) f))
  (write-line "  ]," f)
  (write-line (strcat "  \"failed\": ["
                      (if failed
                        (substr (apply 'strcat (mapcar (function (lambda (x) (strcat ", " (hle:jstr x)))) failed)) 3)
                        "")
                      "]") f)
  (write-line "}" f)
  (close f)
  path)

;;; ---------------------------------------------------------------------
;;; 외부 프로그램
;;; ---------------------------------------------------------------------
(defun hle:cmd-for (p)
  (if (wcmatch (strcase p) "*.PYW,*.PY")
    (strcat "pythonw.exe \"" p "\"")
    (strcat "\"" p "\"")))

;; 찾는 순서: 직접 지정 → 허브 설치 자리 → 지원 파일 검색 경로 → 손으로 둔 자리 → 개발용 pyw
(defun hle:launcher ( / p la)
  (setq la (getenv "LOCALAPPDATA"))
  (cond
    ((and (= (type *hle-exe*) 'STR) (setq p (findfile *hle-exe*))) (hle:cmd-for p))
    ((and la (setq p (findfile (strcat la "\\Programs\\hy\\hy-layer-export\\hy_layer_export.exe"))))
     (hle:cmd-for p))
    ((setq p (findfile "hy_layer_export.exe")) (hle:cmd-for p))
    ((and la (setq p (findfile (strcat la "\\hy\\layer_export\\hy_layer_export.exe"))))
     (hle:cmd-for p))
    ((setq p (findfile "hle_app.pyw")) (hle:cmd-for p))))

;; wait 가 t 면 창이 닫힐 때까지 기다리고 종료 코드를 돌려준다
(defun hle:run (cmd wait / ws rc)
  (setq ws (vlax-create-object "WScript.Shell"))
  (setq rc (vl-catch-all-apply 'vlax-invoke-method
             (list ws 'Run cmd 1 (if wait :vlax-true :vlax-false))))
  (vlax-release-object ws)
  (cond ((vl-catch-all-error-p rc) -1)
        ((= (type rc) 'VARIANT) (vlax-variant-value rc))
        (t rc)))

;; tag 가 있으면 끝에 붙임 — 내보내기 창이 같은 초에 여러 도곽을 내보내도 폴더가 겹치지 않게
(defun hle:job-dir (tag / tmp)
  (setq tmp (getenv "TEMP"))
  (if (not tmp) (setq tmp (getvar "TEMPPREFIX")))
  (if (= (substr tmp (strlen tmp)) "\\") (setq tmp (substr tmp 1 (1- (strlen tmp)))))
  (hle:mkdirs (strcat tmp "\\hy_layer_export\\"
                      (vl-string-translate "." "_" (rtos (getvar "CDATE") 2 6))
                      (if tag (strcat "_" tag) ""))))

;;; ---------------------------------------------------------------------
;;; 영역 고르기
;;; ---------------------------------------------------------------------
;; HY_TB_<용지>(_P) → 그 방향의 종이 (가로 세로 mm), 도곽이 아니면 nil
(defun hle:hy-paper (name / u p)
  (setq u (strcase name))
  (if (and (wcmatch u "HY_TB_A#,HY_TB_A#_P")
           (setq p (cdr (assoc (substr u 7 2) '(("A4" 297.0 210.0) ("A3" 420.0 297.0) ("A2" 594.0 420.0) ("A1" 841.0 594.0))))))
    (if (wcmatch u "*_P") (list (cadr p) (car p)) p)))

;; 도곽 블록 → ((x1 y1 x2 y2) 축척) — hy CAD 도곽(돌리지 않은 것)은 종이 끝 범위와 블록 축척, 다른 블록은 경계 상자(축척 nil). 블록이 아니면 nil.
(defun hle:frame-of (en / o p sx rot ins a b)
  (if (and en (= (cdr (assoc 0 (entget en))) "INSERT"))
    (progn
     (setq o   (vlax-ename->vla-object en)
           p   (hle:hy-paper (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))
           sx  (vla-get-XScaleFactor o)
           rot (vla-get-Rotation o))
     (if (and p (> sx 0.0) (or (equal rot 0.0 1e-6) (equal rot (* 2 pi) 1e-6)))
       (progn
         (setq ins (vlax-get o 'InsertionPoint))
         (list (list (car ins) (cadr ins) (+ (car ins) (* (car p) sx)) (+ (cadr ins) (* (cadr p) sx))) sx))
       (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
         (progn
           (setq a (vlax-safearray->list a) b (vlax-safearray->list b))
           (list (list (car a) (cadr a) (car b) (cadr b)) nil)))))))

;; 도곽 블록 클릭 → hle:frame-of
(defun hle:pick-frame ( / sel)
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n도곽 블록을 클릭하세요: "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n도곽을 고르지 않았습니다.") nil)
    ((/= (cdr (assoc 0 (entget (car sel)))) "INSERT") (princ "\n[주의] 도곽은 블록이어야 합니다.") nil)
    (t (setq *hle-picked* (car sel)) (hle:frame-of (car sel)))))

;; 도곽 빼기 (0.6.0~ — 호용 2026-10-31 '내보내기 할 때 도곽은 제외시킬 수도'):
;; 고른 도곽 블록 + 영역 안 YGN 도곽(HY_TB_*) 블록 → ename 목록
(defun hle:frames-in (ss fen / i e ed o nm out)
  (if (and fen (entget fen)) (setq out (list fen)))
  (setq i 0)
  (repeat (sslength ss)
    (setq e (ssname ss i) i (1+ i) ed (entget e))
    (if (and (= (cdr (assoc 0 ed)) "INSERT") (not (member e out)))
      (progn
        (setq o (vlax-ename->vla-object e)
              nm (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))
        (if (hle:hy-paper nm) (setq out (cons e out))))))
  out)

;; ss 에서 목록의 객체를 뺀 새 선택 (없으면 nil)
(defun hle:ss-minus (ss ens / out i e)
  (setq out (ssadd) i 0)
  (repeat (sslength ss)
    (setq e (ssname ss i) i (1+ i))
    (if (not (member e ens)) (ssadd e out)))
  (if (> (sslength out) 0) out))

;; 영역에 걸친 객체 — 화면 밖이어도 잡히게 잠시 그 영역으로 화면을 옮겨 고른 뒤 되돌린다
(defun hle:select (box / m ss)
  (setq m (* 0.02 (max (- (nth 2 box) (nth 0 box)) (- (nth 3 box) (nth 1 box)))))
  (command "_.ZOOM" "_W" "_non" (trans (list (- (nth 0 box) m) (- (nth 1 box) m) 0.0) 0 1)
                         "_non" (trans (list (+ (nth 2 box) m) (+ (nth 3 box) m) 0.0) 0 1))
  (setq ss (ssget "_C" (trans (list (nth 0 box) (nth 1 box) 0.0) 0 1) (trans (list (nth 2 box) (nth 3 box) 0.0) 0 1)))
  (command "_.ZOOM" "_P")
  ss)

;; 평면 보기인지. 아니면 평면(PLAN 표준)으로 바꿀지 묻는다 (플롯 창은 화면 좌표라서)
(defun hle:plan-ok ( / k)
  (cond
    ((and (equal (trans '(1.0 0.0 0.0) 0 2 t) '(1.0 0.0 0.0) 1e-8)
          (equal (trans '(0.0 0.0 1.0) 0 2 t) '(0.0 0.0 1.0) 1e-8)) t)
    (t
     (initget "Yes No")
     (setq k (getkword "\n[주의] 화면이 평면 보기가 아닙니다 (시점·화면 회전). 평면 보기(PLAN 표준)로 바꿀까요? [예(Y)/아니오(N)] <Y>: "))
     (if (/= k "No") (progn (command "_.PLAN" "_W") t)))))

;;; ---------------------------------------------------------------------
;;; 명령
;;; ---------------------------------------------------------------------
;; 명령마다 처음에 — 문서 · 레이어 · 플롯 객체, 명령줄 조용히
(defun hle:begin ()
  (setq *hle-doc*    (vla-get-ActiveDocument (vlax-get-acad-object))
        *hle-layers* (vla-get-Layers *hle-doc*)
        *hle-plot*   (vla-get-Plot *hle-doc*)
        *hle-layout* nil)
  (hle:setvar "CMDECHO" 0)
  (hle:setvar "DIMZIN" 0))

;; 영역 하나 내보내기 — 설정 창(닫힐 때까지 기다림) → 레이어별 PDF → 조립.
;; target("ai" · "ps")이 있으면 설정 창이 그것을 먼저 고른다, tag 는 작업 폴더 이름 끝에. 넘겼으면 t.
(defun hle:export-box (launcher box scale target tag fen / ss layers jobdir dwg job rc settings res result frames)
  (cond
    ((or (equal (nth 0 box) (nth 2 box) 1e-9) (equal (nth 1 box) (nth 3 box) 1e-9))
     (princ "\n[주의] 영역 크기가 0 입니다.") nil)
    ((not (setq ss (hle:select box)))
     (princ "\n[주의] 영역 안에 객체가 없습니다.") nil)
    (t
     (princ "\n레이어를 확인하는 중...")
     (cond
       ((null (setq layers (hle:collect ss)))
        (princ "\n[주의] 내보낼 수 있는 레이어가 없습니다 (꺼진 · 동결 · Defpoints 레이어는 빠짐).") nil)
       (t
        (setq frames (hle:frames-in ss fen)
              jobdir (hle:job-dir tag)
              dwg    (strcat (getvar "DWGPREFIX") (getvar "DWGNAME"))
              job    (hle:write-job (strcat jobdir "\\job.json") jobdir dwg box layers scale target (length frames)))
        (princ (strcat "\n[알림] 레이어 " (itoa (length layers)) "개. 설정 창이 닫힐 때까지 캐드는 기다립니다."))
        (setq rc (hle:run (strcat launcher " --job \"" job "\"") t))
        (cond
          ((= rc 2) (princ "\n취소했습니다.") nil)
          ((/= rc 0) (princ (strcat "\n[오류] 설정 창이 비정상으로 끝났습니다 (코드 " (vl-princ-to-string rc) ").")) nil)
          ((not (setq settings (hle:read-settings (strcat jobdir "\\settings.lsp"))))
           (princ "\n[오류] 설정 파일을 읽지 못했습니다.") nil)
          (t
           (setq res (hle:export box ss settings jobdir frames))
           (setq result (hle:write-result (strcat jobdir "\\result.json") jobdir dwg settings res))
           (hle:cleanup)
           (if (car res)
             (progn
               (princ (strcat "\n[완료] PDF " (itoa (length (car res))) "장을 출력했습니다. "
                              (if (= (hle:opt "target" settings) "ps") "포토샵으로" "일러스트레이터로")
                              " 넘기는 중입니다."))
               (hle:run (strcat launcher " --assemble \"" result "\"") nil)
               t)
             (progn (princ "\n[주의] 출력된 레이어가 없습니다.") nil)))))))))

(defun hle:no-launcher ()
  (alert (strcat "설정 창 프로그램 hy Layer Export 를 찾지 못했습니다.\n\n"
                 "hy 허브에서 hy Layer Export 를 설치하세요.\n"
                 "(다른 곳에 두었다면 (setq *hle-exe* \"경로\\\\hy_layer_export.exe\") 로 지정)")))

(defun c:HLE ( / *error* launcher p1 p2 fr w1 w2 box scale)
  (defun *error* (msg)
    (hle:cleanup)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (setq *hle-picked* nil)
  (setq *hle-ctb* nil)   ; 내보내기 창이 남긴 CTB 는 HLE 명령에 안 씀 (모형 탭 페이지 설정의 CTB)
  (hle:begin)
  (cond
    ((/= (getvar "TILEMODE") 1)
     (princ "\n[주의] 모형 탭에서 실행하세요."))
    ((not (setq launcher (hle:launcher)))
     (hle:no-launcher))
    ((not (hle:plan-ok))
     (princ "\n평면 보기가 아니어서 그만두었습니다."))
    ((progn (initget "Frame")
            (null (setq p1 (getpoint "\n내보낼 영역의 첫 번째 구석을 지정하세요 [도곽 고르기(F)]: ")))))
    ((and (= (type p1) 'STR) (null (setq fr (hle:pick-frame)))))
    ((and (null fr) (null (setq p2 (getcorner p1 "\n반대쪽 구석을 지정하세요: ")))))
    (t
     (if fr
       (setq box (car fr) scale (cadr fr))
       (setq w1  (trans p1 1 0)
             w2  (trans p2 1 0)
             box (list (min (car w1) (car w2)) (min (cadr w1) (cadr w2))
                       (max (car w1) (car w2)) (max (cadr w1) (cadr w2)))))
     (hle:export-box launcher box scale nil nil (if fr *hle-picked*))))
  (hle:cleanup)
  (princ))

;; YGN CAD 내보내기 창 (1.23.0~) — 묻지 않고 도곽 · 영역마다 내보낸다 (도곽마다 설정 창이 열림).
;; (hle:run-preset '("ai" "1A" "1B" (x1 y1 x2 y2))) — 첫 칸은 보낼 곳("ai" · "ps"),
;; 글 = 도곽 블록 핸들(YGN 도곽이면 종이 끝 범위 · 축척), 숫자 넷 = 영역 상자(WCS).
(defun hle:run-preset (lst / *error* launcher target items en fr n i ok)
  (defun *error* (msg)
    (hle:cleanup)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (setq target (car lst) items (cdr lst) n (length items) i 0 ok 0)
  (hle:begin)
  (cond
    ((null items) (princ "\n[주의] 내보낼 도곽이 없습니다."))
    ((not (setq launcher (hle:launcher))) (hle:no-launcher))
    (t
     (if (/= (getvar "TILEMODE") 1)
       (progn (setvar "TILEMODE" 1) (princ "\n[알림] 모형 탭으로 옮겼습니다.")))
     (if (not (hle:plan-ok))
       (princ "\n평면 보기가 아니어서 그만두었습니다.")
       (progn
         (foreach it items
           (setq i (1+ i) fr nil en nil)
           (cond
             ((= (type it) 'STR)
              (if (not (and (setq en (handent it)) (setq fr (hle:frame-of en))))
                (princ (strcat "\n[주의] 도곽(" it ")을 찾지 못했습니다."))))
             ((and (listp it) (= (length it) 4) (vl-every 'numberp it))
              (setq fr (list (mapcar 'float it) nil))))
           (if fr
             (progn
               (hle:begin)
               (princ (strcat "\n[알림] " (itoa i) "/" (itoa n) " 내보내는 중..."))
               (if (hle:export-box launcher (car fr) (cadr fr) target (itoa i) en) (setq ok (1+ ok)))
               (hle:cleanup))))
         (princ (strcat "\n[완료] " (itoa ok) "/" (itoa n) "개를 "
                        (if (= target "ps") "포토샵으로" "일러스트레이터로") " 넘겼습니다."))))))
  (hle:cleanup)
  (princ))

(defun hle:read-settings (path / s)
  (if (setq s (hle:read-file path)) (read s)))

(princ)
