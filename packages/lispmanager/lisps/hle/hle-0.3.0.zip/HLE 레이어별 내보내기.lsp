;;; =====================================================================
;;;  hy Layer Export  v0.3.0          명령: HLE
;;;
;;;  캐드에서 플롯하듯 영역을 정하면 레이어별로 나눠
;;;  일러스트레이터 / 포토샵 레이어로 넘긴다.
;;;
;;;  흐름
;;;    1. 영역 지정 (플롯 창처럼 두 점, 또는 F 로 도곽 블록 클릭 — hy CAD 도곽은 종이 끝 범위 · 축척까지)
;;;    2. 영역 안 레이어 수집 (블록 내부 · 속성 포함)  -> job.json
;;;    3. 설정 창(exe) 실행, 닫힐 때까지 대기            -> settings.lsp
;;;    4. 선가중치 임시 적용 -> 레이어별 PDF 플롯 -> 원상 복구
;;;    5. result.json 작성 -> 조립(exe --assemble) 실행
;;;
;;;  YGN CAD 내보내기 창(1.23.0~)은 묻지 않고 도곽마다 부른다:
;;;    (hle:run-preset '("ai" "1A" "1B"))  — 글 = 도곽 블록 핸들, 숫자 넷 = 영역 상자
;;;
;;;  색은 캐드에서 건드리지 않는다. 흑백(monochrome)으로 플롯한 뒤
;;;  일러스트/포토샵 쪽에서 지정한 색을 입힌다.
;;;
;;;  필요: AutoCAD 2021 이상(유니코드 AutoLISP), DWG To PDF.pc3, 모형 탭
;;;        hy 허브의 hy Layer Export (설정 창 · 조립 프로그램)
;;; =====================================================================
(vl-load-com)

(setq *hle-version* "0.3.0")

;; 설정 창 실행 파일을 직접 지정하려면 아래 줄의 주석을 풀고 경로를 넣는다.
;; .exe 또는 개발용 .pyw 모두 가능
;; (setq *hle-exe* "D:\\hy\\hy_layer_export\\hy_layer_export.exe")

(setq hle:PC3          "DWG To PDF.pc3"
      hle:FRAME-LAYER  "HLE__FRAME"
      hle:LW-BYLAYER   -1
      hle:PLOT-WINDOW  4      ; acWindow
      hle:ROT-0        0      ; ac0degrees
      hle:MM           1)     ; acMillimeters

;;; ---------------------------------------------------------------------
;;; 문자열 · 파일 유틸
;;; ---------------------------------------------------------------------
(defun hle:split (s d / i out)
  (while (setq i (vl-string-search d s))
    (setq out (cons (substr s 1 i) out)
          s   (substr s (+ i 1 (strlen d)))))
  (reverse (cons s out)))

(defun hle:mkdirs (path / cur)
  (foreach p (hle:split path "\\")
    (setq cur (if cur (strcat cur "\\" p) p))
    (if (and (/= p "") (not (vl-file-directory-p cur)))
      (vl-mkdir cur)))
  path)

(defun hle:slash (p) (vl-string-translate "\\" "/" p))

(defun hle:jstr (s / out i c)
  (setq out "" i 1)
  (while (<= i (strlen s))
    (setq c (substr s i 1)
          i (1+ i)
          out (strcat out (cond ((= c "\\") "\\\\")
                                ((= c "\"") "\\\"")
                                (t c)))))
  (strcat "\"" out "\""))

(defun hle:jnum (x)
  (if (= (type x) 'INT) (itoa x) (rtos x 2 6)))

;; AutoCAD 2021+ 는 인코딩 인자를 받는다. 구버전이면 기본 인코딩으로.
(defun hle:open (path mode / f)
  (setq f (vl-catch-all-apply 'open (list path mode "utf8")))
  (if (or (vl-catch-all-error-p f) (null f))
    (open path mode)
    f))

(defun hle:read-file (path / f ln out)
  (if (and (findfile path) (setq f (hle:open path "r")))
    (progn
      (setq out "")
      (while (setq ln (read-line f)) (setq out (strcat out ln " ")))
      (close f)
      out)))

(defun hle:opt (key lst) (cdr (assoc key lst)))

;;; ---------------------------------------------------------------------
;;; 상태 저장 · 복구
;;; ---------------------------------------------------------------------
(defun hle:setvar (name val)
  (if (not (assoc name *hle-sysvars*))
    (setq *hle-sysvars* (cons (cons name (getvar name)) *hle-sysvars*)))
  (setvar name val))

(defun hle:try (fn obj args) (vl-catch-all-apply fn (cons obj args)))

(defun hle:layers-save ( / out)
  (vlax-for l *hle-layers*
    (setq out (cons (list l
                          (vla-get-LayerOn l)
                          (vla-get-Lock l)
                          (vla-get-Plottable l)
                          (vla-get-Lineweight l))
                    out)))
  out)

(defun hle:layers-restore (st)
  (foreach s st
    (hle:try 'vla-put-LayerOn    (nth 0 s) (list (nth 1 s)))
    (hle:try 'vla-put-Plottable  (nth 0 s) (list (nth 3 s)))
    (hle:try 'vla-put-Lineweight (nth 0 s) (list (nth 4 s))))
  ;; 잠금은 마지막에
  (foreach s st (hle:try 'vla-put-Lock (nth 0 s) (list (nth 2 s)))))

;; 모형 탭 페이지 설정 백업
(defun hle:pc-save (lo / n d ll ur)
  (vl-catch-all-apply 'vla-GetCustomScale (list lo 'n 'd))
  (vl-catch-all-apply 'vla-GetWindowToPlot (list lo 'll 'ur))
  (list (vla-get-ConfigName lo)            ; 0
        (vla-get-CanonicalMediaName lo)    ; 1
        (vla-get-PaperUnits lo)            ; 2
        (vla-get-PlotRotation lo)          ; 3
        (vla-get-PlotType lo)              ; 4
        (vla-get-UseStandardScale lo)      ; 5
        (vla-get-StandardScale lo)         ; 6
        n d                                ; 7 8
        (vla-get-CenterPlot lo)            ; 9
        (vla-get-PlotOrigin lo)            ; 10
        (vla-get-PlotWithLineweights lo)   ; 11
        (vla-get-PlotWithPlotStyles lo)    ; 12
        (vla-get-StyleSheet lo)            ; 13
        ll ur))                            ; 14 15

(defun hle:pc-restore (lo s)
  (hle:try 'vla-put-ConfigName lo (list (nth 0 s)))
  (hle:try 'vla-RefreshPlotDeviceInfo lo nil)
  (hle:try 'vla-put-CanonicalMediaName lo (list (nth 1 s)))
  (hle:try 'vla-put-PaperUnits lo (list (nth 2 s)))
  (hle:try 'vla-put-PlotRotation lo (list (nth 3 s)))
  (hle:try 'vla-put-StyleSheet lo (list (nth 13 s)))
  (hle:try 'vla-put-PlotWithPlotStyles lo (list (nth 12 s)))
  (hle:try 'vla-put-PlotWithLineweights lo (list (nth 11 s)))
  (if (and (nth 7 s) (nth 8 s))
    (hle:try 'vla-SetCustomScale lo (list (nth 7 s) (nth 8 s))))
  (hle:try 'vla-put-UseStandardScale lo (list (nth 5 s)))
  (if (= (nth 5 s) :vlax-true)
    (hle:try 'vla-put-StandardScale lo (list (nth 6 s))))
  (hle:try 'vla-put-CenterPlot lo (list (nth 9 s)))
  (hle:try 'vla-put-PlotOrigin lo (list (nth 10 s)))
  (if (and (nth 14 s) (nth 15 s))
    (hle:try 'vla-SetWindowToPlot lo (list (nth 14 s) (nth 15 s))))
  (hle:try 'vla-put-PlotType lo (list (nth 4 s))))

;; 여러 번 불러도 안전하다
(defun hle:cleanup ()
  (foreach u *hle-lw-undo*
    (vl-catch-all-apply 'vla-put-Lineweight (list (car u) (cdr u))))
  (setq *hle-lw-undo* nil
        *hle-lw-seen* nil)
  (foreach o *hle-frame-objs* (vl-catch-all-apply 'vla-delete (list o)))
  (setq *hle-frame-objs* nil)
  (if *hle-lay-state*
    (progn (hle:layers-restore *hle-lay-state*) (setq *hle-lay-state* nil)))
  (if *hle-frame-layer*
    (progn (vl-catch-all-apply 'vla-delete (list *hle-frame-layer*))
           (setq *hle-frame-layer* nil)))
  (if (and *hle-layout* *hle-pc-state*)
    (progn (hle:pc-restore *hle-layout* *hle-pc-state*)
           (setq *hle-pc-state* nil)))
  (if *hle-plot* (vl-catch-all-apply 'vla-put-QuietErrorMode (list *hle-plot* :vlax-false)))
  (if *hle-undo-open*
    (progn (vl-catch-all-apply 'vla-EndUndoMark (list *hle-doc*))
           (setq *hle-undo-open* nil)))
  (foreach sv *hle-sysvars* (vl-catch-all-apply 'setvar (list (car sv) (cdr sv))))
  (setq *hle-sysvars* nil))

;;; ---------------------------------------------------------------------
;;; 레이어 수집 (블록 내부 · 속성 · 치수 포함)
;;; ---------------------------------------------------------------------
(defun hle:cnt-add (lay / a)
  (if (setq a (assoc lay *hle-cnt*))
    (setq *hle-cnt* (subst (cons lay (1+ (cdr a))) a *hle-cnt*))
    (setq *hle-cnt* (cons (cons lay 1) *hle-cnt*))))

;; 블록 안 0번 레이어 객체는 블록이 놓인 레이어를 따른다
(defun hle:eff-layer (lay parent)
  (if (and parent (= (strcase lay) "0")) parent lay))

(defun hle:scan-ent (e parent / ed typ lay a)
  (setq ed  (entget e)
        typ (cdr (assoc 0 ed))
        lay (hle:eff-layer (cdr (assoc 8 ed)) parent))
  (hle:cnt-add lay)
  (cond
    ((= typ "INSERT")
     (if (= 1 (cdr (assoc 66 ed)))
       (progn
         (setq a (entnext e))
         (while (and a (= (cdr (assoc 0 (entget a))) "ATTRIB"))
           (hle:cnt-add (hle:eff-layer (cdr (assoc 8 (entget a))) lay))
           (setq a (entnext a)))))
     (hle:scan-block (cdr (assoc 2 ed)) lay))
    ((= typ "DIMENSION")
     (if (assoc 2 ed) (hle:scan-block (cdr (assoc 2 ed)) lay)))))

(defun hle:scan-block (bname eff / key e typ)
  (setq key (strcat (strcase bname) "|" (strcase eff)))
  (if (and (not (member key *hle-seen*))
           (setq e (tblobjname "BLOCK" bname)))
    (progn
      (setq *hle-seen* (cons key *hle-seen*))
      (while (and (setq e (entnext e))
                  (/= (setq typ (cdr (assoc 0 (entget e)))) "ENDBLK"))
        (if (not (member typ '("ATTRIB" "SEQEND" "ATTDEF")))
          (hle:scan-ent e eff))))))

(defun hle:layer-visible-p (name / td)
  (and (setq td (tblsearch "LAYER" name))
       (> (cdr (assoc 62 td)) 0)              ; 꺼진 레이어는 색 번호가 음수
       (zerop (logand 1 (cdr (assoc 70 td)))) ; 동결 아님
       (/= (strcase name) "DEFPOINTS")))

;; 결과: ((이름 객체수 선가중치) ...)
(defun hle:collect (ss / i out lw)
  (setq *hle-cnt* nil *hle-seen* nil i 0)
  (repeat (sslength ss)
    (hle:scan-ent (ssname ss i) nil)
    (setq i (1+ i)))
  (foreach c *hle-cnt*
    (if (hle:layer-visible-p (car c))
      (progn
        (setq lw (cdr (assoc 370 (entget (tblobjname "LAYER" (car c))))))
        (setq out (cons (list (car c) (cdr c) (if lw lw -3)) out)))))
  (setq *hle-cnt* nil *hle-seen* nil)
  out)

;;; ---------------------------------------------------------------------
;;; 선가중치 임시 정리: 객체 선가중치를 전부 ByLayer 로
;;; (블록 정의 안쪽까지. 외부참조 · 치수 · 표 블록은 제외)
;;; ---------------------------------------------------------------------
(defun hle:lw-norm (obj / lw)
  (if (vlax-property-available-p obj 'Lineweight t)
    (progn
      (setq lw (vl-catch-all-apply 'vla-get-Lineweight (list obj)))
      (if (and (not (vl-catch-all-error-p lw)) (/= lw hle:LW-BYLAYER))
        (if (not (vl-catch-all-error-p
                   (vl-catch-all-apply 'vla-put-Lineweight (list obj hle:LW-BYLAYER))))
          (setq *hle-lw-undo* (cons (cons obj lw) *hle-lw-undo*)))))))

(defun hle:lw-obj (obj / on)
  (hle:lw-norm obj)
  (setq on (vla-get-ObjectName obj))
  (if (wcmatch on "AcDbBlockReference,AcDbMInsertBlock")
    (progn
      (if (= (vla-get-HasAttributes obj) :vlax-true)
        (foreach a (vlax-invoke obj 'GetAttributes) (hle:lw-norm a)))
      (hle:lw-block (vla-get-Name obj)))))

(defun hle:lw-block (bn / blk)
  (if (and (not (member (strcase bn) *hle-lw-seen*))
           (not (wcmatch bn "`*D*,`*T*")))
    (progn
      (setq *hle-lw-seen* (cons (strcase bn) *hle-lw-seen*))
      (setq blk (vl-catch-all-apply 'vla-item (list (vla-get-Blocks *hle-doc*) bn)))
      (if (and (not (vl-catch-all-error-p blk))
               (= (vla-get-IsXRef blk) :vlax-false))
        (vlax-for o blk (hle:lw-obj o))))))

(defun hle:lw-ss (ss / i)
  (setq *hle-lw-seen* nil i 0)
  (repeat (sslength ss)
    (hle:lw-obj (vlax-ename->vla-object (ssname ss i)))
    (setq i (1+ i))))

;;; ---------------------------------------------------------------------
;;; 플롯 설정
;;; ---------------------------------------------------------------------
(defun hle:pt2 (x y)
  (vlax-make-variant
    (vlax-safearray-fill (vlax-make-safearray vlax-vbDouble '(0 . 1)) (list x y))))

;; "ISO_full_bleed_A3_(420.00_x_297.00_MM)" -> (420.0 297.0)
(defun hle:parse-mm (nm / a s x)
  (if (and (wcmatch (strcase nm) "*_MM)")
           (setq a (vl-string-position (ascii "(") nm nil t)))
    (progn
      (setq s (substr nm (+ a 2) (- (strlen nm) a 5)))
      (if (setq x (vl-string-search "_x_" s))
        (list (atof (substr s 1 x)) (atof (substr s (+ x 4))))))))

;; 회전 방향과 상관없이 들어가도록 짧은 변이 출력 긴 변보다 큰 용지 중
;; 여백 없는(full bleed) 용지를 우선, 그중 가장 작은 것
(defun hle:pick-media (lo need / names wh mn ar fb usable best)
  (setq names (vl-catch-all-apply
                (function (lambda ()
                  (vlax-safearray->list
                    (vlax-variant-value (vla-GetCanonicalMediaNames lo)))))
                nil))
  (if (vl-catch-all-error-p names) (setq names nil))
  (foreach nm names
    (if (setq wh (hle:parse-mm nm))
      (progn
        (setq mn     (min (car wh) (cadr wh))
              ar     (* (car wh) (cadr wh))
              fb     (wcmatch (strcase nm) "*FULL_BLEED*")
              usable (if fb mn (- mn 30.0)))
        (if (and (>= usable need)
                 (or (null best)
                     (and fb (not (cadr best)))
                     (and (eq fb (cadr best)) (< ar (caddr best)))))
          (setq best (list nm fb ar))))))
  (car best))

(defun hle:mono-style (lo / want names)
  (setq want (if (= (getvar "PSTYLEMODE") 1) "MONOCHROME.CTB" "MONOCHROME.STB"))
  (setq names (vl-catch-all-apply
                (function (lambda ()
                  (vlax-safearray->list
                    (vlax-variant-value (vla-GetPlotStyleTableNames lo)))))
                nil))
  (if (not (vl-catch-all-error-p names))
    (car (vl-remove-if-not (function (lambda (n) (= (strcase n) want))) names))))

;; 결과: (용지이름 흑백여부 출력폭mm 출력높이mm)
(defun hle:setup-plot (lo box unit-mm scale / wmm hmm media mono d1 d2)
  (setq wmm (/ (* (- (nth 2 box) (nth 0 box)) unit-mm) scale)
        hmm (/ (* (- (nth 3 box) (nth 1 box)) unit-mm) scale))
  (vla-put-ConfigName lo hle:PC3)
  (vla-RefreshPlotDeviceInfo lo)
  (if (not (setq media (hle:pick-media lo (+ (max wmm hmm) 2.0))))
    (progn
      (alert (strcat "출력 크기 " (rtos wmm 2 0) " x " (rtos hmm 2 0)
                     " mm 가 " hle:PC3 " 의 가장 큰 용지보다 큽니다.\n"
                     "축척을 키우거나 영역을 줄이세요."))
      (exit)))
  (vla-put-CanonicalMediaName lo media)
  (vla-put-PaperUnits lo hle:MM)
  (vla-put-PlotRotation lo hle:ROT-0)
  (if (setq mono (hle:mono-style lo))
    (progn (vla-put-StyleSheet lo mono)
           (vla-put-PlotWithPlotStyles lo :vlax-true))
    (vla-put-PlotWithPlotStyles lo :vlax-false))
  (vla-put-PlotWithLineweights lo :vlax-true)
  (vla-SetCustomScale lo unit-mm scale)          ; 용지 unit-mm : 도면 scale
  (vla-put-UseStandardScale lo :vlax-false)
  (vla-put-CenterPlot lo :vlax-true)
  ;; 창은 화면 좌표(DCS)로 — 평면 보기면 월드와 같은 방향
  (setq d1 (trans (list (nth 0 box) (nth 1 box) 0.0) 0 2)
        d2 (trans (list (nth 2 box) (nth 3 box) 0.0) 0 2))
  (vla-SetWindowToPlot lo (hle:pt2 (min (car d1) (car d2)) (min (cadr d1) (cadr d2)))
                          (hle:pt2 (max (car d1) (car d2)) (max (cadr d1) (cadr d2))))
  (vla-put-PlotType lo hle:PLOT-WINDOW)
  (list media (if mono t nil) wmm hmm))

;; 기준 프레임: 영역 전체를 채운 SOLID + 왼쪽 아래 작은 표식
;; 조립 단계에서 이걸로 정확한 영역과 회전 방향을 찾는다
(defun hle:make-frame (box / x1 y1 x2 y2 s lay)
  (setq x1 (nth 0 box) y1 (nth 1 box) x2 (nth 2 box) y2 (nth 3 box)
        s  (* 0.08 (min (- x2 x1) (- y2 y1))))
  (setq lay (vla-Add *hle-layers* hle:FRAME-LAYER)
        *hle-frame-layer* lay)
  (hle:try 'vla-put-Freeze lay '(:vlax-false))
  (hle:try 'vla-put-Lock lay '(:vlax-false))
  (hle:try 'vla-put-Plottable lay '(:vlax-true))
  (hle:try 'vla-put-Lineweight lay '(0))
  (foreach q (list (list x1 y1 x2 y2)
                   (list x1 y1 (+ x1 s) (+ y1 s)))
    (if (entmake (list '(0 . "SOLID")
                       (cons 8 hle:FRAME-LAYER)
                       '(62 . 7)
                       (list 10 (nth 0 q) (nth 1 q) 0.0)
                       (list 11 (nth 2 q) (nth 1 q) 0.0)
                       (list 12 (nth 0 q) (nth 3 q) 0.0)
                       (list 13 (nth 2 q) (nth 3 q) 0.0)))
      (setq *hle-frame-objs* (cons (vlax-ename->vla-object (entlast)) *hle-frame-objs*)))))

(defun hle:only-on (name / u)
  (setq u (strcase name))
  (vlax-for l *hle-layers*
    (vl-catch-all-apply 'vla-put-LayerOn
      (list l (if (= (strcase (vla-get-Name l)) u) :vlax-true :vlax-false)))))

(defun hle:plot-to (fname / r)
  (if (findfile fname) (vl-file-delete fname))
  (setq r (vl-catch-all-apply 'vla-PlotToFile (list *hle-plot* fname)))
  (and (not (vl-catch-all-error-p r)) (findfile fname)))

;;; ---------------------------------------------------------------------
;;; 내보내기 본체
;;; settings: (("target" . "ai") ("scale" . 100.0) ("unit_mm" . 1.0)
;;;            ("dpi" . 300) ("layers" (이름 r g b 선가중치) ...))
;;; 결과: (완료목록 실패목록 frame경로 setup)
;;; ---------------------------------------------------------------------
(defun hle:export (box ss settings jobdir / scale unit-mm layers lo setup frame i n lay fname done failed)
  (setq scale   (float (hle:opt "scale" settings))
        unit-mm (float (hle:opt "unit_mm" settings))
        layers  (hle:opt "layers" settings)
        n       (length layers))
  (hle:setvar "BACKGROUNDPLOT" 0)
  (hle:setvar "FILLMODE" 1)
  (vla-StartUndoMark *hle-doc*)
  (setq *hle-undo-open* t)
  (vla-put-QuietErrorMode *hle-plot* :vlax-true)

  (setq *hle-lay-state* (hle:layers-save))
  (vlax-for l *hle-layers* (hle:try 'vla-put-Lock l '(:vlax-false)))

  (princ "\n선가중치를 정리하는 중...")
  (hle:lw-ss ss)

  (setq lo (vla-get-ActiveLayout *hle-doc*)
        *hle-layout* lo
        *hle-pc-state* (hle:pc-save lo)
        setup (hle:setup-plot lo box unit-mm scale))

  (hle:make-frame box)
  (hle:only-on hle:FRAME-LAYER)
  (setq frame (strcat jobdir "\\frame.pdf"))
  (princ "\n기준 프레임을 출력하는 중...")
  (if (not (hle:plot-to frame))
    (progn (alert "기준 프레임 PDF 출력에 실패했습니다.\nDWG To PDF.pc3 가 있는지 확인하세요.")
           (exit)))

  (setq i 0)
  (foreach L layers
    (setq i (1+ i)
          lay (vl-catch-all-apply 'vla-item (list *hle-layers* (car L))))
    (princ (strcat "\n  (" (itoa i) "/" (itoa n) ") " (car L)))
    (if (vl-catch-all-error-p lay)
      (setq failed (cons (car L) failed))
      (progn
        (hle:try 'vla-put-Lineweight lay (list (nth 4 L)))
        (hle:try 'vla-put-Plottable lay '(:vlax-true))
        (hle:only-on (car L))
        (setq fname (strcat jobdir "\\L" (if (< i 10) "0" "") (itoa i) ".pdf"))
        (if (hle:plot-to fname)
          (setq done (cons (list (car L) fname (list (nth 1 L) (nth 2 L) (nth 3 L)) (nth 4 L)) done))
          (setq failed (cons (car L) failed))))))
  (list (reverse done) (reverse failed) frame setup))

;;; ---------------------------------------------------------------------
;;; JSON 쓰기
;;; ---------------------------------------------------------------------
(defun hle:write-job (path jobdir dwg box layers scale target / f n i)
  (setq f (hle:open path "w") n (length layers) i 0)
  (write-line "{" f)
  (write-line "  \"version\": 1," f)
  (write-line (strcat "  \"lisp_version\": " (hle:jstr *hle-version*) ",") f)
  (write-line (strcat "  \"dwg\": " (hle:jstr (hle:slash dwg)) ",") f)
  (write-line (strcat "  \"job_dir\": " (hle:jstr (hle:slash jobdir)) ",") f)
  (write-line (strcat "  \"insunits\": " (itoa (getvar "INSUNITS")) ",") f)
  (write-line (strcat "  \"window\": [" (hle:jnum (nth 0 box)) ", " (hle:jnum (nth 1 box)) ", "
                      (hle:jnum (nth 2 box)) ", " (hle:jnum (nth 3 box)) "],") f)
  (if scale (write-line (strcat "  \"scale\": " (hle:jnum scale) ",") f))   ; hy CAD 도곽을 고르면 그 축척 (설정 창 기본값)
  (if target (write-line (strcat "  \"target\": " (hle:jstr target) ",") f))   ; 내보내기 창에서 고른 보낼 곳 (설정 창이 먼저 고름)
  (write-line "  \"layers\": [" f)
  (foreach L layers
    (setq i (1+ i))
    (write-line (strcat "    {\"name\": " (hle:jstr (car L))
                        ", \"count\": " (itoa (cadr L))
                        ", \"lw\": " (itoa (caddr L)) "}"
                        (if (< i n) "," "")) f))
  (write-line "  ]" f)
  (write-line "}" f)
  (close f)
  path)

(defun hle:write-result (path jobdir dwg settings res / f done failed setup n i)
  (setq done (nth 0 res) failed (nth 1 res) setup (nth 3 res)
        f (hle:open path "w") n (length done) i 0)
  (write-line "{" f)
  (write-line "  \"version\": 1," f)
  (write-line (strcat "  \"dwg\": " (hle:jstr (hle:slash dwg)) ",") f)
  (write-line (strcat "  \"job_dir\": " (hle:jstr (hle:slash jobdir)) ",") f)
  (write-line (strcat "  \"target\": " (hle:jstr (hle:opt "target" settings)) ",") f)
  (write-line (strcat "  \"dpi\": " (hle:jnum (hle:opt "dpi" settings)) ",") f)
  (write-line (strcat "  \"mono\": " (if (nth 1 setup) "true" "false") ",") f)
  (write-line (strcat "  \"media\": " (hle:jstr (nth 0 setup)) ",") f)
  (write-line (strcat "  \"paper_mm\": [" (hle:jnum (nth 2 setup)) ", " (hle:jnum (nth 3 setup)) "],") f)
  (write-line (strcat "  \"frame\": " (hle:jstr (hle:slash (nth 2 res))) ",") f)
  (write-line "  \"layers\": [" f)
  (foreach L done
    (setq i (1+ i))
    (write-line (strcat "    {\"name\": " (hle:jstr (nth 0 L))
                        ", \"pdf\": " (hle:jstr (hle:slash (nth 1 L)))
                        ", \"color\": [" (itoa (nth 0 (nth 2 L))) ", " (itoa (nth 1 (nth 2 L))) ", " (itoa (nth 2 (nth 2 L))) "]"
                        ", \"lw\": " (itoa (nth 3 L)) "}"
                        (if (< i n) "," "")) f))
  (write-line "  ]," f)
  (write-line (strcat "  \"failed\": ["
                      (if failed
                        (substr (apply 'strcat (mapcar (function (lambda (x) (strcat ", " (hle:jstr x)))) failed)) 3)
                        "")
                      "]") f)
  (write-line "}" f)
  (close f)
  path)

;;; ---------------------------------------------------------------------
;;; 외부 프로그램
;;; ---------------------------------------------------------------------
(defun hle:cmd-for (p)
  (if (wcmatch (strcase p) "*.PYW,*.PY")
    (strcat "pythonw.exe \"" p "\"")
    (strcat "\"" p "\"")))

;; 찾는 순서: 직접 지정 → 허브 설치 자리 → 지원 파일 검색 경로 → 손으로 둔 자리 → 개발용 pyw
(defun hle:launcher ( / p la)
  (setq la (getenv "LOCALAPPDATA"))
  (cond
    ((and (= (type *hle-exe*) 'STR) (setq p (findfile *hle-exe*))) (hle:cmd-for p))
    ((and la (setq p (findfile (strcat la "\\Programs\\hy\\hy-layer-export\\hy_layer_export.exe"))))
     (hle:cmd-for p))
    ((setq p (findfile "hy_layer_export.exe")) (hle:cmd-for p))
    ((and la (setq p (findfile (strcat la "\\hy\\layer_export\\hy_layer_export.exe"))))
     (hle:cmd-for p))
    ((setq p (findfile "hle_app.pyw")) (hle:cmd-for p))))

;; wait 가 t 면 창이 닫힐 때까지 기다리고 종료 코드를 돌려준다
(defun hle:run (cmd wait / ws rc)
  (setq ws (vlax-create-object "WScript.Shell"))
  (setq rc (vl-catch-all-apply 'vlax-invoke-method
             (list ws 'Run cmd 1 (if wait :vlax-true :vlax-false))))
  (vlax-release-object ws)
  (cond ((vl-catch-all-error-p rc) -1)
        ((= (type rc) 'VARIANT) (vlax-variant-value rc))
        (t rc)))

;; tag 가 있으면 끝에 붙임 — 내보내기 창이 같은 초에 여러 도곽을 내보내도 폴더가 겹치지 않게
(defun hle:job-dir (tag / tmp)
  (setq tmp (getenv "TEMP"))
  (if (not tmp) (setq tmp (getvar "TEMPPREFIX")))
  (if (= (substr tmp (strlen tmp)) "\\") (setq tmp (substr tmp 1 (1- (strlen tmp)))))
  (hle:mkdirs (strcat tmp "\\hy_layer_export\\"
                      (vl-string-translate "." "_" (rtos (getvar "CDATE") 2 6))
                      (if tag (strcat "_" tag) ""))))

;;; ---------------------------------------------------------------------
;;; 영역 고르기
;;; ---------------------------------------------------------------------
;; HY_TB_<용지>(_P) → 그 방향의 종이 (가로 세로 mm), 도곽이 아니면 nil
(defun hle:hy-paper (name / u p)
  (setq u (strcase name))
  (if (and (wcmatch u "HY_TB_A#,HY_TB_A#_P")
           (setq p (cdr (assoc (substr u 7 2) '(("A4" 297.0 210.0) ("A3" 420.0 297.0) ("A2" 594.0 420.0) ("A1" 841.0 594.0))))))
    (if (wcmatch u "*_P") (list (cadr p) (car p)) p)))

;; 도곽 블록 → ((x1 y1 x2 y2) 축척) — hy CAD 도곽(돌리지 않은 것)은 종이 끝 범위와 블록 축척, 다른 블록은 경계 상자(축척 nil). 블록이 아니면 nil.
(defun hle:frame-of (en / o p sx rot ins a b)
  (if (and en (= (cdr (assoc 0 (entget en))) "INSERT"))
    (progn
     (setq o   (vlax-ename->vla-object en)
           p   (hle:hy-paper (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))
           sx  (vla-get-XScaleFactor o)
           rot (vla-get-Rotation o))
     (if (and p (> sx 0.0) (or (equal rot 0.0 1e-6) (equal rot (* 2 pi) 1e-6)))
       (progn
         (setq ins (vlax-get o 'InsertionPoint))
         (list (list (car ins) (cadr ins) (+ (car ins) (* (car p) sx)) (+ (cadr ins) (* (cadr p) sx))) sx))
       (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
         (progn
           (setq a (vlax-safearray->list a) b (vlax-safearray->list b))
           (list (list (car a) (cadr a) (car b) (cadr b)) nil)))))))

;; 도곽 블록 클릭 → hle:frame-of
(defun hle:pick-frame ( / sel)
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n도곽 블록을 클릭하세요: "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n도곽을 고르지 않았습니다.") nil)
    ((/= (cdr (assoc 0 (entget (car sel)))) "INSERT") (princ "\n[주의] 도곽은 블록이어야 합니다.") nil)
    (t (hle:frame-of (car sel)))))

;; 영역에 걸친 객체 — 화면 밖이어도 잡히게 잠시 그 영역으로 화면을 옮겨 고른 뒤 되돌린다
(defun hle:select (box / m ss)
  (setq m (* 0.02 (max (- (nth 2 box) (nth 0 box)) (- (nth 3 box) (nth 1 box)))))
  (command "_.ZOOM" "_W" "_non" (trans (list (- (nth 0 box) m) (- (nth 1 box) m) 0.0) 0 1)
                         "_non" (trans (list (+ (nth 2 box) m) (+ (nth 3 box) m) 0.0) 0 1))
  (setq ss (ssget "_C" (trans (list (nth 0 box) (nth 1 box) 0.0) 0 1) (trans (list (nth 2 box) (nth 3 box) 0.0) 0 1)))
  (command "_.ZOOM" "_P")
  ss)

;; 평면 보기인지. 아니면 평면(PLAN 표준)으로 바꿀지 묻는다 (플롯 창은 화면 좌표라서)
(defun hle:plan-ok ( / k)
  (cond
    ((and (equal (trans '(1.0 0.0 0.0) 0 2 t) '(1.0 0.0 0.0) 1e-8)
          (equal (trans '(0.0 0.0 1.0) 0 2 t) '(0.0 0.0 1.0) 1e-8)) t)
    (t
     (initget "Yes No")
     (setq k (getkword "\n[주의] 화면이 평면 보기가 아닙니다 (시점·화면 회전). 평면 보기(PLAN 표준)로 바꿀까요? [예(Y)/아니오(N)] <Y>: "))
     (if (/= k "No") (progn (command "_.PLAN" "_W") t)))))

;;; ---------------------------------------------------------------------
;;; 명령
;;; ---------------------------------------------------------------------
;; 명령마다 처음에 — 문서 · 레이어 · 플롯 객체, 명령줄 조용히
(defun hle:begin ()
  (setq *hle-doc*    (vla-get-ActiveDocument (vlax-get-acad-object))
        *hle-layers* (vla-get-Layers *hle-doc*)
        *hle-plot*   (vla-get-Plot *hle-doc*)
        *hle-layout* nil)
  (hle:setvar "CMDECHO" 0)
  (hle:setvar "DIMZIN" 0))

;; 영역 하나 내보내기 — 설정 창(닫힐 때까지 기다림) → 레이어별 PDF → 조립.
;; target("ai" · "ps")이 있으면 설정 창이 그것을 먼저 고른다, tag 는 작업 폴더 이름 끝에. 넘겼으면 t.
(defun hle:export-box (launcher box scale target tag / ss layers jobdir dwg job rc settings res result)
  (cond
    ((or (equal (nth 0 box) (nth 2 box) 1e-9) (equal (nth 1 box) (nth 3 box) 1e-9))
     (princ "\n[주의] 영역 크기가 0 입니다.") nil)
    ((not (setq ss (hle:select box)))
     (princ "\n[주의] 영역 안에 객체가 없습니다.") nil)
    (t
     (princ "\n레이어를 확인하는 중...")
     (cond
       ((null (setq layers (hle:collect ss)))
        (princ "\n[주의] 내보낼 수 있는 레이어가 없습니다 (꺼진 · 동결 · Defpoints 레이어는 빠짐).") nil)
       (t
        (setq jobdir (hle:job-dir tag)
              dwg    (strcat (getvar "DWGPREFIX") (getvar "DWGNAME"))
              job    (hle:write-job (strcat jobdir "\\job.json") jobdir dwg box layers scale target))
        (princ (strcat "\n[알림] 레이어 " (itoa (length layers)) "개. 설정 창이 닫힐 때까지 캐드는 기다립니다."))
        (setq rc (hle:run (strcat launcher " --job \"" job "\"") t))
        (cond
          ((= rc 2) (princ "\n취소했습니다.") nil)
          ((/= rc 0) (princ (strcat "\n[오류] 설정 창이 비정상으로 끝났습니다 (코드 " (vl-princ-to-string rc) ").")) nil)
          ((not (setq settings (hle:read-settings (strcat jobdir "\\settings.lsp"))))
           (princ "\n[오류] 설정 파일을 읽지 못했습니다.") nil)
          (t
           (setq res (hle:export box ss settings jobdir))
           (setq result (hle:write-result (strcat jobdir "\\result.json") jobdir dwg settings res))
           (hle:cleanup)
           (if (car res)
             (progn
               (princ (strcat "\n[완료] PDF " (itoa (length (car res))) "장을 출력했습니다. "
                              (if (= (hle:opt "target" settings) "ps") "포토샵으로" "일러스트레이터로")
                              " 넘기는 중입니다."))
               (hle:run (strcat launcher " --assemble \"" result "\"") nil)
               t)
             (progn (princ "\n[주의] 출력된 레이어가 없습니다.") nil)))))))))

(defun hle:no-launcher ()
  (alert (strcat "설정 창 프로그램 hy Layer Export 를 찾지 못했습니다.\n\n"
                 "hy 허브에서 hy Layer Export 를 설치하세요.\n"
                 "(다른 곳에 두었다면 (setq *hle-exe* \"경로\\\\hy_layer_export.exe\") 로 지정)")))

(defun c:HLE ( / *error* launcher p1 p2 fr w1 w2 box scale)
  (defun *error* (msg)
    (hle:cleanup)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (hle:begin)
  (cond
    ((/= (getvar "TILEMODE") 1)
     (princ "\n[주의] 모형 탭에서 실행하세요."))
    ((not (setq launcher (hle:launcher)))
     (hle:no-launcher))
    ((not (hle:plan-ok))
     (princ "\n평면 보기가 아니어서 그만두었습니다."))
    ((progn (initget "Frame")
            (null (setq p1 (getpoint "\n내보낼 영역의 첫 번째 구석을 지정하세요 [도곽 고르기(F)]: ")))))
    ((and (= (type p1) 'STR) (null (setq fr (hle:pick-frame)))))
    ((and (null fr) (null (setq p2 (getcorner p1 "\n반대쪽 구석을 지정하세요: ")))))
    (t
     (if fr
       (setq box (car fr) scale (cadr fr))
       (setq w1  (trans p1 1 0)
             w2  (trans p2 1 0)
             box (list (min (car w1) (car w2)) (min (cadr w1) (cadr w2))
                       (max (car w1) (car w2)) (max (cadr w1) (cadr w2)))))
     (hle:export-box launcher box scale nil nil)))
  (hle:cleanup)
  (princ))

;; YGN CAD 내보내기 창 (1.23.0~) — 묻지 않고 도곽 · 영역마다 내보낸다 (도곽마다 설정 창이 열림).
;; (hle:run-preset '("ai" "1A" "1B" (x1 y1 x2 y2))) — 첫 칸은 보낼 곳("ai" · "ps"),
;; 글 = 도곽 블록 핸들(YGN 도곽이면 종이 끝 범위 · 축척), 숫자 넷 = 영역 상자(WCS).
(defun hle:run-preset (lst / *error* launcher target items en fr n i ok)
  (defun *error* (msg)
    (hle:cleanup)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (setq target (car lst) items (cdr lst) n (length items) i 0 ok 0)
  (hle:begin)
  (cond
    ((null items) (princ "\n[주의] 내보낼 도곽이 없습니다."))
    ((not (setq launcher (hle:launcher))) (hle:no-launcher))
    (t
     (if (/= (getvar "TILEMODE") 1)
       (progn (setvar "TILEMODE" 1) (princ "\n[알림] 모형 탭으로 옮겼습니다.")))
     (if (not (hle:plan-ok))
       (princ "\n평면 보기가 아니어서 그만두었습니다.")
       (progn
         (foreach it items
           (setq i (1+ i) fr nil)
           (cond
             ((= (type it) 'STR)
              (if (not (and (setq en (handent it)) (setq fr (hle:frame-of en))))
                (princ (strcat "\n[주의] 도곽(" it ")을 찾지 못했습니다."))))
             ((and (listp it) (= (length it) 4) (vl-every 'numberp it))
              (setq fr (list (mapcar 'float it) nil))))
           (if fr
             (progn
               (hle:begin)
               (princ (strcat "\n[알림] " (itoa i) "/" (itoa n) " 내보내는 중..."))
               (if (hle:export-box launcher (car fr) (cadr fr) target (itoa i)) (setq ok (1+ ok)))
               (hle:cleanup))))
         (princ (strcat "\n[완료] " (itoa ok) "/" (itoa n) "개를 "
                        (if (= target "ps") "포토샵으로" "일러스트레이터로") " 넘겼습니다."))))))
  (hle:cleanup)
  (princ))

(defun hle:read-settings (path / s)
  (if (setq s (hle:read-file path)) (read s)))

(princ)
