(defun c:CW ( / ss max_len active_lines i ent ed p1 p2 pt1_str pt2_str len 
                 all_pts pt_counts deleted_this_round c1 c2 k_val candidates target_ent total_deleted count curr_pt)
  (vl-load-com)
  (prompt "\n정리할 벽체 선들을 선택하세요 (반드시 BXI 등으로 교차점이 끊어져 있어야 합니다): ")
  (setq ss (ssget '((0 . "LINE"))))
  
  (if ss
    (progn
      (setq max_len (getdist "\n지울 벽 교차부 안쪽 선의 최대 길이 (클릭 또는 입력) <300>: "))
      (if (not max_len) (setq max_len 300.0)) 

      (princ "\n교차부 분석 중 (우선순위 K: 5 -> 6 이상 -> 4)... 잠시 기다려 주세요.")
      (setq total_deleted 0)

      (setq active_lines nil)
      (setq i 0)
      (while (< i (sslength ss))
        (setq active_lines (cons (ssname ss i) active_lines))
        (setq i (1+ i))
      )

      (setq deleted_this_round T)
      
      (while deleted_this_round
        (setq deleted_this_round nil)
        (setq pt_counts nil)
        (setq all_pts nil)

        ;; 1. 모든 끝점 수집 및 카운트
        (foreach ent active_lines
          (setq ed (entget ent))
          (setq p1 (cdr (assoc 10 ed)))
          (setq p2 (cdr (assoc 11 ed)))
          (setq pt1_str (strcat (rtos (car p1) 2 2) "," (rtos (cadr p1) 2 2)))
          (setq pt2_str (strcat (rtos (car p2) 2 2) "," (rtos (cadr p2) 2 2)))
          (setq all_pts (cons pt1_str all_pts))
          (setq all_pts (cons pt2_str all_pts))
        )

        (if all_pts
          (progn
            (setq all_pts (vl-sort all_pts '<))
            (setq count 1)
            (setq curr_pt (car all_pts))
            (foreach pt (cdr all_pts)
              (if (= pt curr_pt)
                (setq count (1+ count))
                (progn
                  (setq pt_counts (cons (cons curr_pt count) pt_counts))
                  (setq curr_pt pt)
                  (setq count 1)
                )
              )
            )
            (setq pt_counts (cons (cons curr_pt count) pt_counts))
          )
        )

        ;; 2. 각 선분의 K값(자기 자신 제외 교차선 수) 계산
        (setq candidates nil)
        (foreach ent active_lines
          (setq ed (entget ent))
          (setq p1 (cdr (assoc 10 ed)))
          (setq p2 (cdr (assoc 11 ed)))
          (setq len (distance p1 p2))
          
          (if (<= len max_len)
            (progn
              (setq pt1_str (strcat (rtos (car p1) 2 2) "," (rtos (cadr p1) 2 2)))
              (setq pt2_str (strcat (rtos (car p2) 2 2) "," (rtos (cadr p2) 2 2)))
              (setq c1 (cdr (assoc pt1_str pt_counts)))
              (setq c2 (cdr (assoc pt2_str pt_counts)))
              
              ;; K = C1 + C2 - 2 (두 끝점의 선 수 합에서 자기 자신 둘을 뺌)
              (setq k_val (- (+ c1 c2) 2))
              (setq candidates (cons (list ent k_val) candidates))
            )
          )
        )

        ;; 3. 지울 순서(우선순위) 적용
        (setq target_ent nil)
        
        ;; 1순위: K=5 (비대칭 연결선을 먼저 지워 T자 벽 보호)
        (foreach item candidates
          (if (and (not target_ent) (= (cadr item) 5))
            (setq target_ent (car item))
          )
        )
        
        ;; 2순위: K>=6 (K=5를 다 지운 뒤 십자 교차부 가운데 선)
        (if (not target_ent)
          (foreach item candidates
            (if (and (not target_ent) (>= (cadr item) 6))
              (setq target_ent (car item))
            )
          )
        )
        
        ;; 3순위: K=4 (마지막으로 남은 잔선 정리)
        (if (not target_ent)
          (foreach item candidates
            (if (and (not target_ent) (= (cadr item) 4))
              (setq target_ent (car item))
            )
          )
        )

        ;; 4. 대상 삭제 후 다시 계산 (반복)
        (if target_ent
          (progn
            (entdel target_ent)
            (setq active_lines (vl-remove target_ent active_lines))
            (setq total_deleted (1+ total_deleted))
            (setq deleted_this_round T)
          )
        )
      )
      
      (princ (strcat "\n[완료] 총 " (itoa total_deleted) "개의 안쪽 선분을 정리했습니다."))
    )
    (princ "\n선택된 객체가 없습니다.")
  )
  (princ)
)