;;; ==============================================================================
;;;  CW — 벽이 만나는 곳 안쪽의 짧은 선(십자·T자·사선) 지우기
;;;
;;;  교차점에서 끊어 둔(BXI 등) 벽선을 고르면, 최대 길이(기억) 이하의 선 중 양 끝에 모인 선 수로 교차부 안쪽 선을 찾아 지운다.
;;;  순서는 예전 그대로: 한쪽만 이어진 연결선(K=5) → 십자 가운데(K≥6) → 남은 T자 안쪽(K=4).
;;;   · T자 두 개가 최대 길이보다 가까우면 안쪽 선과 그 사이 진짜 벽면이 구별되지 않는다 (예전: 먼저 나온 것을 지워
;;;     벽면이 사라질 수 있었음) — 그런 선은 지우지 않고 끝에 골라 두니 직접 보고 지우면 된다.
;;;   · 잠긴 레이어는 빠진다. 끝점 수는 처음에 한 번 세고 지울 때마다 그 두 끝만 고친다 (평면 전체도 빠름).
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 점 → 기호 이름 (소수 둘째 자리, -0.00 = 0.00)
(defun cw:key (p / f)
  (defun f (v) (if (< (abs v) 0.005) "0.00" (rtos v 2 2)))
  (read (strcat "CW_" (vl-string-translate ",.-" "_DM" (strcat (f (car p)) "," (f (cadr p)))))))

(defun cw:cnt (k) (cond ((vl-symbol-value k)) (0)))

(defun c:CW ( / *error* doc undo_open mx ss i e ed a b keys cands k4 hit target level n amb out sym)
  (defun *error* (msg)
    (foreach s keys (set s nil))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n정리할 벽선을 고르세요 (교차점에서 끊어 두어야 함 · 잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L" '((0 . "LINE")))))
    (princ "\n고른 선이 없습니다.")
    (progn
      (setq mx (if (getenv "HyCwMax") (atof (getenv "HyCwMax")) 300.0))
      (initget 6)
      (setq mx (cond ((getdist (strcat "\n지울 안쪽 선의 최대 길이 <" (rtos mx 2 2) ">: "))) (mx)))
      (setenv "HyCwMax" (rtos mx 2 8))
      ;; 끝점마다 모인 선 수 (기호에 담음) · 짧은 선 후보 (ename 끝A 끝B)
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) ed (entget e) a (cw:key (cdr (assoc 10 ed))) b (cw:key (cdr (assoc 11 ed))))
        (foreach s (list a b)
          (if (not (member s keys)) (setq keys (cons s keys)))
          (set s (1+ (cw:cnt s))))
        (if (<= (distance (cdr (assoc 10 ed)) (cdr (assoc 11 ed))) mx) (setq cands (cons (list e a b) cands)))
        (setq i (1+ i)))
      (vla-StartUndoMark doc)
      (setq undo_open T n 0)
      (while (progn
               (setq target nil amb nil)
               ;; K = 두 끝의 선 수 합 − 2
               (foreach level '(5 6 4)
                 (if (not target)
                   (progn
                     (setq hit (vl-remove-if-not
                                 '(lambda (c / kk) (setq kk (- (+ (cw:cnt (cadr c)) (cw:cnt (caddr c))) 2))
                                    (if (= level 6) (>= kk 6) (= kk level)))
                                 cands))
                     (if (= level 4)
                       ;; K=4 끼리 끝점을 같이 쓰면 안쪽 선인지 벽면인지 모름 → 지우지 않고 남김
                       (progn
                         (setq k4 (apply 'append (mapcar '(lambda (c) (list (cadr c) (caddr c))) hit)))
                         (foreach c hit
                           (if (and (not target)
                                    (= 1 (length (vl-remove-if-not '(lambda (s) (eq s (cadr c))) k4)))
                                    (= 1 (length (vl-remove-if-not '(lambda (s) (eq s (caddr c))) k4))))
                             (setq target c)))
                         (if (not target) (setq amb hit)))
                       (setq target (car hit))))))
               target)
        (entdel (car target))
        (set (cadr target) (1- (cw:cnt (cadr target))))
        (set (caddr target) (1- (cw:cnt (caddr target))))
        (setq cands (vl-remove target cands) n (1+ n)))
      (foreach s keys (set s nil))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 교차부 안쪽 선 " (itoa n) "개를 지웠습니다."))
      (if amb
        (progn
          (setq out (ssadd))
          (foreach c amb (ssadd (car c) out))
          (sssetfirst nil out)
          (princ (strcat "\n[주의] 안쪽 선인지 벽면인지 구별되지 않는 선 " (itoa (length amb)) "개는 남겨 두고 골라 두었습니다. 직접 보고 지우세요."))))))
  (princ))

(princ)
