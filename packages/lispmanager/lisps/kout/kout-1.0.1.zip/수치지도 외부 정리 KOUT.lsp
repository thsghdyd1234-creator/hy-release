(defun c:KOUT (/ ent vla-ent minpt maxpt pt-max pt-min dist off-dist pt-list ss-all ss-in i obj-name 
               off1 off2 area1 area2 orig-area target-off ent-off fence-pts 
               old-trim old-edge old-osmode)
  (vl-load-com)
  
  ;; 1. 경계가 될 닫힌 폴리선 선택
  (setq ent (car (entsel "\n남길 영역의 닫힌 폴리선(사각형)을 선택하세요: ")))
  
  (if ent
    (progn
      (princ "\n경계 밖 객체를 정리하는 중... (Z값 유지)")
      
      ;; 사각형 영역으로 화면 확대 (TRIM이 화면 밖 객체를 못 잡는 문제 방지)
      (command "_.ZOOM" "Object" ent "")
      
      (setq vla-ent (vlax-ename->vla-object ent))
      (setq pt-list (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) (entget ent))))
      
      ;; === [1단계: 완전히 밖에 있는 객체 삭제] ===
      (setq ss-all (ssget "X" (list (cons 410 (getvar "CTAB"))))) 
      (setq ss-in (ssget "CP" pt-list))
      (if (and ss-all ss-in)
        (progn
          (setq i 0)
          (while (< i (sslength ss-in))
            (setq obj-name (ssname ss-in i))
            (ssdel obj-name ss-all) ; 걸친 객체 제외
            (setq i (1+ i))
          )
          (if (> (sslength ss-all) 0)
            (command "_.ERASE" ss-all "") ; 바로 삭제
          )
        )
      )
      
      ;; === [2단계: 바깥 자르기용 임시 경계(Offset) 생성] ===
      (vla-getboundingbox vla-ent 'minpt 'maxpt)
      (setq dist (distance (vlax-safearray->list minpt) (vlax-safearray->list maxpt)))
      (setq off-dist (/ dist 1000.0)) ; 도면 스케일에 비례하는 아주 미세한 간격
      
      ;; 안쪽, 바깥쪽 양방향으로 간격을 띄워보고 면적이 더 큰(바깥쪽) 선을 찾음
      (setq off1 (vl-catch-all-apply 'vlax-invoke (list vla-ent 'Offset off-dist)))
      (setq off2 (vl-catch-all-apply 'vlax-invoke (list vla-ent 'Offset (- off-dist))))
      
      (defun get-area (vla-obj)
        (if (and (listp vla-obj) (car vla-obj) (not (vl-catch-all-error-p vla-obj)))
           (vla-get-Area (car vla-obj)) 0.0))
      
      (setq area1 (get-area off1))
      (setq area2 (get-area off2))
      (setq orig-area (vla-get-Area vla-ent))
      
      (setq target-off nil)
      (if (> area1 orig-area) (setq target-off (car off1))
        (if (> area2 orig-area) (setq target-off (car off2))))
      
      ;; 쓰지 않는 간격띄우기 선은 삭제
      (if (and (listp off1) (car off1) (not (equal (car off1) target-off))) (vla-Delete (car off1)))
      (if (and (listp off2) (car off2) (not (equal (car off2) target-off))) (vla-Delete (car off2)))
      
      ;; === [3단계: TRIM 명령 + FENCE(울타리) 자르기] ===
      (if target-off
        (progn
          (setq ent-off (vlax-vla-object->ename target-off))
          (setq fence-pts (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) (entget ent-off))))
          (setq fence-pts (append fence-pts (list (car fence-pts)))) ; 울타리를 닫힌 루프로 만들기
          
          ;; 시스템 변수 저장 및 설정
          (setq old-osmode (getvar "OSMODE"))
          (setq old-edge (getvar "EDGEMODE"))
          (setvar "OSMODE" 0) ; 객체 스냅 끄기 (울타리가 다른 점에 붙지 않게)
          (setvar "EDGEMODE" 0)
          
          (setq old-trim (vl-catch-all-apply 'getvar (list "TRIMEXTENDMODE")))
          (if (not (vl-catch-all-error-p old-trim))
            (vl-catch-all-apply 'setvar (list "TRIMEXTENDMODE" 0)) ; 최신 캐드 빠른 자르기 모드 끄기
          )
          
          ;; 캐드 기본 TRIM 실행 -> 자르기 기준선(사각형) 선택 -> F(울타리) 모드 -> 포인트 연속 클릭
          (command "_.TRIM" ent "")
          (command "F")
          (foreach pt fence-pts (command pt))
          (command "" "")
          
          ;; 임시 경계 삭제, 변수·화면 복구
          (vla-Delete target-off)
          (setvar "OSMODE" old-osmode)
          (setvar "EDGEMODE" old-edge)
          (if (not (vl-catch-all-error-p old-trim)) (vl-catch-all-apply 'setvar (list "TRIMEXTENDMODE" old-trim)))
          
          (command "_.ZOOM" "Previous")
          (princ "\n[완료] 경계 밖 객체를 삭제하고 걸친 선을 잘랐습니다. (Z값 유지)")
        )
        (princ "\n외곽선 인식 오류로 자르기를 생략했습니다. 사각형이 꼬여있지 않은지 확인해주세요.")
      )
    )
    (princ "\n객체가 선택되지 않았습니다.")
  )
  (princ)
)