;;; ==============================================================================
;;;  KOUT — 경계 밖 정리 (수치지도 · 큰 도면에서 필요한 영역만 남기기)
;;;
;;;  닫힌 경계(폴리선 · 원 · 타원)를 고르면 모형 공간에서
;;;   1) 경계 밖에 있는 객체를 지운다
;;;      · 화면에 보이는 객체: 경계 둘레(호는 잘게 나눔)로 걸침 선택 → 안·걸친 것만 남김
;;;      · 꺼진·동결 레이어, 숨긴 객체: 객체 범위가 경계와 완전히 떨어져 있을 때만 지움 (경계 안이면 그대로)
;;;   2) 경계에 걸친 선은 경계에서 잘라 바깥 부분을 없앤다 (TRIM 표준 모드 · 투영 PROJMODE 1 — 높이(Z)는 그대로)
;;;  걸친 블록·문자·해치는 자르지 않고 그대로 둔다. 잠긴 레이어는 건드리지 않는다.
;;;  지우기 전에 개수를 보여 주고 묻는다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 점이 다각형(WCS 점 목록) 안에 있는지 — 반직선 세기 (XY 평면)
(defun kout:inside-p (p poly / c n i a b)
  (setq c nil n (length poly) i 0)
  (while (< i n)
    (setq a (nth i poly) b (nth (rem (1+ i) n) poly))
    (if (and (/= (> (cadr a) (cadr p)) (> (cadr b) (cadr p)))
             (< (car p) (+ (car a) (/ (* (- (cadr p) (cadr a)) (- (car b) (car a))) (- (cadr b) (cadr a))))))
      (setq c (not c)))
    (setq i (1+ i)))
  c)

;; 두 선분이 만나는지 (XY)
(defun kout:seg-hit-p (p1 p2 p3 p4)
  (inters (list (car p1) (cadr p1)) (list (car p2) (cadr p2)) (list (car p3) (cadr p3)) (list (car p4) (cadr p4)) T))

;; 상자 (lo hi) 가 다각형과 완전히 떨어져 있는지
(defun kout:apart-p (lo hi poly / box n i hit)
  (setq box (list (list (car lo) (cadr lo)) (list (car hi) (cadr lo)) (list (car hi) (cadr hi)) (list (car lo) (cadr hi))))
  (cond
    ((vl-some '(lambda (q) (kout:inside-p q poly)) box) nil)
    ((vl-some '(lambda (q) (and (<= (car lo) (car q) (car hi)) (<= (cadr lo) (cadr q) (cadr hi)))) poly) nil)
    (T
     (setq n (length poly) i 0)
     (while (and (< i n) (not hit))
       (foreach k '(0 1 2 3)
         (if (kout:seg-hit-p (nth i poly) (nth (rem (1+ i) n) poly) (nth k box) (nth (rem (1+ k) 4) box)) (setq hit T)))
       (setq i (1+ i)))
     (not hit))))

;; 닫힌 곡선을 점 목록으로 (호 구간은 잘게) — WCS
(defun kout:flatten (obj / typ n i b k pts par)
  (setq typ (vla-get-ObjectName obj))
  (cond
    ((= typ "AcDbPolyline")
     (setq n (fix (+ 0.5 (vlax-curve-getEndParam obj))) i 0)
     (while (< i n)
       (setq b (vla-GetBulge obj i))
       (setq k (if (equal b 0.0 1e-12) 1 (max 4 (fix (* 16 (abs (atan b)))))))
       (setq par 0)
       (while (< par k)
         (setq pts (cons (vlax-curve-getPointAtParam obj (+ i (/ (float par) k))) pts) par (1+ par)))
       (setq i (1+ i))))
    (T
     (setq i 0)
     (while (< i 128)
       (setq pts (cons (vlax-curve-getPointAtParam obj (* (vlax-curve-getEndParam obj) (/ i 128.0))) pts) i (1+ i)))))
  (reverse pts))

(defun kout:closed-p (obj / typ)
  (setq typ (vla-get-ObjectName obj))
  (cond
    ((= typ "AcDbCircle") T)
    ((member typ '("AcDbPolyline" "AcDbEllipse" "AcDbSpline"))
     (or (vlax-curve-isClosed obj)
         (< (distance (vlax-curve-getStartPoint obj) (vlax-curve-getEndPoint obj)) 1e-6)))))

(defun kout:ss-list (ss / i out)
  (setq i 0)
  (if ss (while (< i (sslength ss)) (setq out (cons (ssname ss i) out) i (1+ i))))
  out)

;; 숨은 객체인지 (꺼진·동결 레이어 또는 숨김)
(defun kout:hidden-p (ed / r)
  (setq r (tblsearch "LAYER" (cdr (assoc 8 ed))))
  (or (= (cdr (assoc 60 ed)) 1)
      (and r (or (minusp (cdr (assoc 62 r))) (= 1 (logand 1 (cdr (assoc 70 r))))))))

(defun kout:locked-p (ed / r)
  (setq r (tblsearch "LAYER" (cdr (assoc 8 ed))))
  (and r (= 4 (logand 4 (cdr (assoc 70 r))))))

(defun c:KOUT ( / *error* doc sv undo_open zoomed sel ent obj poly upoly lo hi d off o1 o2 a1 a2 target fence
                  ss_in all in_set gone keep_hidden locked ans e ed mn mx r)

  (defun *error* (msg)
    (if (and target (not (vlax-erased-p target))) (vla-Delete target))
    (if zoomed (command-s "_.ZOOM" "_P"))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("OSMODE" "CMDECHO" "TRIMEXTENDMODE" "EDGEMODE" "PROJMODE")))

  (cond
    ((/= (getvar "CTAB") "Model") (princ "\n[주의] 모형 탭에서 실행하세요."))
    ((not (equal (getvar "VIEWDIR") '(0.0 0.0 1.0) 1e-6))
     (princ "\n[주의] 평면 뷰(PLAN)에서 실행하세요 — 걸침 선택·자르기가 화면 기준입니다."))
    ((null (setq sel (entsel "\n남길 영역의 닫힌 경계(폴리선·원)를 고르세요: "))) nil)
    ((not (and (setq ent (car sel) obj (vlax-ename->vla-object ent))
               (member (vla-get-ObjectName obj) '("AcDbPolyline" "AcDbCircle" "AcDbEllipse" "AcDbSpline"))
               (kout:closed-p obj)))
     (princ "\n[주의] 닫힌 폴리선·원·타원을 고르세요."))
    (T
     (setq poly (kout:flatten obj)
           upoly (mapcar '(lambda (p) (trans p 0 1)) poly))
     ;; 경계 둘레 + 여백 5% 로 화면 맞춤 (걸침 선택·펜스는 화면에 보이는 것만 잡음)
     (setq lo (list (apply 'min (mapcar 'car upoly)) (apply 'min (mapcar 'cadr upoly)))
           hi (list (apply 'max (mapcar 'car upoly)) (apply 'max (mapcar 'cadr upoly)))
           d (distance lo hi))
     (setvar "CMDECHO" 0)
     (setvar "OSMODE" 0)
     (vla-StartUndoMark doc)
     (setq undo_open T)
     (command "_.ZOOM" "_W" "_non" (mapcar '(lambda (a b) (- a (* 0.05 (- b a)))) lo hi)
                           "_non" (mapcar '(lambda (a b) (+ b (* 0.05 (- b a)))) lo hi))
     (setq zoomed T)

     ;; ---- 1. 경계 밖 ----
     (setq ss_in (ssget "_CP" upoly)
           in_set (kout:ss-list ss_in)
           all (kout:ss-list (ssget "_X" '((410 . "Model") (-4 . "<NOT") (0 . "VIEWPORT") (-4 . "NOT>")))))
     (foreach e all
       (if (not (eq e ent))
         (progn
           (setq ed (entget e))
           (cond
             ((kout:locked-p ed) (if (not (member e in_set)) (setq locked (cons e locked))))
             ((kout:hidden-p ed)
              ;; 숨은 객체: 범위가 경계와 완전히 떨어져 있을 때만
              (setq r (vl-catch-all-apply 'vla-GetBoundingBox (list (vlax-ename->vla-object e) 'mn 'mx)))
              (if (and (not (vl-catch-all-error-p r))
                       (kout:apart-p (vlax-safearray->list mn) (vlax-safearray->list mx) poly))
                (setq gone (cons e gone))
                (setq keep_hidden (cons e keep_hidden))))
             ((not (member e in_set)) (setq gone (cons e gone)))))))
     (initget "Y N")
     (setq ans (getkword (strcat "\n경계 밖 객체 " (itoa (length gone)) "개를 지우고 걸친 선을 자릅니다"
                                 (if locked (strcat " (잠긴 레이어 " (itoa (length locked)) "개는 그대로)") "")
                                 ". 계속할까요? [예(Y)/아니오(N)] <Y>: ")))
     (if (= ans "N")
       (princ "\n그만두었습니다.")
       (progn
         (foreach e gone (entdel e))

         ;; ---- 2. 걸친 선 자르기: 경계 바로 바깥(대각선의 10만분의 1)에 펜스 ----
         (setq off (max 0.01 (* d 1e-5))
               o1 (vl-catch-all-apply 'vlax-invoke (list obj 'Offset off))
               o2 (vl-catch-all-apply 'vlax-invoke (list obj 'Offset (- off))))
         (setq a1 (if (and (not (vl-catch-all-error-p o1)) o1) (vla-get-Area (car o1)) 0.0)
               a2 (if (and (not (vl-catch-all-error-p o2)) o2) (vla-get-Area (car o2)) 0.0))
         (cond
           ((> a1 a2) (setq target (car o1)) (if (and (not (vl-catch-all-error-p o2)) o2) (foreach x o2 (vla-Delete x))))
           ((> a2 0.0) (setq target (car o2)) (if (and (not (vl-catch-all-error-p o1)) o1) (foreach x o1 (vla-Delete x)))))
         (if target
           (progn
             (setq fence (mapcar '(lambda (p) (trans p 0 1)) (kout:flatten target)))
             (setq fence (append fence (list (car fence))))
             (setvar "TRIMEXTENDMODE" 0)
             (setvar "EDGEMODE" 0)
             (setvar "PROJMODE" 1)
             (command "_.TRIM" ent "" "_F")
             (foreach p fence (command "_non" p))
             (command "" "")
             (vla-Delete target)
             (setq target nil))
           (princ "\n[주의] 경계를 바깥으로 띄울 수 없어 걸친 선은 자르지 못했습니다 (경계가 꼬였는지 확인하세요)."))
         (princ (strcat "\n[완료] 경계 밖 " (itoa (length gone)) "개를 지우고 걸친 선을 잘랐습니다."))
         (if keep_hidden
           (princ (strcat "\n[알림] 꺼진·숨긴 객체 중 경계 안·걸친 " (itoa (length keep_hidden)) "개는 그대로 두었습니다.")))))
     (command "_.ZOOM" "_P")
     (setq zoomed nil)
     (vla-EndUndoMark doc)
     (setq undo_open nil)))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
