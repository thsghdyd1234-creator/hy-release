## 1.0.0 — 2026-11-06
- 첫 등록: 슬래브 · 코어 · 무주 영역(로비 / 아트리움)을 골라 %TEMP%\hycol_request.json 으로 hy Column 에 보냄
- hy Column 을 허브 설치 자리(%LOCALAPPDATA%\Programs\hy\hy-column\hy_column.exe)부터 찾음 (`*hycol-exe*` 로 바꿀 수 있음)
