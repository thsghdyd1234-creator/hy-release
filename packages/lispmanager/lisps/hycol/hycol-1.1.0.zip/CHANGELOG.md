## 1.1.0 — 2026-11-08
- 같은 층의 분동: 무주 영역을 다 고른 뒤 '다른 동 슬래브 외곽'과 그 동의 코어를 더 고를 수 있음 → 요청에 slabs · cores 여럿 (hy Column 0.22 가 떨어진 동마다 축렬을 따로 깖, 예전 hy Column 은 첫 슬래브만 읽음)
- 예전 순서(슬래브 → 코어 → 무주 영역)는 그대로 — 새 질문은 맨 끝이라 Enter 로 넘어감

## 1.0.0 — 2026-11-06
- 첫 등록: 슬래브 · 코어 · 무주 영역(로비 / 아트리움)을 골라 %TEMP%\hycol_request.json 으로 hy Column 에 보냄
- hy Column 을 허브 설치 자리(%LOCALAPPDATA%\Programs\hy\hy-column\hy_column.exe)부터 찾음 (`*hycol-exe*` 로 바꿀 수 있음)
