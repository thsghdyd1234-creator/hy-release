;;; ============================================================
;;; HYCOL — 기둥 배치 (hy Column 시작)  v1.1.0
;;;
;;;  명령 HYCOL
;;;   1) 슬래브 외곽 폴리라인을 고릅니다
;;;   2) 코어 폴리라인을 고릅니다 (없으면 Enter)
;;;   3) 무주 영역 폴리라인을 하나씩 고릅니다 (Enter 로 끝)
;;;      L 로비 = 위층 기둥을 전이 부재로 받음 / T 아트리움 = 위층도 비움
;;;   4) 같은 층의 다른 동이 있으면 그 동 슬래브 외곽과 코어를 고릅니다 (Enter 로 끝)
;;;      떨어진 동은 hy Column 이 동마다 축렬을 따로 깝니다 (hy Column 0.22 이상)
;;;  → %TEMP%\hycol_request.json 을 쓰고 hy Column 을 실행합니다.
;;;     hy Column 이 이미 떠 있으면 그 창이 받아서 바로 탐색합니다.
;;;
;;;  hy Column 은 hy 허브에서 설치합니다
;;;  (%LOCALAPPDATA%\Programs\hy\hy-column\hy_column.exe).
;;;  다른 곳에 두었으면 *hycol-exe* 에 경로를 넣으세요.
;;; ============================================================

(vl-load-com)

(defun hycol:exe (/ p)
  (cond
    ((and *hycol-exe* (findfile *hycol-exe*)) *hycol-exe*)
    ((and (getenv "LOCALAPPDATA")
          (findfile (setq p (strcat (getenv "LOCALAPPDATA") "\\Programs\\hy\\hy-column\\hy_column.exe"))))
     p)
    ((findfile "C:\\YGN\\hyColumn\\hyColumn.exe") "C:\\YGN\\hyColumn\\hyColumn.exe")
  )
)

(defun hycol:num (x) (vl-string-translate "," "." (rtos x 2 4)))

(defun hycol:join (lst sep / out)
  (setq out "")
  (foreach s lst (setq out (if (= out "") s (strcat out sep s))))
  out
)

(defun hycol:poly->json (ent / ed pts bul)
  (setq ed (entget ent))
  (foreach pr ed
    (cond ((= (car pr) 10) (setq pts (cons (cdr pr) pts)))
          ((= (car pr) 42) (setq bul (cons (cdr pr) bul)))))
  (setq pts (reverse pts) bul (reverse bul))
  (strcat "{\"pts\": ["
          (hycol:join (mapcar '(lambda (p) (strcat "[" (hycol:num (car p)) ", " (hycol:num (cadr p)) "]")) pts) ", ")
          "], \"bulges\": [" (hycol:join (mapcar 'hycol:num bul) ", ") "]}")
)

(defun hycol:pick (msg / s e done)
  ;; 폴리라인을 고를 때까지 다시 묻는다. Enter(아무것도 안 고름)면 nil.
  (while (not done)
    (setq s (entsel msg))
    (cond
      ((null s) (setq done t e nil))
      ((= (cdr (assoc 0 (entget (car s)))) "LWPOLYLINE") (setq done t e (car s)))
      (t (princ "\n[주의] 폴리라인(LWPOLYLINE)이 아닙니다. 다시 고르세요."))))
  e
)

(defun c:HYCOL (/ slab core voids v kind fname fh unit exe slabs cores s2 c2)
  (setq slab (hycol:pick "\n슬래브 외곽 폴리라인을 고르세요: "))
  (cond
    ((null slab) (princ "\n[알림] 취소했습니다."))
    (t
     (setq core (hycol:pick "\n코어 폴리라인을 고르세요 (없으면 Enter): "))
     (while (setq v (hycol:pick "\n무주 영역 폴리라인을 고르세요 (끝내려면 Enter): "))
       (initget "L T")
       (setq kind (getkword "\n  위층 기둥을 받습니까? [L 로비(전이) / T 아트리움(위층도 비움)] <L>: "))
       (setq voids (cons (strcat "{\"polygon\": " (hycol:poly->json v)
                                 ", \"kind\": \"" (if (= kind "T") "through" "lobby") "\""
                                 ", \"name\": \"" (if (= kind "T") "atrium" "lobby") "\"}") voids)))
     ;; 같은 층의 다른 동 — 동마다 슬래브 외곽 · 코어 (맨 끝에 물어 예전 순서대로 누른 코어가 다른 동 바닥이 되지 않게)
     (setq slabs (list (hycol:poly->json slab))
           cores (if core (list (hycol:poly->json core))))
     (while (setq s2 (hycol:pick "\n다른 동 슬래브 외곽 폴리라인을 고르세요 (끝내려면 Enter): "))
       (setq slabs (cons (hycol:poly->json s2) slabs))
       (if (setq c2 (hycol:pick "\n  그 동의 코어 폴리라인을 고르세요 (없으면 Enter): "))
         (setq cores (cons (hycol:poly->json c2) cores))))
     (setq slabs (reverse slabs) cores (reverse cores))
     (setq unit (cond ((= (getvar "INSUNITS") 6) "m") ((= (getvar "INSUNITS") 5) "cm") (t "mm")))
     (setq fname (strcat (getenv "TEMP") "\\hycol_request.json")
           fh    (open fname "w"))
     (write-line "{" fh)
     (write-line (strcat "  \"unit\": \"" unit "\",") fh)
     (write-line "  \"source\": \"HYCOL\"," fh)
     (write-line (strcat "  \"slab\": " (car slabs) ",") fh)
     (if (cdr slabs) (write-line (strcat "  \"slabs\": [" (hycol:join slabs ", ") "],") fh))
     (write-line (strcat "  \"core\": " (if cores (car cores) "null") ",") fh)
     (if (cdr cores) (write-line (strcat "  \"cores\": [" (hycol:join cores ", ") "],") fh))
     (write-line (strcat "  \"voids\": [" (hycol:join (reverse voids) ", ") "]") fh)
     (write-line "}" fh)
     (close fh)
     (if (setq exe (hycol:exe))
       (progn
         (startapp exe (strcat "--load \"" fname "\""))
         (princ "\n[완료] hy Column 으로 보냈습니다. 창에서 대안을 확인하세요."))
       (princ (strcat "\n[오류] hy Column 실행 파일을 찾지 못했습니다. hy 허브에서 hy Column 을 설치하세요."
                      "\n       요청 파일은 저장했습니다: " fname)))))
  (princ)
)

(princ)
