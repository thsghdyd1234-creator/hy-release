;;; ==========================================================================
;;; [명령 6] 선택한 블록만 숨기기
;;; ==========================================================================
(defun c:6 (/ ss i ent vla_ent cnt)
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (princ "\n[6: 선택 블록 숨기기] 숨길 블록을 선택하세요.")

  ;; '((0 . "INSERT")) 필터를 걸어 드래그해도 블록만 선택되도록 처리
  (if (setq ss (ssget '((0 . "INSERT"))))
    (progn
      (setq cnt 0 i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (setq vla_ent (vlax-ename->vla-object ent))
        
        ;; 현재 켜져 있는 객체만 숨김 처리
        (if (= (vla-get-Visible vla_ent) :vlax-true)
          (progn
            (vla-put-Visible vla_ent :vlax-false)
            (setq cnt (1+ cnt))
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\n선택한 블록 [" (itoa cnt) "]개를 숨겼습니다."))
    )
    (princ "\n선택한 객체 중 블록이 없습니다.")
  )
  (princ)
)

;;; ==========================================================================
;;; [명령 7] 도면의 모든 블록 숨기기
;;; ==========================================================================
(defun c:7 (/ ss i ent vla_ent cnt)
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (princ "\n도면 내의 모든 블록을 검색 중...")

  ;; 도면 전체("X")에서 블록("INSERT")만 선택
  (if (setq ss (ssget "X" '((0 . "INSERT"))))
    (progn
      (setq cnt 0 i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (setq vla_ent (vlax-ename->vla-object ent))
        
        (if (= (vla-get-Visible vla_ent) :vlax-true)
          (progn
            (vla-put-Visible vla_ent :vlax-false)
            (setq cnt (1+ cnt))
          )
        )
        (setq i (1+ i))
      )
      (if (> cnt 0)
        (princ (strcat "\n도면의 모든 블록 [" (itoa cnt) "]개를 숨겼습니다."))
        (princ "\n숨길 블록이 없거나 이미 모두 숨겨져 있습니다.")
      )
    )
    (princ "\n도면에 블록이 존재하지 않습니다.")
  )
  (princ)
)

;;; ==========================================================================
;;; [명령 8] 숨긴 블록 모두 다시 표시
;;; ==========================================================================
(defun c:8 (/ ss i ent vla_ent cnt)
  (vl-load-com)
  (setvar "CMDECHO" 0)

  ;; 숨겨진 객체도 검색할 수 있도록 도면 전체("X") 스캔
  (if (setq ss (ssget "X" '((0 . "INSERT"))))
    (progn
      (setq cnt 0 i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (setq vla_ent (vlax-ename->vla-object ent))
        
        ;; 보이지 않는 상태(:vlax-false)인 블록만 골라서 켬
        (if (= (vla-get-Visible vla_ent) :vlax-false)
          (progn
            (vla-put-Visible vla_ent :vlax-true)
            (setq cnt (1+ cnt))
          )
        )
        (setq i (1+ i))
      )
      (if (> cnt 0)
        (princ (strcat "\n숨겨진 블록 [" (itoa cnt) "]개를 다시 표시했습니다."))
        (princ "\n숨겨진 블록이 없습니다.")
      )
    )
  )
  (princ)
)