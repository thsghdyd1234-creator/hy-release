;;; ==============================================================================
;;;  6 · 7 · 8 — 블록 숨기기 · 다시 보이기
;;;
;;;  6 = 고른 것 중 블록만 숨김 (드래그해도 블록만 골라짐)
;;;  7 = 지금 공간의 모든 블록을 숨김 (외부 참조는 그대로, 다른 배치 탭의 도곽도 그대로)
;;;  8 = 숨긴 것을 모두 다시 보이기 (UNISOLATEOBJECTS)
;;;
;;;  숨기기는 캐드 기본 HIDEOBJECTS 를 쓴다 — 도면에 저장되지 않고(닫았다 열면 다 보임), 상태 막대에 격리 표시가 켜진다.
;;;  8 · G3 · UNISOLATEOBJECTS 는 같은 것을 되살린다 (그룹 G1·G2 로 숨긴 것도 함께).
;;;  예전 판(1.0)으로 숨겨 도면에 저장된 블록도 8 이 다시 보이게 한다 (잠긴 레이어의 것은 빼고 알림).
;;; ==============================================================================

(defun blk678:space ()
  (if (or (= (getvar "TILEMODE") 1) (/= (getvar "CVPORT") 1)) "Model" (getvar "CTAB")))

(defun blk678:xref-p (name / b)
  (and (setq b (tblsearch "BLOCK" name)) (= 4 (logand 4 (cdr (assoc 70 b))))))

(defun blk678:hide (ss / sv)
  (setq sv (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (command "_.HIDEOBJECTS" ss "")
  (setvar "CMDECHO" sv)
  (sslength ss))

(defun blk678:err (msg)
  (if blk678_sv (setvar "CMDECHO" blk678_sv))
  (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
    (princ (strcat "\n[오류] " msg)))
  (princ))

(defun c:6 ( / *error* blk678_sv ss)
  (setq *error* blk678:err blk678_sv (getvar "CMDECHO"))
  (prompt "\n숨길 블록을 고르세요 (블록만 골라짐): ")
  (if (setq ss (ssget '((0 . "INSERT"))))
    (princ (strcat "\n[완료] 블록 " (itoa (blk678:hide ss)) "개를 숨겼습니다. 다시 보이기: 8"))
    (princ "\n고른 블록이 없습니다."))
  (princ))

(defun c:7 ( / *error* blk678_sv all ss i e x)
  (setq *error* blk678:err blk678_sv (getvar "CMDECHO"))
  (setq ss (ssadd) i 0 x 0)
  (if (setq all (ssget "_X" (list '(0 . "INSERT") (cons 410 (blk678:space)))))
    (while (< i (sslength all))
      (setq e (ssname all i))
      (cond ((= (cdr (assoc 60 (entget e))) 1))
            ((blk678:xref-p (cdr (assoc 2 (entget e)))) (setq x (1+ x)))
            (T (ssadd e ss)))
      (setq i (1+ i))))
  (if (> (sslength ss) 0)
    (princ (strcat "\n[완료] 지금 공간의 블록 " (itoa (blk678:hide ss)) "개를 숨겼습니다"
                   (if (> x 0) (strcat " (외부 참조 " (itoa x) "개는 그대로)") "") ". 다시 보이기: 8"))
    (princ "\n지금 공간에 숨길 블록이 없습니다."))
  (princ))

(defun c:8 ( / *error* blk678_sv ss i n lk)
  (setq *error* blk678:err blk678_sv (getvar "CMDECHO"))
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (command "_.UNISOLATEOBJECTS")
  (setvar "CMDECHO" blk678_sv)
  ;; 예전 판이 도면에 저장한 숨김 (Visible 끔) 되살리기
  (setq n 0 lk 0 i 0)
  (if (setq ss (ssget "_X" '((0 . "INSERT") (60 . 1))))
    (while (< i (sslength ss))
      (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Visible (list (vlax-ename->vla-object (ssname ss i)) :vlax-true)))
        (setq lk (1+ lk))
        (setq n (1+ n)))
      (setq i (1+ i))))
  (princ (strcat "\n[완료] 숨긴 객체를 모두 다시 보이게 했습니다"
                 (if (> n 0) (strcat " (예전 판으로 숨겨 저장된 블록 " (itoa n) "개 포함)") "")
                 "."
                 (if (> lk 0) (strcat "\n[주의] 잠긴 레이어의 숨은 블록 " (itoa lk) "개는 그대로입니다 (ULALL 뒤 다시 8).") "")))
  (princ))

(princ)
