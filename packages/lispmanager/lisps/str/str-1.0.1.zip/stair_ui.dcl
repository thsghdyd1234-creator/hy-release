stair_ui : dialog {
    label = "직선 계단 그리기";
    
    : boxed_column {
        label = "1. 기본 제원 설정";
        : popup_list { key = "st_layer"; label = "적용 도면층(Layer):"; edit_width = 16; }
        : edit_box { key = "st_width"; label = "계단 폭 (W) [mm]:"; edit_width = 12; value = "1200"; }
        : edit_box { key = "st_height"; label = "올라갈 층고 (H) [mm]:"; edit_width = 12; value = "3000"; }
        : edit_box { key = "st_riser"; label = "희망 단높이 (R) [mm]:"; edit_width = 12; value = "160"; }
        : edit_box { key = "st_tread"; label = "단너비 (T) [mm]:"; edit_width = 12; value = "280"; }
    }
    
    : boxed_column {
        label = "2. 공간 계산";
        : toggle { key = "chk_auto_land"; label = "남는 공간을 계단참으로 자동 연장"; value = "1"; }
        : button { key = "btn_sim"; label = "입력값으로 미리 계산하기"; }
        : text { key = "sim_txt1"; value = "- 단수: - 단  /  실제 단높이: - mm"; }
        : text { key = "sim_txt2"; value = "- 총 필요 길이: - mm"; }
        : text { key = "sim_txt3"; value = "- 확보된 공간: - mm"; }
    }

    : boxed_column {
        label = "3. 세부 옵션";
        : radio_row {
            key = "hd_pos";
            label = "난간 위치 (50mm):";
            : radio_button { key = "hd_both"; label = "양쪽"; value = "1"; }
            : radio_button { key = "hd_left"; label = "좌측"; }
            : radio_button { key = "hd_right"; label = "우측"; }
            : radio_button { key = "hd_none"; label = "없음"; }
        }
    }
    
    ok_cancel;
}