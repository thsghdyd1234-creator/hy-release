;;; ==============================================================================
;;;  GCO — 기둥으로 외곽선 만들기 · 외곽선을 기둥 자리에서 나누기
;;;
;;;  먼저 기준 기둥 블록을 클릭한다 — 같은 블록(동적 블록도 원본 이름으로)만 기둥으로 본다 (문·그리드 기호가 섞여도 됨).
;;;  모드 1 (외곽선 만들기): 기둥을 고르면, 같은 줄(가로·세로)에서 '이을 최대 간격' 이내의 이웃 기둥을 이어
;;;         그 바깥 둘레를 닫힌 폴리선으로 만든다 (ㄱ·ㄷ·ㅁ 모양). 떨어진 동이 여럿이면 동마다 하나씩,
;;;         둘레 안쪽에 생기는 구멍(중정 · 칸 안)은 버린다. 결과는 지금 레이어.
;;;  모드 2 (외곽선 나누기): 외곽선 폴리선을 클릭하고 기둥을 고르면, 외곽선이 기둥 상자 변과 만나는 곳마다 꼭짓점을 넣는다.
;;;         이중 정점(D)을 켜면 꼭짓점을 두 번씩 넣는다 (꼭짓점을 옮길 때 이웃 변이 같이 기울지 않게). 원래 폴리선을
;;;         그대로 고치므로 레이어·고도·핸들이 남는다. 호 구간은 나누지 않고 그대로 둔다.
;;;  한 번 실행 = 실행 취소 한 번(U). 모드 · 이중 정점은 기억한다.
;;; ==============================================================================

;; 와일드카드 글자 앞에 `
(defun gco:esc (s / out)
  (setq out "")
  (foreach c (vl-string->list s)
    (setq out (strcat out (if (member c (vl-string->list "#@.*?~[]`,-")) "`" "") (chr c))))
  out)

(defun gco:ename (o)
  (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))

;; 기준 블록과 같은 블록만 고르기 → 선택 집합 / nil
(defun gco:pick-cols (name msg / ss out i e)
  (prompt msg)
  (if (setq ss (ssget (list '(0 . "INSERT") (cons 2 (strcat (gco:esc name) ",`*U*")))))
    (progn
      (setq out (ssadd) i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (if (= (strcase (gco:ename (vlax-ename->vla-object e))) (strcase name)) (ssadd e out))
        (setq i (1+ i)))
      (if (> (sslength out) 0) out))))

;; 기둥 → (cx cy minx miny maxx maxy)
(defun gco:box (e / o a b p q)
  (setq o (vlax-ename->vla-object e))
  (vla-GetBoundingBox o 'a 'b)
  (setq p (vlax-safearray->list a) q (vlax-safearray->list b))
  (list (/ (+ (car p) (car q)) 2.0) (/ (+ (cadr p) (cadr q)) 2.0) (car p) (cadr p) (car q) (cadr q)))

;; 값(key 함수)이 tol 안인 것끼리 묶기
(defun gco:group (cols key tol / groups hit k)
  (foreach c cols
    (setq k (apply key (list c)) hit nil)
    (setq groups (mapcar '(lambda (g) (if (and (not hit) (< (abs (- (car g) k)) tol))
                                        (progn (setq hit T) (cons (car g) (cons c (cdr g))))
                                        g))
                         groups))
    (if (not hit) (setq groups (cons (list k c) groups))))
  (mapcar 'cdr groups))

(defun gco:median (lst / s n)
  (setq s (vl-sort lst '<) n (length s))
  (if (> n 0) (if (= (rem n 2) 1) (nth (/ n 2) s) (/ (+ (nth (1- (/ n 2)) s) (nth (/ n 2) s)) 2.0))))

;; 줄마다 이웃 사이 간격 / 다리 사각형
(defun gco:pairs (groups axis / out srt)
  ;; axis 0 = 가로 줄(가운데 x 로 정렬), 1 = 세로 줄(가운데 y)
  (foreach g groups
    (setq srt (vl-sort g (if (= axis 0) '(lambda (a b) (< (car a) (car b))) '(lambda (a b) (< (cadr a) (cadr b))))))
    (while (cdr srt)
      (setq out (cons (list (car srt) (cadr srt)) out) srt (cdr srt))))
  out)

(defun gco:gap (pr axis)
  (if (= axis 0) (- (car (cadr pr)) (car (car pr))) (- (cadr (cadr pr)) (cadr (car pr)))))

(defun gco:bridge (pr axis / a b)
  (setq a (car pr) b (cadr pr))
  (if (= axis 0)
    (list (nth 2 a) (min (nth 3 a) (nth 3 b)) (nth 4 b) (max (nth 5 a) (nth 5 b)))
    (list (min (nth 2 a) (nth 2 b)) (nth 3 a) (max (nth 4 a) (nth 4 b)) (nth 5 b))))

;; 선분 목록 ((p q) …) → 닫힌 고리 목록 (같은 직선 위 점은 뺌)
(defun gco:loops (segs / loops loop start cur hit rest)
  (while segs
    (setq start (car (car segs)) cur (cadr (car segs)) loop (list start) segs (cdr segs))
    (while (and cur (not (equal cur start 1e-3)))
      (setq loop (cons cur loop) hit nil rest nil)
      (foreach s segs
        (cond ((and (null hit) (equal (car s) cur 1e-3)) (setq hit (cadr s)))
              ((and (null hit) (equal (cadr s) cur 1e-3)) (setq hit (car s)))
              (T (setq rest (cons s rest)))))
      (setq segs (reverse rest) cur hit))
    (if (and cur (> (length loop) 2)) (setq loops (cons (gco:simplify (reverse loop)) loops))))
  loops)

(defun gco:simplify (pts / n out i a b c)
  (setq n (length pts) i 0)
  (while (< i n)
    (setq a (nth (rem (+ i n -1) n) pts) b (nth i pts) c (nth (rem (1+ i) n) pts))
    (if (> (abs (- (* (- (car b) (car a)) (- (cadr c) (cadr b))) (* (- (cadr b) (cadr a)) (- (car c) (car b)))))
           (* 1e-9 (distance a b) (distance b c)))
      (setq out (cons b out)))
    (setq i (1+ i)))
  (reverse out))

(defun gco:area (pts / s p q)
  (setq s 0.0 p (last pts))
  (foreach q pts (setq s (+ s (- (* (car p) (cadr q)) (* (car q) (cadr p)))) p q))
  (/ s 2.0))

(defun gco:inside (p poly / n i j a b in)
  (setq n (length poly) j (1- n) i 0)
  (while (< i n)
    (setq a (nth i poly) b (nth j poly))
    (if (and (not (eq (> (cadr a) (cadr p)) (> (cadr b) (cadr p))))
             (< (car p) (+ (car a) (/ (* (- (car b) (car a)) (- (cadr p) (cadr a))) (- (cadr b) (cadr a))))))
      (setq in (not in)))
    (setq j i i (1+ i)))
  in)

;; 모드 1 — 기둥 상자 + 다리 → 바깥 둘레 폴리선들
(defun gco:outline (cols span elev / doc spc rects o tmp regs base todo lines segs loops n)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        spc (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc)))
  (setq rects (mapcar '(lambda (c) (list (nth 2 c) (nth 3 c) (nth 4 c) (nth 5 c))) cols))
  (foreach ax '(0 1)
    (foreach pr (gco:pairs (gco:group cols (if (= ax 0) 'cadr 'car)
                                      (* 0.5 (apply 'min (mapcar '(lambda (c) (if (= ax 0) (- (nth 5 c) (nth 3 c)) (- (nth 4 c) (nth 2 c)))) cols))))
                           ax)
      (if (<= (gco:gap pr ax) span) (setq rects (cons (gco:bridge pr ax) rects)))))
  ;; 사각형 → 영역 → 합치기 → 분해한 선 → 고리
  (foreach r rects
    (setq tmp (cons (vlax-ename->vla-object
                      (entmakex (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
                                      (cons 38 elev)
                                      (list 10 (nth 0 r) (nth 1 r)) (list 10 (nth 2 r) (nth 1 r))
                                      (list 10 (nth 2 r) (nth 3 r)) (list 10 (nth 0 r) (nth 3 r)))))
                    tmp)))
  (setq regs (vlax-invoke spc 'AddRegion tmp))
  (foreach o tmp (vla-Delete o))
  (setq base (car regs))
  (foreach o (cdr regs) (vla-Boolean base 0 o))
  ;; 분해 — 떨어진 동이 섞인 영역은 영역들로 나뉘므로 선이 나올 때까지
  (setq todo (list base))
  (while todo
    (setq o (car todo) todo (cdr todo))
    (foreach x (vlax-invoke o 'Explode)
      (if (= (vla-get-ObjectName x) "AcDbRegion") (setq todo (cons x todo)) (setq lines (cons x lines))))
    (vla-Delete o))
  (foreach o lines
    (setq segs (cons (list (list (car (vlax-get o 'StartPoint)) (cadr (vlax-get o 'StartPoint)))
                           (list (car (vlax-get o 'EndPoint)) (cadr (vlax-get o 'EndPoint))))
                     segs))
    (vla-Delete o))
  (setq loops (gco:loops segs) n 0)
  ;; 다른 고리 안에 든 고리(구멍)는 버림
  (foreach L loops
    (if (not (vl-some '(lambda (M) (and (not (eq L M)) (> (abs (gco:area M)) (abs (gco:area L)))
                                        (gco:inside (mapcar '(lambda (a b) (/ (+ a b) 2.0)) (car L) (cadr L)) M)))
                      loops))
      (progn
        (entmake (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline")
                               (cons 90 (length L)) '(70 . 1) (cons 38 elev))
                         (mapcar '(lambda (p) (cons 10 p)) L)))
        (setq n (1+ n)))))
  n)

;; 모드 2 — 폴리선 꼭짓점 ((점 볼록) …)
(defun gco:verts (ed / out)
  (foreach g ed
    (cond ((= (car g) 10) (setq out (cons (list (list (cadr g) (caddr g)) 0.0) out)))
          ((and (= (car g) 42) out) (setq out (cons (list (car (car out)) (cdr g)) (cdr out))))))
  (reverse out))

(defun gco:split (pl cols double / ed vs closed n i a b p pts out new head tail seen)
  (setq ed (entget pl) vs (gco:verts ed) closed (= 1 (logand 1 (cdr (assoc 70 ed)))) n (length vs) i 0)
  (while (< i (if closed n (1- n)))
    (setq a (nth i vs) b (nth (rem (1+ i) n) vs))
    (setq out (cons a out))
    (if (equal (cadr a) 0.0 1e-12)
      (progn
        (setq pts nil)
        (foreach c cols
          (foreach s (list (list (list (nth 2 c) (nth 3 c)) (list (nth 4 c) (nth 3 c)))
                           (list (list (nth 4 c) (nth 3 c)) (list (nth 4 c) (nth 5 c)))
                           (list (list (nth 4 c) (nth 5 c)) (list (nth 2 c) (nth 5 c)))
                           (list (list (nth 2 c) (nth 5 c)) (list (nth 2 c) (nth 3 c))))
            (if (setq p (inters (car a) (car b) (car s) (cadr s))) (setq pts (cons (list (car p) (cadr p)) pts)))))
        (setq pts (vl-sort pts '(lambda (p q) (< (distance (car a) p) (distance (car a) q)))))
        (foreach p pts
          (if (and (not (equal p (car (car out)) 1e-3)) (not (equal p (car b) 1e-3)))
            (setq out (cons (list p 0.0) out))))))
    (setq i (1+ i)))
  (if (not closed) (setq out (cons (last vs) out)))
  (setq out (reverse out))
  (if double (setq out (apply 'append (mapcar '(lambda (v) (list (list (car v) 0.0) v)) out))))
  ;; 원래 폴리선을 고친다 (레이어·고도·핸들 유지)
  (foreach g ed
    (cond ((member (car g) '(10 40 41 42 91)) (setq seen T))
          ((not seen) (setq head (cons (if (= (car g) 90) (cons 90 (length out)) g) head)))
          (T (setq tail (cons g tail)))))
  (setq new (append (reverse head)
                    (apply 'append (mapcar '(lambda (v) (list (cons 10 (car v)) '(40 . 0.0) '(41 . 0.0) (cons 42 (cadr v))))
                                           out))
                    (reverse tail)))
  (if (entmod new) (progn (entupd pl) (- (length out) n))))

(defun c:GCO ( / *error* doc undo_open mode sel name ss cols i gaps span def elev pl r p)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (null *gco_mode*) (setq *gco_mode* "1"))
  (initget "1 2")
  (setq mode (getkword (strcat "\n모드 [외곽선 만들기(1)/외곽선 나누기(2)] <" *gco_mode* ">: ")))
  (if mode (setq *gco_mode* mode) (setq mode *gco_mode*))
  ;; 기준 기둥
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n기준 기둥 블록을 클릭하세요 (같은 블록만 기둥으로 봄): "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n기준 기둥을 고르지 않았습니다."))
    ((/= (cdr (assoc 0 (entget (car sel)))) "INSERT") (princ "\n[주의] 블록이 아닙니다."))
    ((= mode "1")
     (setq name (gco:ename (vlax-ename->vla-object (car sel)))
           elev (caddr (cdr (assoc 10 (entget (car sel))))))
     (if (null (setq ss (gco:pick-cols name (strcat "\n외곽선을 감쌀 기둥 [" name "] 을 고르세요: "))))
       (princ "\n고른 기둥이 없습니다.")
       (progn
         (setq i 0)
         (while (< i (sslength ss)) (setq cols (cons (gco:box (ssname ss i)) cols) i (1+ i)))
         ;; 이을 최대 간격: 이웃 간격의 가운데 값 × 1.5
         (foreach ax '(0 1)
           (foreach pr (gco:pairs (gco:group cols (if (= ax 0) 'cadr 'car)
                                             (* 0.5 (apply 'min (mapcar '(lambda (c) (if (= ax 0) (- (nth 5 c) (nth 3 c)) (- (nth 4 c) (nth 2 c)))) cols))))
                                  ax)
             (setq gaps (cons (gco:gap pr ax) gaps))))
         (setq def (if gaps (* 1.5 (gco:median gaps)) 0.0))
         (initget 4)
         (setq span (getdist (strcat "\n이을 최대 간격 (기둥 가운데 사이) <" (rtos def 2 0) ">: ")))
         (if (null span) (setq span def))
         (vla-StartUndoMark doc)
         (setq undo_open T r (gco:outline cols span elev))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (princ (strcat "\n[완료] 기둥 " (itoa (length cols)) "개로 외곽선 " (itoa r) "개를 만들었습니다 (지금 레이어)."
                        (if (> r 1) " 떨어진 동마다 하나씩입니다." ""))))))
    (T
     (setq name (gco:ename (vlax-ename->vla-object (car sel))))
     (while (progn
              (setvar "ERRNO" 0)
              (initget "Double")
              (setq pl (entsel (strcat "\n나눌 외곽선(폴리선)을 클릭하세요 [이중 정점(D) " (if (= *gco_double* "N") "끔" "켬") "]: ")))
              (cond ((= pl "Double") (setq *gco_double* (if (= *gco_double* "N") "Y" "N")) T)
                    ((and (null pl) (= (getvar "ERRNO") 7)) (princ "\n빗나갔습니다. 다시 클릭하세요.") T))))
     (cond
       ((null pl) (princ "\n외곽선을 고르지 않았습니다."))
       ((/= (cdr (assoc 0 (entget (car pl)))) "LWPOLYLINE") (princ "\n[주의] 폴리선(LWPOLYLINE)이 아닙니다."))
       ((null (setq ss (gco:pick-cols name (strcat "\n나눌 자리의 기둥 [" name "] 을 고르세요: "))))
        (princ "\n고른 기둥이 없습니다."))
       (T
        (setq i 0)
        (while (< i (sslength ss)) (setq cols (cons (gco:box (ssname ss i)) cols) i (1+ i)))
        (vla-StartUndoMark doc)
        (setq undo_open T r (gco:split (car pl) cols (/= *gco_double* "N")))
        (vla-EndUndoMark doc)
        (setq undo_open nil)
        (if r
          (princ (strcat "\n[완료] 외곽선에 꼭짓점 " (itoa r) "개를 넣었습니다" (if (/= *gco_double* "N") " (이중 정점)" "") "."))
          (princ "\n[주의] 외곽선을 고치지 못했습니다 (잠긴 레이어?)."))))))
  (princ))

(princ)
