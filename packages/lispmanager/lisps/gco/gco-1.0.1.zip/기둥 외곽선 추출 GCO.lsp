(defun c:GCO ( / opt ss i obj minPt maxPt ptMin ptMax 
                 plineEnt blocks ent plineObj pline-verts-list original-verts 
                 boundary-segments b-seg startPt endPt pts-on-seg 
                 blk blk-verts blk-segments blk-s int-pt 
                 sorted-pts all-unique-perimeter-pts final-verts
                 col-data cx cy tol y-groups x-groups grp cols j col1 col2 dx dy
                 minDx minDy bridge-coords pMin pMax bMinX bMaxX bMinY bMaxY
                 doc mspace pline vlaObj regArray ssReg cmdecho_save 
                 explode-mark union-ents curr-ent line-ents pedit_save
                 final-plines max-area max-pline area vObj )
  (vl-load-com)

  ;; 내부 함수: 허용 오차 이내 중복 좌표 제거
  (defun remove-dups-tol (lst tol / res)
    (foreach item lst
      (if (not (vl-some '(lambda (x) (equal item x tol)) res))
        (setq res (cons item res))
      )
    )
    (reverse res)
  )

  ;; 내부 함수: 시작점 기준으로 점들 정렬
  (defun sort-pts (pts startPt)
    (vl-sort pts '(lambda (p1 p2) (< (distance startPt p1) (distance startPt p2))))
  )

  (initget "1 2")
  (setq opt (getkword "\n작업 모드 선택 [형태 인식 닫힌 외곽선 생성(1) / 기존 외곽선 분할 업데이트(2)] <1>: "))
  (if (not opt) (setq opt "1"))

  (if (= opt "1")
    ;; ==========================================
    ;; [모드 1] 내부 잔선을 지우고 최외곽선 1개만 추출
    ;; ==========================================
    (progn
      (prompt "\n[모드 1] 외곽선을 감쌀 기둥 블록들을 모두 선택하세요 ('ㄱ', 'ㄷ', 'ㅁ' 형태 등): ")
      (if (setq ss (ssget '((0 . "INSERT"))))
        (progn
          (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
          (setq mspace (vla-get-ModelSpace doc))
          
          (setq i 0 col-data nil tol 0.1)
          ;; 1. 기둥 데이터 수집
          (while (< i (sslength ss))
            (setq obj (vlax-ename->vla-object (ssname ss i)))
            (vla-getboundingbox obj 'minPt 'maxPt)
            (setq ptMin (vlax-safearray->list minPt))
            (setq ptMax (vlax-safearray->list maxPt))
            (setq cx (/ (+ (car ptMin) (car ptMax)) 2.0))
            (setq cy (/ (+ (cadr ptMin) (cadr ptMax)) 2.0))
            (setq col-data (cons (list cx cy ptMin ptMax) col-data))
            (setq i (1+ i))
          )

          ;; 2. 가로/세로 그룹화
          (setq y-groups nil x-groups nil)
          (foreach col col-data
            (setq cy (cadr col) found nil)
            (foreach grp y-groups
              (if (< (abs (- (car grp) cy)) tol)
                (progn (setq y-groups (subst (append grp (list col)) grp y-groups)) (setq found t))
              )
            )
            (if (not found) (setq y-groups (cons (list cy col) y-groups)))
            
            (setq cx (car col) found nil)
            (foreach grp x-groups
              (if (< (abs (- (car grp) cx)) tol)
                (progn (setq x-groups (subst (append grp (list col)) grp x-groups)) (setq found t))
              )
            )
            (if (not found) (setq x-groups (cons (list cx col) x-groups)))
          )

          ;; 3. 최소 간격 계산
          (setq minDx 1e99 minDy 1e99)
          (foreach grp y-groups
            (setq cols (vl-sort (cdr grp) '(lambda (a b) (< (car a) (car b)))))
            (setq j 0)
            (while (< j (1- (length cols)))
              (setq dx (- (car (nth (1+ j) cols)) (car (nth j cols))))
              (if (and (> dx 1.0) (< dx minDx)) (setq minDx dx))
              (setq j (1+ j))
            )
          )
          (foreach grp x-groups
            (setq cols (vl-sort (cdr grp) '(lambda (a b) (< (cadr a) (cadr b)))))
            (setq j 0)
            (while (< j (1- (length cols)))
              (setq dy (- (cadr (nth (1+ j) cols)) (cadr (nth j cols))))
              (if (and (> dy 1.0) (< dy minDy)) (setq minDy dy))
              (setq j (1+ j))
            )
          )
          (if (= minDx 1e99) (setq minDx 1.0))
          (if (= minDy 1e99) (setq minDy 1.0))

          ;; 4. 연결 사각형 좌표 수집
          (setq bridge-coords nil)
          (foreach col col-data
            (setq pMin (nth 2 col) pMax (nth 3 col))
            (setq bridge-coords (cons (list (car pMin) (cadr pMin) (car pMax) (cadr pMax)) bridge-coords))
          )
          
          (foreach grp y-groups
            (setq cols (vl-sort (cdr grp) '(lambda (a b) (< (car a) (car b)))))
            (setq j 0)
            (while (< j (1- (length cols)))
              (setq col1 (nth j cols) col2 (nth (1+ j) cols))
              (setq dx (- (car col2) (car col1)))
              (if (<= dx (* minDx 1.5))
                (progn
                  (setq bMinX (car (nth 2 col1)) bMaxX (car (nth 3 col2))
                        bMinY (min (cadr (nth 2 col1)) (cadr (nth 2 col2)))
                        bMaxY (max (cadr (nth 3 col1)) (cadr (nth 3 col2))))
                  (setq bridge-coords (cons (list bMinX bMinY bMaxX bMaxY) bridge-coords))
                )
              )
              (setq j (1+ j))
            )
          )

          (foreach grp x-groups
            (setq cols (vl-sort (cdr grp) '(lambda (a b) (< (cadr a) (cadr b)))))
            (setq j 0)
            (while (< j (1- (length cols)))
              (setq col1 (nth j cols) col2 (nth (1+ j) cols))
              (setq dy (- (cadr col2) (cadr col1)))
              (if (<= dy (* minDy 1.5))
                (progn
                  (setq bMinX (min (car (nth 2 col1)) (car (nth 2 col2)))
                        bMaxX (max (car (nth 3 col1)) (car (nth 3 col2)))
                        bMinY (cadr (nth 2 col1)) bMaxY (cadr (nth 3 col2)))
                  (setq bridge-coords (cons (list bMinX bMinY bMaxX bMaxY) bridge-coords))
                )
              )
              (setq j (1+ j))
            )
          )

          ;; 5. Region 생성
          (setq ssReg (ssadd))
          (foreach br bridge-coords
            (setq pline (entmakex (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
                                        (list 10 (nth 0 br) (nth 1 br)) (list 10 (nth 2 br) (nth 1 br))
                                        (list 10 (nth 2 br) (nth 3 br)) (list 10 (nth 0 br) (nth 3 br)))))
            (setq vlaObj (vlax-ename->vla-object pline))
            (setq regArray (vlax-invoke mspace 'AddRegion (list vlaObj)))
            (if regArray (ssadd (vlax-vla-object->ename (car regArray)) ssReg))
            (entdel pline) 
          )

          ;; 6. Region 결합 (UNION)
          (setq cmdecho_save (getvar "CMDECHO"))
          (setvar "CMDECHO" 0)

          (if (> (sslength ssReg) 1)
            (progn
              (setq last-ent (entlast))
              (vl-cmdf "_.UNION" ssReg "")
              (setq union-ents (ssadd) curr-ent (if last-ent (entnext last-ent) (entnext)))
              (while curr-ent (ssadd curr-ent union-ents) (setq curr-ent (entnext curr-ent)))
              (if (= (sslength union-ents) 0) (setq union-ents ssReg))
            )
            (setq union-ents ssReg)
          )

          ;; 7. Region 분해 및 선 추출
          (setq explode-mark (entlast)) ; 분해 직전의 마지막 객체 기억
          (vl-cmdf "_.EXPLODE" union-ents) 
          (setq line-ents (ssadd) curr-ent (if explode-mark (entnext explode-mark) (entnext)))
          (while curr-ent
            (if (wcmatch (cdr (assoc 0 (entget curr-ent))) "LINE,ARC")
              (ssadd curr-ent line-ents)
            )
            (setq curr-ent (entnext curr-ent))
          )

          ;; 8. 폴리선 병합 및 최대 면적(최외곽선) 고르기
          (if (> (sslength line-ents) 0)
            (progn
              (setq pedit_save (getvar "PEDITACCEPT"))
              (setvar "PEDITACCEPT" 1)
              (vl-cmdf "_.PEDIT" "M" line-ents "" "J" "0.01" "")
              
              ;; PEDIT 이후 생성된 모든 폴리선 수집
              (setq final-plines nil)
              (setq curr-ent (if explode-mark (entnext explode-mark) (entnext)))
              (while curr-ent
                (if (entget curr-ent) ; 객체가 삭제되지 않고 존재하는지 확인
                  (if (= (cdr (assoc 0 (entget curr-ent))) "LWPOLYLINE")
                    (setq final-plines (cons curr-ent final-plines))
                  )
                )
                (setq curr-ent (entnext curr-ent))
              )

              ;; 면적을 비교하여 가장 큰 폴리선 1개만 남기고 나머지는 모두 삭제
              (if final-plines
                (progn
                  (setq max-area -1.0 max-pline nil)
                  (foreach pl final-plines
                    (setq vObj (vlax-ename->vla-object pl))
                    (vla-put-Closed vObj :vlax-true) ; 면적 계산을 위해 닫힘 속성 강제 부여
                    (setq area (vl-catch-all-apply 'vla-get-Area (list vObj)))
                    (if (not (vl-catch-all-error-p area))
                      (if (> area max-area)
                        (setq max-area area max-pline pl)
                      )
                    )
                  )
                  ;; 최대 면적이 아닌 내부 선은 모두 삭제
                  (foreach pl final-plines
                    (if (not (equal pl max-pline))
                      (entdel pl)
                    )
                  )
                )
              )
              (setvar "PEDITACCEPT" pedit_save)
            )
          )
          (setvar "CMDECHO" cmdecho_save)

          (princ "\n[완료] 내부 선을 지운 최외곽선 폴리선 1개를 만들었습니다. (MIO 사용 가능)")
        )
        (princ "\n기둥 블록이 선택되지 않았습니다.")
      )
    )
    ;; ==========================================
    ;; [모드 2] 기존 로직 유지 (사다리꼴 방지)
    ;; ==========================================
    (progn
      (prompt "\n[모드 2] 수정할 외곽선(폴리선 1개)과 기준 기둥 블록들을 한 번에 드래그하여 선택하세요: ")
      (if (setq ss (ssget '((0 . "LWPOLYLINE,INSERT"))))
        (progn
          (setq plineEnt nil blocks nil i 0)
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (if (= (cdr (assoc 0 (entget ent))) "LWPOLYLINE")
              (if (not plineEnt) (setq plineEnt ent))
              (setq blocks (cons ent blocks))
            )
            (setq i (1+ i))
          )
          
          (if (and plineEnt blocks)
            (progn
              (setq plineObj (vlax-ename->vla-object plineEnt))
              (setq pline-verts-list (vlax-get plineObj 'Coordinates))
              (setq original-verts nil)
              (while pline-verts-list
                (setq original-verts (cons (list (car pline-verts-list) (cadr pline-verts-list)) original-verts))
                (setq pline-verts-list (cddr pline-verts-list))
              )
              (setq original-verts (reverse original-verts))
              
              (setq boundary-segments nil i 0)
              (while (< i (1- (length original-verts)))
                (setq boundary-segments (cons (list (nth i original-verts) (nth (1+ i) original-verts)) boundary-segments))
                (setq i (1+ i))
              )
              (setq boundary-segments (cons (list (last original-verts) (car original-verts)) boundary-segments))
              (setq boundary-segments (reverse boundary-segments))

              (setq all-unique-perimeter-pts nil)
              
              (foreach b-seg boundary-segments
                (setq startPt (car b-seg) endPt (cadr b-seg))
                (setq pts-on-seg (list startPt endPt))
                
                (foreach blk blocks
                  (setq obj (vlax-ename->vla-object blk))
                  (vla-getboundingbox obj 'minPt 'maxPt)
                  (setq ptMin (vlax-safearray->list minPt))
                  (setq ptMax (vlax-safearray->list maxPt))
                  
                  (setq blk-verts (list ptMin (list (car ptMax) (cadr ptMin)) ptMax (list (car ptMin) (cadr ptMax))))
                  (setq blk-segments (list (list (nth 0 blk-verts) (nth 1 blk-verts)) (list (nth 1 blk-verts) (nth 2 blk-verts))
                                           (list (nth 2 blk-verts) (nth 3 blk-verts)) (list (nth 3 blk-verts) (nth 0 blk-verts))))
                  
                  (foreach blk-s blk-segments
                    (setq int-pt (inters startPt endPt (car blk-s) (cadr blk-s)))
                    (if int-pt (setq pts-on-seg (cons int-pt pts-on-seg)))
                  )
                )
                
                (setq sorted-pts (remove-dups-tol (sort-pts pts-on-seg startPt) 0.001))
                (setq sorted-pts (reverse (cdr (reverse sorted-pts))))
                (setq all-unique-perimeter-pts (append all-unique-perimeter-pts sorted-pts))
              )
              
              (setq final-verts nil)
              (foreach pt all-unique-perimeter-pts
                (setq final-verts (cons pt final-verts))
                (setq final-verts (cons pt final-verts))
              )
              (setq final-verts (reverse final-verts))
              
              (entmake
                (append
                  (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline")
                        (cons 90 (length final-verts)) '(70 . 1))
                  (mapcar '(lambda (pt) (cons 10 pt)) final-verts)
                )
              )
              
              (entdel plineEnt)
              (princ "\n[모드 2] 사다리꼴 방지용 '이중 정점'이 적용된 외곽선으로 업데이트되었습니다.")
            )
            (princ "\n수정할 폴리선 1개와 기준 기둥 블록들을 함께 선택해야 합니다.")
          )
        )
        (princ "\n객체가 선택되지 않았습니다.")
      )
    )
  )
  (princ)
)