(defun c:bplot ( / base_ent base_obj base_pt1 base_pt2 base_x ss i ent obj minpt maxpt pt1 pt2
                   entList y_sort_list txt_ss j txt_ent txt_obj h max_h final_name pdf_path dwg_path tol 
                   plotter_name is_pdf doc layout mode export_path export_ss origin_pt)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq layout (vla-get-ActiveLayout doc))
  (setq dwg_path (getvar "DWGPREFIX"))
  (setq tol 100.0)

  ;; 모드 선택
  (initget "1 2")
  (setq mode (getkword "\n작업 모드를 선택하세요 [1: 플롯/PDF 출력, 2: 개별 DWG 저장] <1>: "))
  (if (not mode) (setq mode "1")) ;; 기본값 1

  ;; 좌표계 초기화 (빈 출력 방지)
  (vl-cmdf "_.UCS" "_W")
  
  (if (= mode "1")
    (progn
      (vla-RefreshPlotDeviceInfo layout)
      (setq plotter_name (vla-get-ConfigName layout))
      (setq is_pdf (wcmatch (strcase plotter_name) "*PDF*"))
      (prompt (strcat "\n현재 장치: [" plotter_name "] / 기준 도곽 하나를 선택하세요: "))
    )
    (prompt "\n[DWG 저장 모드] 기준 도곽 하나를 선택하세요: ")
  )

  (if (setq base_ent (entsel))
    (progn
      (setq base_obj (vlax-ename->vla-object (car base_ent)))
      (vla-GetBoundingBox base_obj 'base_pt1 'base_pt2)
      (setq base_x (car (vlax-safearray->list base_pt1)))

      (if (= mode "1") (setvar "BACKGROUNDPLOT" 0))

      (if (setq ss (ssget "X" '((0 . "INSERT"))))
        (progn
          (setq i 0 entList nil)
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (setq obj (vlax-ename->vla-object ent))
            (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'minpt 'maxpt))))
              (progn
                (setq pt1 (vlax-safearray->list minpt))
                (setq pt2 (vlax-safearray->list maxpt))
                (if (< (abs (- (car pt1) base_x)) tol)
                  (setq entList (cons (list (cadr pt1) ent obj pt1 pt2) entList))
                )
              )
            )
            (setq i (1+ i))
          )

          (if entList
            (progn
              (setq y_sort_list (vl-sort entList '(lambda (a b) (< (car a) (car b)))))

              (setq i 0)
              (foreach item y_sort_list
                (setq obj (caddr item))
                (setq pt1 (cadddr item))
                (setq pt2 (nth 4 item))

                ;; ==========================================
                ;; 글자를 찾기 전에 그 도곽으로 화면을 먼저 이동
                ;; 화면에 객체가 보여야 캐드가 글씨를 인식할 수 있습니다.
                ;; ==========================================
                (vl-cmdf "_.ZOOM" "_W" pt1 pt2)

                ;; 파일명 추출 (가장 큰 텍스트 기준)
                (setq max_h 0.0 final_name (strcat "Output_" (itoa (1+ i))))
                (if (setq txt_ss (ssget "C" pt1 pt2 '((0 . "*TEXT"))))
                  (progn
                    (setq j 0)
                    (while (< j (sslength txt_ss))
                      (setq txt_ent (ssname txt_ss j))
                      (setq txt_obj (vlax-ename->vla-object txt_ent))
                      (setq h (vla-get-Height txt_obj))
                      (if (> h max_h)
                        (progn (setq max_h h) (setq final_name (vla-get-TextString txt_obj))))
                      (setq j (1+ j))
                    )
                  )
                )

                (if (= mode "1")
                  ;; [모드 1] 플롯 및 PDF 저장 로직
                  (progn
                    (setq pdf_path (strcat dwg_path final_name ".pdf"))
                    (if is_pdf
                      (if (= (getvar "TILEMODE") 1)
                        (vl-cmdf "_.-PLOT" "_Y" "" plotter_name "" "_M" "" "_N" "_W" pt1 pt2 "_F" "_C" "_Y" "" "_Y" "" pdf_path "_N" "_Y")
                        (vl-cmdf "_.-PLOT" "_Y" "" plotter_name "" "_M" "" "_N" "_W" pt1 pt2 "_F" "_C" "_Y" "" "_Y" "_N" "_N" pdf_path "_N" "_Y")
                      )
                      (if (= (getvar "TILEMODE") 1)
                        (vl-cmdf "_.-PLOT" "_Y" "" plotter_name "" "_M" "" "_N" "_W" pt1 pt2 "_F" "_C" "_Y" "" "_Y" "" "_N" "_N" "_Y")
                        (vl-cmdf "_.-PLOT" "_Y" "" plotter_name "" "_M" "" "_N" "_W" pt1 pt2 "_F" "_C" "_Y" "" "_Y" "_N" "_N" "_N" "_N" "_Y")
                      )
                    )
                    (if is_pdf
                      (princ (strcat "\nPDF 저장 완료: " final_name ".pdf"))
                      (princ (strcat "\n프린터 전송 완료: " final_name))
                    )
                  )
                  ;; [모드 2] 개별 DWG 원점 이동 파일 저장 로직
                  (progn
                    (setq export_path (strcat dwg_path final_name ".dwg"))
                    
                    ;; 동일한 이름의 파일 덮어쓰기 처리
                    (if (findfile export_path)
                      (vl-file-delete export_path)
                    )
                    
                    ;; 도곽 왼쪽 아래 모서리(pt1)의 Z를 0으로 고정해 원점 기준점 생성
                    (setq origin_pt (list (car pt1) (cadr pt1) 0.0))

                    (if (setq export_ss (ssget "C" pt1 pt2))
                      (progn
                        ;; 지정한 origin_pt가 새 파일의 0,0,0이 됨
                        (vl-cmdf "_.-WBLOCK" export_path "" "_non" origin_pt export_ss "")
                        ;; 추출 후 화면에서 지워진 객체 원상 복구
                        (vl-cmdf "_.OOPS")
                        (princ (strcat "\nDWG 원점(0,0,0) 저장 완료: " final_name ".dwg"))
                      )
                    )
                  )
                )

                (setq i (1+ i))
              )
              (vl-cmdf "_.ZOOM" "_E")
              (if (= mode "1")
                (prompt (strcat "\n[완료] 총 " (itoa i) "장의 도면을 출력했습니다."))
                (prompt (strcat "\n[완료] 총 " (itoa i) "장의 도면을 원점(0,0,0) 기준 개별 DWG로 저장했습니다."))
              )
            )
          )
        )
      )
    )
  )
  (princ)
)