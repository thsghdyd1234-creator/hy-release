;;; ==============================================================================
;;;  BPLOT — 도곽마다 PDF·출력 또는 DWG 파일로 한꺼번에
;;;
;;;  작업 [PDF·출력(1)/DWG 저장(2)] → 도곽 고르기 → (1) 출력 장치 → 저장 폴더 → 이름 목록을 보고 확인.
;;;   · 도곽 고르기: YGN 도곽(HY_TB_A1~A4, 세로는 _P)이 있으면 Enter = 모두. 도곽 블록 하나를 클릭하면 같은 이름 블록 모두,
;;;     S = 영역으로 고르기(그 안의 YGN 도곽, 없으면 고른 것 중 가장 큰 블록과 같은 이름). 지금 공간(모형 / 이 배치)의 도곽만.
;;;   · YGN 도곽은 블록 이름의 용지에 정확한 축척(블록 축척 = 1:N)으로, 여백 없는(full bleed) 용지에 뽑는다.
;;;     다른 도곽 블록은 용지에 맞춰(Fit) 뽑고, 도곽 방향에 맞춰 용지를 돌린다.
;;;   · 출력 장치: 지금 장치가 PDF(.pc3)면 그대로, 아니면 PDF(DWG To PDF.pc3)와 지금 장치 중에서 고른다.
;;;   · 파일 이름: 속성 '도면번호_도면명'(YGN 도곽은 NO · TITLE). 다른 블록은 그런 속성이 없으면 도곽 안에서 가장 큰 글자.
;;;     파일 이름에 못 쓰는 글자는 빼고, 같은 이름은 '이름 (2)'. 다른 프로그램에서 열려 있어 덮어쓸 수 없는 파일도 '이름 (2)'로.
;;;   · 저장 폴더는 YGN CAD 패널(HYPDF)과 같다 — 도면 폴더\출력. 다른 폴더로 바꾸면 이 도면에 기억한다(도면 사전 HY_CAD).
;;;   · DWG 저장은 도곽 왼쪽 아래를 원점(0,0,0)으로, 도곽에 걸친 객체를 담는다 (꺼진·동결 레이어 객체는 빠짐, 잠긴 레이어는 들어감).
;;;   · 페이지 설정 · BACKGROUNDPLOT · UCS · 화면 · 레이어 잠금은 끝나면(ESC 때도) 원래대로.
;;; ==============================================================================

(defun bplot:ename (o)
  (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))

;; HY_TB_<용지>(_P) → 그 방향의 종이 (가로 세로 mm). 도곽이 아니면 nil (방위표 HY_TB_NORTH · 축척 막대 HY_TB_BAR_* 도 nil)
(defun bplot:hy-paper (name / u p)
  (setq u (strcase name))
  (if (and (wcmatch u "HY_TB_A#,HY_TB_A#_P")
           (setq p (cdr (assoc (substr u 7 2) '(("A4" 297.0 210.0) ("A3" 420.0 297.0) ("A2" 594.0 420.0) ("A1" 841.0 594.0))))))
    (if (wcmatch u "*_P") (list (cadr p) (car p)) p)))

(defun bplot:box (o / a b)
  (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
    (list (vlax-safearray->list a) (vlax-safearray->list b))))

;; 블록 참조 → 도곽 (ename 블록이름 (x1 y1 x2 y2) 종이 축척 속성들), 돌리거나 뒤집은 YGN 도곽은 'ROT
;; 종이 · 축척은 YGN 도곽만 (다른 블록은 nil). 속성들 = ((태그 값 높이) …)
(defun bplot:frame (e / o nm p sx rot ins b atts)
  (setq o (vlax-ename->vla-object e) nm (bplot:ename o) p (bplot:hy-paper nm))
  (if (= (vla-get-HasAttributes o) :vlax-true)
    (foreach a (vlax-invoke o 'GetAttributes)
      (setq atts (cons (list (strcase (vla-get-TagString a)) (vla-get-TextString a) (vla-get-Height a)) atts))))
  (setq atts (reverse atts) sx (vla-get-XScaleFactor o) rot (vla-get-Rotation o))
  (cond
    ((and p (> sx 0.0) (or (equal rot 0.0 1e-6) (equal rot (* 2 pi) 1e-6)))
     (setq ins (vlax-get o 'InsertionPoint))
     (list e nm (list (car ins) (cadr ins) (+ (car ins) (* (car p) sx)) (+ (cadr ins) (* (cadr p) sx))) p sx atts))
    (p 'ROT)
    ((setq b (bplot:box o))
     (list e nm (list (car (car b)) (cadr (car b)) (car (cadr b)) (cadr (cadr b))) nil nil atts))))

;; 지금 공간의 블록 참조 중 도곽 → 도곽 목록 ('ROT 섞임)
;; nm = 이 이름의 블록 (nil = YGN 도곽 모두) · ss = 이 안에서만 (nil = 지금 공간 전체)
(defun bplot:collect (space nm ss / i e en out)
  (if (null ss) (setq ss (ssget "_X" (list '(0 . "INSERT") (cons 410 space)))))
  (if ss
    (repeat (setq i (sslength ss))
      (setq e (ssname ss (setq i (1- i))) en (bplot:ename (vlax-ename->vla-object e)))
      (if (if nm (= (strcase en) (strcase nm)) (bplot:hy-paper en))
        (setq out (cons (bplot:frame e) out)))))
  out)

;; 고른 것 중 가장 큰 블록의 이름
(defun bplot:biggest (ss / i o b a big ba)
  (setq i 0 ba 0.0)
  (repeat (sslength ss)
    (setq o (vlax-ename->vla-object (ssname ss i)) i (1+ i))
    (if (and (setq b (bplot:box o))
             (> (setq a (* (- (car (cadr b)) (car (car b))) (- (cadr (cadr b)) (cadr (car b))))) ba))
      (setq ba a big (bplot:ename o))))
  big)

;; 놓인 순: 줄(위 → 아래), 줄 안은 왼쪽부터. 세로로 겹치면 같은 줄 (YGN CAD HYPDF 와 같은 규칙)
(defun bplot:sort (frs / rest out top b mid row)
  (setq rest (vl-sort frs (function (lambda (a c)
                                      (if (equal (cadddr (nth 2 a)) (cadddr (nth 2 c)) 1e-6)
                                        (< (car (nth 2 a)) (car (nth 2 c)))
                                        (> (cadddr (nth 2 a)) (cadddr (nth 2 c))))))))
  (while rest
    (setq top (car rest) b (nth 2 top) mid (+ (cadr b) (* 0.5 (- (cadddr b) (cadr b))))
          row (vl-remove-if-not (function (lambda (f) (or (eq f top)
                                                          (and (>= (cadddr (nth 2 f)) mid) (<= (cadr (nth 2 f)) (- (cadddr b) 1e-9))))))
                                rest)
          rest (vl-remove-if (function (lambda (f) (member f row))) rest)
          out (append out (vl-sort row (function (lambda (a c) (< (car (nth 2 a)) (car (nth 2 c)))))))))
  out)

;; ── 이름 ─────────────────────────────────────────────────
;; 지금 공간의 글자 → ((x y 높이 글) …)
(defun bplot:texts (space / ss i ed p s out)
  (if (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 space))))
    (repeat (setq i (sslength ss))
      (setq ed (entget (ssname ss (setq i (1- i)))))
      (if (= (cdr (assoc 0 ed)) "TEXT")
        (setq p (trans (cdr (assoc 10 ed)) (cdr (assoc -1 ed)) 0) s (cdr (assoc 1 ed)))
        (setq p (cdr (assoc 10 ed)) s (bplot:unmtext (bplot:mtext ed))))
      (setq out (cons (list (car p) (cadr p) (cdr (assoc 40 ed)) s) out))))
  out)

(defun bplot:mtext (ed / s)
  (setq s "")
  (foreach g ed (if (= (car g) 3) (setq s (strcat s (cdr g)))))
  (strcat s (cdr (assoc 1 ed))))

;; \U+XXXX → 글자
(defun bplot:uchar (h / n k c)
  (setq n 0 k 1)
  (while (<= k (strlen h))
    (setq c (ascii (strcase (substr h k 1)))
          n (+ (* n 16) (cond ((<= 48 c 57) (- c 48)) ((<= 65 c 70) (- c 55)) (T 0)))
          k (1+ k)))
  (setq c (vl-catch-all-apply 'chr (list n)))
  (if (or (= n 0) (vl-catch-all-error-p c)) "" c))

;; MTEXT 서식 코드 벗기기: \P 줄바꿈 → 빈칸, \f…; \H…; 같은 설정은 빼고, 쌓은 글 \S1^2; → 1/2, 중괄호는 뺌
(defun bplot:unmtext (s / out i n c d j)
  (setq out "" i 1 n (strlen s))
  (while (<= i n)
    (setq c (substr s i 1))
    (cond
      ((and (= c "\\") (< i n))
       (setq d (substr s (1+ i) 1))
       (cond
         ((member d '("P" "X" "~")) (setq out (strcat out " ") i (+ i 2)))
         ((member d '("f" "F" "H" "W" "Q" "T" "C" "c" "A" "p"))
          (setq j (vl-string-search ";" s i) i (if j (+ j 2) (1+ n))))
         ((member d '("L" "l" "O" "o" "K" "k" "N")) (setq i (+ i 2)))
         ((= d "S")
          (setq j (vl-string-search ";" s i)
                out (strcat out (vl-string-translate "^#" "//" (substr s (+ i 2) (- (if j (1+ j) (1+ n)) (+ i 2)))))
                i (if j (+ j 2) (1+ n))))
         ((and (= d "U") (= (substr s (+ i 2) 1) "+"))
          (setq out (strcat out (bplot:uchar (substr s (+ i 3) 4))) i (+ i 7)))
         (T (setq out (strcat out d) i (+ i 2)))))
      ((member c '("{" "}")) (setq i (1+ i)))
      (T (setq out (strcat out c) i (1+ i)))))
  out)

;; 글자 특수 코드 %%c %%d %%p (지름 · 도 · 플러스마이너스), %%u %%o %%k (밑줄 · 윗줄 · 취소선) 는 뺌
(defun bplot:pct (s)
  (foreach pr '(("%%C" . "Ø") ("%%c" . "Ø") ("%%D" . "°") ("%%d" . "°") ("%%P" . "±") ("%%p" . "±")
                ("%%U" . "") ("%%u" . "") ("%%O" . "") ("%%o" . "") ("%%K" . "") ("%%k" . ""))
    (while (vl-string-search (car pr) s) (setq s (vl-string-subst (cdr pr) (car pr) s))))
  s)

;; 파일 이름에 쓸 수 있게: 못 쓰는 글자 \ / : * ? " < > | 와 제어 문자는 빈칸, 빈칸은 하나로, 끝의 점·빈칸은 뺌, 100자까지
(defun bplot:clean (s / out i c)
  (setq out "" i 1 s (bplot:pct s))
  (while (<= i (strlen s))
    (setq c (substr s i 1) i (1+ i)
          out (strcat out (if (or (< (ascii c) 32) (member c '("\\" "/" ":" "*" "?" "\"" "<" ">" "|"))) " " c))))
  (while (vl-string-search "  " out) (setq out (vl-string-subst " " "  " out)))
  (setq out (vl-string-right-trim ". " (vl-string-left-trim " " out)))
  (if (> (strlen out) 100) (setq out (vl-string-right-trim ". " (substr out 1 100))))
  out)

;; 속성 중 tags 의 첫 값 (비어 있지 않은 것, 정리해서)
(defun bplot:attr (atts tags / r x)
  (foreach tg tags
    (if (and (null r) (setq x (assoc tg atts)) (/= (bplot:clean (cadr x)) "")) (setq r (bplot:clean (cadr x)))))
  r)

;; 도곽 이름: 속성 도면번호_도면명 → (YGN 도곽이 아니면) 도곽 안에서 가장 큰 글자(속성 포함) → nil
(defun bplot:name (fr texts / atts b no ti best)
  (setq atts (nth 5 fr) b (nth 2 fr)
        no (bplot:attr atts '("NO" "DWGNO" "DWG_NO" "SHEETNO" "SHEET_NO" "도면번호"))
        ti (bplot:attr atts '("TITLE" "DWGNAME" "DWG_NAME" "DWGTITLE" "DWG_TITLE" "DRAWING_TITLE" "도면명" "도면이름")))
  (cond
    ((and no ti) (strcat no "_" ti))
    (no)
    (ti)
    ((nth 3 fr) nil)                                        ; YGN 도곽은 번호·도면명만 (HYPDF 와 같은 이름)
    (T
     (foreach a atts
       (if (and (/= (bplot:clean (cadr a)) "") (or (null best) (> (caddr a) (car best))))
         (setq best (list (caddr a) (cadr a)))))
     (foreach x texts
       (if (and (<= (car b) (car x) (caddr b)) (<= (cadr b) (cadr x) (cadddr b))
                (/= (bplot:clean (cadddr x)) "") (or (null best) (> (caddr x) (car best))))
         (setq best (list (caddr x) (cadddr x)))))
     (if best (bplot:clean (cadr best))))))

;; 같은 이름은 '이름 (2)' … (대소문자 무시)
(defun bplot:unique (names / used out cur k)
  (foreach n names
    (setq cur n k 1)
    (while (member (strcase cur) used) (setq k (1+ k) cur (strcat n " (" (itoa k) ")")))
    (setq used (cons (strcase cur) used) out (cons cur out)))
  (reverse out))

;; 목록에 보일 용지·축척 "(A3 1:100)" — YGN 도곽만
(defun bplot:info (f / u)
  (if (nth 3 f)
    (progn
      (setq u (strcase (nth 1 f)))
      (strcat "  (" (substr u 7 2) (if (wcmatch u "*_P") " 세로" "") " 1:"
              (rtos (nth 4 f) 2 (if (equal (nth 4 f) (fix (nth 4 f)) 1e-9) 0 2)) ")"))
    ""))

(defun bplot:join (lst / s k)
  (setq s "" k 0)
  (foreach x lst
    (setq k (1+ k))
    (if (<= k 5) (setq s (strcat s (if (= s "") "" ", ") x))))
  (if (> k 5) (strcat s " …") s))

;; ── 폴더 · 파일 ──────────────────────────────────────────
(defun bplot:split (s d / i out)
  (while (setq i (vl-string-search d s))
    (setq out (cons (substr s 1 i) out) s (substr s (+ i 1 (strlen d)))))
  (reverse (cons s out)))

(defun bplot:dir (s)
  (if (and s (/= (setq s (vl-string-trim " \"" s)) ""))
    (strcat (vl-string-right-trim "\\/" s) "\\")))

(defun bplot:mkdirs (path / cur)
  (foreach p (bplot:split (vl-string-right-trim "\\" path) "\\")
    (setq cur (if cur (strcat cur "\\" p) p))
    (if (and (/= p "") (not (vl-file-directory-p cur))) (vl-mkdir cur)))
  (vl-file-directory-p (vl-string-right-trim "\\" path)))

;; 도면 사전 HY_CAD 의 글 (YGN CAD 패널과 같이 쓴다)
(defun bplot:nod-get (key / d x)
  (if (and (setq d (dictsearch (namedobjdict) "HY_CAD"))
           (setq x (dictsearch (cdr (assoc -1 d)) key)))
    (cdr (assoc 1 x))))

(defun bplot:nod-put (key val / d dn x)
  (setq dn (if (setq d (dictsearch (namedobjdict) "HY_CAD"))
             (cdr (assoc -1 d))
             (dictadd (namedobjdict) "HY_CAD" (entmakex '((0 . "DICTIONARY") (100 . "AcDbDictionary"))))))
  (if dn
    (if (setq x (dictsearch dn key))
      (entmod (if (assoc 1 x) (subst (cons 1 val) (assoc 1 x) x) (append x (list (cons 1 val)))))
      (dictadd dn key (entmakex (list '(0 . "XRECORD") '(100 . "AcDbXrecord") (cons 1 val)))))))

;; 기본 저장 폴더: 도면 폴더\출력 (저장 안 한 새 도면은 문서\hy 출력) — YGN CAD 패널과 같음
(defun bplot:base-folder ()
  (if (= (getvar "DWGTITLED") 1)
    (strcat (getvar "DWGPREFIX") "출력\\")
    (strcat (vl-string-right-trim "\\" (cond ((getvar "MYDOCUMENTSPREFIX")) ((getenv "USERPROFILE")) ("C:"))) "\\hy 출력\\")))

;; 폴더 찾아보기 창 → 폴더 / nil
(defun bplot:browse ( / sh f p hw)
  (setq hw (vl-catch-all-apply 'vla-get-HWND (list (vlax-get-acad-object))))
  (setq sh (vl-catch-all-apply 'vlax-create-object (list "Shell.Application")))
  (if (and sh (not (vl-catch-all-error-p sh)))
    (progn
      (setq f (vl-catch-all-apply 'vlax-invoke-method (list sh 'BrowseForFolder (if (vl-catch-all-error-p hw) 0 hw) "저장할 폴더를 고르세요" 65)))
      (if (vl-catch-all-error-p f)
        (setq f (vl-catch-all-apply 'vlax-invoke-method (list sh 'BrowseForFolder 0 "저장할 폴더를 고르세요" 65))))
      (if (and f (not (vl-catch-all-error-p f)))
        (setq p (vl-catch-all-apply (function (lambda () (vlax-get-property (vlax-get-property f 'Self) 'Path))) nil)))
      (vl-catch-all-apply 'vlax-release-object (list sh))))
  (if (= (type p) 'STR) (bplot:dir p)))

;; 저장 폴더 묻기: Enter = 그대로, 경로를 치면 그 폴더(상대 경로는 도면 폴더 기준), B = 찾아보기
(defun bplot:ask-folder (def / s)
  (setq s (vl-string-trim " \"" (getstring T (strcat "\n저장 폴더 (경로를 치면 바꿈 · B = 찾아보기) <" def ">: "))))
  (cond
    ((= s "") def)
    ((member (strcase s) '("B" "ㅠ")) (cond ((bplot:browse)) (def)))
    ((or (wcmatch s "?:*") (wcmatch s "\\\\*")) (bplot:dir s))
    (T (bplot:dir (strcat (getvar "DWGPREFIX") s)))))

;; 파일 자리: 없으면 그대로, 있으면 지우고, 지울 수 없으면(열려 있음) '이름 (2)' … · taken = 이번에 이미 쓴 파일
(defun bplot:target (folder name ext taken / k p)
  (setq k 1 p (strcat folder name ext))
  (while (and (< k 50) (or (member (strcase p) taken) (and (findfile p) (not (vl-file-delete p)))))
    (setq k (1+ k) p (strcat folder name " (" (itoa k) ")" ext)))
  p)

;; ── 출력 설정 ────────────────────────────────────────────
(defun bplot:pt2 (x y)
  (vlax-make-variant (vlax-safearray-fill (vlax-make-safearray vlax-vbDouble '(0 . 1)) (list x y))))

;; 장치 · 용지 · 스타일 목록 — 못 읽으면 nil
(defun bplot:names (lo fn / r)
  (setq r (vl-catch-all-apply (function (lambda () (vlax-safearray->list (vlax-variant-value (apply fn (list lo)))))) nil))
  (if (vl-catch-all-error-p r) nil r))

(defun bplot:pdf-p (dev) (and dev (wcmatch (strcase dev) "*PDF*.PC3")))

;; PDF 장치: DWG To PDF.pc3 → AutoCAD PDF*.pc3 → 이름에 PDF 가 든 다른 .pc3
(defun bplot:pdf-device (lo / devs)
  (setq devs (bplot:names lo 'vla-GetPlotDeviceNames))
  (cond ((car (vl-member-if (function (lambda (d) (= (strcase d) "DWG TO PDF.PC3"))) devs)))
        ((car (vl-member-if (function (lambda (d) (wcmatch (strcase d) "AUTOCAD PDF*.PC3"))) devs)))
        ((car (vl-member-if 'bplot:pdf-p devs)))))

;; "ISO_full_bleed_A3_(420.00_x_297.00_MM)" → (420.0 297.0), 인치 용지는 mm 로
(defun bplot:media-mm (nm / k a s x)
  (setq k (cond ((wcmatch (strcase nm) "*_MM)") 1.0) ((wcmatch (strcase nm) "*_INCHES)") 25.4)))
  (if (and k (setq a (vl-string-position (ascii "(") nm nil T)))
    (progn
      (setq s (substr nm (+ a 2)))
      (if (setq x (vl-string-search "_x_" s))
        (list (* k (atof (substr s 1 x))) (* k (atof (substr s (+ x 4)))))))))

;; 종이 w×h 에 맞는 용지 → (용지 회전 정확) · 같은 방향 여백 없음 → 반대 방향 여백 없음(90°) → 같은 크기 여백 있음 → nil
(defun bplot:pick-media (names w h / mm full same swap same2 swap2)
  (foreach nm names
    (if (setq mm (bplot:media-mm nm))
      (progn
        (setq full (wcmatch (strcase nm) "*FULL_BLEED*"))
        (cond
          ((and (equal (car mm) w 1.0) (equal (cadr mm) h 1.0))
           (if full (if (null same) (setq same nm)) (if (null same2) (setq same2 nm))))
          ((and (equal (car mm) h 1.0) (equal (cadr mm) w 1.0))
           (if full (if (null swap) (setq swap nm)) (if (null swap2) (setq swap2 nm))))))))
  (cond (same (list same 0 T)) (swap (list swap 1 T)) (same2 (list same2 0 nil)) (swap2 (list swap2 1 nil))))

;; 맞춰 뽑을 때 용지: 원래 용지가 그 장치에 있으면 그대로, 없으면 A3 (여백 없음 먼저), 그것도 없으면 첫 용지
(defun bplot:general-media (media orig)
  (cond ((member orig media) orig)
        ((car (bplot:pick-media media 420.0 297.0)))
        ((car media))))

;; 지금 용지가 도곽과 방향이 다르면 90° (1), 같으면 0
(defun bplot:rot-for (lo fw fh / mm pw ph)
  (setq mm (bplot:media-mm (vla-get-CanonicalMediaName lo)))
  (if (and (null mm) (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetPaperSize (list lo 'pw 'ph)))))
    (setq mm (list pw ph)))
  (if (and mm (numberp (car mm)) (numberp (cadr mm)) (not (eq (> (car mm) (cadr mm)) (> fw fh)))) 1 0))

;; 페이지 설정의 출력 스타일이 이 PC 에 없으면 흑백(monochrome)으로, 그것도 없으면 스타일 없이 → 알림 글 / nil
(defun bplot:check-style (lo / st names want mono)
  (setq st (vla-get-StyleSheet lo))
  (if (and (/= st "") (setq names (bplot:names lo 'vla-GetPlotStyleTableNames))
           (not (member (strcase st) (mapcar 'strcase names))))
    (progn
      (setq want (if (= (getvar "PSTYLEMODE") 1) "MONOCHROME.CTB" "MONOCHROME.STB")
            mono (car (vl-member-if (function (lambda (n) (= (strcase n) want))) names)))
      (vl-catch-all-apply 'vla-put-StyleSheet (list lo (if mono mono "")))
      (strcat "출력 스타일 " st " 이(가) 이 PC 에 없어 " (if mono (strcat mono " 로") "스타일 없이") " 뽑았습니다"))))

;; 페이지 설정 저장 · 되돌리기 (출력은 지금 배치의 페이지 설정을 잠시 바꿔서 한다)
(defun bplot:pc-save (lo / n d ll ur)
  (vl-catch-all-apply 'vla-GetCustomScale (list lo 'n 'd))
  (vl-catch-all-apply 'vla-GetWindowToPlot (list lo 'll 'ur))
  (list (vla-get-ConfigName lo) (vla-get-CanonicalMediaName lo) (vla-get-PaperUnits lo) (vla-get-PlotRotation lo)
        (vla-get-PlotType lo) (vla-get-UseStandardScale lo) (vla-get-StandardScale lo) n d (vla-get-CenterPlot lo)
        (vla-get-PlotOrigin lo) (vla-get-StyleSheet lo) ll ur))

(defun bplot:pc-restore (lo s)
  (vl-catch-all-apply 'vla-put-ConfigName (list lo (nth 0 s)))
  (vl-catch-all-apply 'vla-RefreshPlotDeviceInfo (list lo))
  (vl-catch-all-apply 'vla-put-CanonicalMediaName (list lo (nth 1 s)))
  (vl-catch-all-apply 'vla-put-PaperUnits (list lo (nth 2 s)))
  (vl-catch-all-apply 'vla-put-PlotRotation (list lo (nth 3 s)))
  (vl-catch-all-apply 'vla-put-StyleSheet (list lo (nth 11 s)))
  (if (and (nth 7 s) (nth 8 s)) (vl-catch-all-apply 'vla-SetCustomScale (list lo (nth 7 s) (nth 8 s))))
  (vl-catch-all-apply 'vla-put-UseStandardScale (list lo (nth 5 s)))
  (if (= (nth 5 s) :vlax-true) (vl-catch-all-apply 'vla-put-StandardScale (list lo (nth 6 s))))
  (vl-catch-all-apply 'vla-put-CenterPlot (list lo (nth 9 s)))
  (vl-catch-all-apply 'vla-put-PlotOrigin (list lo (nth 10 s)))
  (if (and (nth 12 s) (nth 13 s)) (vl-catch-all-apply 'vla-SetWindowToPlot (list lo (nth 12 s) (nth 13 s))))
  (vl-catch-all-apply 'vla-put-PlotType (list lo (nth 4 s))))

;; 도곽 하나 출력 → T (정확한 축척 또는 다른 블록) · 'FIT (YGN 도곽인데 맞는 용지가 없어 맞춰 뽑음) · nil (실패)
;; path = PDF 파일 (nil = 장치로 출력)
(defun bplot:plot1 (lo plot fr media gmedia path / b fw fh pk fit p1 p2 r)
  (setq b (nth 2 fr) fw (- (caddr b) (car b)) fh (- (cadddr b) (cadr b))
        pk (if (nth 3 fr) (bplot:pick-media media (car (nth 3 fr)) (cadr (nth 3 fr)))))
  (setq fit (and (nth 3 fr) (not (caddr pk))))
  (if (null pk) (setq pk (list gmedia nil nil)))
  (if (car pk) (vl-catch-all-apply 'vla-put-CanonicalMediaName (list lo (car pk))))
  (vla-put-PlotRotation lo (if (cadr pk) (cadr pk) (bplot:rot-for lo fw fh)))
  ;; 창은 화면 좌표(DCS)로 — 평면 보기면 월드와 같은 방향
  (setq p1 (trans (list (car b) (cadr b) 0.0) 0 2) p2 (trans (list (caddr b) (cadddr b) 0.0) 0 2))
  (vla-SetWindowToPlot lo (bplot:pt2 (min (car p1) (car p2)) (min (cadr p1) (cadr p2)))
                          (bplot:pt2 (max (car p1) (car p2)) (max (cadr p1) (cadr p2))))
  (vla-put-PlotType lo 4)                                   ; acWindow
  (if (caddr pk)
    (progn (vla-SetCustomScale lo 1.0 (nth 4 fr)) (vla-put-UseStandardScale lo :vlax-false))
    (progn (vla-put-UseStandardScale lo :vlax-true) (vla-put-StandardScale lo 0)))   ; acScaleToFit
  (vla-put-CenterPlot lo :vlax-true)
  (if path
    (progn
      (setq r (vl-catch-all-apply 'vla-PlotToFile (list plot path)))
      (if (and (not (findfile path)) (findfile (strcat path ".pdf"))) (vl-file-rename (strcat path ".pdf") path))
      (setq r (and (findfile path) T)))
    (progn
      (setq r (vl-catch-all-apply 'vla-PlotToDevice (list plot)))
      (setq r (and (not (vl-catch-all-error-p r)) (/= r :vlax-false)))))
  (cond ((not r) nil) (fit 'FIT) (T T)))

;; 평면 보기인지 (종이 공간은 늘 참). 아니면 평면(PLAN 표준)으로 바꿀지 묻는다
(defun bplot:plan-ok ( / k)
  (cond
    ((= (getvar "CVPORT") 1) T)
    ((and (equal (trans '(1.0 0.0 0.0) 0 2 T) '(1.0 0.0 0.0) 1e-8) (equal (trans '(0.0 0.0 1.0) 0 2 T) '(0.0 0.0 1.0) 1e-8)) T)
    (T
     (initget "Yes No")
     (setq k (getkword "\n[주의] 화면이 평면 보기가 아닙니다 (시점·화면 회전). 평면 보기(PLAN 표준)로 바꿀까요? [예(Y)/아니오(N)] <Y>: "))
     (if (/= k "No") (progn (command "_.PLAN" "_W") T)))))

;; ── 명령 ─────────────────────────────────────────────────
(defun c:BPLOT ( / *error* doc lo plot sv pcs ucs_changed vctr vsize undo_open wb_ss locked
                   k mode space hys n sel ss frs why rot texts names i dev pdf outdev base mem folder ext
                   exist media gmedia nm path r ok fail fits notes taken b m cnt)
  (defun *error* (msg)
    ;; WBLOCK 이 지운 객체가 그대로면 되살림
    (if (and wb_ss (ssname wb_ss 0) (null (entget (ssname wb_ss 0)))) (command-s "_.OOPS"))
    (setq wb_ss nil)
    (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
    (setq locked nil)
    (if pcs (progn (bplot:pc-restore lo pcs) (setq pcs nil)))
    (if plot (vl-catch-all-apply 'vla-put-QuietErrorMode (list plot :vlax-false)))
    (if ucs_changed (progn (command-s "_.UCS" "_P") (setq ucs_changed nil)))
    (if vctr (progn (command-s "_.ZOOM" "_C" "_non" (trans vctr 0 1) vsize) (setq vctr nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (setq sv nil)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (cond
    ((and (= (getvar "TILEMODE") 0) (/= (getvar "CVPORT") 1))
     (princ "\n[주의] 배치의 모형 창 안에서는 실행할 수 없습니다. 종이 공간(PSPACE)이나 모형 탭에서 실행하세요."))
    ((not (bplot:plan-ok)) (princ "\n평면 보기가 아니어서 그만두었습니다."))
    (T
     (initget "1 2")
     (setq k (cond ((getenv "HyBplotMode")) ("1"))
           mode (cond ((getkword (strcat "\n작업 [PDF·출력(1)/DWG 저장(2)] <" k ">: "))) (k)))
     (setenv "HyBplotMode" mode)
     (setq space (if (= (getvar "TILEMODE") 1) "Model" (getvar "CTAB"))
           hys (bplot:collect space nil nil)
           n (length (vl-remove 'ROT hys)))
     ;; 도곽 고르기
     (setvar "ERRNO" 0)
     (while (progn (initget "Select")
                   (setq sel (entsel (strcat "\n도곽 블록을 클릭하세요 [영역으로 고르기(S)]"
                                             (if (> n 0) (strcat " <YGN 도곽 " (itoa n) "장 모두>: ") ": "))))
                   (and (null sel) (= (getvar "ERRNO") 7)))
       (princ "\n빗나갔습니다. 다시 클릭하세요.")
       (setvar "ERRNO" 0))
     (cond
       ((= (type sel) 'STR)
        (prompt "\n도곽이 든 영역을 고르세요: ")
        (if (setq ss (ssget '((0 . "INSERT"))))
          (setq frs (cond ((bplot:collect space nil ss)) ((bplot:collect space (bplot:biggest ss) ss))))))
       ((and sel (/= (cdr (assoc 0 (entget (car sel)))) "INSERT"))
        (setq why "\n[주의] 도곽은 블록이어야 합니다."))
       (sel (setq frs (bplot:collect space (bplot:ename (vlax-ename->vla-object (car sel))) nil)))
       (T (setq frs hys)))
     (setq rot (length (vl-remove-if-not (function (lambda (x) (eq x 'ROT))) frs))
           frs (vl-remove 'ROT frs))
     (cond
       (why (princ why))
       ((null frs)
        (princ (cond ((> rot 0) (strcat "\n[주의] 돌려 놓은 YGN 도곽 " (itoa rot) "장은 출력하지 않습니다 (회전 0° 인 도곽만)."))
                     ((and (null sel) (= n 0)) "\n도곽을 고르지 않았습니다.")
                     (T "\n[주의] 고른 것 중에 도곽 블록이 없습니다."))))
       (T
        (setq frs (bplot:sort frs)
              texts (if (vl-remove-if (function (lambda (f) (nth 3 f))) frs) (bplot:texts space))
              i 0)
        (foreach f frs
          (setq i (1+ i) names (cons (cond ((bplot:name f texts)) ((strcat "도곽_" (if (< i 10) "0" "") (itoa i)))) names)))
        (setq names (bplot:unique (reverse names))
              lo (vla-get-ActiveLayout doc) plot (vla-get-Plot doc))
        ;; 출력 장치
        (if (= mode "1")
          (progn
            (vl-catch-all-apply 'vla-RefreshPlotDeviceInfo (list lo))
            (setq dev (vla-get-ConfigName lo))
            (cond
              ((bplot:pdf-p dev) (setq pdf dev))
              ((setq pdf (bplot:pdf-device lo))
               (if (not (wcmatch (strcase dev) "NONE,없음,*없음*"))
                 (progn
                   (initget "1 2")
                   (if (= (getkword (strcat "\n지금 출력 장치는 " dev " 입니다. [PDF로 저장(1)/이 장치로 출력(2)] <1>: ")) "2")
                     (setq pdf nil))))))
            (setq outdev (cond (pdf) ((not (wcmatch (strcase dev) "NONE,없음,*없음*")) dev)))))
        (cond
          ((and (= mode "1") (null outdev))
           (princ "\n[주의] 출력 장치가 없습니다. PDF 장치(DWG To PDF.pc3)도 찾지 못했습니다. 페이지 설정 관리자에서 장치를 고르세요."))
          ((and (or pdf (= mode "2"))
                (progn (setq base (bplot:base-folder) mem (bplot:dir (bplot:nod-get "plot_folder"))
                             folder (bplot:ask-folder (cond (mem) (base))))
                       (not (bplot:mkdirs folder))))
           (princ (strcat "\n[주의] 폴더를 만들 수 없습니다: " folder)))
          ((progn
             (setq ext (if (= mode "2") ".dwg" ".pdf") i 0)
             (princ (strcat "\n도곽 " (itoa (length frs)) "장:"))
             (foreach nm names
               (if (<= (setq i (1+ i)) 30) (princ (strcat "\n  " (itoa i) ". " nm (if (= mode "1") (bplot:info (nth (1- i) frs)) "")))))
             (if (> i 30) (princ (strcat "\n  … 외 " (itoa (- i 30)) "장")))
             (setq exist (if folder (length (vl-remove-if-not (function (lambda (x) (findfile (strcat folder x ext)))) names)) 0))
             (princ (strcat "\n" (cond ((= mode "2") (strcat "DWG " (itoa (length frs)) "개를 " folder " 에 저장합니다 (도곽 왼쪽 아래 = 원점)."))
                                       (pdf (strcat "PDF " (itoa (length frs)) "장을 " folder " 에 저장합니다."))
                                       (T (strcat (itoa (length frs)) "장을 " outdev " (으)로 출력합니다.")))
                            (if (> exist 0) (strcat " 같은 이름 파일 " (itoa exist) "개는 덮어씁니다.") "")))
             (initget "Yes No")
             (= (getkword "\n계속할까요? [예(Y)/아니오(N)] <Y>: ") "No"))
           (princ "\n그만두었습니다."))
          (T
           (setq ok 0)
           (vla-StartUndoMark doc)
           (setq undo_open T)
           (if (= mode "1")
             ;; PDF · 출력 — 페이지 설정을 잠시 바꿔 ActiveX 로 (명령 질문 순서에 기대지 않음)
             (progn
               (setq sv (mapcar (function (lambda (v) (cons v (getvar v)))) '("BACKGROUNDPLOT" "CMDECHO")))
               (setvar "BACKGROUNDPLOT" 0)
               (setvar "CMDECHO" 0)
               (setq pcs (bplot:pc-save lo))
               (vl-catch-all-apply 'vla-put-QuietErrorMode (list plot :vlax-true))
               (vla-put-ConfigName lo outdev)
               (vl-catch-all-apply 'vla-RefreshPlotDeviceInfo (list lo))
               (vl-catch-all-apply 'vla-put-PaperUnits (list lo 1))   ; acMillimeters
               (setq media (bplot:names lo 'vla-GetCanonicalMediaNames)
                     gmedia (bplot:general-media media (nth 1 pcs)) fits 0)
               (if (setq r (bplot:check-style lo)) (setq notes (cons r notes)))
               (setq i 0)
               (foreach f frs
                 (setq nm (nth i names) i (1+ i)
                       path (if pdf (bplot:target folder nm ".pdf" taken)))
                 (princ (strcat "\n  (" (itoa i) "/" (itoa (length frs)) ") " (if path (strcat nm ".pdf") nm)))
                 (setq r (vl-catch-all-apply 'bplot:plot1 (list lo plot f media gmedia path)))
                 (cond
                   ((or (null r) (vl-catch-all-error-p r))
                    (setq fail (cons nm fail)))
                   (T
                    (setq ok (1+ ok))
                    (if (eq r 'FIT) (setq fits (1+ fits)))
                    (if path (setq taken (cons (strcase path) taken)))))))
             ;; DWG — 도곽마다 걸침 선택 → -WBLOCK (기준점 = 도곽 왼쪽 아래) → OOPS
             (progn
               (setq sv (mapcar (function (lambda (v) (cons v (getvar v)))) '("CMDECHO" "FILEDIA")))
               (setvar "CMDECHO" 0)
               (setvar "FILEDIA" 0)
               (setq vctr (trans (getvar "VIEWCTR") 1 0) vsize (getvar "VIEWSIZE"))
               (if (= (getvar "WORLDUCS") 0) (progn (command "_.UCS" "_W") (setq ucs_changed T)))
               ;; 잠긴 레이어는 잠시 풀어 둔다 (WBLOCK 은 잠긴 객체를 빼 버림)
               (vlax-for l (vla-get-Layers doc)
                 (if (and (= (vla-get-Lock l) :vlax-true)
                          (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Lock (list l :vlax-false)))))
                   (setq locked (cons l locked))))
               (setq i 0)
               (foreach f frs
                 (setq nm (nth i names) i (1+ i) b (nth 2 f)
                       m (* 0.02 (max (- (caddr b) (car b)) (- (cadddr b) (cadr b)))))
                 (princ (strcat "\n  (" (itoa i) "/" (itoa (length frs)) ") " nm ".dwg"))
                 (command "_.ZOOM" "_W" "_non" (list (- (car b) m) (- (cadr b) m)) "_non" (list (+ (caddr b) m) (+ (cadddr b) m)))
                 (setq ss (ssget "_C" (list (car b) (cadr b)) (list (caddr b) (cadddr b))))
                 ;; 옆 도곽 블록은 빼기
                 (if ss (foreach g frs (if (and (not (eq g f)) (ssmemb (car g) ss)) (ssdel (car g) ss))))
                 (if (and ss (> (sslength ss) 0))
                   (progn
                     (setq path (bplot:target folder nm ".dwg" taken) wb_ss ss)
                     (command "_.-WBLOCK" path "" "_non" (list (car b) (cadr b) 0.0) ss "")
                     (setq cnt 0)
                     (while (and (> (getvar "CMDACTIVE") 0) (< (setq cnt (1+ cnt)) 5)) (command ""))
                     (if (null (entget (ssname ss 0))) (command "_.OOPS"))
                     (setq wb_ss nil)
                     (if (findfile path)
                       (setq ok (1+ ok) taken (cons (strcase path) taken))
                       (setq fail (cons nm fail))))
                   (setq fail (cons nm fail))))))
           ;; 다른 폴더를 골랐으면 이 도면에 기억 (YGN CAD 패널과 같이 씀)
           (if (and folder (> ok 0) (/= (strcase folder) (strcase base)) (not (and mem (= (strcase folder) (strcase mem)))))
             (bplot:nod-put "plot_folder" (vl-string-right-trim "\\" folder)))
           (*error* nil)
           (princ (cond
                    ((= ok 0) "\n[주의] 하나도 만들지 못했습니다.")
                    ((= mode "2") (strcat "\n[완료] DWG " (itoa ok) "개를 " folder " 에 저장했습니다."))
                    (pdf (strcat "\n[완료] PDF " (itoa ok) "장을 " folder " 에 저장했습니다."))
                    (T (strcat "\n[완료] " (itoa ok) "장을 " outdev " (으)로 보냈습니다."))))
           (if fail (princ (strcat "\n[주의] 만들지 못한 것 " (itoa (length fail)) "장: " (bplot:join (reverse fail)))))
           (if (> rot 0) (princ (strcat "\n[알림] 돌려 놓은 YGN 도곽 " (itoa rot) "장은 건너뛰었습니다.")))
           (if (and fits (> fits 0)) (princ (strcat "\n[알림] 맞는 여백 없는 용지가 없어 용지에 맞춰 뽑은 YGN 도곽 " (itoa fits) "장이 있습니다.")))
           (foreach x notes (princ (strcat "\n[알림] " x)))))))))
  (princ))

(princ)
