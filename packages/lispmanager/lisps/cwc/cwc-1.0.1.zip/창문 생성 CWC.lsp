;;; ==============================================================================
;;; 명령어: CWC (창문 생성)
;;; 기능: 직선/곡선/원형/폴리선(ㄷ자 연속 벽체) 벽체 자동 판별 및 프레임 자동 정렬
;;;         + [모드1] 클릭 방식 (연속 폴리선 선택 시 전체 경로 동일 등분 지원)
;;;         + [모드2] 영역 드래그 방식 (직선/곡선/원형 자동 판별)
;;;         + [모드3] 가이드라인 기반 다중 치수 일괄 생성 
;;; 참고: 폴리선 유리선이 프레임(Mullion)을 파고들지 않게 선분을 나눠 그림,
;;;         스케치업 3D 작업용 '개구부-창' 레이어에 닫힌 경계를 만듦
;;; ==============================================================================

(if (null *CWC_MODE*) (setq *CWC_MODE* "1"))

(defun c:CWC ( / doc old_err undo_started ent1 obj1 type1 centerPt r1 p2 ent2 obj2 
                 p2_start_exact p2_end_exact r2 thickness p3 startAng endAng bays 
                 blkName rMid angDiff angStep ssOpening i 
                 j rGlass1 rGlass2 oldOsnap oldColor oldLayer 
                 p1_start p1_end p2_start p2_end startCenterAng endCenterAng totalCenterDiff
                 angWall angOut p1_proj distTotal typeArc
                 modeInput ssRect rectPts pA pB pC pD l1 l2
                 guideEnt guideLayer strLens lstLens ssGuide guideList pairList 
                 cur matchFound check distMid isTargetLen ang1 ang2 diffAng 
                 data1 data2 k pair ssArc arcObj mid1 mid2 mid_long1 mid_long2)
  
  (vl-load-com)
  (princ "\n[CWC 창문 생성]")

  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (vl-catch-all-apply 'vla-EndUndoMark (list doc))
  (setq undo_started nil)
  (setq old_err *error*)

  (defun *error* (msg)
    (if undo_started (progn (vl-catch-all-apply 'vla-EndUndoMark (list doc)) (command-s "_.U")))
    (if oldOsnap (setvar "OSMODE" oldOsnap)) (if oldColor (setvar "CECOLOR" oldColor)) (if oldLayer (setvar "CLAYER" oldLayer))
    (setq *error* old_err) (princ "\n[작업 취소] 실행 전 상태로 되돌렸습니다.") (princ)
  )

  ;; --- 0. 작업 모드 선택 ---
  (initget "1 2 3")
  (setq modeInput (getkword (strcat "\n[모드 선택] 1.클릭(원형·폴리선) / 2.영역 드래그 / 3.여러 개 한 번에 <" *CWC_MODE* ">: ")))
  (if modeInput (setq *CWC_MODE* modeInput))

  ;; --- 1. 데이터 수집 단계 ---
  (cond
    ((= *CWC_MODE* "1")
      (setq ent1 (car (entsel "\n1. 기준 내측 벽선(Line/Arc/Circle/Polyline) 선택: ")))
      (if (null ent1) (quit))
      (setq obj1 (vlax-ename->vla-object ent1) type1 (vlax-get obj1 'ObjectName))
      
      (if (= type1 "AcDbCircle")
        (progn
          (setq p2 (getpoint "\n2. 반대편 외측 원형 벽선 클릭 (두께 지정): "))
          (if (null p2) (quit))
          (setq ent2 (car (nentselp p2)))
        )
        (if (or (= type1 "AcDbPolyline") (= type1 "AcDb2dPolyline"))
          (progn
            (setq p2 (getpoint "\n2. 반대편 외측 꺾은 벽선 클릭: "))
            (if (null p2) (quit))
            (setq ent2 (GetParallelEntity p2 ent1))
            (setq obj2 (vlax-ename->vla-object ent2))
          )
          (progn
            (setq p2 (getpoint "\n2. 반대편 외측 벽선 클릭: "))
            (if (null p2) (quit))
            (setq ent2 (GetParallelEntity p2 ent1))
            (setq p3 (getpoint p2 "\n3. 개구부 끝점 클릭: "))
            (if (null p3) (quit))
          )
        )
      )
      (setq bays (getint "\n나눌 칸 수 입력 <3>: ")) (if (null bays) (setq bays 3))
    )
    ((= *CWC_MODE* "2")
      (princ "\n창호가 생성될 개구부 영역(가이드 사각형)을 드래그하세요.")
      (setq ssRect (ssget '((0 . "LINE,LWPOLYLINE"))))
      (if (null ssRect) (quit))
      (setq rectPts (CWC_GetRectPts ssRect))
      (if (null rectPts) (progn (princ "\n[오류] 꼭짓점을 찾지 못했습니다.") (quit)))
      (setq bays (getint "\n나눌 칸 수 입력 <3>: ")) (if (null bays) (setq bays 3))
    )
    ((= *CWC_MODE* "3")
      (setq guideEnt (car (entsel "\n기준 가이드라인(붉은 선) 클릭: "))) (if (null guideEnt) (quit))
      (setq guideLayer (cdr (assoc 8 (entget guideEnt))))
      (setq strLens (getstring "\n창문 길이 여러 개 입력 (예: 3000,2000): "))
      (setq lstLens (CWC_ParseLengths strLens)) (if (null lstLens) (quit))
      (setq bays (getint "\n나눌 칸 수 입력 <3>: ")) (if (null bays) (setq bays 3))
      (princ "\n일괄 적용할 도면 영역을 드래그하세요.")
      (setq ssGuide (ssget (list '(0 . "LINE") (cons 8 guideLayer)))) (if (null ssGuide) (quit))
      
      (setq i 0 guideList '() pairList '())
      (while (< i (sslength ssGuide))
        (setq obj2 (vlax-ename->vla-object (ssname ssGuide i))
              pA (vlax-get obj2 'StartPoint) pB (vlax-get obj2 'EndPoint)
              mid1 (list (/ (+ (car pA) (car pB)) 2.0) (/ (+ (cadr pA) (cadr pB)) 2.0) 0.0))
        (setq guideList (cons (list (ssname ssGuide i) pA pB mid1) guideList) i (1+ i))
      )
      (while guideList
        (setq cur (car guideList) guideList (cdr guideList) mid1 (cadddr cur) matchFound nil k 0)
        (while (and (< k (length guideList)) (not matchFound))
          (setq check (nth k guideList) mid2 (cadddr check) distMid (distance mid1 mid2) isTargetLen nil)
          (foreach len lstLens (if (< (abs (- distMid len)) 5.0) (setq isTargetLen T)))
          (if isTargetLen
            (progn
              (setq ang1 (angle (cadr cur) (caddr cur)) ang2 (angle (cadr check) (caddr check)) diffAng (abs (- ang1 ang2)))
              (while (>= diffAng pi) (setq diffAng (- diffAng pi)))
              (if (or (< diffAng 0.05) (> diffAng (- pi 0.05))) 
                (setq pairList (cons (list cur check) pairList) guideList (vl-remove check guideList) matchFound T)
              )
            )
          )
          (setq k (1+ k))
        )
      )
    )
  )

  (vla-StartUndoMark doc) (setq undo_started T)
  (setq oldOsnap (getvar "OSMODE") oldColor (getvar "CECOLOR") oldLayer (getvar "CLAYER"))
  (setvar "OSMODE" 0) (setq ssOpening (ssadd))

  ;; --- 2. 로직 처리 단계 ---
  (cond
    ((= *CWC_MODE* "1")
      (cond
        ((= type1 "AcDbCircle")
          (setq centerPt (vlax-get obj1 'Center) r1 (vlax-get obj1 'Radius) r2 (distance centerPt p2))
          (setq blkName (CWC_BuildCircleWindow centerPt r1 r2 bays oldLayer oldColor ssOpening))
          (vl-catch-all-apply 'entdel (list ent1))
          (if ent2 (vl-catch-all-apply 'entdel (list ent2)))
        )
        ((= type1 "AcDbArc")
          (setq centerPt (vlax-get obj1 'Center) r1 (vlax-get obj1 'Radius) r2 (distance centerPt p2))
          (setq startAng (angle centerPt p2) endAng (angle centerPt p3))
          (setq blkName (CWC_BuildCurvedWindow centerPt r1 r2 startAng endAng bays oldLayer oldColor ssOpening))
        )
        ;; 폴리선 처리 분기
        ((or (= type1 "AcDbPolyline") (= type1 "AcDb2dPolyline"))
          (setq blkName (CWC_BuildPolylineWindow obj1 obj2 bays oldLayer oldColor ssOpening))
          (vl-catch-all-apply 'entdel (list ent1))
          (if ent2 (vl-catch-all-apply 'entdel (list ent2)))
        )
        (t
          (setq p1_proj (vlax-curve-getClosestPointTo obj1 p2) p1_end (vlax-curve-getClosestPointTo obj1 p3))
          (setq angWall (angle p1_proj p1_end) p2_start p2 angOut (angle p1_proj p2_start) thickness (distance p1_proj p2_start))
          (setq distTotal (distance p1_proj p1_end) p1_start p1_proj p2_end (polar p1_end angOut thickness))
          (setq blkName (CWC_BuildLinearWindow p1_start p1_end p2_start p2_end distTotal thickness angWall angOut bays oldLayer oldColor ssOpening))
        )
      )
    )
    ((= *CWC_MODE* "2")
      (setq pA (nth 0 rectPts) pB (nth 1 rectPts) pC (nth 2 rectPts) pD (nth 3 rectPts))
      (setq l1 (distance pA pB) l2 (distance pB pC))
      (if (> l1 l2)
        (setq p1_start pA p1_end pB p2_start pD p2_end pC distTotal l1 thickness l2 angWall (angle pA pB) angOut (angle pA pD))
        (setq p1_start pB p1_end pC p2_start pA p2_end pD distTotal l2 thickness l1 angWall (angle pB pC) angOut (angle pB pA))
      )
      
      (setq ssArc (ssget "_C" pA pC '((0 . "ARC,CIRCLE"))))
      (if ssArc
        (progn
          (setq arcObj (vlax-ename->vla-object (ssname ssArc 0)) typeArc (vlax-get arcObj 'ObjectName) centerPt (vlax-get arcObj 'Center))
          (if (= typeArc "AcDbCircle")
            (progn
              (setq mid_long1 (list (/ (+ (car p1_start) (car p1_end)) 2.0) (/ (+ (cadr p1_start) (cadr p1_end)) 2.0) 0.0))
              (setq mid_long2 (list (/ (+ (car p2_start) (car p2_end)) 2.0) (/ (+ (cadr p2_start) (cadr p2_end)) 2.0) 0.0))
              (setq r1 (distance centerPt mid_long1) r2 (distance centerPt mid_long2))
              (command "_.erase" ssRect "")
              (setq blkName (CWC_BuildCircleWindow centerPt r1 r2 bays oldLayer oldColor ssOpening))
            )
            (progn
              (setq mid1 (list (/ (+ (car p1_start) (car p2_start)) 2.0) (/ (+ (cadr p1_start) (cadr p2_start)) 2.0) 0.0))
              (setq mid2 (list (/ (+ (car p1_end) (car p2_end)) 2.0) (/ (+ (cadr p1_end) (cadr p2_end)) 2.0) 0.0))
              (setq startAng (angle centerPt mid1) endAng (angle centerPt mid2))
              (setq mid_long1 (list (/ (+ (car p1_start) (car p1_end)) 2.0) (/ (+ (cadr p1_start) (cadr p1_end)) 2.0) 0.0))
              (setq mid_long2 (list (/ (+ (car p2_start) (car p2_end)) 2.0) (/ (+ (cadr p2_start) (cadr p2_end)) 2.0) 0.0))
              (setq r1 (distance centerPt mid_long1) r2 (distance centerPt mid_long2))
              (command "_.erase" ssRect "")
              (setq blkName (CWC_BuildCurvedWindow centerPt r1 r2 startAng endAng bays oldLayer oldColor ssOpening))
            )
          )
        )
        (progn
          (command "_.erase" ssRect "")
          (setq blkName (CWC_BuildLinearWindow p1_start p1_end p2_start p2_end distTotal thickness angWall angOut bays oldLayer oldColor ssOpening))
        )
      )
    )
    ((= *CWC_MODE* "3")
      (foreach pair pairList
        (setq data1 (car pair) data2 (cadr pair) ent1 (car data1) pA (cadr data1) pB (caddr data1) ent2 (car data2) pC (cadr data2) pD (caddr data2))
        (if (< (distance pA pC) (distance pA pD)) (setq p1_start pA p1_end pC p2_start pB p2_end pD) (setq p1_start pA p1_end pD p2_start pB p2_end pC))
        (setq distTotal (distance p1_start p1_end) thickness (distance p1_start p2_start) angWall (angle p1_start p1_end) angOut (angle p1_start p2_start))
        (CWC_BuildLinearWindow p1_start p1_end p2_start p2_end distTotal thickness angWall angOut bays oldLayer oldColor ssOpening)
        (vl-catch-all-apply 'entdel (list ent1)) (vl-catch-all-apply 'entdel (list ent2))
      )
      (setq blkName "다중 일괄 생성")
    )
  )

  (if blkName (CleanupCWC blkName ssOpening oldColor oldLayer oldOsnap))
  (vla-EndUndoMark doc) (setq undo_started nil) (setq *error* old_err)
  (princ)
)

;;; ==============================================================================
;;; [보조 함수: 연속 폴리선(ㄷ자 등) 창호 생성]
;;; ==============================================================================
(defun CWC_BuildPolylineWindow (objIn objOut bays oldLayer oldColor ssOpening / 
                                totLen stepDist i dist ptIn ptOut angNorm
                                thk halfThk offDist1 offDist2
                                ssOrigin blkName intL intT pA pB pC pD
                                entIn entOut cpOrigin openIn openOut
                                breakDists cleanDists breakParams splitObjs
                                segIndex segEnt outEnt g1Ent g2Ent midParam midPt localSidePt safeSidePt p)
  (setq entIn (vlax-vla-object->ename objIn) entOut (vlax-vla-object->ename objOut))
  ;; 1. 폴리선의 전체 길이 파악
  (setq totLen (vlax-curve-getDistAtParam objIn (vlax-curve-getEndParam objIn)))
  (setq stepDist (/ totLen (float bays)))

  ;; 2. 두께 및 오프셋 정보 계산
  (setq ptIn (vlax-curve-getStartPoint objIn))
  (setq ptOut (vlax-curve-getClosestPointTo objOut ptIn))
  (setq thk (distance ptIn ptOut))
  (setq halfThk (/ thk 2.0))

  ;; 3. 스케치업용 개구부 마감 선 생성 (닫힌 경계)
  (if (null (tblsearch "LAYER" "개구부-창")) (command "_.-layer" "_make" "개구부-창" "_color" "6" "" ""))
  (setvar "CLAYER" "개구부-창") (setvar "CECOLOR" "256")
  
  ;; 좌/우측 마감선 닫기
  (command "_.line" ptIn ptOut "") (ssadd (entlast) ssOpening)
  (command "_.line" (vlax-curve-getEndPoint objIn) (vlax-curve-getClosestPointTo objOut (vlax-curve-getEndPoint objIn)) "") (ssadd (entlast) ssOpening)
  
  ;; 내곽/외곽 원본 라인 복사 (스케치업 면 생성을 위해 개구부 레이어로)
  (command "_.copy" entIn "" '(0 0) '(0 0)) 
  (setq openIn (entlast))
  (vla-put-Layer (vlax-ename->vla-object openIn) "개구부-창")
  (ssadd openIn ssOpening)
  
  (command "_.copy" entOut "" '(0 0) '(0 0))
  (setq openOut (entlast))
  (vla-put-Layer (vlax-ename->vla-object openOut) "개구부-창")
  (ssadd openOut ssOpening)

  ;; 4. 블록 이름 및 객체 준비
  (setq intL (fix (+ totLen 0.5)) intT (fix (+ thk 0.5)))
  (setq blkName (strcat "CWC-PL-L" (itoa intL) "-T" (itoa intT) "-B" (itoa bays)))

  (if (not (tblsearch "BLOCK" blkName))
    (progn
      (setq ssOrigin (ssadd))

      ;; [A] 프레임(기둥) 박스 그리기
      (setvar "CECOLOR" "5")
      (setq i 0)
      (while (<= i bays)
        (setq dist (* i stepDist))
        (if (> dist totLen) (setq dist totLen))
        (setq ptIn (vlax-curve-getPointAtDist objIn dist))
        (setq ptOut (vlax-curve-getClosestPointTo objOut ptIn))
        (setq angNorm (angle ptIn ptOut))

        (setq pA (polar ptIn (+ angNorm (/ pi 2.0)) 25.0)
              pB (polar ptIn (- angNorm (/ pi 2.0)) 25.0)
              pC (polar ptOut (- angNorm (/ pi 2.0)) 25.0)
              pD (polar ptOut (+ angNorm (/ pi 2.0)) 25.0))
        (command "_.pline" pA pB pC pD "_C")
        (ssadd (entlast) ssOrigin)
        (setq i (1+ i))
      )

      ;; [B] 유리선·가로 프레임 분할 (프레임을 파고들지 않게 선분으로 나눔)
      (setq offDist1 (- halfThk 12.0) offDist2 (+ halfThk 12.0))
      
      (setq breakDists '() i 0)
      (while (<= i bays)
        (setq dist (* i stepDist))
        (if (> (- dist 25.0) 0.0) (setq breakDists (cons (- dist 25.0) breakDists)))
        (if (< (+ dist 25.0) totLen) (setq breakDists (cons (+ dist 25.0) breakDists)))
        (setq i (1+ i))
      )
      
      (setq cleanDists '())
      (foreach d breakDists
        (if (not (vl-member-if '(lambda (x) (< (abs (- x d)) 0.1)) cleanDists))
          (setq cleanDists (cons d cleanDists))
        )
      )
      (setq breakDists (vl-sort cleanDists '<))
      
      (setq breakParams '())
      (foreach d breakDists
        (setq p (vl-catch-all-apply 'vlax-curve-getParamAtDist (list objIn d)))
        (if (and p (not (vl-catch-all-error-p p)))
          (setq breakParams (cons p breakParams))
        )
      )
      (setq breakParams (reverse breakParams))

      (setq splitObjs (vl-catch-all-apply 'vlax-invoke (list objIn 'GetSplitCurves breakParams)))

      (if (vl-catch-all-error-p splitObjs)
        (progn
          ;; 실패할 때 쓰는 대안
          (princ "\n[알림] 정점 분할에 실패하여 연속선 모드로 생성합니다.")
          (setq safeSidePt (vlax-curve-getPointAtParam objOut (/ (vlax-curve-getEndParam objOut) 2.0)))
          
          (setvar "CECOLOR" "5")
          (command "_.copy" entIn "" '(0 0) '(0 0)) (setq inEnt (entlast)) (vla-put-Color (vlax-ename->vla-object inEnt) 5) (ssadd inEnt ssOrigin)
          (command "_.copy" entOut "" '(0 0) '(0 0)) (setq outEnt (entlast)) (vla-put-Color (vlax-ename->vla-object outEnt) 5) (ssadd outEnt ssOrigin)
          
          (setvar "CECOLOR" "4")
          (if (> offDist1 0) (progn (command "_.offset" offDist1 entIn safeSidePt "") (setq g1Ent (entlast)) (vla-put-Color (vlax-ename->vla-object g1Ent) 4) (ssadd g1Ent ssOrigin)))
          (if (> offDist2 0) (progn (command "_.offset" offDist2 entIn safeSidePt "") (setq g2Ent (entlast)) (vla-put-Color (vlax-ename->vla-object g2Ent) 4) (ssadd g2Ent ssOrigin)))
        )
        (progn
          ;; 분할 성공 (나눈 선분만 배치)
          (setq segIndex 0)
          (foreach segObj splitObjs
            (setq segEnt (vlax-vla-object->ename segObj))
            (if (= (rem segIndex 2) 1) ; 프레임과 프레임 사이 공간 (유리)
              (progn
                (setq midParam (/ (+ (vlax-curve-getStartParam segObj) (vlax-curve-getEndParam segObj)) 2.0))
                (setq midPt (vlax-curve-getPointAtParam segObj midParam))
                (setq localSidePt (vlax-curve-getClosestPointTo objOut midPt))
                (setq safeSidePt (polar midPt (angle midPt localSidePt) (* thk 2.0)))
                
                (vla-put-Color segObj 5)
                (ssadd segEnt ssOrigin)
                
                (command "_.offset" thk segEnt safeSidePt "")
                (setq outEnt (entlast))
                (vla-put-Color (vlax-ename->vla-object outEnt) 5)
                (ssadd outEnt ssOrigin)
                
                (if (> offDist1 0.0)
                  (progn
                    (command "_.offset" offDist1 segEnt safeSidePt "")
                    (setq g1Ent (entlast))
                    (vla-put-Color (vlax-ename->vla-object g1Ent) 4)
                    (ssadd g1Ent ssOrigin)
                  )
                )
                (if (> offDist2 0.0)
                  (progn
                    (command "_.offset" offDist2 segEnt safeSidePt "")
                    (setq g2Ent (entlast))
                    (vla-put-Color (vlax-ename->vla-object g2Ent) 4)
                    (ssadd g2Ent ssOrigin)
                  )
                )
              )
              (progn
                (vla-Delete segObj) ; 프레임(Mullion)을 관통하는 겹친 선 삭제
              )
            )
            (setq segIndex (1+ segIndex))
          )
        )
      )

      ;; 블록 정리
      (setvar "CLAYER" oldLayer) (setvar "CECOLOR" oldColor)
      (setq cpOrigin (vlax-curve-getStartPoint objIn))
      (command "_.-block" blkName cpOrigin ssOrigin "")
      (if (null (tblsearch "LAYER" "창문")) (command "_.-layer" "_make" "창문" ""))
      (setvar "CLAYER" "창문")
      (command "_.-insert" blkName cpOrigin 1 1 0)
    )
    (progn
      (if (null (tblsearch "LAYER" "창문")) (command "_.-layer" "_make" "창문" ""))
      (setvar "CLAYER" "창문") (setvar "CECOLOR" oldColor)
      (command "_.-insert" blkName (vlax-curve-getStartPoint objIn) 1 1 0)
    )
  )
  blkName
)

;;; ==============================================================================
;;; [서브 함수들 (Circle / Curved / Linear / Utils)]
;;; ==============================================================================
(defun CWC_BuildCircleWindow (centerPt r1 r2 bays oldLayer oldColor ssOpening / 
                              thickness rMid angStep intR intT blkName halfAng
                              ssOrigin cpOrigin i cur angR angL nextCur nextAngR
                              pGlass1 pGlass2)
  (setq thickness (abs (- r1 r2)) rMid (/ (+ r1 r2) 2.0))
  (setq angStep (/ (* 2 pi) bays) halfAng (/ 25.0 rMid))
  (if (null (tblsearch "LAYER" "개구부-창")) (command "_.-layer" "_make" "개구부-창" "_color" "6" "" ""))
  (setvar "CLAYER" "개구부-창") (setvar "CECOLOR" "256")
  (command "_.circle" centerPt r1) (ssadd (entlast) ssOpening)
  (command "_.circle" centerPt r2) (ssadd (entlast) ssOpening)
  (setq intR (fix (+ (min r1 r2) 0.5)) intT (fix (+ thickness 0.5)))
  (setq blkName (strcat "CWC-C-R" (itoa intR) "-T" (itoa intT) "-B" (itoa bays)))
  
  (if (not (tblsearch "BLOCK" blkName))
    (progn
      (setq ssOrigin (ssadd) cpOrigin '(0.0 0.0 0.0))
      (setq pGlass1 (+ rMid 12.0) pGlass2 (- rMid 12.0) i 0)
      (while (< i bays)
        (setq cur (* i angStep) angR (- cur halfAng) angL (+ cur halfAng))
        (setq nextCur (* (1+ i) angStep) nextAngR (- nextCur halfAng))
        (setvar "CECOLOR" "5")
        (command "_.line" (polar cpOrigin angR r1) (polar cpOrigin angR r2) "") (ssadd (entlast) ssOrigin)
        (command "_.line" (polar cpOrigin angL r1) (polar cpOrigin angL r2) "") (ssadd (entlast) ssOrigin)
        (command "_.arc" "_C" cpOrigin (polar cpOrigin angR r1) (polar cpOrigin angL r1)) (ssadd (entlast) ssOrigin)
        (command "_.arc" "_C" cpOrigin (polar cpOrigin angR r2) (polar cpOrigin angL r2)) (ssadd (entlast) ssOrigin)
        (command "_.arc" "_C" cpOrigin (polar cpOrigin angL r1) (polar cpOrigin nextAngR r1)) (ssadd (entlast) ssOrigin)
        (command "_.arc" "_C" cpOrigin (polar cpOrigin angL r2) (polar cpOrigin nextAngR r2)) (ssadd (entlast) ssOrigin)
        (setvar "CECOLOR" "4")
        (command "_.arc" "_C" cpOrigin (polar cpOrigin angL pGlass1) (polar cpOrigin nextAngR pGlass1)) (ssadd (entlast) ssOrigin)
        (command "_.arc" "_C" cpOrigin (polar cpOrigin angL pGlass2) (polar cpOrigin nextAngR pGlass2)) (ssadd (entlast) ssOrigin)
        (setq i (1+ i))
      )
      (setvar "CLAYER" oldLayer) (setvar "CECOLOR" oldColor)
      (command "_.-block" blkName cpOrigin ssOrigin "")
    )
  )
  (if (null (tblsearch "LAYER" "창문")) (command "_.-layer" "_make" "창문" ""))
  (setvar "CLAYER" "창문") (setvar "CECOLOR" oldColor)
  (command "_.-insert" blkName centerPt 1 1 0)
  blkName
)

(defun CWC_BuildCurvedWindow (centerPt r1 r2 startAng endAng bays oldLayer oldColor ssOpening / 
                              thickness rMid angDiff halfAng startCenterAng endCenterAng totalCenterDiff
                              angStep p1_start p1_end p2_start p2_end r_min r_max p_box1 p_box2 p_box3 p_box4
                              cutEdge1 cutEdge2 midAng fence_s fence_e intR intT intAng blkName
                              ssOrigin cpOrigin)
  (setq thickness (abs (- r1 r2)) rMid (/ (+ r1 r2) 2.0))
  (setq angDiff (- endAng startAng)) (if (< angDiff 0.0) (setq angDiff (+ angDiff (* 2 pi))))
  (setq halfAng (/ 25.0 rMid) startCenterAng (+ startAng halfAng) endCenterAng (- endAng halfAng))
  (setq totalCenterDiff (- endCenterAng startCenterAng)) (if (< totalCenterDiff 0.0) (setq totalCenterDiff (+ totalCenterDiff (* 2 pi))))
  (setq angStep (/ totalCenterDiff bays))
  (setq p1_start (polar centerPt startAng r1) p1_end (polar centerPt endAng r1))
  (setq p2_start (polar centerPt startAng r2) p2_end (polar centerPt endAng r2))
  (setq r_min (- (min r1 r2) 50.0) r_max (+ (max r1 r2) 50.0))
  (setq p_box1 (polar centerPt startAng r_min) p_box2 (polar centerPt startAng r_max))
  (setq p_box4 (polar centerPt endAng r_min) p_box3 (polar centerPt endAng r_max))
  (command "_.line" p_box1 p_box2 "") (setq cutEdge1 (entlast))
  (command "_.line" p_box4 p_box3 "") (setq cutEdge2 (entlast))
  (setq midAng (+ startAng (/ angDiff 2.0)))
  (setq fence_s (polar centerPt midAng r_min) fence_e (polar centerPt midAng r_max))
  (command "_.trim" cutEdge1 cutEdge2 "" "_F" fence_s fence_e "" "")
  (entdel cutEdge1) (entdel cutEdge2)
  (setvar "CECOLOR" "BYLAYER") 
  (command "_.line" p1_start p2_start "") (command "_.line" p1_end p2_end "")
  (DrawSUOpening centerPt p1_start p1_end p2_start p2_end "ARC" ssOpening)
  (setq intR (fix (+ (min r1 r2) 0.5)) intT (fix (+ thickness 0.5)) intAng (fix (+ (* totalCenterDiff (/ 180.0 pi)) 0.5)))
  (setq blkName (strcat "CWC-A-R" (itoa intR) "-A" (itoa intAng) "-T" (itoa intT) "-B" (itoa bays)))
  
  (if (not (tblsearch "BLOCK" blkName))
    (progn
      (setq ssOrigin (ssadd) cpOrigin '(0.0 0.0 0.0))
      (CWC_DrawCurved cpOrigin r1 r2 rMid 0.0 angStep halfAng bays ssOrigin)
      (setvar "CLAYER" oldLayer) (setvar "CECOLOR" oldColor)
      (command "_.-block" blkName cpOrigin ssOrigin "")
    )
  )
  (if (null (tblsearch "LAYER" "창문")) (command "_.-layer" "_make" "창문" ""))
  (setvar "CLAYER" "창문") (setvar "CECOLOR" oldColor)
  (command "_.-insert" blkName centerPt 1 1 (* 180.0 (/ startCenterAng pi)))
  blkName
)

(defun CWC_BuildLinearWindow (p1s p1e p2s p2e distTotal thickness angWall angOut bays oldLayer oldColor ssOpening / 
                              cut_ang1 p_box1 p_box2 cut_ang2 p_box4 p_box3 cutEdge1 cutEdge2
                              mid_in mid_out fence_ang fence_s fence_e intW intT blkName
                              ssOrigin cpOrigin cpOut relAng yScale)
  (setq cut_ang1 (angle p1s p2s) p_box1 (polar p1s (+ cut_ang1 pi) 50.0) p_box2 (polar p2s cut_ang1 50.0))
  (setq cut_ang2 (angle p1e p2e) p_box4 (polar p1e (+ cut_ang2 pi) 50.0) p_box3 (polar p2e cut_ang2 50.0))
  (command "_.line" p_box1 p_box2 "") (setq cutEdge1 (entlast))
  (command "_.line" p_box4 p_box3 "") (setq cutEdge2 (entlast))
  (setq mid_in (list (/ (+ (car p1s) (car p1e)) 2.0) (/ (+ (cadr p1s) (cadr p1e)) 2.0) 0.0))
  (setq mid_out (list (/ (+ (car p2s) (car p2e)) 2.0) (/ (+ (cadr p2s) (cadr p2e)) 2.0) 0.0))
  (setq fence_ang (angle mid_in mid_out) fence_s (polar mid_in (+ fence_ang pi) 50.0) fence_e (polar mid_out fence_ang 50.0))
  (command "_.trim" cutEdge1 cutEdge2 "" "_F" fence_s fence_e "" "")
  (entdel cutEdge1) (entdel cutEdge2)
  (setvar "CECOLOR" "BYLAYER") (command "_.line" p1s p2s "") (command "_.line" p1e p2e "")
  (DrawSUOpening nil p1s p1e p2s p2e "LINE" ssOpening)
  (setq intW (fix (+ distTotal 0.5)) intT (fix (+ thickness 0.5)))
  (setq blkName (strcat "CWC-L-W" (itoa intW) "-T" (itoa intT) "-B" (itoa bays)))
  
  (if (not (tblsearch "BLOCK" blkName))
    (progn
      (setq ssOrigin (ssadd) cpOrigin '(0.0 0.0 0.0) cpOut (polar cpOrigin (/ pi 2.0) thickness))
      (CWC_DrawStraight cpOrigin cpOut 0.0 (/ pi 2.0) distTotal thickness bays ssOrigin)
      (setvar "CLAYER" oldLayer) (setvar "CECOLOR" oldColor)
      (command "_.-block" blkName cpOrigin ssOrigin "")
    )
  )
  (setq relAng (- angOut angWall)) (while (< relAng 0.0) (setq relAng (+ relAng (* 2 pi))))
  (setq yScale (if (and (> relAng 0.0) (< relAng pi)) 1.0 -1.0))
  (if (null (tblsearch "LAYER" "창문")) (command "_.-layer" "_make" "창문" ""))
  (setvar "CLAYER" "창문") (setvar "CECOLOR" oldColor)
  (command "_.-insert" blkName p1s 1 yScale (* 180.0 (/ angWall pi)))
  blkName
)

(defun CWC_ParseLengths (str / pos lst val)
  (setq lst '())
  (while (setq pos (vl-string-search "," str))
    (setq val (atof (vl-string-trim " " (substr str 1 pos))))
    (if (> val 0) (setq lst (append lst (list val))))
    (setq str (substr str (+ pos 2)))
  )
  (setq val (atof (vl-string-trim " " str)))
  (if (> val 0) (setq lst (append lst (list val))))
  lst
)

(defun CWC_GetRectPts (ss / i ent obj pList p cleanList dup cen coords idx)
  (setq pList '() i 0)
  (while (< i (sslength ss))
    (setq ent (ssname ss i) obj (vlax-ename->vla-object ent))
    (if (= (cdr (assoc 0 (entget ent))) "LINE")
      (setq pList (append pList (list (vlax-get obj 'StartPoint) (vlax-get obj 'EndPoint))))
      (if (= (cdr (assoc 0 (entget ent))) "LWPOLYLINE")
        (progn
          (setq coords (vlax-get obj 'Coordinates) idx 0)
          (while (< idx (length coords))
            (setq pList (append pList (list (list (nth idx coords) (nth (1+ idx) coords) 0.0))) idx (+ idx 2))
          )
        )
      )
    )
    (setq i (1+ i))
  )
  (setq cleanList '())
  (foreach p pList
    (setq dup nil)
    (foreach cp cleanList (if (< (distance (list (car p) (cadr p)) (list (car cp) (cadr cp))) 1.0) (setq dup T)))
    (if (not dup) (setq cleanList (cons (list (car p) (cadr p) 0.0) cleanList)))
  )
  (if (= (length cleanList) 4)
    (progn
      (setq cen (list (/ (apply '+ (mapcar 'car cleanList)) 4.0) (/ (apply '+ (mapcar 'cadr cleanList)) 4.0) 0.0))
      (setq cleanList (vl-sort cleanList '(lambda (a b) (< (angle cen a) (angle cen b)))))
      cleanList
    )
    nil 
  )
)

(defun DrawSUOpening (cp p1s p1e p2s p2e mode ss / )
  (if (null (tblsearch "LAYER" "개구부-창")) (command "_.-layer" "_make" "개구부-창" "_color" "6" "" ""))
  (setvar "CLAYER" "개구부-창") (setvar "CECOLOR" "256")
  (if (/= mode "CIRCLE") 
    (progn
      (command "_.line" p1s p2s "") (ssadd (entlast) ss) (command "_.line" p1e p2e "") (ssadd (entlast) ss)
      (if (= mode "ARC")
        (progn (command "_.arc" "_C" cp p1s p1e) (ssadd (entlast) ss) (command "_.arc" "_C" cp p2s p2e) (ssadd (entlast) ss))
        (progn (command "_.line" p1s p1e "") (ssadd (entlast) ss) (command "_.line" p2s p2e "") (ssadd (entlast) ss))
      )
    )
  )
)

(defun CWC_DrawCurved (cp r1 r2 rm sang astep hang bays ss / i cur angR angL pGlass1 pGlass2 j segS segE)
  (setvar "CECOLOR" "5") (setq i 0) 
  (while (<= i bays)
    (setq cur (+ sang (* i astep)) angR (- cur hang) angL (+ cur hang))
    (command "_.line" (polar cp angR r1) (polar cp angR r2) "") (ssadd (entlast) ss)
    (command "_.line" (polar cp angL r1) (polar cp angL r2) "") (ssadd (entlast) ss)
    (command "_.arc" "_C" cp (polar cp angR r1) (polar cp angL r1)) (ssadd (entlast) ss)
    (command "_.arc" "_C" cp (polar cp angR r2) (polar cp angL r2)) (ssadd (entlast) ss)
    (setq i (1+ i))
  )
  (setq pGlass1 (+ rm 12.0) pGlass2 (- rm 12.0) j 0)
  (while (< j bays)
    (setq segS (+ sang (* j astep) hang) segE (- (+ sang (* (1+ j) astep)) hang))
    (setvar "CECOLOR" "5")            
    (command "_.arc" "_C" cp (polar cp segS r1) (polar cp segE r1)) (ssadd (entlast) ss)
    (command "_.arc" "_C" cp (polar cp segS r2) (polar cp segE r2)) (ssadd (entlast) ss)
    (setvar "CECOLOR" "4")
    (command "_.arc" "_C" cp (polar cp segS pGlass1) (polar cp segE pGlass1)) (ssadd (entlast) ss)
    (command "_.arc" "_C" cp (polar cp segS pGlass2) (polar cp segE pGlass2)) (ssadd (entlast) ss)
    (setq j (1+ j))
  )
)

(defun CWC_DrawStraight (p1s p2s angW angO dtotal thk bays ss / i distStep dist curIn curOut pA pB pC pD rMid g1 g2 j segS segE)
  (setvar "CECOLOR" "5") (setq distStep (/ (- dtotal 50.0) bays) i 0) 
  (while (<= i bays)
    (setq dist (+ 25.0 (* i distStep)) curIn (polar p1s angW dist) curOut (polar curIn angO thk))
    (setq pA (polar curIn (+ angW pi) 25.0) pB (polar curIn angW 25.0) pC (polar curOut angW 25.0) pD (polar curOut (+ angW pi) 25.0))
    (command "_.pline" pA pB pC pD "_C") (ssadd (entlast) ss)
    (setq i (1+ i))
  )
  (setq rMid (/ thk 2.0) g1 (+ rMid 12.0) g2 (- rMid 12.0) j 0)
  (while (< j bays)
    (setq segS (+ 25.0 (* j distStep) 25.0) segE (- (+ 25.0 (* (1+ j) distStep)) 25.0))
    (setvar "CECOLOR" "5")            
    (command "_.line" (polar p1s angW segS) (polar p1s angW segE) "") (ssadd (entlast) ss)
    (command "_.line" (polar p2s angW segS) (polar p2s angW segE) "") (ssadd (entlast) ss)
    (setvar "CECOLOR" "4")
    (command "_.line" (polar (polar p1s angW segS) angO g1) (polar (polar p1s angW segE) angO g1) "") (ssadd (entlast) ss)
    (command "_.line" (polar (polar p1s angW segS) angO g2) (polar (polar p1s angW segE) angO g2) "") (ssadd (entlast) ss)
    (setq j (1+ j))
  )
)

(defun CleanupCWC (bn ssO oc ol oo)
  (if (> (sslength ssO) 0) (princ "\n[알림] 개구부 가이드 생성 완료."))
  (setvar "OSMODE" oo) (setvar "CECOLOR" oc) (setvar "CLAYER" ol)
  (princ (strcat "\n[완료] 블록 <" bn "> 처리가 완료되었습니다. (레이어: 창문)"))
)

(defun GetParallelEntity (pPt entBase / ss i ent tempObj baseObj pNear baseParam baseDir baseAng tempNear tempParam tempDir tempAng diff res)
  (setq baseObj (vlax-ename->vla-object entBase) pNear (vlax-curve-getClosestPointTo baseObj pPt))
  (setq baseParam (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list baseObj pNear)))
  (if (vl-catch-all-error-p baseParam) (setq baseParam (vlax-curve-getParamAtDist baseObj (vlax-curve-getDistAtPoint baseObj pNear))))
  (setq baseDir (vlax-curve-getFirstDeriv baseObj baseParam) baseAng (angle '(0 0 0) baseDir))
  (setq ss (ssget "_C" (polar pPt (* pi 1.25) 10.0) (polar pPt (* pi 0.25) 10.0)))
  (if ss
    (progn (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (if (not (equal ent entBase))
          (progn
            (setq tempObj (vlax-ename->vla-object ent))
            (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vlax-curve-getEndParam (list tempObj))))
              (progn (setq tempNear (vlax-curve-getClosestPointTo tempObj pPt))
                (if tempNear
                  (progn (setq tempParam (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list tempObj tempNear)))
                    (if (vl-catch-all-error-p tempParam) (setq tempParam (vl-catch-all-apply 'vlax-curve-getParamAtDist (list tempObj (vlax-curve-getDistAtPoint tempObj tempNear)))))
                    (if (not (vl-catch-all-error-p tempParam))
                      (progn
                        (setq tempDir (vlax-curve-getFirstDeriv tempObj tempParam) tempAng (angle '(0 0 0) tempDir) diff (abs (- baseAng tempAng)))
                        (while (>= diff pi) (setq diff (- diff pi)))
                        (if (or (< diff 0.1) (> diff (- pi 0.1))) (setq res ent))
                      )
                    )
                  )
                )
              )
            )
          )
        )
        (setq i (1+ i))
      )
    )
  )
  (if res res (car (nentselp pPt)))
)

(princ "\n[로드 완료] 명령: CWC (창문 생성)")
(princ)