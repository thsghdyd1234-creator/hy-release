;;; ==============================================================================
;;; CWC — 창문 생성
;;;
;;;  모드 1 (클릭): 안쪽 벽선(선·호·원·폴리선)을 고르고 맞은편 벽선을 클릭한다.
;;;          선·호 = 맞은편 벽선을 찍은 곳부터 개구부 끝점까지 / 원 = 한 바퀴 창 / 폴리선 = 폴리선 전체를 따라 꺾인 창.
;;;          끝점을 고르는 동안 커서를 따라 창 띠·칸·길이를 미리 보여 준다 (호 벽은 곡률대로 휨).
;;;          숫자를 치고 Enter 면 커서 쪽으로 그 길이 (호 벽은 벽 가운데 호 길이). 객체 스냅은 OSMODE 대로.
;;;  모드 2 (가이드 사각형): 사각형(닫힌 폴리선 하나 또는 선 넷)을 고르면 긴 변 = 창 길이, 짧은 변 = 벽 두께.
;;;          사각형을 가로지르는 벽 호가 있으면 곡선 창.
;;;  모드 3 (여러 개): 벽을 가로지르는 가이드 선 쌍(입력한 길이만큼 떨어진 것)마다 창을 한꺼번에.
;;;
;;;  벽 자르기는 IDD 와 같다 — 두 벽면과 그 사이의 평행한(곡선 벽은 중심이 같은) 벽선만 직접 잘라 낸다.
;;;  중심선·그리드는 그대로. 폴리선 벽은 펜스 자르기(TRIM 표준 모드).
;;;  창 블록은 '창문' 레이어 — 블록 안은 0 레이어, 프레임 색 5 · 유리 색 4. 개구부 경계(닫힌 선)는 '개구부-창'(색 6).
;;;  한 번 실행이 실행 취소 한 번(U)이다.
;;; ==============================================================================

;; ── 보조 ─────────────────────────────────────────────────
(defun cwc:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun cwc:sub (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b)) (- (caddr a) (caddr b))))
(defun cwc:add (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b)) (+ (caddr a) (caddr b))))
(defun cwc:mul (a k) (list (* (car a) k) (* (cadr a) k) (* (caddr a) k)))
(defun cwc:dir (ang) (list (cos ang) (sin ang) 0.0))
(defun cwc:p3 (p) (if (caddr p) p (list (car p) (cadr p) 0.0)))
(defun cwc:mid (a b) (cwc:mul (cwc:add a b) 0.5))
(defun cwc:unit (v / d) (setq d (distance '(0 0 0) v)) (if (> d 1e-12) (cwc:mul v (/ 1.0 d)) v))
(defun cwc:para-p (a b) (< (abs (sin (- a b))) 0.0175))
(defun cwc:norm (a) (setq a (rem a (+ pi pi))) (if (< a 0.0) (+ a pi pi) a))
(defun cwc:span (a b) (cwc:norm (- b a)))
(defun cwc:tan4 (sw) (/ (sin (/ sw 4.0)) (cos (/ sw 4.0))))
(defun cwc:cross (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))

(defun cwc:mklayer (name color)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 color) '(6 . "Continuous")))))

(defun cwc:locked-p (lay / r)
  (setq r (tblsearch "LAYER" lay))
  (and r (= 4 (logand 4 (cdr (assoc 70 r))))))

(defun cwc:ltype (ed / lt)
  (setq lt (cdr (assoc 6 ed)))
  (if (or (null lt) (= (strcase lt) "BYLAYER"))
    (setq lt (cdr (assoc 6 (tblsearch "LAYER" (cdr (assoc 8 ed)))))))
  (if lt lt "Continuous"))

(defun cwc:wall-like-p (ed wall_lay / lay lt)
  (setq lay (strcase (cdr (assoc 8 ed)))
        lt (strcase (cwc:ltype ed)))
  (cond
    ((wcmatch lt "*CENTER*,*DASHDOT*,*PHANTOM*,*CEN*,*ACAD_ISO04*,*ACAD_ISO10*") nil)
    ((wcmatch lay "*CEN*,*중심*,*C`.L*,*GRID*,*그리드*,개구부*") nil)
    ((and wall_lay (= lay (strcase wall_lay))) T)
    ((wcmatch lt "CONTINUOUS,BYBLOCK") T)))

(defun cwc:ss-around (p r flt / u)
  (setq u (trans p 0 1))
  (ssget "_C" (list (- (car u) r) (- (cadr u) r)) (list (+ (car u) r) (+ (cadr u) r)) flt))

(defun cwc:ss-list (ss / i out)
  (setq i 0)
  (if ss (while (< i (sslength ss)) (setq out (cons (ssname ss i) out) i (1+ i))))
  (reverse out))

(defun cwc:foot (pt p1 p2 / v L2)
  (setq v (cwc:sub p2 p1) L2 (cwc:dot v v))
  (if (< L2 1e-12) p1 (cwc:add p1 (cwc:mul v (/ (cwc:dot (cwc:sub pt p1) v) L2)))))

;; ── 도면에 그리기 (WCS · 지정한 레이어 · 색) ─────────────
(defun cwc:line (p q lay col)
  (entmakex (append (list '(0 . "LINE") (cons 8 lay)) (if col (list (cons 62 col))) (list (cons 10 p) (cons 11 q)))))

(defun cwc:circle (c r lay)
  (entmakex (list '(0 . "CIRCLE") (cons 8 lay) (cons 10 c) (cons 40 r))))

(defun cwc:pline (pts buls closed lay col)
  (entmakex (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay))
                    (if col (list (cons 62 col)))
                    (list '(100 . "AcDbPolyline") (cons 90 (length pts)) (cons 70 (if closed 1 0)) (cons 38 (caddr (car pts))))
                    (apply 'append (mapcar '(lambda (p b) (list (cons 10 (list (car p) (cadr p))) (cons 42 b))) pts buls)))))

;; 블록 안 객체 (0 레이어 · 색)
(defun cwc:dxf-line (p q col) (list '(0 . "LINE") '(8 . "0") (cons 62 col) (cons 10 p) (cons 11 q)))
(defun cwc:dxf-arc (c r a0 a1 col)
  (list '(0 . "ARC") '(8 . "0") (cons 62 col) (cons 10 c) (cons 40 r) (cons 50 (cwc:norm a0)) (cons 51 (cwc:norm a1))))
(defun cwc:dxf-box (pts col)
  (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(8 . "0") (cons 62 col) '(100 . "AcDbPolyline")
                (cons 90 (length pts)) '(70 . 1))
          (mapcar '(lambda (p) (cons 10 (list (car p) (cadr p)))) pts)))
(defun cwc:dxf-of (ent col / ed)
  (setq ed (vl-remove-if '(lambda (g) (member (car g) '(-1 5 102 330 360 8 62))) (entget ent)))
  (append (list (car ed) '(8 . "0") (cons 62 col)) (cdr ed)))

(defun cwc:make-block (name base dxfs)
  (entmake (list '(0 . "BLOCK") (cons 2 name) '(70 . 0) (cons 10 base)))
  (foreach d dxfs (entmake d))
  (entmake '((0 . "ENDBLK"))))

;; 예전 판이 만든 같은 이름 블록은 안쪽이 '개구부-창' 레이어 — 0 레이어로 (모양은 같음)
(defun cwc:fix-old-block (name / e ed)
  (setq e (cdr (assoc -2 (tblsearch "BLOCK" name))))
  (while e
    (setq ed (entget e))
    (if (= (strcase (cdr (assoc 8 ed))) "개구부-창") (entmod (subst '(8 . "0") (assoc 8 ed) ed)))
    (setq e (entnext e))))

(defun cwc:free-name (base / n nm)
  (setq nm base n 1)
  (while (tblsearch "BLOCK" nm) (setq n (1+ n) nm (strcat base "_" (itoa n))))
  nm)

(defun cwc:insert (space name pt rot sy / o)
  (cwc:mklayer "창문" 7)
  (setq o (vla-InsertBlock space (vlax-3d-point pt) name 1.0 sy 1.0 rot))
  (vla-put-Layer o "창문")
  o)

;; ── 창 블록 모양 ─────────────────────────────────────────
;; 곧은 창: 원점에서 +X 로 길이 L, +Y 로 두께 thk. 멀리언 50 (양 끝은 안쪽으로 붙임), 유리선 가운데 ±12
(defun cwc:dxf-linear (L thk bays / step i x out j s e gm)
  (setq step (/ (- L 50.0) bays) i 0)
  (while (<= i bays)
    (setq x (+ 25.0 (* i step)))
    (setq out (cons (cwc:dxf-box (list (list (- x 25.0) 0.0 0.0) (list (+ x 25.0) 0.0 0.0)
                                       (list (+ x 25.0) thk 0.0) (list (- x 25.0) thk 0.0)) 5) out))
    (setq i (1+ i)))
  (setq gm (/ thk 2.0) j 0)
  (while (< j bays)
    (setq s (+ 50.0 (* j step)) e (* (1+ j) step))
    (setq out (cons (cwc:dxf-line (list s 0.0 0.0) (list e 0.0 0.0) 5) out)
          out (cons (cwc:dxf-line (list s thk 0.0) (list e thk 0.0) 5) out))
    (if (> thk 40.0)
      (setq out (cons (cwc:dxf-line (list s (+ gm 12.0) 0.0) (list e (+ gm 12.0) 0.0) 4) out)
            out (cons (cwc:dxf-line (list s (- gm 12.0) 0.0) (list e (- gm 12.0) 0.0) 4) out))
      (setq out (cons (cwc:dxf-line (list s gm 0.0) (list e gm 0.0) 4) out)))
    (setq j (1+ j)))
  out)

;; 곡선 창: 원점 중심, 각 0 ~ sweep 에 멀리언 중심 (반각 hang)
(defun cwc:dxf-curved (ri ro sweep bays hang / astep i cur aR aL out j s e rm o)
  (setq rm (/ (+ ri ro) 2.0) astep (/ sweep bays) i 0 o '(0.0 0.0 0.0))
  (while (<= i bays)
    (setq cur (* i astep) aR (- cur hang) aL (+ cur hang))
    (setq out (cons (cwc:dxf-line (polar o aR ri) (polar o aR ro) 5) out)
          out (cons (cwc:dxf-line (polar o aL ri) (polar o aL ro) 5) out)
          out (cons (cwc:dxf-arc o ri aR aL 5) out)
          out (cons (cwc:dxf-arc o ro aR aL 5) out))
    (setq i (1+ i)))
  (setq j 0)
  (while (< j bays)
    (setq s (+ (* j astep) hang) e (- (* (1+ j) astep) hang))
    (setq out (cons (cwc:dxf-arc o ri s e 5) out)
          out (cons (cwc:dxf-arc o ro s e 5) out))
    (if (> (- ro ri) 40.0)
      (setq out (cons (cwc:dxf-arc o (+ rm 12.0) s e 4) out)
            out (cons (cwc:dxf-arc o (- rm 12.0) s e 4) out))
      (setq out (cons (cwc:dxf-arc o rm s e 4) out)))
    (setq j (1+ j)))
  out)

;; 원형 창: 한 바퀴를 bays 칸으로
(defun cwc:dxf-circle (ri ro bays / astep hang i cur aR aL nR out rm o)
  (setq rm (/ (+ ri ro) 2.0) astep (/ (+ pi pi) bays) hang (/ 25.0 rm) i 0 o '(0.0 0.0 0.0))
  (while (< i bays)
    (setq cur (* i astep) aR (- cur hang) aL (+ cur hang) nR (- (* (1+ i) astep) hang))
    (setq out (cons (cwc:dxf-line (polar o aR ri) (polar o aR ro) 5) out)
          out (cons (cwc:dxf-line (polar o aL ri) (polar o aL ro) 5) out)
          out (cons (cwc:dxf-arc o ri aR aL 5) out)
          out (cons (cwc:dxf-arc o ro aR aL 5) out)
          out (cons (cwc:dxf-arc o ri aL nR 5) out)
          out (cons (cwc:dxf-arc o ro aL nR 5) out))
    (if (> (- ro ri) 40.0)
      (setq out (cons (cwc:dxf-arc o (+ rm 12.0) aL nR 4) out)
            out (cons (cwc:dxf-arc o (- rm 12.0) aL nR 4) out))
      (setq out (cons (cwc:dxf-arc o rm aL nR 4) out)))
    (setq i (1+ i)))
  out)

;; ── 벽 자르기 ────────────────────────────────────────────
(defun cwc:piece (s e t0 t1 a b / pa pb)
  (setq pa (cwc:add s (cwc:mul (cwc:sub e s) (/ (- a t0) (- t1 t0))))
        pb (cwc:add s (cwc:mul (cwc:sub e s) (/ (- b t0) (- t1 t0)))))
  (if (<= t0 t1) (list pa pb) (list pb pa)))

(defun cwc:set-ends (ed pq)
  (subst (cons 10 (car pq)) (assoc 10 ed) (subst (cons 11 (cadr pq)) (assoc 11 ed) ed)))

(defun cwc:copy-ed (ed) (vl-remove-if '(lambda (g) (member (car g) '(-1 5 102 330 360))) ed))

;; 선 하나에서 [0, L] (t = lo 에서 u 방향 거리) 를 잘라 낸다
(defun cwc:cut-line (ent lo u L / ed s e t0 t1 tmin tmax k1 k2)
  (setq ed (entget ent)
        s (cwc:p3 (cdr (assoc 10 ed))) e (cwc:p3 (cdr (assoc 11 ed)))
        t0 (cwc:dot (cwc:sub s lo) u) t1 (cwc:dot (cwc:sub e lo) u)
        tmin (min t0 t1) tmax (max t0 t1))
  (if (and (< tmin (- L 0.01)) (> tmax 0.01) (> (abs (- t1 t0)) 1e-6))
    (progn
      (setq k1 (if (< tmin -0.01) (list tmin 0.0))
            k2 (if (> tmax (+ L 0.01)) (list L tmax)))
      (cond
        ((and k1 k2)
         (entmod (cwc:set-ends ed (cwc:piece s e t0 t1 (car k1) (cadr k1))))
         (entmake (cwc:set-ends (cwc:copy-ed ed) (cwc:piece s e t0 t1 (car k2) (cadr k2)))))
        (k1 (entmod (cwc:set-ends ed (cwc:piece s e t0 t1 (car k1) (cadr k1)))))
        (k2 (entmod (cwc:set-ends ed (cwc:piece s e t0 t1 (car k2) (cadr k2)))))
        (T (entdel ent)))
      T)))

;; 곧은 벽: [lo, lo+u·L] × [0, thk·n] 안의 평행한 벽선을 잘라 낸다 → (자른 수 자른 선의 레이어)
(defun cwc:cut-band (lo u n L thk faces wall_lay / cnt polys ed s e a b box pol hi mid f_top f_bot lay)
  (setq cnt 0 hi (cwc:add lo (cwc:mul u L)))
  (setq box (cwc:ss-around (cwc:mid lo (cwc:add hi (cwc:mul n thk))) (+ (/ (max L thk) 2.0) 60.0)
                           '((0 . "LINE,LWPOLYLINE"))))
  (foreach ent (cwc:ss-list box)
    (setq ed (entget ent))
    (cond
      ((cwc:locked-p (cdr (assoc 8 ed))) nil)
      ((= (cdr (assoc 0 ed)) "LINE")
       (setq s (cwc:p3 (cdr (assoc 10 ed))) e (cwc:p3 (cdr (assoc 11 ed)))
             a (cwc:dot (cwc:sub s lo) n) b (cwc:dot (cwc:sub e lo) n))
       (if (and (> (distance s e) 1e-6)
                (cwc:para-p (angle s e) (angle '(0 0 0) u))
                (> (min a b) -1.0) (< (max a b) (+ thk 1.0))
                (or (member ent faces) (cwc:wall-like-p ed wall_lay)))
         (if (cwc:cut-line ent lo u L) (setq cnt (1+ cnt) lay (cdr (assoc 8 ed))))))
      ((and (= (cdr (assoc 0 ed)) "LWPOLYLINE") (or (member ent faces) (cwc:wall-like-p ed wall_lay)))
       (setq polys (cons ent polys) lay (cdr (assoc 8 ed))))))
  ;; 폴리선 벽: 임시 사각형을 칼선으로 펜스 자르기 (표준 모드)
  (if polys
    (progn
      (setq pol (cwc:pline (list (cwc:add lo (cwc:mul n -50.0)) (cwc:add hi (cwc:mul n -50.0))
                                 (cwc:add hi (cwc:mul n (+ thk 50.0))) (cwc:add lo (cwc:mul n (+ thk 50.0))))
                           '(0.0 0.0 0.0 0.0) T (cond (wall_lay) (lay) ((getvar "CLAYER"))) nil))
      (setq mid (cwc:add lo (cwc:mul u (/ L 2.0)))
            f_top (cwc:add mid (cwc:mul n (+ thk 10.0)))
            f_bot (cwc:add mid (cwc:mul n -10.0)))
      (command "_.-view" "_s" "CWC_TMP")
      (setq *cwc:view* T)
      (command "_.zoom" "_c" "_non" (trans mid 0 1) (* (max L thk) 1.5))
      (vl-catch-all-apply
        '(lambda () (command "_.trim" pol "" "_f" "_non" (trans f_top 0 1) "_non" (trans f_bot 0 1) "" "")))
      (if (entget pol) (entdel pol))
      (command "_.-view" "_r" "CWC_TMP")
      (command "_.-view" "_d" "CWC_TMP")
      (setq *cwc:view* nil)
      (setq cnt (+ cnt (length polys)))))
  (list cnt (cond (wall_lay) (lay) ((getvar "CLAYER")))))

;; 구간 k=(a b) 에서 c=(x y) 빼기
(defun cwc:minus (k c / a b)
  (setq a (car k) b (cadr k))
  (if (or (<= (cadr c) a) (>= (car c) b))
    (list k)
    (append (if (> (car c) a) (list (list a (car c)))) (if (< (cadr c) b) (list (list (cadr c) b))))))

;; 호 [0, as] 에서 [os, os+sw] (os 는 0~2π) 를 뺀 나머지 구간들
(defun cwc:arc-keep (as os sw / keep)
  (setq keep (list (list 0.0 as)))
  (foreach c (list (list os (+ os sw)) (list (- os pi pi) (- (+ os sw) pi pi)))
    (setq keep (apply 'append (mapcar '(lambda (k) (cwc:minus k c)) keep))))
  (vl-remove-if '(lambda (k) (< (- (cadr k) (car k)) 1e-7)) keep))

;; 곡선 벽: 중심 c, 반지름 [ri, ro] 의 같은 중심 호·원에서 [a0, a0+sw] (반시계) 를 잘라 낸다 → 자른 수
(defun cwc:cut-arcband (c ri ro a0 sw faces wall_lay / cnt ed typ s as keep ed2)
  (setq cnt 0)
  (foreach ent (cwc:ss-list (cwc:ss-around c (+ ro 60.0) '((0 . "ARC,CIRCLE"))))
    (setq ed (entget ent) typ (cdr (assoc 0 ed)))
    (if (and (not (cwc:locked-p (cdr (assoc 8 ed))))
             (< (distance (cwc:p3 (cdr (assoc 10 ed))) c) 1.0)
             (> (cdr (assoc 40 ed)) (- ri 1.0)) (< (cdr (assoc 40 ed)) (+ ro 1.0))
             (or (member ent faces) (cwc:wall-like-p ed wall_lay)))
      (cond
        ((= typ "CIRCLE")
         (entmake (append (vl-remove-if '(lambda (g) (member (car g) '(-1 5 102 330 360 0 100))) ed)
                          (list '(0 . "ARC") (cons 50 (cwc:norm (+ a0 sw))) (cons 51 (cwc:norm a0)))))
         (entdel ent)
         (setq cnt (1+ cnt)))
        (T
         (setq s (cdr (assoc 50 ed)) as (cwc:span s (cdr (assoc 51 ed))))
         (if (< as 1e-9) (setq as (+ pi pi)))
         (setq keep (cwc:arc-keep as (cwc:span s a0) sw))
         (if (not (and (= (length keep) 1) (equal (car keep) (list 0.0 as) 1e-7)))
           (progn
             (cond
               ((null keep) (entdel ent))
               (T
                (entmod (subst (cons 50 (cwc:norm (+ s (car (car keep))))) (assoc 50 ed)
                               (subst (cons 51 (cwc:norm (+ s (cadr (car keep))))) (assoc 51 ed) ed)))
                (if (cadr keep)
                  (progn
                    (setq ed2 (cwc:copy-ed ed))
                    (entmake (subst (cons 50 (cwc:norm (+ s (car (cadr keep))))) (assoc 50 ed2)
                                    (subst (cons 51 (cwc:norm (+ s (cadr (cadr keep))))) (assoc 51 ed2) ed2)))))))
             (setq cnt (1+ cnt))))))))
  cnt)

;; ── 창 만들기 ────────────────────────────────────────────
(defun cwc:build-linear (space p1s u n L thk bays wall_lay faces / p1e p2s p2e r cnt name)
  (setq p1e (cwc:add p1s (cwc:mul u L)) p2s (cwc:add p1s (cwc:mul n thk)) p2e (cwc:add p1e (cwc:mul n thk)))
  (setq r (cwc:cut-band p1s u n L thk faces wall_lay) cnt (car r))
  (if (> cnt 0) (progn (cwc:line p1s p2s (cadr r) nil) (cwc:line p1e p2e (cadr r) nil)))
  (cwc:pline (list p1s p1e p2e p2s) '(0.0 0.0 0.0 0.0) T "개구부-창" nil)
  (setq name (strcat "CWC-L-W" (itoa (fix (+ L 0.5))) "-T" (itoa (fix (+ thk 0.5))) "-B" (itoa bays)))
  (if (tblsearch "BLOCK" name) (cwc:fix-old-block name) (cwc:make-block name '(0.0 0.0 0.0) (cwc:dxf-linear L thk bays)))
  (cwc:insert space name p1s (angle '(0 0 0) u) (if (> (cwc:cross u n) 0.0) 1.0 -1.0))
  cnt)

(defun cwc:build-curved (space c r1 r2 a0 sw bays wall_lay faces / ri ro rm hang a1 cnt name)
  (setq ri (min r1 r2) ro (max r1 r2) rm (/ (+ ri ro) 2.0) hang (/ 25.0 rm) a1 (+ a0 sw))
  (setq cnt (cwc:cut-arcband c ri ro a0 sw faces wall_lay))
  (if (> cnt 0)
    (progn (cwc:line (polar c a0 ri) (polar c a0 ro) wall_lay nil) (cwc:line (polar c a1 ri) (polar c a1 ro) wall_lay nil)))
  (cwc:pline (list (polar c a0 ri) (polar c a1 ri) (polar c a1 ro) (polar c a0 ro))
             (list (cwc:tan4 sw) 0.0 (- (cwc:tan4 sw)) 0.0) T "개구부-창" nil)
  (setq name (strcat "CWC-A-R" (itoa (fix (+ ri 0.5))) "-L" (itoa (fix (+ (* rm sw) 0.5)))
                     "-T" (itoa (fix (+ (- ro ri) 0.5))) "-B" (itoa bays)))
  (if (tblsearch "BLOCK" name)
    (cwc:fix-old-block name)
    (cwc:make-block name '(0.0 0.0 0.0) (cwc:dxf-curved ri ro (- sw (* 2.0 hang)) bays hang)))
  (cwc:insert space name c (+ a0 hang) 1.0)
  cnt)

(defun cwc:build-circle (space c r1 r2 bays walls / ri ro name)
  (setq ri (min r1 r2) ro (max r1 r2))
  (foreach w walls (if (not (cwc:locked-p (cdr (assoc 8 (entget w))))) (entdel w)))
  (cwc:circle c ri "개구부-창")
  (cwc:circle c ro "개구부-창")
  (setq name (strcat "CWC-C-R" (itoa (fix (+ ri 0.5))) "-T" (itoa (fix (+ (- ro ri) 0.5))) "-B" (itoa bays)))
  (if (tblsearch "BLOCK" name) (cwc:fix-old-block name) (cwc:make-block name '(0.0 0.0 0.0) (cwc:dxf-circle ri ro bays)))
  (cwc:insert space name c 0.0 1.0))

;; 폴리선을 따라 거리 d0 ~ d1 부분 → (점 목록 볼록도 목록)
(defun cwc:subpath (obj d0 d1 / p0 p1 i a e b pts buls)
  (setq p0 (vlax-curve-getParamAtDist obj d0) p1 (vlax-curve-getParamAtDist obj d1)
        pts (list (vlax-curve-getPointAtParam obj p0)) i (fix p0))
  (while (< i (- p1 1e-9))
    (setq a (max p0 i) e (min p1 (1+ i)) b (vla-getbulge obj i))
    (setq buls (cons (if (equal b 0.0 1e-12) 0.0 (cwc:tan4 (* 4.0 (atan b) (- e a)))) buls)
          pts (append pts (list (vlax-curve-getPointAtParam obj e)))
          i (1+ i)))
  (list pts (reverse (cons 0.0 buls))))

;; 폴리선 tmp 를 d 만큼 (바깥 벽 쪽으로) → 새 객체들
(defun cwc:offset (ent d / r)
  (setq r (vl-catch-all-apply 'vla-Offset (list (vlax-ename->vla-object ent) d)))
  (if (vl-catch-all-error-p r)
    nil
    (mapcar 'vlax-vla-object->ename (vlax-safearray->list (vlax-variant-value r)))))

(defun cwc:toward (ent o2 thk / try mp gap)
  ;; +thk 로 띄운 것이 바깥 벽에 닿으면 1, 아니면 -1
  (setq try (cwc:offset ent thk))
  (if try
    (progn
      (setq mp (vlax-curve-getPointAtParam (vlax-ename->vla-object (car try)) 0.5)
            gap (distance mp (vlax-curve-getClosestPointTo o2 mp)))
      (foreach x try (entdel x))
      (if (< gap (* 0.25 thk)) 1.0 -1.0))
    -1.0))

(defun cwc:build-poly (space e1 e2 bays wall_lay / o1 o2 tot pin thk step i d pout an dxfs j sp tmp side offs gm base name)
  (setq o1 (vlax-ename->vla-object e1) o2 (vlax-ename->vla-object e2)
        tot (vlax-curve-getDistAtParam o1 (vlax-curve-getEndParam o1))
        pin (vlax-curve-getStartPoint o1)
        thk (distance pin (vlax-curve-getClosestPointTo o2 pin))
        step (/ (- tot 50.0) bays) i 0)
  ;; 멀리언 (양 끝은 안쪽으로 붙임)
  (while (<= i bays)
    (setq d (+ 25.0 (* i step))
          pin (vlax-curve-getPointAtDist o1 d)
          pout (vlax-curve-getClosestPointTo o2 pin)
          an (angle pin pout))
    (setq dxfs (cons (cwc:dxf-box (list (polar pin (+ an (/ pi 2.0)) 25.0) (polar pin (- an (/ pi 2.0)) 25.0)
                                        (polar pout (- an (/ pi 2.0)) 25.0) (polar pout (+ an (/ pi 2.0)) 25.0)) 5) dxfs))
    (setq i (1+ i)))
  ;; 칸마다: 안쪽 면 · 바깥 면(5) · 유리(4) — 멀리언을 파고들지 않게 칸 안에서만
  (setq gm (/ thk 2.0) j 0 side nil)
  (while (< j bays)
    (setq sp (cwc:subpath o1 (+ 50.0 (* j step)) (* (1+ j) step))
          tmp (cwc:pline (car sp) (cadr sp) nil "0" 5))
    (if (null side) (setq side (cwc:toward tmp o2 thk)))
    (setq dxfs (cons (cwc:dxf-of tmp 5) dxfs))
    (foreach k (append (list (list thk 5)) (if (> thk 40.0) (list (list (+ gm 12.0) 4) (list (- gm 12.0) 4)) (list (list gm 4))))
      (foreach x (cwc:offset tmp (* side (car k)))
        (setq dxfs (cons (cwc:dxf-of x (cadr k)) dxfs))
        (entdel x)))
    (entdel tmp)
    (setq j (1+ j)))
  ;; 개구부 경계: 두 벽 폴리선을 '개구부-창' 으로 복사 + 양 끝 막음
  (foreach o (list o1 o2) (vla-put-Layer (vla-Copy o) "개구부-창"))
  (cwc:line (vlax-curve-getStartPoint o1) (vlax-curve-getClosestPointTo o2 (vlax-curve-getStartPoint o1)) "개구부-창" nil)
  (cwc:line (vlax-curve-getEndPoint o1) (vlax-curve-getClosestPointTo o2 (vlax-curve-getEndPoint o1)) "개구부-창" nil)
  ;; 창 블록 (폴리선마다 모양이 달라 이름을 새로)
  (setq base (vlax-curve-getStartPoint o1)
        name (cwc:free-name (strcat "CWC-PL-L" (itoa (fix (+ tot 0.5))) "-T" (itoa (fix (+ thk 0.5))) "-B" (itoa bays))))
  (cwc:make-block name base dxfs)
  (cwc:insert space name base 0.0 1.0)
  (foreach e (list e1 e2) (if (not (cwc:locked-p (cdr (assoc 8 (entget e))))) (entdel e))))

;; ── 입력 보조 ────────────────────────────────────────────
(defun cwc:tangent (ent pt / o par)
  (setq o (vlax-ename->vla-object ent)
        par (vlax-curve-getParamAtPoint o (vlax-curve-getClosestPointTo o pt)))
  (if par (angle '(0 0 0) (vlax-curve-getFirstDeriv o par))))

;; p(WCS) 근처에서 e1 과 평행한(호·원은 중심이 같은) 곡선 중 p 에 가장 가까운 것
(defun cwc:parallel-at (p e1 / ed1 c1 best bd ed o q d t1 t2)
  (setq ed1 (entget e1))
  (if (member (cdr (assoc 0 ed1)) '("ARC" "CIRCLE")) (setq c1 (cwc:p3 (cdr (assoc 10 ed1)))))
  (foreach e (cwc:ss-list (cwc:ss-around p (max 20.0 (* 0.02 (getvar "VIEWSIZE"))) '((0 . "LINE,ARC,CIRCLE,LWPOLYLINE"))))
    (if (not (eq e e1))
      (progn
        (setq ed (entget e) o (vlax-ename->vla-object e)
              q (vlax-curve-getClosestPointTo o p) d (distance p q))
        (if (and (or (null bd) (< d bd))
                 (if c1
                   (and (member (cdr (assoc 0 ed)) '("ARC" "CIRCLE")) (< (distance (cwc:p3 (cdr (assoc 10 ed))) c1) 1.0))
                   (and (not (member (cdr (assoc 0 ed)) '("ARC" "CIRCLE")))
                        (setq t2 (cwc:tangent e q))
                        (setq t1 (cwc:tangent e1 (vlax-curve-getClosestPointTo (vlax-ename->vla-object e1) q)))
                        (cwc:para-p t1 t2))))
          (setq bd d best e)))))
  best)

;; 호 범위 안에 각 a 가 있는지
(defun cwc:in-arc-p (ed a / s as)
  (if (= (cdr (assoc 0 ed)) "CIRCLE")
    T
    (progn
      (setq s (cdr (assoc 50 ed)) as (cwc:span s (cdr (assoc 51 ed))))
      (<= (cwc:span s a) (+ as 1e-9)))))

;; 두 각 a·b 사이의 창 범위 (a0 sw) — 벽 호 범위 안에 드는 쪽, 둘 다면 짧은 쪽
(defun cwc:arc-range (a b ed / s1 s2 in1 in2)
  (setq s1 (cwc:span a b) s2 (cwc:span b a)
        in1 (or (null ed) (cwc:in-arc-p ed (+ a (/ s1 2.0))))
        in2 (or (null ed) (cwc:in-arc-p ed (+ b (/ s2 2.0)))))
  (cond ((and in1 (or (not in2) (<= s1 s2))) (list a s1))
        (in2 (list b s2))
        (T (if (<= s1 s2) (list a s1) (list b s2)))))

;; 원(중심 c, 반지름 rr)이 구간 pq 와 만나는지 (호는 그 점이 호 위에 있어야)
(defun cwc:circle-hit-p (ed p q / c rr dv fv qa qb qc disc hit pt)
  (setq c (cwc:p3 (cdr (assoc 10 ed))) rr (cdr (assoc 40 ed))
        dv (cwc:sub q p) fv (cwc:sub p c)
        qa (cwc:dot dv dv) qb (* 2.0 (cwc:dot fv dv)) qc (- (cwc:dot fv fv) (* rr rr)))
  (if (> qa 1e-12)
    (progn
      (setq disc (- (* qb qb) (* 4.0 qa qc)))
      (if (>= disc 0.0)
        (foreach k (list (/ (- (- qb) (sqrt disc)) (* 2.0 qa)) (/ (+ (- qb) (sqrt disc)) (* 2.0 qa)))
          (if (and (>= k -1e-9) (<= k (+ 1.0 1e-9)))
            (progn
              (setq pt (cwc:add p (cwc:mul dv k)))
              (if (cwc:in-arc-p ed (angle c pt)) (setq hit T))))))))
  hit)

;; 가이드 사각형 → ((네 점, 반시계) 지울 객체들) 또는 nil
(defun cwc:rect (ss / ed pls pts cen)
  (foreach e (cwc:ss-list ss)
    (setq ed (entget e))
    (if (and (= (cdr (assoc 0 ed)) "LWPOLYLINE") (= 1 (logand 1 (cdr (assoc 70 ed)))) (= 4 (cdr (assoc 90 ed))))
      (setq pls (cons e pls))))
  (if (= (length pls) 1)
    (setq pts (mapcar '(lambda (g) (list (cadr g) (caddr g) (cond ((cdr (assoc 38 (entget (car pls))))) (0.0))))
                      (vl-remove-if-not '(lambda (g) (= (car g) 10)) (entget (car pls)))))
    (progn
      (setq pls nil)
      (foreach e (cwc:ss-list ss)
        (setq ed (entget e))
        (if (= (cdr (assoc 0 ed)) "LINE")
          (foreach p (list (cwc:p3 (cdr (assoc 10 ed))) (cwc:p3 (cdr (assoc 11 ed))))
            (if (not (vl-some '(lambda (q) (< (distance p q) 1.0)) pts)) (setq pts (cons p pts))))))
      (if (= (length pts) 4)
        (foreach e (cwc:ss-list ss)
          (setq ed (entget e))
          (if (and (= (cdr (assoc 0 ed)) "LINE")
                   (vl-some '(lambda (q) (< (distance (cwc:p3 (cdr (assoc 10 ed))) q) 1.0)) pts)
                   (vl-some '(lambda (q) (< (distance (cwc:p3 (cdr (assoc 11 ed))) q) 1.0)) pts))
            (setq pls (cons e pls)))))))
  (if (= (length pts) 4)
    (progn
      (setq cen (cwc:mul (cwc:add (cwc:add (car pts) (cadr pts)) (cwc:add (caddr pts) (cadddr pts))) 0.25))
      (list (vl-sort pts '(lambda (a b) (< (angle cen a) (angle cen b)))) pls))))

;; 곧은 벽: 시작점을 두 벽선에 수선으로 내림 → ("L" 안쪽 시작점 벽방향 두께벡터)
(defun cwc:line-geom (e1 e2 w2 / ed1 ed2 seg1 seg2 q p1s p2s)
  (setq ed1 (entget e1) ed2 (entget e2)
        seg1 (list (cwc:p3 (cdr (assoc 10 ed1))) (cwc:p3 (cdr (assoc 11 ed1)))))
  (if (= (cdr (assoc 0 ed2)) "LINE")
    (setq seg2 (list (cwc:p3 (cdr (assoc 10 ed2))) (cwc:p3 (cdr (assoc 11 ed2)))))
    (setq q (vlax-curve-getClosestPointTo (vlax-ename->vla-object e2) w2)
          seg2 (list q (cwc:add q (cwc:sub (cadr seg1) (car seg1))))))
  (setq p1s (cwc:foot w2 (car seg1) (cadr seg1)) p2s (cwc:foot w2 (car seg2) (cadr seg2)))
  (list "L" p1s (cwc:unit (cwc:sub (cadr seg1) (car seg1))) (cwc:sub p2s p1s)))

;; ── 끝점 고르기: 커서를 따라 창 띠(벽 곡률대로) · 칸 · 길이를 미리 보여 줌 (getpoint 대신) ──
;; g = ("L" 시작점 벽방향 두께벡터) | ("A" 중심 안반지름 바깥반지름 시작각 벽호ed) — 모두 WCS
(setq *cwc-snaps* '((1 . "end") (2 . "mid") (4 . "cen") (8 . "nod") (16 . "qua")
                    (32 . "int") (64 . "ins") (128 . "per") (2048 . "app")))
(defun cwc:px () (/ (getvar "VIEWSIZE") (cadr (getvar "SCREENSIZE"))))

;; OSMODE 스냅 중 커서(UCS)에서 가장 가까운 것 → UCS 점 / 근처점은 다른 스냅이 없을 때만
(defun cwc:snap (p / m lim best bd sp d)
  (setq m (getvar "OSMODE"))
  (if (and (> m 0) (= 0 (logand m 16384)))
    (progn
      (setq lim (* 1.5 (max 8 (getvar "APERTURE")) (cwc:px)))
      (foreach b *cwc-snaps*
        (if (and (/= 0 (logand m (car b)))
                 (setq sp (osnap p (strcat "_" (cdr b))))
                 (< (setq d (distance (list (car sp) (cadr sp)) (list (car p) (cadr p)))) lim)
                 (or (null bd) (< d bd)))
          (setq bd d best sp)))
      (if (and (null best) (/= 0 (logand m 512)) (setq sp (osnap p "_nea"))) (setq best sp))))
  best)

;; 호 위 점들 (WCS, 높이 z)
(defun cwc:arc-pts (c r a0 sw z / i n out)
  (setq n (max 2 (fix (+ 0.5 (/ (abs sw) 0.05)))) i 0)
  (while (<= i n)
    (setq out (cons (list (+ (car c) (* r (cos (+ a0 (* sw (/ i (float n))))))) (+ (cadr c) (* r (sin (+ a0 (* sw (/ i (float n))))))) z) out)
          i (1+ i)))
  (reverse out))

;; 커서 w3(WCS, nil 이면 기본 방향) · 길이 len(nil 이면 커서까지) → (안쪽 점들 바깥 점들 길이 끝점 칸 나눔 점 쌍들)
(defun cwc:end-geom (g w3 len / p1s u nv s p1e c r1 r2 a2 ed z rm a3 rg a0 sw ae bays k mull)
  (if (= (car g) "L")
    (progn
      (setq p1s (nth 1 g) u (nth 2 g) nv (nth 3 g)
            s (if w3 (cwc:dot (cwc:sub w3 p1s) u) 1.0))
      (if len (setq s (if (< s 0.0) (- len) len)))
      (setq p1e (cwc:add p1s (cwc:mul u s)) bays (cwc:fit-bays (abs s) (cond (*cwc_bays*) (3))) k 1)
      (while (< k bays)
        (setq mull (cons (list (cwc:add p1s (cwc:mul u (* s (/ k (float bays)))))
                               (cwc:add (cwc:add p1s (cwc:mul u (* s (/ k (float bays))))) nv)) mull)
              k (1+ k)))
      (list (list p1s p1e) (list (cwc:add p1s nv) (cwc:add p1e nv)) (abs s) p1e mull))
    (progn
      (setq c (nth 1 g) r1 (nth 2 g) r2 (nth 3 g) a2 (nth 4 g) ed (nth 5 g) z (caddr c)
            rm (/ (+ r1 r2) 2.0)
            a3 (if w3 (angle c w3) (+ a2 (/ 100.0 rm)))
            rg (cwc:arc-range a2 a3 ed) a0 (car rg) sw (cadr rg))
      (if len
        (setq sw (/ len rm) a0 (if (equal (car rg) a2 1e-9) a2 (- a2 sw))))
      (setq ae (if (equal a0 a2 1e-9) (+ a2 sw) a0)
            bays (cwc:fit-bays (* rm sw) (cond (*cwc_bays*) (3))) k 1)
      (while (< k bays)
        (setq mull (cons (list (polar c (+ a0 (* sw (/ k (float bays)))) r1) (polar c (+ a0 (* sw (/ k (float bays)))) r2)) mull)
              k (1+ k)))
      (list (cwc:arc-pts c r1 a0 sw z) (cwc:arc-pts c r2 a0 sw z) (* rm sw) (polar c ae r1) mull))))

(defun cwc:vec-line (pts / out) ; 점들 → grvecs 쌍 (UCS)
  (while (cdr pts) (setq out (cons (trans (cadr pts) 0 1) (cons (trans (car pts) 0 1) out)) pts (cdr pts)))
  (reverse out))

(defun cwc:show (g w3 len snp buf / eg a b vs h px)
  (redraw)
  (setq eg (cwc:end-geom g w3 len) a (car eg) b (cadr eg))
  (if (> (caddr eg) 1e-6)
    (progn
      (setq vs (append (cwc:vec-line a) (cwc:vec-line b)
                       (cwc:vec-line (list (car a) (car b))) (cwc:vec-line (list (last a) (last b)))))
      (foreach m (nth 4 eg) (setq vs (append vs (cwc:vec-line m))))
      (grvecs (cons 4 vs))))
  (if snp
    (progn
      (setq px (cwc:px) h (* 5.0 px))
      (grvecs (list 2 (list (- (car snp) h) (- (cadr snp) h)) (list (+ (car snp) h) (- (cadr snp) h))
                      (list (+ (car snp) h) (- (cadr snp) h)) (list (+ (car snp) h) (+ (cadr snp) h))
                      (list (+ (car snp) h) (+ (cadr snp) h)) (list (- (car snp) h) (+ (cadr snp) h))
                      (list (- (car snp) h) (+ (cadr snp) h)) (list (- (car snp) h) (- (cadr snp) h))))))
  (grtext -1 (strcat "창 길이 " (rtos (caddr eg) 2 0)
                     (if (> (strlen buf) 0) (strcat " · 입력 " buf) ""))))

;; → 끝점(UCS) 또는 nil(Enter·오른쪽 클릭). 숫자를 치고 Enter = 커서 쪽으로 그 길이(호는 벽 가운데 호 길이)
(defun cwc:pick-end (g / go gr code val snp w3 buf res len)
  (setq go T buf "")
  (princ "\n3. 개구부 끝점을 클릭하거나 창 길이를 입력하세요: ")
  (while go
    (setq gr (grread T 15 0) code (car gr) val (cadr gr))
    (cond
      ((= code 5)
       (setq snp (cwc:snap val) w3 (trans (cond (snp) (val)) 1 0))
       (cwc:show g w3 nil snp buf))
      ((= code 3)
       (setq snp (cwc:snap val) res (cond (snp) (val)) go nil))
      ((member code '(11 25)) (setq go nil))
      ((= code 2)
       (cond
         ((member val '(13 32))
          (cond
            ((= buf "") (setq go nil))
            ((> (setq len (atof buf)) 0.0)
             (setq res (trans (nth 3 (cwc:end-geom g w3 len)) 0 1) go nil))
            (T (princ "\n[주의] 창 길이를 숫자로 입력하세요: ") (setq buf ""))))
         ((= val 8)
          (if (> (strlen buf) 0) (progn (setq buf (substr buf 1 (1- (strlen buf)))) (princ "\010 \010"))))
         ((or (and (>= val 48) (<= val 57)) (= val 46))
          (setq buf (strcat buf (chr val)))
          (princ (chr val))
          (cwc:show g w3 (if (> (atof buf) 0.0) (atof buf)) snp buf))))))
  (redraw)
  (grtext -1 "")
  res)

(defun cwc:parse-lengths (str / pos lst val)
  (while (setq pos (vl-string-search "," str))
    (setq val (atof (vl-string-trim " " (substr str 1 pos))))
    (if (> val 0) (setq lst (append lst (list val))))
    (setq str (substr str (+ pos 2))))
  (setq val (atof (vl-string-trim " " str)))
  (if (> val 0) (setq lst (append lst (list val))))
  lst)

(defun cwc:ask-bays ( / b)
  (if (null *cwc_bays*) (setq *cwc_bays* 3))
  (initget 6)
  (setq b (getint (strcat "\n나눌 칸 수 <" (itoa *cwc_bays*) ">: ")))
  (if b (setq *cwc_bays* b))
  *cwc_bays*)

;; 칸이 너무 좁으면(멀리언 사이 60 미만) 칸 수를 줄인다
(defun cwc:fit-bays (L bays)
  (while (and (> bays 1) (< (/ (- L 50.0) bays) 110.0)) (setq bays (1- bays)))
  bays)

;; ==============================================================================
(defun c:CWC ( / *error* doc space sv undo_open mode jobs sel e1 ed1 typ p2 e2 ed2 p3 bays wall_lay
                 seg1 seg2 w2 w3 p1s p2s p1e p2e L thk u n c r1 r2 rg rr pts dels pA pB pC pD l1 l2 ss arcs best bd
                 m1 m2 rin rout ed diff guide glay lens gl pairs cur used k chk d1 a b job cnt)

  (defun *error* (msg)
    (redraw)
    (grtext -1 "")
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if *cwc:view* (progn (command-s "_.-view" "_r" "CWC_TMP") (command-s "_.-view" "_d" "CWC_TMP") (setq *cwc:view* nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        space (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("OSMODE" "CMDECHO" "TRIMEXTENDMODE" "EDGEMODE")))

  (if (null *CWC_MODE*) (setq *CWC_MODE* "1"))
  (initget "1 2 3")
  (setq mode (getkword (strcat "\n[모드] 1: 클릭 / 2: 가이드 사각형 / 3: 여러 개 한 번에 <" *CWC_MODE* ">: ")))
  (if mode (setq *CWC_MODE* mode))
  (setq mode *CWC_MODE*)

  ;; ---- 1. 입력 → 할 일(jobs) ----
  (cond
    ;; 모드 1: 클릭
    ((= mode "1")
     (setq sel (entsel "\n1. 안쪽 벽선(선·호·원·폴리선)을 고르세요: "))
     (if sel (setq e1 (car sel) ed1 (entget e1) typ (cdr (assoc 0 ed1)) wall_lay (cdr (assoc 8 ed1))))
     (cond
       ((null sel) nil)
       ((not (member typ '("LINE" "ARC" "CIRCLE" "LWPOLYLINE")))
        (princ "\n[주의] 선·호·원·폴리선을 고르세요."))
       ((null (setq p2 (getpoint (cond ((= typ "CIRCLE") "\n2. 맞은편 원 벽선을 클릭하세요: ")
                                       ((= typ "LWPOLYLINE") "\n2. 맞은편 꺾인 벽선을 클릭하세요: ")
                                       (T "\n2. 맞은편 벽선에서 개구부 시작점을 클릭하세요: ")))))
        nil)
       ((null (setq w2 (trans p2 1 0) e2 (cwc:parallel-at w2 e1)))
        (princ "\n[주의] 맞은편 벽선(평행한 선·같은 중심의 호)을 찾지 못했습니다. 맞은편 선 위를 클릭하세요."))
       ((= typ "CIRCLE")
        (setq c (cwc:p3 (cdr (assoc 10 ed1))) r1 (cdr (assoc 40 ed1)) r2 (cdr (assoc 40 (entget e2))))
        (setq jobs (list (list "C" c r1 r2 (cwc:ask-bays) (list e1 e2)))))
       ((= typ "LWPOLYLINE")
        (setq jobs (list (list "P" e1 e2 (cwc:ask-bays) wall_lay))))
       ((null (setq p3 (cwc:pick-end
                         (if (= typ "ARC")
                           (list "A" (cwc:p3 (cdr (assoc 10 ed1))) (cdr (assoc 40 ed1)) (cdr (assoc 40 (entget e2)))
                                 (angle (cwc:p3 (cdr (assoc 10 ed1))) w2) ed1)
                           (cwc:line-geom e1 e2 w2)))))
        nil)
       ((= typ "ARC")
        (setq w3 (trans p3 1 0) c (cwc:p3 (cdr (assoc 10 ed1))) r1 (cdr (assoc 40 ed1)) r2 (cdr (assoc 40 (entget e2)))
              rg (cwc:arc-range (angle c w2) (angle c w3) ed1))
        (if (< (cadr rg) 0.01)
          (princ "\n[주의] 개구부 시작점과 끝점이 같습니다.")
          (setq jobs (list (list "A" c r1 r2 (car rg) (cadr rg) (cwc:ask-bays) wall_lay (list e1 e2))))))
       (T
        ;; 곧은 벽: 시작점을 두 벽선에 수선으로 내림
        (setq w3 (trans p3 1 0) ed2 (entget e2)
              seg1 (list (cwc:p3 (cdr (assoc 10 ed1))) (cwc:p3 (cdr (assoc 11 ed1)))))
        (if (= (cdr (assoc 0 ed2)) "LINE")
          (setq seg2 (list (cwc:p3 (cdr (assoc 10 ed2))) (cwc:p3 (cdr (assoc 11 ed2)))))
          (setq seg2 (list (vlax-curve-getClosestPointTo (vlax-ename->vla-object e2) w2)
                           (cwc:add (vlax-curve-getClosestPointTo (vlax-ename->vla-object e2) w2) (cwc:sub (cadr seg1) (car seg1))))))
        (setq p1s (cwc:foot w2 (car seg1) (cadr seg1))
              p2s (cwc:foot w2 (car seg2) (cadr seg2))
              p1e (cwc:foot w3 (car seg1) (cadr seg1))
              L (distance p1s p1e) thk (distance p1s p2s))
        (if (or (< L 100.0) (< thk 10.0))
          (princ "\n[주의] 개구부가 너무 짧거나 두께를 잴 수 없습니다.")
          (setq jobs (list (list "L" p1s (cwc:unit (cwc:sub p1e p1s)) (cwc:unit (cwc:sub p2s p1s)) L thk
                                 (cwc:ask-bays) wall_lay (list e1 e2))))))))

    ;; 모드 2: 가이드 사각형
    ((= mode "2")
     (princ "\n창을 낼 자리의 가이드 사각형을 고르세요 (닫힌 폴리선은 클릭, 선 넷이면 드래그).")
     (setq ss (ssget '((0 . "LINE,LWPOLYLINE"))))
     (cond
       ((null ss) nil)
       ((null (setq rr (cwc:rect ss)))
        (princ "\n[주의] 가이드 사각형을 찾지 못했습니다 — 사각형만 고르세요 (네 꼭짓점)."))
       (T
        (setq pts (car rr) dels (cadr rr)
              pA (nth 0 pts) pB (nth 1 pts) pC (nth 2 pts) pD (nth 3 pts)
              l1 (distance pA pB) l2 (distance pB pC))
        (if (> l1 l2)
          (setq p1s pA p1e pB p2s pD p2e pC L l1 thk l2)
          (setq p1s pB p1e pC p2s pA p2e pD L l2 thk l1))
        (setq u (cwc:unit (cwc:sub p1e p1s)) n (cwc:unit (cwc:sub p2s p1s))
              m1 (cwc:mid p1s p2s) m2 (cwc:mid p1e p2e))
        ;; 사각형을 가로지르는 벽 호: 두 짧은 변과 모두 만나고, 반지름이 꼭짓점까지 거리와 맞는 것
        (setq best nil bd nil)
        (foreach e (cwc:ss-list (ssget "_CP" (mapcar '(lambda (p) (trans p 0 1)) pts) '((0 . "ARC,CIRCLE"))))
          (setq ed (entget e) c (cwc:p3 (cdr (assoc 10 ed)))
                rin (/ (+ (distance c p1s) (distance c p1e)) 2.0)
                rout (/ (+ (distance c p2s) (distance c p2e)) 2.0)
                diff (min (abs (- (cdr (assoc 40 ed)) rin)) (abs (- (cdr (assoc 40 ed)) rout))))
          (if (and (<= diff (max 5.0 (* 0.25 thk)))
                   (cwc:circle-hit-p ed p1s p2s)
                   (cwc:circle-hit-p ed p1e p2e)
                   (or (null bd) (< diff bd)))
            (setq best e bd diff)))
        (if best
          (progn
            (setq ed (entget best) c (cwc:p3 (cdr (assoc 10 ed)))
                  r1 (/ (+ (distance c p1s) (distance c p1e)) 2.0)
                  r2 (/ (+ (distance c p2s) (distance c p2e)) 2.0)
                  rg (cwc:arc-range (angle c m1) (angle c m2) ed))
            (setq jobs (list (list "A" c r1 r2 (car rg) (cadr rg) (cwc:ask-bays) (cdr (assoc 8 ed)) nil))))
          (setq jobs (list (list "L" p1s u n L thk (cwc:ask-bays) nil nil)))))))

    ;; 모드 3: 가이드 선 쌍
    (T
     (setq sel (entsel "\n기준 가이드 선을 클릭하세요: "))
     (cond
       ((null sel) nil)
       ((/= (cdr (assoc 0 (entget (car sel)))) "LINE") (princ "\n[주의] 가이드는 선(LINE)이어야 합니다."))
       ((null (setq glay (cdr (assoc 8 (entget (car sel))))
                    lens (cwc:parse-lengths (getstring T "\n창 길이를 쉼표로 (예: 3000,2000): "))))
        (princ "\n[주의] 길이를 입력하세요."))
       (T
        (setq bays (cwc:ask-bays))
        (princ "\n한꺼번에 만들 영역을 드래그하세요.")
        (setq ss (ssget (list '(0 . "LINE") (cons 8 glay))))
        (foreach e (cwc:ss-list ss)
          (setq ed (entget e) a (cwc:p3 (cdr (assoc 10 ed))) b (cwc:p3 (cdr (assoc 11 ed))))
          (setq gl (cons (list e a b (cwc:mid a b)) gl)))
        (while gl
          (setq cur (car gl) gl (cdr gl) used nil k 0)
          (while (and (< k (length gl)) (not used))
            (setq chk (nth k gl) d1 (distance (cadddr cur) (cadddr chk)))
            (if (and (vl-some '(lambda (x) (< (abs (- d1 x)) 5.0)) lens)
                     (cwc:para-p (angle (cadr cur) (caddr cur)) (angle (cadr chk) (caddr chk))))
              (setq pairs (cons (list cur chk) pairs) gl (vl-remove chk gl) used T))
            (setq k (1+ k))))
        (foreach pr pairs
          ;; 가이드 a 가 벽을 가로지르는 방향 = n, 두께 = a 의 길이, 창 방향 u = a → b (n 에 수직)
          (setq a (car pr) b (cadr pr)
                p1s (cadr a) p2s (caddr a)
                n (cwc:unit (cwc:sub p2s p1s))
                thk (distance p1s p2s)
                d1 (cwc:sub (cadddr b) (cadddr a))
                u (cwc:unit (cwc:sub d1 (cwc:mul n (cwc:dot d1 n))))
                L (cwc:dot d1 u))
          (setq jobs (cons (list "L" p1s u n L thk bays nil nil) jobs)
                dels (append dels (list (car a) (car b)))))
        (if (null pairs) (princ "\n[주의] 입력한 길이만큼 떨어진 평행한 가이드 쌍이 없습니다."))))))

  ;; ---- 2. 만들기 (실행 취소 한 번) ----
  (if jobs
    (progn
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)
      (setvar "OSMODE" 0)
      (setvar "TRIMEXTENDMODE" 0)
      (setvar "EDGEMODE" 0)
      (cwc:mklayer "개구부-창" 6)
      (cwc:mklayer "창문" 7)
      ;; 가이드는 먼저 지운다 (벽선으로 잘리지 않게)
      (foreach e dels (if (entget e) (entdel e)))
      (setq cnt 0)
      (foreach job jobs
        (cond
          ((= (car job) "L")
           (setq bays (cwc:fit-bays (nth 4 job) (nth 6 job)))
           (if (/= bays (nth 6 job)) (princ (strcat "\n[알림] 칸이 너무 좁아 " (itoa bays) "칸으로 줄였습니다.")))
           (setq cnt (+ cnt (cwc:build-linear space (nth 1 job) (nth 2 job) (nth 3 job) (nth 4 job) (nth 5 job) bays
                                              (nth 7 job) (nth 8 job)))))
          ((= (car job) "A")
           (setq bays (cwc:fit-bays (* (/ (+ (nth 2 job) (nth 3 job)) 2.0) (nth 5 job)) (nth 6 job)))
           (setq cnt (+ cnt (cwc:build-curved space (nth 1 job) (nth 2 job) (nth 3 job) (nth 4 job) (nth 5 job) bays
                                              (nth 7 job) (nth 8 job)))))
          ((= (car job) "C")
           (cwc:build-circle space (nth 1 job) (nth 2 job) (nth 3 job) (nth 4 job) (nth 5 job)))
          ((= (car job) "P")
           (cwc:build-poly space (nth 1 job) (nth 2 job) (nth 3 job) (nth 4 job)))))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 창 " (itoa (length jobs)) "개를 만들었습니다 (레이어: 창문)."))))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
