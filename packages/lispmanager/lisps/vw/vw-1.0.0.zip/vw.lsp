;; ======================================================================
;; [ VW ] (Vacuum Wrap) 진공 포장식 외곽선 추출 엔진
;; - 스케치업 잔선 도면을 거대한 박스로 감싼 뒤, 역으로 외곽선만 떠냅니다.
;; - 뚫려있는 미세한 간극(Gap)을 무시하는 기능이 탑재되어 있습니다.
;; ======================================================================
(defun c:VW ( / ss i obj minPt maxPt oMin oMax margin p1 p3 ptClick old_gap eLast tempBox ssNew )
  (vl-load-com)
  (prompt "\n[외곽선 추출 VW] 외곽선을 딸 객체(스케치업 도면)들을 모두 드래그하세요: ")
  (setq ss (ssget))
  (if (not ss) (exit))

  ;; 1. 선택된 도면 전체의 바운딩 박스(최외곽 크기) 계산
  (setq oMin '(1e99 1e99) oMax '(-1e99 -1e99))
  (setq i 0)
  (while (< i (sslength ss))
    (setq obj (vlax-ename->vla-object (ssname ss i)))
    (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'minPt 'maxPt))))
      (progn
        (setq pMin (vlax-safearray->list minPt))
        (setq pMax (vlax-safearray->list maxPt))
        (if (< (car pMin) (car oMin)) (setq oMin (list (car pMin) (cadr oMin))))
        (if (< (cadr pMin) (cadr oMin)) (setq oMin (list (car oMin) (cadr pMin))))
        (if (> (car pMax) (car oMax)) (setq oMax (list (car pMax) (cadr oMax))))
        (if (> (cadr pMax) (cadr oMax)) (setq oMax (list (car oMax) (cadr pMax))))
      )
    )
    (setq i (1+ i))
  )

  ;; 2. 건물보다 10% 더 큰 거대한 '임시 박스' 생성
  (setq margin (/ (distance oMin oMax) 10.0))
  (setq p1 (list (- (car oMin) margin) (- (cadr oMin) margin) 0.0))
  (setq p3 (list (+ (car oMax) margin) (+ (cadr oMax) margin) 0.0))
  (command "_.RECTANG" "_non" p1 "_non" p3)
  (setq tempBox (entlast))

  ;; 3. 임시 박스와 건물 사이의 '허공' 좌표 계산
  (setq ptClick (list (- (car p3) (/ margin 2.0)) (- (cadr p3) (/ margin 2.0)) 0.0))

  ;; 4. 💡 [핵심] 끊긴 선 무시! 스케치업 잔선 틈새(Gap) 허용치 임시 상향
  (setq old_gap (getvar "HPGAPTOL"))
  (setvar "HPGAPTOL" 50.0) ;; 도면 단위에 따라 틈새가 너무 크면 이 숫자를 늘리세요.

  ;; 5. 허공에 진공 포장(BOUNDARY) 터뜨리기
  (setq eLast (entlast))
  ;; 에러 무시를 위해 vl-catch-all-apply 사용 (구멍이 너무 커서 새어나가는 경우 방지)
  (vl-catch-all-apply 
    'vl-cmdf 
    (list "_.-BOUNDARY" "_A" "_B" "_N" ss tempBox "" "_I" "_Y" "_O" "_P" "" "_non" ptClick "")
  )

  (setvar "HPGAPTOL" old_gap) ;; 시스템 변수 원상복구

  ;; 6. 임시 박스 삭제 및 추출된 외곽선 빨간색으로 시각화
  (entdel tempBox)
  
  (setq ssNew (ssadd))
  (while (setq eLast (entnext eLast))
    (ssadd eLast ssNew)
  )

  (if (> (sslength ssNew) 0)
    (progn
      ;; 제일 바깥에 쳐진 박스 껍데기도 하나 생기므로 그것도 지워줌
      (command "_.ERASE" (ssname ssNew (1- (sslength ssNew))) "")
      (command "_.CHPROP" ssNew "" "_C" "1" "") ;; 진짜 건물 외곽선만 빨간색(1)으로 변경
      (princ "\n▶ [쾌감!] 고무줄 효과 없이 건물의 오목한 외곽선이 완벽히 빨간색으로 추출되었습니다.")
    )
    (princ "\n▶ [실패] 선이 너무 심하게 끊겨있어 닫힌 영역을 포장할 수 없습니다. OVERKILL을 먼저 실행해 보세요.")
  )
  (princ)
)