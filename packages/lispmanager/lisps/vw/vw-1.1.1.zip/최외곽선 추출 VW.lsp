;;; ==============================================================================
;;;  VW — 고른 도면의 바깥 실루엣(최외곽선) 뽑기
;;;
;;;  객체를 고르면 그 둘레에 임시 상자를 두르고, 상자와 도면 사이 빈 곳에서 경계를 찾아 도면의 바깥 실루엣만 빨간 폴리선으로 남긴다.
;;;  떨어진 동이 여럿이면 동마다 하나씩. 틈 허용치(기본 mm 도면 50 · 기억) 이하의 끊긴 곳은 이어진 것으로 본다.
;;;   · 경계는 고른 객체 + 상자만으로 찾는다 (주변 치수·다른 도면이 끼지 않음). UCS 를 돌려 둔 화면에서도 맞다.
;;;   · 경계는 캐드 명령의 옵션 키워드 없이 찾는다 (bpoly — 1.1.1: 캐드 판에 따라 -BOUNDARY 옵션 키워드가 거절됐음)
;;;   · 틈이 커서 바깥이 안으로 새면 실패로 알리고 아무것도 남기지 않는다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 경계 찾기에 쓰는 시스템 변수 (이 캐드에 있는 것만) 의 지금 값
(defun vw:hpvars ( )
  (vl-remove-if '(lambda (v) (null (cdr v)))
    (mapcar '(lambda (v) (cons v (getvar v))) '("HPGAPTOL" "HPBOUND" "HPISLANDDETECTIONMODE" "HPISLANDDETECTION"))))

;; 점 p(UCS) 둘레 경계 → 새로 생긴 폴리선들 (넓은 것부터, islands 가 아니면 바깥 둘레 하나만) / 없으면 nil.
;;  캐드 명령의 옵션 키워드를 쓰지 않는다 — 캐드 판에 따라 -BOUNDARY 의 옵션 키워드가 거절되어 '옵션 키워드가 유효하지 않음' 뒤 멈췄음.
;;  bpoly 함수로 찾고, 그 함수가 오류면 옵션 없는 -BOUNDARY 로. 틈 · 섬 · 폴리선으로 만들기는 시스템 변수로 넘기고 바로 원래대로.
;;  ss = 경계로 쓸 객체 · cmd = T 면 bpoly 를 건너뛰고 옵션 없는 -BOUNDARY 로 (화면에 보이는 모든 것이 경계).
;;  -BOUNDARY 로 찾았으면 plain 을 T 로 (부른 쪽의 지역 변수 — 고른 것만으로 못 찾았다고 알림).
(defun vw:bound (p gap islands ss cmd / e0 e out old k)
  (setq e0 (entlast) old (vw:hpvars))
  (foreach v (list (cons "HPGAPTOL" gap) '("HPBOUND" . 1) (cons "HPISLANDDETECTIONMODE" (if islands 1 0)) '("HPISLANDDETECTION" . 1))
    (if (assoc (car v) old) (vl-catch-all-apply 'setvar (list (car v) (cdr v)))))
  (if (or cmd (vl-catch-all-error-p (vl-catch-all-apply 'bpoly (list p ss))))
    (progn
      (command "_.-BOUNDARY" "_non" p "")
      (setq k 0)
      (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))
      (setq plain T)))
  (foreach v old (vl-catch-all-apply 'setvar (list (car v) (cdr v))))
  (setq e (if e0 (entnext e0) (entnext)))
  (while e
    (if (and (entget e) (= (cdr (assoc 0 (entget e))) "LWPOLYLINE")) (setq out (cons e out)))
    (setq e (entnext e)))
  (setq out (vl-sort out '(lambda (a b) (> (vla-get-Area (vlax-ename->vla-object a)) (vla-get-Area (vlax-ename->vla-object b))))))
  (if (and (cdr out) (not islands))
    (progn (foreach x (cdr out) (entdel x)) (setq out (list (car out)))))
  out)

;; 바깥 실루엣: 임시 상자와 도면 사이 빈 곳 p 에서 섬까지 찾는다 → (상자 둘레 실루엣 …) 넓은 것부터.
;;  bpoly 가 섬을 만들지 않는 캐드면(상자 둘레 하나뿐) 옵션 없는 -BOUNDARY 로 한 번 더.
(defun vw:silhouette (p gap ss / new)
  (setq new (vw:bound p gap T ss nil))
  (if (and (< (length new) 2) (not plain))
    (progn
      (foreach e new (entdel e))
      (setq new (vw:bound p gap T ss T))))
  new)

(defun c:VW ( / *error* doc undo_open sv ss ssx i o a b p q lo hi m box gap new big out plain)
  (defun *error* (msg)
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n바깥 실루엣을 뽑을 객체를 모두 고르세요: ")
  (if (null (setq ss (ssget)))
    (princ "\n고른 객체가 없습니다.")
    (progn
      ;; 범위 (월드)
      (setq i 0)
      (while (< i (sslength ss))
        (setq o (vlax-ename->vla-object (ssname ss i)))
        (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
          (setq a (vlax-safearray->list a) b (vlax-safearray->list b)
                lo (if lo (mapcar 'min lo a) a) hi (if hi (mapcar 'max hi b) b)))
        (setq i (1+ i)))
      (setq gap (if (getenv "HyVwGap") (atof (getenv "HyVwGap")) (if (= (getvar "INSUNITS") 6) 0.05 50.0)))
      (initget 4)
      (setq gap (cond ((getdist (strcat "\n틈 허용치 <" (rtos gap 2 3) ">: "))) (gap)))
      (setenv "HyVwGap" (rtos gap 2 8))
      (cond
        ((or (null lo) (< (distance (list (car lo) (cadr lo)) (list (car hi) (cadr hi))) 1e-6))
         (princ "\n[주의] 범위가 없는 객체라 실루엣을 뽑을 수 없습니다."))
        (T
         (setq m (max (/ (distance (list (car lo) (cadr lo)) (list (car hi) (cadr hi))) 10.0) (* 4 gap) 1.0)
               sv (cons (cons "CMDECHO" (getvar "CMDECHO")) (vw:hpvars)))
         (vla-StartUndoMark doc)
         (setq undo_open T)
         (setq box (entmakex (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
                                   (list 10 (- (car lo) m) (- (cadr lo) m)) (list 10 (+ (car hi) m) (- (cadr lo) m))
                                   (list 10 (+ (car hi) m) (+ (cadr hi) m)) (list 10 (- (car lo) m) (+ (cadr hi) m)))))
         (ssadd box ss)
         (setvar "CMDECHO" 0)
         ;; 새 폴리선 중 가장 넓은 것 = 상자 둘레 → 지움, 나머지 = 실루엣
         (setq new (vw:silhouette (trans (list (- (+ (car hi) m) (/ m 2.0)) (- (+ (cadr hi) m) (/ m 2.0)) 0.0) 0 1) gap ss))
         (foreach v sv (setvar (car v) (cdr v)))
         (setq sv nil)
         (entdel box)
         (if new (setq big (car new) out (cdr new)))
         (cond
           ((null new) (princ "\n[주의] 경계를 찾지 못했습니다. 틈 허용치를 키우거나 OVERKILL 을 먼저 해 보세요."))
           ((null out)
            (entdel big)
            (princ "\n[주의] 바깥이 도면 안으로 샜습니다 (틈이 허용치보다 큼). 틈 허용치를 키워 다시 하세요."))
           (T
            (entdel big)
            (foreach x out (vla-put-Color (vlax-ename->vla-object x) 1))
            (if plain (princ "\n[알림] 이 캐드에서는 고른 선만으로 경계를 찾지 못해 화면에 보이는 모든 선으로 찾았습니다. 주변 선이 끼었으면 그 선을 숨기고 다시 하세요."))
            (princ (strcat "\n[완료] 바깥 실루엣 " (itoa (length out)) "개를 빨간 폴리선으로 뽑았습니다."))
            ;; 실루엣 범위가 고른 범위와 다르면 바깥이 안으로 샌 것 (실내 방이 실루엣으로 나옴)
            (setq a nil b nil)
            (foreach x out
              (vla-GetBoundingBox (vlax-ename->vla-object x) 'p 'q)
              (setq p (vlax-safearray->list p) q (vlax-safearray->list q)
                    a (if a (mapcar 'min a p) p) b (if b (mapcar 'max b q) q)))
            (if (> (max (abs (- (car a) (car lo))) (abs (- (cadr a) (cadr lo))) (abs (- (car b) (car hi))) (abs (- (cadr b) (cadr hi))))
                   (max (* 2 gap) (* 1e-6 (distance lo hi))))
              (progn
                (setq ssx (ssadd))
                (foreach x out (ssadd x ssx))
                (sssetfirst nil ssx)
                (princ "\n[주의] 실루엣 범위가 고른 범위보다 작습니다 — 틈이 허용치보다 커서 바깥이 안으로 샜을 수 있습니다 (골라 둠, 틈 허용치를 키워 보세요).")))))
         (vla-EndUndoMark doc)
         (setq undo_open nil)))))
  (princ))

(princ)
