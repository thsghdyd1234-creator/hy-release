;; ======================================================================
;; [VW] 최외곽선 추출
;; - 도면을 큰 사각형으로 감싼 뒤 바깥에서부터 외곽선만 추출합니다.
;; - 작은 틈은 무시합니다.
;; ======================================================================
(defun c:VW ( / ss i obj minPt maxPt oMin oMax margin p1 p3 ptClick old_gap eLast tempBox ssNew )
  (vl-load-com)
  (prompt "\n[VW 최외곽선 추출] 외곽선을 만들 객체(스케치업 도면)를 모두 드래그하세요: ")
  (setq ss (ssget))
  (if (not ss) (exit))

  ;; 1. 선택된 도면 전체의 경계 상자(최외곽 크기) 계산
  (setq oMin '(1e99 1e99) oMax '(-1e99 -1e99))
  (setq i 0)
  (while (< i (sslength ss))
    (setq obj (vlax-ename->vla-object (ssname ss i)))
    (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'minPt 'maxPt))))
      (progn
        (setq pMin (vlax-safearray->list minPt))
        (setq pMax (vlax-safearray->list maxPt))
        (if (< (car pMin) (car oMin)) (setq oMin (list (car pMin) (cadr oMin))))
        (if (< (cadr pMin) (cadr oMin)) (setq oMin (list (car oMin) (cadr pMin))))
        (if (> (car pMax) (car oMax)) (setq oMax (list (car pMax) (cadr oMax))))
        (if (> (cadr pMax) (cadr oMax)) (setq oMax (list (car oMax) (cadr pMax))))
      )
    )
    (setq i (1+ i))
  )

  ;; 2. 건물보다 10% 큰 임시 사각형 생성
  (setq margin (/ (distance oMin oMax) 10.0))
  (setq p1 (list (- (car oMin) margin) (- (cadr oMin) margin) 0.0))
  (setq p3 (list (+ (car oMax) margin) (+ (cadr oMax) margin) 0.0))
  (command "_.RECTANG" "_non" p1 "_non" p3)
  (setq tempBox (entlast))

  ;; 3. 임시 사각형과 건물 사이 빈 곳의 좌표 계산
  (setq ptClick (list (- (car p3) (/ margin 2.0)) (- (cadr p3) (/ margin 2.0)) 0.0))

  ;; 4. 끊긴 선을 무시하도록 틈 허용치(HPGAPTOL)를 잠시 올림
  (setq old_gap (getvar "HPGAPTOL"))
  (setvar "HPGAPTOL" 50.0) ;; 도면 단위에 따라 틈새가 너무 크면 이 숫자를 늘리세요.

  ;; 5. 빈 곳에서 BOUNDARY 실행
  (setq eLast (entlast))
  ;; 오류 무시를 위해 vl-catch-all-apply 사용 (틈이 너무 커서 경계를 못 만드는 경우)
  (vl-catch-all-apply 
    'vl-cmdf 
    (list "_.-BOUNDARY" "_A" "_B" "_N" ss tempBox "" "_I" "_Y" "_O" "_P" "" "_non" ptClick "")
  )

  (setvar "HPGAPTOL" old_gap) ;; 시스템 변수 원상복구

  ;; 6. 임시 사각형 삭제, 추출한 외곽선을 빨간색으로
  (entdel tempBox)
  
  (setq ssNew (ssadd))
  (while (setq eLast (entnext eLast))
    (ssadd eLast ssNew)
  )

  (if (> (sslength ssNew) 0)
    (progn
      ;; 맨 바깥 사각형 경계도 하나 생기므로 지움
      (command "_.ERASE" (ssname ssNew (1- (sslength ssNew))) "")
      (command "_.CHPROP" ssNew "" "_C" "1" "") ;; 건물 외곽선만 빨간색(1)으로 변경
      (princ "\n[완료] 오목한 부분까지 따라간 건물 외곽선을 빨간색으로 추출했습니다.")
    )
    (princ "\n[오류] 선이 많이 끊겨 있어 닫힌 영역을 만들 수 없습니다. OVERKILL을 먼저 실행해 보세요.")
  )
  (princ)
)