;;; ==============================================================================
;;;  CL — 보이는 색으로 객체를 목표 레이어에 모으기 (Color to Layer)
;;;
;;;  1. 기준 색을 가진 객체를 클릭 (ByLayer 면 그 레이어의 색)
;;;  2. 목표 레이어의 객체를 클릭 — Enter = 지난번 목표 레이어, 이름(N) = 이름으로, 색 유지(K) = 색은 그대로 두기
;;;  3. 영역을 고르면 '보이는 색'이 같은 객체를 목표 레이어로 옮기고 색을 ByLayer 로 바꾼다
;;;   · 트루컬러·색상표 색은 그 색 그대로 비교 (번호가 가까운 다른 색과 섞이지 않음)
;;;   · ByBlock 은 화면에 보이는 대로 7번으로 본다. 잠긴 레이어의 객체는 빠진다.
;;;   · 한 번 실행 = 실행 취소 한 번(U). 목표 레이어와 색 유지 설정은 기억한다.
;;; ==============================================================================

;; 레이어의 색 → (A . 번호) / (T . 트루컬러)
(defun cl:layer-color (lay / ed)
  (setq ed (entget (tblobjname "LAYER" lay)))
  (if (assoc 420 ed) (cons 'T (cdr (assoc 420 ed))) (cons 'A (abs (cdr (assoc 62 ed))))))

;; 레이어 색은 레이어마다 한 번만 읽는다 (cl_cache 는 c:CL 의 지역 변수)
(defun cl:lcolor (lay / hit)
  (if (setq hit (assoc (strcase lay) cl_cache))
    (cdr hit)
    (progn (setq hit (cl:layer-color lay) cl_cache (cons (cons (strcase lay) hit) cl_cache)) hit)))

;; 객체의 보이는 색
(defun cl:color (ed / c)
  (cond ((assoc 420 ed) (cons 'T (cdr (assoc 420 ed))))
        ((and (setq c (cdr (assoc 62 ed))) (/= c 256)) (cons 'A (if (= c 0) 7 c)))
        (T (cl:lcolor (cdr (assoc 8 ed))))))

(defun cl:name (k / v)
  (if (= (car k) 'T)
    (progn (setq v (cdr k))
           (strcat "트루컬러 " (itoa (lsh v -16)) "," (itoa (logand (lsh v -8) 255)) "," (itoa (logand v 255))))
    (strcat (itoa (cdr k)) "번")))

(defun cl:move (e lay / o)
  (setq o (vlax-ename->vla-object e))
  (vla-put-Layer o lay)
  (if (not *cl_keep*) (vla-put-Color o 256)))

(defun c:CL ( / *error* doc undo_open cl_cache sel key lay done s ss i e ed n same fail)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  ;; 1. 기준 색
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n1. 옮길 색을 가진 객체를 클릭하세요 (ByLayer 면 레이어 색): ")))
              (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (if sel
    (progn
      (setq key (cl:color (entget (car sel))))
      (princ (strcat "\n기준 색: " (cl:name key)))
      ;; 2. 목표 레이어
      (while (not done)
        (setvar "ERRNO" 0)
        (initget "Name Keep")
        (setq sel (entsel (strcat "\n2. 목표 레이어의 객체를 클릭하세요 [이름(N)/색 유지(K) — 지금 "
                                  (if *cl_keep* "색 유지" "ByLayer 로") "]"
                                  (if (and *cl_lay* (tblsearch "LAYER" *cl_lay*)) (strcat " <" *cl_lay* ">") "") ": ")))
        (cond
          ((= sel "Keep") (setq *cl_keep* (not *cl_keep*)))
          ((= sel "Name")
           (setq s (getstring T "\n목표 레이어 이름: "))
           (cond ((= s "") nil)
                 ((tblsearch "LAYER" s) (setq lay (cdr (assoc 2 (tblsearch "LAYER" s))) done T))
                 (T (princ (strcat "\n[주의] [" s "] 레이어가 없습니다.")))))
          ((listp sel) (if sel (setq lay (cdr (assoc 8 (entget (car sel)))) done T)
                         (if (= (getvar "ERRNO") 7)
                           (princ "\n빗나갔습니다. 다시 클릭하세요.")
                           (setq lay (if (and *cl_lay* (tblsearch "LAYER" *cl_lay*)) *cl_lay*) done T))))))
      (cond
        ((null lay) (princ "\n목표 레이어를 고르지 않았습니다."))
        ((progn (setq *cl_lay* lay)
                (prompt (strcat "\n3. 색이 " (cl:name key) "인 객체를 [" lay "] 레이어로 옮길 영역을 고르세요 (전체는 ALL, 잠긴 레이어는 빠짐): "))
                (null (setq ss (ssget "_:L"))))
         (princ "\n고른 객체가 없습니다."))
        (T
         (vla-StartUndoMark doc)
         (setq undo_open T i 0 n 0 same 0 fail 0)
         (while (< i (sslength ss))
           (setq e (ssname ss i) ed (entget e))
           (if (equal (cl:color ed) key)
             (cond
               ((and (= (strcase (cdr (assoc 8 ed))) (strcase lay))
                     (or *cl_keep* (member (cdr (assoc 62 ed)) '(nil 256))))
                (setq same (1+ same)))
               ((vl-catch-all-error-p (vl-catch-all-apply 'cl:move (list e lay))) (setq fail (1+ fail)))
               (T (setq n (1+ n)))))
           (setq i (1+ i)))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (if (= (+ n same fail) 0)
           (princ (strcat "\n고른 영역에 색이 " (cl:name key) "인 객체가 없습니다."))
           (princ (strcat "\n[완료] " (itoa n) "개를 [" lay "] 레이어로 옮겼습니다"
                          (if *cl_keep* " (색은 그대로)" " (색은 ByLayer)")
                          (if (> same 0) (strcat ", " (itoa same) "개는 이미 그 레이어") "")
                          (if (> fail 0) (strcat ", " (itoa fail) "개는 바꾸지 못함") "") "."))))))
    (princ "\n고른 객체가 없습니다."))
  (princ))

(princ)
