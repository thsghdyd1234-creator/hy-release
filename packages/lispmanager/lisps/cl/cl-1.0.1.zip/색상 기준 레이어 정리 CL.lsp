;; ======================================================================
;; [CL] 색상 기준 레이어 정리 (Color to Layer)
;; - 직접 지정한 색은 물론 ByLayer로 물려받은 보이는 색상까지 봅니다.
;; - 고른 영역의 객체를 한 번에 목표 레이어로 옮기고 색을 ByLayer로 바꿉니다.
;; ======================================================================
(defun c:CL ( / ent1 ed1 col1 lay1 lay_data target_col ent2 lay2 ss ss_target i ent ed ent_col ent_lay obj_col old_cmd )
  (vl-load-com)
  (setq old_cmd (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)

  ;; 1. 기준 색상 추출 (ByLayer 색상까지 확인)
  (prompt "\n[CL 레이어 정리] 1. 바꿀 '색상'을 가진 객체를 클릭하세요 (ByLayer 상태도 가능): ")
  (setq ent1 (car (entsel)))
  (if (not ent1) (exit))
  (setq ed1 (entget ent1))

  ;; 선택한 객체의 시각적 색상 계산
  (setq col1 (cdr (assoc 62 ed1)))
  (if (or (not col1) (= col1 256)) ; 객체에 색이 없는 ByLayer 상태인 경우
    (progn
      (setq lay1 (cdr (assoc 8 ed1)))
      (setq lay_data (tblsearch "LAYER" lay1)) ; 레이어 정보에서 색상을 읽음
      (setq target_col (abs (cdr (assoc 62 lay_data))))
      (prompt (strcat "\n선택한 객체는 [ByLayer] 상태입니다. 도면층(" lay1 ")의 색상 [" (itoa target_col) "]번을 대상으로 합니다."))
    )
    (progn ; 객체에 색이 직접 지정된 경우
      (setq target_col col1)
      (prompt (strcat "\n직접 지정된 색상 [" (itoa target_col) "]번을 대상으로 합니다."))
    )
  )

  ;; 2. 목표 레이어 추출
  (prompt "\n[CL 레이어 정리] 2. '목표 레이어'에 있는 객체를 클릭하세요: ")
  (setq ent2 (car (entsel)))
  (if (not ent2) (exit))
  (setq lay2 (cdr (assoc 8 (entget ent2))))
  (prompt (strcat "\n목표 레이어: [" lay2 "]"))

  ;; 3. 영역 선택
  (prompt (strcat "\n보이는 색상이 (" (itoa target_col) ")인 모든 객체를 레이어(" lay2 ")로 보낼 영역을 드래그하세요 (전체는 ALL): "))
  (setq ss (ssget))

  ;; 4. 걸러 낸 객체를 한 번에 정리
  (if ss
    (progn
      (setq ss_target (ssadd)) ; 처리할 객체 목록
      (setq i 0)
      
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq ed (entget ent))
        
        ;; 드래그한 개별 객체들의 시각적 색상 판별
        (setq ent_col (cdr (assoc 62 ed)))
        (if (or (not ent_col) (= ent_col 256))
          (progn
            (setq ent_lay (cdr (assoc 8 ed)))
            (setq obj_col (abs (cdr (assoc 62 (tblsearch "LAYER" ent_lay)))))
          )
          (setq obj_col ent_col) ; 색이 직접 지정된 경우
        )

        ;; 객체 색상이 대상 색상과 같으면 목록에 추가
        (if (= obj_col target_col)
          (ssadd ent ss_target)
        )
        (setq i (1+ i))
      )
      
      ;; 목록의 객체를 한 번에 변경
      (if (> (sslength ss_target) 0)
        (progn
          (command "_.CHPROP" ss_target "" "_LA" lay2 "_C" "BYLAYER" "")
          (princ (strcat "\n[완료] 총 " (itoa (sslength ss_target)) "개의 객체를 [" lay2 "] 레이어로 옮기고 색을 ByLayer로 바꿨습니다."))
        )
        (princ (strcat "\n선택한 영역에 색상 [" (itoa target_col) "]번인 객체가 없습니다."))
      )
    )
    (princ "\n선택된 영역이 없습니다.")
  )
  
  (setvar "CMDECHO" old_cmd)
  (princ)
)