(defun c:cc ( / ss p1 p2 input mode num dx dy dz i p_new)
  (setvar "cmdecho" 0)
  (command "_.undo" "begin") ; 실행 취소를 한 번에 묶기 위함

  (prompt "\n[스케치업 스타일 복사] 복사할 객체를 선택하세요: ")
  (if (setq ss (ssget))
    (progn
      (if (setq p1 (getpoint "\n기준점 지정: "))
        (progn
          (if (setq p2 (getpoint p1 "\n두 번째 점 지정 (복사될 위치): "))
            (progn
              ;; 1. 첫 번째 복사본 우선 생성 (_non 옵션으로 오스냅 간섭 방지)
              (command "_.copy" ss "" "_non" p1 "_non" p2)

              ;; 2. 다중/등분 옵션 입력받기
              (setq input (getstring "\n배열 옵션 입력 [*숫자(다중복사) 또는 /숫자(등분복사)] <종료는 Enter>: "))

              (if (and input (/= input ""))
                (progn
                  (setq mode (substr input 1 1))
                  (setq num (atoi (substr input 2)))

                  (cond
                    ;; ★ 곱하기 모드 (*5 : 지정한 간격 그대로 5개의 복사본 생성)
                    ((= mode "*")
                     (if (> num 1)
                       (progn
                         (setq i 2)
                         (while (<= i num)
                           (setq dx (* (- (car p2) (car p1)) i))
                           (setq dy (* (- (cadr p2) (cadr p1)) i))
                           (setq dz (* (- (caddr p2) (caddr p1)) i))
                           (setq p_new (list (+ (car p1) dx) (+ (cadr p1) dy) (+ (caddr p1) dz)))
                           
                           (command "_.copy" ss "" "_non" p1 "_non" p_new)
                           (setq i (1+ i))
                         )
                       )
                     )
                    )

                    ;; ★ 나누기 모드 (/5 : 기준점과 두 번째 점 사이를 5등분하여 객체 채움)
                    ((= mode "/")
                     (if (> num 1)
                       (progn
                         (setq dx (/ (- (car p2) (car p1)) (float num)))
                         (setq dy (/ (- (cadr p2) (cadr p1)) (float num)))
                         (setq dz (/ (- (caddr p2) (caddr p1)) (float num)))

                         (setq i 1)
                         (while (< i num)
                           (setq p_new (list (+ (car p1) (* dx i)) (+ (cadr p1) (* dy i)) (+ (caddr p1) (* dz i))))
                           
                           (command "_.copy" ss "" "_non" p1 "_non" p_new)
                           (setq i (1+ i))
                         )
                       )
                     )
                    )
                    (t (prompt "\n올바르지 않은 입력입니다. 명령어를 종료합니다."))
                  )
                )
              )
            )
          )
        )
      )
    )
  )

  (command "_.undo" "end")
  (setvar "cmdecho" 1)
  (princ "\n완료되었습니다.")
  (princ)
)