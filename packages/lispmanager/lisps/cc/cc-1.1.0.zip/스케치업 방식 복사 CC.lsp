;;; ==============================================================================
;;;  CC — 스케치업처럼 복사한 뒤 개수 정하기
;;;
;;;  객체를 고르고 기준점 → 두 번째 점을 찍으면 하나 복사된다. 이어서 개수를 넣는다:
;;;    *5 · 5* · x5 · 5x  = 같은 간격으로 모두 5개 (스케치업 다중 복사)
;;;    /5 · 5/            = 두 점 사이를 5 등분한 자리마다 (스케치업 등분)
;;;  다시 넣으면 개수를 바꾼다 (앞에 넣은 것은 지우고 다시). Enter = 끝.
;;;  COPYMODE 와 상관없이 동작하고, 잠긴 레이어의 객체는 빠진다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; "*5" "5x" "/5" … → ("*" . 5) / ("/" . 5) / nil
(defun cc:parse (s / u n)
  (setq u (strcase (vl-string-trim " " s)) n (atoi (vl-string-trim "*X/ " u)))
  (cond
    ((< n 1) nil)
    ((/= (vl-string-trim "0123456789*X/ " u) "") nil)
    ((vl-string-search "/" u) (cons "/" n))
    ((or (vl-string-search "*" u) (vl-string-search "X" u)) (cons "*" n))))

;; 객체 목록을 v 만큼 옮긴 복사본 → 새 객체 목록
(defun cc:copy (objs v / out c)
  (foreach o objs
    (setq c (vla-Copy o))
    (vla-Move c (vlax-3d-point '(0.0 0.0 0.0)) (vlax-3d-point v))
    (setq out (cons c out)))
  out)

(defun c:CC ( / *error* doc undo_open ss i objs p1 p2 v spec extra n s)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n복사할 객체를 고르세요 (잠긴 레이어는 빠짐): ")
  (cond
    ((null (setq ss (ssget "_:L"))) (princ "\n고른 객체가 없습니다."))
    ((null (setq p1 (getpoint "\n기준점: "))) (princ "\n그만두었습니다."))
    ((null (setq p2 (getpoint p1 "\n두 번째 점 (복사할 자리): "))) (princ "\n그만두었습니다."))
    (T
     (setq i 0)
     (while (< i (sslength ss)) (setq objs (cons (vlax-ename->vla-object (ssname ss i)) objs) i (1+ i)))
     (setq v (mapcar '- (trans p2 1 0) (trans p1 1 0)))
     (vla-StartUndoMark doc)
     (setq undo_open T n 1)
     (cc:copy objs v)
     (while (/= "" (setq s (getstring "\n개수 [*5 · 5x = 같은 간격 5개 / /5 = 5 등분] <Enter = 끝>: ")))
       (if (null (setq spec (cc:parse s)))
         (princ "\n*5 · 5x · /5 처럼 넣으세요.")
         (progn
           ;; 앞에 넣은 개수로 만든 것은 지우고 다시
           (foreach o extra (vl-catch-all-apply 'vla-Delete (list o)))
           (setq extra nil i 2)
           (if (= (car spec) "*")
             (while (<= i (cdr spec))
               (setq extra (append (cc:copy objs (mapcar '(lambda (x) (* x i)) v)) extra) i (1+ i)))
             (progn
               (setq i 1)
               (while (< i (cdr spec))
                 (setq extra (append (cc:copy objs (mapcar '(lambda (x) (* x (/ (float i) (cdr spec)))) v)) extra) i (1+ i)))))
           (setq n (cdr spec))
           (princ (strcat "\n" (if (= (car spec) "*") "같은 간격으로 " "두 점 사이를 등분해 ") (itoa n) "개 (다시 넣으면 바꿈).")))))
     (vla-EndUndoMark doc)
     (setq undo_open nil)
     (princ (strcat "\n[완료] 복사본 " (itoa n) "개를 만들었습니다."))))
  (princ))

(princ)
