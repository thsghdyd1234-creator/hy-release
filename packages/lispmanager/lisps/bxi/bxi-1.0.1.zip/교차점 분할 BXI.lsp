(defun c:BXI ( / doc old_err undo_started mode opt ss i j ent1 ent2 obj1 obj2 pts pList startPt endPt curPt nextPt dList ents_to_delete lay col ang diff_h1 diff_h2 diff_h3 diff_v1 diff_v2 do_break count k new_ent_data objType param paramList ptOnCurve brkPt old_osmode len rad segN arcAng step idx distList cleanDistList d d0 pt1 pt2 )
  (vl-load-com)
  (prompt "\n[BXI 교차점 분할] 선을 교차점에서 나눕니다. 스케치업 모드는 곡선을 선분으로 바꿉니다.")

  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (vl-catch-all-apply 'vla-EndUndoMark (list doc))
  (setq undo_started nil)
  (setq old_err *error*)
  (setq old_osmode (getvar "OSMODE"))
  
  (defun *error* (msg)
    (if old_osmode (setvar "OSMODE" old_osmode))
    (if undo_started
      (progn
        (vl-catch-all-apply 'vla-EndUndoMark (list doc))
        (command-s "_.U")
      )
    )
    (setq *error* old_err)
    (princ "\n[작업 취소] 실행 전 상태로 되돌렸습니다.")
    (princ)
  )

  ;; 1. 작업 모드 선택
  (initget "1 2")
  (setq mode (getkword "\n작업 모드 [1: 일반 캐드용(기존) / 2: 스케치업 내보내기용(곡선 세그먼트화)] <1>: "))
  (if (not mode) (setq mode "1"))

  ;; 2. 방향 옵션 선택
  (initget "All X Y")
  (setq opt (getkword "\n분할할 선의 방향을 선택하세요 [전체(All) / 수평(X) / 수직(Y)] <All>: "))
  (if (not opt) (setq opt "All"))

  ;; 3. 객체 선택
  (if (= mode "1")
    (prompt (strcat "\n일반 모드 [" opt "] - 교차점을 분할할 선/스플라인/호를 드래그하세요: "))
    (prompt (strcat "\n스케치업 모드 [" opt "] - 선분으로 바꾸고 교차 분할할 객체를 모두 드래그하세요: "))
  )
  
  ;; 모드 2일 경우 원(CIRCLE)과 타원(ELLIPSE) 자동 포함
  (if (= mode "1")
    (setq ss (ssget '((0 . "LINE,SPLINE,ARC"))))
    (setq ss (ssget '((0 . "LINE,SPLINE,ARC,CIRCLE,ELLIPSE"))))
  )

  (if ss
    (progn
      (vla-StartUndoMark doc)
      (setq undo_started T)
      (setvar "OSMODE" 0)

      (if (= mode "1")
        (princ "\n교차점을 찾아 분할하는 중...")
        (princ "\n곡선을 선분으로 바꾸고 교차점에서 분할하는 중...")
      )
      
      (setq ents_to_delete (ssadd) i 0 count 0)
      
      ;; 4. 메인 루프 실행
      (while (< i (sslength ss))
        (setq ent1 (ssname ss i) obj1 (vlax-ename->vla-object ent1))
        (setq objType (cdr (assoc 0 (entget ent1))))
        
        (setq startPt (vl-catch-all-apply 'vlax-curve-getStartPoint (list obj1)))
        (setq endPt (vl-catch-all-apply 'vlax-curve-getEndPoint (list obj1)))
        
        (if (and (not (vl-catch-all-error-p startPt)) (not (vl-catch-all-error-p endPt)))
          (progn
            (if (> (distance startPt endPt) 1e-6)
              (setq ang (angle startPt endPt))
              (setq ang 0.0)
            )
            
            (setq diff_h1 (abs (- ang 0.0)) diff_h2 (abs (- ang pi)) diff_h3 (abs (- ang (* pi 2.0))))
            (setq diff_v1 (abs (- ang (/ pi 2.0))) diff_v2 (abs (- ang (* pi 1.5))))
            
            (setq do_break nil)
            (cond
              ((= opt "All") (setq do_break T))
              ;; 스케치업 모드에서는 방향과 무관하게 모든 곡선 객체 강제 다각화 진행
              ((and (= mode "2") (wcmatch objType "ARC,CIRCLE,SPLINE,ELLIPSE")) (setq do_break T)) 
              ((= opt "X") (if (or (< diff_h1 0.05) (< diff_h2 0.05) (< diff_h3 0.05)) (setq do_break T)))
              ((= opt "Y") (if (or (< diff_v1 0.05) (< diff_v2 0.05)) (setq do_break T)))
            )

            (if do_break
              (progn
                (setq pList nil)
                (if (= objType "LINE") (setq pList (list startPt endPt))) 
                
                ;; 다른 모든 객체와의 교차점 수집 (원본 기준)
                (setq j 0)
                (while (< j (sslength ss))
                  (if (/= i j)
                    (progn
                      (setq ent2 (ssname ss j) obj2 (vlax-ename->vla-object ent2))
                      (setq pts (vl-catch-all-apply 'vlax-invoke (list obj1 'IntersectWith obj2 0)))
                      (if (and pts (not (vl-catch-all-error-p pts)))
                        (while (>= (length pts) 3) 
                          (setq pList (cons (list (car pts) (cadr pts) (caddr pts)) pList)) 
                          (setq pts (cdddr pts))))
                    )
                  )
                  (setq j (1+ j))
                )
                
                (if (= objType "LINE")
                  (progn
                    ;; 직선 교차 분할 로직 (교차점이 1개라도 있을 때만 재작성하여 속도 최적화)
                    (if (> (length pList) 2)
                      (progn
                        (setq dList nil)
                        (foreach pt pList (setq dList (cons (cons (distance startPt pt) pt) dList)))
                        (setq dList (vl-sort dList '(lambda (a b) (< (car a) (car b)))))
                        
                        (setq curPt (cdr (nth 0 dList)))
                        (foreach item (cdr dList)
                          (setq nextPt (cdr item))
                          (if (> (distance curPt nextPt) 1e-4)
                            (progn 
                              (setq lay (assoc 8 (entget ent1)) col (assoc 62 (entget ent1)))
                              (setq new_ent_data (list '(0 . "LINE") (cons 10 curPt) (cons 11 nextPt) lay))
                              (if col (setq new_ent_data (append new_ent_data (list col))))
                              (if (not (entmakex new_ent_data))
                                  (entmakex (list '(0 . "LINE") (cons 10 curPt) (cons 11 nextPt) '(8 . "0"))))
                              (setq curPt nextPt)
                            )
                          )
                        )
                        (ssadd ent1 ents_to_delete)
                        (setq count (1+ count))
                      )
                    )
                  )
                  (progn
                    ;; 곡선 (ARC, CIRCLE, SPLINE, ELLIPSE) 처리 로직
                    (if (= mode "2")
                      (progn
                        ;; [모드 2] 스케치업 맞춤 다각형화 및 교차
                        (setq len (vl-catch-all-apply 'vlax-curve-getDistAtParam (list obj1 (vlax-curve-getEndParam obj1))))
                        (if (not (vl-catch-all-error-p len))
                          (progn
                            ;; 지름·길이에 따라 선분 개수 계산
                            (cond
                              ((or (= objType "CIRCLE") (= objType "ARC"))
                                (setq rad (cdr (assoc 40 (entget ent1))))
                                (if (not rad) (setq rad 100.0))
                                (setq segN (fix (max 24 (min 144 (* 2.0 (sqrt rad))))))
                                (if (= objType "ARC")
                                  (progn
                                    (setq arcAng (- (cdr (assoc 51 (entget ent1))) (cdr (assoc 50 (entget ent1)))))
                                    (if (< arcAng 0) (setq arcAng (+ arcAng (* 2.0 pi))))
                                    (setq segN (max 6 (fix (* segN (/ arcAng (* 2.0 pi))))))
                                  )
                                )
                              )
                              (t
                                (setq segN (fix (max 12 (min 144 (* 1.5 (sqrt len))))))
                              )
                            )
                            
                            (setq step (/ len (float segN)) idx 0 distList nil)
                            (while (<= idx segN)
                              (if (= idx segN)
                                (setq distList (cons len distList))
                                (setq distList (cons (* idx step) distList))
                              )
                              (setq idx (1+ idx))
                            )

                            ;; 다른 객체와의 '교차점' 거리를 세그먼트 꼭짓점 리스트에 강제 편입 (면 뚫림 방지)
                            (if pList
                              (foreach pt pList
                                (setq ptOnCurve (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list obj1 pt)))
                                (if (not (vl-catch-all-error-p ptOnCurve))
                                  (progn
                                    (setq d (vl-catch-all-apply 'vlax-curve-getDistAtPoint (list obj1 ptOnCurve)))
                                    (if (and d (not (vl-catch-all-error-p d)))
                                      (setq distList (cons d distList))
                                    )
                                  )
                                )
                              )
                            )

                            ;; 거리순 정렬 및 중복 제거
                            (setq distList (vl-sort distList '<))
                            (setq cleanDistList nil)
                            (foreach d distList
                              (if (not cleanDistList)
                                (setq cleanDistList (list d))
                                (if (> (- d (car cleanDistList)) 1e-4)
                                  (setq cleanDistList (cons d cleanDistList))
                                )
                              )
                            )
                            (setq cleanDistList (reverse cleanDistList))

                            (setq lay (assoc 8 (entget ent1)) col (assoc 62 (entget ent1)))
                            
                            (setq d0 (nth 0 cleanDistList))
                            (if (<= d0 1e-6)
                              (setq pt1 startPt)
                              (progn
                                (setq pt1 (vl-catch-all-apply 'vlax-curve-getPointAtDist (list obj1 d0)))
                                (if (vl-catch-all-error-p pt1) (setq pt1 startPt))
                              )
                            )
                            
                            ;; 스케치업용 다각형 선분(LINE) 생성
                            (setq idx 1)
                            (while (< idx (length cleanDistList))
                              (setq d (nth idx cleanDistList))
                              (if (>= d (- len 1e-6))
                                (setq pt2 endPt)
                                (progn
                                  (setq pt2 (vl-catch-all-apply 'vlax-curve-getPointAtDist (list obj1 d)))
                                  (if (vl-catch-all-error-p pt2) (setq pt2 endPt))
                                )
                              )
                              
                              (if (> (distance pt1 pt2) 1e-4)
                                (progn
                                  (setq new_ent_data (list '(0 . "LINE") (cons 10 pt1) (cons 11 pt2) lay))
                                  (if col (setq new_ent_data (append new_ent_data (list col))))
                                  (if (not (entmakex new_ent_data))
                                      (entmakex (list '(0 . "LINE") (cons 10 pt1) (cons 11 pt2) '(8 . "0"))))
                                  (setq pt1 pt2)
                                )
                              )
                              (setq idx (1+ idx))
                            )
                            (ssadd ent1 ents_to_delete)
                            (setq count (1+ count))
                          )
                        )
                      )
                      (progn
                        ;; [모드 1] 기존 캐드용 (원형 유지, 교차점만 BREAK 처리)
                        (if pList
                          (progn
                            (setq paramList nil)
                            (foreach pt pList
                              (setq ptOnCurve (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list obj1 pt)))
                              (if (not (vl-catch-all-error-p ptOnCurve))
                                (progn
                                  (setq param (vlax-curve-getParamAtPoint obj1 ptOnCurve))
                                  (if (and param (> param 1e-4) (< param (- (vlax-curve-getEndParam obj1) 1e-4)))
                                    (setq paramList (cons (cons param ptOnCurve) paramList))
                                  )
                                )
                              )
                            )
                            
                            (if paramList
                              (progn
                                (setq paramList (vl-sort paramList '(lambda (a b) (> (car a) (car b)))))
                                (foreach item paramList
                                  (setq brkPt (cdr item))
                                  (command "_.BREAK" (list ent1 brkPt) "_F" "_non" brkPt "_non" brkPt)
                                )
                                (setq count (1+ count))
                              )
                            )
                          )
                        )
                      )
                    ) ; end Mode 1 / Mode 2
                  )
                ) ; end LINE vs CURVE
              )
            ) ; end do_break
          )
        )
        (setq i (1+ i))
      )
      
      ;; 분할한 원본 객체 일괄 삭제
      (setq k 0)
      (while (< k (sslength ents_to_delete))
        (vl-catch-all-apply 'entdel (list (ssname ents_to_delete k)))
        (setq k (1+ k))
      )

      ;; 마무리 및 스냅 복구
      (setvar "OSMODE" old_osmode)
      (vla-EndUndoMark doc)
      (setq undo_started nil)
      (setq *error* old_err)
      
      (if (= mode "1")
        (princ (strcat "\n\n[완료] 일반 모드: " (itoa count) "개 객체를 분할했습니다."))
        (princ (strcat "\n\n[완료] 스케치업 모드: " (itoa count) "개 객체를 선분으로 바꾸고 분할했습니다."))
      )
    )
    (princ "\n선택된 객체가 없습니다.")
  )
  (princ)
)