;;; ==============================================================================
;;;  V2 · SOFF · SON — 스케치업과 함께 쓸 때 캐드 평면 화면 지키기
;;;
;;;  V2   = 2D 평면으로: UCS World · 위에서 보기 (지금 보던 자리·크기 그대로) + 스냅은 바닥에만 (OSNAPZ 1 · ELEVATION 0)
;;;  SOFF = Shift+휠 3D 궤도 잠그기 (3DORBIT 명령을 잠시 없앰 — 캐드를 다시 켜면 풀림)
;;;  SON  = 궤도 잠금 풀기 + OSNAPZ 0 (3D 작업용)
;;; ==============================================================================

(defun v2:err (msg)
  (if v2_sv (setvar "CMDECHO" v2_sv))
  (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
    (princ (strcat "\n[오류] " msg)))
  (princ))

;; UCS World + 위에서 보기, 보던 자리·크기 유지
(defun v2:plan-world ( / ctr size)
  (setq ctr (trans (getvar "VIEWCTR") 1 0) size (getvar "VIEWSIZE"))
  (command "_.UCS" "_World")
  (command "_.PLAN" "_World")
  (command "_.ZOOM" "_C" "_non" ctr size))

(defun c:V2 ( / *error* v2_sv)
  (setq *error* v2:err v2_sv (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (v2:plan-world)
  (setvar "OSNAPZ" 1)
  (setvar "ELEVATION" 0.0)
  (setvar "CMDECHO" v2_sv)
  (princ "\n[완료] 2D 평면(UCS World · 위에서 보기)으로 돌렸습니다. 보던 자리 그대로, 스냅은 바닥(Z 0)에만 (OSNAPZ 1 · ELEVATION 0).")
  (princ))

(defun c:SOFF ( / *error* v2_sv)
  (setq *error* v2:err v2_sv (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (command "_.UNDEFINE" "3DORBITTRANSPARENT")
  (command "_.UNDEFINE" "3DORBIT")
  (setvar "CMDECHO" v2_sv)
  (princ "\n[완료] Shift+휠 3D 궤도를 잠갔습니다 (캐드를 다시 켜면 풀림 · 풀기: SON).")
  (princ))

(defun c:SON ( / *error* v2_sv)
  (setq *error* v2:err v2_sv (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (command "_.REDEFINE" "3DORBITTRANSPARENT")
  (command "_.REDEFINE" "3DORBIT")
  (setvar "OSNAPZ" 0)
  (setvar "CMDECHO" v2_sv)
  (princ "\n[완료] Shift+휠 3D 궤도를 풀고 Z 스냅을 되돌렸습니다 (OSNAPZ 0).")
  (princ))

(princ)
