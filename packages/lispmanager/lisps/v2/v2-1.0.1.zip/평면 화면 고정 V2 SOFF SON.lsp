;;; =======================================================
;;; 스케치업과 함께 쓸 때 캐드 평면 화면 고정·복구
;;; =======================================================

;;; 1. 2D 평면(World Top) 복구 및 Z축 스냅 무시
(defun c:V2 ()
  (setvar "CMDECHO" 0)
  (command "_.UCS" "_World")    ; UCS를 WCS로 되돌림
  (command "_.PLAN" "_World")   ; WCS 기준 절대 평면(Top) 뷰로 화면 이동
  (setvar "OSNAPZ" 1)           ; 객체 스냅 시 3D 높이(Z값)를 무시하고 바닥(Z=0)에만 찍히도록 강제
  (setvar "CMDECHO" 1)
  (princ "\n[완료] 2D 평면(WCS 위에서 보기)으로 되돌리고 평면 스냅(OSNAPZ=1)을 켰습니다.")
  (princ)
)

;;; 2. Shift 궤도 잠금 (3D 궤도 막기)
(defun c:SOFF ()
  (setvar "CMDECHO" 0)
  (command "_.UNDEFINE" "3DORBITTRANSPARENT")
  (command "_.UNDEFINE" "3DORBIT")
  (setvar "CMDECHO" 1)
  (princ "\n[완료] Shift+휠 3D 궤도를 잠갔습니다.")
  (princ)
)

;;; 3. Shift 궤도 잠금 해제 (3D 궤도·스냅 복구 — 3D 작업용)
(defun c:SON ()
  (setvar "CMDECHO" 0)
  (command "_.REDEFINE" "3DORBITTRANSPARENT")
  (command "_.REDEFINE" "3DORBIT")
  (setvar "OSNAPZ" 0)           ; 3D 작업이 필요할 수 있으므로 Z축 스냅을 원래대로 복구
  (setvar "CMDECHO" 1)
  (princ "\n[완료] Shift+휠 3D 궤도와 Z축 스냅을 되돌렸습니다.")
  (princ)
)

(princ "\n[V2·SOFF·SON] 로드했습니다. (V2 평면 복구 / SOFF 궤도 잠금 / SON 잠금 해제)")
(princ)