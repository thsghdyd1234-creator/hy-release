;;; ============================================================
;;;  IDD — 문 블록 벽 삽입 + 자동 개구부 타공
;;;
;;;  동작:
;;;   1) 벽선을 클릭한다 — 선(LINE) 또는 폴리선의 곧은 구간. 빈 곳을 찍으면 다시 묻고, Enter 로 끝낸다.
;;;   2) 맞은편 벽선을 찾아 두께를 잰다 — 같은 레이어를 먼저 보고, 중심선(CENTER·1점 쇄선 등)은 뺀다.
;;;      못 찾으면 맞은편 벽선을 클릭하거나 두께를 입력한다.
;;;   3) 문을 넣고 마우스로 경첩 쪽(좌/우)과 여는 쪽(안/밖)을 고른 뒤 클릭(또는 Enter)으로 확정한다.
;;;   4) 개구부를 뚫는다 — 선으로 된 벽은 두 벽선과 그 사이의 평행한 벽선만 직접 잘라 낸다(TRIM 을 쓰지 않음).
;;;      폴리선 벽은 펜스 자르기(TRIM)로 자른다. 문틀선은 벽선 레이어, 개구부 경계는 '개구부-문' 레이어(색 6).
;;;
;;;  문 하나가 실행 취소 한 번(U)이다. 방향을 고르다 ESC 하면 그 문은 넣지 않은 것으로 되돌린다.
;;;  전제: 블록 기준점 = 개구부 모서리, +X = 문 폭 방향, +Y = 벽 안쪽. 블록은 축척 1로 넣는다.
;;; ============================================================

;; ── 보조 ─────────────────────────────────────────────────
(defun idd:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun idd:sub (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b)) (- (caddr a) (caddr b))))
(defun idd:add (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b)) (+ (caddr a) (caddr b))))
(defun idd:mul (a k) (list (* (car a) k) (* (cadr a) k) (* (caddr a) k)))
(defun idd:dir (ang) (list (cos ang) (sin ang) 0.0))
(defun idd:p3 (p) (if (caddr p) p (list (car p) (cadr p) 0.0)))

;; 두 각이 평행한지 (1도 안)
(defun idd:para-p (a b) (< (abs (sin (- a b))) 0.0175))

;; 도면층이 없으면 만든다 (지금 도면층은 그대로)
(defun idd:mklayer (name color)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 color) '(6 . "Continuous")))))

(defun idd:locked-p (lay / r)
  (setq r (tblsearch "LAYER" lay))
  (and r (= 4 (logand 4 (cdr (assoc 70 r))))))

;; 객체의 실제 선종류 (ByLayer 면 도면층의 선종류)
(defun idd:ltype (ed / lt)
  (setq lt (cdr (assoc 6 ed)))
  (if (or (null lt) (= (strcase lt) "BYLAYER"))
    (setq lt (cdr (assoc 6 (tblsearch "LAYER" (cdr (assoc 8 ed)))))))
  (if lt lt "Continuous"))

;; 벽선으로 볼 수 있는지 — 중심선·그리드·개구부 레이어는 아님. 벽선 레이어이거나 실선이면 벽선.
(defun idd:wall-like-p (ed wall_lay / lay lt)
  (setq lay (strcase (cdr (assoc 8 ed)))
        lt (strcase (idd:ltype ed)))
  (cond
    ((wcmatch lt "*CENTER*,*DASHDOT*,*PHANTOM*,*CEN*,*ACAD_ISO04*,*ACAD_ISO10*") nil)
    ((wcmatch lay "*CEN*,*중심*,*C`.L*,*GRID*,*그리드*,개구부*") nil)
    ((= lay (strcase wall_lay)) T)
    ((wcmatch lt "CONTINUOUS,BYBLOCK") T)))

;; 곧은 구간 목록 ((p1 p2) …) — 선은 하나, 폴리선은 볼록도 0 인 구간들
(defun idd:segs (ent / ed typ obj n i out)
  (setq ed (entget ent) typ (cdr (assoc 0 ed)))
  (cond
    ((= typ "LINE") (list (list (idd:p3 (cdr (assoc 10 ed))) (idd:p3 (cdr (assoc 11 ed))))))
    ((= typ "LWPOLYLINE")
     (setq obj (vlax-ename->vla-object ent)
           n (fix (+ 0.5 (vlax-curve-getEndParam obj)))
           i 0)
     (while (< i n)
       (if (equal (vla-getbulge obj i) 0.0 1e-9)
         (setq out (cons (list (vlax-curve-getPointAtParam obj i) (vlax-curve-getPointAtParam obj (1+ i))) out)))
       (setq i (1+ i)))
     (reverse out))))

;; 클릭점에 가장 가까운 곧은 구간 (p1 p2), 없으면 nil
(defun idd:seg-at (ent pt / best bd d)
  (foreach s (idd:segs ent)
    (setq d (distance pt (idd:foot pt s nil)))
    (if (or (null bd) (< d bd)) (setq bd d best s)))
  best)

;; 점 pt 에서 구간 s=(p1 p2) 로 내린 수선의 발. ext=T 면 무한 직선 위, 아니면 구간 안으로 자름.
(defun idd:foot (pt s ext / p1 p2 v L2 k)
  (setq p1 (car s) p2 (cadr s) v (idd:sub p2 p1) L2 (idd:dot v v))
  (if (< L2 1e-12)
    p1
    (progn
      (setq k (/ (idd:dot (idd:sub pt p1) v) L2))
      (if (not ext) (setq k (max 0.0 (min 1.0 k))))
      (idd:add p1 (idd:mul v k)))))

;; 점이 구간 안쪽(양 끝 사이)에 수선을 내리는지
(defun idd:over-p (pt s / v k)
  (setq v (idd:sub (cadr s) (car s)))
  (if (< (idd:dot v v) 1e-12)
    nil
    (progn
      (setq k (/ (idd:dot (idd:sub pt (car s)) v) (idd:dot v v)))
      (and (> k -1e-6) (< k (+ 1.0 1e-6))))))

(defun idd:same-seg-p (a b)
  (or (and (equal (car a) (car b) 1e-6) (equal (cadr a) (cadr b) 1e-6))
      (and (equal (car a) (cadr b) 1e-6) (equal (cadr a) (car b) 1e-6))))

;; UCS 좌표로 만든 걸침 창 (WCS 점 p 둘레 r)
(defun idd:ss-around (p r flt / u)
  (setq u (trans p 0 1))
  (ssget "_C" (list (- (car u) r) (- (cadr u) r)) (list (+ (car u) r) (+ (cadr u) r)) flt))

(defun idd:ss-list (ss / i out)
  (setq i 0)
  (if ss (while (< i (sslength ss)) (setq out (cons (ssname ss i) out) i (1+ i))))
  (reverse out))

;; 선(LINE) 조각: 원래 방향(s→e)을 지키며 t 구간 [a, b] (t = lo 에서 u 방향 거리)
(defun idd:piece (s e t0 t1 a b / pa pb)
  (setq pa (idd:add s (idd:mul (idd:sub e s) (/ (- a t0) (- t1 t0))))
        pb (idd:add s (idd:mul (idd:sub e s) (/ (- b t0) (- t1 t0)))))
  (if (<= t0 t1) (list pa pb) (list pb pa)))

(defun idd:set-ends (ed pq)
  (subst (cons 10 (car pq)) (assoc 10 ed) (subst (cons 11 (cadr pq)) (assoc 11 ed) ed)))

;; 선 하나에서 개구부 구간 [0, dw] 를 잘라 낸다. 고쳤으면 T.
(defun idd:cut-line (ent lo u dw / ed s e t0 t1 tmin tmax k1 k2 ed2)
  (setq ed (entget ent)
        s (idd:p3 (cdr (assoc 10 ed))) e (idd:p3 (cdr (assoc 11 ed)))
        t0 (idd:dot (idd:sub s lo) u) t1 (idd:dot (idd:sub e lo) u)
        tmin (min t0 t1) tmax (max t0 t1))
  (if (and (< tmin (- dw 0.01)) (> tmax 0.01) (> (abs (- t1 t0)) 1e-6))
    (progn
      (setq k1 (if (< tmin -0.01) (list tmin 0.0))
            k2 (if (> tmax (+ dw 0.01)) (list dw tmax)))
      (cond
        ((and k1 k2)
         (setq ed2 (vl-remove-if '(lambda (g) (member (car g) '(-1 5 102 330 360))) ed))
         (entmod (idd:set-ends ed (idd:piece s e t0 t1 (car k1) (cadr k1))))
         (entmake (idd:set-ends ed2 (idd:piece s e t0 t1 (car k2) (cadr k2)))))
        (k1 (entmod (idd:set-ends ed (idd:piece s e t0 t1 (car k1) (cadr k1)))))
        (k2 (entmod (idd:set-ends ed (idd:piece s e t0 t1 (car k2) (cadr k2)))))
        (T (entdel ent)))
      T)))

;; ── 개구부 뚫기 ──────────────────────────────────────────
;;   lo   : 클릭한 벽면 위 개구부 시작점 (WCS), u = 벽 방향(lo → 끝), n = 벽 안쪽, thk = 두께
;;   faces: 두 벽면 객체 (선 · 폴리선), wall_lay: 문틀선 레이어
;;   돌려줌: 자른 벽선 수
(defun idd:cut-opening (lo u n dw thk faces wall_lay / hi c3 c4 cnt poly_faces ed s e a b box ss pol mid
                        f_top f_bot vctr)
  (setq hi (idd:add lo (idd:mul u dw))
        c3 (idd:add hi (idd:mul n thk))
        c4 (idd:add lo (idd:mul n thk))
        cnt 0)
  ;; 개구부 둘레의 선 (화면이 아니라 둘레 창으로 모음)
  (setq box (idd:ss-around (idd:mul (idd:add lo c3) 0.5) (+ (/ (max dw thk) 2.0) 60.0) '((0 . "LINE,LWPOLYLINE"))))
  (foreach ent (idd:ss-list box)
    (setq ed (entget ent))
    (cond
      ((idd:locked-p (cdr (assoc 8 ed))) nil)
      ((= (cdr (assoc 0 ed)) "LINE")
       (setq s (idd:p3 (cdr (assoc 10 ed))) e (idd:p3 (cdr (assoc 11 ed)))
             a (idd:dot (idd:sub s lo) n) b (idd:dot (idd:sub e lo) n))
       ;; 벽 띠 안(두 벽면 포함)의 평행한 벽선만
       (if (and (> (distance s e) 1e-6)
                (idd:para-p (angle s e) (angle '(0 0 0) u))
                (> (min a b) -1.0) (< (max a b) (+ thk 1.0))
                (or (member ent faces) (idd:wall-like-p ed wall_lay)))
         (if (idd:cut-line ent lo u dw) (setq cnt (1+ cnt)))))
      ((member ent faces) (setq poly_faces (cons ent poly_faces)))))
  ;; 폴리선 벽면: 임시 사각형을 칼선으로 펜스 자르기
  (if poly_faces
    (progn
      (setq pol (entmakex (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 wall_lay) '(100 . "AcDbPolyline")
                                '(90 . 4) '(70 . 1) (cons 38 (caddr lo))
                                (cons 10 (idd:add lo (idd:mul n -50.0))) (cons 10 (idd:add hi (idd:mul n -50.0)))
                                (cons 10 (idd:add hi (idd:mul n (+ thk 50.0)))) (cons 10 (idd:add lo (idd:mul n (+ thk 50.0)))))))
      (setq mid (idd:add lo (idd:mul u (/ dw 2.0)))
            f_top (idd:add mid (idd:mul n (+ thk 10.0)))
            f_bot (idd:add mid (idd:mul n -10.0)))
      (command "_.-view" "_s" "IDD_TMP")
      (setq *idd:view* T)
      (command "_.zoom" "_c" "_non" (trans mid 0 1) (* (max dw thk) 3.0))
      (vl-catch-all-apply
        '(lambda () (command "_.trim" pol "" "_f" "_non" (trans f_top 0 1) "_non" (trans f_bot 0 1) "" "")))
      (if (entget pol) (entdel pol))
      (command "_.-view" "_r" "IDD_TMP")
      (command "_.-view" "_d" "IDD_TMP")
      (setq *idd:view* nil)
      (setq cnt (+ cnt (length poly_faces)))))
  (if (> cnt 0)
    (progn
      (entmake (list '(0 . "LINE") (cons 8 wall_lay) (cons 10 lo) (cons 11 c4)))
      (entmake (list '(0 . "LINE") (cons 8 wall_lay) (cons 10 hi) (cons 11 c3)))
      (entmake (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(8 . "개구부-문") '(100 . "AcDbPolyline")
                     '(90 . 4) '(70 . 1) (cons 38 (caddr lo))
                     (cons 10 lo) (cons 10 hi) (cons 10 c3) (cons 10 c4)))))
  cnt)

;; 문 블록의 X 방향 폭 (축척 1, 회전 0 기준)
(defun idd:block-width (obj / mn mx r)
  (setq r (vla-get-Rotation obj))
  (vla-put-Rotation obj 0.0)
  (vla-GetBoundingBox obj 'mn 'mx)
  (vla-put-Rotation obj r)
  (- (car (vlax-safearray->list mx)) (car (vlax-safearray->list mn))))

;; ============================================================
;; 메인 명령
;; ============================================================
(defun c:IDD ( / *error* doc space sv undo_open door_pending input_blk blk_name dw cut_opt mode_input off_in
                 sel ent pt seg p1 p2 ang1 u1 proj wall_lay ss cands best d foot e2 s2 thk pt_inner sel2 seg2
                 ang_wall uw nw corner_pt cbest cd q int offset_dir pA pB lo hi mid obj width warned
                 curX curY loop loop2 gr code pm lx ly nx ny ins cnt n_done)

  (defun *error* (msg)
    (if undo_open
      (progn
        (vla-EndUndoMark doc)
        (setq undo_open nil)
        (if door_pending (command-s "_.U"))))
    (if *idd:view*
      (progn (command-s "_.-view" "_r" "IDD_TMP") (command-s "_.-view" "_d" "IDD_TMP") (setq *idd:view* nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        space (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("OSMODE" "CMDECHO" "TRIMEXTENDMODE" "EDGEMODE")))

  ;; ---- 입력: 블록 이름 ----
  (if (null *last_door_blk*) (setq *last_door_blk* ""))
  (setq input_blk (getstring T (if (= *last_door_blk* "")
                                  "\n삽입할 문 블록 이름: "
                                  (strcat "\n삽입할 문 블록 이름 <" *last_door_blk* ">: "))))
  (if (/= input_blk "") (setq *last_door_blk* input_blk))
  (setq blk_name *last_door_blk*)
  (cond
    ((= blk_name "") (princ "\n명령을 취소했습니다."))
    ((not (tblsearch "BLOCK" blk_name))
     (alert (strcat "'" blk_name "' 블록이 이 도면에 없습니다.\n블록을 먼저 넣거나 이름을 확인하세요."))
     (setq *last_door_blk* ""))
    (T
     ;; ---- 입력: 문 폭 · 타공 · 위치 모드 ----
     (if (null *last_dw*) (setq *last_dw* 900.0))
     (initget 6)
     (setq dw (getdist (strcat "\n문 폭(개구부 크기) <" (rtos *last_dw* 2 0) ">: ")))
     (if dw (setq *last_dw* dw) (setq dw *last_dw*))

     (if (null *idd_cut_opt*) (setq *idd_cut_opt* "1"))
     (initget "1 2")
     (setq cut_opt (getkword (strcat "\n타공 여부 [1: 타공 함 / 2: 삽입만] <" *idd_cut_opt* ">: ")))
     (if cut_opt (setq *idd_cut_opt* cut_opt))
     (setq cut_opt *idd_cut_opt*)

     (if (null *idd_mode*) (setq *idd_mode* "1"))
     (initget "1 2")
     (setq mode_input (getkword (strcat "\n위치 모드 [1: 자유 / 2: 코너 오프셋] <" *idd_mode* ">: ")))
     (if mode_input (setq *idd_mode* mode_input))
     (if (= *idd_mode* "2")
       (progn
         (if (null *idd_offset*) (setq *idd_offset* 100.0))
         (initget 4)
         (setq off_in (getdist (strcat "\n코너에서 띄울 거리 <" (rtos *idd_offset* 2 0) ">: ")))
         (if off_in (setq *idd_offset* off_in))))
     (if (null *last_tw*) (setq *last_tw* 200.0))

     ;; ---- 준비 ----
     (setvar "CMDECHO" 0)
     (setvar "OSMODE" 0)
     (setvar "TRIMEXTENDMODE" 0)
     (setvar "EDGEMODE" 0)
     (idd:mklayer "개구부-문" 6)
     (setq n_done 0)

     ;; ---- 벽선 클릭 루프 (연속 삽입) ----
     (setq loop T)
     (while loop
       (setvar "ERRNO" 0)
       (setq sel (entsel "\n문을 달 벽선을 클릭하세요 (끝내기: Enter): "))
       (cond
         ((and (null sel) (= (getvar "ERRNO") 7)) (princ "\n선택된 객체가 없습니다. 벽선을 다시 클릭하세요."))
         ((null sel) (setq loop nil))
         ((null (setq ent (car sel) pt (trans (cadr sel) 1 0) seg (idd:seg-at ent pt)))
          (princ "\n[주의] 선(LINE)이나 폴리선의 곧은 구간을 클릭하세요."))
         (T
          (setq p1 (car seg) p2 (cadr seg)
                ang1 (angle p1 p2)
                u1 (idd:dir ang1)
                proj (idd:foot pt seg T)
                wall_lay (cdr (assoc 8 (entget ent))))

          ;; [1] 맞은편 벽선 → 두께 (같은 레이어 먼저, 중심선 빼고, 수선의 발이 그 선 위에 있어야 함)
          (setq ss (idd:ss-around proj 1100.0 '((0 . "LINE,LWPOLYLINE"))) cands nil)
          (foreach e2 (idd:ss-list ss)
            (foreach s2 (idd:segs e2)
              (if (and (not (and (eq e2 ent) (idd:same-seg-p s2 seg)))
                       (> (distance (car s2) (cadr s2)) 1e-6)
                       (idd:para-p (angle (car s2) (cadr s2)) ang1)
                       (idd:over-p proj s2))
                (progn
                  (setq foot (idd:foot proj s2 T) d (distance proj foot))
                  (if (and (>= d 30.0) (<= d 1000.0) (idd:wall-like-p (entget e2) wall_lay))
                    (setq cands (cons (list (if (= (strcase (cdr (assoc 8 (entget e2)))) (strcase wall_lay)) 0 1)
                                            d e2 foot) cands)))))))
          (setq best nil)
          (foreach c cands
            (if (or (null best) (< (car c) (car best)) (and (= (car c) (car best)) (< (cadr c) (cadr best))))
              (setq best c)))
          (setq thk nil pt_inner nil e2 nil)
          (if best
            (setq thk (cadr best) e2 (caddr best) pt_inner (cadddr best))
            (progn
              ;; 못 찾으면 직접
              (setq sel2 (entsel "\n맞은편 벽선을 클릭하세요 (두께를 입력하려면 Enter): "))
              (if (and sel2 (setq seg2 (idd:seg-at (car sel2) (trans (cadr sel2) 1 0)))
                       (idd:para-p (angle (car seg2) (cadr seg2)) ang1))
                (setq e2 (car sel2) pt_inner (idd:foot proj seg2 T) thk (distance proj pt_inner))
                (progn
                  (if sel2 (princ "\n[주의] 평행한 벽선이 아닙니다."))
                  (initget 6)
                  (setq thk (getdist (strcat "\n벽 두께 <" (rtos *last_tw* 2 0) ">: ")))
                  (if (not thk) (setq thk *last_tw*))
                  (setq *last_tw* thk
                        pt_inner (polar proj (+ ang1 (/ pi 2.0)) thk))
                  (princ "\n[주의] 두께를 직접 정했습니다 — 벽 안쪽이 반대면 문을 확정한 뒤 확인하세요.")))))

          (if (< thk 1.0)
            (princ "\n두께를 정하지 못해 이 벽은 건너뜁니다.")
            (progn
              (princ (strcat "\n벽 두께 " (rtos thk 2 1)))
              ;; [2] 벽 방향: +Y(= ang_wall + 90)가 벽 안쪽을 향하게
              (setq ang_wall (if (> (- (* (car u1) (cadr (idd:sub pt_inner proj))) (* (cadr u1) (car (idd:sub pt_inner proj)))) 0.0)
                               ang1 (+ ang1 pi))
                    uw (idd:dir ang_wall)
                    nw (idd:dir (+ ang_wall (/ pi 2.0))))

              ;; [3] 위치: 자유 = 클릭점에서 벽 방향으로 / 코너 = 직교 벽선과 만나는 점에서 띄움
              (setq offset_dir ang_wall pA proj)
              (if (= *idd_mode* "2")
                (progn
                  (setq corner_pt nil cbest nil)
                  (foreach e3 (idd:ss-list ss)
                    (if (not (or (eq e3 ent) (eq e3 e2)))
                      (foreach q (idd:segs e3)
                        (if (and (> (abs (sin (- ang1 (angle (car q) (cadr q))))) 0.707)
                                 (idd:wall-like-p (entget e3) wall_lay)
                                 (setq int (inters p1 p2 (car q) (cadr q) nil))
                                 (< (distance (idd:p3 int) (idd:foot (idd:p3 int) q nil)) 150.0)
                                 (< (distance (idd:p3 int) (idd:foot (idd:p3 int) seg nil)) 150.0))
                          (progn
                            (setq int (idd:p3 int) cd (distance proj int))
                            (if (or (null cbest) (< cd cbest)) (setq cbest cd corner_pt int)))))))
                  (if corner_pt
                    (setq offset_dir (if (> (idd:dot (idd:sub proj corner_pt) u1) 0.0) ang1 (+ ang1 pi))
                          pA (polar corner_pt offset_dir *idd_offset*))
                    (princ "\n[주의] 코너를 찾지 못해 클릭한 곳에서 넣습니다."))))
              (setq pB (polar pA offset_dir dw)
                    mid (polar pA offset_dir (/ dw 2.0)))
              ;; 개구부 양 끝: lo = 벽 방향(uw)으로 앞쪽 끝
              (if (<= (idd:dot (idd:sub pA pB) uw) 0.0) (setq lo pA hi pB) (setq lo pB hi pA))

              ;; ---- 넣기 (문 하나 = 실행 취소 한 번) ----
              (vla-StartUndoMark doc)
              (setq undo_open T door_pending T)
              (setq obj (vla-InsertBlock space (vlax-3d-point lo) blk_name 1.0 1.0 1.0 0.0))
              (if (not (member blk_name warned))
                (progn
                  (setq width (idd:block-width obj) warned (cons blk_name warned))
                  (if (> (abs (- width dw)) (max 20.0 (* 0.1 dw)))
                    (princ (strcat "\n[주의] 블록 '" blk_name "' 의 폭이 약 " (rtos width 2 0)
                                   " 입니다 (문 폭 " (rtos dw 2 0) " 과 다름 — 블록은 축척 1로 넣습니다).")))))
              (vla-put-Rotation obj ang_wall)

              ;; ---- 방향 고르기: 마우스가 있는 쪽 = 문 끝(+X) · 여는 쪽 ----
              (prompt "\n마우스로 경첩 쪽(좌/우)과 여는 쪽(안/밖)을 고르고 클릭하세요 (Enter = 지금 모양).")
              (setq curX 1 curY 1 loop2 T)
              (while loop2
                (setq gr (grread T 15 0) code (car gr))
                (cond
                  ((and (member code '(3 5)) (listp (cadr gr)))
                   (setq pm (trans (cadr gr) 1 0)
                         lx (idd:dot (idd:sub pm mid) uw)
                         ly (idd:dot (idd:sub pm mid) nw)
                         nx (if (>= lx 0.0) 1 -1)
                         ny (if (>= ly 0.0) 1 -1))
                   (if (or (/= nx curX) (/= ny curY))
                     (progn
                       (setq curX nx curY ny
                             ins (if (= curX 1) lo hi))
                       ;; 여는 쪽을 뒤집으면(Y -1) 기준점을 맞은편 벽면으로 — 문틀은 벽 안에 그대로
                       (if (< curY 0) (setq ins (idd:add ins (idd:mul nw thk))))
                       (if (vl-catch-all-error-p
                             (vl-catch-all-apply
                               '(lambda ()
                                  (vla-put-InsertionPoint obj (vlax-3d-point ins))
                                  (vla-put-XScaleFactor obj (float curX))
                                  (vla-put-YScaleFactor obj (float curY)))))
                         (princ "\n[주의] 이 블록은 뒤집을 수 없습니다 (축척 고정 블록)."))
                       (vla-Update obj)))
                   (if (= code 3) (setq loop2 nil)))
                  ((and (= code 2) (member (cadr gr) '(13 32))) (setq loop2 nil))
                  ((member code '(11 25)) (setq loop2 nil))))

              ;; ---- 타공 ----
              (if (= cut_opt "1")
                (progn
                  (setq cnt (idd:cut-opening lo uw nw dw thk (vl-remove nil (list ent e2)) wall_lay))
                  (if (= cnt 0) (princ "\n[주의] 자를 벽선이 없습니다 (잠긴 레이어인지 확인하세요)."))))
              (setq door_pending nil)
              (vla-EndUndoMark doc)
              (setq undo_open nil n_done (1+ n_done))
              (princ (if (= cut_opt "1") "\n문을 넣고 개구부를 뚫었습니다." "\n문을 넣었습니다.")))))))

     (foreach v sv (setvar (car v) (cdr v)))
     (princ (strcat "\n문 " (itoa n_done) "개를 넣었습니다."))))
  (princ))

(princ)
