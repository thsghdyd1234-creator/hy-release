;;; ============================================================
;;;  IDD — 문 블록 벽 삽입 + 자동 개구부 타공
;;;
;;;  동작 요약:
;;;   1) 벽선을 직접 선택(entsel) — 빈 곳 클릭, L·T자 오작동 없음
;;;   2) 반대편 평행선을 찾아 벽 두께를 잼 — 직접 입력 불필요
;;;   3) 삽입하면서 잰 두께로 개구부 타공
;;;      · 타공은 SDC의 사각형 + 펜스 트림 방식을 그대로 씀
;;;   4) 반대편 벽선을 못 찾으면 직접 선택하거나 두께를 입력
;;;
;;;  전제: 벽은 개별 LINE, 블록 기준점은 개구부 모서리
;;;  주의: 사본에서 먼저 시험하세요.
;;; ============================================================

;; ------------------------------------------------------------
;; 타공 보조 함수: 배치된 블록 하나의 개구부를 뚫는다 (SDC 방식)
;;   ent    : 배치 완료된 문 블록(INSERT)
;;   dw     : 문 폭
;;   thk    : 벽 두께(양수, ang_Y=rot+90 이 이미 벽 안쪽을 향함)
;;   base_lay: 벽선이 있는 레이어(잘라낸 뒤 되돌릴 현재 레이어)
;; ------------------------------------------------------------
(defun idd:cut-opening (ent dw thk base_lay / entData insPt rot xs ang_X ang_Y
                        dist_Y1 dist_Y2 f_dist1 f_dist2 base_X p1 p2 p3 p4
                        cap1_s cap1_e cap2_s cap2_e mid_X pol f_top f_bot)
  (setq entData (entget ent)
        insPt (cdr (assoc 10 entData))
        rot   (cdr (assoc 50 entData))
        xs    (cond ((cdr (assoc 41 entData))) (1.0)))
  ;; 문 폭 방향은 경첩(X 축척)에 따라 뒤집힘
  (setq ang_X (if (< xs 0) (+ rot pi) rot))
  ;; 두께 방향은 항상 rot+90 = 측정으로 확정된 '벽 안쪽'.
  ;; 문짝 개폐(Y스케일) 반전과 무관하게 고정 → 안/밖을 바꿔도 타공은 실제 벽으로.
  (setq ang_Y (+ rot (/ pi 2.0)))
  (setq thk (abs thk))
  (setq dist_Y1 (+ thk 50.0) dist_Y2 -50.0 f_dist1 (+ thk 10.0) f_dist2 -10.0)
  (setq base_X (polar insPt ang_X dw))
  (setq p1 (polar insPt ang_Y dist_Y1)
        p2 (polar insPt ang_Y dist_Y2)
        p3 (polar base_X ang_Y dist_Y2)
        p4 (polar base_X ang_Y dist_Y1))
  (setq cap1_s insPt
        cap1_e (polar insPt ang_Y thk)
        cap2_s base_X
        cap2_e (polar base_X ang_Y thk))
  (setq mid_X (polar insPt ang_X (/ dw 2.0)))
  (command "_.zoom" "_C" mid_X (* dw 3.0))
  (setvar "clayer" base_lay)
  (command "_.pline" p1 p2 p3 p4 "_C")
  (setq pol (entlast))
  (setq f_top (polar mid_X ang_Y f_dist1)
        f_bot (polar mid_X ang_Y f_dist2))
  (vl-catch-all-apply
    (function (lambda () (command "_.trim" pol "" "_F" f_top f_bot "" ""))))
  (while (> (getvar "cmdactive") 0) (command))
  (if (entget pol) (entdel pol))
  (command "_.line" cap1_s cap1_e "")
  (command "_.line" cap2_s cap2_e "")
  (setvar "clayer" "개구부-문")
  (command "_.pline" cap1_s cap1_e cap2_e cap2_s "_C")
  (setvar "clayer" base_lay)
  (princ))

;; ------------------------------------------------------------
;; 메인 명령
;; ------------------------------------------------------------
(defun c:IDD ( / *error* old_os old_echo old_lay old_trim old_edge
                 sel host_line pt ss i ent obj proj d
                 pt1 pt2 ang1 ang2 diff min_dist2 second_line pt_inner obj2 proj_pt
                 sel2 test_pt_left test_pt_right ang_wall
                 input_blk blk_name dw mode_input off_in cut_opt
                 corner_pt min_corner_dist pt3 pt4 ang3 diff2 int_pt obj3 pt_on_line d_int
                 offset_dir pA pB mid_X dot_prod align_same test1 test2
                 base_insPt blkEnt entData curXScale curYScale newXScale newYScale
                 current_insPt local_x local_y
                 loop gr code pt_mouse ang_to_pt rel_ang base_lay pMin pMax)

  (defun *error* (msg)
    (if old_os   (setvar "OSMODE" old_os))
    (if old_echo (setvar "CMDECHO" old_echo))
    (if old_lay  (setvar "CLAYER" old_lay))
    (if old_trim (setvar "TRIMEXTENDMODE" old_trim))
    (if old_edge (setvar "EDGEMODE" old_edge))
    (if (tblsearch "VIEW" "TEMP_VIEW_IDD")
      (progn (command "_.view" "_r" "TEMP_VIEW_IDD") (command "_.view" "_d" "TEMP_VIEW_IDD")))
    (while (> (getvar "cmdactive") 0) (command))
    (if (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*"))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (vl-load-com)

  ;; ---- 상태 백업 ----
  (setq old_os   (getvar "OSMODE")
        old_echo (getvar "CMDECHO")
        old_lay  (getvar "CLAYER")
        old_trim (getvar "TRIMEXTENDMODE")
        old_edge (getvar "EDGEMODE"))
  (setq base_lay old_lay)

  ;; ---- 입력: 블록 이름 ----
  (if (null *last_door_blk*) (setq *last_door_blk* ""))
  (if (= *last_door_blk* "")
    (setq input_blk (getstring "\n삽입할 문 블록 이름 (띄어쓰기 불가): "))
    (setq input_blk (getstring (strcat "\n삽입할 문 블록 이름 <" *last_door_blk* ">: "))))
  (if (/= input_blk "") (setq *last_door_blk* input_blk))
  (setq blk_name *last_door_blk*)
  (if (= blk_name "") (progn (princ "\n명령을 취소했습니다.") (exit)))
  (if (not (tblsearch "BLOCK" blk_name))
    (progn (alert (strcat "오류: '" blk_name "' 블록을 찾을 수 없습니다.")) (setq *last_door_blk* "") (exit)))

  ;; ---- 입력: 문 폭 ----
  (if (null *last_dw*) (setq *last_dw* 900.0))
  (setq dw (getreal (strcat "\n문 폭(개구부 크기) <" (rtos *last_dw* 2 0) ">: ")))
  (if (not dw) (setq dw *last_dw*) (setq *last_dw* dw))

  ;; ---- 입력: 타공 여부 ----
  (if (null *idd_cut_opt*) (setq *idd_cut_opt* "1"))
  (initget "1 2")
  (setq cut_opt (getkword (strcat "\n타공 여부 [1: 타공 함 / 2: 삽입만] <" *idd_cut_opt* ">: ")))
  (if cut_opt (setq *idd_cut_opt* cut_opt))
  (setq cut_opt *idd_cut_opt*)

  ;; ---- 입력: 위치 모드 ----
  (if (null *idd_mode*) (setq *idd_mode* "1"))
  (initget "1 2")
  (setq mode_input (getkword (strcat "\n위치 모드 [1: 자유 / 2: 코너 오프셋] <" *idd_mode* ">: ")))
  (if mode_input (setq *idd_mode* mode_input))
  (if (= *idd_mode* "2")
    (progn
      (if (null *idd_offset*) (setq *idd_offset* 100.0))
      (setq off_in (getreal (strcat "\n코너에서 띄울 거리 <" (rtos *idd_offset* 2 0) ">: ")))
      (if off_in (setq *idd_offset* off_in))))

  (if (null *last_tw*) (setq *last_tw* 200.0))

  ;; ---- 준비 ----
  (setvar "CMDECHO" 0)
  (setvar "TRIMEXTENDMODE" 0)
  (setvar "EDGEMODE" 0)
  (if (not (tblsearch "LAYER" "개구부-문"))
    (command "_.-layer" "_m" "개구부-문" "_c" "6" "" ""))
  (setvar "OSMODE" 0)

  ;; ============================================================
  ;; 벽선 직접 선택 루프 (연속 삽입)
  ;; ============================================================
  (while (setq sel (entsel "\n문이 달릴 벽선을 선택하세요 (종료: Enter): "))
    (setq host_line (car sel) pt (cadr sel))

    (if (/= "LINE" (cdr (assoc 0 (entget host_line))))
      (princ "\n[주의] 선(LINE)으로 된 벽을 선택하세요.")
      (progn
        ;; 클릭 지점을 host_line 위로 투영
        (setq proj_pt (vlax-curve-getClosestPointTo (vlax-ename->vla-object host_line) pt T))
        (setq pt1 (cdr (assoc 10 (entget host_line)))
              pt2 (cdr (assoc 11 (entget host_line)))
              ang1 (angle pt1 pt2))

        ;; 주변 선 수집 (평행선/코너 탐색용)
        (setq pMin (list (- (car proj_pt) 1500) (- (cadr proj_pt) 1500) 0.0)
              pMax (list (+ (car proj_pt) 1500) (+ (cadr proj_pt) 1500) 0.0))
        (setq ss (ssget "_C" pMin pMax '((0 . "LINE"))))

        ;; [1] 반대편 평행선 → 두께 측정
        (setq min_dist2 999999.0 second_line nil pt_inner nil i 0)
        (if ss
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (if (not (equal ent host_line))
              (progn
                (setq ang2 (angle (cdr (assoc 10 (entget ent))) (cdr (assoc 11 (entget ent)))))
                (setq diff (rem (abs (- ang1 ang2)) pi))
                (if (or (< diff 0.1) (> diff (- pi 0.1)))
                  (progn
                    (setq obj2 (vlax-ename->vla-object ent)
                          proj (vlax-curve-getClosestPointTo obj2 proj_pt T)
                          d (distance proj_pt proj))
                    (if (and (< d min_dist2) (> d 1.0) (< d 1000.0))
                      (setq min_dist2 d second_line ent pt_inner proj))))))
            (setq i (1+ i))))

        ;; [1-대안] 평행선을 못 찾으면 직접 지정
        (if (not second_line)
          (progn
            (setq sel2 (entsel "\n반대편 벽선을 선택하세요 (두께 직접입력은 Enter): "))
            (if (and sel2 (= "LINE" (cdr (assoc 0 (entget (car sel2))))))
              (progn
                (setq obj2 (vlax-ename->vla-object (car sel2))
                      pt_inner (vlax-curve-getClosestPointTo obj2 proj_pt T)
                      min_dist2 (distance proj_pt pt_inner)
                      second_line (car sel2)))
              (progn
                (setq min_dist2 (getreal (strcat "\n벽 두께 <" (rtos *last_tw* 2 0) ">: ")))
                (if (not min_dist2) (setq min_dist2 *last_tw*))
                (setq *last_tw* min_dist2)
                (setq pt_inner (polar proj_pt (+ ang1 (/ pi 2.0)) min_dist2)
                      second_line host_line)
                (princ "\n[주의] 두께를 직접 지정했습니다 — 안쪽 방향이 반대면 문을 확정한 뒤 확인하세요.")))))

        (if (not pt_inner)
          (princ "\n두께를 결정하지 못해 이 벽은 건너뜁니다.")
          (progn
            ;; [2] 안/밖 방향으로 벽 각도(ang_wall) 고정 → rot+90 이 벽 안쪽을 향하게
            (setq test_pt_left  (polar proj_pt (+ ang1 (/ pi 2.0)) 10.0)
                  test_pt_right (polar proj_pt (- ang1 (/ pi 2.0)) 10.0))
            (if (< (distance test_pt_left pt_inner) (distance test_pt_right pt_inner))
              (setq ang_wall ang1)
              (setq ang_wall (+ ang1 pi)))

            ;; [3] 위치(pA) 결정
            (if (= *idd_mode* "2")
              (progn
                (setq min_corner_dist 999999.0 corner_pt nil i 0)
                (if ss
                  (while (< i (sslength ss))
                    (setq ent (ssname ss i))
                    (if (and (not (equal ent host_line)) (not (equal ent second_line)))
                      (progn
                        (setq pt3 (cdr (assoc 10 (entget ent)))
                              pt4 (cdr (assoc 11 (entget ent)))
                              ang3 (angle pt3 pt4)
                              diff2 (rem (abs (- ang1 ang3)) pi))
                        (if (and (> diff2 0.785) (< diff2 2.356))
                          (if (setq int_pt (inters pt1 pt2 pt3 pt4 nil))
                            (progn
                              (setq obj3 (vlax-ename->vla-object ent)
                                    pt_on_line (vlax-curve-getClosestPointTo obj3 int_pt T))
                              (if (< (distance int_pt pt_on_line) 150.0)
                                (progn
                                  (setq d_int (distance proj_pt int_pt))
                                  (if (< d_int min_corner_dist)
                                    (setq min_corner_dist d_int corner_pt int_pt)))))))))
                    (setq i (1+ i))))
                (if corner_pt
                  (progn
                    (setq test1 (polar corner_pt ang1 10.0)
                          test2 (polar corner_pt (+ ang1 pi) 10.0))
                    (if (< (distance test1 proj_pt) (distance test2 proj_pt))
                      (setq offset_dir ang1)
                      (setq offset_dir (+ ang1 pi)))
                    (setq pA (polar corner_pt offset_dir *idd_offset*)))
                  (progn
                    (princ "\n[주의] 코너를 못 찾아 자유 위치로 진행합니다.")
                    (setq offset_dir ang_wall pA proj_pt))))
              (setq offset_dir ang_wall pA proj_pt))

            ;; 개구부 범위/중심
            (setq pB (polar pA offset_dir dw)
                  mid_X (polar pA offset_dir (/ dw 2.0)))
            (setq dot_prod (cos (- ang_wall offset_dir)))
            (setq align_same (if (> dot_prod 0.0) T nil))

            ;; ---- 삽입 (undo 그룹 시작) ----
            (command "_.undo" "_begin")
            (setq curXScale 1.0 curYScale 1.0)
            (setq base_insPt (if align_same pA pB))
            (command "_.-insert" blk_name "_non" base_insPt 1 1 (* ang_wall (/ 180.0 pi)))
            (setq blkEnt (entlast))

            ;; ---- 방향 결정 (grread): 좌/우=힌지, 상/하=개폐 안·밖 ----
            (prompt "\n[좌/우: 경첩 좌우] [상/하: 여는 쪽 안·밖] [클릭: 확정]")
            (setq loop T)
            (while loop
              (setq gr (grread T 15 0) code (car gr) pt_mouse (cadr gr))
              (if (and (or (= code 5) (= code 3)) (listp pt_mouse) (not (equal mid_X pt_mouse 1e-4)))
                (progn
                  (setq ang_to_pt (angle mid_X pt_mouse)
                        rel_ang (- ang_to_pt offset_dir)
                        local_x (* (distance mid_X pt_mouse) (cos rel_ang))
                        local_y (* (distance mid_X pt_mouse) (sin rel_ang))
                        newXScale (if (>= local_x 0.0) 1.0 -1.0)
                        newYScale (if (>= local_y 0.0) 1.0 -1.0))
                  (if (or (/= newXScale curXScale) (/= newYScale curYScale))
                    (progn
                      (setq curXScale newXScale curYScale newYScale)
                      ;; 경첩(X)에 따라 삽입 모서리를 pA/pB 로 이동
                      (setq current_insPt
                        (if align_same
                          (if (= curXScale 1.0) pA pB)
                          (if (= curXScale 1.0) pB pA)))
                      ;; 여는 쪽 안/밖(Y 반전) 때: 대칭으로 벽 밖에 놓인 문짝을 벽 안쪽으로 thk만큼 되돌림
                      ;; (벽 중심선 기준 미러 효과 → 문틀은 벽 안, 호 방향만 반대편으로)
                      ;; 참고: 반대쪽으로 놓이면 아래 각도를 (- ang_wall (/ pi 2.0))로 바꾸세요.
                      (if (< curYScale 0)
                        (setq current_insPt
                          (polar current_insPt (+ ang_wall (/ pi 2.0)) min_dist2)))
                      (setq entData (entget blkEnt))
                      (setq entData (subst (cons 10 current_insPt) (assoc 10 entData) entData))
                      (if (assoc 41 entData)
                        (setq entData (subst (cons 41 curXScale) (assoc 41 entData) entData))
                        (setq entData (append entData (list (cons 41 curXScale)))))
                      (if (assoc 42 entData)
                        (setq entData (subst (cons 42 curYScale) (assoc 42 entData) entData))
                        (setq entData (append entData (list (cons 42 curYScale)))))
                      (entmod entData)
                      (entupd blkEnt)))))
              (if (= code 3) (setq loop nil)))

            ;; ---- 타공 (측정 두께 사용) ----
            (if (= cut_opt "1")
              (progn
                (command "_.view" "_s" "TEMP_VIEW_IDD")
                (idd:cut-opening blkEnt dw min_dist2 base_lay)
                (if (tblsearch "VIEW" "TEMP_VIEW_IDD")
                  (progn (command "_.view" "_r" "TEMP_VIEW_IDD") (command "_.view" "_d" "TEMP_VIEW_IDD")))))

            (command "_.undo" "_end")
            (princ "\n문을 넣고 개구부를 뚫었습니다.")
            ))))
    )

  ;; ---- 복구 ----
  (if old_os   (setvar "OSMODE" old_os))
  (if old_echo (setvar "CMDECHO" old_echo))
  (if old_lay  (setvar "CLAYER" old_lay))
  (if old_trim (setvar "TRIMEXTENDMODE" old_trim))
  (if old_edge (setvar "EDGEMODE" old_edge))
  (princ "\n연속 삽입 작업을 종료했습니다.")
  (princ))

(princ "\n[IDD] 로드했습니다. 명령: IDD (벽선 선택 → 삽입 → 타공)\n")
(princ)
