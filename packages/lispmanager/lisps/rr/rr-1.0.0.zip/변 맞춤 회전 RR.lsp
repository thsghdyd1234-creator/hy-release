;;; ============================================================
;;; RR.lsp  -  변 맞춤 회전 (RO · R 참조 회전을 클릭 두 번으로)
;;; 명령: RR
;;;
;;; 1. 기준 변(맞출 방향)을 누른다.
;;;      선 · 폴리선의 한 구간 · 호 · 원 · 타원 · 스플라인(누른 곳의 접선) · 글자 · 다중선,
;;;      블록 · 외부 참조 안의 선도 된다. 수평(H) · 수직(V) · 각도 숫자(예: 30 Enter)도 된다.
;;; 2. 돌릴 변을 누른다 → 그 변이 기준 변과 나란해지도록 그 객체를 돌린다 (덜 도는 쪽으로).
;;;      이어서 다른 객체의 변을 누르면 같은 기준 변에 계속 맞춘다. Enter · Space · 오른쪽 클릭 = 끝.
;;;      블록 안의 선을 누르면 블록 통째로, 그룹에 든 객체면 그룹 통째로 (PICKSTYLE 그룹 선택이 켜졌을 때) 돈다.
;;; 커서 아래의 변은 미리 칠해 보인다 — 기준 변 청록, 돌릴 변 노랑(돌릴 객체는 강조), 못 돌리는 변 빨강
;;; (밝은 바탕이면 파랑 · 자홍). 돌릴 변 위에서는 회전 중심(네모)과 돌아갈 자리(점선)도 보인다.
;;;   S  객체 선택 — 고른 객체를 함께 돌림 (명령 전에 골라 두어도 됨, Enter = 다시 누른 객체만)
;;;   F  뒤집기 — 방금 돌린 것을 180° 더
;;;   R  직각 ↔ 나란히 — 방금 돌린 것도 바뀜
;;;   U  되돌리기 — 방금 돌린 것을 원래대로
;;;   T  기준 변 다시 고르기
;;;   P  회전 중심 — 가까운 끝(기본) · 변 가운데 · 객체 가운데 · 직접 찍기 (환경 변수 HyRrPivot 에 기억)
;;; 한글 자판 상태여도 같은 자리의 키로 된다. 잠긴 레이어는 돌리지 않고, 외부 참조는 S 로 고를 때만 돌린다.
;;; 각도 단위(AUNITS)와 상관없음 · UCS 를 돌려 둔 화면에서도 맞음 · 한 번 실행 = 실행 취소 한 번(U).
;;; ============================================================

(vl-load-com)

;;; ---------- 2D 벡터 (월드 XY) ----------
(defun rr:v- (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun rr:v+ (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))
(defun rr:vx (a s) (list (* (car a) s) (* (cadr a) s)))
(defun rr:len (a) (sqrt (+ (* (car a) (car a)) (* (cadr a) (cadr a)))))
(defun rr:dist (a b) (rr:len (rr:v- a b)))
(defun rr:2d (p) (list (car p) (cadr p)))
(defun rr:z (p) (if (caddr p) (caddr p) 0.0))
(defun rr:ang (v) (atan (cadr v) (car v)))
(defun rr:dir (a) (list (cos a) (sin a)))
(defun rr:mid (a b) (rr:vx (rr:v+ a b) 0.5))
(defun rr:unit (v / l)
  (setq l (rr:len v))
  (if (> l 1e-15) (rr:vx v (/ 1.0 l))))

;; 점 p 를 c 둘레로 a 만큼
(defun rr:rot (p c a / dx dy)
  (setq dx (- (car p) (car c)) dy (- (cadr p) (cadr c)))
  (list (+ (car c) (- (* dx (cos a)) (* dy (sin a))))
        (+ (cadr c) (* dx (sin a)) (* dy (cos a)))))

;; 점 q 를 선분 a-b 에 내린 점
(defun rr:proj (q a b / ab l2 s)
  (setq ab (rr:v- b a) l2 (+ (* (car ab) (car ab)) (* (cadr ab) (cadr ab))))
  (if (< l2 1e-24)
    a
    (progn
      (setq s (/ (+ (* (- (car q) (car a)) (car ab)) (* (- (cadr q) (cadr a)) (cadr ab))) l2)
            s (max 0.0 (min 1.0 s)))
      (rr:v+ a (rr:vx ab s)))))

;;; ---------- 각도 ----------
;; (-π, π]
(defun rr:norm (a)
  (while (> a pi) (setq a (- a (* 2.0 pi))))
  (while (<= a (- pi)) (setq a (+ a (* 2.0 pi))))
  a)

;; 나란히 맞출 때 도는 각 (-90°, 90°] — 변에는 앞뒤가 없으니 덜 도는 쪽
(defun rr:half (a)
  (setq a (rr:norm a))
  (cond ((> a (/ pi 2.0)) (- a pi))
        ((<= a (/ pi -2.0)) (+ a pi))
        (t a)))

;; 지금 UCS 의 X 방향 (월드 각)
(defun rr:ucs-ang () (rr:ang (rr:2d (trans '(1.0 0.0 0.0) 1 0 T))))

;; 숫자 → 글 (소수 둘째 자리까지, 끝의 0 은 뗌)
(defun rr:num (x / s)
  (setq s (rtos x 2 2))
  (if (vl-string-search "." s) (setq s (vl-string-right-trim "." (vl-string-right-trim "0" s))))
  (if (= "." (substr s 1 1)) (setq s (strcat "0" s)))
  (if (= "-0" s) (setq s "0"))
  s)

(defun rr:deg (a) (strcat (rr:num (abs (* a (/ 180.0 pi)))) "°"))

;; 방향(앞뒤 없음) → UCS X 에서 잰 0 ~ 180°
(defun rr:deg-dir (a / d)
  (setq d (* (rr:norm (- a (rr:ucs-ang))) (/ 180.0 pi)))
  (if (< d 0.0) (setq d (+ d 180.0)))
  (if (>= d 179.995) (setq d (- d 180.0)))
  (strcat (rr:num d) "°"))

;; 넣은 각도(도) → 월드 각 (ANGBASE · ANGDIR 따름, UCS 기준)
(defun rr:typed-ang (deg / a)
  (setq a (* deg (/ pi 180.0)))
  (+ (rr:ucs-ang) (getvar "ANGBASE") (if (= 1 (getvar "ANGDIR")) (- a) a)))

(defun rr:sense (a) (if (> a 0.0) "반시계로" "시계로"))

;;; ---------- nentselp 행렬 (4×4, 행) ----------
(defun rr:mp (m p / x y z)
  (setq x (car p) y (cadr p) z (rr:z p))
  (mapcar '(lambda (r) (+ (* (car r) x) (* (cadr r) y) (* (caddr r) z) (cadddr r)))
          (list (car m) (cadr m) (caddr m))))

(defun rr:mv (m v / x y z)
  (setq x (car v) y (cadr v) z (rr:z v))
  (mapcar '(lambda (r) (+ (* (car r) x) (* (cadr r) y) (* (caddr r) z)))
          (list (car m) (cadr m) (caddr m))))

;; 월드 점 → 블록 안 좌표 (행렬의 역)
(defun rr:mi (m p / a b c d e f g h k det x y z)
  (setq a (car (car m)) b (cadr (car m)) c (caddr (car m))
        d (car (cadr m)) e (cadr (cadr m)) f (caddr (cadr m))
        g (car (caddr m)) h (cadr (caddr m)) k (caddr (caddr m))
        det (+ (* a (- (* e k) (* f h))) (- (* b (- (* d k) (* f g)))) (* c (- (* d h) (* e g)))))
  (if (> (abs det) 1e-30)
    (progn
      (setq x (- (car p) (cadddr (car m))) y (- (cadr p) (cadddr (cadr m))) z (- (rr:z p) (cadddr (caddr m))))
      (list (/ (+ (* (- (* e k) (* f h)) x) (* (- (* c h) (* b k)) y) (* (- (* b f) (* c e)) z)) det)
            (/ (+ (* (- (* f g) (* d k)) x) (* (- (* a k) (* c g)) y) (* (- (* c d) (* a f)) z)) det)
            (/ (+ (* (- (* d h) (* e g)) x) (* (- (* b g) (* a h)) y) (* (- (* a e) (* b d)) z)) det)))))

;; 블록 안 점 · 방향 → 월드 2D (m 이 없으면 그대로)
(defun rr:w (m p) (rr:2d (if m (rr:mp m p) p)))
(defun rr:wv (m v) (rr:2d (if m (rr:mv m v) v)))

;;; ---------- 변 ----------
;;; 변 = (종류 각 점 끝점들 그림점들 주인 열쇠 가운데 형상) — 점은 모두 월드 2D
;;;   종류  "line" 곧은 변 · "curve" 곡선(누른 곳의 접선) · "dir" 수평 · 수직 · 숫자로 정한 방향
;;;   점    누른 곳에서 가장 가까운 변 위의 점      끝점들  회전 중심 '가까운 끝' 후보
;;;   주인  돌릴 객체 (블록 안이면 맨 바깥 블록)   열쇠    커서 아래가 바뀌었는지 볼 값
(defun rr:e-kind (x) (nth 0 x))
(defun rr:e-ang (x) (nth 1 x))
(defun rr:e-pt (x) (nth 2 x))
(defun rr:e-ends (x) (nth 3 x))
(defun rr:e-draw (x) (nth 4 x))
(defun rr:e-owner (x) (nth 5 x))
(defun rr:e-key (x) (nth 6 x))
(defun rr:e-mid (x) (nth 7 x))

;; 헤비 폴리선의 정점 → 폴리선
(defun rr:poly-of (v / d o)
  (setq d (entget v) o (cdr (assoc 330 d)))
  (if (and o (setq d (entget o)) (= "POLYLINE" (cdr (assoc 0 d))))
    o
    (progn
      (while (and v (/= "SEQEND" (cdr (assoc 0 (entget v))))) (setq v (entnext v)))
      (if v (cdr (assoc -2 (entget v)))))))

;; 누른 객체 → 돌릴 객체 (블록 안 = 맨 바깥 블록, 속성 = 그 블록, 정점 = 그 폴리선)
(defun rr:owner (e conts / d)
  (setq d (entget e))
  (cond
    (conts (last conts))
    ((= "ATTRIB" (cdr (assoc 0 d))) (cdr (assoc 330 d)))
    ((= "VERTEX" (cdr (assoc 0 d))) (rr:poly-of e))
    (t e)))

;; 곡선 위 점 → 매개변수 (스플라인이 가끔 못 찾으면 거리로)
(defun rr:param (e p / r)
  (setq r (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list e p)))
  (if (or (null r) (vl-catch-all-error-p r))
    (progn
      (setq r (vl-catch-all-apply 'vlax-curve-getDistAtPoint (list e p)))
      (if (and r (not (vl-catch-all-error-p r)))
        (setq r (vl-catch-all-apply 'vlax-curve-getParamAtDist (list e r))))))
  (if (and r (not (vl-catch-all-error-p r)) (numberp r)) r))

;; 매개변수 a → b 를 n 등분한 점들 (월드 2D)
(defun rr:samples (e a b n m / i q out)
  (setq i 0)
  (repeat (1+ n)
    (if (setq q (vlax-curve-getPointAtParam e (if (= i n) b (+ a (* (- b a) (/ (float i) n))))))
      (setq out (cons (rr:w m q) out)))
    (setq i (1+ i)))
  (reverse out))

;; 매개변수 a · b 의 방향이 같으면 곧은 구간
(defun rr:straight-p (e a b / da db)
  (setq da (rr:2d (vlax-curve-getFirstDeriv e a)) db (rr:2d (vlax-curve-getFirstDeriv e b)))
  (and (> (rr:len da) 1e-12) (> (rr:len db) 1e-12)
       (< (abs (- (* (car da) (cadr db)) (* (cadr da) (car db)))) (* 1e-9 (rr:len da) (rr:len db)))
       (> (+ (* (car da) (car db)) (* (cadr da) (cadr db))) 0.0)))

;; 선 · 호 · 원 · 타원 · 스플라인 · 폴리선 → (종류 각 점 끝점들 그림점들 가운데 구간)
(defun rr:curve-edge (e typ m pw / pb cp par st en d1 seg p0 p1 cl)
  (setq pb (if m (rr:mi m pw) pw))
  (if (and pb (setq cp (vlax-curve-getClosestPointTo e pb)) (setq par (rr:param e cp)))
    (progn
      (setq st (vlax-curve-getStartParam e) en (vlax-curve-getEndParam e)
            d1 (rr:wv m (vlax-curve-getFirstDeriv e par)))
      (cond
        ;; 폴리선: 누른 구간만 (곧은 구간이면 선, 호 구간이면 곡선)
        ((member typ '("LWPOLYLINE" "POLYLINE"))
         (setq seg (max 0 (min (fix par) (1- (fix (+ en 1e-9)))))
               p0 (rr:w m (vlax-curve-getPointAtParam e (float seg)))
               p1 (rr:w m (vlax-curve-getPointAtParam e (+ seg 1.0))))
         (cond
           ((< (rr:dist p0 p1) 1e-9) nil)
           ((rr:straight-p e (+ seg 0.02) (+ seg 0.98))
            (list "line" (rr:ang (rr:v- p1 p0)) (rr:w m cp) (list p0 p1) (list p0 p1) (rr:mid p0 p1) seg))
           ((> (rr:len d1) 1e-12)
            (list "curve" (rr:ang d1) (rr:w m cp) (list p0 p1) (rr:samples e (float seg) (+ seg 1.0) 24 m)
                  (rr:w m (vlax-curve-getPointAtParam e (+ seg 0.5))) seg))))
        ((= typ "LINE")
         (setq p0 (rr:w m (vlax-curve-getStartPoint e)) p1 (rr:w m (vlax-curve-getEndPoint e)))
         (if (> (rr:dist p0 p1) 1e-9)
           (list "line" (rr:ang (rr:v- p1 p0)) (rr:w m cp) (list p0 p1) (list p0 p1) (rr:mid p0 p1) 0)))
        ;; 호 · 원 · 타원 · 스플라인: 누른 곳의 접선
        ((> (rr:len d1) 1e-12)
         (setq cl (vlax-curve-isClosed e))
         (list "curve" (rr:ang d1) (rr:w m cp)
               (if (not cl) (list (rr:w m (vlax-curve-getStartPoint e)) (rr:w m (vlax-curve-getEndPoint e))))
               (rr:samples e st en (if (= typ "SPLINE") 64 48) m)
               (if (not cl) (rr:w m (vlax-curve-getPointAtParam e (/ (+ st en) 2.0))))
               0))))))

;; 구성선 · 광선
(defun rr:xline-edge (d typ m pw / b v q s ln)
  (setq b (rr:w m (cdr (assoc 10 d))) v (rr:unit (rr:wv m (cdr (assoc 11 d)))))
  (if v
    (progn
      (setq q (rr:2d pw)
            s (+ (* (- (car q) (car b)) (car v)) (* (- (cadr q) (cadr b)) (cadr v))))
      (if (and (= typ "RAY") (< s 0.0)) (setq s 0.0))
      (setq q (rr:v+ b (rr:vx v s)) ln (* 2.0 (getvar "VIEWSIZE")))
      (list "line" (rr:ang v) q (if (= typ "RAY") (list b))
            (list (if (= typ "RAY") b (rr:v- q (rr:vx v ln))) (rr:v+ q (rr:vx v ln)))
            nil 0))))

;; 글자: 밑줄 방향, 회전 중심 '가까운 끝' = 삽입점
(defun rr:text-edge (e d typ m / a v ins w bx p0 p1 vw)
  (if (= typ "MTEXT")
    (setq v (if (assoc 11 d)
              (cdr (assoc 11 d))
              (list (cos (cond ((cdr (assoc 50 d))) (0.0))) (sin (cond ((cdr (assoc 50 d))) (0.0))) 0.0))
          ins (cdr (assoc 10 d))
          w (cond ((and (assoc 42 d) (> (cdr (assoc 42 d)) 0.0)) (cdr (assoc 42 d)))
                  ((assoc 41 d) (cdr (assoc 41 d)))
                  (0.0)))
    (setq a (cond ((cdr (assoc 50 d))) (0.0))
          v (trans (list (cos a) (sin a) 0.0) e 0 T)
          ins (trans (cdr (assoc 10 d)) e 0)
          bx (vl-catch-all-apply 'textbox (list d))
          w (if (and bx (not (vl-catch-all-error-p bx))) (- (car (cadr bx)) (car (car bx))) 0.0)))
  (if (and (setq v (rr:unit (rr:2d v))) (setq vw (rr:unit (rr:wv m v))))
    (progn
      (setq p0 (rr:w m ins)
            p1 (if (> w 1e-9)
                 (rr:w m (list (+ (car ins) (* (car v) w)) (+ (cadr ins) (* (cadr v) w)) (rr:z ins)))
                 (rr:v+ p0 (rr:vx vw (* 40.0 (rr:px))))))
      (list "line" (rr:ang vw) p0 (list p0) (list p0 p1) (rr:mid p0 p1) 0))))

;; 다중선: 누른 곳에서 가장 가까운 구간
(defun rr:mline-edge (d m pw / pts q a k pr bd best)
  (foreach g d (if (= 11 (car g)) (setq pts (cons (rr:w m (cdr g)) pts))))
  (setq pts (reverse pts) q (rr:2d pw) k 0)
  (if (and (= 2 (logand 2 (cond ((cdr (assoc 71 d))) (0)))) (cddr pts)) (setq pts (append pts (list (car pts)))))
  (setq a (car pts))
  (foreach b (cdr pts)
    (if (> (rr:dist a b) 1e-9)
      (progn
        (setq pr (rr:proj q a b))
        (if (or (null bd) (< (rr:dist pr q) bd)) (setq bd (rr:dist pr q) best (list a b pr k)))))
    (setq a b k (1+ k)))
  (if best
    (list "line" (rr:ang (rr:v- (cadr best) (car best))) (caddr best) (list (car best) (cadr best))
          (list (car best) (cadr best)) (rr:mid (car best) (cadr best)) (cadddr best))))

;; 블록 참조 자체 (안의 선을 못 잡은 경우): 블록의 X 방향
(defun rr:insert-edge (e d m / a v p0 vw)
  (setq a (cond ((cdr (assoc 50 d))) (0.0))
        v (trans (list (cos a) (sin a) 0.0) e 0 T)
        p0 (rr:w m (trans (cdr (assoc 10 d)) e 0))
        vw (rr:unit (rr:wv m v)))
  (if vw
    (list "line" (rr:ang vw) p0 (list p0) (list p0 (rr:v+ p0 (rr:vx vw (* 60.0 (rr:px))))) nil 0)))

;;; nentselp 결과 → 변 (못 쓰는 객체면 nil)
(defun rr:edge (pk / e d typ m conts own pw r)
  (setq e (car pk) d (entget e) typ (cdr (assoc 0 d)) conts (cadddr pk)
        m (if (and (listp (caddr pk)) (= 4 (length (caddr pk)))) (caddr pk))
        own (rr:owner e conts)
        pw (trans (cadr pk) 1 0))
  (if (= typ "VERTEX")
    (setq e (rr:poly-of e) d (if e (entget e)) typ (if d (cdr (assoc 0 d)))))
  (if d
    (setq r (cond
              ((member typ '("LINE" "ARC" "CIRCLE" "ELLIPSE" "SPLINE" "LWPOLYLINE" "POLYLINE"))
               (rr:curve-edge e typ m pw))
              ((member typ '("XLINE" "RAY")) (rr:xline-edge d typ m pw))
              ((member typ '("TEXT" "ATTRIB" "ATTDEF" "MTEXT")) (rr:text-edge e d typ m))
              ((= typ "MLINE") (rr:mline-edge d m pw))
              ((= typ "INSERT") (rr:insert-edge e d m)))))
  ;; r = (종류 각 점 끝점들 그림점들 가운데 구간)
  (if (and r own)
    (list (nth 0 r) (nth 1 r) (nth 2 r) (nth 3 r) (nth 4 r) own (list e (nth 6 r) conts) (nth 5 r) e)))

(defun rr:edge-safe (pk / r)
  (setq r (vl-catch-all-apply 'rr:edge (list pk)))
  (if (not (vl-catch-all-error-p r)) r))

;; 커서 자리(UCS)의 변
(defun rr:edge-at (pt / pk)
  (if (and pt (setq pk (nentselp pt))) (rr:edge-safe pk)))

;; 수평 · 수직 · 숫자로 정한 방향 (화면 가운데에 표시)
(defun rr:dir-target (a)
  (list "dir" a (rr:2d (trans (getvar "VIEWCTR") 1 0)) nil nil nil nil nil nil))

;;; ---------- 돌릴 객체 ----------
(defun rr:locked-p (e / l)
  (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e)))))
  (and l (= 4 (logand 4 (cdr (assoc 70 l))))))

(defun rr:xref-p (e / d b)
  (setq d (entget e))
  (and (= "INSERT" (cdr (assoc 0 d)))
       (setq b (tblsearch "BLOCK" (cdr (assoc 2 d))))
       (= 4 (logand 4 (cdr (assoc 70 b))))))

(defun rr:usable (l) (vl-remove-if 'rr:locked-p l))

(defun rr:ss->list (ss / i out)
  (setq i 0)
  (repeat (sslength ss) (setq out (cons (ssname ss i) out) i (1+ i)))
  (reverse out))

;; 고를 수 있는 그룹 (없으면 nil)
(defun rr:group-of (e / l g d)
  (setq l (cdr (member '(102 . "{ACAD_REACTORS") (entget e))))
  (while (and l (null g) (not (equal (car l) '(102 . "}"))))
    (if (and (= 330 (car (car l))) (setq d (entget (cdr (car l))))
             (= "GROUP" (cdr (assoc 0 d))) (= 1 (cdr (assoc 71 d))))
      (setq g (cdr (car l))))
    (setq l (cdr l)))
  g)

;; 객체 → 같이 돌 객체들 (그룹 선택이 켜졌으면 그룹 통째로)
(defun rr:with-group (e / ps g out)
  (setq ps (getvar "PICKSTYLE"))
  (if (and (= 1 (logand 1 (if (numberp ps) ps 1))) (setq g (rr:group-of e)))
    (progn
      (foreach x (entget g) (if (and (= 340 (car x)) (entget (cdr x))) (setq out (cons (cdr x) out))))
      (if (not (member e out)) (setq out (cons e out)))
      (reverse out))
    (list e)))

;; 객체들의 월드 상자 가운데 — 같은 목록 · 돌린 뒤 바뀌지 않았으면 지난 값 (고른 객체가 많을 때 커서마다 재지 않게)
(defun rr:center (objs / o a b lo hi)
  (if (and *rr-cen* (eq (car *rr-cen*) objs) (equal (cadr *rr-cen*) *rr-gen*))
    (caddr *rr-cen*)
    (progn
      (foreach x objs
        (setq o (vlax-ename->vla-object x))
        (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
          (setq a (vlax-safearray->list a) b (vlax-safearray->list b)
                lo (if lo (mapcar 'min lo a) a) hi (if hi (mapcar 'max hi b) b))))
      (setq *rr-cen* (list objs *rr-gen* (if lo (rr:mid (rr:2d lo) (rr:2d hi)))))
      (caddr *rr-cen*))))

;; 누른 곳에서 가까운 끝 (끝이 없으면 누른 곳)
(defun rr:near-end (ed / p best bd)
  (setq p (rr:e-pt ed))
  (foreach q (rr:e-ends ed)
    (if (or (null bd) (< (rr:dist p q) bd)) (setq bd (rr:dist p q) best q)))
  (cond (best) (p)))

;;; 돌릴 변 → (객체들 회전중심 도는각) / 못 돌리면 까닭(글). 회전 중심 '직접 찍기'면 회전중심 nil
(defun rr:plan (ed tang perp pivot sel / own objs base)
  (setq own (rr:e-owner ed))
  (cond
    ((and (null sel) (rr:xref-p own)) "외부 참조는 돌리지 않습니다 — 꼭 돌리려면 객체 선택(S)으로 고르세요.")
    ((and (null sel) (rr:locked-p own)) "잠긴 레이어의 객체입니다.")
    (t
     (setq objs (if sel sel (rr:usable (rr:with-group own))))
     (if (null objs) (setq objs (list own)))
     (setq base (cond ((= pivot "M") (cond ((rr:e-mid ed)) ((rr:e-pt ed))))
                      ((= pivot "C") (cond ((rr:center objs)) ((rr:e-pt ed))))
                      ((= pivot "P") nil)
                      (t (rr:near-end ed))))
     (list objs base (rr:half (- (+ tang (if perp (/ pi 2.0) 0.0)) (rr:e-ang ed)))))))

;; 돌리기 → 돌린 수
(defun rr:turn (objs base a / n)
  (setq n 0 *rr-gen* (1+ (if (numberp *rr-gen*) *rr-gen* 0)))
  (foreach x objs
    (if (not (vl-catch-all-error-p
               (vl-catch-all-apply 'vla-Rotate
                                   (list (vlax-ename->vla-object x) (vlax-3d-point (list (car base) (cadr base) 0.0)) a))))
      (setq n (1+ n))))
  n)

;; 돌린 기록 → 서로 다른 객체 수
(defun rr:count (hist / seen)
  (foreach h hist (foreach x (car h) (if (not (member x seen)) (setq seen (cons x seen)))))
  (length seen))

;;; ---------- 화면 ----------
(defun rr:px () (/ (getvar "VIEWSIZE") (cadr (getvar "SCREENSIZE"))))
(defun rr:vsig () (list (getvar "VIEWCTR") (getvar "VIEWSIZE")))
(defun rr:u (p) (trans (list (car p) (cadr p) 0.0) 0 1))
(defun rr:gv (l) (if l (grvecs l)))

;; 바탕이 밝으면 진한 색 — (기준 변 · 돌릴 변 · 못 돌림)
(defun rr:palette (/ d c)
  (setq d (vl-catch-all-apply 'vla-get-Display (list (vla-get-Preferences (vlax-get-acad-object)))))
  (if (not (vl-catch-all-error-p d))
    (setq c (vl-catch-all-apply 'vlax-get
                                (list d (if (= 1 (getvar "TILEMODE")) 'GraphicsWinModelBackgrndColor 'GraphicsWinLayoutBackgrndColor)))))
  (if (and c (not (vl-catch-all-error-p c)) (= 'VARIANT (type c))) (setq c (vlax-variant-value c)))
  (if (and (numberp c) (setq c (fix c))
           (> (+ (* 0.299 (logand c 255)) (* 0.587 (logand (lsh c -8) 255)) (* 0.114 (logand (lsh c -16) 255))) 140))
    '(5 6 1)
    '(4 2 1)))

;; 굵은 선: 가운데 + 양옆 w 만큼 비킨 선 (grvecs 목록)
(defun rr:thick (col pts w / out a n)
  (setq a (car pts))
  (foreach b (cdr pts)
    (if (setq n (rr:unit (list (- (cadr a) (cadr b)) (- (car b) (car a)))))
      (foreach o (list '(0.0 0.0) (rr:vx n w) (rr:vx n (- w)))
        (setq out (cons (rr:u (rr:v+ b o)) (cons (rr:u (rr:v+ a o)) (cons col out))))))
    (setq a b))
  (reverse out))

;; 가는 선 (col 이 음수면 점선)
(defun rr:thin (col pts / out a)
  (setq a (car pts))
  (foreach b (cdr pts)
    (setq out (cons (rr:u b) (cons (rr:u a) (cons col out))) a b))
  (reverse out))

(defun rr:square (col c r)
  (rr:thin col (list (list (- (car c) r) (- (cadr c) r)) (list (+ (car c) r) (- (cadr c) r))
                     (list (+ (car c) r) (+ (cadr c) r)) (list (- (car c) r) (+ (cadr c) r))
                     (list (- (car c) r) (- (cadr c) r)))))

;; 변의 방향을 점선으로 (곡선의 접선 · 수평 · 수직)
(defun rr:tangent (ed col half)
  (rr:gv (rr:thin (- col) (list (rr:v- (rr:e-pt ed) (rr:vx (rr:dir (rr:e-ang ed)) half))
                                (rr:v+ (rr:e-pt ed) (rr:vx (rr:dir (rr:e-ang ed)) half))))))

(defun rr:draw-tgt (ed col px)
  (if (rr:e-draw ed) (rr:gv (rr:thick col (rr:e-draw ed) (* 0.8 px))))
  (if (/= "line" (rr:e-kind ed)) (rr:tangent ed col (* (if (= "dir" (rr:e-kind ed)) 150.0 70.0) px))))

;; 돌릴 변: 칠하고, 회전 중심(네모) · 돌아갈 자리(점선) — 못 돌리면 빨강, 이미 맞으면 가는 선만
(defun rr:draw-edge (ed pl col bad px / base a)
  (cond
    ((null pl) nil)
    ((= 'STR (type pl)) (rr:gv (rr:thick bad (rr:e-draw ed) (* 0.8 px))))
    ((rr:aligned-p pl) (rr:gv (rr:thin col (rr:e-draw ed))))
    (t
     (rr:gv (rr:thick col (rr:e-draw ed) (* 0.8 px)))
     (if (= "curve" (rr:e-kind ed)) (rr:tangent ed col (* 40.0 px)))
     (if (setq base (cadr pl))
       (progn
         (rr:gv (rr:square col base (* 4.0 px)))
         (if (> (abs (setq a (caddr pl))) 1e-10)
           (rr:gv (rr:thin (- col) (mapcar '(lambda (q) (rr:rot q base a)) (rr:e-draw ed))))))))))

(defun rr:show (tgt ed pl stage pal px)
  (redraw)
  (if tgt (rr:draw-tgt tgt (car pal) px))
  (if ed
    (if (= stage 1)
      (rr:draw-tgt ed (car pal) px)
      (rr:draw-edge ed pl (cadr pal) (caddr pal) px))))

;; 객체 강조: old 에만 있는 것은 끄고 new 에만 있는 것은 켬 → new
(defun rr:hilite (new old)
  (if (not (eq new old))
    (progn
      (foreach x old (if (and (not (member x new)) (entget x)) (redraw x 4)))
      (foreach x new (if (and (not (member x old)) (entget x)) (redraw x 3)))))
  new)

;; 계획이 '이미 맞음' 인지
(defun rr:aligned-p (pl) (and pl (listp pl) (< (abs (caddr pl)) 1e-10)))

;; 강조할 객체: 고른 객체(2000개까지) / 돌릴 변 위면 돌아갈 객체 (이미 맞으면 없음)
(defun rr:want-hl (sel pl stage)
  (cond
    (sel (if (< (length sel) 2000) sel))
    ((and (= stage 2) pl (listp pl) (not (rr:aligned-p pl)) (< (length (car pl)) 500)) (car pl))))

;; 커서 아래가 바뀌었는지 볼 값 (곡선은 커서를 따라 접선이 바뀌므로 자리도)
(defun rr:hkey (ed px)
  (if ed
    (list (rr:e-key ed)
          (if (= "curve" (rr:e-kind ed)) (mapcar '(lambda (x) (fix (/ x (* 3.0 px)))) (rr:e-pt ed))))))

;; 다시 그림 → (변 계획 열쇠 화면 강조). 커서가 기준 변 위면 기준 변만 (돌릴 변으로 칠하지 않음)
(defun rr:paint (ed tgt stage tang perp pivot sel pal hl px / k pl)
  (setq k (rr:hkey ed px))
  (if (and ed tgt (equal (rr:e-key ed) (rr:e-key tgt))) (setq ed nil))
  (setq pl (if (and ed (= stage 2)) (rr:plan ed tang perp pivot sel))
        hl (rr:hilite (rr:want-hl sel pl stage) hl))
  (rr:show tgt ed pl stage pal px)
  (list ed pl k (rr:vsig) hl))

;;; ---------- 키 ----------
;; 키 코드 → 대문자 한 글자 (한글 자판 상태여도 같은 자리의 영문 키로)
(defun rr:key (v / k)
  (cond
    ((and (> v 32) (< v 127)) (strcase (chr v)))
    ((setq k (assoc v '((12609 . "A") (12640 . "B") (12618 . "C") (12615 . "D") (12599 . "E") (12600 . "E")
                        (12601 . "F") (12622 . "G") (12631 . "H") (12625 . "I") (12627 . "J") (12623 . "K")
                        (12643 . "L") (12641 . "M") (12636 . "N") (12624 . "O") (12626 . "O") (12628 . "P")
                        (12630 . "P") (12610 . "Q") (12611 . "Q") (12593 . "R") (12594 . "R") (12596 . "S")
                        (12613 . "T") (12614 . "T") (12629 . "U") (12621 . "V") (12616 . "W") (12617 . "W")
                        (12620 . "X") (12635 . "Y") (12619 . "Z"))))
     (cdr k))
    (t "")))

(defun rr:numkey-p (v) (or (and (>= v 48) (<= v 57)) (= v 46) (= v 45)))

(defun rr:pivot-name (k)
  (cond ((= k "M") "변 가운데") ((= k "C") "객체 가운데") ((= k "P") "직접 찍기") (t "가까운 끝")))

;; 회전 중심 고르기 (키 하나, Enter = 그대로)
(defun rr:ask-pivot (cur / gr r)
  (princ (strcat "\n회전 중심 [가까운 끝(E)/변 가운데(M)/객체 가운데(C)/직접 찍기(P)] <" (rr:pivot-name cur) ">: "))
  (while (null r)
    (setq gr (grread nil 10))
    (cond
      ((= 2 (car gr))
       (cond ((member (rr:key (cadr gr)) '("E" "M" "C" "P")) (setq r (rr:key (cadr gr))))
             ((member (cadr gr) '(13 32)) (setq r cur))))
      ((member (car gr) '(3 11 25)) (setq r cur))))
  r)

(defun rr:prompt (stage sel perp)
  (princ (if (= stage 1)
           "\n기준 변을 누르세요 (각도 숫자도 됨) [수평(H)/수직(V)/객체 선택(S)/회전 중심(P)]: "
           (strcat "\n돌릴 변을 누르세요"
                   (if sel (strcat " (고른 " (itoa (length sel)) "개를 돌림)") "")
                   (if perp " (직각)" "")
                   " [객체 선택(S)/뒤집기(F)/" (if perp "나란히(R)" "직각(R)")
                   "/되돌리기(U)/기준 변(T)/회전 중심(P)] <끝>: "))))

;;; ---------- 명령 ----------
(defun c:RR (/ *error* doc undo_open pal px stage go redo gr code val cur ed key r pl base p n
               tgt tang perp pivot sel ss hl hk vs hist ent nd buf ch)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (defun *error* (msg)
    (rr:hilite nil hl)
    (redraw)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (setq pal (rr:palette) stage 1 go T buf ""
        pivot (if (member (getenv "HyRrPivot") '("E" "M" "C" "P")) (getenv "HyRrPivot") "E"))
  ;; 명령 전에 골라 둔 객체 = 함께 돌릴 객체
  (if (setq ss (cadr (ssgetfirst)))
    (progn (setq sel (rr:usable (rr:ss->list ss))) (sssetfirst nil nil)))
  (princ (strcat "\n[알림] 기준 변과 돌릴 변을 차례로 누르세요 — 돌릴 변이 기준 변과 나란해지게 돌립니다 (회전 중심: "
                 (rr:pivot-name pivot) ")."))
  (if sel (princ (strcat "\n[알림] 고른 객체 " (itoa (length sel)) "개를 함께 돌립니다.")))
  (setq hl (rr:hilite (rr:want-hl sel nil stage) nil))
  (rr:prompt stage sel perp)

  (while go
    (setq gr (grread T 15 2) code (car gr) val (cadr gr) px (rr:px))
    (cond
      ;; 커서 이동: 아래의 변을 칠함 (바뀔 때만)
      ((= code 5)
       (setq cur val ed (rr:edge-at val) key (rr:hkey ed px))
       (if (or (not (equal key hk)) (not (equal (rr:vsig) vs)))
         (setq r (rr:paint ed tgt stage tang perp pivot sel pal hl px)
               hk (caddr r) vs (cadddr r) hl (nth 4 r))))

      ;; 클릭: 1단계 = 기준 변, 2단계 = 돌릴 변
      ((= code 3)
       (setq cur val ed (rr:edge-at val) buf "" redo T)
       (cond
         ((null ed)
          (princ (if (nentselp val)
                   "\n[주의] 선 · 폴리선 · 호 · 원 · 스플라인 · 글자를 누르세요 (해치 · 면은 테두리 선을)."
                   "\n빗나갔습니다. 변 위를 누르세요.")))
         ((= stage 1)
          (setq tgt ed tang (rr:e-ang ed) stage 2)
          (princ (strcat "\n기준 방향 " (rr:deg-dir tang) ".")))
         (t
          (setq pl (rr:plan ed tang perp pivot sel))
          (cond
            ((= 'STR (type pl)) (princ (strcat "\n[주의] " pl)))
            ((< (abs (caddr pl)) 1e-10) (princ (if perp "\n이미 직각입니다." "\n이미 나란합니다.")))
            (t
             (setq base (cadr pl))
             (if (null base)
               (progn
                 (rr:show tgt ed pl stage pal px)
                 (if (setq p (getpoint "\n회전 중심을 찍으세요: "))
                   (setq base (rr:2d (trans p 1 0)))
                   (princ "\n그만두었습니다."))))
             (if base
               (progn
                 (if (not undo_open) (progn (vla-StartUndoMark doc) (setq undo_open T)))
                 (setq n (rr:turn (car pl) base (caddr pl))
                       hist (cons (list (car pl) base (caddr pl) (rr:e-ang ed) tang nil) hist))
                 (princ (strcat "\n" (rr:sense (caddr pl)) " " (rr:deg (caddr pl)) " 돌렸습니다"
                                (if (cdr (car pl)) (strcat " (객체 " (itoa n) "개)") "")
                                (if (< n (length (car pl))) (strcat " — " (itoa (- (length (car pl)) n)) "개는 못 돌림") "")
                                ".")))))))))

      ;; 오른쪽 클릭 = 끝
      ((member code '(11 25)) (setq go nil))

      ;; 키
      ((= code 2)
       (setq ch (rr:key val))
       (cond
         ;; 1단계: 각도 숫자
         ((and (= stage 1) (rr:numkey-p val)) (setq buf (strcat buf (chr val))) (princ (chr val)))
         ((and (= val 8) (/= buf ""))
          (setq buf (substr buf 1 (1- (strlen buf))))
          (princ (strcat (chr 8) " " (chr 8))))
         ((member val '(13 32))
          (cond
            ((= buf "") (setq go nil))
            ((wcmatch buf "*#*")
             (setq tang (rr:typed-ang (atof buf)) tgt (rr:dir-target tang) stage 2 buf "" redo T)
             (princ (strcat "\n기준 방향 " (rr:deg-dir tang) ".")))
            (t (setq buf "" redo T) (princ "\n[주의] 각도를 숫자로 넣으세요."))))
         ((/= buf "") nil)
         ((= ch "S")
          (setq hl (rr:hilite nil hl))
          (redraw)
          (princ "\n함께 돌릴 객체를 고르세요 (Enter = 누른 변의 객체만): ")
          (setq ss (ssget "_:L") sel (if ss (rr:ss->list ss)) redo T)
          (princ (if sel (strcat "\n객체 " (itoa (length sel)) "개를 함께 돌립니다.") "\n누른 변의 객체만 돌립니다.")))
         ((= ch "P")
          (setq pivot (rr:ask-pivot pivot) redo T)
          (setenv "HyRrPivot" pivot)
          (princ (strcat "\n회전 중심: " (rr:pivot-name pivot) ".")))
         ((and (= stage 1) (member ch '("H" "V")))
          (setq tang (+ (rr:ucs-ang) (if (= ch "V") (/ pi 2.0) 0.0)) tgt (rr:dir-target tang) stage 2 redo T)
          (princ (strcat "\n기준 방향 " (if (= ch "V") "수직" "수평") " (" (rr:deg-dir tang) ").")))
         ((= ch "U")
          (if hist
            (progn
              (setq ent (car hist) hist (cdr hist))
              (rr:turn (nth 0 ent) (nth 1 ent) (- (nth 2 ent)))
              (princ "\n한 번 되돌렸습니다."))
            (princ "\n되돌릴 것이 없습니다."))
          (setq redo T))
         ((and (= stage 2) (= ch "F"))
          (if hist
            (progn
              (setq ent (car hist))
              (rr:turn (nth 0 ent) (nth 1 ent) pi)
              (setq hist (cons (list (nth 0 ent) (nth 1 ent) (+ (nth 2 ent) pi) (nth 3 ent) (nth 4 ent) (not (nth 5 ent)))
                               (cdr hist)))
              (princ "\n180° 더 돌렸습니다."))
            (princ "\n뒤집을 것이 없습니다 — 먼저 돌릴 변을 누르세요."))
          (setq redo T))
         ((and (= stage 2) (= ch "R"))
          (setq perp (not perp) redo T)
          (princ (if perp "\n[알림] 기준 변과 직각으로 맞춥니다." "\n[알림] 기준 변과 나란히 맞춥니다."))
          ;; 방금 돌린 것도 다시 맞춤 (뒤집기는 그대로)
          (if hist
            (progn
              (setq ent (car hist)
                    nd (+ (rr:half (- (+ (nth 4 ent) (if perp (/ pi 2.0) 0.0)) (nth 3 ent))) (if (nth 5 ent) pi 0.0)))
              (if (> (abs (- nd (nth 2 ent))) 1e-12) (rr:turn (nth 0 ent) (nth 1 ent) (- nd (nth 2 ent))))
              (setq hist (cons (list (nth 0 ent) (nth 1 ent) nd (nth 3 ent) (nth 4 ent) (nth 5 ent)) (cdr hist))))))
         ((and (= stage 2) (= ch "T"))
          (setq stage 1 tgt nil redo T)))))
    ;; 무언가 바뀌었으면 지금 커서 자리로 다시 그림
    (if (and go redo)
      (progn
        (setq redo nil
              r (rr:paint (rr:edge-at cur) tgt stage tang perp pivot sel pal hl px)
              hk (caddr r) vs (cadddr r) hl (nth 4 r))
        (rr:prompt stage sel perp))))

  (setq hl (rr:hilite nil hl))
  (redraw)
  (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
  (princ (if hist (strcat "\n[완료] 객체 " (itoa (rr:count hist)) "개를 돌렸습니다.") "\n돌린 객체가 없습니다."))
  (princ))

(princ)
