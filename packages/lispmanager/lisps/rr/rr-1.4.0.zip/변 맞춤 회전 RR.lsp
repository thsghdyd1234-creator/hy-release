;;; ============================================================
;;; RR.lsp  -  변 맞춤 회전 (RO · R 참조 회전을 클릭 두 번으로)
;;; 명령: RR
;;;
;;; 1. 기준 변(맞출 방향)을 누른다.
;;;      선 · 폴리선의 한 구간 · 호 · 원 · 타원 · 스플라인(누른 곳의 접선) · 글자 · 다중선,
;;;      블록 · 외부 참조 안의 선도 된다. 수평(H) · 수직(V) · 각도 숫자(예: 30 Enter)도 된다.
;;; 2. 돌릴 변을 누른다 → 그 변이 기준 변과 나란해지는 자리(덜 도는 쪽)가 객체 통째로 점선으로 보인다.
;;;      돌아갈 쪽은 둘뿐 — 커서를 변 옆으로 비키면 객체가 변의 그쪽으로 가는 자리로 바뀐다 (덜 도는 쪽 / 반 바퀴 더).
;;; 3. 한 번 더 누른다 → 보이는 자리로 돈다 (같은 자리에서 두 번 누르면 기본 쪽).
;;;      Enter · Space · 오른쪽 클릭 · U = 그 변을 놓음 (돌리지 않음).
;;;    이어서 다른 객체의 변을 누르면 같은 기준 변에 계속 맞춘다. Enter · Space · 오른쪽 클릭 = 끝.
;;;    블록 안의 선을 누르면 블록 통째로, 그룹에 든 객체면 그룹 통째로 (PICKSTYLE 그룹 선택이 켜졌을 때) 돈다.
;;; 커서 아래의 변은 칠해 보인다 — 기준 변 청록, 돌릴 변 노랑(돌릴 객체는 강조 · 회전 중심은 네모), 못 돌리는 변 빨강
;;; (밝은 바탕이면 파랑 · 자홍). 돌아갈 자리(점선)는 돌릴 변을 누른 뒤에만 보인다 — 블록 안의 선 · 그룹 · 고른 객체
;;; 모두 통째로 그려서 기준 변의 어느 쪽으로 갈지(좌우) 보인다. 이미 나란한 변도 눌러서 반대쪽(180°)으로 돌릴 수 있음.
;;;   S  객체 선택 — 고른 객체를 함께 돌림 (명령 전에 골라 두어도 됨, Enter = 다시 누른 객체만)
;;;   F  뒤집기 — 돌릴 변을 누른 뒤면 돌아갈 자리를 반대쪽으로 (커서 대신 키로 · F 로 정하면 커서를 비켜도 그대로,
;;;      한 번 더 F = 기본 쪽), 아니면 방금 돌린 것을 180° 더
;;;   R  직각 ↔ 나란히 — 누른 뒤면 돌아갈 자리가, 아니면 방금 돌린 것이 바뀜
;;;   U  되돌리기 — 방금 돌린 것을 원래대로 (누른 뒤면 그 변을 놓음)
;;;   T  기준 변 다시 고르기
;;;   P  회전 중심 — 가까운 끝(기본, 누른 곳에서) · 변 가운데 · 객체 가운데 · 직접 찍기 (환경 변수 HyRrPivot 에 기억)
;;;   A  붙이기 ↔ 돌리기만 — 돌린 뒤 돌릴 변이 기준 변의 줄(곧은 변은 늘인 줄 · 곡선은 누른 곳의 접선) 위에 오도록
;;;      기준 변에 곧게 옮김. 직각이면 누른 쪽 끝을 붙임. 객체는 지금 있는 쪽에 남게 돌림 (커서 · F = 반대쪽).
;;;      줄자(TT) 무한선에 맞춰 붙일 때 좋음. 누른 뒤면 돌아갈 자리가, 아니면 방금 돌린 것이 바뀜.
;;;      환경 변수 HyRrAttach 에 기억.
;;; 한글 자판 상태여도 같은 자리의 키로 된다. 잠긴 레이어는 돌리지 않고, 외부 참조는 S 로 고를 때만 돌린다.
;;; 각도 단위(AUNITS)와 상관없음 · UCS 를 돌려 둔 화면에서도 맞음 · 한 번 실행 = 실행 취소 한 번(U).
;;; ============================================================

(vl-load-com)

;;; ---------- 2D 벡터 (월드 XY) ----------
(defun rr:v- (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun rr:v+ (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))
(defun rr:vx (a s) (list (* (car a) s) (* (cadr a) s)))
(defun rr:len (a) (sqrt (+ (* (car a) (car a)) (* (cadr a) (cadr a)))))
(defun rr:dist (a b) (rr:len (rr:v- a b)))
(defun rr:2d (p) (list (car p) (cadr p)))
(defun rr:z (p) (if (caddr p) (caddr p) 0.0))
(defun rr:ang (v) (atan (cadr v) (car v)))
(defun rr:dir (a) (list (cos a) (sin a)))
(defun rr:mid (a b) (rr:vx (rr:v+ a b) 0.5))
(defun rr:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun rr:unit (v / l)
  (setq l (rr:len v))
  (if (> l 1e-15) (rr:vx v (/ 1.0 l))))

;; 점 p 를 c 둘레로 a 만큼
(defun rr:rot (p c a / dx dy)
  (setq dx (- (car p) (car c)) dy (- (cadr p) (cadr c)))
  (list (+ (car c) (- (* dx (cos a)) (* dy (sin a))))
        (+ (cadr c) (* dx (sin a)) (* dy (cos a)))))

;; 점 q 를 선분 a-b 에 내린 점
(defun rr:proj (q a b / ab l2 s)
  (setq ab (rr:v- b a) l2 (+ (* (car ab) (car ab)) (* (cadr ab) (cadr ab))))
  (if (< l2 1e-24)
    a
    (progn
      (setq s (/ (+ (* (- (car q) (car a)) (car ab)) (* (- (cadr q) (cadr a)) (cadr ab))) l2)
            s (max 0.0 (min 1.0 s)))
      (rr:v+ a (rr:vx ab s)))))

;;; ---------- 각도 ----------
;; (-π, π]
(defun rr:norm (a)
  (while (> a pi) (setq a (- a (* 2.0 pi))))
  (while (<= a (- pi)) (setq a (+ a (* 2.0 pi))))
  a)

;; 나란히 맞출 때 도는 각 (-90°, 90°] — 변에는 앞뒤가 없으니 덜 도는 쪽
(defun rr:half (a)
  (setq a (rr:norm a))
  (cond ((> a (/ pi 2.0)) (- a pi))
        ((<= a (/ pi -2.0)) (+ a pi))
        (t a)))

;; 지금 UCS 의 X 방향 (월드 각)
(defun rr:ucs-ang () (rr:ang (rr:2d (trans '(1.0 0.0 0.0) 1 0 T))))

;; 숫자 → 글 (소수 둘째 자리까지, 끝의 0 은 뗌)
(defun rr:num (x / s)
  (setq s (rtos x 2 2))
  (if (vl-string-search "." s) (setq s (vl-string-right-trim "." (vl-string-right-trim "0" s))))
  (if (= "." (substr s 1 1)) (setq s (strcat "0" s)))
  (if (= "-0" s) (setq s "0"))
  s)

(defun rr:deg (a) (strcat (rr:num (abs (* a (/ 180.0 pi)))) "°"))

;; 방향(앞뒤 없음) → UCS X 에서 잰 0 ~ 180°
(defun rr:deg-dir (a / d)
  (setq d (* (rr:norm (- a (rr:ucs-ang))) (/ 180.0 pi)))
  (if (< d 0.0) (setq d (+ d 180.0)))
  (if (>= d 179.995) (setq d (- d 180.0)))
  (strcat (rr:num d) "°"))

;; 넣은 각도(도) → 월드 각 (ANGBASE · ANGDIR 따름, UCS 기준)
(defun rr:typed-ang (deg / a)
  (setq a (* deg (/ pi 180.0)))
  (+ (rr:ucs-ang) (getvar "ANGBASE") (if (= 1 (getvar "ANGDIR")) (- a) a)))

(defun rr:sense (a) (if (> a 0.0) "반시계로" "시계로"))

;;; ---------- nentselp 행렬 (4×4, 행) ----------
(defun rr:mp (m p / x y z)
  (setq x (car p) y (cadr p) z (rr:z p))
  (mapcar '(lambda (r) (+ (* (car r) x) (* (cadr r) y) (* (caddr r) z) (cadddr r)))
          (list (car m) (cadr m) (caddr m))))

(defun rr:mv (m v / x y z)
  (setq x (car v) y (cadr v) z (rr:z v))
  (mapcar '(lambda (r) (+ (* (car r) x) (* (cadr r) y) (* (caddr r) z)))
          (list (car m) (cadr m) (caddr m))))

;; 월드 점 → 블록 안 좌표 (행렬의 역)
(defun rr:mi (m p / a b c d e f g h k det x y z)
  (setq a (car (car m)) b (cadr (car m)) c (caddr (car m))
        d (car (cadr m)) e (cadr (cadr m)) f (caddr (cadr m))
        g (car (caddr m)) h (cadr (caddr m)) k (caddr (caddr m))
        det (+ (* a (- (* e k) (* f h))) (- (* b (- (* d k) (* f g)))) (* c (- (* d h) (* e g)))))
  (if (> (abs det) 1e-30)
    (progn
      (setq x (- (car p) (cadddr (car m))) y (- (cadr p) (cadddr (cadr m))) z (- (rr:z p) (cadddr (caddr m))))
      (list (/ (+ (* (- (* e k) (* f h)) x) (* (- (* c h) (* b k)) y) (* (- (* b f) (* c e)) z)) det)
            (/ (+ (* (- (* f g) (* d k)) x) (* (- (* a k) (* c g)) y) (* (- (* c d) (* a f)) z)) det)
            (/ (+ (* (- (* d h) (* e g)) x) (* (- (* b g) (* a h)) y) (* (- (* a e) (* b d)) z)) det)))))

;; 블록 안 점 · 방향 → 월드 2D (m 이 없으면 그대로)
(defun rr:w (m p) (rr:2d (if m (rr:mp m p) p)))
(defun rr:wv (m v) (rr:2d (if m (rr:mv m v) v)))

;;; ---------- 변 ----------
;;; 변 = (종류 각 점 끝점들 그림점들 주인 열쇠 가운데 형상) — 점은 모두 월드 2D
;;;   종류  "line" 곧은 변 · "curve" 곡선(누른 곳의 접선) · "dir" 수평 · 수직 · 숫자로 정한 방향
;;;   점    누른 곳에서 가장 가까운 변 위의 점      끝점들  회전 중심 '가까운 끝' 후보
;;;   주인  돌릴 객체 (블록 안이면 맨 바깥 블록)   열쇠    커서 아래가 바뀌었는지 볼 값
(defun rr:e-kind (x) (nth 0 x))
(defun rr:e-ang (x) (nth 1 x))
(defun rr:e-pt (x) (nth 2 x))
(defun rr:e-ends (x) (nth 3 x))
(defun rr:e-draw (x) (nth 4 x))
(defun rr:e-owner (x) (nth 5 x))
(defun rr:e-key (x) (nth 6 x))
(defun rr:e-mid (x) (nth 7 x))

;; 헤비 폴리선의 정점 → 폴리선
(defun rr:poly-of (v / d o)
  (setq d (entget v) o (cdr (assoc 330 d)))
  (if (and o (setq d (entget o)) (= "POLYLINE" (cdr (assoc 0 d))))
    o
    (progn
      (while (and v (/= "SEQEND" (cdr (assoc 0 (entget v))))) (setq v (entnext v)))
      (if v (cdr (assoc -2 (entget v)))))))

;; 누른 객체 → 돌릴 객체 (블록 안 = 맨 바깥 블록, 속성 = 그 블록, 정점 = 그 폴리선)
(defun rr:owner (e conts / d)
  (setq d (entget e))
  (cond
    (conts (last conts))
    ((= "ATTRIB" (cdr (assoc 0 d))) (cdr (assoc 330 d)))
    ((= "VERTEX" (cdr (assoc 0 d))) (rr:poly-of e))
    (t e)))

;; 곡선 위 점 → 매개변수 (스플라인이 가끔 못 찾으면 거리로)
(defun rr:param (e p / r)
  (setq r (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list e p)))
  (if (or (null r) (vl-catch-all-error-p r))
    (progn
      (setq r (vl-catch-all-apply 'vlax-curve-getDistAtPoint (list e p)))
      (if (and r (not (vl-catch-all-error-p r)))
        (setq r (vl-catch-all-apply 'vlax-curve-getParamAtDist (list e r))))))
  (if (and r (not (vl-catch-all-error-p r)) (numberp r)) r))

;; 매개변수 a → b 를 n 등분한 점들 (월드 2D)
(defun rr:samples (e a b n m / i q out)
  (setq i 0)
  (repeat (1+ n)
    (if (setq q (vlax-curve-getPointAtParam e (if (= i n) b (+ a (* (- b a) (/ (float i) n))))))
      (setq out (cons (rr:w m q) out)))
    (setq i (1+ i)))
  (reverse out))

;; 매개변수 a · b 의 방향이 같으면 곧은 구간
(defun rr:straight-p (e a b / da db)
  (setq da (rr:2d (vlax-curve-getFirstDeriv e a)) db (rr:2d (vlax-curve-getFirstDeriv e b)))
  (and (> (rr:len da) 1e-12) (> (rr:len db) 1e-12)
       (< (abs (- (* (car da) (cadr db)) (* (cadr da) (car db)))) (* 1e-9 (rr:len da) (rr:len db)))
       (> (+ (* (car da) (car db)) (* (cadr da) (cadr db))) 0.0)))

;; 선 · 호 · 원 · 타원 · 스플라인 · 폴리선 → (종류 각 점 끝점들 그림점들 가운데 구간)
(defun rr:curve-edge (e typ m pw / pb cp par st en d1 seg p0 p1 cl)
  (setq pb (if m (rr:mi m pw) pw))
  (if (and pb (setq cp (vlax-curve-getClosestPointTo e pb)) (setq par (rr:param e cp)))
    (progn
      (setq st (vlax-curve-getStartParam e) en (vlax-curve-getEndParam e)
            d1 (rr:wv m (vlax-curve-getFirstDeriv e par)))
      (cond
        ;; 폴리선: 누른 구간만 (곧은 구간이면 선, 호 구간이면 곡선)
        ((member typ '("LWPOLYLINE" "POLYLINE"))
         (setq seg (max 0 (min (fix par) (1- (fix (+ en 1e-9)))))
               p0 (rr:w m (vlax-curve-getPointAtParam e (float seg)))
               p1 (rr:w m (vlax-curve-getPointAtParam e (+ seg 1.0))))
         (cond
           ((< (rr:dist p0 p1) 1e-9) nil)
           ((rr:straight-p e (+ seg 0.02) (+ seg 0.98))
            (list "line" (rr:ang (rr:v- p1 p0)) (rr:w m cp) (list p0 p1) (list p0 p1) (rr:mid p0 p1) seg))
           ((> (rr:len d1) 1e-12)
            (list "curve" (rr:ang d1) (rr:w m cp) (list p0 p1) (rr:samples e (float seg) (+ seg 1.0) 24 m)
                  (rr:w m (vlax-curve-getPointAtParam e (+ seg 0.5))) seg))))
        ((= typ "LINE")
         (setq p0 (rr:w m (vlax-curve-getStartPoint e)) p1 (rr:w m (vlax-curve-getEndPoint e)))
         (if (> (rr:dist p0 p1) 1e-9)
           (list "line" (rr:ang (rr:v- p1 p0)) (rr:w m cp) (list p0 p1) (list p0 p1) (rr:mid p0 p1) 0)))
        ;; 호 · 원 · 타원 · 스플라인: 누른 곳의 접선
        ((> (rr:len d1) 1e-12)
         (setq cl (vlax-curve-isClosed e))
         (list "curve" (rr:ang d1) (rr:w m cp)
               (if (not cl) (list (rr:w m (vlax-curve-getStartPoint e)) (rr:w m (vlax-curve-getEndPoint e))))
               (rr:samples e st en (if (= typ "SPLINE") 64 48) m)
               (if (not cl) (rr:w m (vlax-curve-getPointAtParam e (/ (+ st en) 2.0))))
               0))))))

;; 구성선 · 광선
(defun rr:xline-edge (d typ m pw / b v q s ln)
  (setq b (rr:w m (cdr (assoc 10 d))) v (rr:unit (rr:wv m (cdr (assoc 11 d)))))
  (if v
    (progn
      (setq q (rr:2d pw)
            s (+ (* (- (car q) (car b)) (car v)) (* (- (cadr q) (cadr b)) (cadr v))))
      (if (and (= typ "RAY") (< s 0.0)) (setq s 0.0))
      (setq q (rr:v+ b (rr:vx v s)) ln (* 2.0 (getvar "VIEWSIZE")))
      (list "line" (rr:ang v) q (if (= typ "RAY") (list b))
            (list (if (= typ "RAY") b (rr:v- q (rr:vx v ln))) (rr:v+ q (rr:vx v ln)))
            nil 0))))

;; 글자: 밑줄 방향, 회전 중심 '가까운 끝' = 삽입점
(defun rr:text-edge (e d typ m / a v ins w bx p0 p1 vw)
  (if (= typ "MTEXT")
    (setq v (if (assoc 11 d)
              (cdr (assoc 11 d))
              (list (cos (cond ((cdr (assoc 50 d))) (0.0))) (sin (cond ((cdr (assoc 50 d))) (0.0))) 0.0))
          ins (cdr (assoc 10 d))
          w (cond ((and (assoc 42 d) (> (cdr (assoc 42 d)) 0.0)) (cdr (assoc 42 d)))
                  ((assoc 41 d) (cdr (assoc 41 d)))
                  (0.0)))
    (setq a (cond ((cdr (assoc 50 d))) (0.0))
          v (trans (list (cos a) (sin a) 0.0) e 0 T)
          ins (trans (cdr (assoc 10 d)) e 0)
          bx (vl-catch-all-apply 'textbox (list d))
          w (if (and bx (not (vl-catch-all-error-p bx))) (- (car (cadr bx)) (car (car bx))) 0.0)))
  (if (and (setq v (rr:unit (rr:2d v))) (setq vw (rr:unit (rr:wv m v))))
    (progn
      (setq p0 (rr:w m ins)
            p1 (if (> w 1e-9)
                 (rr:w m (list (+ (car ins) (* (car v) w)) (+ (cadr ins) (* (cadr v) w)) (rr:z ins)))
                 (rr:v+ p0 (rr:vx vw (* 40.0 (rr:px))))))
      (list "line" (rr:ang vw) p0 (list p0) (list p0 p1) (rr:mid p0 p1) 0))))

;; 다중선: 누른 곳에서 가장 가까운 구간
(defun rr:mline-edge (d m pw / pts q a k pr bd best)
  (foreach g d (if (= 11 (car g)) (setq pts (cons (rr:w m (cdr g)) pts))))
  (setq pts (reverse pts) q (rr:2d pw) k 0)
  (if (and (= 2 (logand 2 (cond ((cdr (assoc 71 d))) (0)))) (cddr pts)) (setq pts (append pts (list (car pts)))))
  (setq a (car pts))
  (foreach b (cdr pts)
    (if (> (rr:dist a b) 1e-9)
      (progn
        (setq pr (rr:proj q a b))
        (if (or (null bd) (< (rr:dist pr q) bd)) (setq bd (rr:dist pr q) best (list a b pr k)))))
    (setq a b k (1+ k)))
  (if best
    (list "line" (rr:ang (rr:v- (cadr best) (car best))) (caddr best) (list (car best) (cadr best))
          (list (car best) (cadr best)) (rr:mid (car best) (cadr best)) (cadddr best))))

;; 블록 참조 자체 (안의 선을 못 잡은 경우): 블록의 X 방향
(defun rr:insert-edge (e d m / a v p0 vw)
  (setq a (cond ((cdr (assoc 50 d))) (0.0))
        v (trans (list (cos a) (sin a) 0.0) e 0 T)
        p0 (rr:w m (trans (cdr (assoc 10 d)) e 0))
        vw (rr:unit (rr:wv m v)))
  (if vw
    (list "line" (rr:ang vw) p0 (list p0) (list p0 (rr:v+ p0 (rr:vx vw (* 60.0 (rr:px))))) nil 0)))

;;; nentselp 결과 → 변 (못 쓰는 객체면 nil)
(defun rr:edge (pk / e d typ m conts own pw r)
  (setq e (car pk) d (entget e) typ (cdr (assoc 0 d)) conts (cadddr pk)
        m (if (and (listp (caddr pk)) (= 4 (length (caddr pk)))) (caddr pk))
        own (rr:owner e conts)
        pw (trans (cadr pk) 1 0))
  (if (= typ "VERTEX")
    (setq e (rr:poly-of e) d (if e (entget e)) typ (if d (cdr (assoc 0 d)))))
  (if d
    (setq r (cond
              ((member typ '("LINE" "ARC" "CIRCLE" "ELLIPSE" "SPLINE" "LWPOLYLINE" "POLYLINE"))
               (rr:curve-edge e typ m pw))
              ((member typ '("XLINE" "RAY")) (rr:xline-edge d typ m pw))
              ((member typ '("TEXT" "ATTRIB" "ATTDEF" "MTEXT")) (rr:text-edge e d typ m))
              ((= typ "MLINE") (rr:mline-edge d m pw))
              ((= typ "INSERT") (rr:insert-edge e d m)))))
  ;; r = (종류 각 점 끝점들 그림점들 가운데 구간)
  (if (and r own)
    (list (nth 0 r) (nth 1 r) (nth 2 r) (nth 3 r) (nth 4 r) own (list e (nth 6 r) conts) (nth 5 r) e)))

(defun rr:edge-safe (pk / r)
  (setq r (vl-catch-all-apply 'rr:edge (list pk)))
  (if (not (vl-catch-all-error-p r)) r))

;; 커서 자리(UCS)의 변
(defun rr:edge-at (pt / pk)
  (if (and pt (setq pk (nentselp pt))) (rr:edge-safe pk)))

;; 수평 · 수직 · 숫자로 정한 방향 (화면 가운데에 표시)
(defun rr:dir-target (a)
  (list "dir" a (rr:2d (trans (getvar "VIEWCTR") 1 0)) nil nil nil nil nil nil))

;;; ---------- 돌릴 객체 ----------
(defun rr:locked-p (e / l)
  (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e)))))
  (and l (= 4 (logand 4 (cdr (assoc 70 l))))))

(defun rr:xref-p (e / d b)
  (setq d (entget e))
  (and (= "INSERT" (cdr (assoc 0 d)))
       (setq b (tblsearch "BLOCK" (cdr (assoc 2 d))))
       (= 4 (logand 4 (cdr (assoc 70 b))))))

(defun rr:usable (l) (vl-remove-if 'rr:locked-p l))

(defun rr:ss->list (ss / i out)
  (setq i 0)
  (repeat (sslength ss) (setq out (cons (ssname ss i) out) i (1+ i)))
  (reverse out))

;; 고를 수 있는 그룹 (없으면 nil)
(defun rr:group-of (e / l g d)
  (setq l (cdr (member '(102 . "{ACAD_REACTORS") (entget e))))
  (while (and l (null g) (not (equal (car l) '(102 . "}"))))
    (if (and (= 330 (car (car l))) (setq d (entget (cdr (car l))))
             (= "GROUP" (cdr (assoc 0 d))) (= 1 (cdr (assoc 71 d))))
      (setq g (cdr (car l))))
    (setq l (cdr l)))
  g)

;; 객체 → 같이 돌 객체들 (그룹 선택이 켜졌으면 그룹 통째로)
(defun rr:with-group (e / ps g out)
  (setq ps (getvar "PICKSTYLE"))
  (if (and (= 1 (logand 1 (if (numberp ps) ps 1))) (setq g (rr:group-of e)))
    (progn
      (foreach x (entget g) (if (and (= 340 (car x)) (entget (cdr x))) (setq out (cons (cdr x) out))))
      (if (not (member e out)) (setq out (cons e out)))
      (reverse out))
    (list e)))

;; 객체들의 월드 상자 가운데 — 같은 목록 · 돌린 뒤 바뀌지 않았으면 지난 값 (고른 객체가 많을 때 커서마다 재지 않게)
(defun rr:center (objs / o a b lo hi)
  (if (and *rr-cen* (eq (car *rr-cen*) objs) (equal (cadr *rr-cen*) *rr-gen*))
    (caddr *rr-cen*)
    (progn
      (foreach x objs
        (setq o (vlax-ename->vla-object x))
        (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
          (setq a (vlax-safearray->list a) b (vlax-safearray->list b)
                lo (if lo (mapcar 'min lo a) a) hi (if hi (mapcar 'max hi b) b))))
      (setq *rr-cen* (list objs *rr-gen* (if lo (rr:mid (rr:2d lo) (rr:2d hi)))))
      (caddr *rr-cen*))))

;; 누른 곳에서 가까운 끝 (끝이 없으면 누른 곳)
(defun rr:near-end (ed / p best bd)
  (setq p (rr:e-pt ed))
  (foreach q (rr:e-ends ed)
    (if (or (null bd) (< (rr:dist p q) bd)) (setq bd (rr:dist p q) best q)))
  (cond (best) (p)))

;;; ---------- 붙이기 ----------
;; 붙일 기준 줄이 지나는 점 — 수평 · 수직 · 숫자로 정한 방향이거나 기준 변이 같이 돌면 없음
(defun rr:ref-pt (tgt objs)
  (if (and tgt (/= "dir" (rr:e-kind tgt)) (not (member (rr:e-owner tgt) objs)))
    (rr:e-pt tgt)))

;; 돌릴 변에서 기준 줄에 닿게 할 점 — 나란히 = 누른 곳 (변이 통째로 줄 위로), 직각 = 누른 쪽 끝
(defun rr:att-pt (ed perp) (if perp (rr:near-end ed) (rr:e-pt ed)))

;; 기준 줄의 왼쪽 법선
(defun rr:normal (tang) (list (- (sin tang)) (cos tang)))

;; 점 q 를 base 둘레로 a 만큼 돌린 뒤 기준 줄(pref 를 지나 tang 방향)에 닿게 하는 옮김 — 기준 줄에 곧게
(defun rr:attach-move (q base a pref tang / n)
  (setq n (rr:normal tang))
  (rr:vx n (rr:dot (rr:v- pref (rr:rot q base a)) n)))

;; 안 옮겨도 되는 만큼 작은지 (좌표가 커도)
(defun rr:tiny-p (d pref) (< (rr:len d) (* 1e-8 (max 1.0 (rr:len pref)))))

;; 붙일 때 객체가 지금 있는 쪽(기준 줄의)에 남는 각 — 덜 도는 쪽 a 에서 붙이면 반대쪽으로 가면 반 바퀴 더.
;; 가운데가 기준 줄이나 붙일 점의 줄 위라 쪽을 모르면 a 그대로
(defun rr:side-ang (a q pref tang cen / n s0 v s1)
  (if (and q pref cen)
    (progn
      (setq n (rr:normal tang)
            s0 (rr:dot (rr:v- cen pref) n)
            v (rr:rot (rr:v- cen q) '(0.0 0.0) a)
            s1 (rr:dot v n))
      (if (and (> (abs s0) (* 1e-6 (max 1.0 (rr:len (rr:v- cen pref)))))
               (> (abs s1) (* 1e-6 (max 1.0 (rr:len v))))
               (< (* s0 s1) 0.0))
        (rr:norm (+ a pi))
        a))
    a))

;; 돌릴 각 — 덜 도는 쪽 (붙이면 객체가 있는 쪽에 남게) · 뒤집었으면 반 바퀴 더 (-180° ~ 180° 로)
(defun rr:angle (eang tang perp att q pref cen fl / a)
  (setq a (rr:half (- (+ tang (if perp (/ pi 2.0) 0.0)) eang)))
  (if (and att pref) (setq a (rr:side-ang a q pref tang cen)))
  (if fl (rr:norm (+ a pi)) a))

;;; 돌릴 변 → (객체들 회전중심 도는각 옮김 기준점 가운데 열쇠 뒤집음 그림중심 그림옮김 쪽고르기) / 못 돌리면 까닭(글).
;;;   회전 중심 '직접 찍기'면 회전중심 nil (돌 각이 0 이면 누른 곳), 옮김 = 붙일 때만 · 기준점 = 붙일 수 있는 기준 줄의 점
;;;   fl = 반대쪽으로 (덜 도는 쪽 · 있던 쪽에서 반 바퀴 더 — 마우스 쪽 · F 로 정함), 열쇠 = (객체들 변)
;;;   그림중심 · 그림옮김 = 돌아갈 자리를 그릴 때 — 회전 중심을 아직 안 찍었으면 누른 곳 둘레로 (어느 쪽으로 갈지만 보임)
;;;   쪽 고르기 = (객체 쪽 덜도는각 기본각 축 가운데중심) — 마우스 쪽을 볼 때 (rr:aim-fl). 객체 쪽 = 객체 가운데가
;;;   돌릴 변의 왼쪽 법선 쪽으로 얼마나 있는지(월드), 축 = 기본 쪽 → 반대쪽을 가르는 방향 (rr:axis)
(defun rr:plan (ed tgt tang perp pivot sel att fl / own objs base a0 a pref cen d key gb gd q c)
  (setq own (rr:e-owner ed))
  (cond
    ((and (null sel) (rr:xref-p own)) "외부 참조는 돌리지 않습니다 — 꼭 돌리려면 객체 선택(S)으로 고르세요.")
    ((and (null sel) (rr:locked-p own)) "잠긴 레이어의 객체입니다.")
    (t
     (setq objs (if sel sel (rr:usable (rr:with-group own))))
     (if (null objs) (setq objs (list own)))
     (setq key (list objs (rr:e-key ed))
           pref (rr:ref-pt tgt objs)
           cen (if (and att pref) (rr:center objs))
           q (rr:att-pt ed perp)
           a0 (rr:angle (rr:e-ang ed) tang perp att q pref cen nil)
           a (if fl (rr:norm (+ a0 pi)) a0)
           base (cond ((= pivot "M") (cond ((rr:e-mid ed)) ((rr:e-pt ed))))
                      ((= pivot "C") (cond ((rr:center objs)) ((rr:e-pt ed))))
                      ((= pivot "P") (if (< (abs a) 1e-10) (rr:e-pt ed)))
                      (t (rr:near-end ed))))
     (if (and att pref base)
       (setq d (rr:attach-move q base a pref tang)))
     (if (and d (rr:tiny-p d pref)) (setq d nil))
     (setq gb (cond (base) ((rr:e-pt ed)))
           gd (cond (base d) ((and att pref) (rr:attach-move q gb a pref tang))))
     (if (and gd (rr:tiny-p gd pref)) (setq gd nil))
     (list objs base a d pref cen key (if fl T) gb gd
           (list (if (setq c (rr:center objs)) (rr:dot (rr:v- c (rr:e-pt ed)) (rr:normal (rr:e-ang ed))))
                 (rr:half (- (+ tang (if perp (/ pi 2.0) 0.0)) (rr:e-ang ed)))
                 a0 (rr:axis objs ed gb a0 q (and att pref) pref tang) (= pivot "C"))))))

;; 기본 쪽(A) 과 반대쪽(B) 을 가르는 방향 = A 로 돌아간 대표점 − B 로 돌아간 대표점 (붙이면 붙인 자리로 옮긴 뒤).
;; 대표점 = 객체 가운데 — 회전 중심이 가운데면 두 쪽 가운데가 같으므로 누른 곳(누른 변이 어느 쪽으로 가는지)
(defun rr:axis (objs ed gb a0 q at pref tang / r ra rb)
  (setq r (rr:center objs))
  (if (or (null r) (< (rr:dist r gb) (* 1e-9 (max 1.0 (rr:len gb))))) (setq r (rr:e-pt ed)))
  (setq ra (rr:rot r gb a0) rb (rr:rot r gb (+ a0 pi)))
  (if at
    (setq ra (rr:v+ ra (rr:attach-move q gb a0 pref tang))
          rb (rr:v+ rb (rr:attach-move q gb (+ a0 pi) pref tang))))
  (rr:v- ra rb))

;;; ---------- 돌아갈 쪽 (1.4.0) ----------
;;; 돌릴 변을 누르면 그 변을 붙잡고 돌아갈 자리를 기본 쪽(덜 도는 쪽 · 붙이면 있던 쪽)으로 보임. 돌아갈 쪽은 둘뿐이라
;;; 커서가 누른 곳에서 어느 쪽으로 비켰는지로 고름 — 객체가 누른 변의 그쪽으로 가는 쪽(기본 쪽 / 반 바퀴 더).
;;; 한 번 더 누르면 보이는 쪽으로 돎. F 로 정한 쪽은 커서를 비켜도 그대로.
;; 누른 곳에서 이만큼(화면 점) 넘게 비켜야 쪽이 바뀜 — 그 안이면 보이는 쪽 그대로 (같은 자리에서 두 번 누르면 기본 쪽)
(defun rr:hyst () (max 12.0 (* 5.0 (getvar "PICKBOX"))))

;; 비킨 쪽 aim(누른 곳 → 커서, 월드)으로 뒤집을지 → fl. dec = 계획의 쪽 고르기, ne = 누른 변의 왼쪽 법선.
;;   회전 중심이 변 위(가까운 끝 · 변 가운데 · 직접 찍기)이고 객체가 변의 한쪽에 있으면: 커서가 변에서 객체 쪽이면
;;   덜 도는 쪽, 반대쪽이면 반 바퀴 더 — 객체가 누른 변을 축으로 커서 쪽으로 넘어감 (변에 곧게 rr:hyst 안이면 그대로).
;;   회전 중심이 가운데거나 객체가 변 위(선 하나)면: 비킨 방향이 축 쪽(누른 곳 · 가운데가 가는 쪽)인지 (75° 안)
(defun rr:aim-fl (aim dec ne fl px / sb as a0 ax s u c)
  (if (and aim dec (> (rr:len aim) (* (rr:hyst) px)))
    (progn
      (setq sb (nth 0 dec) as (nth 1 dec) a0 (nth 2 dec) ax (nth 3 dec))
      (cond
        ((and (not (nth 4 dec)) sb ne (> (abs sb) (* 0.5 px)))
         (setq s (/ (rr:dot aim ne) px))
         (if (< (abs s) (rr:hyst))
           fl
           (> (abs (rr:norm (- (if (> (* s sb) 0.0) as (+ as pi)) a0))) 1e-6)))
        ((and ax (setq u (rr:unit ax)) (setq c (rr:unit aim)))
         (setq c (rr:dot c u))
         (cond ((> c 0.26) nil) ((< c -0.26) T) (t fl)))
        (t fl)))
    fl))

;; 누른 돌릴 변 pe 의 계획 pp 에서 커서 p(UCS) 쪽으로 반대쪽으로 돌릴지 → fl (F 로 정했으면 lk — 그대로)
(defun rr:pick-fl (pe pp fl lk p px)
  (if (or lk (null p) (not (listp pp)))
    fl
    (rr:aim-fl (rr:v- (rr:2d (trans p 1 0)) (rr:e-pt pe)) (nth 10 pp) (rr:normal (rr:e-ang pe)) fl px)))

;; 이미 맞음 글
(defun rr:already (pl att perp)
  (cond ((and att (nth 4 pl)) "이미 붙어 있습니다") (perp "이미 직각입니다") (t "이미 나란합니다")))

;; 돌리기 → 돌린 수
(defun rr:turn (objs base a / n)
  (setq n 0 *rr-gen* (1+ (if (numberp *rr-gen*) *rr-gen* 0)))
  (foreach x objs
    (if (not (vl-catch-all-error-p
               (vl-catch-all-apply 'vla-Rotate
                                   (list (vlax-ename->vla-object x) (vlax-3d-point (list (car base) (cadr base) 0.0)) a))))
      (setq n (1+ n))))
  n)

;; 옮기기 → 옮긴 수
(defun rr:shift (objs d / n)
  (setq n 0 *rr-gen* (1+ (if (numberp *rr-gen*) *rr-gen* 0)))
  (foreach x objs
    (if (not (vl-catch-all-error-p
               (vl-catch-all-apply 'vla-Move
                                   (list (vlax-ename->vla-object x) (vlax-3d-point '(0.0 0.0 0.0))
                                         (vlax-3d-point (list (car d) (cadr d) 0.0))))))
      (setq n (1+ n))))
  n)

;;; 돌린 기록 = (객체들 회전중심 도는각 변각 기준각 뒤집음 옮김 누른점 누른끝 기준점 직각 붙임 가운데)
;; 지난 돌림을 각 nd · 뒤집음 fl · 직각 pp · 붙임 at 로 다시 → 새 기록 (옮김을 풀고 → 더 돌리고 → 다시 붙임)
(defun rr:redo (ent nd fl pp at / objs base d)
  (setq objs (nth 0 ent) base (nth 1 ent))
  (if (nth 6 ent) (rr:shift objs (rr:vx (nth 6 ent) -1.0)))
  (if (> (abs (- nd (nth 2 ent))) 1e-12) (rr:turn objs base (- nd (nth 2 ent))))
  (if (and at (nth 9 ent))
    (setq d (rr:attach-move (if pp (nth 8 ent) (nth 7 ent)) base nd (nth 9 ent) (nth 4 ent))))
  (if (and d (rr:tiny-p d (nth 9 ent))) (setq d nil))
  (if d (rr:shift objs d))
  (list objs base nd (nth 3 ent) (nth 4 ent) fl d (nth 7 ent) (nth 8 ent) (nth 9 ent) pp at (nth 12 ent)))

;; 지난 돌림을 직각 pp · 붙임 at · 뒤집음 fl 로 처음부터 다시 셈한 각
(defun rr:redo-ang (ent pp at fl)
  (rr:angle (nth 3 ent) (nth 4 ent) pp at (if pp (nth 8 ent) (nth 7 ent)) (nth 9 ent) (nth 12 ent) fl))

;; 되돌리기 (옮김을 풀고 → 거꾸로 돌림)
(defun rr:undo (ent)
  (if (nth 6 ent) (rr:shift (nth 0 ent) (rr:vx (nth 6 ent) -1.0)))
  (if (> (abs (nth 2 ent)) 1e-12) (rr:turn (nth 0 ent) (nth 1 ent) (- (nth 2 ent)))))

;; 한 일 글 — '반시계로 20° 돌렸습니다' · '… 돌리고 기준 변에 붙였습니다' · '기준 변에 붙였습니다'
(defun rr:did (a d)
  (cond
    ((and d (> (abs a) 1e-10)) (strcat (rr:sense a) " " (rr:deg a) " 돌리고 기준 변에 붙였습니다"))
    (d "기준 변에 붙였습니다")
    (t (strcat (rr:sense a) " " (rr:deg a) " 돌렸습니다"))))

(defun rr:join (l sep / s)
  (setq s (car l))
  (foreach x (cdr l) (setq s (strcat s sep x)))
  s)

;; 돌린 기록 → 서로 다른 객체 수
(defun rr:count (hist / seen)
  (foreach h hist (foreach x (car h) (if (not (member x seen)) (setq seen (cons x seen)))))
  (length seen))

;;; ---------- 돌아갈 자리 모양 (객체 통째로) ----------
;;; 돌릴 객체들 → 돌리기 전의 월드 2D 꺾은선들. 미리보기는 이것을 돌려 그려서 블록 · 그룹이 기준 변의 어느 쪽으로
;;; 갈지(좌우) 보이게 함. 블록 · 외부 참조는 안의 선까지 (8단계, 꺼진 · 얼린 레이어와 안 보이는 객체는 빼고),
;;; 글자는 상자, 해치는 테두리, 그 밖의 객체는 상자. 점이 (rr:shape-max) 를 넘으면 남은 객체는 상자만 (미리보기라서).
(defun rr:shape-max () 4000)

;; 2D 변환 m = (a b c d e f): x' = ax + by + c, y' = dx + ey + f — nil 이면 그대로
(defun rr:xa (m p)
  (if m
    (list (+ (* (nth 0 m) (car p)) (* (nth 1 m) (cadr p)) (nth 2 m))
          (+ (* (nth 3 m) (car p)) (* (nth 4 m) (cadr p)) (nth 5 m)))
    (list (car p) (cadr p))))

;; m · n (n 을 먼저)
(defun rr:xm (m n)
  (cond
    ((null m) n)
    ((null n) m)
    (t (list (+ (* (nth 0 m) (nth 0 n)) (* (nth 1 m) (nth 3 n)))
             (+ (* (nth 0 m) (nth 1 n)) (* (nth 1 m) (nth 4 n)))
             (+ (* (nth 0 m) (nth 2 n)) (* (nth 1 m) (nth 5 n)) (nth 2 m))
             (+ (* (nth 3 m) (nth 0 n)) (* (nth 4 m) (nth 3 n)))
             (+ (* (nth 3 m) (nth 1 n)) (* (nth 4 m) (nth 4 n)))
             (+ (* (nth 3 m) (nth 2 n)) (* (nth 4 m) (nth 5 n)) (nth 5 m))))))

;; 블록 참조 d → 블록 안 좌표를 그 참조가 놓인 곳의 좌표로 (평면에 비춘 2D). ij = 다중 삽입(MINSERT)의 (열 행)
(defun rr:ins-xf (d ij / n r sx sy b o du dv vx vy)
  (setq n (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        r (cond ((cdr (assoc 50 d))) (0.0))
        sx (cond ((cdr (assoc 41 d))) (1.0))
        sy (cond ((cdr (assoc 42 d))) (1.0))
        b (cond ((cdr (assoc 10 (tblsearch "BLOCK" (cdr (assoc 2 d)))))) ('(0.0 0.0 0.0)))
        du (* (car ij) (cond ((cdr (assoc 44 d))) (0.0)))
        dv (* (cadr ij) (cond ((cdr (assoc 45 d))) (0.0)))
        o (rr:v+ (trans (cdr (assoc 10 d)) n 0)
                 (trans (list (- (* du (cos r)) (* dv (sin r))) (+ (* du (sin r)) (* dv (cos r))) 0.0) n 0 T))
        vx (trans (list (* sx (cos r)) (* sx (sin r)) 0.0) n 0 T)
        vy (trans (list (- (* sy (sin r))) (* sy (cos r)) 0.0) n 0 T))
  (list (car vx) (car vy) (- (car o) (* (car vx) (car b)) (* (car vy) (cadr b)))
        (cadr vx) (cadr vy) (- (cadr o) (* (cadr vx) (car b)) (* (cadr vy) (cadr b)))))

;; OCS 점 p (2D) · 높이 el · 법선 n → 월드(블록 안이면 그 좌표) → m
(defun rr:ocs (p el n m)
  (rr:xa m (if (equal n '(0.0 0.0 1.0) 1e-12) p (trans (list (car p) (cadr p) el) n 0))))

;; 레이어가 보이는지 — 0 레이어는 블록을 따라가니 보이는 것으로, 한 번 본 레이어는 기억 (rr$lay)
(defun rr:lay-on (nm / k r)
  (if (or (null nm) (= nm "0"))
    T
    (progn
      (setq k (strcase nm))
      (if (not (setq r (assoc k rr$lay)))
        (setq r (cons k (if (setq r (tblsearch "LAYER" nm))
                          (and (>= (cond ((cdr (assoc 62 r))) (7)) 0) (/= 1 (logand 1 (cond ((cdr (assoc 70 r))) (0)))))
                          T))
              rr$lay (cons r rr$lay)))
      (cdr r))))

;; 꺾은선 하나 넣기 (점 둘 이상) — 점 수를 셈 (rr$out rr$n)
(defun rr:sh-put (pts)
  (if (cdr pts) (setq rr$out (cons pts rr$out) rr$n (+ rr$n (length pts)))))

;; p0 → p1 볼록(bulge) 구간 위의 점들 (p0 은 빼고 p1 까지) — 중심은 현 가운데에서 왼쪽으로 (1/b - b)/4 × 현
(defun rr:bulge-pts (p0 p1 b / th h c n i out)
  (if (< (abs b) 1e-9)
    (list p1)
    (progn
      (setq th (* 4.0 (atan b))
            h (rr:v- p1 p0)
            c (rr:v+ (rr:mid p0 p1) (rr:vx (list (- (cadr h)) (car h)) (/ (- (/ 1.0 b) b) 4.0)))
            n (max 2 (fix (+ 0.5 (/ (abs th) (/ pi 12.0)))))
            i 1)
      (repeat n
        (setq out (cons (if (= i n) p1 (rr:rot p0 c (* th (/ (float i) n)))) out) i (1+ i)))
      (reverse out))))

;; 꼭짓점들 ((x y 볼록) …) (OCS) → 꺾은선 (닫힘이면 처음으로 돌아옴)
(defun rr:sh-poly (vs closed el n m / a out)
  (if (and closed (cdr vs)) (setq vs (append vs (list (car vs)))))
  (if (setq a (car vs))
    (progn
      (setq out (list (rr:ocs a el n m)))
      (foreach b (cdr vs)
        (foreach q (rr:bulge-pts (list (car a) (cadr a)) (list (car b) (cadr b)) (caddr a))
          (setq out (cons (rr:ocs q el n m) out)))
        (setq a b))
      (rr:sh-put (reverse out)))))

;; 가벼운 폴리선의 꼭짓점들 ((x y 볼록) …)
(defun rr:lw-verts (d / vs cur)
  (foreach g d
    (cond ((= 10 (car g)) (if cur (setq vs (cons cur vs))) (setq cur (list (cadr g) (caddr g) 0.0)))
          ((and (= 42 (car g)) cur) (setq cur (list (car cur) (cadr cur) (cdr g))))))
  (if cur (setq vs (cons cur vs)))
  (reverse vs))

;; 무거운 폴리선 — 2D 는 OCS 꼭짓점 · 볼록, 3D 는 월드 꼭짓점 (그물망은 상자)
(defun rr:sh-pline (e d m / f v dv vs n)
  (setq f (cond ((cdr (assoc 70 d))) (0)))
  (if (/= 0 (logand f 80))
    (rr:sh-bbox e m)
    (progn
      (setq v (entnext e))
      (while (and v (setq dv (entget v)) (= "VERTEX" (cdr (assoc 0 dv))))
        (if (/= 16 (logand 16 (cond ((cdr (assoc 70 dv))) (0))))
          (setq vs (cons (list (cadr (assoc 10 dv)) (caddr (assoc 10 dv)) (cond ((cdr (assoc 42 dv))) (0.0))) vs)))
        (setq v (entnext v)))
      (setq n (if (= 8 (logand f 8)) '(0.0 0.0 1.0) (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))))
      (rr:sh-poly (reverse vs) (= 1 (logand f 1)) (rr:z (cdr (assoc 10 d))) n m))))

;; 호 · 원 · 타원 · 스플라인 — 곡선 위를 고르게
(defun rr:sh-curve (e typ m / st en n i q out)
  (setq st (vlax-curve-getStartParam e) en (vlax-curve-getEndParam e)
        n (cond ((= typ "SPLINE") 64)
                ((= typ "ARC") (max 4 (fix (+ 0.5 (/ (abs (- en st)) (/ pi 18.0))))))
                (t 48))
        i 0)
  (repeat (1+ n)
    (if (setq q (vlax-curve-getPointAtParam e (if (= i n) en (+ st (* (- en st) (/ (float i) n))))))
      (setq out (cons (rr:xa m q) out)))
    (setq i (1+ i)))
  (rr:sh-put (reverse out)))

;; 네모 (u0 v0)-(u1 v1) — 원점 o · 각 r 인 OCS 좌표계에서
(defun rr:sh-box (o r u0 v0 u1 v1 n m / cs sn)
  (setq cs (cos r) sn (sin r))
  (rr:sh-put (mapcar '(lambda (uv) (rr:ocs (list (+ (car o) (- (* (car uv) cs) (* (cadr uv) sn)))
                                                 (+ (cadr o) (* (car uv) sn) (* (cadr uv) cs)))
                                           (rr:z o) n m))
                     (list (list u0 v0) (list u1 v0) (list u1 v1) (list u0 v1) (list u0 v0)))))

;; 글자 · 속성 — 밑줄 방향으로 돌린 상자
(defun rr:sh-text (d m / bx)
  (setq bx (vl-catch-all-apply 'textbox (list d)))
  (if (and bx (not (vl-catch-all-error-p bx)) (car bx) (cadr bx))
    (rr:sh-box (cdr (assoc 10 d)) (cond ((cdr (assoc 50 d))) (0.0))
               (car (car bx)) (cadr (car bx)) (car (cadr bx)) (cadr (cadr bx))
               (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0))) m)))

;; 여러 줄 글자 — 붙는 점(71)에 맞춘 상자
(defun rr:sh-mtext (d m / x y w h k u0 v1 o)
  (setq x (if (assoc 11 d) (rr:unit (rr:2d (cdr (assoc 11 d))))))
  (if (null x) (setq x (rr:dir (cond ((cdr (assoc 50 d))) (0.0)))))
  (setq y (list (- (cadr x)) (car x))
        w (cond ((and (assoc 42 d) (> (cdr (assoc 42 d)) 0.0)) (cdr (assoc 42 d)))
                ((and (assoc 41 d) (> (cdr (assoc 41 d)) 0.0)) (cdr (assoc 41 d)))
                (t (* 0.8 (cond ((cdr (assoc 40 d))) (2.5)) (max 1 (strlen (cond ((cdr (assoc 1 d))) (" ")))))))
        h (cond ((and (assoc 43 d) (> (cdr (assoc 43 d)) 0.0)) (cdr (assoc 43 d))) ((cdr (assoc 40 d))) (2.5))
        k (1- (max 1 (min 9 (cond ((cdr (assoc 71 d))) (1)))))
        u0 (cond ((= 0 (rem k 3)) 0.0) ((= 1 (rem k 3)) (* -0.5 w)) (t (- w)))
        v1 (cond ((= 0 (/ k 3)) 0.0) ((= 1 (/ k 3)) (* 0.5 h)) (t h))
        o (rr:2d (cdr (assoc 10 d))))
  (rr:sh-put (mapcar '(lambda (uv) (rr:xa m (rr:v+ o (rr:v+ (rr:vx x (car uv)) (rr:vx y (cadr uv))))))
                     (list (list u0 (- v1 h)) (list (+ u0 w) (- v1 h)) (list (+ u0 w) v1) (list u0 v1) (list u0 (- v1 h))))))

;; 해치 원호 · 타원 변 (반시계 각 a0 → a1) 위의 점들
(defun rr:arc-pts (c ux uy a0 a1 / n i t1 out)
  (while (< a1 a0) (setq a1 (+ a1 (* 2.0 pi))))
  (setq n (max 4 (fix (+ 0.5 (/ (- a1 a0) (/ pi 18.0))))) i 0)
  (repeat (1+ n)
    (setq t1 (+ a0 (* (- a1 a0) (/ (float i) n)))
          out (cons (rr:v+ c (rr:v+ (rr:vx ux (cos t1)) (rr:vx uy (sin t1)))) out)
          i (1+ i)))
  (reverse out))

;; 해치 테두리 — 꺾은선 경로 · 선 · 원호 · 타원 변 (스플라인 변이 나오면 그 해치는 거기까지).
;; 시계 방향 변(73 = 0)의 각은 보각(360° - 각)으로 들어 있음
(defun rr:sh-hatch (d m / n el l np f hb cl nv ne ty vs g b c r a0 a1 ux)
  (setq n (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        el (rr:z (cdr (assoc 10 d)))
        np (cond ((cdr (assoc 91 d))) (0))
        l (cdr (member (assoc 91 d) d)))
  (while (and l (> np 0))
    (while (and l (/= 92 (car (car l)))) (setq l (cdr l)))
    (if l
      (progn
        (setq f (cdr (car l)) l (cdr l) np (1- np))
        (if (= 2 (logand 2 f))
          ;; 꺾은선 경로: 72 볼록 있음 · 73 닫힘 · 93 꼭짓점 수 · 꼭짓점마다 10 (+ 42)
          (progn
            (setq hb (cdr (assoc 72 l)) cl (cdr (assoc 73 l)) nv (cond ((cdr (assoc 93 l))) (0))
                  l (cdr (member (assoc 93 l) l)) vs nil)
            (repeat nv
              (while (and l (/= 10 (car (car l)))) (setq l (cdr l)))
              (if l
                (progn
                  (setq g (car l) l (cdr l) b 0.0)
                  (if (and (equal hb 1) l (= 42 (car (car l)))) (setq b (cdr (car l)) l (cdr l)))
                  (setq vs (cons (list (cadr g) (caddr g) b) vs)))))
            (rr:sh-poly (reverse vs) (equal cl 1) el n m))
          ;; 변 경로: 93 변 수 · 변마다 72 종류 (1 선 · 2 원호 · 3 타원 · 4 스플라인)
          (progn
            (setq ne (cond ((cdr (assoc 93 l))) (0)) l (cdr (member (assoc 93 l) l)))
            (while (and l (> ne 0))
              (setq ty (cdr (car l)) l (cdr l) ne (1- ne))
              (cond
                ((= ty 1)
                 (rr:sh-poly (list (list (cadr (car l)) (caddr (car l)) 0.0) (list (cadr (cadr l)) (caddr (cadr l)) 0.0))
                             nil el n m)
                 (setq l (cddr l)))
                ((member ty '(2 3))
                 ;; 원호 10 40 50 51 73 · 타원 10 11 40 50 51 73
                 (setq c (rr:2d (cdr (car l))) l (cdr l))
                 (if (= ty 3) (setq ux (rr:2d (cdr (car l))) l (cdr l)))
                 (setq r (cdr (car l)) a0 (cdr (cadr l)) a1 (cdr (caddr l)) cl (cdr (cadddr l)) l (cddddr l))
                 (if (not (equal cl 1)) (setq b a0 a0 (- (* 2.0 pi) a1) a1 (- (* 2.0 pi) b)))
                 ;; 타원 변의 각은 실제 각 → 매개변수로
                 (if (= ty 3) (setq a0 (atan (/ (sin a0) r) (cos a0)) a1 (atan (/ (sin a1) r) (cos a1))))
                 (if (= ty 2) (setq ux (list r 0.0) r 1.0))
                 (rr:sh-put (mapcar '(lambda (q) (rr:ocs q el n m))
                                    (rr:arc-pts c ux (rr:vx (list (- (cadr ux)) (car ux)) r) a0 a1))))
                (t (setq l nil np 0)))))))))
  nil)

;; 상자 (월드 상자, 블록 안이면 그 좌표의 상자를 m 으로)
(defun rr:sh-bbox (e m / o a b)
  (setq o (vlax-ename->vla-object e))
  (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
    (progn
      (setq a (vlax-safearray->list a) b (vlax-safearray->list b))
      (rr:sh-put (mapcar '(lambda (p) (rr:xa m p))
                         (list a (list (car b) (cadr a)) b (list (car a) (cadr b)) a))))))

;; 블록 정의 이름 → 안의 객체들 (안 그려지는 객체가 많은 큰 블록도 오래 걸리지 않게 객체 2만 개까지만 봄)
(defun rr:sh-blk (nm m dep / x dx)
  (if (and nm (setq x (tblobjname "BLOCK" nm)))
    (progn
      (setq x (entnext x))
      (while (and x (< rr$n (rr:shape-max)) (< rr$v 20000) (setq dx (entget x)) (/= "ENDBLK" (cdr (assoc 0 dx))))
        (setq rr$v (1+ rr$v))
        (vl-catch-all-apply 'rr:sh-ent (list x dx m dep))
        (setq x (entnext x))))))

;; 블록 참조 (다중 삽입은 칸마다, 16 × 16 까지) — 안을 못 읽으면(외부 참조 등) 상자. 맨 바깥 블록은 속성도
(defun rr:sh-ins (e d m dep / k i j x dx)
  (setq k rr$n i 0)
  (if (< dep 8)
    (repeat (min 16 (max 1 (cond ((cdr (assoc 70 d))) (1))))
      (setq j 0)
      (repeat (min 16 (max 1 (cond ((cdr (assoc 71 d))) (1))))
        (rr:sh-blk (cdr (assoc 2 d)) (rr:xm m (rr:ins-xf d (list i j))) (1+ dep))
        (setq j (1+ j)))
      (setq i (1+ i))))
  (if (= k rr$n) (rr:sh-bbox e m))
  (if (and (= dep 0) (equal 1 (cdr (assoc 66 d))))
    (progn
      (setq x (entnext e))
      (while (and x (setq dx (entget x)) (= "ATTRIB" (cdr (assoc 0 dx))))
        (rr:sh-ent x dx nil 0)
        (setq x (entnext x))))))

;; 객체 하나 → 꺾은선들. m = 그 객체가 있는 곳에서 월드까지의 변환 (맨 바깥은 nil), dep = 블록 깊이
(defun rr:sh-ent (e d m dep / typ)
  (setq typ (cdr (assoc 0 d)))
  (cond
    ((>= rr$n (rr:shape-max)) nil)
    ((equal 1 (cdr (assoc 60 d))) nil)
    ((not (rr:lay-on (cdr (assoc 8 d)))) nil)
    ((= typ "LINE") (rr:sh-put (list (rr:xa m (cdr (assoc 10 d))) (rr:xa m (cdr (assoc 11 d))))))
    ((= typ "LWPOLYLINE")
     (rr:sh-poly (rr:lw-verts d) (= 1 (logand 1 (cond ((cdr (assoc 70 d))) (0)))) (cond ((cdr (assoc 38 d))) (0.0))
                 (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0))) m))
    ((= typ "POLYLINE") (rr:sh-pline e d m))
    ((member typ '("ARC" "CIRCLE" "ELLIPSE" "SPLINE")) (rr:sh-curve e typ m))
    ((or (member typ '("TEXT" "ATTRIB"))
         (and (= typ "ATTDEF") (or (= dep 0) (= 2 (logand 2 (cond ((cdr (assoc 70 d))) (0)))))))
     (if (/= 1 (logand 1 (if (= typ "TEXT") 0 (cond ((cdr (assoc 70 d))) (0))))) (rr:sh-text d m)))
    ((= typ "MTEXT") (rr:sh-mtext d m))
    ((= typ "HATCH") (rr:sh-hatch d m))
    ((member typ '("SOLID" "TRACE"))
     (rr:sh-poly (mapcar '(lambda (k) (list (cadr (assoc k d)) (caddr (assoc k d)) 0.0)) '(10 11 13 12)) T
                 (rr:z (cdr (assoc 10 d))) (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0))) m))
    ((= typ "3DFACE") (rr:sh-put (mapcar '(lambda (k) (rr:xa m (cdr (assoc k d)))) '(10 11 12 13 10))))
    ((= typ "INSERT") (rr:sh-ins e d m dep))
    ((= typ "DIMENSION") (if (< dep 8) (rr:sh-blk (cdr (assoc 2 d)) m (1+ dep))))
    ((member typ '("XLINE" "RAY" "POINT" "ATTDEF" "VIEWPORT" "SEQEND" "VERTEX")) nil)
    (t (rr:sh-bbox e m))))

;; 목록의 앞 n 개
(defun rr:head (l n / out)
  (repeat (min n (length l)) (setq out (cons (car l) out) l (cdr l)))
  (reverse out))

;; 돌릴 객체들 → 꺾은선들 (월드 2D, 돌리기 전). 최근 넷은 기억 (같은 객체 · 돌린 뒤 바뀌지 않았으면 다시 안 셈)
(defun rr:shape (objs / rr$out rr$n rr$v rr$lay rest hit d)
  (foreach c *rr-shp*
    (if (and (null hit) (equal (car c) objs) (equal (cadr c) *rr-gen*)) (setq hit c)))
  (if hit
    (caddr hit)
    (progn
      (setq rr$n 0 rr$v 0 rest objs)
      (while (and rest (< rr$n (rr:shape-max)))
        (if (setq d (entget (car rest)))
          (progn
            (vl-catch-all-apply 'rr:sh-ent (list (car rest) d nil 0))
            ;; 이 객체에서 한도를 넘었으면 (다 못 그렸을 수 있음) 상자도
            (if (>= rr$n (rr:shape-max)) (rr:sh-bbox (car rest) nil))))
        (setq rest (cdr rest)))
      ;; 남은 객체는 상자만 (2000 개까지)
      (repeat (min 2000 (length rest))
        (rr:sh-bbox (car rest) nil)
        (setq rest (cdr rest)))
      (setq *rr-shp* (cons (list objs *rr-gen* rr$out) (rr:head *rr-shp* 3)))
      rr$out)))

;; 돌아갈 자리 — 모양을 base 둘레로 a 만큼 돌리고 d 만큼 옮긴 선들 (grvecs 목록, col 이 음수면 점선)
(defun rr:ghost (shp base a d col / ca sa bx by dx dy wu out p0)
  (setq ca (cos a) sa (sin a) bx (car base) by (cadr base)
        dx (if d (car d) 0.0) dy (if d (cadr d) 0.0) wu (= 1 (getvar "WORLDUCS")))
  (foreach pl shp
    (setq p0 nil)
    (foreach q pl
      (setq q (list (+ bx dx (- (* (- (car q) bx) ca) (* (- (cadr q) by) sa)))
                    (+ by dy (* (- (car q) bx) sa) (* (- (cadr q) by) ca)))
            q (if wu (list (car q) (cadr q) 0.0) (rr:u q)))
      (if p0 (setq out (cons q (cons p0 (cons col out)))))
      (setq p0 q)))
  (reverse out))

;;; ---------- 화면 ----------
(defun rr:px () (/ (getvar "VIEWSIZE") (cadr (getvar "SCREENSIZE"))))
(defun rr:vsig () (list (getvar "VIEWCTR") (getvar "VIEWSIZE")))
(defun rr:u (p) (trans (list (car p) (cadr p) 0.0) 0 1))
(defun rr:gv (l) (if l (grvecs l)))

;; 바탕이 밝으면 진한 색 — (기준 변 · 돌릴 변 · 못 돌림)
(defun rr:palette (/ d c)
  (setq d (vl-catch-all-apply 'vla-get-Display (list (vla-get-Preferences (vlax-get-acad-object)))))
  (if (not (vl-catch-all-error-p d))
    (setq c (vl-catch-all-apply 'vlax-get
                                (list d (if (= 1 (getvar "TILEMODE")) 'GraphicsWinModelBackgrndColor 'GraphicsWinLayoutBackgrndColor)))))
  (if (and c (not (vl-catch-all-error-p c)) (= 'VARIANT (type c))) (setq c (vlax-variant-value c)))
  (if (and (numberp c) (setq c (fix c))
           (> (+ (* 0.299 (logand c 255)) (* 0.587 (logand (lsh c -8) 255)) (* 0.114 (logand (lsh c -16) 255))) 140))
    '(5 6 1)
    '(4 2 1)))

;; 굵은 선: 가운데 + 양옆 w 만큼 비킨 선 (grvecs 목록)
(defun rr:thick (col pts w / out a n)
  (setq a (car pts))
  (foreach b (cdr pts)
    (if (setq n (rr:unit (list (- (cadr a) (cadr b)) (- (car b) (car a)))))
      (foreach o (list '(0.0 0.0) (rr:vx n w) (rr:vx n (- w)))
        (setq out (cons (rr:u (rr:v+ b o)) (cons (rr:u (rr:v+ a o)) (cons col out))))))
    (setq a b))
  (reverse out))

;; 가는 선 (col 이 음수면 점선)
(defun rr:thin (col pts / out a)
  (setq a (car pts))
  (foreach b (cdr pts)
    (setq out (cons (rr:u b) (cons (rr:u a) (cons col out))) a b))
  (reverse out))

(defun rr:square (col c r)
  (rr:thin col (list (list (- (car c) r) (- (cadr c) r)) (list (+ (car c) r) (- (cadr c) r))
                     (list (+ (car c) r) (+ (cadr c) r)) (list (- (car c) r) (+ (cadr c) r))
                     (list (- (car c) r) (- (cadr c) r)))))

;; 변의 방향을 점선으로 (곡선의 접선 · 수평 · 수직)
(defun rr:tangent (ed col half)
  (rr:gv (rr:thin (- col) (list (rr:v- (rr:e-pt ed) (rr:vx (rr:dir (rr:e-ang ed)) half))
                                (rr:v+ (rr:e-pt ed) (rr:vx (rr:dir (rr:e-ang ed)) half))))))

(defun rr:draw-tgt (ed col px)
  (if (rr:e-draw ed) (rr:gv (rr:thick col (rr:e-draw ed) (* 0.8 px))))
  (if (/= "line" (rr:e-kind ed)) (rr:tangent ed col (* (if (= "dir" (rr:e-kind ed)) 150.0 70.0) px))))

;; 기준 줄(pref 를 지나 ang 방향) 위에서 pref 와 점들을 덮는 토막 (양끝 조금 더)
(defun rr:span (pref ang pts / u lo hi s m)
  (setq u (rr:dir ang) lo 0.0 hi 0.0)
  (foreach q pts
    (setq s (rr:dot (rr:v- q pref) u) lo (min lo s) hi (max hi s)))
  (setq m (* 0.05 (- hi lo)))
  (list (rr:v+ pref (rr:vx u (- lo m))) (rr:v+ pref (rr:vx u (+ hi m)))))

;; 돌릴 변: 칠하고 회전 중심(네모) — 못 돌리면 빨강, 이미 맞으면 가는 선만. 누른 뒤(full)면 돌아갈 자리(점선)도:
;; 객체 통째로 가는 점선 + 돌릴 변이 갈 자리는 굵은 점선 (한 번에 그림). 회전 중심을 아직 안 찍었으면(직접 찍기)
;; 누른 곳 둘레로 그려 어느 쪽으로 갈지만 보임 (네모 없음). 붙이면 돌아갈 자리는 기준 줄 위 · 기준 변을 그 자리까지
;; 늘인 줄도 점선(기준 변 색)으로. 누른 변이 이미 맞으면 굵게 칠하고 네모만 (반대쪽으로 비키면 돌아갈 자리가 보임)
(defun rr:draw-edge (ed pl col bad px tgt rcol full / base a gb gd dst)
  (cond
    ((null pl) nil)
    ((= 'STR (type pl)) (rr:gv (rr:thick bad (rr:e-draw ed) (* 0.8 px))))
    ((and (not full) (rr:aligned-p pl)) (rr:gv (rr:thin col (rr:e-draw ed))))
    (t
     (rr:gv (rr:thick col (rr:e-draw ed) (* 0.8 px)))
     (if (= "curve" (rr:e-kind ed)) (rr:tangent ed col (* 40.0 px)))
     (setq base (cadr pl) a (caddr pl) gb (nth 8 pl) gd (nth 9 pl))
     (if base (rr:gv (rr:square col base (* 4.0 px))))
     (if (and full gb (not (rr:aligned-p pl)))
       (progn
         (setq dst (mapcar '(lambda (q) (rr:rot q gb a)) (rr:e-draw ed)))
         (if gd (setq dst (mapcar '(lambda (q) (rr:v+ q gd)) dst)))
         (rr:gv (append (rr:ghost (rr:shape (car pl)) gb a gd (- col)) (rr:thick (- col) dst (* 0.8 px))))
         (if (and gd tgt) (rr:gv (rr:thin (- rcol) (rr:span (nth 4 pl) (rr:e-ang tgt) dst)))))))))

(defun rr:show (tgt ed pl stage pal px full)
  (redraw)
  (if tgt (rr:draw-tgt tgt (car pal) px))
  (if ed
    (if (= stage 1)
      (rr:draw-tgt ed (car pal) px)
      (rr:draw-edge ed pl (cadr pal) (caddr pal) px tgt (car pal) full))))

;; 객체 강조: old 에만 있는 것은 끄고 new 에만 있는 것은 켬 → new
(defun rr:hilite (new old)
  (if (not (eq new old))
    (progn
      (foreach x old (if (and (not (member x new)) (entget x)) (redraw x 4)))
      (foreach x new (if (and (not (member x old)) (entget x)) (redraw x 3)))))
  new)

;; 계획이 '이미 맞음' 인지 (돌 각도 옮길 거리도 없음)
(defun rr:aligned-p (pl) (and pl (listp pl) (< (abs (caddr pl)) 1e-10) (null (nth 3 pl))))

;; 강조할 객체: 고른 객체(2000개까지) / 돌릴 변 위면 돌아갈 객체 (커서만 올렸을 때 이미 맞으면 없음)
(defun rr:want-hl (sel pl stage full)
  (cond
    (sel (if (< (length sel) 2000) sel))
    ((and (= stage 2) pl (listp pl) (or full (not (rr:aligned-p pl))) (< (length (car pl)) 500)) (car pl))))

;; 커서 아래가 바뀌었는지 볼 값 (곡선은 커서를 따라 접선이 바뀌므로 자리도 · 가까운 끝이 바뀌면 회전 중심도 바뀜)
(defun rr:hkey (ed px)
  (if ed
    (list (rr:e-key ed)
          (if (= "curve" (rr:e-kind ed)) (mapcar '(lambda (x) (fix (/ x (* 3.0 px)))) (rr:e-pt ed)))
          (rr:near-end ed))))

;; 커서 아래를 다시 그림 → (변 계획 열쇠 화면 강조). 커서가 기준 변 위면 기준 변만 (돌릴 변으로 칠하지 않음).
;; 돌릴 변은 칠하고 회전 중심(네모)만 — 돌아갈 자리는 누른 뒤에 (rr:paint-pick)
(defun rr:paint (ed tgt stage tang perp pivot sel att pal hl px / k pl)
  (setq k (rr:hkey ed px))
  (if (and ed tgt (equal (rr:e-key ed) (rr:e-key tgt))) (setq ed nil))
  (if (and ed (= stage 2)) (setq pl (rr:plan ed tgt tang perp pivot sel att nil)))
  (setq hl (rr:hilite (rr:want-hl sel pl stage nil) hl))
  (rr:show tgt ed pl stage pal px nil)
  (list ed pl k (rr:vsig) hl))

;; 누른 돌릴 변 pe 를 계획 pp 대로 — 돌아갈 자리까지 → (화면 강조)
(defun rr:paint-pick (pe pp tgt sel pal hl px)
  (setq hl (rr:hilite (rr:want-hl sel pp 2 T) hl))
  (rr:show tgt pe pp 2 pal px T)
  (list (rr:vsig) hl))

;;; ---------- 키 ----------
;; 키 코드 → 대문자 한 글자 (한글 자판 상태여도 같은 자리의 영문 키로)
(defun rr:key (v / k)
  (cond
    ((and (> v 32) (< v 127)) (strcase (chr v)))
    ((setq k (assoc v '((12609 . "A") (12640 . "B") (12618 . "C") (12615 . "D") (12599 . "E") (12600 . "E")
                        (12601 . "F") (12622 . "G") (12631 . "H") (12625 . "I") (12627 . "J") (12623 . "K")
                        (12643 . "L") (12641 . "M") (12636 . "N") (12624 . "O") (12626 . "O") (12628 . "P")
                        (12630 . "P") (12610 . "Q") (12611 . "Q") (12593 . "R") (12594 . "R") (12596 . "S")
                        (12613 . "T") (12614 . "T") (12629 . "U") (12621 . "V") (12616 . "W") (12617 . "W")
                        (12620 . "X") (12635 . "Y") (12619 . "Z"))))
     (cdr k))
    (t "")))

(defun rr:numkey-p (v) (or (and (>= v 48) (<= v 57)) (= v 46) (= v 45)))

(defun rr:pivot-name (k)
  (cond ((= k "M") "변 가운데") ((= k "C") "객체 가운데") ((= k "P") "직접 찍기") (t "가까운 끝")))

;; 회전 중심 고르기 (키 하나, Enter = 그대로)
(defun rr:ask-pivot (cur / gr r)
  (princ (strcat "\n회전 중심 [가까운 끝(E)/변 가운데(M)/객체 가운데(C)/직접 찍기(P)] <" (rr:pivot-name cur) ">: "))
  (while (null r)
    (setq gr (grread nil 10))
    (cond
      ((= 2 (car gr))
       (cond ((member (rr:key (cadr gr)) '("E" "M" "C" "P")) (setq r (rr:key (cadr gr))))
             ((member (cadr gr) '(13 32)) (setq r cur))))
      ((member (car gr) '(3 11 25)) (setq r cur))))
  r)

(defun rr:prompt (stage sel perp att pend / ak)
  (setq ak (if att "돌리기만(A)" "붙이기(A)"))
  (princ (cond
           ((= stage 1)
            (strcat "\n기준 변을 누르세요 (각도 숫자도 됨)" (if att " (붙이기)" "")
                    " [수평(H)/수직(V)/객체 선택(S)/회전 중심(P)/" ak "]: "))
           (pend
            (strcat "\n돌아갈 쪽을 고르고 누르세요" (if perp " (직각)" "") (if att " (붙이기)" "")
                    " [뒤집기(F)/" (if perp "나란히(R)" "직각(R)") "/" ak "/회전 중심(P)/취소(U)] <취소>: "))
           (t
            (strcat "\n돌릴 변을 누르세요"
                    (if sel (strcat " (고른 " (itoa (length sel)) "개를 돌림)") "")
                    (if perp " (직각)" "")
                    (if att " (붙이기)" "")
                    " [객체 선택(S)/뒤집기(F)/" (if perp "나란히(R)" "직각(R)")
                    "/" ak "/되돌리기(U)/기준 변(T)/회전 중심(P)] <끝>: ")))))

;; 붙일 줄이 없는 기준(정한 방향)이면 알림
(defun rr:no-line (tgt att)
  (if (and att tgt (= "dir" (rr:e-kind tgt)))
    (princ "\n[주의] 수평 · 수직 · 각도로 정한 방향에는 붙일 줄이 없어 돌리기만 합니다.")))

;;; ---------- 명령 ----------
;;; 2단계 상태: pe = 누른 돌릴 변 (nil = 아직 안 누름), pp = 그 계획, pfl = 반대쪽으로 돌릴지, plk = F 로 정함
(defun c:RR (/ *error* doc undo_open pal px stage go redo gr code val cur ed key r pl base p n
               tgt tang perp pivot sel ss hl hk vs hist ent buf ch att a d cen notes k
               pe pp pfl plk nf told)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (defun *error* (msg)
    (rr:hilite nil hl)
    (redraw)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  ;; 돌아갈 자리 모양은 이번 실행에서만 기억 (그사이 도면을 고쳤을 수 있음)
  (setq pal (rr:palette) stage 1 go T buf "" *rr-shp* nil
        pivot (if (member (getenv "HyRrPivot") '("E" "M" "C" "P")) (getenv "HyRrPivot") "E")
        att (= "1" (getenv "HyRrAttach")))
  ;; 명령 전에 골라 둔 객체 = 함께 돌릴 객체
  (if (setq ss (cadr (ssgetfirst)))
    (progn (setq sel (rr:usable (rr:ss->list ss))) (sssetfirst nil nil)))
  (princ (strcat "\n[알림] 기준 변과 돌릴 변을 차례로 누르세요 — 돌릴 변이 기준 변과 나란해지게 "
                 (if att "돌리고 기준 변에 붙입니다" "돌립니다") " (회전 중심: " (rr:pivot-name pivot) ")."))
  (if sel (princ (strcat "\n[알림] 고른 객체 " (itoa (length sel)) "개를 함께 돌립니다.")))
  (setq hl (rr:hilite (rr:want-hl sel nil stage nil) nil))
  (rr:prompt stage sel perp att nil)

  (while go
    (setq gr (grread T 15 2) code (car gr) val (cadr gr) px (rr:px))
    (cond
      ;; 커서 이동
      ((= code 5)
       (setq cur val)
       (if pe
         ;; 돌릴 변을 누른 뒤: 커서가 누른 곳에서 어느 쪽으로 비켰는지로 돌아갈 쪽 (바뀔 때만 다시 그림)
         (progn
           (if (not (eq (setq nf (rr:pick-fl pe pp pfl plk val px)) pfl))
             (setq pfl nf pp (rr:plan pe tgt tang perp pivot sel att pfl) vs nil))
           (if (not (equal (rr:vsig) vs))
             (setq r (rr:paint-pick pe pp tgt sel pal hl px) vs (car r) hl (cadr r))))
         ;; 아직 안 누름: 커서 아래의 변을 칠함 (바뀔 때만) — 돌아갈 자리는 누른 뒤에
         (progn
           (setq ed (rr:edge-at val) key (rr:hkey ed px))
           (if (or (not (equal key hk)) (not (equal (rr:vsig) vs)))
             (setq r (rr:paint ed tgt stage tang perp pivot sel att pal hl px)
                   hk (caddr r) vs (cadddr r) hl (nth 4 r))))))

      ;; 클릭: 1단계 = 기준 변, 2단계 = 돌릴 변 (누르면 돌아갈 자리를 보임) → 한 번 더 = 보이는 자리로 돌림
      ((= code 3)
       (setq cur val buf "" redo T)
       (cond
         (pe
          ;; 누른 자리로 돌아갈 쪽을 한 번 더 봄 (옮기지 않고 누른 경우)
          (if (not (eq (setq nf (rr:pick-fl pe pp pfl plk val px)) pfl))
            (setq pfl nf pp (rr:plan pe tgt tang perp pivot sel att pfl)))
          (setq ed pe pl pp pe nil pp nil pfl nil plk nil)
          (cond
            ((= 'STR (type pl)) (princ (strcat "\n[주의] " pl)))
            ((rr:aligned-p pl) (princ "\n그대로 둡니다."))
            (t
             (setq base (cadr pl) a (caddr pl) d (nth 3 pl))
             (if (null base)
               (progn
                 (rr:show tgt ed pl stage pal px T)
                 (if (setq p (getpoint "\n회전 중심을 찍으세요: "))
                   (setq base (rr:2d (trans p 1 0))
                         d (if (and att (nth 4 pl)) (rr:attach-move (rr:att-pt ed perp) base a (nth 4 pl) tang)))
                   (princ "\n그만두었습니다."))))
             (if (and d (rr:tiny-p d (nth 4 pl))) (setq d nil))
             (if base
               (progn
                 (if (not undo_open) (progn (vla-StartUndoMark doc) (setq undo_open T)))
                 ;; 객체 가운데는 돌리기 전에 (나중에 붙이기를 켜도 있는 쪽을 알게)
                 (setq cen (cond ((nth 5 pl)) ((nth 4 pl) (rr:center (car pl))))
                       n (if (> (abs a) 1e-10) (rr:turn (car pl) base a) (length (car pl))))
                 (if d (setq k (rr:shift (car pl) d) n (min n k)))
                 (setq hist (cons (list (car pl) base a (rr:e-ang ed) tang (nth 7 pl) d (rr:e-pt ed) (rr:near-end ed)
                                        (nth 4 pl) perp (if (and att (nth 4 pl)) T) cen)
                                  hist)
                       notes (vl-remove nil (list (if d (strcat (rr:num (rr:len d)) " 옮김"))
                                                  (if (cdr (car pl)) (strcat "객체 " (itoa n) "개")))))
                 (princ (strcat "\n" (rr:did a d)
                                (if notes (strcat " (" (rr:join notes " · ") ")") "")
                                (if (< n (length (car pl))) (strcat " — " (itoa (- (length (car pl)) n)) "개는 못 돌림") "")
                                "."))
                 (if (and att tgt (/= "dir" (rr:e-kind tgt)) (null (nth 4 pl)))
                   (princ "\n[주의] 기준 변도 같이 돌아서 붙이지 않았습니다.")))))))
         ((null (setq ed (rr:edge-at val)))
          (princ (if (nentselp val)
                   "\n[주의] 선 · 폴리선 · 호 · 원 · 스플라인 · 글자를 누르세요 (해치 · 면은 테두리 선을)."
                   "\n빗나갔습니다. 변 위를 누르세요.")))
         ((= stage 1)
          (setq tgt ed tang (rr:e-ang ed) stage 2)
          (princ (strcat "\n기준 방향 " (rr:deg-dir tang) ".")))
         ;; 기준 변을 다시 누름 — 돌릴 변이 아님
         ((and tgt (equal (rr:e-key ed) (rr:e-key tgt)))
          (princ "\n기준 변입니다 — 돌릴 변을 누르세요 (기준 변을 다시 고르려면 T)."))
         ;; 돌릴 변을 누름 → 그 변을 붙잡고 돌아갈 자리를 보임 (기본 쪽부터)
         ((= 'STR (type (setq pl (rr:plan ed tgt tang perp pivot sel att nil))))
          (princ (strcat "\n[주의] " pl)))
         (t
          (setq pe ed pp pl pfl nil plk nil)
          (if (rr:aligned-p pl)
            (princ (strcat "\n" (rr:already pl att perp)
                           " — 반대쪽(180°)으로 돌리려면 커서를 변 옆으로 비킨 뒤 누르세요 (같은 자리 = 그대로)."))))))

      ;; 오른쪽 클릭 = 누른 변을 놓음 / 끝
      ((member code '(11 25))
       (if pe
         (progn (setq pe nil pp nil pfl nil plk nil redo T) (princ "\n취소했습니다 — 돌릴 변을 다시 누르세요."))
         (setq go nil)))

      ;; 키
      ((= code 2)
       (setq ch (rr:key val))
       (cond
         ;; 1단계: 각도 숫자
         ((and (= stage 1) (rr:numkey-p val)) (setq buf (strcat buf (chr val))) (princ (chr val)))
         ((and (= val 8) (/= buf ""))
          (setq buf (substr buf 1 (1- (strlen buf))))
          (princ (strcat (chr 8) " " (chr 8))))
         ((member val '(13 32))
          (cond
            (pe (setq pe nil pp nil pfl nil plk nil redo T) (princ "\n취소했습니다 — 돌릴 변을 다시 누르세요."))
            ((= buf "") (setq go nil))
            ((wcmatch buf "*#*")
             (setq tang (rr:typed-ang (atof buf)) tgt (rr:dir-target tang) stage 2 buf "" redo T)
             (princ (strcat "\n기준 방향 " (rr:deg-dir tang) "."))
             (rr:no-line tgt att))
            (t (setq buf "" redo T) (princ "\n[주의] 각도를 숫자로 넣으세요."))))
         ((/= buf "") nil)
         ((= ch "S")
          (setq hl (rr:hilite nil hl) pe nil pp nil pfl nil plk nil)
          (redraw)
          (princ "\n함께 돌릴 객체를 고르세요 (Enter = 누른 변의 객체만): ")
          (setq ss (ssget "_:L") sel (if ss (rr:ss->list ss)) redo T)
          (princ (if sel (strcat "\n객체 " (itoa (length sel)) "개를 함께 돌립니다.") "\n누른 변의 객체만 돌립니다.")))
         ((= ch "P")
          (setq pivot (rr:ask-pivot pivot) redo T pfl nil plk nil)
          (setenv "HyRrPivot" pivot)
          (princ (strcat "\n회전 중심: " (rr:pivot-name pivot) ".")))
         ((= ch "A")
          (setq att (not att) redo T)
          (setenv "HyRrAttach" (if att "1" "0"))
          (princ (if att
                   "\n[알림] 돌린 뒤 기준 변에 붙입니다 — 객체가 있는 쪽에 남게 (직각이면 누른 쪽 끝을)."
                   "\n[알림] 돌리기만 합니다 (붙이지 않음)."))
          (rr:no-line tgt att)
          (cond
            ;; 누른 뒤: 돌아갈 자리를 다시 — 쪽은 커서 자리로 다시 고름 (붙이면 기본 쪽 = 있던 쪽)
            (pe (setq pfl nil plk nil))
            ;; 방금 돌린 것도 (2단계에서) — 붙일 때는 뒤집음을 풀고 있던 쪽에 (돌리기만 할 때 고른 방향은
            ;; 기준 줄의 쪽이 아니라서), 뗄 때는 뒤집음 그대로
            ((and (= stage 2) hist (nth 9 (car hist)) (not (eq att (nth 11 (car hist)))))
             (setq ent (car hist)
                   k (if att nil (nth 5 ent))
                   hist (cons (rr:redo ent (rr:redo-ang ent (nth 10 ent) att k) k (nth 10 ent) att) (cdr hist)))
             (princ (if att "\n방금 돌린 것도 붙였습니다." "\n방금 붙인 것을 뗐습니다.")))))
         ((and (= stage 1) (member ch '("H" "V")))
          (setq tang (+ (rr:ucs-ang) (if (= ch "V") (/ pi 2.0) 0.0)) tgt (rr:dir-target tang) stage 2 redo T)
          (princ (strcat "\n기준 방향 " (if (= ch "V") "수직" "수평") " (" (rr:deg-dir tang) ")."))
          (rr:no-line tgt att))
         ((= ch "U")
          (cond
            (pe (setq pe nil pp nil pfl nil plk nil) (princ "\n취소했습니다 — 돌릴 변을 다시 누르세요."))
            (hist
             (rr:undo (car hist))
             (setq hist (cdr hist))
             (princ "\n한 번 되돌렸습니다."))
            (t (princ "\n되돌릴 것이 없습니다.")))
          (setq redo T))
         ((and (= stage 2) (= ch "F"))
          (cond
            ;; 누른 뒤: 돌아갈 자리를 반대쪽으로 — F 로 정하면 커서를 비켜도 그대로
            (pe
             (setq pfl (not pfl) plk T)
             (princ (if pfl
                      "\n[알림] 반대쪽으로 정했습니다 — 누르면 그쪽으로 돕니다 (커서를 비켜도 그대로, F = 기본 쪽)."
                      "\n[알림] 기본 쪽으로 정했습니다 — 누르면 그쪽으로 돕니다.")))
            (hist
             (setq ent (car hist)
                   ent (rr:redo ent (+ (nth 2 ent) pi) (not (nth 5 ent)) (nth 10 ent) (nth 11 ent))
                   hist (cons ent (cdr hist)))
             (princ (if (nth 6 ent) "\n180° 더 돌려 반대쪽에 붙였습니다." "\n180° 더 돌렸습니다.")))
            (t (princ "\n뒤집을 것이 없습니다 — 돌릴 변을 누른 뒤 F 를 누르거나 커서를 변 옆으로 비키면 돌아갈 자리가 반대쪽으로 바뀝니다.")))
          (setq redo T))
         ((and (= stage 2) (= ch "R"))
          (setq perp (not perp) redo T)
          (princ (if perp "\n[알림] 기준 변과 직각으로 맞춥니다." "\n[알림] 기준 변과 나란히 맞춥니다."))
          (cond
            ;; 누른 뒤: 돌아갈 자리를 다시 — 쪽은 커서 자리로 다시 고름
            (pe (setq pfl nil plk nil))
            ;; 방금 돌린 것도 다시 맞춤 (뒤집기 · 붙이기는 그대로)
            (hist
             (setq ent (car hist)
                   hist (cons (rr:redo ent (rr:redo-ang ent perp (nth 11 ent) (nth 5 ent)) (nth 5 ent) perp (nth 11 ent))
                              (cdr hist))))))
         ((and (= stage 2) (= ch "T"))
          (setq stage 1 tgt nil pe nil pp nil pfl nil plk nil redo T)))))
    ;; 무언가 바뀌었으면 지금 커서 자리로 다시 그림
    (if (and go redo)
      (progn
        (setq redo nil)
        (if pe
          ;; 누른 뒤: 계획을 다시 (붙이기 · 직각 · 회전 중심이 바뀌었을 수 있음) — 쪽은 커서 자리로 (F 로 정했으면 그대로)
          (progn
            (setq pp (rr:plan pe tgt tang perp pivot sel att pfl))
            (if (not (eq (setq nf (rr:pick-fl pe pp pfl plk cur px)) pfl))
              (setq pfl nf pp (rr:plan pe tgt tang perp pivot sel att pfl)))
            (setq r (rr:paint-pick pe pp tgt sel pal hl px) vs (car r) hl (cadr r) hk nil)
            ;; 처음 돌릴 변을 누를 때 한 번: 돌아갈 쪽 고르기 알림
            (if (not told)
              (progn
                (setq told T)
                (princ (strcat "\n[알림] 돌아갈 자리를 점선으로 보입니다 — 커서를 변 옆으로 비키면 객체가 그쪽으로 가는 자리로 "
                               "바뀌고, 누르면 그 자리로 돕니다 (같은 자리에서 한 번 더 = 기본 쪽 · Enter = 취소).")))))
          (setq ed (rr:edge-at cur)
                r (rr:paint ed tgt stage tang perp pivot sel att pal hl px)
                hk (caddr r) vs (cadddr r) hl (nth 4 r)))
        (rr:prompt stage sel perp att pe))))

  (setq hl (rr:hilite nil hl))
  (redraw)
  (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
  (setq k (rr:count (vl-remove-if '(lambda (h) (null (nth 6 h))) hist)))
  (princ (cond
           ((null hist) "\n돌린 객체가 없습니다.")
           ((= k 0) (strcat "\n[완료] 객체 " (itoa (rr:count hist)) "개를 돌렸습니다."))
           ((= k (rr:count hist)) (strcat "\n[완료] 객체 " (itoa k) "개를 돌려 기준 변에 붙였습니다."))
           (t (strcat "\n[완료] 객체 " (itoa (rr:count hist)) "개를 돌렸습니다 (그중 " (itoa k) "개는 기준 변에 붙임)."))))
  (princ))

(princ)
