;;; ==============================================================================
;;;  AA — 면적 산출
;;;
;;;  닫힌 영역 안쪽을 클릭할 때마다 경계를 찾아 면적(m2)을 글자로 적는다 (Enter = 끝).
;;;   · 틈 허용(기본 50mm)만큼 끊긴 곳은 닫힌 것으로 본다 — 끝나면 HPGAPTOL 을 원래대로
;;;   · 섬 빼기(기본 끔): 켜면 영역 안의 닫힌 도형(기둥 등)을 뺀다. 가구·집기 블록도 섬으로 잡히니 주의
;;;   · 글자는 영역 무게중심에 (영역 밖이면 클릭한 점에), 지금 레이어 · 지금 글자 스타일
;;;   · 도면 단위(INSUNITS)가 m · cm 여도 맞게 환산
;;;  옵션 [섬 빼기(I)/글자 높이(H)/틈(G)] 은 기억한다. 클릭 하나 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 단위 → (m2 환산 · 기본 틈 · 기본 글자 높이)
(defun aa:units ( / u)
  (setq u (getvar "INSUNITS"))
  (cond ((= u 6) '(1.0 0.05 0.3)) ((= u 5) '(1e-4 5.0 30.0)) (T '(1e-6 50.0 300.0))))

;; 점 p(UCS) 둘레 경계 → 새로 생긴 폴리선들 (넓은 것부터) / 없으면 nil
(defun aa:bound (p gap islands / e0 e out old)
  (setq e0 (entlast) old (getvar "HPGAPTOL"))
  (setvar "HPGAPTOL" gap)
  (command "_.-BOUNDARY" "_A" "_B" "_E" "_I" (if islands "_Y" "_N") "_O" "_P" "" "_non" p "")
  (setvar "HPGAPTOL" old)
  (setq e (if e0 (entnext e0) (entnext)))
  (while e
    (if (wcmatch (cdr (assoc 0 (entget e))) "*POLYLINE") (setq out (cons e out)))
    (setq e (entnext e)))
  (vl-sort out '(lambda (a b) (> (vla-get-Area (vlax-ename->vla-object a)) (vla-get-Area (vlax-ename->vla-object b))))))

;; 폴리선 꼭짓점(WCS) 목록
(defun aa:verts (e / o n i out)
  (setq o (vlax-ename->vla-object e) n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
  (while (< i n) (setq out (cons (vlax-curve-getPointAtParam o i) out) i (1+ i)))
  (reverse out))

;; 다각형 넓이 무게중심 (x y 넓이)
(defun aa:centroid (pts / a cx cy p q k)
  (setq a 0.0 cx 0.0 cy 0.0)
  (mapcar '(lambda (p q)
             (setq k (- (* (car p) (cadr q)) (* (car q) (cadr p)))
                   a (+ a k) cx (+ cx (* (+ (car p) (car q)) k)) cy (+ cy (* (+ (cadr p) (cadr q)) k))))
          pts (append (cdr pts) (list (car pts))))
  (if (> (abs a) 1e-12) (list (/ cx (* 3.0 a)) (/ cy (* 3.0 a)) (abs (/ a 2.0)))))

(defun aa:inside (p poly / c n i a b)
  (setq c nil n (length poly) i 0)
  (while (< i n)
    (setq a (nth i poly) b (nth (rem (1+ i) n) poly))
    (if (and (/= (> (cadr a) (cadr p)) (> (cadr b) (cadr p)))
             (< (car p) (+ (car a) (/ (* (- (cadr p) (cadr a)) (- (car b) (car a))) (- (cadr b) (cadr a))))))
      (setq c (not c)))
    (setq i (1+ i)))
  c)

;; 소수 둘째 자리까지 늘 두 자리로 (DIMZIN 과 상관없이)
(defun aa:s2 (x / s k)
  (setq s (rtos x 2 2) k (vl-string-search "." s))
  (cond ((null k) (strcat s ".00")) ((= (- (strlen s) k) 2) (strcat s "0")) (s)))

(defun aa:text (s p h / nrm q)
  (setq nrm (trans '(0.0 0.0 1.0) 1 0 T) q (trans p 1 nrm))
  (entmake (list '(0 . "TEXT") (cons 10 q) (cons 11 q) (cons 40 h) (cons 1 s) (cons 7 (getvar "TEXTSTYLE"))
                 (cons 50 (angle '(0.0 0.0 0.0) (trans '(1.0 0.0 0.0) 1 nrm T))) '(72 . 1) '(73 . 2) (cons 210 nrm))))

(defun c:AA ( / *error* doc sv undo_open un pt ents outer isl area c c0 ok tp v)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO" "HPGAPTOL"))
        un (aa:units))
  (setvar "CMDECHO" 0)
  (if (null *aa_gap*) (setq *aa_gap* (cadr un)))
  (if (null *aa_h*) (setq *aa_h* (caddr un)))
  (while
    (progn
      (initget "I H G")
      (setq pt (getpoint (strcat "\n면적을 잴 곳의 안쪽을 클릭하세요 [섬 빼기(I) " (if *aa_isl* "켬" "끔")
                                 "/글자 높이(H) " (rtos *aa_h* 2 2) "/틈(G) " (rtos *aa_gap* 2 2) "] <끝>: "))))
    (cond
      ((= pt "I") (setq *aa_isl* (not *aa_isl*)))
      ((= pt "H") (initget 6) (if (setq v (getdist (strcat "\n글자 높이 <" (rtos *aa_h* 2 2) ">: "))) (setq *aa_h* v)))
      ((= pt "G") (initget 4) (if (setq v (getdist (strcat "\n틈 허용 <" (rtos *aa_gap* 2 2) ">: "))) (setq *aa_gap* v)))
      (T
       (vla-StartUndoMark doc)
       (setq undo_open T)
       (setq ents (aa:bound pt *aa_gap* *aa_isl*))
       (if (null ents)
         (princ (strcat "\n[주의] 닫힌 경계를 찾지 못했습니다. 틈이 " (rtos *aa_gap* 2 2)
                        " 보다 크거나, 영역이 화면 밖으로 나가 있습니다."))
         (progn
           (setq outer (car ents) isl (cdr ents)
                 area (- (vla-get-Area (vlax-ename->vla-object outer))
                         (apply '+ (mapcar '(lambda (e) (vla-get-Area (vlax-ename->vla-object e))) isl)))
                 c0 (aa:centroid (aa:verts outer)) c c0)
           ;; 섬을 뺀 무게중심
           (if (and c0 isl)
             (progn
               (setq ok (- (caddr c0) (apply '+ (mapcar '(lambda (e) (caddr (aa:centroid (aa:verts e)))) isl))))
               (if (> ok 1e-9)
                 (setq c (list (/ (- (* (car c0) (caddr c0))
                                     (apply '+ (mapcar '(lambda (e / k) (setq k (aa:centroid (aa:verts e))) (* (car k) (caddr k))) isl)))
                                  ok)
                               (/ (- (* (cadr c0) (caddr c0))
                                     (apply '+ (mapcar '(lambda (e / k) (setq k (aa:centroid (aa:verts e))) (* (cadr k) (caddr k))) isl)))
                                  ok))))))
           ;; 글자 자리: 무게중심이 영역 안(섬 밖)이면 거기, 아니면 클릭한 점
           (setq tp (if (and c (aa:inside c (aa:verts outer)) (not (vl-some '(lambda (e) (aa:inside c (aa:verts e))) isl)))
                      (trans (list (car c) (cadr c) (caddr (car (aa:verts outer)))) 0 1)
                      pt))
           (aa:text (strcat (aa:s2 (* area (car un))) " m2") tp *aa_h*)
           (foreach e ents (entdel e))
           (princ (strcat "\n면적: " (aa:s2 (* area (car un))) " m2" (if isl (strcat " (섬 " (itoa (length isl)) "개 뺌)") "")))))
       (vla-EndUndoMark doc)
       (setq undo_open nil))))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
