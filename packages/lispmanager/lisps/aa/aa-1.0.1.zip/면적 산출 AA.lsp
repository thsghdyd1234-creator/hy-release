(defun c:AA (/ pt e_last ent lst_objs max_obj net_region centroid txt_pt final_area old_gaptol)
  (vl-load-com)
  (setvar "CMDECHO" 0)
  
  ;; 1. 기존 설정 저장 및 틈새 허용치 50 고정
  (setq old_gaptol (getvar "HPGAPTOL"))
  (setvar "HPGAPTOL" 50.0)
  
  (princ "\n[AA 면적 산출] (문자 높이 300 / 50mm 이하 틈 무시) 영역 내부를 클릭하세요.")
  
  (if (setq pt (getpoint "\n내부 점 클릭: "))
    (progn
      (setq e_last (entlast))
      
      ;; 2. BOUNDARY 실행 (50mm 이하의 틈새는 닫힌 것으로 간주)
      (command "._-BOUNDARY" pt "")
      
      (setq lst_objs nil)
      (setq ent (entnext e_last))
      
      (while ent
        (if (wcmatch (cdr (assoc 0 (entget ent))) "*POLYLINE")
          (setq lst_objs (cons (vlax-ename->vla-object ent) lst_objs))
        )
        (setq ent (entnext ent))
      )
      
      (if lst_objs
        (progn
          ;; 3. VLA 객체로 면적 및 기하학적 중심(Centroid) 계산
          (setq regions (vlax-invoke (vla-get-modelspace (vla-get-activedocument (vlax-get-acad-object))) "AddRegion" lst_objs))
          
          (setq max_obj (car regions))
          (setq max_area (vla-get-area max_obj))
          (foreach reg (cdr regions)
            (if (> (vla-get-area reg) max_area)
              (setq max_area (vla-get-area reg) max_obj reg)
            )
          )
          
          (setq net_region max_obj)
          (foreach reg regions
            (if (not (eq reg net_region))
              (vla-boolean net_region acSubtraction reg)
            )
          )
          
          (setq centroid (vlax-safearray->list (vlax-variant-value (vla-get-centroid net_region))))
          (setq txt_pt (list (car centroid) (cadr centroid) 0.0))
          (setq final_area (vla-get-area net_region))
          
          ;; 4. 텍스트 생성 (m2 단위, 정중앙 정렬, 높이 300 고정)
          (entmake (list '(0 . "TEXT")
                         (cons 10 txt_pt)
                         (cons 11 txt_pt)
                         (cons 40 300.0)  ; 문자 높이 300
                         (cons 72 1)
                         (cons 73 2)
                         (cons 1 (strcat (rtos (/ final_area 1000000.0) 2 2) " m2"))
                   )
          )
          
          ;; 5. 계산용 임시 객체 삭제
          (vla-delete net_region)
          (foreach obj lst_objs (vla-delete obj))
          (princ (strcat "\n면적: " (rtos (/ final_area 1000000.0) 2 2) " m2"))
        )
        (princ "\n[오류] 영역을 형성할 수 없습니다. 틈새가 50mm보다 크거나 객체가 화면을 벗어났습니다.")
      )
    )
  )
  
  ;; 6. 작업 종료 후 원래 틈새 허용치로 복구
  (setvar "HPGAPTOL" old_gaptol)
  (setvar "CMDECHO" 1)
  (princ)
)