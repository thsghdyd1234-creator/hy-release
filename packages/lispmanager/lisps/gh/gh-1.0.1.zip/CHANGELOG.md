## 1.0.1 — 2026-10-25
- GH를 쓰고 나서 Y(Y·GN)를 쓰면 Y가 인수 개수 오류(too many arguments)로 멈추던 문제 고침 — GH 안의 보조 함수 이름이 Y·GN과 같아서(WUX-acos · trp-get-miter-points) GH가 실행될 때 Y의 것을 덮어썼다. 이름을 GH:acos · GH:miter-points 로 바꾸고 GH 안에서만 쓰게 함

## 1.0.0 — 2026-10-25
- 리습매니저 1.0의 리습 목록에서 옮김 (첫 등록)
