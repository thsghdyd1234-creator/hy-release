;;; ==============================================================================
;;;  GH — 예전 방식 (1.5 그대로 — 1.8.0~ 다시 GH): 두께 하나를 묻고 고른 중심선(선·호·폴리선·스플라인)마다 띠를 만들어 합침. 맨 아래 'GH — 예전 방식'.
;;;
;;;  GHS — 벽 뼈대(선·호·폴리선·스플라인·원)로 이중선 벽체를 한 번에 — 외벽 · 내벽 두께 · 외벽 기준선 (1.6.0~ GH, 1.8.0~ GHS)
;;;
;;;  뼈대를 고르면 방(닫힌 칸)을 찾아 방의 둘레는 외벽, 방과 방 사이는 내벽, 방이 아닌 곳의 선은 따로 선 벽(내벽 두께)으로 판정해 미리 보여 준다.
;;;   · 외벽 기준: 그린 선 = 벽 가운데(C) · 벽 바깥 면(O) · 벽 안쪽 면(I). 바깥면 · 안쪽면이면 외벽 중심선을 반 두께만큼 옮기고, 모서리 · 칸막이 끝이 따라간다.
;;;   · 미리보기(도면은 그대로): 벽 외곽 흰색 · 외벽 파랑 · 내벽 주황 · 따로 선 벽 초록 · 직접 정한 선 하늘 · 노랑 · 판정이 바뀐 선 빨강 · 옮긴 중심선 회색 · 중정 × · 열린 끝 ○.
;;;   · 고치기: 선을 누르면 외벽 ↔ 내벽 (다시 누르면 자동 판정), 방 안을 누르면 중정 (둘레가 외벽 — 다시 누르면 방),
;;;     T 외벽 두께 · N 내벽 두께 · J 외벽 기준 · L 레이어 · U 되돌리기 → Enter 로 만든다. 미리보기에서 ESC 면 아무것도 바뀌지 않는다.
;;;     두께 · 기준은 기억한다 (HyGhExtThick · HyGhIntThick · HyGhExtJust — 처음엔 GH 1.5 의 한 두께 HyGhThick).
;;;   · 끝이 조금 떨어진 선(두께의 1/4 안)은 이어 본다 — 두 곧은 선이면 늘여 만나는 모서리로.
;;;   · 만들면 그린 선을 벽 중심선 자리로 옮겨 쓴다 (선 · 호 · 원 · 폴리선은 그 객체 그대로, 스플라인 · 2D 폴리선 · 뒤집힌 호는 폴리선으로 바꿔 쓰고,
;;;     한 선이 외벽 · 내벽으로 갈리면 나눔). 중심선마다 값을 남겨(XDATA HY_SKEL — 종류 · 기준 · 두께 · 직접 정한 것 · 중정 씨앗 · 쓴 자리 · 그린 자리)
;;;     같은 뼈대를 다시 고르면 지난 값으로 시작하고 두 번 옮기지 않는다. 판정이 바뀐 선(증축으로 외벽이 안이 되는 등)은 빨강으로 보이고 Enter 로 새 값.
;;;     다시 고르면 처음 그린 자리(그린 뼈대)에서 다시 셈 — 같은 값이면 하나도 안 옮기고, 두께 · 기준을 바꾸면 처음부터 그 값으로 그린 것과 같다
;;;     (오목 모서리 · 중정 둘레도). 쓴 자리(1011 — 옮기기 · 돌리기 · 복사 · 신축에 같이 옮겨짐)가 지금 모양과 같으면 그린 자리 그대로, 그립으로 꼭짓점만
;;;     고쳤으면 그 꼭짓점만 고친 자리에서, 꼭짓점 수가 바뀌었으면 지금 자리에서 지난 값만큼 되돌려 셈 ('모양을 고친 선 n개' 알림).
;;;   · 벽: 선마다 두께만큼 띠를 만들어 끝끼리 만나는 곳(L자)은 마이터로(두께가 다르면 두 면 선이 만나는 점), 혼자 끝·T자는 평평하게,
;;;     세 갈래 이상은 가장 두꺼운 둘(셋째보다 두꺼울 때 — 보통 외벽 둘)을 마이터로 · 나머지는 평평하게 끝낸 뒤 띠를 모두 합쳐 폴리선으로 (1.6.1~ —
;;;     외벽 모서리에 칸막이 · 담장이 붙어도 모서리가 막힘). 오목 모서리를 칸막이가 나눠도 외벽 둘은 모서리를 돌아 이어지고 칸막이는 거기에 T자. YGN CAD 벽 그리기(HYWALL · 뼈대로 한 번에)와 같은 계산
;;;     (대조: cad/tests-core wall_build_cases.json ← tests/gh_cases.py · wall_skel_cases.json ← tests/gh_skel_cases.py — 한쪽을 고치면 다른 쪽도).
;;;   · 결과는 벽 레이어 · ByLayer, 지금 공간에. 고른 중심선은 중심선 레이어로 — YGN CAD 레이어 이름표(벽 · 벽 중심선)를 따르고, 없으면 도면층 색상표대로 3_WALL · 1_CEN.
;;;     없는 레이어는 색상표 색 · 선종류로 만든다 (3_WALL 색 3 · 1_CEN 색 1 CENTER — 연구실 CTB 로 뽑으면 그 두께). 있는 레이어는 그대로.
;;;     L 로 바꿈 (* = 벽은 지금 레이어 · 중심선은 안 옮김, . = 처음 이름 — 기억). 축선(그리드) · Y·GN 중심선 · 잠긴 레이어의 선은 레이어를 안 옮긴다.
;;;   · 잠긴 레이어의 선도 잠깐 풀어 옮기고 다시 잠근다. 길이 0 인 선 · 3D 폴리선 · 메시 · YGN CAD 로 연결한 중심선 · Y·GN 중심선은 건너뛴다.
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;;
;;;   · 같은 벽으로 다시 (1.7.0~): 만든 벽 · 중심선에 뼈대 묶음 번호를 남긴다 (중심선 HY_SKEL "g:번호" · 벽 HY_SKELW). 다시 GHS 하면 고른 선에 닿는
;;;     지난 중심선(새 선 끝이 지난 벽 안이어도) · 같은 묶음 · 같은 연결을 모두 같이 다시 셈하고, 지난 벽은 지우고 한 벽으로 다시 만든다.
;;;     지난 벽 = 묶음 표시가 있는 벽 + 표시 없는 벽 레이어 선 중 지난 중심선(쓴 자리 · 두께)의 벽 띠 테두리 위에만 놓인 것 (1.6 이하 벽 · 문으로 잘린 조각).
;;;     새 선 끝이 지난 벽 안(중심선에서 반 두께 안)이면 지난 중심선까지 늘이거나 줄여 T자로. 벽만 골라도 그 벽의 중심선으로 다시.
;;;     GHS 로 골라도 GHL 연결이 든 덩어리는 연결 그대로. YGN CAD 로 연결한 벽은 YGN CAD 가 맡음 (닿으면 알림).
;;;
;;;   · 기존 벽선과 맞물림 (1.9.0~ — GH · GHS, GHL 은 아님): 새 벽이 연결 · 기록 없는 벽 레이어의 이중선 벽(GH 로 만든 뒤 분해하고 중심선을 지운 벽 등)에
;;;     닿거나 지나가면 한 벽처럼 정리한다 — 닿은 끝(T자)은 기존 면이 새 벽 폭만큼 열리고 새 벽 끝 막음이 없어지며, 지나가면(십자) 네 모서리만 남고,
;;;     기존 벽의 끝에서 이어 가면 끝 막음이 없어지고, 끝에서 꺾어 나가면 바깥 모서리까지 채운 ㄱ자가 된다. 아래 '기존 벽선과 맞물림'.
;;;
;;;  GHL — GHS 와 같은 벽(뼈대 판정)을 만들되 중심선과 '연결'해 둔다 (GH · GHS 는 연결 · 리액터 없음).
;;;   · 연결된 중심선을 옮기거나(MOVE · STRETCH · 그립) CRVE 로 곡률을 주면, 명령이 끝날 때 그 벽을 다시 만든다 (중심선마다 제 두께).
;;;   · 연결된 중심선이나 벽을 GHL 로 다시 고르면 그 연결 전체를 지난 값으로 다시 연다 — 새로 그린 선이 닿으면 같은 연결로.
;;;   · 벽을 직접 고치면(자르기 · 옮기기 · 지우기) 그 벽의 연결을 풀고 손대지 않는다 — 고친 벽은 그대로 남는다.
;;;     중심선과 벽을 같이 옮긴 것처럼 다시 만들어도 똑같으면 연결을 유지한다.
;;;   · 중심선을 모두 지우거나 타원 등이 되면 연결을 풀고 벽은 남긴다. 연결된 것을 통째로 복사하면 복사본은 따로 연결된다.
;;;   · U · REDO 는 따라가지 않는다. GH 로 골라도 연결된 중심선은 연결 그대로 (1.7.0~ — 전에는 건너뜀).
;;;  GHN — 연결 풀기(확정). 고른 것이 속한 연결만, Enter 면 도면 전체. 벽 · 중심선은 그대로 남고 연결 번호를 뼈대 묶음 번호로 남긴다 (GH 로 다시 고르면 같은 벽).
;;;  연결 표시 = XDATA HY_GHL (C|W, 연결 번호, 두께, 그 뒤 k: j: t! v — YGN CAD 연결 표시와 같은 글). 도면을 다시 열면 리습을 불러올 때 연결이 다시 켜진다.
;;; ==============================================================================

(defun GH:2d (p) (list (car p) (cadr p)))
(defun GH:acos (x)
  (cond ((>= x 1.0) 0.0) ((<= x -1.0) pi) (T (atan (sqrt (- 1.0 (* x x))) x))))

(defun GH:unit (v / l)
  (setq l (sqrt (+ (* (car v) (car v)) (* (cadr v) (cadr v)))))
  (list (/ (car v) l) (/ (cadr v) l)))

(defun GH:sweep (a b dir / d)
  (setq d (* dir (- b a)))
  (while (< d 0.0) (setq d (+ d (* 2 pi))))
  (while (>= d (* 2 pi)) (setq d (- d (* 2 pi))))
  d)

;; --- 스플라인 중심선 → 호로 이은 조각 (계산용 — 원래 스플라인은 그대로, 옮겨 쓸 때만 폴리선으로) ---
;; 구간마다 양 끝 위치·접선이 같은 두 호(바이아크)로 맞추고, 스플라인과 tol 넘게 벗어나면 반으로 나눠 다시.
;; 이웃 구간과 접선이 이어져 폴리선 중심선처럼 마디마다 매끈하게 맞물린다.
(defun GH:sp-pt (o d) (GH:2d (vlax-curve-getPointAtDist o d)))
(defun GH:sp-tan (o d) (GH:unit (GH:2d (vlax-curve-getFirstDeriv o (vlax-curve-getParamAtDist o d)))))
(defun GH:v- (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun GH:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun GH:crs (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
;; s→e 호, 시작 접선 tg 에서 정한 볼록 값
(defun GH:bul-s (s e tg / c) (setq c (GH:v- e s)) (/ (sin (/ (atan (GH:crs tg c) (GH:dot tg c)) 2.0)) (cos (/ (atan (GH:crs tg c) (GH:dot tg c)) 2.0))))
;; s→e 호, 끝 접선 tg 에서 정한 볼록 값
(defun GH:bul-e (s e tg / c) (setq c (GH:v- e s)) (/ (sin (/ (atan (GH:crs c tg) (GH:dot c tg)) 2.0)) (cos (/ (atan (GH:crs c tg) (GH:dot c tg)) 2.0))))
;; 점 p 와 호(s e bu) 사이 거리
(defun GH:d-arc (p s e bu / c L r cen a0 ap sw k)
  (setq c (GH:v- e s) L (distance s e))
  (cond
    ((< L 1e-12) (distance p s))
    ((< (abs bu) 1e-9)
     (setq k (max 0.0 (min 1.0 (/ (GH:dot (GH:v- p s) c) (* L L)))))
     (distance p (list (+ (car s) (* k (car c))) (+ (cadr s) (* k (cadr c))))))
    (T
     (setq r (/ (* L (+ 1.0 (* bu bu))) (* 4.0 (abs bu)))
           k (/ (* L (- 1.0 (* bu bu))) (* 4.0 bu))
           cen (list (+ (* 0.5 (+ (car s) (car e))) (* k (- (/ (cadr c) L))))
                     (+ (* 0.5 (+ (cadr s) (cadr e))) (* k (/ (car c) L))))
           a0 (angle cen s) ap (angle cen p) sw (* 4.0 (atan (abs bu))))
     (if (<= (GH:sweep a0 ap (if (> bu 0) 1 -1)) sw)
       (abs (- (distance p cen) r))
       (min (distance p s) (distance p e))))))
;; d0~d1 구간을 바이아크로 → ((시작점 볼록) …), 끝점은 다음 구간 시작점
(defun GH:sp-fit (o d0 d1 tol dep / p1 p2 t1 t2 v tt c dd pm b1 b2 k dm mx)
  (setq p1 (GH:sp-pt o d0) p2 (GH:sp-pt o d1) t1 (GH:sp-tan o d0) t2 (GH:sp-tan o d1)
        v (GH:v- p2 p1) tt (list (+ (car t1) (car t2)) (+ (cadr t1) (cadr t2))) c (- 1.0 (GH:dot t1 t2)))
  (setq dd (cond ((> c 1e-9) (/ (+ (- (GH:dot v tt)) (sqrt (+ (* (GH:dot v tt) (GH:dot v tt)) (* 2.0 c (GH:dot v v))))) (* 2.0 c)))
                 ((> (abs (GH:dot v t2)) 1e-12) (/ (GH:dot v v) (* 4.0 (GH:dot v t2))))))
  (if dd
    (setq pm (list (* 0.5 (+ (car p1) (* dd (car t1)) (car p2) (- (* dd (car t2)))))
                   (* 0.5 (+ (cadr p1) (* dd (cadr t1)) (cadr p2) (- (* dd (cadr t2))))))
          b1 (GH:bul-s p1 pm t1) b2 (GH:bul-e pm p2 t2)))
  (setq mx (if dd 0.0 1e99) k 1)
  (while (and dd (< k 8) (<= mx tol))
    (setq dm (GH:sp-pt o (+ d0 (* (- d1 d0) (/ k 8.0))))
          mx (max mx (min (GH:d-arc dm p1 pm b1) (GH:d-arc dm pm p2 b2)))
          k (1+ k)))
  (if (or (<= mx tol) (>= dep 10) (< (- d1 d0) (* 4.0 tol)))
    (if dd (list (list p1 b1) (list pm b2)) (list (list p1 0.0)))
    (append (GH:sp-fit o d0 (* 0.5 (+ d0 d1)) tol (1+ dep))
            (GH:sp-fit o (* 0.5 (+ d0 d1)) d1 tol (1+ dep)))))
(defun GH:ctb-rows ()
  '(("1_CEN" 1 "CENTER") ("2_CON" 2) ("3_WALL" 3) ("4_WIN" 4) ("5_ETC" 5) ("6_FUN" 6) ("7_TEXT" 7)
    ("8_HAT" 8) ("9_ELE" 9) ("10_COL" 4) ("11_DOT" 7 "DOT") ("12_GRI" 9) ("13_SHEET" 40) ("14_HID" 8 "HIDDEN")))

;; key "wall" | "wall_cen" → 레이어 이름 ("*" = 벽은 지금 레이어 · 중심선은 안 옮김).
;; GH 의 L 로 정한 것 > YGN CAD 레이어 이름표 (ygn-layer — 없으면 건너뜀) > 처음 이름 3_WALL · 1_CEN
(defun GH:lay-name (key / v x)
  (setq v (getenv (if (= key "wall") "HyGhWallLayer" "HyGhCenLayer")))
  (cond ((and v (/= v "")) v)
        ((and (setq x (vl-catch-all-apply 'ygn-layer (list key))) (not (vl-catch-all-error-p x)) (= (type x) 'STR) (/= x "")) x)
        ((= key "wall") "3_WALL")
        (T "1_CEN")))

(defun GH:lay-show (key / n)
  (setq n (GH:lay-name key))
  (cond ((/= n "*") n) ((= key "wall") "지금 레이어") (T "안 옮김")))

;; 없으면 만듦 — 이름이 색상표 줄이면 그 색 · 선종류, 아니면 벽 색 3 · 중심선 색 1 CENTER. 있으면 그대로. → 이름
(defun GH:ensure-layer (name key / row col lt)
  (if (not (tblsearch "LAYER" name))
    (progn
      (setq row (assoc (strcase name) (GH:ctb-rows))
            col (cond (row (cadr row)) ((= key "wall") 3) (T 1))
            lt (cond (row (caddr row)) ((= key "wall") nil) (T "CENTER")))
      (if (and lt (not (tblsearch "LTYPE" lt)))
        (vl-catch-all-apply 'vla-Load (list (vla-get-Linetypes (vla-get-ActiveDocument (vlax-get-acad-object))) lt
                                            (if (= (getvar "MEASUREMENT") 1) "acadiso.lin" "acad.lin"))))
      (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                     (cons 2 name) '(70 . 0) (cons 62 col) (cons 6 (if (and lt (tblsearch "LTYPE" lt)) lt "Continuous"))))))
  name)

;; 벽을 놓을 레이어 (없으면 만듦)
(defun GH:wall-layer ( / n)
  (setq n (GH:lay-name "wall"))
  (if (= n "*") (getvar "CLAYER") (GH:ensure-layer n "wall")))

(defun GH:layer-locked-p (name / l) (and (setq l (tblsearch "LAYER" name)) (= 4 (logand 4 (cdr (assoc 70 l))))))

;; 고른 중심선을 중심선 레이어로 — 축선(그리드 레이어 · YGN 축선 HY_GRID) · Y·GN 중심선 · 잠긴 레이어 · 이미 그 레이어는 그대로.
;; → (옮긴 수 잠겨서 못 옮긴 수 레이어 이름)
(defun GH:move-cens (enames / name d lay moved lk)
  (setq name (GH:lay-name "wall_cen") moved 0 lk 0)
  (if (/= name "*")
    (foreach e enames
      (if (and (setq d (entget e '("HY_GRID" "WUX_CENTER")))
               (setq lay (cdr (assoc 8 d)))
               (/= (strcase lay) (strcase name))
               (not (assoc -3 d))
               (not (wcmatch (strcase lay) "*GRID*,*_GRI*,*그리드*,*축선*,*축렬*")))
        (if (or (GH:locked-p e) (GH:layer-locked-p name))
          (setq lk (1+ lk))
          (progn
            (GH:ensure-layer name "wall_cen")
            (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Layer (list (vlax-ename->vla-object e) name))))
              (setq moved (1+ moved))))))))
  (list moved lk name))

;; (옮긴 수 잠긴 수 이름) → 알림 조각
(defun GH:cen-note (mv)
  (strcat (if (> (car mv) 0) (strcat " · 중심선 " (itoa (car mv)) "개는 " (caddr mv) " 으로") "")
          (if (> (cadr mv) 0) (strcat " · 잠긴 중심선 " (itoa (cadr mv)) "개는 그대로") "")))

;; L — 벽 · 중심선 레이어 (기억: HyGhWallLayer · HyGhCenLayer, 빈 값 = YGN CAD 이름표 · 처음 이름)
(defun GH:layer-opts ( / v)
  (foreach k '(("wall" "HyGhWallLayer" "\n벽 레이어 (* = 지금 레이어, . = 처음 이름) <")
               ("wall_cen" "HyGhCenLayer" "\n중심선을 옮길 레이어 (* = 옮기지 않음, . = 처음 이름) <"))
    (setq v (getstring T (strcat (caddr k) (GH:lay-name (car k)) ">: ")))
    (cond ((= v "") nil)
          ((= v ".") (setenv (cadr k) ""))
          ((or (= v "*") (snvalid v)) (setenv (cadr k) v))
          (T (princ "\n[주의] 레이어 이름으로 쓸 수 없는 글자가 있어 그대로 둡니다."))))
  (princ (strcat "\n[알림] 벽 " (GH:lay-show "wall") " · 중심선 " (GH:lay-show "wall_cen"))))

(defun GH:space ( / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc)))


;;; ══════════════════════════════════════════════════════════════════════════
;;;  뼈대 → 벽 (1.6.0~) — 그린 선(뼈대)을 판정해 외벽 · 내벽 · 따로 선 벽 두께와 외벽 기준(가운데 · 바깥면 · 안쪽면)으로 중심선을 옮긴다.
;;;  YGN CAD Core WallSkeleton 과 같은 셈 (대조 자료 cad/tests-core/wall_skel_cases.json ← tests/gh_skel_cases.py — 한쪽을 고치면 다른 쪽도).
;;;  뼈대 = ((조각들 닫힘? 정한종류 정한두께 정한기준 지난종류 지난기준 지난두께 그린자리?) …), 조각 = (A B 볼록), 종류 "E" "I" "F" · 기준 "C" "O" "I".
;;;  그린자리? = 조각이 그린 자리 그대로 (다시 고칠 때 기록해 둔 그린 뼈대 — 지난 값은 판정 · 유지에만). 아니면 지금 자리가 지난 값으로 옮겨 둔 중심선.
;;; ══════════════════════════════════════════════════════════════════════════

;; ── 작은 셈 ──
(defun GH:v+ (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))
(defun GH:v* (a k) (list (* (car a) k) (* (cadr a) k)))
(defun GH:vneg (a) (list (- (car a)) (- (cadr a))))
(defun GH:perp (a) (list (- (cadr a)) (car a)))
(defun GH:vlen (a) (sqrt (+ (* (car a) (car a)) (* (cadr a) (cadr a)))))
(defun GH:vunit (a / l) (setq l (GH:vlen a)) (if (< l 1e-12) (list 1.0 0.0) (list (/ (car a) l) (/ (cadr a) l))))
(defun GH:vang (a) (if (and (zerop (car a)) (zerop (cadr a))) 0.0 (atan (cadr a) (car a))))
(defun GH:pol (a r) (list (* r (cos a)) (* r (sin a))))
(defun GH:dist (a b) (GH:vlen (GH:v- a b)))
(defun GH:near (a b e) (and (<= (abs (- (car a) (car b))) e) (<= (abs (- (cadr a) (cadr b))) e)))
(defun GH:lerp (a b u) (list (+ (car a) (* (- (car b) (car a)) u)) (+ (cadr a) (* (- (cadr b) (cadr a)) u))))
(defun GH:norm0 (a) (if (< a 0.0) (+ a (* 2.0 pi)) a))
(defun GH:tan (a) (/ (sin a) (cos a)))
(defun GH:ceil (x / f) (setq f (fix x)) (if (> x f) (1+ f) f))
(defun GH:sgn (x) (cond ((> x 0) 1) ((< x 0) -1) (T 0)))
(defun GH:setnth (lst i v / k) (setq k -1) (mapcar '(lambda (x) (if (= (setq k (1+ k)) i) v x)) lst))
(defun GH:iota (n / i o) (setq i n) (while (> i 0) (setq i (1- i) o (cons i o))) o)
(defun GH:sortby (lst fn) (mapcar '(lambda (i) (nth i lst)) (vl-sort-i lst fn)))

;; 상자 (x0 y0 x1 y1)
(defun GH:box2 (a b) (list (min (car a) (car b)) (min (cadr a) (cadr b)) (max (car a) (car b)) (max (cadr a) (cadr b))))
(defun GH:box+ (bx p) (list (min (car bx) (car p)) (min (cadr bx) (cadr p)) (max (caddr bx) (car p)) (max (cadddr bx) (cadr p))))
(defun GH:box-in (bx p e)
  (and (>= (car p) (- (car bx) e)) (<= (car p) (+ (caddr bx) e)) (>= (cadr p) (- (cadr bx) e)) (<= (cadr p) (+ (cadddr bx) e))))
(defun GH:box-ov (a b e)
  (not (or (< (+ (caddr a) e) (car b)) (> (- (car a) e) (caddr b)) (< (+ (cadddr a) e) (cadr b)) (> (- (cadr a) e) (cadddr b)))))

;; ── 선 · 호 조각 (YGN CAD Core WallBuild.Seg 와 같은 셈) ──
;; (A B 볼록) → (A B 볼록 호? C R A0 Sweep 상자) — 호는 볼록 부호대로 (양수 = 반시계)
(defun GH:sg (a b bu / L sw hf c r a0 bx k an)
  (setq L (GH:dist a b))
  (if (and (> (abs bu) 1e-12) (> L 1e-12))
    (progn
      (setq sw (* 4.0 (atan bu)) hf (/ sw 2.0)
            r (/ L (* 2.0 (abs (sin hf))))
            c (GH:v+ (GH:v* (GH:v+ a b) 0.5) (GH:v* (GH:v* (GH:perp (GH:v- b a)) (/ 1.0 L)) (/ (/ L 2.0) (GH:tan hf))))
            a0 (GH:vang (GH:v- a c))
            bx (GH:box2 a b) k 0)
      (repeat 4
        (setq an (* k (/ pi 2.0)))
        (if (<= (GH:sweep a0 an (if (> sw 0) 1 -1)) (abs sw)) (setq bx (GH:box+ bx (GH:v+ c (GH:pol an r)))))
        (setq k (1+ k)))
      (list a b bu T c r a0 sw bx))
    (list a b 0.0 nil nil 0.0 0.0 0.0 (GH:box2 a b))))

(defun GH:slen (s) (if (nth 3 s) (* (nth 5 s) (abs (nth 7 s))) (GH:dist (car s) (cadr s))))
(defun GH:sat (s u) (if (nth 3 s) (GH:v+ (nth 4 s) (GH:pol (+ (nth 6 s) (* (nth 7 s) u)) (nth 5 s))) (GH:lerp (car s) (cadr s) u)))
(defun GH:stan (s u / r)
  (if (nth 3 s)
    (progn (setq r (GH:pol (+ (nth 6 s) (* (nth 7 s) u)) 1.0)) (if (> (nth 7 s) 0) (GH:perp r) (GH:vneg (GH:perp r))))
    (GH:vunit (GH:v- (cadr s) (car s)))))
;; 가장 가까운 점 → (점 자리(0~1) 거리)
(defun GH:sclose (s p / a b c l2 u q v da span disA disB)
  (setq a (car s) b (cadr s))
  (if (not (nth 3 s))
    (progn
      (setq c (GH:v- b a) l2 (GH:dot c c)
            u (if (< l2 1e-24) 0.0 (max 0.0 (min 1.0 (/ (GH:dot (GH:v- p a) c) l2))))
            q (GH:lerp a b u))
      (list q u (GH:dist q p)))
    (progn
      (setq v (GH:v- p (nth 4 s)) span (abs (nth 7 s)))
      (if (and (> (GH:vlen v) 1e-12) (<= (setq da (GH:sweep (nth 6 s) (GH:vang v) (if (> (nth 7 s) 0) 1 -1))) span))
        (progn (setq q (GH:v+ (nth 4 s) (GH:v* (GH:vunit v) (nth 5 s))))
               (list q (if (< span 1e-12) 0.0 (/ da span)) (GH:dist q p)))
        (progn (setq disA (GH:dist p a) disB (GH:dist p b))
               (if (<= disA disB) (list a 0.0 disA) (list b 1.0 disB)))))))
;; 두 조각의 선 · 원이 만나는 점 (끝없는 선 · 온 원)
(defun GH:hits (e f / r s den d a h2 u m h arc ln dir L along foot off)
  (cond
    ((and (not (nth 3 e)) (not (nth 3 f)))
     (setq r (GH:v- (cadr e) (car e)) s (GH:v- (cadr f) (car f)) den (GH:crs r s))
     (if (>= (abs den) (* 1e-12 (+ (* (GH:vlen r) (GH:vlen s)) 1e-300)))
       (list (GH:v+ (car e) (GH:v* r (/ (GH:crs (GH:v- (car f) (car e)) s) den))))))
    ((and (nth 3 e) (nth 3 f))
     (setq d (GH:dist (nth 4 e) (nth 4 f)))
     (if (not (or (< d 1e-12) (> d (+ (nth 5 e) (nth 5 f) 1e-9)) (< d (- (abs (- (nth 5 e) (nth 5 f))) 1e-9))))
       (progn
         (setq a (/ (+ (* d d) (* (nth 5 e) (nth 5 e)) (- (* (nth 5 f) (nth 5 f)))) (* 2.0 d))
               h2 (- (* (nth 5 e) (nth 5 e)) (* a a))
               u (list (/ (- (car (nth 4 f)) (car (nth 4 e))) d) (/ (- (cadr (nth 4 f)) (cadr (nth 4 e))) d))
               m (GH:v+ (nth 4 e) (GH:v* u a)))
         (if (<= h2 0.0) (list m)
           (progn (setq h (sqrt h2)) (list (GH:v+ m (GH:v* (GH:perp u) h)) (GH:v- m (GH:v* (GH:perp u) h))))))))
    (T
     (setq arc (if (nth 3 e) e f) ln (if (nth 3 e) f e) dir (GH:v- (cadr ln) (car ln)) L (GH:vlen dir))
     (if (>= L 1e-12)
       (progn
         (setq dir (list (/ (car dir) L) (/ (cadr dir) L))
               along (GH:dot (GH:v- (nth 4 arc) (car ln)) dir)
               foot (GH:v+ (car ln) (GH:v* dir along)) off (GH:dist foot (nth 4 arc)))
         (if (<= off (+ (nth 5 arc) 1e-9))
           (progn (setq h2 (- (* (nth 5 arc) (nth 5 arc)) (* off off)))
                  (if (<= h2 0.0) (list foot)
                    (progn (setq h (sqrt h2)) (list (GH:v+ foot (GH:v* dir h)) (GH:v- foot (GH:v* dir h))))))))))))

;; ── 계획: 마디 · 나눔 · 틈 (전역 *GH:k…* — GH:skel 안에서만) ──
(defun GH:kfind (n) (while (/= (nth n *GH:kA*) n) (setq n (nth n *GH:kA*))) n)
(defun GH:knear (q / k best)
  (setq k 0)
  (foreach p *GH:kN*
    (if (and (null best) (= (nth k *GH:kA*) k) (<= (GH:dist p q) *GH:ktol*)) (setq best k))
    (setq k (1+ k)))
  best)
(defun GH:kadd (q)
  (setq *GH:kN* (append *GH:kN* (list q)) *GH:kA* (append *GH:kA* (list (length *GH:kA*))))
  (1- (length *GH:kN*)))
(defun GH:knode (q / n) (if (setq n (GH:knear q)) n (GH:kadd q)))
(defun GH:kinner (i u / L) (setq L (nth 3 (nth i *GH:kP*))) (and (> (* u L) *GH:ktol*) (> (* (- 1.0 u) L) *GH:ktol*)))
(defun GH:ksplit (i u n / sp)
  (setq n (GH:kfind n) sp (nth i *GH:kS*))
  (if (not (or (= (GH:kfind (nth i *GH:k0*)) n) (= (GH:kfind (nth i *GH:k1*)) n)
               (vl-some '(lambda (x) (= (GH:kfind (cadr x)) n)) sp)))
    (setq *GH:kS* (GH:setnth *GH:kS* i (append sp (list (list u n)))))))
(defun GH:kdeg (n / d i)
  (setq d 0 i 0)
  (repeat (length *GH:kP*)
    (if (= (GH:kfind (nth i *GH:k0*)) n) (setq d (1+ d)))
    (if (= (GH:kfind (nth i *GH:k1*)) n) (setq d (1+ d)))
    (foreach x (nth i *GH:kS*) (if (= (GH:kfind (cadr x)) n) (setq d (+ d 2))))
    (setq i (1+ i)))
  d)
;; 그 마디를 끝으로 쓰는 첫 조각 번호
(defun GH:kown (n / i r)
  (setq i 0)
  (while (and (null r) (< i (length *GH:kP*)))
    (if (or (= (GH:kfind (nth i *GH:k0*)) n) (= (GH:kfind (nth i *GH:k1*)) n)) (setq r i))
    (setq i (1+ i)))
  r)
(defun GH:outdir (s st) (if st (GH:vneg (GH:stan s 0.0)) (GH:stan s 1.0)))
(defun GH:linehit (p1 d1 p2 d2 / den)
  (setq den (GH:crs d1 d2))
  (if (>= (abs den) 0.1) (GH:v+ p1 (GH:v* d1 (/ (GH:crs (GH:v- p2 p1) d2) den)))))

;; 닿았다고 보는 거리 · 틈을 이어 보는 거리 → (tol gap)
(defun GH:ktols (srcs opts / minT tol)
  (setq minT (min (car opts) (cadr opts)))
  (foreach s srcs (if (and (nth 3 s) (> (nth 3 s) 0)) (setq minT (min minT (nth 3 s)))))
  (if (not (> minT 0)) (setq minT 1.0))
  (setq tol (min 1.0 (/ (/ minT 2.0) 10.0)))
  (list tol (max tol (/ minT 4.0))))

;; 고정한 면까지 (왼쪽 +): 바깥면 = 밖 쪽 반 두께, 안쪽면 = 안 쪽 반 두께
(defun GH:anchor (j os th)
  (cond ((or (= os 0) (not (> th 0))) 0.0) ((= j "O") (/ (* os th) 2.0)) ((= j "I") (/ (* (- os) th) 2.0)) (T 0.0)))

;; 변 = (0 src 1 ax 2 t0 3 t1 4 u 5 v 6 A 7 B 8 볼록 9 호? 10 C 11 R 12 sweep 13 왼면 14 오른면 15 경계? 16 밖쪽 17 판정 18 종류 19 두께 20 기준 21 D
;;       22 NA 23 NB 24 새볼록 25 뒤집힘)
(defun GH:angout (e fwd / tv a tn)
  (if (not (nth 9 e))
    (setq tv (if fwd (GH:v- (nth 7 e) (nth 6 e)) (GH:v- (nth 6 e) (nth 7 e))))
    (setq a (GH:vang (GH:v- (if fwd (nth 6 e) (nth 7 e)) (nth 10 e)))
          tn (if (> (nth 12 e) 0) (list (- (sin a)) (cos a)) (list (sin a) (- (cos a))))
          tv (if fwd tn (GH:vneg tn))))
  (GH:norm0 (GH:vang tv)))

(defun GH:knext (h edges outs / e v tw l k)
  (setq e (nth (/ h 2) edges) v (if (= (rem h 2) 0) (nth 5 e) (nth 4 e))
        tw (if (= (rem h 2) 0) (1+ h) (1- h)) l (cdr (assoc v outs)) k (vl-position tw l))
  (nth (rem (+ (1- k) (length l)) (length l)) l))

;; 반쪽 변 위 점 (0 = 꼬리 · 1 = 머리)
(defun GH:arcpt (e fwd u) (GH:v+ (nth 10 e) (GH:pol (+ (GH:vang (GH:v- (nth 6 e) (nth 10 e))) (* (nth 12 e) (if fwd u (- 1.0 u)))) (nth 11 e))))

;; 면 → (반쪽변들 넓이 고리 상자)
(defun GH:fshape (half edges / area ring bx e fwd a b bu th L r k j)
  (setq area 0.0)
  (foreach h half
    (setq e (nth (/ h 2) edges) fwd (= (rem h 2) 0)
          a (if fwd (nth 6 e) (nth 7 e)) b (if fwd (nth 7 e) (nth 6 e))
          area (+ area (/ (GH:crs a b) 2.0))
          bu (if fwd (nth 8 e) (- (nth 8 e))))
    (if (and (nth 9 e) (> (abs bu) 1e-12))
      (progn
        (setq th (* 4.0 (atan bu)) L (GH:dist a b))
        (if (> L 1e-12) (setq r (/ L (* 2.0 (abs (sin (/ th 2.0))))) area (+ area (* (/ (* r r) 2.0) (- th (sin th))))))
        (setq k (max 2 (GH:ceil (/ (abs th) (/ pi 16.0)))) j 0)
        (repeat k (setq ring (cons (GH:arcpt e fwd (/ (float j) k)) ring) j (1+ j))))
      (setq ring (cons a ring))))
  (setq ring (reverse ring) bx (GH:box2 (car ring) (car ring)))
  (foreach q ring (setq bx (GH:box+ bx q)))
  (list half area ring bx))

;; 짝수-홀수
(defun GH:inside (ring q / c n i j a b)
  (setq n (length ring) i 0 j (1- n))
  (while (< i n)
    (setq a (nth i ring) b (nth j ring))
    (if (and (not (eq (> (cadr a) (cadr q)) (> (cadr b) (cadr q))))
             (< (car q) (+ (/ (* (- (car b) (car a)) (- (cadr q) (cadr a))) (- (cadr b) (cadr a))) (car a))))
      (setq c (not c)))
    (setq j i i (1+ i)))
  c)

;; 점이 든 가장 작은 방 (그 덩어리 것은 뺌) — 면 = (0 반쪽변 1 넓이 2 고리 3 상자 4 방? 5 덩어리 6 안? 7 중정?)
(defun GH:ksmall (faces q skip / i best ba)
  (setq i 0)
  (foreach f faces
    (if (and (nth 4 f) (/= (nth 5 f) skip) (GH:box-in (nth 3 f) q 0.0) (GH:inside (nth 2 f) q) (or (null best) (< (nth 1 f) ba)))
      (setq best i ba (nth 1 f)))
    (setq i (1+ i)))
  best)

(defun GH:cf (i comp) (while (/= (nth i comp) i) (setq i (nth i comp))) i)

;; 옮긴 선 · 원 = (된? 호? P U C R)
(defun GH:mgeo (e / u r)
  (if (not (nth 9 e))
    (progn (setq u (GH:vunit (GH:v- (nth 7 e) (nth 6 e)))) (list T nil (GH:v+ (nth 6 e) (GH:v* (GH:perp u) (nth 21 e))) u nil 0.0))
    (progn (setq r (- (nth 11 e) (* (nth 21 e) (GH:sgn (nth 12 e))))) (list (> r 1e-9) T nil nil (nth 10 e) r))))
(defun GH:mgeo-seg (g)
  (if (cadr g)
    (GH:sg (GH:v+ (nth 4 g) (list (nth 5 g) 0.0)) (GH:v+ (nth 4 g) (list 0.0 (nth 5 g))) (GH:tan (/ pi 8.0)))
    (GH:sg (nth 2 g) (GH:v+ (nth 2 g) (nth 3 g)) 0.0)))
(defun GH:mgeo-proj (g q / v l)
  (if (not (cadr g))
    (GH:v+ (nth 2 g) (GH:v* (nth 3 g) (GH:dot (GH:v- q (nth 2 g)) (nth 3 g))))
    (progn (setq v (GH:v- q (nth 4 g)) l (GH:vlen v))
           (if (< l 1e-12) (GH:v+ (nth 4 g) (list (nth 5 g) 0.0)) (GH:v+ (nth 4 g) (GH:v* (list (/ (car v) l) (/ (cadr v) l)) (nth 5 g)))))))
(defun GH:inter (g1 g2) (if (and (car g1) (car g2)) (GH:hits (GH:mgeo-seg g1) (GH:mgeo-seg g2))))
(defun GH:nearest (pts q lim / best bd d)
  (foreach x pts (setq d (GH:dist x q)) (if (and (<= d lim) (or (null bd) (< d bd))) (setq bd d best x)))
  best)

;; 한 마디의 끝들(반쪽 변 — 반시계 차례)의 옮긴 자리 → ((반쪽변 . 점) …) . 짝 못 지은 수
(defun GH:kres (ends NP edges faces faceOf tol / n eds bds secs pairOf pairs k ccw mids j found brk step stemOf i geo
                                               pos done a b lim c pa pb unp pq pr Dk Tk Ak Own)
  (setq n (length ends)
        eds (mapcar '(lambda (h) (nth (/ h 2) edges)) ends)
        bds (mapcar '(lambda (e) (nth 15 e)) eds)
        secs (mapcar '(lambda (h) (nth 6 (nth (nth h faceOf) faces))) ends)
        pairOf (mapcar '(lambda (x) -1) ends)
        unp 0 k 0)
  (repeat n
    (if (and (nth k bds) (< (nth k pairOf) 0))
      (progn
        (setq ccw (nth k secs) mids nil j k found -1 brk nil step 1)
        (while (and (< step n) (not brk))
          (setq j (if ccw (rem (1+ j) n) (rem (+ (1- j) n) n)))
          (cond ((= j k) (setq brk T))
                ((nth j bds) (setq found j brk T))
                (T (setq mids (append mids (list j)))))
          (setq step (1+ step)))
        (if (or (< found 0) (>= (nth found pairOf) 0))
          (setq unp (1+ unp))
          (setq pairOf (GH:setnth (GH:setnth pairOf k (length pairs)) found (length pairs))
                pairs (append pairs (list (list k found mids ccw)))))))
    (setq k (1+ k)))
  ;; 바깥의 따로 선 벽 끝 — 반시계로 가다 처음 만나는 경계 끝의 짝
  (setq stemOf (mapcar '(lambda (x) -1) ends) i 0)
  (foreach pr pairs (foreach m (caddr pr) (setq stemOf (GH:setnth stemOf m i))) (setq i (1+ i)))
  (setq k 0)
  (repeat n
    (if (and (not (nth k bds)) (< (nth k stemOf) 0) (= (nth 17 (nth k eds)) "F"))
      (progn
        (setq j k brk nil step 1)
        (while (and (< step n) (not brk))
          (setq j (rem (1+ j) n))
          (if (nth j bds) (progn (if (>= (nth j pairOf) 0) (setq stemOf (GH:setnth stemOf k (nth j pairOf)))) (setq brk T)))
          (setq step (1+ step)))))
    (setq k (1+ k)))
  (setq geo (mapcar 'GH:mgeo eds)
        Dk (mapcar '(lambda (e) (abs (nth 21 e))) eds)
        Tk (mapcar '(lambda (e) (nth 19 e)) eds)
        Ak (mapcar '(lambda (h e) (GH:angout e (= (rem h 2) 0))) ends eds)
        Own (mapcar '(lambda (e g) (if (and (> (abs (nth 21 e)) 1e-12) (car g)) (GH:mgeo-proj g NP) NP)) eds geo)
        pos (mapcar '(lambda (x) NP) ends)
        done (mapcar '(lambda (x) nil) ends))
  ;; 짝(외벽 둘)은 오목 모서리여도 옮긴 두 선이 만나는 점에서 ㄱ자로 — 외벽은 모서리를 돌아 이어짐 (1.6.1 — 1.6.0 은 오목 모서리를 칸막이가 나누면
  ;; 외벽 끝을 칸막이 선에서 멈춰 모서리가 벌어졌음). 칸막이는 아래에서 옮긴 외벽 선까지 T자
  (foreach pr pairs
    (setq a (car pr) b (cadr pr))
    (if (not (and (<= (nth a Dk) 1e-12) (<= (nth b Dk) 1e-12)))
      (progn
        (setq lim (+ (* 5.0 (max (nth a Dk) (nth b Dk))) tol)
              c (GH:nearest (GH:inter (nth a geo) (nth b geo)) NP lim))
        (if c
          (setq pos (GH:setnth (GH:setnth pos a c) b c))
          (progn
            (setq pa (nth a Own) pb (nth b Own))
            (if (<= (GH:dist pa pb) tol) (setq pb pa))
            (setq pos (GH:setnth (GH:setnth pos a pa) b pb))))))
    (setq done (GH:setnth (GH:setnth done a T) b T)))
  (setq k 0)
  (repeat n
    (if (not (nth k done))
      (progn
        (setq pq (nth k stemOf))
        (if (>= pq 0)
          (progn
            (setq a (car (nth pq pairs)) b (cadr (nth pq pairs)))
            (if (not (and (<= (nth a Dk) 1e-12) (<= (nth b Dk) 1e-12) (<= (nth k Dk) 1e-12)))
              (progn
                (setq lim (+ (* 3.0 (max (nth a Tk) (nth b Tk))) tol)
                      c (GH:nearest (append (vl-remove-if-not '(lambda (x) (>= (GH:dot (GH:v- x (nth a pos)) (GH:pol (nth a Ak) 1.0)) (- tol)))
                                                              (GH:inter (nth k geo) (nth a geo)))
                                            (vl-remove-if-not '(lambda (x) (>= (GH:dot (GH:v- x (nth b pos)) (GH:pol (nth b Ak) 1.0)) (- tol)))
                                                              (GH:inter (nth k geo) (nth b geo))))
                                    NP lim)
                      pos (GH:setnth pos k (cond (c) ((nth k Own))))))))
          (setq pos (GH:setnth pos k (nth k Own))))))
    (setq k (1+ k)))
  (cons (mapcar 'cons ends pos) unp))

(defun GH:skey (a b)
  (and (= (nth 18 a) (nth 18 b)) (= (nth 20 a) (nth 20 b)) (<= (abs (- (nth 19 a) (nth 19 b))) 1e-9)
       (<= (abs (- (nth 21 a) (nth 21 b))) 1e-9) (= (nth 16 a) (nth 16 b))))
(defun GH:emoved (e) (or (not (GH:near (nth 22 e) (nth 6 e) 1e-9)) (not (GH:near (nth 23 e) (nth 7 e) 1e-9))))

;; 그린 선 하나의 토막들 → 토막 = (0 src 1 종류 2 기준 3 두께 4 D 5 밖쪽 6 닫힘? 7 옮김? 8 조각들((A B 볼록) …) 9 중정씨앗 10 그린 자리 조각들)
;; 조각(part) = (0 첫변 1 끝변 2 A 3 B 4 sweep 5 호? 6 옮김? 7 변들 8 그린A 9 그린B 10 그린sweep)
(defun GH:kruns (si src es faces seeds tol / parts lp e q runs cur f l rp e0 axes dax mv sds out a0 b1 fc)
  (foreach e es
    (setq lp (last parts))
    (if (and lp (= (nth 1 (nth 1 lp)) (nth 1 e)) (GH:skey (nth 1 lp) e) (<= (GH:dist (nth 3 lp) (nth 22 e)) 1e-9))
      (setq parts (GH:setnth parts (1- (length parts))
                             (list (car lp) e (nth 2 lp) (nth 23 e) (if (nth 9 e) (+ (nth 4 lp) (* 4.0 (atan (nth 24 e)))) (nth 4 lp))
                                   (nth 5 lp) (or (nth 6 lp) (GH:emoved e)) (append (nth 7 lp) (list e))
                                   (nth 8 lp) (nth 7 e) (if (nth 9 e) (+ (nth 10 lp) (nth 12 e)) (nth 10 lp)))))
      (setq parts (append parts (list (list e e (nth 22 e) (nth 23 e) (if (nth 9 e) (* 4.0 (atan (nth 24 e))) 0.0)
                                            (nth 9 e) (GH:emoved e) (list e)
                                            (nth 6 e) (nth 7 e) (if (nth 9 e) (nth 12 e) 0.0)))))))
  (foreach q parts
    (setq cur (last runs))
    (if (and cur (GH:skey (nth 1 (last cur)) (car q)) (<= (GH:dist (nth 3 (last cur)) (nth 2 q)) 1e-9))
      (setq runs (GH:setnth runs (1- (length runs)) (append cur (list q))))
      (setq runs (append runs (list (list q))))))
  (if (and (nth 1 src) (>= (length runs) 2))
    (progn
      (setq f (car runs) l (last runs))
      (if (and (GH:skey (nth 1 (last l)) (car (car f))) (<= (GH:dist (nth 3 (last l)) (nth 2 (car f))) 1e-9))
        (setq runs (GH:setnth (cdr runs) (- (length runs) 2) (append l f))))))
  (foreach rp runs
    (setq e0 (car (car rp)) axes nil dax nil mv nil sds nil)
    (foreach q rp
      (setq axes (append axes (list (list (nth 2 q) (nth 3 q) (if (nth 5 q) (GH:tan (/ (nth 4 q) 4.0)) 0.0))))
            dax (append dax (list (list (nth 8 q) (nth 9 q) (if (nth 5 q) (GH:tan (/ (nth 10 q) 4.0)) 0.0))))
            mv (or mv (nth 6 q)))
      (foreach e (nth 7 q)
        (foreach fi (list (nth 13 e) (nth 14 e))
          (setq fc (nth fi faces))
          (if (nth 7 fc)
            (foreach s seeds
              (if (and (GH:box-in (nth 3 fc) s 0.0) (GH:inside (nth 2 fc) s) (not (vl-some '(lambda (x) (GH:near x s 1e-9)) sds)))
                (setq sds (append sds (list s)))))))))
    (setq a0 (car (car axes)) b1 (cadr (last axes)))
    (setq out (append out (list (list si (nth 18 e0) (nth 20 e0) (nth 19 e0) (nth 21 e0) (if (= (nth 18 e0) "E") (nth 16 e0) 0)
                                      (and (nth 1 src) (= (length runs) 1) (<= (GH:dist a0 b1) (max tol 1e-9))) mv axes sds dax)))))
  out)

;; 계획 → (("tol" . ) ("gap" . ) ("nodes" . ) ("edges" . ) ("faces" . ) ("runs" . ) ("snaps" . ) ("open" . ) ("seeds" . ) ("auto" . ) ("same" . ) ("flips" . ) ("unpaired" . ))
;; opts = (외벽두께 내벽두께 외벽기준 중정씨앗들)
(defun GH:skel (srcs opts / tl tol gap si ai pcs sg i j n c ca cb ia ib pa pb oi own osg st other q dir best toN toP toT toPt m d at pj psg x kp dr bd
                            edges same pts k u v t0 t1 e sw nH h fwd from outs angs left faces half guard fo faceOf fi comp a b outer f firstNode
                            seeds inL inR lf rt bdy os au s kd side th ju aN aO autoOf ks res posAll unp NA NB r2 sg2 flips runs opn deg es)
  (setq tl (GH:ktols srcs opts) tol (car tl) gap (cadr tl) *GH:ktol* tol same 0 unp 0 flips 0 *GH:ksn* nil)
  ;; 1) 조각
  (setq si 0)
  (foreach s srcs
    (setq ai 0)
    (foreach a (car s)
      (setq sg (GH:sg (car a) (cadr a) (caddr a)))
      (if (> (GH:slen sg) 1e-6) (setq pcs (cons (list si ai sg (GH:slen sg)) pcs)))
      (setq ai (1+ ai)))
    (setq si (1+ si)))
  (setq *GH:kP* (reverse pcs) *GH:kN* nil *GH:kA* nil *GH:k0* nil *GH:k1* nil *GH:kS* nil)
  ;; 2) 마디 — 끝점 먼저 (조각 차례), 가까운 것은 앞 마디로
  (foreach pc *GH:kP*
    (setq *GH:k0* (cons (GH:knode (car (caddr pc))) *GH:k0*)
          *GH:k1* (cons (GH:knode (cadr (caddr pc))) *GH:k1*)
          *GH:kS* (cons nil *GH:kS*)))
  (setq *GH:k0* (reverse *GH:k0*) *GH:k1* (reverse *GH:k1*))
  ;; 3) 다른 조각 가운데에 닿은 마디 (T자)
  (setq n 0)
  (repeat (length *GH:kN*)
    (if (= (nth n *GH:kA*) n)
      (progn
        (setq i 0)
        (foreach pc *GH:kP*
          (if (and (/= (GH:kfind (nth i *GH:k0*)) n) (/= (GH:kfind (nth i *GH:k1*)) n) (GH:box-in (nth 8 (caddr pc)) (nth n *GH:kN*) tol))
            (progn
              (setq c (GH:sclose (caddr pc) (nth n *GH:kN*)))
              (if (and (< (caddr c) tol) (GH:kinner i (cadr c))) (GH:ksplit i (cadr c) n))))
          (setq i (1+ i)))))
    (setq n (1+ n)))
  ;; 4) 가운데끼리 엇갈림 (십자)
  (setq i 0)
  (repeat (length *GH:kP*)
    (setq pa (nth i *GH:kP*) j (1+ i))
    (repeat (- (length *GH:kP*) i 1)
      (setq pb (nth j *GH:kP*))
      (if (GH:box-ov (nth 8 (caddr pa)) (nth 8 (caddr pb)) tol)
        (foreach hh (GH:hits (caddr pa) (caddr pb))
          (setq ca (GH:sclose (caddr pa) hh) cb (GH:sclose (caddr pb) hh))
          (if (and (< (caddr ca) tol) (< (caddr cb) tol))
            (progn
              (setq ia (GH:kinner i (cadr ca)) ib (GH:kinner j (cadr cb)))
              (if (or ia ib)
                (progn
                  (setq n (GH:kfind (GH:knode hh)))
                  (if ia (GH:ksplit i (cadr ca) n))
                  (if ib (GH:ksplit j (cadr cb) n))))))))
      (setq j (1+ j)))
    (setq i (1+ i)))
  ;; 5) 혼자 끝난 끝 → gap 안의 마디 · 선으로 이어 봄 (마디 번호 차례)
  (if (> gap tol)
    (progn
      (setq n 0)
      (repeat (length *GH:kN*)
        (if (and (= (nth n *GH:kA*) n) (= (GH:kdeg n) 1))
          (progn
            (setq oi (GH:kown n) own (nth oi *GH:kP*) osg (caddr own)
                  st (= (GH:kfind (nth oi *GH:k0*)) n)
                  other (if st (GH:kfind (nth oi *GH:k1*)) (GH:kfind (nth oi *GH:k0*)))
                  q (nth n *GH:kN*) dir (GH:outdir osg st)
                  best 1e300 toN nil toP nil toT 0.0 toPt q m 0)
            (foreach pm *GH:kN*
              (if (and (= (nth m *GH:kA*) m) (/= m n) (/= m other))
                (progn (setq d (GH:dist pm q))
                       (if (and (<= d gap) (< d best)) (setq best d toN m toP nil toPt pm))))
              (setq m (1+ m)))
            (setq j 0)
            (foreach pc *GH:kP*
              (if (and (/= j oi) (GH:box-in (nth 8 (caddr pc)) q gap))
                (progn
                  (setq c (GH:sclose (caddr pc) q))
                  (if (and (<= (caddr c) gap) (GH:kinner j (cadr c)) (< (caddr c) (- best 1e-12)))
                    (setq best (caddr c) toN nil toP j toT (cadr c) toPt (car c)))))
              (setq j (1+ j)))
            (cond
              (toN
               (setq at (nth toN *GH:kN*))
               ;; 혼자 끝난 끝끼리 — 두 곧은 선이 엇갈리면 늘여 만나는 모서리로 (둘 다 옮김)
               (if (and (not (nth 3 osg)) (= (GH:kdeg toN) 1))
                 (progn
                   (setq pj (GH:kown toN) psg (caddr (nth pj *GH:kP*)))
                   (if (and (not (nth 3 psg))
                            (setq x (GH:linehit q dir at (GH:outdir psg (= (GH:kfind (nth pj *GH:k0*)) toN))))
                            (<= (GH:dist x q) (* 2.0 gap)) (<= (GH:dist x at) (* 2.0 gap)))
                     (setq at x))))
               (if (not (GH:near q at 1e-12)) (setq *GH:ksn* (cons (list q at) *GH:ksn*)))
               (if (not (GH:near (nth toN *GH:kN*) at 1e-12)) (setq *GH:ksn* (cons (list (nth toN *GH:kN*) at) *GH:ksn*)))
               (setq kp (min n toN) dr (max n toN)
                     *GH:kN* (GH:setnth *GH:kN* kp at) *GH:kA* (GH:setnth *GH:kA* dr kp)))
              (toP
               ;; 곧은 선이면 제 방향으로 늘여 닿는 점 (gap 의 2배 안 · 그 선 가운데), 없으면 수선의 발
               (if (not (nth 3 osg))
                 (progn
                   (setq bd 1e300)
                   (foreach hh (GH:hits (GH:sg q (GH:v+ q dir) 0.0) (caddr (nth toP *GH:kP*)))
                     (if (and (>= (GH:dot (GH:v- hh q) dir) (- tol)) (<= (GH:dist hh q) (* 2.0 gap)))
                       (progn (setq c (GH:sclose (caddr (nth toP *GH:kP*)) hh))
                              (if (and (<= (caddr c) tol) (GH:kinner toP (cadr c)) (< (GH:dist hh q) bd))
                                (setq bd (GH:dist hh q) toPt hh toT (cadr c))))))))
               (setq at nil)
               (foreach x (nth toP *GH:kS*)
                 (if (and (null at) (<= (GH:dist (nth (GH:kfind (cadr x)) *GH:kN*) toPt) tol)) (setq at (GH:kfind (cadr x)))))
               (if at
                 (setq *GH:kA* (GH:setnth *GH:kA* n at))
                 (progn (setq *GH:kN* (GH:setnth *GH:kN* n toPt)) (GH:ksplit toP toT n)))
               (setq *GH:ksn* (cons (list q toPt) *GH:ksn*))))))
        (setq n (1+ n)))))
  ;; 6) 변 — 겹쳐 그린 같은 변은 하나로
  (setq i 0)
  (foreach pc *GH:kP*
    (setq sg (caddr pc)
          pts (append (list (list 0.0 (GH:kfind (nth i *GH:k0*))))
                      (mapcar '(lambda (x) (list (car x) (GH:kfind (cadr x)))) (GH:sortby (nth i *GH:kS*) '(lambda (a b) (< (car a) (car b)))))
                      (list (list 1.0 (GH:kfind (nth i *GH:k1*)))))
          k 0)
    (repeat (1- (length pts))
      (setq u (cadr (nth k pts)) v (cadr (nth (1+ k) pts)))
      (if (/= u v)
        (progn
          (setq t0 (car (nth k pts)) t1 (car (nth (1+ k) pts)))
          (if (nth 3 sg)
            (setq sw (* (nth 7 sg) (- t1 t0))
                  e (list (car pc) (cadr pc) t0 t1 u v (nth u *GH:kN*) (nth v *GH:kN*) (GH:tan (/ sw 4.0)) T (nth 4 sg) (nth 5 sg) sw))
            (setq e (list (car pc) (cadr pc) t0 t1 u v (nth u *GH:kN*) (nth v *GH:kN*) 0.0 nil nil 0.0 0.0)))
          (if (vl-some '(lambda (f) (or (and (= (nth 4 f) u) (= (nth 5 f) v) (< (abs (- (nth 8 f) (nth 8 e))) 1e-6))
                                        (and (= (nth 4 f) v) (= (nth 5 f) u) (< (abs (+ (nth 8 f) (nth 8 e))) 1e-6))))
                       edges)
            (setq same (1+ same))
            (setq edges (append edges (list e))))))
      (setq k (1+ k)))
    (setq i (1+ i)))
  (if edges
    (progn
      ;; 7) 반쪽 변 · 면
      (setq nH (* 2 (length edges)) h 0)
      (repeat nH
        (setq e (nth (/ h 2) edges) fwd (= (rem h 2) 0)
              angs (cons (GH:angout e fwd) angs)
              from (if fwd (nth 4 e) (nth 5 e)))
        (if (setq x (assoc from outs))
          (setq outs (subst (cons from (append (cdr x) (list h))) x outs))
          (setq outs (cons (list from h) outs)))
        (setq h (1+ h)))
      (setq angs (reverse angs) outs (reverse outs))
      (setq outs (mapcar '(lambda (x) (cons (car x) (GH:sortby (cdr x) '(lambda (a b) (or (< (nth a angs) (nth b angs)) (and (= (nth a angs) (nth b angs)) (< a b)))))))
                         outs))
      (setq left (GH:iota nH) fi 0)
      (while left
        (setq h (car left) half nil guard 0)
        (while (and (member h left) (<= guard nH))
          (setq half (cons h half) left (vl-remove h left) h (GH:knext h edges outs) guard (1+ guard)))
        (setq half (reverse half) faces (cons half faces) fo (append fo (mapcar '(lambda (x) (cons x fi)) half)) fi (1+ fi)))
      (setq faces (mapcar '(lambda (hl) (GH:fshape hl edges)) (reverse faces))
            faceOf (mapcar 'cdr (GH:sortby fo '(lambda (a b) (< (car a) (car b))))))
      ;; 8) 덩어리 · 바깥 고리
      (setq comp (GH:iota (length *GH:kN*)))
      (foreach e edges
        (setq a (GH:cf (nth 4 e) comp) b (GH:cf (nth 5 e) comp))
        (if (/= a b) (setq comp (GH:setnth comp (max a b) (min a b)))))
      (setq faces (mapcar '(lambda (f / e0) (setq e0 (nth (/ (car (car f)) 2) edges))
                             (append f (list nil (GH:cf (if (= (rem (car (car f)) 2) 0) (nth 4 e0) (nth 5 e0)) comp))))
                          faces)
            i 0)
      (foreach f faces
        (if (or (null (setq x (assoc (nth 5 f) outer))) (< (nth 1 f) (- (nth 1 (nth (cdr x) faces)) 1e-9)))
          (setq outer (if x (subst (cons (nth 5 f) i) x outer) (append outer (list (cons (nth 5 f) i))))))
        (setq i (1+ i)))
      ;; 9) 안 · 밖 — 방은 안, 씨앗이 든 방은 중정(밖), 덩어리 바깥은 그 덩어리를 품은 방을 따름
      (setq i -1
            faces (mapcar '(lambda (f / bnd) (setq i (1+ i) bnd (/= (cdr (assoc (nth 5 f) outer)) i))
                             (list (nth 0 f) (nth 1 f) (nth 2 f) (nth 3 f) bnd (nth 5 f) bnd nil))
                          faces))
      (foreach s (cadddr opts)
        (setq fi (GH:ksmall faces s -1))
        (if (and fi (not (nth 7 (nth fi faces))))
          (setq f (nth fi faces) faces (GH:setnth faces fi (list (nth 0 f) (nth 1 f) (nth 2 f) (nth 3 f) (nth 4 f) (nth 5 f) nil T))
                seeds (append seeds (list s)))))
      (foreach e edges
        (foreach nd (list (nth 4 e) (nth 5 e))
          (setq c (GH:cf nd comp))
          (if (or (null (setq x (assoc c firstNode))) (< nd (cdr x)))
            (setq firstNode (if x (subst (cons c nd) x firstNode) (cons (cons c nd) firstNode))))))
      (foreach kv outer
        (setq x (GH:ksmall faces (nth (cdr (assoc (car kv) firstNode)) *GH:kN*) (car kv))
              f (nth (cdr kv) faces)
              faces (GH:setnth faces (cdr kv) (list (nth 0 f) (nth 1 f) (nth 2 f) (nth 3 f) (nth 4 f) (nth 5 f) (and x (nth 6 (nth x faces))) (nth 7 f)))))
      ;; 10) 변 종류 · 두께 · 기준 · 옮김
      (setq i 0)
      (setq edges
        (mapcar '(lambda (e / lf rt inL inR bdy os au s kd side th ju aN aO)
                   (setq lf (nth (* 2 i) faceOf) rt (nth (1+ (* 2 i)) faceOf)
                         inL (nth 6 (nth lf faces)) inR (nth 6 (nth rt faces)) i (1+ i))
                   (if (not (eq inL inR)) (setq bdy T os (if inL -1 1) au "E") (setq bdy nil os 0 au (if inL "I" "F")))
                   (setq s (nth (car e) srcs)
                         kd (if (and (nth 2 s) (/= (nth 2 s) "F")) (nth 2 s) au)
                         side (if (= kd "E") os 0)
                         th (if (and (nth 3 s) (> (nth 3 s) 0)) (nth 3 s) (if (= kd "E") (car opts) (cadr opts)))
                         ju (if (and (= kd "E") (/= side 0)) (cond ((nth 4 s)) ((caddr opts))) "C")
                         aN (GH:anchor ju side th)
                         aO (if (and (= (nth 5 s) "E") (not (nth 8 s))) (GH:anchor (cond ((nth 6 s)) ("C")) os (cond ((nth 7 s)) (0.0))) 0.0))
                   (append e (list lf rt bdy os au kd th ju (- aO aN))))
                edges))
      (setq si 0)
      (repeat (length srcs)
        (setq ks nil)
        (foreach e edges (if (and (= (car e) si) (not (member (nth 17 e) ks))) (setq ks (cons (nth 17 e) ks))))
        (if ks (setq autoOf (append autoOf (list (cons si (if (= (length ks) 1) (car ks)))))))
        (setq si (1+ si)))
      ;; 11) 마디마다 옮긴 자리
      (foreach kv outs
        (if (vl-some '(lambda (h) (> (abs (nth 21 (nth (/ h 2) edges))) 1e-12)) (cdr kv))
          (progn
            (setq res (GH:kres (cdr kv) (nth (car kv) *GH:kN*) edges faces faceOf tol)
                  posAll (append posAll (car res)) unp (+ unp (cdr res))))))
      (setq i 0)
      (setq edges
        (mapcar '(lambda (e / NA NB r2 sg2 sw fl nbu)
                   (setq NA (cond ((cdr (assoc (* 2 i) posAll))) ((nth 6 e))) NB (cond ((cdr (assoc (1+ (* 2 i)) posAll))) ((nth 7 e))) i (1+ i))
                   (if (not (nth 9 e))
                     (setq nbu 0.0 fl (<= (GH:dot (GH:v- NB NA) (GH:v- (nth 7 e) (nth 6 e))) 0.0))
                     (progn
                       (setq r2 (- (nth 11 e) (* (nth 21 e) (GH:sgn (nth 12 e)))))
                       (if (not (> r2 1e-9))
                         (setq fl T nbu (nth 8 e))
                         (progn
                           (setq sg2 (GH:sgn (nth 12 e))
                                 sw (* sg2 (GH:sweep (GH:vang (GH:v- NA (nth 10 e))) (GH:vang (GH:v- NB (nth 10 e))) sg2)))
                           (if (> (abs (- sw (nth 12 e))) pi) (setq fl T sw (- sw (* sg2 2.0 pi))))
                           (setq nbu (GH:tan (/ sw 4.0)))))))
                   (if fl (setq flips (1+ flips)))
                   (append e (list NA NB nbu fl)))
                edges))
      ;; 12) 그린 선마다 토막
      (setq si 0)
      (foreach s srcs
        (setq es (vl-remove-if-not '(lambda (e) (= (car e) si)) edges))
        (if es (setq runs (append runs (GH:kruns si s es faces seeds tol))))
        (setq si (1+ si)))
      ;; 13) 혼자 끝난 끝
      (foreach e edges
        (foreach nd (list (nth 4 e) (nth 5 e))
          (setq deg (if (setq x (assoc nd deg)) (subst (cons nd (1+ (cdr x))) x deg) (cons (cons nd 1) deg)))))
      (foreach kv (GH:sortby deg '(lambda (a b) (< (car a) (car b))))
        (if (= (cdr kv) 1) (setq opn (append opn (list (nth (car kv) *GH:kN*))))))))
  (setq res
    (list (cons "tol" tol) (cons "gap" gap) (cons "nodes" *GH:kN*) (cons "edges" edges) (cons "faces" faces) (cons "runs" runs)
          (cons "snaps" (reverse *GH:ksn*)) (cons "open" opn) (cons "seeds" seeds) (cons "auto" autoOf)
          (cons "same" same) (cons "flips" flips) (cons "unpaired" unp)))
  (setq *GH:kP* nil *GH:kN* nil *GH:kA* nil *GH:k0* nil *GH:k1* nil *GH:kS* nil *GH:ksn* nil)
  res)

(defun GH:pl (plan key) (cdr (assoc key plan)))

;; ── 다시 고치기 · 미리보기에서 고치는 동안 (YGN CAD Core SkelSession 과 같은 셈) ──
;; 지난 값을 그대로 둘 그린 선 — 판정이 같으면 지난 두께 · 기준 → (뼈대 판정이 바뀐 선 번호들)
(defun GH:keepold (srcs first xk xt xj / i out ch au same)
  (setq i 0)
  (foreach s srcs
    (if (nth 5 s)
      (progn
        (setq au (cdr (assoc i (GH:pl first "auto")))
              same (if (nth i xk) (= (nth 2 s) (nth 5 s)) (and au (= au (nth 5 s)))))
        (if (not same)
          (if (not (nth i xk)) (setq ch (append ch (list i))))
          (progn
            (if (and (not (nth i xt)) (null (nth 3 s)) (> (cond ((nth 7 s)) (0.0)) 0)) (setq s (GH:setnth s 3 (nth 7 s))))
            (if (and (not (nth i xj)) (null (nth 4 s)) (= (nth 5 s) "E") (nth 6 s)) (setq s (GH:setnth s 4 (nth 6 s))))))))
    (setq out (append out (list s)) i (1+ i)))
  (list out ch))

;; 다시 고칠 때 시작 값 — 지난 외벽 두께 · 내벽(따로 선 벽 포함) 두께 · 외벽 기준 중 가장 많은 것 (같으면 기본값이 든 쪽, 그다음 작은 값)
(defun GH:most (xs def / g x top best)
  (foreach v xs
    (if (> v 0)
      (if (setq x (vl-some '(lambda (y) (if (<= (abs (- (car y) v)) 1e-6) y)) g))
        (setq g (subst (list (car x) (1+ (cadr x))) x g))
        (setq g (append g (list (list v 1)))))))
  (if (null g) def
    (progn
      (setq top (apply 'max (mapcar 'cadr g)) best (mapcar 'car (vl-remove-if-not '(lambda (y) (= (cadr y) top)) g)))
      (if (vl-some '(lambda (y) (<= (abs (- y def)) 1e-6)) best) def (apply 'min best)))))
(defun GH:jrank (j) (cond ((= j "O") 1) ((= j "I") 2) (T 0)))
(defun GH:ss-most (b ext inn just / js g g2 top best)
  (setq js (mapcar '(lambda (s) (cond ((nth 6 s)) ("C"))) (vl-remove-if-not '(lambda (s) (= (nth 5 s) "E")) b)))
  (foreach j js (if (setq g2 (assoc j g)) (setq g (subst (cons j (1+ (cdr g2))) g2 g)) (setq g (append g (list (cons j 1))))))
  (if g
    (progn
      (setq top (apply 'max (mapcar 'cdr g)) best (mapcar 'car (vl-remove-if-not '(lambda (y) (= (cdr y) top)) g)))
      (if (not (member just best)) (setq just (car (GH:sortby best '(lambda (a b) (< (GH:jrank a) (GH:jrank b)))))))))
  (list (GH:most (mapcar '(lambda (s) (cond ((nth 7 s)) (0.0))) (vl-remove-if-not '(lambda (s) (= (nth 5 s) "E")) b)) ext)
        (GH:most (mapcar '(lambda (s) (cond ((nth 7 s)) (0.0))) (vl-remove-if-not '(lambda (s) (member (nth 5 s) '("I" "F"))) b)) inn)
        just))

;; 세션 — *GH:sb* 그린 선(직접 정한 값 · 지난 값) · *GH:se* *GH:si* *GH:sj* 기본값 · *GH:sv* 중정 씨앗 · *GH:skt* *GH:skj* 지난 두께 · 기준을 둘 선
;; · *GH:sp* 계획 · *GH:sc* 판정이 바뀐 선 · *GH:su* 되돌리기
(defun GH:ss-opts () (list *GH:se* *GH:si* *GH:sj* *GH:sv*))
(defun GH:ss-replan ( / first r)
  (setq first (GH:skel *GH:sb* (GH:ss-opts)))
  (if (vl-some '(lambda (s) (nth 5 s)) *GH:sb*)
    (setq r (GH:keepold *GH:sb* first (mapcar '(lambda (s) (if (nth 2 s) T)) *GH:sb*)
                        (mapcar '(lambda (s k) (or (nth 3 s) (not k))) *GH:sb* *GH:skt*)
                        (mapcar '(lambda (s k) (or (nth 4 s) (not k))) *GH:sb* *GH:skj*))
          *GH:sc* (cadr r)
          *GH:sp* (GH:skel (car r) (GH:ss-opts)))
    (setq *GH:sc* nil *GH:sp* first)))   ; 지난 값이 없으면 두 번째 계획은 첫 계획과 같음
(defun GH:ss-start (base ext inn just voids / st)
  (setq st (GH:ss-most base ext inn just)
        *GH:sb* base *GH:se* (car st) *GH:si* (cadr st) *GH:sj* (caddr st) *GH:sv* nil *GH:su* nil
        *GH:skt* (mapcar '(lambda (s) (if (nth 5 s) T)) base) *GH:skj* (mapcar '(lambda (s) (if (nth 5 s) T)) base))
  (foreach v voids (if (not (vl-some '(lambda (x) (GH:near x v 1e-6)) *GH:sv*)) (setq *GH:sv* (append *GH:sv* (list v)))))
  (GH:ss-replan))
(defun GH:ss-push ()
  (setq *GH:su* (cons (list (mapcar '(lambda (s) (nth 2 s)) *GH:sb*) *GH:sv* *GH:se* *GH:si* *GH:sj* *GH:skt* *GH:skj*) *GH:su*)))
(defun GH:ss-undo ( / u)
  (if (setq u (car *GH:su*))
    (progn
      (setq *GH:su* (cdr *GH:su*)
            *GH:sb* (mapcar '(lambda (s k) (GH:setnth s 2 k)) *GH:sb* (car u))
            *GH:sv* (nth 1 u) *GH:se* (nth 2 u) *GH:si* (nth 3 u) *GH:sj* (nth 4 u) *GH:skt* (nth 5 u) *GH:skj* (nth 6 u))
      (GH:ss-replan)
      T)))
(defun GH:ss-ext (v)
  (if (and v (> v 0))
    (progn (GH:ss-push)
           (setq *GH:se* v *GH:skt* (mapcar '(lambda (s k) (if (= (nth 5 s) "E") nil k)) *GH:sb* *GH:skt*))
           (GH:ss-replan))))
(defun GH:ss-int (v)
  (if (and v (> v 0))
    (progn (GH:ss-push)
           (setq *GH:si* v *GH:skt* (mapcar '(lambda (s k) (if (member (nth 5 s) '("I" "F")) nil k)) *GH:sb* *GH:skt*))
           (GH:ss-replan))))
(defun GH:ss-just (j)
  (GH:ss-push)
  (setq *GH:sj* j *GH:skj* (mapcar '(lambda (s k) (if (= (nth 5 s) "E") nil k)) *GH:sb* *GH:skj*))
  (GH:ss-replan))
(defun GH:elen (e) (if (nth 9 e) (abs (* (nth 11 e) (nth 12 e))) (GH:dist (nth 6 e) (nth 7 e))))
;; 그린 선 하나의 지금 종류 — 변 길이가 가장 긴 종류 (같으면 외벽 · 내벽 · 따로 선 벽 차례)
(defun GH:kindnow (src / g x best bl)
  (foreach e (GH:pl *GH:sp* "edges")
    (if (= (car e) src)
      (if (setq x (assoc (nth 18 e) g)) (setq g (subst (cons (car x) (+ (cdr x) (GH:elen e))) x g)) (setq g (cons (cons (nth 18 e) (GH:elen e)) g)))))
  (foreach k '("E" "I" "F") (if (and (setq x (assoc k g)) (or (null bl) (> (cdr x) bl))) (setq best k bl (cdr x))))
  (cond (best) ("I")))
(defun GH:kname (k) (cond ((= k "E") "외벽") ((= k "I") "내벽") (T "따로 선 벽")))
(defun GH:ss-toggle (src / b k)
  (GH:ss-push)
  (setq b (nth src *GH:sb*)
        k (if (nth 2 b) nil (if (= (GH:kindnow src) "E") "I" "E"))
        *GH:sb* (GH:setnth *GH:sb* src (GH:setnth b 2 k)))
  (GH:ss-replan)
  k)
;; 누른 점에서 tol 안의 가장 가까운 그린 선 (그린 자리)
(defun GH:srcat (plan q tol / best bd s c)
  (foreach e (GH:pl plan "edges")
    (setq s (GH:sg (nth 6 e) (nth 7 e) (nth 8 e)))
    (if (GH:box-in (nth 8 s) q tol)
      (progn (setq c (GH:sclose s q))
             (if (and (<= (caddr c) tol) (or (null bd) (< (caddr c) bd))) (setq bd (caddr c) best (car e))))))
  best)
(defun GH:ss-void (q / fs fi n)
  (setq fs (GH:pl *GH:sp* "faces"))
  (if (setq fi (GH:ksmall fs q -1))
    (progn
      (GH:ss-push)
      (setq n (length *GH:sv*) *GH:sv* (vl-remove-if '(lambda (s) (= (GH:ksmall fs s -1) fi)) *GH:sv*))
      (if (= n (length *GH:sv*)) (setq *GH:sv* (append *GH:sv* (list q))))
      (GH:ss-replan)
      T)))
;; 누르기 — 그린 선 = 종류 바꾸기, 방 안 = 중정 켜고 끄기 → 한 일 (아무것도 안 했으면 nil)
(defun GH:ss-click (q tol / src k fi was)
  (cond
    ((setq src (GH:srcat *GH:sp* q tol))
     (setq k (GH:ss-toggle src))
     (if k (strcat "이 선을 " (GH:kname k) "으로 정했습니다") (strcat "이 선을 다시 자동 판정으로 — " (GH:kname (GH:kindnow src)))))
    ((setq fi (GH:ksmall (GH:pl *GH:sp* "faces") q -1))
     (setq was (nth 7 (nth fi (GH:pl *GH:sp* "faces"))))
     (GH:ss-void q)
     (if was "중정을 풀었습니다 (방으로)" "이 방을 중정으로 — 둘레가 외벽이 됩니다"))))
;; 요약 한 줄
(defun GH:ss-summary ( / kinds i rooms courts parts)
  (setq i 0)
  (repeat (length *GH:sb*)
    (if (vl-some '(lambda (e) (= (car e) i)) (GH:pl *GH:sp* "edges")) (setq kinds (cons (GH:kindnow i) kinds)))
    (setq i (1+ i)))
  (setq rooms (length (vl-remove-if-not '(lambda (f) (nth 4 f)) (GH:pl *GH:sp* "faces")))
        courts (length (vl-remove-if-not '(lambda (f) (and (nth 4 f) (nth 7 f))) (GH:pl *GH:sp* "faces"))))
  (setq parts (list (strcat "외벽 선 " (itoa (length (vl-remove-if-not '(lambda (k) (= k "E")) kinds))))
                    (strcat "내벽 선 " (itoa (length (vl-remove-if-not '(lambda (k) (= k "I")) kinds))))))
  (if (member "F" kinds) (setq parts (append parts (list (strcat "따로 선 벽 " (itoa (length (vl-remove-if-not '(lambda (k) (= k "F")) kinds))))))))
  (setq parts (append parts (list (strcat "방 " (itoa (- rooms courts))))))
  (if (> courts 0) (setq parts (append parts (list (strcat "중정 " (itoa courts))))))
  (if *GH:sc* (setq parts (append parts (list (strcat "판정이 바뀐 선 " (itoa (length *GH:sc*)) "(빨강)")))))
  (if (GH:pl *GH:sp* "snaps") (setq parts (append parts (list (strcat "틈 이음 " (itoa (length (GH:pl *GH:sp* "snaps"))))))))
  (if (GH:pl *GH:sp* "open") (setq parts (append parts (list (strcat "열린 끝 " (itoa (length (GH:pl *GH:sp* "open"))))))))
  (GH:join parts " · "))
(defun GH:join (xs sep / o) (foreach x xs (setq o (if o (strcat o sep x) x))) (cond (o) ("")))

;;; ══════════════════════════════════════════════════════════════════════════
;;;  벽 띠 → 벽 폴리선 (조각마다 두께 — YGN CAD Core WallBuild 와 같은 끝 모양, 합치기는 캐드 영역)
;;; ══════════════════════════════════════════════════════════════════════════

;; 벽 조각 ((A B 볼록 두께) …) → 띠를 만들 조각 ((조각 반두께) …) — 두께 0 · 길이 0 은 뺌, 시계 호는 뒤집어 반시계로,
;; 똑같이 겹친 것은 하나로(두꺼운 쪽)
(defun GH:wprep (axes / out s j same)
  (foreach a axes
    (if (and (cadddr a) (> (cadddr a) 0))
      (progn
        (setq s (if (< (caddr a) 0) (GH:sg (cadr a) (car a) (- (caddr a))) (GH:sg (car a) (cadr a) (caddr a))))
        (if (> (GH:slen s) 1e-6)
          (progn
            (setq j 0 same nil)
            (foreach o out
              (if (and (null same) (< (abs (- (nth 2 (car o)) (nth 2 s))) 1e-9)
                       (or (and (GH:near (car (car o)) (car s) 1e-6) (GH:near (cadr (car o)) (cadr s) 1e-6))
                           (and (not (nth 3 (car o))) (GH:near (car (car o)) (cadr s) 1e-6) (GH:near (cadr (car o)) (car s) 1e-6))))
                (setq same j))
              (setq j (1+ j)))
            (if same
              (setq out (GH:setnth out same (list (car (nth same out)) (max (cadr (nth same out)) (/ (cadddr a) 2.0)))))
              (setq out (append out (list (list s (/ (cadddr a) 2.0)))))))))))
  out)

;; 세 갈래 이상 마디(끝끼리)에서 i 의 ㄱ자 짝 — 가장 두꺼운 둘(둘째가 셋째보다 두꺼울 때만, 같으면 번호 차례)에 i 가 들면 다른 하나, 아니면 nil
;; (1.6.1 — 외벽 ㄱ자 모서리에 칸막이가 붙어도 모서리가 막힘. YGN CAD WallBuild.Partner 와 같은 규칙)
(defun GH:wpair (i js pcs / cs)
  (setq cs (vl-sort (cons i js) '(lambda (a b / ha hb)
                                    (setq ha (cadr (nth a pcs)) hb (cadr (nth b pcs)))
                                    (if (= ha hb) (< a b) (> ha hb)))))
  (if (and (> (length cs) 2) (> (cadr (nth (cadr cs) pcs)) (+ (cadr (nth (caddr cs) pcs)) 1e-9)))
    (cond ((= i (car cs)) (cadr cs)) ((= i (cadr cs)) (car cs)))))

;; i 번 조각의 시작(st = T) · 끝 꼭짓점 (나가는 방향의 왼쪽 오른쪽)
;; 끝이 다른 조각의 끝 하나와만 만나면(ㄱ자) 마이터 — 두께가 다르면 두 면 선이 만나는 점, 혼자 끝 · T자는 평평하게,
;; 세 갈래 이상은 가장 두꺼운 둘(셋째보다 두꺼울 때)만 ㄱ자로 · 나머지는 평평하게 (1.6.1 — 전에는 모두 평평해서 외벽 모서리가 파였음)
(defun GH:wend (i st pcs / me sg P u1 half tol touch cnt inner j c n1 o2 st2 Q u2 h2 apex vS lenS b phi sn dd m1 m2 pl cr ss lim met)
  (setq me (nth i pcs) sg (car me) P (if st (car sg) (cadr sg))
        u1 (if st (GH:stan sg 0.0) (GH:vneg (GH:stan sg 1.0)))
        half (cadr me) tol (min 1.0 (/ half 10.0)) cnt 0 j 0)
  (foreach o pcs
    (if (and (/= j i) (GH:box-in (nth 8 (car o)) P tol))
      (progn
        (setq c (GH:sclose (car o) P))
        (if (< (caddr c) tol)
          (progn
            (setq cnt (1+ cnt) touch j met (cons j met))
            (if (and (>= (GH:dist (car c) (car (car o))) tol) (>= (GH:dist (car c) (cadr (car o))) tol)) (setq inner T))))))
    (setq j (1+ j)))
  (setq n1 (GH:perp u1))
  (if (and (>= cnt 2) (not inner) (setq touch (GH:wpair i met pcs))) (setq cnt 1))
  (if (or (/= cnt 1) inner)
    (list (GH:v+ P (GH:v* n1 half)) (GH:v- P (GH:v* n1 half)))
    (progn
      (setq o2 (car (nth touch pcs))
            st2 (< (GH:dist (car (GH:sclose o2 P)) (car o2)) tol)
            Q (if st2 (car o2) (cadr o2))
            u2 (if st2 (GH:stan o2 0.0) (GH:vneg (GH:stan o2 1.0)))
            h2 (cadr (nth touch pcs))
            apex (if (> (GH:dist P Q) 1e-12) (GH:v* (GH:v+ P Q) 0.5) P)
            vS (GH:v+ u1 u2) lenS (GH:vlen vS))
      (if (< (abs (- half h2)) 1e-9)
        (progn
          (if (< lenS 0.001)
            (setq b n1 dd half)
            (setq b (list (/ (car vS) lenS) (/ (cadr vS) lenS))
                  phi (GH:acos (GH:dot u1 u2)) sn (sin (/ phi 2.0))
                  dd (if (< sn 0.05) (* half 5.0) (/ half sn))))
          (setq m1 (GH:v+ apex (GH:v* b dd)) m2 (GH:v- apex (GH:v* b dd)) pl (GH:v+ apex (GH:v* n1 half)))
          (if (< (GH:dist m1 pl) (GH:dist m2 pl)) (list m1 m2) (list m2 m1)))
        (progn
          (setq cr (GH:crs u1 u2))
          (if (or (< lenS 0.001) (< (abs cr) 0.1))
            (list (GH:v+ apex (GH:v* n1 half)) (GH:v- apex (GH:v* n1 half)))
            (progn
              (setq ss (/ (+ h2 (* half (GH:dot u1 u2))) cr) lim (* 5.0 (max half h2)) ss (max (- lim) (min lim ss)))
              (list (GH:v+ (GH:v+ apex (GH:v* n1 half)) (GH:v* u1 ss)) (GH:v- (GH:v- apex (GH:v* n1 half)) (GH:v* u1 ss))))))))))

;; 띠 = (L1 R1 L2 R2 오른면볼록 왼면볼록) — 반시계 호: 오른쪽 면(바깥)은 반시계로 R1→L2, 왼쪽 면(안)은 시계로 R2→L1
(defun GH:wbands (pcs / out i sg p1 p2 L1 R1 L2 R2 b1 b3)
  (setq i 0)
  (foreach pc pcs
    (setq sg (car pc) p1 (GH:wend i T pcs) p2 (GH:wend i nil pcs)
          L1 (car p1) R1 (cadr p1) L2 (car p2) R2 (cadr p2) b1 0.0 b3 0.0)
    (if (nth 3 sg)
      (setq b1 (GH:tan (/ (GH:sweep (GH:vang (GH:v- R1 (nth 4 sg))) (GH:vang (GH:v- L2 (nth 4 sg))) 1) 4.0))
            b3 (- (GH:tan (/ (GH:sweep (GH:vang (GH:v- R2 (nth 4 sg))) (GH:vang (GH:v- L1 (nth 4 sg))) -1) 4.0)))))
    (setq out (append out (list (list L1 R1 L2 R2 b1 b3))) i (1+ i)))
  out)

;; 이은 조각 고리의 넓이 (호 조각은 활꼴 넓이를 더함)
(defun GH:ch-area (ch / a th L r)
  (setq a 0.0)
  (foreach s ch
    (setq a (+ a (/ (GH:crs (car s) (cadr s)) 2.0)))
    (if (/= (caddr s) 0.0)
      (progn
        (setq th (* 4.0 (atan (caddr s))) L (GH:dist (car s) (cadr s)))
        (if (> L 1e-12) (setq r (/ L (* 2.0 (abs (sin (/ th 2.0))))) a (+ a (* (/ (* r r) 2.0) (- th (sin th)))))))))
  a)

;; 벽 조각 ((A B 볼록 두께) …) → 벽 폴리선 → (벽 enames 못 합친 조각 수) — 띠를 영역으로 합쳐 외곽만 이어 붙임 (명령 · 실행 취소 표시를 쓰지 않음)
(defun GH:make-walls (axes layer spc z / pcs mtol regs fail pl x base todo o pieces segs walls closed vs i b bands jn tr fbs)
  (setq pcs (GH:wprep axes) fail 0)
  (if pcs
    (progn
      (setq mtol (apply 'min (mapcar '(lambda (p) (min 1.0 (/ (cadr p) 10.0))) pcs))
            bands (GH:wbands pcs))
      ;; 기존 벽선과 맞물림 (1.9.0~) — *GH:jn* = (기존 벽선 길 기록들 · 벽 두께 상한) 일 때만 (GHS 의 연결 없는 벽). 벽 몸에 닿은 혼자 끝은 가운데 선까지 ·
      ;; 기존 벽 끝과의 틈을 채우는 조각(GH:jn-fill)은 띠 다음에 영역으로 더해 같이 합침
      (if (and *GH:jn* (car *GH:jn*))
        (progn
          (setq jn (vl-catch-all-apply 'GH:jn-plan (list pcs (GH:jn-lines (car *GH:jn*)) (cadr *GH:jn*))))
          (if (or (vl-catch-all-error-p jn) (null jn)) (setq jn nil) (setq bands (GH:jn-over pcs bands (cadr jn))))))
      (foreach bd bands
        (setq pl (vlax-invoke spc 'AddLightWeightPolyline (append (car bd) (cadr bd) (caddr bd) (cadddr bd))))
        (vla-put-Closed pl :vlax-true)
        (if (/= (nth 4 bd) 0.0) (vla-SetBulge pl 1 (nth 4 bd)))
        (if (/= (nth 5 bd) 0.0) (vla-SetBulge pl 3 (nth 5 bd)))
        (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
        (if (and (not (vl-catch-all-error-p x)) x) (setq regs (append regs x)) (setq fail (1+ fail)))
        (vla-Delete pl))
      ;; 기존 벽 끝과의 틈을 채우는 조각 (GH:jn-fill) — 못 만들면 그 조각만 빼고 (못 합친 조각 수에는 안 셈)
      (if jn
        (foreach fl (caddr jn)
          (setq pl (vlax-invoke spc 'AddLightWeightPolyline (apply 'append fl)))
          (vla-put-Closed pl :vlax-true)
          (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
          (if (and (not (vl-catch-all-error-p x)) x) (setq regs (append regs x) fbs (cons (GH:jn-polysegs fl) fbs)))
          (vla-Delete pl)))
      (if regs
        (progn
          ;; 합치기 — 못 합친 조각은 따로 (영역으로 남기지 않음)
          (setq base (car regs) todo (list base))
          (foreach r (cdr regs)
            (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Boolean (list base 0 r)))
              (setq todo (cons r todo) fail (1+ fail))))
          (while todo
            (setq o (car todo) todo (cdr todo))
            (foreach y (vlax-invoke o 'Explode)
              (if (= (vla-get-ObjectName y) "AcDbRegion") (setq todo (cons y todo)) (setq pieces (cons y pieces))))
            (vla-Delete o))
          (foreach y pieces
            (if (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc") (setq segs (cons (GH:seg y) segs)))
            (vla-Delete y))
          ;; 이어 붙여 폴리선으로 (넓이가 없는 닫힌 고리 — 영역이 맞닿은 변에 남긴 가시 — 는 버림)
          (foreach ch (GH:chain (reverse segs) (max 1e-6 (/ mtol 10.0)))
            (setq closed (< (distance (cadr (last ch)) (car (car ch))) (max 1e-6 (/ mtol 10.0)))
                  vs (mapcar 'car ch))
            (if (not closed) (setq vs (append vs (list (cadr (last ch))))))
            (if (and (> (length vs) 1) (not (and closed (< (abs (GH:ch-area ch)) (* mtol mtol)))))
              (progn
                (setq pl (vlax-invoke spc 'AddLightWeightPolyline (apply 'append vs)) i 0)
                (foreach s ch
                  (if (and (< i (length vs)) (/= (setq b (caddr s)) 0.0)) (vla-SetBulge pl i b))
                  (setq i (1+ i)))
                (if closed (vla-put-Closed pl :vlax-true))
                (if (and z (/= z 0.0)) (vla-put-Elevation pl z))
                (vl-catch-all-apply 'vla-put-Layer (list pl layer))
                (vl-catch-all-apply 'vla-put-Color (list pl 256))
                (setq walls (cons (vlax-vla-object->ename pl) walls)))))
          ;; 새 벽 외곽 중 기존 벽 몸 안 토막 · 기존 벽선 중 새 벽에 싸인 토막을 뺌 → *GH:jn-n* = (맞물린 곳 고친 기존 벽선 끝 고침)
          (if (and jn walls)
            (progn
              (setq tr (vl-catch-all-apply 'GH:jn-trim (list (reverse walls) (append (mapcar 'GH:bandsegs bands) fbs) (car jn) (car *GH:jn*))))
              (if (vl-catch-all-error-p tr)
                (setq *GH:jn-n* (list -1 0 0))
                (setq walls (reverse (car tr)) *GH:jn-n* (list (cadr tr) (caddr tr) (cadddr jn))))))))))
  (list (reverse walls) fail))

;;; ══════════════════════════════════════════════════════════════════════════
;;;  캐드 객체 ↔ 조각 · 표시
;;; ══════════════════════════════════════════════════════════════════════════

;; 객체 → (조각들 닫힘? 높이) — 선 · 호(270° 넘으면 둘로) · 원(반원 둘) · 폴리선(마디마다) · 2D 폴리선(나눔) · 스플라인(호로 이음, 오차 tol). 못 읽으면 nil
(defun GH:axes-of (e tol / d ty o a b c r a0 sw zn m pts bus n i z x out spl vs closed)
  (setq d (entget e) ty (cdr (assoc 0 d)) o (vlax-ename->vla-object e))
  (cond
    ((= ty "LINE")
     (setq a (GH:2d (cdr (assoc 10 d))) b (GH:2d (cdr (assoc 11 d))))
     (if (> (GH:dist a b) 1e-6) (list (list (list a b 0.0)) nil (caddr (cdr (assoc 10 d))))))
    ((= ty "ARC")
     (setq zn (if (assoc 210 d) (caddr (cdr (assoc 210 d))) 1.0)
           a (GH:2d (vlax-curve-getStartPoint o)) b (GH:2d (vlax-curve-getEndPoint o))
           sw (GH:sweep (cdr (assoc 50 d)) (cdr (assoc 51 d)) 1))
     (if (< zn 0) (setq sw (- sw)))
     (cond
       ((< (abs sw) 1e-9) nil)
       ((> (abs sw) (* 1.5 pi))
        (setq m (GH:2d (vlax-curve-getPointAtParam o (+ (cdr (assoc 50 d)) (/ (abs sw) 2.0)))))
        (list (list (list a m (GH:tan (/ sw 8.0))) (list m b (GH:tan (/ sw 8.0)))) nil (caddr (vlax-curve-getStartPoint o))))
       (T (list (list (list a b (GH:tan (/ sw 4.0)))) nil (caddr (vlax-curve-getStartPoint o))))))
    ((= ty "CIRCLE")
     (setq c (GH:2d (cdr (assoc 10 d))) r (cdr (assoc 40 d)))
     (if (> r 1e-6)
       (list (list (list (GH:v+ c (list r 0.0)) (GH:v- c (list r 0.0)) 1.0) (list (GH:v- c (list r 0.0)) (GH:v+ c (list r 0.0)) 1.0))
             T (caddr (cdr (assoc 10 d))))))
    ((= ty "LWPOLYLINE")
     (setq zn (if (assoc 210 d) (caddr (cdr (assoc 210 d))) 1.0) closed (= 1 (logand 1 (cdr (assoc 70 d)))))
     (foreach g d
       (cond ((= (car g) 10) (setq pts (cons (list (if (< zn 0) (- (cadr g)) (cadr g)) (caddr g)) pts) bus (cons 0.0 bus)))
             ((and (= (car g) 42) bus) (setq bus (cons (if (< zn 0) (- (cdr g)) (cdr g)) (cdr bus))))))
     (setq pts (reverse pts) bus (reverse bus) n (length pts) i 0)
     (repeat (if closed n (1- n))
       (setq a (nth i pts) b (nth (rem (1+ i) n) pts))
       (if (> (GH:dist a b) 1e-6) (setq out (cons (list a b (nth i bus)) out)))
       (setq i (1+ i)))
     (if out (list (reverse out) closed (cond ((cdr (assoc 38 d))) (0.0)))))
    ((= ty "POLYLINE")
     ;; 2D 폴리선 — 메모리에서 나눈 선 · 호 (리습 GH 1.5 처럼 원본은 그대로)
     (setq x (vl-catch-all-apply 'vlax-invoke (list o 'Explode)) closed (= (vla-get-Closed o) :vlax-true))
     (if (and x (not (vl-catch-all-error-p x)))
       (progn
         (foreach y x
           (if (and (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc") (setq spl (GH:axes-of (vlax-vla-object->ename y) tol)))
             (setq out (append out (car spl))))
           (vla-Delete y))
         (if out (list out closed (caddr (vlax-curve-getStartPoint o)))))))
    ((= ty "SPLINE")
     (setq x (vl-catch-all-apply 'vlax-curve-getDistAtParam (list o (vlax-curve-getEndParam o))))
     (if (and (not (vl-catch-all-error-p x)) (> x 1e-6))
       (progn
         (setq closed (= (vlax-curve-isClosed o) T) vs (GH:sp-fit o 0.0 x tol 0))
         (if (not closed) (setq vs (append vs (list (list (GH:2d (vlax-curve-getEndPoint o)) 0.0)))))
         (setq n (length vs) i 0)
         (repeat (if closed n (1- n))
           (setq a (car (nth i vs)) b (car (nth (rem (1+ i) n) vs)))
           (if (> (GH:dist a b) 1e-6) (setq out (cons (list a b (cadr (nth i vs))) out)))
           (setq i (1+ i)))
         (if out (list (reverse out) closed (caddr (vlax-curve-getStartPoint o)))))))))

;; 표시 칸 (YGN CAD 연결 표시와 같은 글): "k:E[!]" "j:O[!]" "t!" "v" + 1011 점 (중정 씨앗)
;; · "w" + (1011 점 1040 볼록)… 쓴 자리 (꼭짓점마다) · "d" + (1012 옮김 1040 볼록)… 그린 자리 = 쓴 자리 + 옮김 (1.6.0~)
;;   1011 은 옮기기 · 돌리기 · 축척 · 대칭 · 신축에 객체와 같이 움직이고 1012 는 신축에는 안 움직임 — 객체를 통째로 옮기거나 꼭짓점을 신축해도 그린 자리가 따라옴
;; → (종류 종류정함 기준 기준정함 두께정함 중정씨앗들 그린꼭짓점들 쓴꼭짓점들), 꼭짓점 = (점 볼록)
(defun GH:fields-of (vals / x k ks j js ts vs dd dv wv mode)
  (while vals
    (setq x (car vals) vals (cdr vals))
    (cond
      ((and (= (car x) 1011) (= mode "w") vals (= (car (car vals)) 1040))
       (setq wv (cons (list (GH:2d (cdr x)) (cdr (car vals))) wv) vals (cdr vals)))
      ((and (= (car x) 1012) (= mode "d") vals (= (car (car vals)) 1040))
       (setq dd (cons (list (GH:2d (cdr x)) (cdr (car vals))) dd) vals (cdr vals)))
      ((/= (car x) 1000) (setq mode nil))
      ((wcmatch (cdr x) "k:?*") (setq mode nil k (substr (cdr x) 3 1) ks (wcmatch (cdr x) "*!")) (if (not (member k '("E" "I" "F"))) (setq k nil ks nil)))
      ((wcmatch (cdr x) "j:?*") (setq mode nil j (substr (cdr x) 3 1) js (wcmatch (cdr x) "*!")) (if (not (member j '("C" "O" "I"))) (setq j nil js nil)))
      ((= (cdr x) "t!") (setq mode nil ts T))
      ((member (cdr x) '("w" "d")) (setq mode (cdr x)))
      ((and (= (cdr x) "v") vals (= (car (car vals)) 1011)) (setq mode nil vs (append vs (list (GH:2d (cdr (car vals))))) vals (cdr vals)))
      (T (setq mode nil))))
  (setq wv (reverse wv) dd (reverse dd))
  (if (and wv (= (length wv) (length dd)))
    (setq dv (mapcar '(lambda (w d) (list (GH:v+ (car w) (car d)) (cadr d))) wv dd))
    (setq wv nil))
  (list k ks j js ts vs dv wv))
(defun GH:fields-xd (k ks j js ts vs dv wv / o)
  (if k (setq o (list (cons 1000 (strcat "k:" k (if ks "!" ""))))))
  (if j (setq o (append o (list (cons 1000 (strcat "j:" j (if js "!" "")))))))
  (if ts (setq o (append o (list (cons 1000 "t!")))))
  (foreach v vs (setq o (append o (list (cons 1000 "v") (list 1011 (car v) (cadr v) 0.0)))))
  ;; 꼭짓점 100 개까지만 (캐드는 객체 하나 XDATA 16KB — 긴 스플라인 폴리선은 기록 없이: 다시 고르면 지금 자리에서 되돌려 셈)
  (if (and dv wv (= (length dv) (length wv)) (<= (length wv) 100))
    (progn
      (setq o (append o (list (cons 1000 "w"))))
      (foreach v wv (setq o (append o (list (list 1011 (car (car v)) (cadr (car v)) 0.0) (cons 1040 (float (cadr v)))))))
      (setq o (append o (list (cons 1000 "d"))))
      (foreach p (mapcar 'list dv wv)
        (setq o (append o (list (list 1012 (- (car (car (car p))) (car (car (cadr p)))) (- (cadr (car (car p))) (cadr (car (cadr p)))) 0.0)
                                (cons 1040 (float (cadr (car p))))))))))
  o)
;; 조각들 ↔ 꼭짓점들 ((점 볼록) …) — 열린 것은 끝점 하나 더 (볼록 0)
(defun GH:ax->v (axes closed / o)
  (setq o (mapcar '(lambda (a) (list (car a) (caddr a))) axes))
  (if (and axes (not closed)) (setq o (append o (list (list (cadr (last axes)) 0.0)))))
  o)
(defun GH:v->ax (vs closed / o p)
  (setq p vs)
  (while (cdr p)
    (if (> (GH:dist (car (car p)) (car (cadr p))) 1e-6) (setq o (cons (list (car (car p)) (car (cadr p)) (cadr (car p))) o)))
    (setq p (cdr p)))
  (if (and closed (cdr vs) (> (GH:dist (car (last vs)) (car (car vs))) 1e-6)) (setq o (cons (list (car (last vs)) (car (car vs)) (cadr (last vs))) o)))
  (reverse o))
;; 모양 견줄 꼴 — 같은 원 위로 이어진 호 조각은 하나로 (반 바퀴 넘는 호 · 원은 읽을 때 둘로 나뉘어서) → ((A B 각 중심) …)
(defun GH:canon (axes closed / o s q f)
  (foreach a axes
    (setq s (GH:sg (car a) (cadr a) (caddr a)) q (last o))
    (if (and q (nth 3 s) (cadddr q) (GH:near (cadddr q) (nth 4 s) 1e-4) (= (GH:sgn (caddr q)) (GH:sgn (nth 7 s))) (GH:near (cadr q) (car a) 1e-4))
      (setq o (GH:setnth o (1- (length o)) (list (car q) (cadr a) (+ (caddr q) (nth 7 s)) (cadddr q))))
      (setq o (append o (list (list (car a) (cadr a) (nth 7 s) (if (nth 3 s) (nth 4 s))))))))
  (if (and closed (cdr o))
    (progn
      (setq q (last o) f (car o))
      (if (and (cadddr q) (cadddr f) (GH:near (cadddr q) (cadddr f) 1e-4) (= (GH:sgn (caddr q)) (GH:sgn (caddr f))))
        (setq o (cons (list (car q) (cadr f) (+ (caddr q) (caddr f)) (cadddr q)) (cdr (reverse (cdr (reverse o)))))))))
  o)
;; 한 바퀴 원은 시작 자리가 아무 데나 — 중심 · 반지름 · 방향만 견줌
(defun GH:full-p (x) (and (cadddr x) (>= (abs (caddr x)) (- (* 2.0 pi) 1e-9))))
(defun GH:canon-eq (a b)
  (and (= (length a) (length b))
       (vl-every '(lambda (x y)
                    (and (<= (abs (- (caddr x) (caddr y))) 1e-6)
                         (if (and (GH:full-p x) (GH:full-p y))
                           (and (GH:near (cadddr x) (cadddr y) 1e-4) (<= (abs (- (GH:dist (car x) (cadddr x)) (GH:dist (car y) (cadddr y)))) 1e-4))
                           (and (GH:near (car x) (car y) 1e-4) (GH:near (cadr x) (cadr y) 1e-4)))))
                 a b)))
(defun GH:canon-same (a b closed / k ok)
  (setq k 0)
  (if (and a (= (length a) (length b)))
    (if closed
      (progn
        (while (and (not ok) (< k (length b)))
          (setq ok (GH:canon-eq a b) b (append (cdr b) (list (car b))) k (1+ k)))
        ok)
      (GH:canon-eq a b))))
;; 조각들 거꾸로 (차례 · 방향 · 볼록 부호)
(defun GH:ax-rev (axes) (reverse (mapcar '(lambda (a) (list (cadr a) (car a) (- (caddr a)))) axes)))
;; 지금 모양(조각들)이 기록한 쓴 자리(꼭짓점들) 그대로인지 → 1 그대로 · -1 방향만 거꾸로 (REVERSE) · nil — 닫힌 것은 시작 자리가 달라도 됨
(defun GH:same-shape (wv cur closed / a)
  (setq a (GH:canon (GH:v->ax wv closed) closed))
  (cond
    ((GH:canon-same a (GH:canon cur closed) closed) 1)
    ((GH:canon-same a (GH:canon (GH:ax-rev cur) closed) closed) -1)))
;; 기록해 둔 그린 뼈대 되찾기 (YGN CAD Core SkelRecord.Recover 와 같은 셈) — wv 쓴 자리 · dv 그린 자리 꼭짓점들, axes · closed 지금 모양
;; → ("same" 조각들) 지금 모양 = 쓴 자리 (옮기기 · 돌리기 · 복사 · 신축은 표시 점도 같이) → 그린 자리 그대로 (방향만 거꾸로 그렸으면 거꾸로)
;;   ("vertex" 조각들) 꼭짓점 수가 같음 → 꼭짓점마다 지금 자리 + (그린 − 쓴) 옮김 (그립으로 고친 꼭짓점도 그린 자리가 따라옴 · 볼록을 고친 마디는 지금 볼록)
;;   nil 그 밖 → 지금 자리에서 지난 값만큼 되돌려 셈
(defun GH:recover (wv dv axes closed / cv ax sh)
  (cond
    ((not (and wv dv (= (length wv) (length dv)))) nil)
    ((setq sh (GH:same-shape wv axes closed))
     (if (setq ax (GH:v->ax dv closed)) (list "same" (if (= sh -1) (GH:ax-rev ax) ax))))
    ((= (length (setq cv (GH:ax->v axes closed))) (length wv))
     (if (setq ax (GH:v->ax (mapcar '(lambda (c w d) (list (GH:v+ (car c) (GH:v- (car d) (car w))) (if (<= (abs (- (cadr c) (cadr w))) 1e-6) (cadr d) (cadr c))))
                                    cv wv dv)
                            closed))
       (list "vertex" ax)))))
(defun GH:xd (e app) (cdr (assoc app (cdr (assoc -3 (entget e (list app)))))))
;; 그린 선의 지난 값 → (역할 연결번호 두께 종류 종류정함 기준 기준정함 두께정함 씨앗들) · 연결(HY_GHL) 은 역할 "C"/"W",
;; 뼈대 기록(HY_SKEL — GH · YGN CAD 가 연결 없이 만든 것) · YGN CAD 의 풀린 연결 표시(HY_WALL wl0) 는 "S"
(defun GH:tag-full (e / v f)
  (cond
    ((and (setq v (GH:xd e "HY_GHL")) (>= (length v) 3) (= (car (nth 2 v)) 1040))
     (setq f (GH:fields-of (cdddr v)))
     (append (list (cdr (nth 0 v)) (cdr (nth 1 v)) (cdr (nth 2 v))) f))
    ((and (setq v (GH:xd e "HY_SKEL")) (>= (length v) 2) (= (cdr (car v)) "sk1") (= (car (cadr v)) 1040))
     (setq f (GH:fields-of (cddr v)))
     (append (list "S" nil (cdr (cadr v))) f))
    ((and (setq v (GH:xd e "HY_WALL")) (>= (length v) 4) (= (cdr (car v)) "wl0") (= (cdr (cadr v)) "C") (= (car (cadddr v)) 1040))
     (setq f (GH:fields-of (cdr (cdddr v))))
     (append (list "S" nil (cdr (cadddr v))) f))))
(defun GH:drop-xd (e app) (if (GH:xd e app) (GH:put-xd e app nil)))
(defun GH:put-xd (e app vals)
  (if (null (tblsearch "APPID" app)) (regapp app))
  (GH:unlocked e (function (lambda (e) (entmod (list (cons -1 e) (list -3 (cons app vals))))))))
;; 표시 쓰기 — 못 쓰면(다른 앱 표시와 합쳐 16KB 넘음 등) 그린 자리 기록 없이 다시
(defun GH:no-rec (f) (list (nth 0 f) (nth 1 f) (nth 2 f) (nth 3 f) (nth 4 f) (nth 5 f) nil nil))
(defun GH:skel-tag (e thick f g / h)
  (setq h (append (list (cons 1000 "sk1") (cons 1040 (float thick))) (if g (list (cons 1000 (strcat "g:" g))))))
  (or (GH:put-xd e "HY_SKEL" (append h (apply 'GH:fields-xd f)))
      (GH:put-xd e "HY_SKEL" (append h (apply 'GH:fields-xd (GH:no-rec f))))))
(defun GH:link-tag (e role net thick f / h)
  (setq h (list (cons 1000 role) (cons 1000 net) (cons 1040 (float thick))))
  (or (GH:put-xd e "HY_GHL" (append h (apply 'GH:fields-xd f)))
      (GH:put-xd e "HY_GHL" (append h (apply 'GH:fields-xd (GH:no-rec f))))))

;;; ══════════════════════════════════════════════════════════════════════════
;;;  미리보기 — 벽 외곽(띠를 합친 바깥 선, 영역 없이 계산) · 선 종류 색 · 옮긴 중심선 · 중정 × · 열린 끝 ○ (grvecs, 도면은 그대로)
;;;  YGN CAD 뼈대 미리보기와 같은 색: 벽 흰색 · 외벽 파랑(직접 정함 하늘) · 내벽 주황(직접 정함 노랑) · 따로 선 벽 초록 · 판정이 바뀐 선 빨강 · 옮긴 중심선 회색
;;; ══════════════════════════════════════════════════════════════════════════

(defun GH:boxu (a b) (list (min (car a) (car b)) (min (cadr a) (cadr b)) (max (caddr a) (caddr b)) (max (cadddr a) (cadddr b))))

;; 띠 (L1 R1 L2 R2 볼록 볼록) → (조각 넷 상자) — 반시계 고리 L1→R1→L2→R2
(defun GH:bandsegs (bd / ss bx)
  (setq ss (list (GH:sg (nth 0 bd) (nth 1 bd) 0.0) (GH:sg (nth 1 bd) (nth 2 bd) (nth 4 bd))
                 (GH:sg (nth 2 bd) (nth 3 bd) 0.0) (GH:sg (nth 3 bd) (nth 0 bd) (nth 5 bd)))
        bx (nth 8 (car ss)))
  (foreach s (cdr ss) (setq bx (GH:boxu bx (nth 8 s))))
  (list ss bx))

;; 점 p 를 도는 각 (YGN CAD WallBuild.Wind 와 같음 — 호 안쪽이면 한 바퀴 더)
(defun GH:wind (s p / a b cr dt w ch sp sm)
  (setq a (GH:v- (car s) p) b (GH:v- (cadr s) p) cr (GH:crs a b) dt (GH:dot a b)
        w (if (and (zerop cr) (zerop dt)) 0.0 (atan cr dt)))
  (if (and (nth 3 s) (< (GH:dist p (nth 4 s)) (nth 5 s)))
    (progn
      (setq ch (GH:v- (cadr s) (car s)) sp (GH:crs ch (GH:v- p (car s))) sm (GH:crs ch (GH:v- (GH:sat s 0.5) (car s))))
      (if (> (* sp sm) 0) (setq w (+ w (if (> (nth 7 s) 0) (* 2.0 pi) (* -2.0 pi)))))))
  w)
(defun GH:inband (bd p / w)
  (if (GH:box-in (cadr bd) p 0.0)
    (progn (setq w 0.0) (foreach s (car bd) (setq w (+ w (GH:wind s p)))) (> (abs w) pi))))

;; 조각 s 의 t0 ~ t1 을 점들로 (호는 7.5° 마다)
(defun GH:spts (s t0 t1 / k q o)
  (if (nth 3 s)
    (progn
      (setq k (max 1 (GH:ceil (/ (* (abs (nth 7 s)) (- t1 t0)) (/ pi 24.0)))) q 0)
      (repeat (1+ k) (setq o (cons (GH:sat s (+ t0 (* (- t1 t0) (/ (float q) k)))) o) q (1+ q)))
      (reverse o))
    (list (GH:sat s t0) (GH:sat s t1))))

;; 띠 조각들(GH:wprep) → 합친 외곽 선들 ((점 …) …) — 변을 서로 만나는 곳에서 나눠 양옆 중 한쪽만 띠 안이면 외곽 (YGN CAD WallBuild.Union 과 같은 규칙)
(defun GH:outline (pcs / bands n all ext eps on mh dl order ii jj i j bi bj go pairs nb k cur cand out len cuts hs ce cf ts tl t0 t1 tm m d nr inL inR pl pr)
  (setq bands (mapcar 'GH:bandsegs (GH:wbands pcs)) n (length bands) all (cadr (car bands)))
  (foreach b (cdr bands) (setq all (GH:boxu all (cadr b))))
  (setq ext (max (abs (car all)) (abs (cadr all)) (abs (caddr all)) (abs (cadddr all)))
        eps (max 1e-7 (* ext 1e-11)) on (* eps 10.0)
        mh (apply 'min (mapcar 'cadr pcs))
        dl (max (* on 5.0) (min (* mh 1e-3) 1e-3)))
  ;; 상자가 겹치는 띠 (x 로 훑기)
  (setq order (vl-sort-i bands '(lambda (a b) (< (car (cadr a)) (car (cadr b))))) ii 0)
  (while (< ii n)
    (setq i (nth ii order) bi (cadr (nth i bands)) jj (1+ ii) go T)
    (while (and go (< jj n))
      (setq j (nth jj order) bj (cadr (nth j bands)))
      (if (> (car bj) (+ (caddr bi) on))
        (setq go nil)
        (if (GH:box-ov bi bj on) (setq pairs (cons (list i j) (cons (list j i) pairs)))))
      (setq jj (1+ jj)))
    (setq ii (1+ ii)))
  (setq pairs (GH:sortby pairs '(lambda (a b) (< (car a) (car b)))) k 0)
  (repeat n
    (setq cur nil)
    (while (and pairs (= (car (car pairs)) k)) (setq cur (cons (cadr (car pairs)) cur) pairs (cdr pairs)))
    (setq nb (cons cur nb) k (1+ k)))
  (setq nb (reverse nb) i 0)
  (foreach bd bands
    (setq cand (mapcar '(lambda (x) (nth x bands)) (cons i (nth i nb))))
    (foreach e (car bd)
      (setq len (GH:slen e))
      (if (> len on)
        (progn
          (setq cuts nil)
          (foreach j (nth i nb)
            (foreach f (car (nth j bands))
              (if (and (> (GH:slen f) on) (GH:box-ov (nth 8 e) (nth 8 f) on))
                (foreach h (append (GH:hits e f) (list (car f) (cadr f)))
                  (setq ce (GH:sclose e h) cf (GH:sclose f h))
                  (if (and (<= (caddr ce) on) (<= (caddr cf) on)) (setq cuts (cons (cadr ce) cuts)))))))
          (setq ts (list 0.0) tl 0.0)
          (foreach x (vl-sort (vl-remove-if-not '(lambda (x) (and (> (* x len) on) (> (* (- 1.0 x) len) on))) cuts) '<)
            (if (> (* (- x tl) len) on) (setq ts (cons x ts) tl x)))
          (setq ts (reverse (cons 1.0 ts)))
          (while (cdr ts)
            (setq t0 (car ts) t1 (cadr ts) ts (cdr ts) tm (* 0.5 (+ t0 t1))
                  m (GH:sat e tm) d (GH:stan e tm) nr (GH:perp d)
                  pl (GH:v+ m (GH:v* nr dl)) pr (GH:v- m (GH:v* nr dl))
                  inL (vl-some '(lambda (b) (GH:inband b pl)) cand)
                  inR (vl-some '(lambda (b) (GH:inband b pr)) cand))
            (if (not (eq (not inL) (not inR))) (setq out (cons (GH:spts e t0 t1) out)))))))
    (setq i (1+ i)))
  (reverse out))

;; 계획의 토막들 → 벽 조각 ((A B 볼록 두께) …)
(defun GH:run-axes (runs / o)
  (foreach r runs (foreach a (nth 8 r) (setq o (cons (append a (list (nth 3 r))) o))))
  (reverse o))

;; grvecs 목록에 선 하나 (거꾸로 쌓음 — 끝에 뒤집음) — 점은 지금 UCS 로
(defun GH:vec (acc col pts z / p q)
  (if (cdr pts)
    (progn
      (setq acc (cons col acc) p (trans (list (car (car pts)) (cadr (car pts)) z) 0 1))
      (foreach x (cdr pts)
        (setq q (trans (list (car x) (cadr x) z) 0 1) acc (cons q (cons p acc)) p q))))
  acc)
(defun GH:apts (a b bu) (GH:spts (GH:sg a b bu) 0.0 1.0))

;; 지금 계획의 그림 → grvecs 목록
(defun GH:picture (z mark / acc pcs col src s r k q)
  (setq pcs (GH:wprep (GH:run-axes (GH:pl *GH:sp* "runs"))))
  (if pcs (foreach pl (GH:outline pcs) (setq acc (GH:vec acc 7 pl z))))
  (foreach e (GH:pl *GH:sp* "edges")
    (setq src (car e) s (nth src *GH:sb*)
          col (cond ((member src *GH:sc*) 1)
                    ((= (nth 18 e) "E") (if (nth 2 s) 4 5))
                    ((= (nth 18 e) "I") (if (nth 2 s) 2 30))
                    (T 3))
          acc (GH:vec acc col (GH:apts (nth 6 e) (nth 7 e) (nth 8 e)) z))
    (if (or (> (abs (nth 21 e)) 1e-9) (not (GH:near (nth 22 e) (nth 6 e) 1e-9)) (not (GH:near (nth 23 e) (nth 7 e) 1e-9)))
      (setq acc (GH:vec acc 8 (GH:apts (nth 22 e) (nth 23 e) (nth 24 e)) z))))
  (foreach v (GH:pl *GH:sp* "seeds")
    (setq acc (GH:vec acc 6 (list (GH:v+ v (list (- mark) (- mark))) (GH:v+ v (list mark mark))) z)
          acc (GH:vec acc 6 (list (GH:v+ v (list (- mark) mark)) (GH:v+ v (list mark (- mark)))) z)))
  (setq r (* 0.6 mark))
  (foreach v (GH:pl *GH:sp* "open")
    (setq q nil k 0)
    (repeat 17 (setq q (cons (GH:v+ v (GH:pol (* k (/ pi 8.0)) r)) q) k (1+ k)))
    (setq acc (GH:vec acc 1 q z)))
  (foreach x (GH:pl *GH:sp* "snaps") (setq acc (GH:vec acc 1 (list (car x) (cadr x)) z)))
  (foreach x *GH:fs* (setq acc (GH:vec acc 1 (list (car x) (cadr x)) z)))
  (reverse acc))

;; 그림을 바꿔 보여 줌 + 요약 한 줄
(defun GH:show (z mark note / v)
  (redraw)
  (if (setq v (GH:picture z mark)) (grvecs v))
  (princ (strcat "\n" (GH:ss-summary) note)))

;;; ══════════════════════════════════════════════════════════════════════════
;;;  GH · GHL — 뼈대 고르기 → 미리보기에서 고치기 → 벽 한 번에
;;; ══════════════════════════════════════════════════════════════════════════

;; 기억한 값 — 외벽 · 내벽 두께 (없으면 GH 1.5 의 한 두께 HyGhThick), 외벽 기준 C 가운데 · O 바깥면 · I 안쪽면
(defun GH:env-thick (key / v)
  (cond ((and (setq v (getenv key)) (> (atof v) 0)) (atof v))
        ((and (setq v (getenv "HyGhThick")) (> (atof v) 0)) (atof v))
        ((and *WUX_DIST* (numberp *WUX_DIST*) (> *WUX_DIST* 0)) (float *WUX_DIST*))
        (200.0)))
(defun GH:env-just ( / v) (if (member (setq v (getenv "HyGhExtJust")) '("C" "O" "I")) v "C"))
(defun GH:just-name (j) (cond ((= j "O") "바깥면") ((= j "I") "안쪽면") (T "가운데")))
(defun GH:just-next (j) (cond ((= j "C") "O") ((= j "O") "I") (T "C")))
(defun GH:num (x) (rtos x 2 (if (equal x (fix (+ x 0.5)) 1e-9) 0 2)))

;; 화면에서 누를 때 허용 거리 (YGN CAD 와 같음 — PICKBOX 픽셀 × 1.5)
(defun GH:pick-tol ( / h)
  (setq h (cadr (getvar "SCREENSIZE")))
  (if (and h (> h 0)) (* (/ (getvar "VIEWSIZE") h) (max 3 (getvar "PICKBOX")) 1.5) 1.0))

;; 두께 묻기 — Enter = 그대로
(defun GH:ask-mm (label cur / v)
  (initget 6)
  (setq v (getdist (strcat "\n" label " <" (GH:num cur) ">: ")))
  (if (and v (> v 0)) v))

(defun GH:len (e / x)
  (setq x (vl-catch-all-apply 'vlax-curve-getDistAtParam (list e (vlax-curve-getEndParam e))))
  (if (vl-catch-all-error-p x) 0.0 x))
(defun GH:ss-list (ss / i o) (setq i 0) (if ss (repeat (sslength ss) (setq o (cons (ssname ss i) o) i (1+ i)))) (reverse o))
(defun GH:ygn-linked-p (e / v) (and (setq v (GH:xd e "HY_WALL")) (= (cdr (car v)) "wl1")))
(defun GH:wall-loose-p (e / v) (and (setq v (GH:xd e "HY_WALL")) (= (cdr (car v)) "wl0")))

;; 닿는지 (끝이 다른 조각 위 tol 안)
(defun GH:touch (xa xb tol / hit)
  (foreach a xa
    (foreach b xb
      (if (and (not hit) (GH:box-ov (nth 8 a) (nth 8 b) tol))
        (if (vl-some '(lambda (p) (< (caddr (GH:sclose b p)) tol)) (list (car a) (cadr a)))
          (setq hit T)
          (if (vl-some '(lambda (p) (< (caddr (GH:sclose a p)) tol)) (list (car b) (cadr b))) (setq hit T))))))
  hit)
(defun GH:segs-of (axes) (mapcar '(lambda (a) (GH:sg (car a) (cadr a) (caddr a))) axes))

;; 토막이 한 원 위의 호들인지 → (중심 반지름 시작각 끝각 한바퀴?) 또는 nil
(defun GH:one-circle (r / ax s0 sw s ok from to)
  (setq ax (nth 8 r) ok (and ax (vl-every '(lambda (a) (> (abs (caddr a)) 1e-12)) ax)))
  (if ok
    (progn
      (setq s0 (GH:sg (car (car ax)) (cadr (car ax)) (caddr (car ax))) sw 0.0)
      (foreach a ax
        (setq s (GH:sg (car a) (cadr a) (caddr a)))
        (if (or (not (GH:near (nth 4 s) (nth 4 s0) (max 1e-6 (* (nth 5 s0) 1e-9))))
                (> (abs (- (nth 5 s) (nth 5 s0))) (max 1e-6 (* (nth 5 s0) 1e-9)))
                (/= (GH:sgn (nth 7 s)) (GH:sgn (nth 7 s0))))
          (setq ok nil))
        (setq sw (+ sw (nth 7 s))))
      (setq s (cdr ax))
      (while (and ok s) (if (not (GH:near (cadr (car ax)) (car (car s)) 1e-7)) (setq ok nil)) (setq ax s s (cdr s)))
      (setq ax (nth 8 r))
      (if (and ok (eq (< (abs (- (abs sw) (* 2.0 pi))) 1e-7) (not (not (nth 6 r)))))
        (progn
          (setq from (car (car ax)) to (cadr (last ax)))
          (if (< sw 0) (setq s from from to to s))
          (list (nth 4 s0) (nth 5 s0) (GH:vang (GH:v- from (nth 4 s0))) (GH:vang (GH:v- to (nth 4 s0))) (< (abs (- (abs sw) (* 2.0 pi))) 1e-7)))))))

(defun GH:same-axes (a b)
  (and (= (length a) (length b))
       (vl-every '(lambda (x y) (and (GH:near (car x) (car y) 1e-7) (GH:near (cadr x) (cadr y) 1e-7) (<= (abs (- (caddr x) (caddr y))) 1e-9))) a b)))

;; 토막 r 의 꼭짓점 · 볼록 값
(defun GH:run-verts (r / ax pts bus)
  (setq ax (nth 8 r) pts (mapcar 'car ax) bus (mapcar 'caddr ax))
  (if (not (nth 6 r)) (setq pts (append pts (list (cadr (last ax)))) bus (append bus (list 0.0))))
  (list pts bus))

;; 그 객체를 그대로 고쳐 씀 (선 · 원 · +Z 호 · +Z 폴리선) → T 또는 nil
(defun GH:try-set (e r / d ty o c nz ax pv i)
  (setq d (entget e) ty (cdr (assoc 0 d)) o (vlax-ename->vla-object e) ax (nth 8 r)
        nz (if (assoc 210 d) (caddr (cdr (assoc 210 d))) 1.0))
  (cond
    ((and (= ty "LINE") (not (nth 6 r)) (= (length ax) 1) (< (abs (caddr (car ax))) 1e-12))
     (entmod (subst (cons 11 (list (car (cadr (car ax))) (cadr (cadr (car ax))) (cadddr (assoc 11 d))))
                    (assoc 11 d)
                    (subst (cons 10 (list (car (car (car ax))) (cadr (car (car ax))) (cadddr (assoc 10 d)))) (assoc 10 d) d)))
     T)
    ((and (= ty "CIRCLE") (> (abs nz) (- 1.0 1e-9)) (setq c (GH:one-circle r)) (nth 4 c))
     (vla-put-Center o (vlax-3d-point (list (car (car c)) (cadr (car c)) (caddr (vlax-get o 'Center)))))
     (vla-put-Radius o (cadr c))
     T)
    ((and (= ty "ARC") (> nz (- 1.0 1e-9)) (setq c (GH:one-circle r)) (not (nth 4 c)))
     (vla-put-Center o (vlax-3d-point (list (car (car c)) (cadr (car c)) (caddr (vlax-get o 'Center)))))
     (vla-put-Radius o (cadr c))
     (vla-put-StartAngle o (GH:norm0 (caddr c)))
     (vla-put-EndAngle o (GH:norm0 (cadddr c)))
     T)
    ((and (= ty "LWPOLYLINE") (> nz (- 1.0 1e-9)))
     (setq pv (GH:run-verts r) i 0)
     (vlax-put o 'Coordinates (apply 'append (car pv)))
     (foreach b (cadr pv) (vla-SetBulge o i b) (setq i (1+ i)))
     (vla-put-Closed o (if (nth 6 r) :vlax-true :vlax-false))
     T)))

;; 토막 r 을 그 객체와 같은 속성 · 표시의 새 곡선으로 → 새 ename
(defun GH:new-like (e r z / d props xd c pv geo)
  (setq d (entget e '("*"))
        props (vl-remove-if-not '(lambda (x) (member (car x) '(8 6 62 370 48 420 430 440 60))) d)
        xd (assoc -3 d))
  (setq geo
    (cond
      ((setq c (GH:one-circle r))
       (if (nth 4 c)
         (list '(0 . "CIRCLE") (cons 10 (list (car (car c)) (cadr (car c)) z)) (cons 40 (cadr c)))
         (list '(0 . "ARC") (cons 10 (list (car (car c)) (cadr (car c)) z)) (cons 40 (cadr c))
               (cons 50 (GH:norm0 (caddr c))) (cons 51 (GH:norm0 (cadddr c))))))
      ((and (not (nth 6 r)) (= (length (nth 8 r)) 1) (< (abs (caddr (car (nth 8 r)))) 1e-12))
       (list '(0 . "LINE") (cons 10 (list (car (car (car (nth 8 r)))) (cadr (car (car (nth 8 r)))) z))
             (cons 11 (list (car (cadr (car (nth 8 r)))) (cadr (cadr (car (nth 8 r)))) z))))))
  (if geo
    (entmake (append (list (car geo)) props (cdr geo) (if xd (list xd))))
    (progn
      (setq pv (GH:run-verts r))
      (entmake (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity")) props
                       (list '(100 . "AcDbPolyline") (cons 90 (length (car pv))) (cons 70 (if (nth 6 r) 1 0)) (cons 38 z))
                       (apply 'append (mapcar '(lambda (p b) (list (cons 10 p) (cons 42 b))) (car pv) (cadr pv)))
                       (if xd (list xd))))))
  (entlast))

;; 그린 선 하나를 토막대로 → ((ename . 토막) …) — 모양이 같으면 그대로, 첫 토막은 그 객체를 고침 (못 고치면 바꿔 씀), 나머지는 새 곡선.
;; 잠긴 레이어는 잠깐 풀었다 다시 잠금. *GH:wn* = (옮긴 수 나눈 수)
(defun GH:rewrite (it rs / e z out x)
  (setq e (car it) z (nth 4 it))
  (if (and (= (length rs) 1) (eq (not (nth 6 (car rs))) (not (nth 3 it))) (GH:same-axes (nth 8 (car rs)) (cond ((nth 5 it)) ((nth 2 it)))))
    (list (cons e (car rs)))
    (progn
      (setq *GH:wn* (list (1+ (car *GH:wn*)) (+ (cadr *GH:wn*) (1- (length rs)))))
      (if (setq x (GH:unlocked e (function (lambda (e) (GH:try-set e (car rs))))))
        (setq out (list (cons e (car rs))))
        (setq out (list (cons (GH:unlocked e (function (lambda (e) (GH:new-like e (car rs) z)))) (car rs)))))
      (foreach r (cdr rs) (setq out (append out (list (cons (GH:unlocked e (function (lambda (e) (GH:new-like e r z)))) r)))))
      (if (not x) (GH:unlocked e (function (lambda (e) (entdel e)))))
      (vl-remove-if '(lambda (p) (null (car p))) out))))

;; 토막의 표시 값 (종류 종류정함 기준 기준정함 두께정함 중정씨앗 그린꼭짓점 쓴꼭짓점)
(defun GH:run-fields (r / b)
  (setq b (nth (car r) *GH:sb*))
  (list (nth 1 r) (if (nth 2 b) T) (nth 2 r) (if (nth 4 b) T) (if (nth 3 b) T) (nth 9 r)
        (GH:ax->v (nth 10 r) (nth 6 r)) (GH:ax->v (nth 8 r) (nth 6 r))))

;; 계획 마디 덩어리 → 그린 선마다 덩어리 번호 ((src . 덩어리) …)
(defun GH:src-comps ( / comp a b o)
  (setq comp (GH:iota (length (GH:pl *GH:sp* "nodes"))))
  (foreach e (GH:pl *GH:sp* "edges")
    (setq a (GH:cf (nth 4 e) comp) b (GH:cf (nth 5 e) comp))
    (if (/= a b) (setq comp (GH:setnth comp (max a b) (min a b)))))
  (foreach e (GH:pl *GH:sp* "edges") (if (not (assoc (car e) o)) (setq o (cons (cons (car e) (GH:cf (nth 4 e) comp)) o))))
  o)

;;; ══════════════════════════════════════════════════════════════════════════
;;;  같은 벽으로 다시 (1.7.0~, 호용 2026-11-24 '이미 생성된 벽에다가 중심선을 그리고 다시 gh 를 했을 때도 같은 벽으로 인식 — 그게 bim 과 가까워지는 길')
;;;   · 한 번 GH 로 만든 벽 = 뼈대 묶음: 중심선 HY_SKEL 에 "g:묶음" · 벽 폴리선 HY_SKELW (1000 "w1") (1000 묶음) — YGN CAD 중심선 고르기와 같은 글.
;;;   · 다시 GH: 고른 선 · 닿는 지난 중심선(새 선 끝이 지난 벽 안이어도) · 같은 묶음 · 같은 연결(GHL)을 모두 같이 → 지난 벽은 지우고 한 벽으로 다시.
;;;     지난 벽 = 묶음 표시가 있는 벽 + 표시 없는 선 중 지난 중심선(쓴 자리 · 두께)의 벽 띠 테두리 위에만 놓인 것 (1.6 이하로 만든 벽 · 문으로 잘린 조각).
;;;   · 새로 그린 선의 끝이 지난 벽 안(지난 중심선에서 반 두께 안)에 있으면 그 중심선까지 늘이거나 줄여 T자로 (곧은 끝만).
;;;   · GH 로 골라도 GHL 연결이 닿거나 섞이면 이번 벽도 연결로 (연결은 그대로 — 확정은 GHN). YGN CAD 로 연결한 벽은 YGN CAD 가 맡음 (닿으면 알림만).
;;; ══════════════════════════════════════════════════════════════════════════

;; 뼈대 묶음 번호 (HY_SKEL 의 "g:번호") → 번호 또는 nil
(defun GH:skel-group (e / v g)
  (if (and (setq v (GH:xd e "HY_SKEL")) (= (cdr (car v)) "sk1"))
    (foreach x (cddr v) (if (and (null g) (= (car x) 1000) (wcmatch (cdr x) "g:?*")) (setq g (substr (cdr x) 3)))))
  g)
;; 묶음의 벽 표시 (HY_SKELW)
(defun GH:wall-tag (e g) (GH:put-xd e "HY_SKELW" (list (cons 1000 "w1") (cons 1000 g))))
(defun GH:wall-group (e / v)
  (if (and (setq v (GH:xd e "HY_SKELW")) (= (cdr (car v)) "w1") (cadr v) (= (car (cadr v)) 1000)) (cdr (cadr v))))
(defun GH:space-of (e) (cond ((cdr (assoc 410 (entget e)))) ("Model")))
;; 조각들 상자
(defun GH:segs-box (segs / bx)
  (foreach s segs (setq bx (if bx (GH:boxu bx (nth 8 s)) (nth 8 s))))
  bx)
;; 지난 중심선의 열쇠 — ("G" . 묶음) · ("N" . GHL 연결) · nil (묶음 없는 기록)
(defun GH:okey (e tg / g)
  (cond ((and tg (= (car tg) "C")) (cons "N" (cadr tg)))
        ((and tg (= (car tg) "S") (setq g (GH:skel-group e))) (cons "G" g))))

;; 다시 맞출 수 있는 지난 중심선 (공간 sp) — 뼈대 기록(HY_SKEL) · GHL 연결 중심선 → ((ename 표시 조각들 닫힘 높이 열쇠 상자 조각sg 두께) …)
(defun GH:old-pool (sp stol / ss i e tg ax out sgs)
  (foreach app '("HY_SKEL" "HY_GHL")
    (if (setq ss (ssget "_X" (list (list -3 (list app)) (cons 410 sp))))
      (progn
        (setq i 0)
        (while (< i (sslength ss))
          (setq e (ssname ss i) i (1+ i) tg (GH:tag-full e))
          (if (and tg (member (car tg) '("S" "C")) (nth 2 tg) (> (nth 2 tg) 0) (not (assoc e out)) (not (GH:ygn-linked-p e))
                   (setq ax (GH:axes-of e stol)) (car ax))
            (setq sgs (GH:segs-of (car ax))
                  out (cons (list e tg (car ax) (cadr ax) (caddr ax) (GH:okey e tg) (GH:segs-box sgs) sgs (nth 2 tg)) out)))))))
  (reverse out))

;; 새 선(조각sg 닫힘)의 열린 끝이 지난 중심선(조각sg · 두께 th)의 벽 안에 있는지 — 반 두께 + tol 안
(defun GH:end-in (fsg closed osg th tol / hit)
  (if (and fsg (not closed))
    (foreach p (list (car (car fsg)) (cadr (last fsg)))
      (foreach s osg
        (if (and (null hit) (GH:box-in (nth 8 s) p (+ (/ th 2.0) tol)) (<= (caddr (GH:sclose s p)) (+ (/ th 2.0) tol)))
          (setq hit T)))))
  hit)

;; 닿는 것 모으기 — 고른 것에서 시작해 닿는 지난 중심선 · 같은 묶음 · 같은 연결을 되풀이로 (새 선은 끝이 지난 벽 안이어도 닿음).
;; YGN CAD Core SkelGroups.Pull 과 같은 셈. items ((조각들 닫힘 두께 새선? 열쇠) …) · pool ((조각들 닫힘 두께 열쇠) …) · keys 고른 벽의 열쇠들
;; → 더한 pool 번호들 (0 부터, 더한 차례). 마디 = (조각sg 닫힘 두께 새선? 상자)
(defun GH:pnode (sgs closed th fresh) (list sgs closed th fresh (GH:segs-box sgs)))
;; rest(남은 번호) 중 열쇠가 keys 에 든 것 → (더한 번호들 남은 번호들)
(defun GH:pull-keys (rest pool keys / take r2)
  (foreach i rest (if (and (nth 3 (nth i pool)) (member (nth 3 (nth i pool)) keys)) (setq take (cons i take)) (setq r2 (cons i r2))))
  (list (reverse take) (reverse r2)))
(defun GH:pull (items pool keys tol / psg pbx queue rest rest2 taken m k kp)
  (foreach x items
    (setq queue (append queue (list (GH:pnode (GH:segs-of (car x)) (cadr x) (if (nth 3 x) 0.0 (caddr x)) (nth 3 x)))))
    (if (and (not (nth 3 x)) (setq k (nth 4 x)) (not (member k keys))) (setq keys (cons k keys))))
  (setq psg (mapcar '(lambda (p) (GH:segs-of (car p))) pool) pbx (mapcar 'GH:segs-box psg) rest (GH:iota (length pool))
        kp (GH:pull-keys rest pool keys) rest (cadr kp))
  (foreach i (car kp) (setq taken (append taken (list i)) queue (append queue (list (GH:pnode (nth i psg) (cadr (nth i pool)) (caddr (nth i pool)) nil)))))
  (while queue
    (setq m (car queue) queue (cdr queue) rest2 nil k nil)
    (foreach i rest
      (if (and (GH:box-ov (nth 4 m) (nth i pbx) (+ tol (/ (max (caddr (nth i pool)) (nth 2 m)) 2.0)))
               (or (GH:touch (car m) (nth i psg) tol)
                   (and (nth 3 m) (GH:end-in (car m) (cadr m) (nth i psg) (caddr (nth i pool)) tol))))
        (progn
          (setq taken (append taken (list i)) queue (append queue (list (GH:pnode (nth i psg) (cadr (nth i pool)) (caddr (nth i pool)) nil))))
          (if (and (nth 3 (nth i pool)) (not (member (nth 3 (nth i pool)) keys))) (setq keys (cons (nth 3 (nth i pool)) keys) k T)))
        (setq rest2 (cons i rest2))))
    (setq rest (reverse rest2))
    (if k
      (progn
        (setq kp (GH:pull-keys rest pool keys) rest (cadr kp))
        (foreach i (car kp) (setq taken (append taken (list i)) queue (append queue (list (GH:pnode (nth i psg) (cadr (nth i pool)) (caddr (nth i pool)) nil))))))))
  taken)

;; 새 선의 열린 끝이 지난 벽 안이면 지난 중심선까지 (곧은 끝만 — 늘이거나 줄여 T자). YGN CAD Core SkelGroups.Snap 과 같은 셈.
;; fresh ((조각들 닫힘) …) · olds ((조각sg 두께) …), 조각 = (A B 볼록) → ((고친 조각들 …) (옮긴 끝 (그린 점 이은 점) …))
(defun GH:snap-ends (fresh olds tol / out moves ax st pc P Q D L best bd th X dx hs)
  (foreach f fresh
    (setq ax (car f))
    (if (and ax (not (cadr f)))
      (foreach st '(T nil)
        (setq pc (if st (car ax) (last ax)))
        (if (< (abs (caddr pc)) 1e-12)
          (progn
            (setq P (if st (car pc) (cadr pc)) Q (if st (cadr pc) (car pc)) L (GH:dist P Q) best nil bd nil)
            (if (> L 1e-9)
              (progn
                (setq D (GH:v* (GH:v- P Q) (/ 1.0 L)))
                (foreach o olds
                  (setq th (cadr o))
                  (foreach s (car o)
                    (if (and (GH:box-in (nth 8 s) P (+ (/ th 2.0) tol))
                             (<= (setq dx (caddr (GH:sclose s P))) (+ (/ th 2.0) tol)) (> dx tol))
                      (foreach X (GH:hits (GH:sg (GH:v- P (GH:v* D th)) (GH:v+ P (GH:v* D th)) 0.0) s)
                        (if (and (<= (caddr (GH:sclose s X)) (/ tol 10.0))
                                 (<= (GH:dist X P) th)
                                 (> (GH:dot (GH:v- X Q) D) (max tol (/ L 2.0)))
                                 (or (null bd) (< (GH:dist X P) bd)))
                          (setq best X bd (GH:dist X P)))))))
                (if best
                  (progn
                    (setq moves (cons (list P best) moves))
                    (if st
                      (setq ax (cons (list best (cadr pc) 0.0) (cdr ax)))
                      (setq ax (append (reverse (cdr (reverse ax))) (list (list (car pc) best 0.0)))))))))))))
    (setq out (cons ax out)))
  (list (reverse out) (reverse moves)))

;; 지난 중심선들(쓴 자리 · 두께)의 벽 띠 테두리 → (테두리 조각sg들 상자) — 이음을 따진 띠 + 혼자 띠(평평한 끝: 따로 만든 벽 · 1.6 이하 벽의 끝도).
;; olds ((조각들 두께) …). YGN CAD Core SkelGroups.Edges 와 같은 셈 (대조 cad/tests-core/skel_group_cases.json ← tests/gh_group_cases.py)
(defun GH:band-edges (olds / axes pcs edges box)
  (foreach o olds (foreach a (car o) (setq axes (cons (append a (list (cadr o))) axes))))
  (if (setq pcs (GH:wprep (reverse axes)))
    (foreach bd (append (GH:wbands pcs) (apply 'append (mapcar '(lambda (p) (GH:wbands (list p))) pcs)))
      (setq bd (GH:bandsegs bd) edges (append edges (car bd)) box (if box (GH:boxu box (cadr bd)) (cadr bd)))))
  (if edges (list edges box)))
;; 띠 테두리를 가로 칸으로 나눔 (큰 도면 — 점마다 그 칸의 조각만 봄, 결과는 나누지 않은 것과 같음): → (칸수 y0 칸높이 칸들 tol)
;; 칸마다 그 칸 높이 ± tol 에 걸친 조각 — tol 이하로 찾을 때만 씀
(defun GH:erows (edges box tol / n y0 ch rows j lo hi row)
  (setq n (min 48 (max 1 (fix (sqrt (length edges))))) y0 (cadr box) ch (/ (- (cadddr box) y0) n) j 0)
  (if (< ch 1e-9) (setq n 1 ch 1e30))
  (while (< j n)
    (setq lo (- (+ y0 (* j ch)) tol) hi (+ y0 (* (1+ j) ch) tol) row nil)
    (foreach es edges (if (and (<= (cadr (nth 8 es)) hi) (>= (cadddr (nth 8 es)) lo)) (setq row (cons es row))))
    (setq rows (cons (reverse row) rows) j (1+ j)))
  (list n y0 ch (reverse rows) tol))
(defun GH:erow (g y) (nth (max 0 (min (1- (car g)) (fix (/ (- y (cadr g)) (caddr g))))) (cadddr g)))
;; 조각들(sg)이 모두 띠 테두리 위에 놓였는지 — 끝 · 가운데(호는 1/4 · 3/4 도)가 tol 안. eb = (조각들 상자 [가로 칸])
(defun GH:on-edges (sg eb tol / ok bx g)
  (setq ok (and sg eb) bx (GH:segs-box sg) g (if (and (caddr eb) (<= tol (nth 4 (caddr eb)))) (caddr eb)))
  (if (and ok (not (and (GH:box-in (cadr eb) (list (car bx) (cadr bx)) tol) (GH:box-in (cadr eb) (list (caddr bx) (cadddr bx)) tol)))) (setq ok nil))
  (foreach s sg
    (foreach p (append (list (car s) (cadr s) (GH:sat s 0.5)) (if (nth 3 s) (list (GH:sat s 0.25) (GH:sat s 0.75))))
      (if (and ok (not (vl-some '(lambda (es) (and (GH:box-in (nth 8 es) p tol) (<= (caddr (GH:sclose es p)) tol))) (if g (GH:erow g (cadr p)) (car eb)))))
        (setq ok nil))))
  ok)

;; 지난 벽 (그림으로 찾기) — 띠 테두리 위에만 놓인 선 · 호 · 폴리선 (레이어 lays 중 하나 · 공간 sp · 우리 표시 없는 것).
;; sets = 중심선 묶음들 — 묶음마다 ((조각들 두께) …): 지난 기록(쓴 자리) · 이번에 쓸 자리(그 자리에 이미 그린 벽 — 기록 없는 벽도 같은 벽으로). 어느 한 묶음의 테두리 위면 지난 벽 → enames
(defun GH:old-walls (sets lays sp tol / ebs eb ss i e d sg out)
  ;; 후보(그 레이어의 선)가 있을 때만 띠를 셈 — 처음 그리는 도면은 가볍게
  (if (setq ss (ssget "_X" (list '(0 . "LINE,ARC,LWPOLYLINE") (cons 8 (GH:join (mapcar 'GH:wc-esc lays) ",")) (cons 410 sp))))
    (progn
      (foreach o sets (if (and o (setq eb (GH:band-edges o))) (setq ebs (cons (append eb (list (GH:erows (car eb) (cadr eb) tol))) ebs))))
      (setq i 0)
      (while (and ebs (< i (sslength ss)))
        (setq e (ssname ss i) i (1+ i) d (entget e '("*")))
        (if (and (not (vl-some '(lambda (x) (wcmatch (strcase (car x)) "HY_*,WUX_*")) (cdr (assoc -3 d))))
                 (setq sg (GH:axes-of e (/ tol 4.0)))
                 (setq sg (GH:segs-of (car sg)))
                 (vl-some '(lambda (b) (GH:on-edges sg b tol)) ebs))
          (setq out (cons e out))))))
  (reverse out))

;; 이름 → wcmatch 무늬 (특수 글자 앞에 `)
(defun GH:wc-esc (n / o i c)
  (setq o "" i 1)
  (while (<= i (strlen n))
    (setq c (substr n i 1) i (1+ i) o (strcat o (if (vl-string-search c "#@.*?~[]-,`") "`" "") c)))
  o)

;; 묶음의 벽 (HY_SKELW — 공간 sp)
(defun GH:group-walls (gids sp / ss i e out)
  (if (and gids (setq ss (ssget "_X" (list '(-3 ("HY_SKELW")) (cons 410 sp)))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) i (1+ i))
        (if (member (GH:wall-group e) gids) (setq out (cons e out))))))
  (reverse out))

;; 공간 sp 에서 상자 bx 안의 YGN CAD 문 · 창 (HY_OPENING · HY_OPENING_REC 블록) 수
(defun GH:openings-in (bx sp / ss i e n p seen)
  (setq n 0)
  (if bx
    (foreach app '("HY_OPENING_REC" "HY_OPENING")
      (if (setq ss (ssget "_X" (list '(0 . "INSERT") (list -3 (list app)) (cons 410 sp))))
        (progn
          (setq i 0)
          (while (< i (sslength ss))
            (setq e (ssname ss i) i (1+ i) p (cdr (assoc 10 (entget e))))
            (if (and p (not (member e seen)) (GH:box-in bx (GH:2d p) 0.0)) (setq n (1+ n) seen (cons e seen))))))))
  n)
;; 객체 범위 (x0 y0 x1 y1) — 중심선 읽기와 같은 길로 (호 볼록까지), 못 읽으면 nil
(defun GH:ent-box (e stol / ax o)
  (if (setq ax (GH:axes-of e stol))
    (foreach sg (GH:segs-of (car ax)) (setq o (if o (GH:boxu o (nth 8 sg)) (nth 8 sg)))))
  o)
;; YGN CAD 가 켜져 있는지 (레이어 이름표 함수가 있음)
(defun GH:ygn-p ( / x) (and (setq x (vl-catch-all-apply 'ygn-layer (list "wall"))) (not (vl-catch-all-error-p x))))

;; YGN CAD 로 연결한 중심선(HY_WALL wl1 C) 중 새 선에 닿는 것 수 (공간 sp)
(defun GH:ygn-near (fresh sp tol stol / ss i e ax n)
  (setq n 0)
  (if (and fresh (setq ss (ssget "_X" (list '(-3 ("HY_WALL")) (cons 410 sp)))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) i (1+ i))
        (if (and (GH:ygn-linked-p e) (= (cdr (cadr (GH:xd e "HY_WALL"))) "C") (setq ax (GH:axes-of e stol))
                 (vl-some '(lambda (f) (GH:touch f (GH:segs-of (car ax)) tol)) fresh))
          (setq n (1+ n))))))
  n)

;; link = nil (GH) · T (GHL)
(defun GH:main (link / *error* doc undo_open filt ss items nets e tg ax z ext inn just olds voids stol tl tol base i n
                       wux ygn walled linkedOff zero bad mode note tolp mark go p v said wl spc res walls fail outs rs
                       comps groups g gnets used net wallsAll gaxes made mv tail ext0 inn0 just0 rerun drawn edited
                       sp keys wkeys wlost pool pulled esc gids igrp gid oldw nw allw mt ers ersN lays sn snaps ygnNear opn obox x2 lcomp pouts
                       wbx bx ygnR jq jheal jcap jt jopen jtag)
  (defun *error* (msg)
    (redraw)
    (GH:ss-clear)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        ext (GH:env-thick "HyGhExtThick") inn (GH:env-thick "HyGhIntThick") just (GH:env-just)
        filt '((-4 . "<OR") (0 . "LINE,ARC,LWPOLYLINE,SPLINE,CIRCLE")
               (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 88) (-4 . "NOT>") (-4 . "AND>")
               (-4 . "OR>")))
  ;; 1) 고르기 (먼저 고른 것이 있으면 그것)
  (if (setq ss (ssget "_I" filt))
    (sssetfirst nil nil)
    (progn
      (prompt (strcat "\n" (if link "연결할 " "") "벽 뼈대(선·호·폴리선·스플라인·원)를 고르세요 — 외벽 " (GH:num ext) " " (GH:just-name just)
                      " · 내벽 " (GH:num inn) ": "))
      (setq ss (ssget filt))))
  (if (null ss)
    (princ "\n고른 선이 없습니다.")
    (progn
      ;; 2) 읽기 — 고른 선 + 닿는 지난 중심선 · 같은 묶음 · 같은 연결(GHL)을 모두 (한 뼈대로 — 1.7.0~ 지난 벽은 지우고 다시)
      (setq stol (min 0.5 (/ (min ext inn) 40.0)) wux 0 ygn 0 walled 0 linkedOff 0 zero 0 bad 0 ygnNear 0 *GH:wn* (list 0 0))
      (foreach e (GH:ss-list ss)
        (setq tg (GH:tag-full e))
        (if (null sp) (setq sp (GH:space-of e)))
        (cond
          ((GH:ygn-linked-p e) (setq ygn (1+ ygn)))
          ((assoc -3 (entget e '("WUX_CENTER"))) (setq wux (1+ wux)))
          ;; 벽을 고르면 그 벽의 묶음 · 연결 (벽은 중심선이 아님)
          ((and tg (= (car tg) "W")) (setq walled (1+ walled) wkeys (cons (cons "N" (cadr tg)) wkeys)) (if (not (member (car wkeys) keys)) (setq keys (cons (car wkeys) keys))))
          ((setq g (GH:wall-group e)) (setq walled (1+ walled) wkeys (cons (cons "G" g) wkeys)) (if (not (member (car wkeys) keys)) (setq keys (cons (car wkeys) keys))))
          ((<= (GH:len e) 1e-6) (setq zero (1+ zero)))
          ((null (setq ax (GH:axes-of e stol))) (setq bad (1+ bad)))
          (T (setq items (append items (list (list e tg (car ax) (cadr ax) (caddr ax))))))))
      (if (or items keys)
        (progn
          (setq tl (GH:ktols (mapcar '(lambda (x) (list (nth 2 x))) items) (list ext inn)) tol (max (car tl) (cadr tl))
                pool (vl-remove-if '(lambda (r) (assoc (car r) items)) (GH:old-pool sp stol))
                pulled (mapcar '(lambda (i) (nth i pool))
                               (GH:pull (mapcar '(lambda (x) (list (nth 2 x) (nth 3 x) (if (cadr x) (nth 2 (cadr x)) 0.0) (null (cadr x)) (GH:okey (car x) (cadr x)))) items)
                                        (mapcar '(lambda (r) (list (nth 2 r) (nth 3 r) (nth 8 r) (nth 5 r))) pool)
                                        keys tol)))
          (foreach r pulled (setq items (append items (list (list (car r) (cadr r) (nth 2 r) (nth 3 r) (nth 4 r))))))
          ;; 연결(GHL) · 묶음
          (setq igrp (mapcar '(lambda (x) (if (and (cadr x) (= (car (cadr x)) "S")) (GH:skel-group (car x)))) items))
          (foreach x items
            (setq tg (cadr x))
            (if (and tg (= (car tg) "C") (not (member (cadr tg) nets))) (setq nets (cons (cadr tg) nets))))
          (foreach g igrp (if (and g (not (member g gids))) (setq gids (cons g gids))))
          ;; 고른 벽 중 그 벽의 중심선을 못 찾은 것 (묶음 · 연결 번호가 고른 · 모은 중심선에 없음) — 그 벽은 그대로 (지우지 않음)
          (setq x2 (mapcar '(lambda (x) (GH:okey (car x) (cadr x))) items)
                wlost (length (vl-remove-if '(lambda (k) (member k x2)) wkeys)))
          ;; 새 선 끝이 지난 벽 안이면 지난 중심선까지 (T자)
          (setq sn (GH:snap-ends (mapcar '(lambda (x) (list (nth 2 x) (nth 3 x))) (vl-remove-if 'cadr items))
                                 (mapcar '(lambda (x) (list (GH:segs-of (nth 2 x)) (nth 2 (cadr x)))) (vl-remove-if-not 'cadr items))
                                 tol)
                snaps (cadr sn) sn (car sn))
          ;; 이은 선은 그린 모양을 (nth 5) 에 — 고쳐 쓸 때 지금 모양과 견줌
          (setq items (mapcar '(lambda (x) (if (cadr x) x (progn (setq x2 (if (GH:same-axes (car sn) (nth 2 x)) x (list (car x) nil (car sn) (nth 3 x) (nth 4 x) (nth 2 x))) sn (cdr sn)) x2))) items))
          (setq ygnNear (GH:ygn-near (mapcar '(lambda (x) (GH:segs-of (nth 2 x))) (vl-remove-if 'cadr items)) sp tol stol))))
      (if (null items)
        (princ (strcat "\n[알림] 벽을 만들 선이 없습니다"
                       (GH:skip-note zero bad linkedOff ygn wux walled) "."))
        (progn
          ;; 3) 세션 — 다시 고르면 지난 벽들의 가장 많은 값으로 시작 (GHL 1.5 연결은 그 두께로)
          (setq z (nth 4 (car items)) rerun nil olds nil voids nil drawn 0 edited 0)
          (foreach x items
            (setq tg (cadr x))
            (if tg
              (progn
                (setq rerun T)
                (if (null (nth 3 tg)) (setq olds (cons (nth 2 tg) olds)))
                (foreach v (nth 8 tg) (if (not (vl-some '(lambda (y) (GH:near y v 1e-6)) voids)) (setq voids (append voids (list v))))))))
          (if olds (setq ext (GH:most olds ext) inn (GH:most olds inn)))
          ;; 기록해 둔 그린 뼈대로 — 같은 값이면 같은 벽 (1.6.0). 지난번에 쓴 모양 그대로면 그린 자리 그대로(옮기기 · 돌리기 · 복사 · 신축은 표시 점도 같이 옮겨짐),
          ;; 꼭짓점 수가 같으면 꼭짓점마다 지금 자리 + 그린 자리까지 옮김 (그립으로 고친 꼭짓점도 그린 자리가 따라옴), 아니면 지금 자리에서 지난 값만큼 되돌려 셈
          (setq base (mapcar '(lambda (x / tg th rc dax)
                                (setq tg (cadr x))
                                (if tg
                                  (progn
                                    (setq th (nth 2 tg) rc (GH:recover (nth 10 tg) (nth 9 tg) (nth 2 x) (nth 3 x)) dax (cadr rc))
                                    (if (and (nth 9 tg) (/= (car rc) "same")) (setq edited (1+ edited)))
                                    (if dax (setq drawn (1+ drawn)))
                                    (list (cond (dax) ((nth 2 x))) (nth 3 x) (if (and (nth 4 tg) (nth 3 tg) (/= (nth 3 tg) "F")) (nth 3 tg))
                                          (if (and (nth 7 tg) th (> th 0)) th) (if (nth 6 tg) (nth 5 tg))
                                          (nth 3 tg) (nth 5 tg) th (if dax T)))
                                  (list (nth 2 x) (nth 3 x) nil nil nil nil nil nil nil)))
                             items))
          (GH:ss-start base ext inn just voids)
          (setq tolp (GH:pick-tol) mark (* 3.0 tolp) go T *GH:fs* snaps
                note (strcat (if rerun (strcat " — 지난 값으로 시작" (if (> edited 0) (strcat " (모양을 고친 선 " (itoa edited) "개는 고친 자리에서)") "")) "")
                             (if pulled (strcat " · 닿은 지난 벽의 중심선 " (itoa (length pulled)) "개 같이") "")
                             (if snaps (strcat " · 지난 벽 안에서 끝난 선 " (itoa (length snaps)) "곳을 지난 중심선까지") "")))
          ;; 4) 미리보기 · 고치기
          (GH:show z mark note)
          (while go
            (initget (if *GH:su* "T N J L U" "T N J L"))
            (setq p (getpoint (strcat "\n선 누르기 = 외벽 ↔ 내벽 · 방 안 = 중정 · Enter = 벽 만들기 — 외벽 " (GH:num *GH:se*) " " (GH:just-name *GH:sj*)
                                      " · 내벽 " (GH:num *GH:si*) " [외벽두께(T)/내벽두께(N)/외벽기준(J)/레이어(L)" (if *GH:su* "/되돌리기(U)" "") "]: ")))
            (cond
              ((null p) (setq go nil))
              ((= p "T") (if (setq v (GH:ask-mm "외벽 두께" *GH:se*)) (progn (GH:ss-ext v) (setenv "HyGhExtThick" (rtos v 2 8)) (GH:show z mark ""))))
              ((= p "N") (if (setq v (GH:ask-mm "내벽 두께" *GH:si*)) (progn (GH:ss-int v) (setenv "HyGhIntThick" (rtos v 2 8)) (GH:show z mark ""))))
              ((= p "J")
               (GH:ss-just (GH:just-next *GH:sj*))
               (setenv "HyGhExtJust" *GH:sj*)
               (princ (strcat "\n외벽 기준: " (GH:just-name *GH:sj*)
                              (cond ((= *GH:sj* "O") " (그린 선 = 벽 바깥 면)") ((= *GH:sj* "I") " (그린 선 = 벽 안쪽 면)") (T " (그린 선 = 벽 가운데)"))))
               (GH:show z mark ""))
              ((= p "L") (GH:layer-opts))
              ((= p "U") (if (GH:ss-undo) (GH:show z mark "")))
              ((listp p)
               (if (setq said (GH:ss-click (GH:2d (trans p 1 0)) tolp))
                 (progn (princ (strcat "\n" said)) (GH:show z mark ""))
                 (princ "\n선(외벽 ↔ 내벽)이나 방 안(중정)을 눌러 주세요.")))))
          (redraw)
          ;; 5) 쓰기 — 한 번에 (U 한 번)
          (vla-StartUndoMark doc)
          (setq undo_open T wl (GH:wall-layer) spc (GH:space) i 0 n 0)
          ;; 지난 벽 (1.7.0~) — 묶음 표시가 있는 벽 + 지난 중심선(쓴 자리 · 두께)의 벽 띠 테두리 위에만 놓인 표시 없는 선 (중심선을 고쳐 쓰기 전에)
          ;; 이번에 쓸 자리(토막)의 띠 테두리 위에 이미 그린 벽도 같은 벽 — 기록 없이 그린 벽(GH 1.5 이하 · 손으로 그린 벽)에 중심선을 그리고 다시 GH 해도 겹치지 않게
          (setq oldw (mapcar '(lambda (x / tg wv) (setq tg (cadr x) wv (nth 10 tg))
                                (list (cond ((if wv (GH:v->ax wv (nth 3 x)))) ((nth 2 x))) (nth 2 tg)))
                             (vl-remove-if-not '(lambda (x) (and (cadr x) (nth 2 (cadr x)) (> (nth 2 (cadr x)) 0))) items))
                nw (mapcar '(lambda (r) (list (nth 8 r) (nth 3 r))) (vl-remove-if-not '(lambda (r) (and (nth 8 r) (> (nth 3 r) 0))) (GH:pl *GH:sp* "runs")))
                allw (append oldw nw)
                ers (GH:group-walls gids sp) jtag ers lays (list wl))
          (foreach e ers (if (not (member (cdr (assoc 8 (entget e))) lays)) (setq lays (cons (cdr (assoc 8 (entget e))) lays))))
          (if allw
            (progn
              (setq mt (max 1e-6 (min 1.0 (/ (apply 'min (mapcar 'cadr allw)) 200.0))))
              (foreach e (GH:old-walls (list oldw nw) lays sp mt)
                (if (and (not (member e ers)) (not (assoc e items))) (setq ers (cons e ers))))
              (foreach o allw
                (foreach sg (GH:segs-of (car o))
                  (setq obox (if obox (GH:boxu obox (nth 8 sg)) (nth 8 sg)))))
              (if obox (setq obox (list (- (car obox) (apply 'max (mapcar 'cadr allw))) (- (cadr obox) (apply 'max (mapcar 'cadr allw)))
                                        (+ (caddr obox) (apply 'max (mapcar 'cadr allw))) (+ (cadddr obox) (apply 'max (mapcar 'cadr allw))))))))
          ;; 지운 벽 자리(wbx)는 YGN CAD 에 넘김 — 맞닿은 피난계단 벽 · 그 자리 문 · 창을 다시 맞춤 (1.7.0~ ygn-walls-redone)
          (setq ersN 0 opn (if ers (GH:openings-in obox sp) 0))
          (foreach e ers
            (setq bx (GH:ent-box e stol) x2 (GH:jn-read e))
            (if (GH:unlocked e (function (lambda (e) (entdel e) T)))
              (progn
                (setq ersN (1+ ersN) wbx (if bx (cons bx wbx) wbx))
                ;; 묶음 표시가 있는 지난 벽 중 열린 폴리선의 두 끝 = 지난 맞물림 자리 (테두리에 겹쳐 지운 표시 없는 선은 아님)
                (if (and x2 (not (caddr x2)) (member e jtag)) (setq jq (cons (car (car (cadddr x2))) (cons (car (last (cadddr x2))) jq)))))))
          ;; 기존 벽선과 맞물림 (1.9.0~) — 지난 맞물림이 연 입은 메워 두고 (벽을 옮겼으면 입도 옮겨 가게) 아래에서 새로 맞물림
          (setq jt (apply 'max (append (list *GH:se* *GH:si*) (mapcar '(lambda (r) (cond ((nth 3 r)) (0.0))) (GH:pl *GH:sp* "runs"))))
                jcap (GH:jn-cap jt)
                jheal (if jq (vl-catch-all-apply 'GH:jn-heal (list jq lays sp (mapcar 'car items) (* 6.0 jt))) 0))
          (if (vl-catch-all-error-p jheal) (setq jheal 0))
          (foreach x items
            (setq rs (vl-remove-if-not '(lambda (r) (= (car r) i)) (GH:pl *GH:sp* "runs")))
            (if rs (setq outs (append outs (mapcar '(lambda (p) (cons i p)) (GH:rewrite x rs)))) (setq n (1+ n)))
            (setq i (1+ i)))
          ;; 연결로 만들 덩어리 — GHL 이면 모두, GH 여도 GHL 연결이 든 덩어리는 연결 그대로 (1.7.0~). 나머지는 뼈대 묶음.
          (setq comps (GH:src-comps) fail 0)
          (foreach o outs
            (setq g (cdr (assoc (car o) comps)) tg (cadr (nth (car o) items)))
            (if (and (or link (and tg (= (car tg) "C"))) (not (member g lcomp))) (setq lcomp (cons g lcomp))))
          (setq esc (and lcomp (not link))
                pouts (vl-remove-if '(lambda (o) (member (cdr (assoc (car o) comps)) lcomp)) outs))
          (if pouts
            (progn
              ;; 뼈대 묶음 (1.7.0~) — 닿은 지난 묶음 중 앞의 것, 없으면 새로 (첫 중심선 핸들). 벽은 묶음 덩어리를 한 번에 합침
              (setq gid (cond ((car (vl-sort (vl-remove nil (mapcar '(lambda (o) (nth (car o) igrp)) pouts)) '<)))
                              (T (strcat "G" (cdr (assoc 5 (entget (cadr (car pouts)))))))))
              (foreach o pouts
                (GH:skel-tag (cadr o) (nth 3 (cddr o)) (GH:run-fields (cddr o)) gid)
                (GH:drop-xd (cadr o) "HY_GHL")
                (if (GH:wall-loose-p (cadr o)) (GH:put-xd (cadr o) "HY_WALL" nil)))
              (setq g (mapcar 'car pouts)
                    gaxes (GH:run-axes (vl-remove-if-not '(lambda (r) (member (car r) g)) (GH:pl *GH:sp* "runs")))
                    *GH:jn-n* nil
                    *GH:jn* (if (GH:jn-on-p)
                              (vl-catch-all-apply 'GH:jn-gather
                                (list lays sp (append (mapcar 'cadr outs) (mapcar 'car items)) (GH:jn-box gaxes (* 6.0 jcap)))))
                    *GH:jn* (if (or (null *GH:jn*) (vl-catch-all-error-p *GH:jn*)) nil (list *GH:jn* jcap))
                    res (GH:make-walls gaxes wl spc z)
                    *GH:jn* nil
                    walls (car res) fail (cadr res))
              (foreach w walls (GH:wall-tag w gid))))
          (if lcomp
            (progn
              ;; 연결 — 이어진 덩어리마다 연결 하나 (닿은 지난 연결 중 앞의 것, 없으면 새로), 지난 벽은 지우고 다시
              (foreach r (GH:scan)
                (if (and (= (nth 2 r) "W") (member (nth 3 r) nets))
                  (progn
                    (setq bx (GH:ent-box (car r) stol))
                    (if (GH:unlocked (car r) (function (lambda (e) (entdel e) T))) (setq wbx (if bx (cons bx wbx) wbx))))))
              (foreach o outs
                (setq g (cdr (assoc (car o) comps)))
                (if (and (member g lcomp) (not (assoc g groups))) (setq groups (append groups (list (list g))))))
              (foreach gr groups
                (setq g (car gr) gnets nil gaxes nil)
                (foreach o outs
                  (if (= (cdr (assoc (car o) comps)) g)
                    (progn
                      (setq tg (cadr (nth (car o) items)))
                      (if (and tg (= (car tg) "C") (not (member (cadr tg) gnets)) (not (member (cadr tg) used))) (setq gnets (cons (cadr tg) gnets)))
                      (foreach a (nth 8 (cddr o)) (setq gaxes (cons (append a (list (nth 3 (cddr o)))) gaxes))))))
                (setq net (if gnets (car (vl-sort gnets '<)) (strcat "N" (cdr (assoc 5 (entget (cadr (vl-some '(lambda (o) (if (= (cdr (assoc (car o) comps)) g) o)) outs)))))))
                      used (cons net used)
                      res (GH:make-walls (reverse gaxes) wl spc z) fail (+ fail (cadr res)))
                (foreach w (car res) (GH:set-tag w "W" net *GH:se*))
                (setq walls (append walls (car res)))
                (foreach o outs
                  (if (= (cdr (assoc (car o) comps)) g)
                    (progn
                      (GH:link-tag (cadr o) "C" net (nth 3 (cddr o)) (GH:run-fields (cddr o)))
                      (GH:drop-xd (cadr o) "HY_SKEL")
                      (if (GH:wall-loose-p (cadr o)) (GH:put-xd (cadr o) "HY_WALL" nil))))))
              (GH:arm)))
          (setq mv (if walls (GH:move-cens (mapcar 'cadr outs)) (list 0 0 "")))
          ;; YGN CAD 1.100~ — 지운 벽 자리의 피난계단 벽 · 문 · 창을 새 벽에 다시 맞춤 (같은 U). 1.99 이하면 함수가 없어 오류 → 문 · 창 알림
          (if (and walls wbx (GH:ygn-p))
            (progn
              (setq ygnR (vl-catch-all-apply 'ygn-walls-redone (list (reverse wbx))))
              (if (not (vl-catch-all-error-p ygnR)) (setq opn 0))))
          (vla-EndUndoMark doc)
          (setq undo_open nil)
          ;; 6) 알림
          (setq tail (GH:skip-note zero bad linkedOff ygn wux 0))
          (if (> (- walled wlost) 0) (setq tail (strcat tail " · 고른 벽 " (itoa (- walled wlost)) "개는 그 벽의 중심선으로 다시")))
          (if (> wlost 0) (setq tail (strcat tail " · 중심선을 찾지 못한 벽 " (itoa wlost) "개는 그대로")))
          (if pulled (setq tail (strcat tail " · 닿은 지난 벽의 중심선 " (itoa (length pulled)) "개 같이")))
          (if (> ersN 0) (setq tail (strcat tail " · 지난 벽 " (itoa ersN) "개를 지우고 다시")))
          (if snaps (setq tail (strcat tail " · 지난 벽 안에서 끝난 선 " (itoa (length snaps)) "곳을 지난 중심선까지 이음")))
          (if (and *GH:jn-n* (> (car *GH:jn-n*) 0)) (setq tail (strcat tail " · 기존 벽선과 " (itoa (car *GH:jn-n*)) "곳 맞물림")))
          (if (and jheal (> jheal 0)) (setq tail (strcat tail " · 지난 맞물림 " (itoa jheal) "곳은 메우고 다시")))
          (if (> (car *GH:wn*) 0) (setq tail (strcat tail " · 그린 선 " (itoa (car *GH:wn*)) "개를 벽 중심선 자리로 옮김")))
          (if (> (cadr *GH:wn*) 0) (setq tail (strcat tail " · 종류가 갈린 선 나눔 +" (itoa (cadr *GH:wn*)))))
          (if (GH:pl *GH:sp* "snaps") (setq tail (strcat tail " · 틈 " (itoa (length (GH:pl *GH:sp* "snaps"))) "곳 이음")))
          ;; 기존 벽에 맞물린 끝은 더는 열린 끝이 아님
          (setq jopen (- (length (GH:pl *GH:sp* "open")) (if (and *GH:jn-n* (> (car *GH:jn-n*) 0)) (caddr *GH:jn-n*) 0)))
          (if (> jopen 0) (setq tail (strcat tail " · 열린 끝 " (itoa jopen) "곳")))
          (if (> n 0) (setq tail (strcat tail " · 겹쳐 그린 선 " (itoa n) "개는 그대로")))
          (if (> (GH:pl *GH:sp* "flips") 0) (setq tail (strcat tail " · 두께보다 짧아 뒤집힌 마디 " (itoa (GH:pl *GH:sp* "flips")) "곳 (확인)")))
          (if (null walls)
            (princ (strcat "\n[주의] 벽체를 만들지 못했습니다" tail "."))
            (princ (strcat "\n[완료] 벽을 만들었습니다 (" (GH:ss-summary) " · 외벽 " (GH:num *GH:se*) " " (GH:just-name *GH:sj*)
                           " · 내벽 " (GH:num *GH:si*) " · 벽 " wl (GH:cen-note mv) ")" tail "."
                           (if lcomp " 중심선을 고치면 벽이 따라갑니다. 확정: GHN" "")
                           (if esc "\n[알림] 연결(GHL)된 벽은 연결 그대로 다시 만들었습니다 (닿은 새 선도 같이 연결) — 확정: GHN" "")
                           (if (and pouts (vl-some '(lambda (x) (= (car (cadr x)) "S")) (vl-remove-if-not 'cadr items)) (= ersN 0)) "\n[알림] 지난 벽을 찾지 못했습니다 — 겹친 선이 남아 있으면 지난 벽을 지워 주세요." "")
                           (if (> ygnNear 0) (strcat "\n[주의] YGN CAD 로 연결한 벽에 닿은 선이 있습니다 — 그 벽과는 맞추지 않았습니다 (YGN CAD 중심선 고르기로 같이).") "")
                           (if (> opn 0)
                             (strcat "\n[주의] 다시 만든 벽에 YGN CAD 문 · 창 " (itoa opn) "개가 있습니다 — "
                                     (if (GH:ygn-p) "YGN CAD 1.100 이상에서 문 · 창 자리를 저절로 다시 자릅니다 (지금은 문 · 창을 옮기면 다시 잘림)."
                                       "YGN CAD 가 없어 문 · 창 자리를 다시 자르지 못했습니다 (YGN CAD 에서 문 · 창을 옮기면 다시 잘림).")) "")
                           (if (and (= (type ygnR) 'LIST) (= (type (car ygnR)) 'STR))
                             (strcat (if (cadr ygnR) "\n[주의] YGN CAD: " "\n[알림] YGN CAD: ") (car ygnR) ".") "")
                           (if (and *GH:jn-n* (< (car *GH:jn-n*) 0)) "\n[주의] 기존 벽선과 맞물리다 멈췄습니다 — 닿은 곳을 확인해 주세요." "")
                           (if (> fail 0) (strcat "\n[주의] 합치지 못한 조각 " (itoa fail) "개는 따로 폴리선이 되었습니다 (겹친 곳 확인).") ""))))))))
  (GH:ss-clear)
  (princ))

;; 건너뛴 것 알림 조각
(defun GH:skip-note (zero bad linkedOff ygn wux walled / o)
  (setq o "")
  (if (> zero 0) (setq o (strcat o " · 길이 0 인 선 " (itoa zero) "개는 건너뜀")))
  (if (> bad 0) (setq o (strcat o " · 읽지 못한 곡선 " (itoa bad) "개는 건너뜀")))
  (if (> linkedOff 0) (setq o (strcat o " · 연결된 중심선 " (itoa linkedOff) "개는 건너뜀 (GHL 로 고르면 지난 값으로 다시)")))
  (if (> ygn 0) (setq o (strcat o " · YGN CAD 로 연결한 중심선 " (itoa ygn) "개는 건너뜀")))
  (if (> wux 0) (setq o (strcat o " · Y·GN 중심선 " (itoa wux) "개는 건너뜀")))
  (if (> walled 0) (setq o (strcat o " · 중심선을 찾지 못한 벽 " (itoa walled) "개는 건너뜀")))
  o)

;; 세션 비우기 (큰 목록을 남기지 않게)
(defun GH:ss-clear ()
  (setq *GH:sb* nil *GH:sp* nil *GH:sc* nil *GH:su* nil *GH:sv* nil *GH:skt* nil *GH:skj* nil *GH:fs* nil *GH:jn* nil *GH:jn-n* nil))

;;; ══════════════════════════════════════════════════════════════════════════
;;;  기존 벽선과 맞물림 (1.9.0~, 호용 2026-11-27 '분해하고 중심선을 지워 연결이 끊긴 이중선 벽 — 레이어는 벽선 — 에 새 벽을 붙이면 벽체 안에 선이 남는다')
;;;  새 벽이 기록 · 연결이 없는 벽 레이어의 이중선 벽(선 · 폴리선)에 닿거나 지나가면 한 벽처럼 맞물린다 (GH · GHS — GHL 연결 벽은 아님).
;;;  아직 리습에만 있는 셈 — YGN CAD [중심선 고르기] · HYWALL 은 같은 규칙을 Core 로 옮길 때까지 예전 그대로.
;;;  끄기: 명령줄에서 (setenv "HyGhJoin" "0") — 1.8 처럼 새 벽만 만든다 (다시 켜기 "1", GH:jn-on-p).
;;;   · 벽 몸 = 새 벽 조각의 축(중심선 + 양 끝 곧은 연장)이 차례로 지나는 나란한(2°) 두 벽선 사이.
;;;     간격은 가장 얇은 새 벽 두께의 1/5 초과 · GH:jn-cap 이하 (새 벽 두께의 3배 · 450 을 넘으면 2배 — 아직 벽으로 안 바꾼 중심선 둘을 벽으로 보지 않게).
;;;     이웃한 둘씩 짝짓되 짝 수가 가장 많게 → 조각에 걸친 짝이 많게 → 얇게 (벽 둘 사이 좁은 틈을 벽으로 보지 않게). 그 자리만큼의 네모가 '기존 벽 몸'.
;;;     벽선은 그 축에서 새 벽 폭(반 두께 ÷ sin 각) 안에 있으면 됨 — 이미 열려 있는 입 · 새 벽에서 끝나는 기존 벽도. 12° 보다 비스듬히 스치면 안 봄.
;;;   · 새 벽의 혼자 끝이 벽 몸 안이거나 면에 닿으면(면에서 잰 틈이 얇은 두께의 1/4 안 — 모자라도 · 조금 넘어도. 비스듬히 오면 끝 막음 모서리가
;;;     면에 닿는 데까지) 그 끝을 벽 몸 가운데 선까지 늘이거나 줄여 만든다.
;;;   · 기존 벽의 끝 (GH:jn-endon — 나란한 두 벽선이 같은 자리에서 끝난 곳, 끝 막음 선은 없어도 됨): 새 벽의 혼자 끝이 그 끝 막음 줄 위이거나
;;;     그 끝에서 6 × cap 안의 벽 몸 안 · 면 위이고 벽 쪽으로 바짝 되접히지 않으면(벽 방향에서 28° 밖 — 예각으로 꺾어 나가도 됨) 그 벽 몸도 '기존 벽 몸'.
;;;     끝점이 끝 막음 줄 너머여도 새 벽 끝 막음의 모서리가 그 줄을 넘어오면(옆으로 나가는 벽이 반 두께 안으로 벽 끝을 지나쳐 붙음) 같음.
;;;     끝 막음 줄에 조금 못 미친 곧은 끝(얇은 두께의 1/4 안)은 그 줄까지 늘인다.
;;;     두 벽 사이에 남는 틈 = (기존 벽을 끝 너머로 늘인 띠) ∩ (새 벽 띠를 뒤로 늘인 띠) 는 새 벽에 더해 채운다 (GH:jn-fill) —
;;;     끝 막음 줄 위 어디서 꺾어 나가든 바깥 모서리까지 찬 ㄱ자, 새 벽이 기존 벽 끝을 지나쳐 나가면 그만큼 기존 벽이 늘어난 꼴, 조금 틀어져 이어 가면 쐐기 틈을 메움.
;;;     거의 곧게 이어 가면(두 끝 줄이 1 안으로 겹침) 채우는 대신 새 벽 끝을 끝 막음 줄에 맞춰 자른다 (겹친 선 · 잔 턱이 안 남게).
;;;   · 만든 뒤: 새 벽 외곽 중 바깥쪽이 기존 벽 몸 안인 토막 · 남는 기존 벽선과 겹친 토막을 빼고, 기존 벽선 중 양옆이 새 벽 · 벽 몸에 싸인 토막(한쪽은 새 벽)을 뺀다
;;;     → T자는 기존 면이 새 벽 폭만큼 열리고, 지나가면 네 선이 열리고, 기존 벽 끝이 새 벽에 닿으면 새 벽 면이 열리고, 이어 가면 끝 막음이 없어진다.
;;;   · 나란한 짝이 없는 선 · 호 벽선 · 잠긴 레이어 · 연결된 벽(GHL · YGN CAD) · 그 밖의 표시(HY_* · WUX_*)가 있는 선은 건드리지 않는다 (묶음 표시 HY_SKELW 는 됨).
;;;     아직 그대로 두는 자리 (벽선이 남음 — 망가뜨리지는 않음): 새 벽이 기존 벽과 나란히 겹침 · 기존 벽의 모서리(꺾인 곳)에 딱 닿음 ·
;;;     기존 벽 끝 막음을 비스듬히 지나감 · 벽 쪽으로 28° 안으로 되접혀 나감 · 두께가 GH:jn-cap 을 넘는 벽 몸 · 벽선으로 남아 있는 옛 중심선.
;;;   · GHS 로 다시 만들 때는 지운 벽의 열린 끝에 맞닿아 있던 기존 벽선의 틈을 먼저 메워 한 선으로 되돌린다 (지난 맞물림이 연 입 — 벽을 옮기면 입도 옮겨 감).
;;;     기존 벽 끝이 새 벽에 붙었던 곳(기존 벽의 끝 막음을 지운 곳)은 되살리지 않는다.
;;; ══════════════════════════════════════════════════════════════════════════

;; 객체 → 길 (ename 종류 닫힘 꼭짓점들) — 꼭짓점 = (점 볼록). 선 · 호 · 폴리선 (호 · 폴리선은 법선이 +Z 인 것만 — 그대로 고쳐 쓸 수 있는 것), 못 읽으면 nil
(defun GH:jn-read (e / d ty zn a b c r a0 a1 sw pts bus)
  (setq d (entget e) ty (cdr (assoc 0 d))
        zn (if (assoc 210 d) (caddr (cdr (assoc 210 d))) 1.0))
  (cond
    ((= ty "LINE")
     (setq a (GH:2d (cdr (assoc 10 d))) b (GH:2d (cdr (assoc 11 d))))
     (if (> (GH:dist a b) 1e-9) (list e ty nil (list (list a 0.0) (list b 0.0)))))
    ((< zn (- 1.0 1e-9)) nil)
    ((= ty "ARC")
     (setq c (GH:2d (cdr (assoc 10 d))) r (cdr (assoc 40 d)) a0 (cdr (assoc 50 d)) a1 (cdr (assoc 51 d))
           sw (GH:sweep a0 a1 1))
     (if (and (> r 1e-9) (> sw 1e-9))
       (list e ty nil (list (list (GH:v+ c (GH:pol a0 r)) (GH:tan (/ sw 4.0))) (list (GH:v+ c (GH:pol a1 r)) 0.0)))))
    ((= ty "LWPOLYLINE")
     (foreach g d
       (cond ((= (car g) 10) (setq pts (cons (list (cadr g) (caddr g)) pts) bus (cons 0.0 bus)))
             ((and (= (car g) 42) bus) (setq bus (cons (cdr g) (cdr bus))))))
     (if (cdr pts)
       (list e ty (= 1 (logand 1 (cdr (assoc 70 d)))) (mapcar 'list (reverse pts) (reverse bus)))))))

;; 길의 변 조각들 (차례대로 — 닫힌 길은 끝 → 처음 변까지)
(defun GH:jn-segs (r / vs p out)
  (setq vs (cadddr r) p vs)
  (while (cdr p)
    (setq out (cons (GH:sg (car (car p)) (car (cadr p)) (cadr (car p))) out) p (cdr p)))
  (if (and (caddr r) (cdr vs)) (setq out (cons (GH:sg (car (last vs)) (car (car vs)) (cadr (last vs))) out)))
  (reverse out))

;; 객체를 길 (닫힘 꼭짓점들) 대로 고침
(defun GH:jn-set (e ty path / d o vs i c)
  (setq d (entget e) vs (cadr path))
  (cond
    ((= ty "LINE")
     (entmod (subst (cons 11 (append (car (cadr vs)) (list (cadddr (assoc 11 d)))))
                    (assoc 11 d)
                    (subst (cons 10 (append (car (car vs)) (list (cadddr (assoc 10 d))))) (assoc 10 d) d))))
    ((= ty "ARC")
     (setq o (vlax-ename->vla-object e) c (GH:2d (cdr (assoc 10 d))))
     (vla-put-StartAngle o (GH:norm0 (GH:vang (GH:v- (car (car vs)) c))))
     (vla-put-EndAngle o (GH:norm0 (GH:vang (GH:v- (car (cadr vs)) c))))
     T)
    (T
     (setq o (vlax-ename->vla-object e) i 0)
     (vlax-put o 'Coordinates (apply 'append (mapcar 'car vs)))
     (foreach v vs (vla-SetBulge o i (cadr v)) (setq i (1+ i)))
     (vla-put-Closed o (if (car path) :vlax-true :vlax-false))
     T)))

;; 객체 e 와 같은 공간 · 속성 · 표시로 길 하나를 새 객체로 → ename | nil
(defun GH:jn-like (e ty path / d props xd vs z c)
  (setq d (entget e '("*"))
        props (vl-remove-if-not '(lambda (x) (member (car x) '(67 410 8 6 62 370 48 420 430 440 60))) d)
        xd (assoc -3 d) vs (cadr path))
  (if (cond
        ((= ty "LINE")
         (setq z (cadddr (assoc 10 d)))
         (entmake (append (list '(0 . "LINE")) props
                          (list (cons 10 (append (car (car vs)) (list z))) (cons 11 (append (car (cadr vs)) (list z))))
                          (if xd (list xd)))))
        ((= ty "ARC")
         (setq c (cdr (assoc 10 d)))
         (entmake (append (list '(0 . "ARC")) props
                          (list (cons 10 c) (assoc 40 d)
                                (cons 50 (GH:norm0 (GH:vang (GH:v- (car (car vs)) (GH:2d c)))))
                                (cons 51 (GH:norm0 (GH:vang (GH:v- (car (cadr vs)) (GH:2d c))))))
                          (if xd (list xd)))))
        (T
         (entmake (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity")) props
                          (list '(100 . "AcDbPolyline") (cons 90 (length vs)) (cons 70 (if (car path) 1 0))
                                (cons 38 (cond ((cdr (assoc 38 d))) (0.0))))
                          (apply 'append (mapcar '(lambda (v) (list (cons 10 (car v)) (cons 42 (cadr v)))) vs))
                          (if xd (list xd))))))
    (entlast)))

;; 길 기록의 객체를 남은 길들로 — 첫 길은 그 객체를 고치고 나머지는 같은 속성 · 표시의 새 객체, 남은 길이 없으면 지움 → 남은 enames
(defun GH:jn-write (rec paths / e ty out x)
  (setq e (car rec) ty (cadr rec))
  (if (null paths)
    (progn (entdel e) nil)
    (progn
      (foreach p (cdr paths) (if (setq x (GH:jn-like e ty p)) (setq out (cons x out))))
      (GH:jn-set e ty (car paths))
      (cons e (reverse out)))))

;; 이어진 토막들 ((변번호 조각 t0 t1) …) → 꼭짓점들
(defun GH:jn-rverts (r / out e t0 t1 lastp)
  (foreach el r
    (setq e (cadr el) t0 (caddr el) t1 (cadddr el)
          out (cons (list (if (<= t0 0.0) (car e) (GH:sat e t0))
                          (if (nth 3 e) (GH:tan (/ (* (nth 7 e) (- t1 t0)) 4.0)) 0.0))
                    out)
          lastp (if (>= t1 1.0) (cadr e) (GH:sat e t1))))
  (reverse (cons (list lastp 0.0) out)))

;; 길(닫힘 꼭짓점들)의 변을 cutters(조각들)와 만나는 곳에서 나눠 keepfn(조각 t0 t1) 이 nil 인 토막을 뺀다 (GH:outline 과 같은 나눔).
;; → nil (뺀 것 없음 — 그대로) | (남은 길들) — 남은 것이 없으면 (nil)
(defun GH:jn-carve (closed verts cutters keepfn on / k len cuts ce ts tl t0 t1 subs drop runs cur)
  (setq k 0)
  (foreach e (GH:jn-segs (list nil nil closed verts))
    (setq len (GH:slen e))
    (if (> len on)
      (progn
        (setq cuts nil)
        (foreach f cutters
          (if (GH:box-ov (nth 8 e) (nth 8 f) on)
            (foreach h (append (GH:hits e f) (list (car f) (cadr f)))
              (setq ce (GH:sclose e h))
              (if (and (<= (caddr ce) on) (<= (caddr (GH:sclose f h)) on)) (setq cuts (cons (cadr ce) cuts))))))
        (setq ts (list 0.0) tl 0.0)
        (foreach x (vl-sort (vl-remove-if-not '(lambda (x) (and (> (* x len) on) (> (* (- 1.0 x) len) on))) cuts) '<)
          (if (> (* (- x tl) len) on) (setq ts (cons x ts) tl x)))
        (setq ts (reverse (cons 1.0 ts)))
        (while (cdr ts)
          (setq t0 (car ts) t1 (cadr ts) ts (cdr ts))
          (if (apply keepfn (list e t0 t1))
            (setq subs (cons (list k e t0 t1 T) subs))
            (setq subs (cons (list k e t0 t1 nil) subs) drop T)))))
    (setq k (1+ k)))
  (if drop
    (progn
      (setq subs (reverse subs))
      ;; 남은 토막을 이어진 것끼리 (같은 변의 이웃 토막은 하나로)
      (foreach s subs
        (if (nth 4 s)
          (if (and cur (= (car (car cur)) (car s)) (equal (cadddr (car cur)) (caddr s) 1e-12))
            (setq cur (cons (list (car s) (cadr s) (caddr (car cur)) (cadddr s)) (cdr cur)))
            (setq cur (cons (list (car s) (cadr s) (caddr s) (cadddr s)) cur)))
          (if cur (setq runs (cons (reverse cur) runs) cur nil))))
      (if cur (setq runs (cons (reverse cur) runs)))
      (setq runs (reverse runs))
      ;; 닫힌 길: 처음 · 끝 토막이 모두 남았으면 끝 묶음 뒤에 첫 묶음
      (if (and closed (cdr runs) (nth 4 (car subs)) (nth 4 (last subs)))
        (setq runs (cons (append (last runs) (car runs)) (cdr (reverse (cdr (reverse runs)))))))
      (list (mapcar '(lambda (r) (list nil (GH:jn-rverts r))) runs)))))

;; 맞물릴 기존 벽선 — 공간 sp · 레이어 lays 의 선 · 호 · 폴리선 중 skip(이번 중심선 등)이 아니고, 연결된 벽(GHL · YGN CAD) · 중심선 · 그 밖의 표시(HY_* · WUX_*)가
;; 없고(묶음 표시 HY_SKELW 는 됨) 잠기지 않은 것. box = 볼 범위 (nil 이면 모두) → 길 기록들 (ename 종류 닫힘 꼭짓점들 상자)
(defun GH:jn-gather (lays sp skip box / ss i e r bx out)
  (if (setq ss (ssget "_X" (list '(0 . "LINE,ARC,LWPOLYLINE") (cons 8 (GH:join (mapcar 'GH:wc-esc lays) ",")) (cons 410 sp))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) i (1+ i))
        (if (and (not (member e skip))
                 (not (vl-some '(lambda (x) (and (wcmatch (strcase (car x)) "HY_*,WUX_*") (/= (strcase (car x)) "HY_SKELW")))
                               (cdr (assoc -3 (entget e '("*"))))))
                 (not (GH:locked-p e))
                 (setq r (GH:jn-read e)))
          (progn
            (setq bx nil)
            (foreach s (GH:jn-segs r) (setq bx (if bx (GH:boxu bx (nth 8 s)) (nth 8 s))))
            (if (and bx (or (null box) (GH:box-ov bx box 0.0))) (setq out (cons (append r (list bx)) out))))))))
  out)

;; 길 기록들의 곧은 변 (벽 몸의 면이 될 수 있는 선)
(defun GH:jn-lines (recs / out)
  (foreach r recs
    (foreach s (GH:jn-segs r)
      (if (and (not (nth 3 s)) (> (GH:slen s) 1e-6)) (setq out (cons s out)))))
  out)

;; 맞물림 켬 · 끔 — 환경 변수 HyGhJoin 이 "0" 이면 끔 (1.8 처럼 새 벽만 만들고 기존 벽선은 그대로). 명령줄에서 (setenv "HyGhJoin" "0") · 다시 켜기 "1".
;; 끈 동안에도 GHS 다시 고르기의 메우기(GH:jn-heal — 지난 맞물림이 연 입을 한 선으로)는 한다
(defun GH:jn-on-p () (not (equal (getenv "HyGhJoin") "0")))

;; 벽 몸으로 볼 두 벽선의 간격 상한 — 새 벽(가장 두꺼운 것) 두께 tk 의 3배, 450(보통 벽 두께 상한 · mm 도면)을 넘으면 2배까지.
;; 얇은 칸막이(100)가 두꺼운 벽(300)에 붙는 것은 받고, 두께의 2배보다 넓은 나란한 두 선(벽으로 안 바꾼 중심선 · 좁은 샤프트)은 벽 몸으로 안 봄
(defun GH:jn-cap (tk) (min (* 3.0 tk) (max (* 2.0 tk) 450.0)))

;; 점 m (방향 dir) 이 곧은 선들 중 하나 위에 나란히 놓였는가
(defun GH:jn-on-line (lines m dir on / hit)
  (foreach f lines
    (if (and (null hit) (GH:box-in (nth 8 f) m on) (<= (abs (GH:crs dir (GH:stan f 0.0))) 1e-6) (<= (caddr (GH:sclose f m)) on))
      (setq hit T)))
  hit)

;; 길 꼭짓점들을 거꾸로 (볼록은 변마다 — 부호를 바꿔 앞 꼭짓점에)
(defun GH:jn-rev (vs / out)
  (setq vs (reverse vs))
  (while (cdr vs)
    (setq out (cons (list (car (car vs)) (- (cadr (cadr vs)))) out) vs (cdr vs)))
  (reverse (cons (list (car (car vs)) 0.0) out)))

;; 조각들((A B 볼록 …) …)의 상자를 pad 만큼 넓혀
(defun GH:jn-box (axes pad / bx)
  (foreach a axes
    (setq bx (if bx (GH:box+ (GH:box+ bx (car a)) (cadr a)) (GH:box2 (car a) (cadr a)))))
  (if bx (list (- (car bx) pad) (- (cadr bx) pad) (+ (caddr bx) pad) (+ (cadddr bx) pad))))

;; i 번 조각의 시작(st) · 끝이 혼자 끝인지 — 다른 새 조각이 안 닿음 (GH:wend 와 같은 거리)
(defun GH:jn-free (i st pcs / P tol j hit)
  (setq P (if st (car (car (nth i pcs))) (cadr (car (nth i pcs)))) tol (min 1.0 (/ (cadr (nth i pcs)) 10.0)) j 0)
  (foreach o pcs
    (if (and (/= j i) (null hit) (GH:box-in (nth 8 (car o)) P tol) (< (caddr (GH:sclose (car o) P)) tol)) (setq hit T))
    (setq j (1+ j)))
  (not hit))

;; 조각(sg · 반 두께)의 축 — 조각 + 양 끝 곧은 연장 R — 이 기존 곧은 벽선의 받침 선과 만나는 곳 → ((s 점 방향 W) …) s 순.
;; s = 조각 시작에서 잰 자리 (연장은 음수 · 길이 너머), W = 반 두께 ÷ sin 각 (새 벽 폭이 그 선에 걸치는 반 길이). 벽선이 그 점에서 W 안에 있을 때만.
;; 같은 자리의 나란한 사건(이어진 선 · 겹친 선)은 하나로, 같은 자리에서 방향이 다르면(꼭짓점 · 모서리) 둘 다 뺌
(defun GH:jn-events (sg half lines R on / L u0 u1 parts bx fd c ad sn W s out res grp bad)
  (setq L (GH:slen sg) u0 (GH:stan sg 0.0) u1 (GH:stan sg 1.0)
        parts (list (list (GH:sg (GH:v- (car sg) (GH:v* u0 R)) (car sg) 0.0) 0)
                    (list sg 1)
                    (list (GH:sg (cadr sg) (GH:v+ (cadr sg) (GH:v* u1 R)) 0.0) 2))
        bx (nth 8 sg) bx (list (- (car bx) R) (- (cadr bx) R) (+ (caddr bx) R) (+ (cadddr bx) R)))
  (foreach f lines
    (if (GH:box-ov bx (nth 8 f) on)
      (progn
        (setq fd (GH:stan f 0.0))
        (foreach p parts
          (foreach h (GH:hits (car p) f)
            (setq c (GH:sclose (car p) h))
            (if (<= (caddr c) on)
              (progn
                (setq ad (GH:stan (car p) (cadr c)) sn (abs (GH:crs ad fd)))
                (if (and (>= sn 0.2) (<= (caddr (GH:sclose f h)) (+ (setq W (/ half sn)) on)))
                  (setq s (cond ((= (cadr p) 0) (- (GH:dist h (car sg))))
                                ((= (cadr p) 1) (* (cadr c) L))
                                (T (+ L (GH:dist h (cadr sg)))))
                        out (cons (list s h fd W) out))))))))))
  (foreach x (GH:sortby out '(lambda (a b) (< (car a) (car b))))
    (if (and grp (<= (- (car x) (car (car grp))) (* 10.0 on)))
      (if (> (abs (GH:crs (caddr x) (caddr (car grp)))) 1e-6) (setq bad T))
      (progn
        (if (and grp (not bad)) (setq res (cons (car grp) res)))
        (setq grp (list x) bad nil))))
  (if (and grp (not bad)) (setq res (cons (car grp) res)))
  (reverse res))

;; 받침 사건 둘이 한 벽의 두 면이면 → 간격 (나란함 2° 안), 아니면 nil
(defun GH:jn-gapd (a b)
  (if (<= (abs (GH:crs (caddr a) (caddr b))) 0.035)
    (abs (GH:dot (GH:v- (cadr b) (cadr a)) (GH:perp (caddr a))))))

;; 받침 사건들(s 순) → 벽 몸 짝들 ((a b) …) — 이웃한 둘씩: 짝 수가 많게 → 조각(0 ~ L)에 걸친 짝이 많게 → 얇게 → 앞에서부터
(defun GH:jn-dp (evs L dmin cap on / b1 b2 cur nx d r2 inn)
  (setq b1 (list 0 0 0.0 nil) b2 b1)
  (foreach x (reverse evs)
    (setq cur b1)
    (if (and nx (setq d (GH:jn-gapd x nx)) (> d dmin) (<= d (+ cap on)))
      (progn
        (setq inn (if (> (- (min (car nx) L) (max (car x) 0.0)) on) 1 0)
              r2 (list (1+ (car b2)) (+ (cadr b2) inn) (+ (caddr b2) d) (cons (list x nx) (cadddr b2))))
        (if (or (> (car r2) (car b1))
                (and (= (car r2) (car b1))
                     (or (> (cadr r2) (cadr b1))
                         (and (= (cadr r2) (cadr b1)) (<= (caddr r2) (+ (caddr b1) 1e-9))))))
          (setq cur r2))))
    (setq b2 b1 b1 cur nx x))
  (cadddr b1))

;; 받침 선(점 h · 방향 fd) 위 기존 벽선이 창 [x0, x1] (h 에서 fd 쪽 거리)에 걸친 범위 → (lo hi) | nil — 창 안의 틈(열려 있는 입)은 메워 봄
(defun GH:jn-hull (h fd x0 x1 lines on / nr lo hi a b c)
  (setq nr (GH:perp fd))
  (foreach f lines
    (if (and (<= (abs (GH:dot (GH:v- (car f) h) nr)) on) (<= (abs (GH:dot (GH:v- (cadr f) h) nr)) on))
      (progn
        (setq a (GH:dot (GH:v- (car f) h) fd) b (GH:dot (GH:v- (cadr f) h) fd))
        (if (> a b) (setq c a a b b c))
        (if (and (< a (- x1 on)) (> b (+ x0 on)))
          (setq lo (if lo (min lo (max a x0)) (max a x0)) hi (if hi (max hi (min b x1)) (min b x1)))))))
  (if (and lo (> (- hi lo) on)) (list lo hi)))

;; 원(c r)과 선(M0 M1)이 만나는 점 중 near 에 가까운 것
(defun GH:jn-circ (c r M0 M1 near / best bd d)
  (foreach h (GH:hits (list nil nil 1.0 T c r 0.0 0.0 nil) (GH:sg M0 M1 0.0))
    (setq d (GH:dist h near))
    (if (or (null bd) (< d bd)) (setq best h bd d)))
  best)

;; 혼자 끝을 벽 몸 가운데 선(M0 → M1)까지 늘이거나 줄인 두 꼭짓점 → (끝점 왼쪽 오른쪽) (GH:wend 와 같은 차례) | nil (조각 길이만큼 줄이거나 너무 멀리 늘임)
(defun GH:jn-end (sg half st M0 M1 L cap / P uin n1 cL cR md XL XR ok)
  (setq P (if st (car sg) (cadr sg))
        uin (if st (GH:stan sg 0.0) (GH:vneg (GH:stan sg 1.0)))
        n1 (GH:perp uin) cL (GH:v+ P (GH:v* n1 half)) cR (GH:v- P (GH:v* n1 half))
        md (GH:vunit (GH:v- M1 M0)))
  (if (nth 3 sg)
    (setq XL (GH:jn-circ (nth 4 sg) (GH:dist cL (nth 4 sg)) M0 M1 cL)
          XR (GH:jn-circ (nth 4 sg) (GH:dist cR (nth 4 sg)) M0 M1 cR))
    (setq XL (GH:linehit cL uin M0 md) XR (GH:linehit cR uin M0 md)))
  (setq ok (and XL XR))
  (foreach q (list (list XL cL) (list XR cR))
    (if ok
      (if (> (GH:dot (GH:v- (car q) (cadr q)) uin) 0.0)
        (if (>= (GH:dist (car q) (cadr q)) (* 0.9 L)) (setq ok nil))
        (if (> (GH:dist (car q) (cadr q)) (* 6.0 cap)) (setq ok nil)))))
  (if ok (list P XL XR)))

;; 볼록 다각형(점들)에서 선(점 p · 방향 d)의 왼쪽만 남김
(defun GH:jn-clip (poly p d / out prev sp cur sc)
  (if poly
    (progn
      (setq prev (last poly) sp (GH:crs d (GH:v- prev p)))
      (foreach cur poly
        (setq sc (GH:crs d (GH:v- cur p)))
        (if (>= sc 0.0)
          (progn
            (if (< sp 0.0) (setq out (cons (GH:lerp prev cur (/ sp (- sp sc))) out)))
            (setq out (cons cur out)))
          (if (>= sp 0.0) (setq out (cons (GH:lerp prev cur (/ sp (- sp sc))) out))))
        (setq prev cur sp sc))
      (reverse out))))

;; 기존 벽 끝(끝 막음 줄 E1 – E2 · 벽이 끝나는 방향 dold)의 너머이면서 새 벽 띠(끝점 Pe · 안쪽 방향 uin · 반 두께)를 뒤로 늘인 자리 =
;; 두 벽 사이에 남는 틈 (꺾어 나간 모서리의 바깥 · 비스듬히 이어 갈 때의 쐐기) → 새 벽에 더할 볼록 다각형 (점 …) | nil.
;; 넓이가 tolP² 아래이거나 2 × cap 너머까지 가면 없음. 새 벽 띠와는 tolP ÷ 10 만큼 겹치게 (맞닿기만 하면 끝자리 오차로 영역 합치기에서 금이 남을 수 있음).
;; 한 덩어리로 둔다 — 네모로 쪼개 넣으면 쪼갠 변이 합친 외곽에 가시로 남을 수 있음.
;; 늘인 띠의 옆선(기존 벽 면 줄)이 새 벽 끝 막음 줄 위에 놓이면(벽 끝 모서리 · 면 줄 위에서 직각으로 나감 — 새 벽 폭 안에서 tolP 안) 그 옆선을 새 벽 쪽으로
;; 밀어 두고 자른다 — 안 그러면 채움이 새 벽 띠와 맞닿기만 함
(defun GH:jn-fill (Pe uin half E1 E2 dold cap tolP / R n1 F1 F2 kn ku m fo lo pg q a prev far)
  (setq R (* 2.0 cap) n1 (GH:perp uin) F1 E1 F2 E2
        kn (GH:dot dold n1) ku (GH:dot dold uin))
  (if (> (abs kn) 0.9)
    (foreach pr (list (list E1 E2 T) (list E2 E1 nil))
      (setq m (GH:v* (GH:v- (car pr) (cadr pr)) (/ 1.0 (max 1e-12 (GH:dist (car pr) (cadr pr)))))
            fo (GH:dot (GH:v- (car pr) Pe) uin) lo (GH:dot (GH:v- (car pr) Pe) n1))
      (if (and (> (GH:dot m uin) 0.5)
               (<= (abs (+ fo (* (/ (- half lo) kn) ku))) tolP)
               (<= (abs (+ fo (* (/ (- (- half) lo) kn) ku))) tolP))
        (if (caddr pr)
          (setq F1 (GH:v+ E1 (GH:v* m (* 2.2 tolP))))
          (setq F2 (GH:v+ E2 (GH:v* m (* 2.2 tolP))))))))
  (setq pg (list F1 F2 (GH:v+ F2 (GH:v* dold R)) (GH:v+ F1 (GH:v* dold R)))
        pg (GH:jn-clip pg (GH:v+ Pe (GH:v* uin (* 0.1 tolP))) n1)
        pg (GH:jn-clip pg (GH:v+ Pe (GH:v* n1 half)) (GH:vneg uin))
        pg (GH:jn-clip pg (GH:v- Pe (GH:v* n1 half)) uin))
  ;; 붙은 점은 하나로 · 넓이 · 너무 멀리 간 점
  (foreach v pg
    (if (or (null q) (and (> (GH:dist v (car q)) (* 1e-3 tolP)) (> (GH:dist v (last q)) (* 1e-3 tolP))))
      (setq q (cons v q))))
  (setq pg (reverse q) a 0.0 prev (last pg))
  (foreach v pg
    (setq a (+ a (GH:crs prev v)) prev v)
    (if (>= (GH:dot (GH:v- v E1) dold) (- R tolP)) (setq far T)))
  (if (and (cddr pg) (> (abs a) (* 2.0 tolP tolP)) (not far)) pg))

;; 다각형(점들) → (조각들 상자) — GH:bandsegs 와 같은 꼴 (GH:inband 로 안팎을 봄)
(defun GH:jn-polysegs (pts / ss prev bx)
  (setq prev (last pts))
  (foreach p pts (setq ss (cons (GH:sg prev p 0.0) ss) prev p))
  (setq ss (reverse ss) bx (nth 8 (car ss)))
  (foreach s (cdr ss) (setq bx (GH:boxu bx (nth 8 s))))
  (list ss bx))

;; 혼자 끝이 기존 벽의 끝(나란한 두 벽선이 같은 자리에서 끝난 곳) 쪽에 있는가 — 끝점이 그 끝 막음 줄 위(이어 가기 · 꺾어 나가기)이거나
;; 그 끝에서 6 × cap 안의 벽 몸 안 · 면 위(겹쳐 이어 가기 · 벽 끝 가까이에서 나감). 끝 막음 선은 없어도 됨 (열린 끝 · GHS 가 겹친 끝 막음을 먼저 지운 뒤).
;; 끝 막음 줄 너머여도 새 벽 끝 막음의 모서리가 그 줄을 넘어오면(옆으로 나가는 벽이 벽 끝을 반 두께 안으로 지나쳐 붙음) 같이 봄.
;; 곧은 끝이 끝 막음 줄에 g 안으로 못 미쳤으면(78° 안으로 다가올 때) 축을 그 줄까지 늘여서 봄 → 끝 고침.
;; → (벽 몸 띠  채움|nil  끝 고침|nil) | nil.  벽 몸 띠 = 그 끝에서 몸 안쪽으로 (GH:bandsegs 꼴), 채움 = 두 벽 사이에 남는 틈 (GH:jn-fill — 볼록 다각형,
;; 꺾어 나간 모서리의 바깥 등), 끝 고침 = (끝점 왼쪽 오른쪽) (GH:jn-end 와 같은 꼴). 끝 막음 줄 위에서 거의 곧게 이어 가면(두 끝 줄이 tolP 안으로 겹침)
;; 채우는 대신 새 벽 끝을 끝 막음 줄에 맞춰 자름. 벽 쪽으로 바짝 되접히면(벽 방향에서 28° 안 — cos 0.88) 안 봄:
;; 예각으로 꺾어 나가는 것(28° 까지)은 두 벽의 바깥 면이 만나는 뾰족한 모서리까지 채움 — 그보다 누우면 새 벽이 기존 벽과 길게 겹쳐 나란한 벽에 가까움
(defun GH:jn-endon (sg half st lines cap dmin tolP g L / P uin cs e o b off lon len c Pe best bd d c1 c2 E1 E2 b1 dep dold cr fill n1 ov)
  (setq P (if st (car sg) (cadr sg))
        uin (if st (GH:stan sg 0.0) (GH:vneg (GH:stan sg 1.0))))
  ;; 벽선 끝 후보 (끝점 몸쪽방향 옆자리 세로자리 길이 볼점) — 세로자리 = 끝에서 몸 안쪽으로 잰 자리, 옆자리 = 볼 점이 그 선의 왼쪽이면 +,
  ;; 볼 점 = 끝점 (끝 막음 줄에 조금 못 미친 곧은 끝은 축을 그 줄까지 늘인 점)
  (foreach f lines
    (if (GH:box-in (nth 8 f) P (+ cap tolP (* 5.0 g)))
      (foreach pr (list (list (car f) (cadr f)) (list (cadr f) (car f)))
        (setq e (car pr) o (cadr pr) len (GH:dist e o))
        (if (> len (* 10.0 tolP))
          (progn
            (setq b (GH:v* (GH:v- o e) (/ 1.0 len))
                  lon (GH:dot (GH:v- P e) b) c (GH:dot uin b) Pe P)
            (if (and (< lon (- tolP)) (>= lon (- g)) (<= c -0.2) (not (nth 3 sg)))
              (setq Pe (GH:v- P (GH:v* uin (/ lon c))) lon 0.0))
            (setq off (GH:crs b (GH:v- Pe e)))
            ;; 끝 막음 줄 너머여도 새 벽 끝 막음의 모서리가 그 줄을 넘어오면 (비스듬히 · 옆으로 나갈 때 — 반 두께 × sin 각) 봄
            (if (and (>= lon (- (max tolP (- (* half (abs (GH:crs uin b))) tolP)))) (<= lon (min len (* 6.0 cap))) (<= (abs off) (+ cap tolP)))
              (setq cs (cons (list e b off lon len Pe) cs))))))))
  ;; 짝: 나란하고 같은 자리에서 끝나며 볼 점이 그 사이 · 새 벽이 벽 쪽으로 바짝(28° 안) 되접히지 않음 — 가장 얇은 것 (같으면 끝이 가까운 것)
  (foreach x cs
    (foreach y cs
      (if (and (< (caddr x) (caddr y))
               (> (GH:dot (cadr x) (cadr y)) 0.9994)
               (<= (abs (- (nth 3 x) (nth 3 y))) tolP)
               (<= (GH:dist (nth 5 x) (nth 5 y)) tolP)
               (<= (caddr x) tolP) (>= (caddr y) (- tolP))
               (<= (GH:dot uin (cadr x)) 0.88)
               (> (setq d (- (caddr y) (caddr x))) dmin) (<= d (+ cap tolP))
               (or (null bd) (< d (- bd tolP)) (and (<= d (+ bd tolP)) (< (nth 3 x) (nth 3 (car best))))))
        (setq best (list x y) bd d))))
  (if best
    (progn
      ;; 끝 막음 줄 위의 두 면 끝 (볼 점에서 옆자리만큼 — 왼쪽이 +)
      (setq c1 (car best) c2 (cadr best) b1 (cadr c1) lon (nth 3 c1) Pe (nth 5 c1)
            dep (min (nth 4 c1) (nth 4 c2) (+ lon (* 6.0 cap)))
            E1 (GH:v- (GH:v- Pe (GH:v* b1 lon)) (GH:v* (GH:perp b1) (caddr c1)))
            E2 (GH:v- (GH:v- Pe (GH:v* b1 lon)) (GH:v* (GH:perp b1) (caddr c2)))
            dold (GH:vneg b1) cr (GH:crs dold uin))
      (if (and (<= lon tolP) (<= (GH:dot uin b1) -0.2) (<= (* half (abs cr)) tolP)
               (setq ov (GH:jn-end sg half st E1 E2 L cap)))
        ;; 끝 막음 줄에 맞춘 두 꼭짓점이 기존 면 끝에 tolP 안이면 그 점으로 (두께가 같을 때 잔 턱이 안 남게)
        (setq ov (cons (car ov)
                       (mapcar '(lambda (q) (cond ((<= (GH:dist q E1) tolP) E1) ((<= (GH:dist q E2) tolP) E2) (q))) (cdr ov))))
        (progn
          (setq fill (GH:jn-fill Pe uin half E1 E2 dold cap tolP))
          (if (> (GH:dist Pe P) 1e-9)
            (setq n1 (GH:perp uin) ov (list P (GH:v+ Pe (GH:v* n1 half)) (GH:v- Pe (GH:v* n1 half)))))))
      (list (GH:bandsegs (list E1 E2 (GH:v+ E2 (GH:v* b1 dep)) (GH:v+ E1 (GH:v* b1 dep)) 0.0 0.0)) fill ov))))

;; 새 벽 조각들(GH:wprep) · 기존 곧은 벽선(GH:jn-lines) · 벽 두께 상한 cap → (벽 몸 띠들 끝 고침들 채움들 맞물린 끝 수) — 띠 = GH:bandsegs 꼴 (조각 넷 상자),
;; 끝 고침 = (조각번호 시작? 끝점 왼쪽 오른쪽), 채움 = 새 벽에 더해 합칠 볼록 다각형 (점 …). 벽 몸이 없으면 nil
(defun GH:jn-plan (pcs lines cap / mh ext eps on g i sg half L evs a b ha fa hb fb xb m0 m1 mg w0 w1 cva cvb lo hi A0 A1 B0 B1 q0 q1 x fr0 fr1 ghosts ovs sn gs go
                                 dmin tolP hit0 hit1 ov0 ov1 fills nend)
  (if (and pcs lines)
    (progn
      (setq mh (apply 'min (mapcar 'cadr pcs)) ext 0.0 nend 0)
      (foreach p pcs (foreach v (nth 8 (car p)) (setq ext (max ext (abs v)))))
      (setq eps (max 1e-7 (* ext 1e-11)) on (* eps 10.0)
            tolP (min 1.0 (/ mh 10.0)) dmin (max (* 0.4 mh) (* 2.0 tolP))
            g (max (/ mh 2.0) tolP) i 0)
      (foreach pc pcs
        (setq sg (car pc) half (cadr pc) L (GH:slen sg)
              evs (GH:jn-events sg half lines (* 5.0 cap) on)
              fr0 (GH:jn-free i T pcs) fr1 (GH:jn-free i nil pcs)
              hit0 nil hit1 nil ov0 nil ov1 nil)
        (if (cdr evs)
          (foreach pr (GH:jn-dp evs L dmin cap on)
            ;; 축 위에서 잰 틈: gs = 끝이 면에 못 미친 만큼 (면에서 잰 틈 g · 비스듬하면 끝 막음 모서리가 면에 닿는 데까지), go = 먼 면을 넘은 만큼
            (setq a (car pr) b (cadr pr)
                  sn (min 1.0 (/ half (cadddr a)))
                  gs (/ (max g (* half (sqrt (max 0.0 (- 1.0 (* sn sn)))))) sn)
                  go (/ g sn))
            (if (and (>= (car b) (- gs)) (<= (car a) (+ L gs)))
              (progn
                (setq ha (cadr a) fa (caddr a) hb (cadr b) fb (caddr b))
                (if (< (GH:dot fa fb) 0.0) (setq fb (GH:vneg fb)))
                (setq xb (GH:dot (GH:v- hb ha) fa)
                      m0 (min (- (cadddr a)) (- xb (cadddr b))) m1 (max (cadddr a) (+ xb (cadddr b)))
                      mg (/ half 2.0) w0 (- m0 mg) w1 (+ m1 mg)
                      cva (GH:jn-hull ha fa w0 w1 lines (* 10.0 on))
                      cvb (GH:jn-hull hb fb (- w0 xb) (- w1 xb) lines (* 10.0 on)))
                (if (and cva cvb)
                  (progn
                    (setq lo (max (car cva) (+ (car cvb) xb)) hi (min (cadr cva) (+ (cadr cvb) xb)))
                    (if (> (- hi lo) (* 100.0 on))
                      (progn
                        (setq A0 (GH:v+ ha (GH:v* fa lo)) A1 (GH:v+ ha (GH:v* fa hi))
                              B0 (GH:v+ hb (GH:v* fb (- lo xb))) B1 (GH:v+ hb (GH:v* fb (- hi xb)))
                              ghosts (cons (GH:bandsegs (list A0 A1 B1 B0 0.0 0.0)) ghosts))
                        (if (and (<= (car a) go) (>= (car b) (- gs))) (setq hit0 T))
                        (if (and (>= (car b) (- L go)) (<= (car a) (+ L gs))) (setq hit1 T))
                        ;; 혼자 끝이 이 벽 몸 안 · 면에 닿음 (새 벽 폭만큼 두 면이 다 있을 때만) → 가운데 선까지
                        (if (and (<= lo (+ m0 on)) (>= hi (- m1 on)))
                          (progn
                            (setq q0 (GH:lerp A0 B0 0.5) q1 (GH:lerp A1 B1 0.5))
                            (if (and fr1 (> (car a) go) (>= (car b) (- L go)) (setq x (GH:jn-end sg half nil q0 q1 L cap)))
                              (setq ovs (cons (cons i (cons nil x)) ovs) ov1 T))
                            (if (and fr0 (<= (car a) go) (< (car b) (- L go)) (setq x (GH:jn-end sg half T q0 q1 L cap)))
                              (setq ovs (cons (cons i (cons T x)) ovs) ov0 T))))))))))))
        ;; 기존 벽의 끝 쪽에 놓인 혼자 끝 (이어 가기 · 꺾어 나가기 · 벽 끝 가까이) — 가운데 선까지 고친 끝은 빼고
        (foreach st (list T nil)
          (if (and (if st fr0 fr1) (not (if st ov0 ov1))
                   (setq x (GH:jn-endon sg half st lines cap dmin tolP g L)))
            (progn
              (if (or (cadr x) (caddr x) (not (if st hit0 hit1))) (setq ghosts (cons (car x) ghosts)))
              (if (cadr x) (setq fills (cons (cadr x) fills)))
              (if (caddr x) (setq ovs (cons (cons i (cons st (caddr x))) ovs)) (setq nend (1+ nend))))))
        (setq i (1+ i)))
      (if ghosts (list (reverse ghosts) (reverse ovs) (reverse fills) (+ nend (length ovs)))))))

;; 띠들(GH:wbands pcs)에 끝 고침을 입힘 (호 조각은 볼록을 다시 셈)
(defun GH:jn-over (pcs bands ovs / i out sg L1 R1 L2 R2 b1 b3 hit)
  (setq i 0)
  (foreach bd bands
    (setq L1 (nth 0 bd) R1 (nth 1 bd) L2 (nth 2 bd) R2 (nth 3 bd) b1 (nth 4 bd) b3 (nth 5 bd) sg (car (nth i pcs)) hit nil)
    (foreach o ovs
      (if (= (car o) i)
        (progn
          (setq hit T)
          (if (cadr o) (setq L1 (nth 3 o) R1 (nth 4 o)) (setq L2 (nth 3 o) R2 (nth 4 o))))))
    (if (and hit (nth 3 sg))
      (setq b1 (GH:tan (/ (GH:sweep (GH:vang (GH:v- R1 (nth 4 sg))) (GH:vang (GH:v- L2 (nth 4 sg))) 1) 4.0))
            b3 (- (GH:tan (/ (GH:sweep (GH:vang (GH:v- R2 (nth 4 sg))) (GH:vang (GH:v- L1 (nth 4 sg))) -1) 4.0)))))
    (setq out (cons (list L1 R1 L2 R2 b1 b3) out) i (1+ i)))
  (reverse out))

;; 끝점 P 의 끝 고침 → (왼쪽 오른쪽) | nil (GH — 예전 방식에서 끝점으로 찾음)
(defun GH:jn-ov-at (ovs P tol / hit)
  (foreach o ovs (if (and (null hit) (< (GH:dist (nth 2 o) P) tol)) (setq hit (list (nth 3 o) (nth 4 o)))))
  hit)

;; 점 p 가 든 띠의 번호 (0 부터) | nil
(defun GH:jn-at (bands p / i hit)
  (setq i 0)
  (foreach b bands (if (and (null hit) (GH:inband b p)) (setq hit i)) (setq i (1+ i)))
  hit)

;; 새 벽(walls) 외곽 중 기존 벽 몸(ghosts) 안 토막을 빼고, 기존 벽선(recs) 중 양옆이 새 벽(bands — GH:bandsegs 꼴) · 벽 몸에 싸인 토막을 뺌
;; → (남은 새 벽 enames 맞물린 곳 수 고친 기존 벽선 수)
;; 기존 벽선은 실제로 만든 새 벽 외곽(자르기 전 모양)과 만나는 곳에서 나눈다 — 영역을 거친 외곽은 셈한 띠와 끝자리가 다를 수 있어 모서리가 어긋나지 않게.
;; 띠 안팎(GH:inband)은 토막 가운데에서만 본다.
(defun GH:jn-trim (walls bands ghosts recs / ext eps on dl nb cutG cutW exl wr r res out used nex newfn exfn)
  (setq ext 0.0)
  (foreach b (append bands ghosts) (foreach v (cadr b) (setq ext (max ext (abs v)))))
  (setq eps (max 1e-7 (* ext 1e-11)) on (* eps 10.0) dl (max (* on 5.0) 1e-3) nex 0
        nb (vl-remove-if-not '(lambda (b) (vl-some '(lambda (g) (GH:box-ov (cadr b) (cadr g) dl)) ghosts)) bands)
        cutG (apply 'append (mapcar 'car ghosts))
        exl (GH:jn-lines (vl-remove-if-not '(lambda (r) (vl-some '(lambda (g) (GH:box-ov (nth 4 r) (cadr g) dl)) ghosts)) recs))
        used (mapcar '(lambda (g) nil) ghosts)
        wr (mapcar '(lambda (w) (cons w (GH:jn-read w))) walls))
  (foreach x wr
    (if (cdr x)
      (foreach sg (GH:jn-segs (cdr x))
        (if (vl-some '(lambda (g) (GH:box-ov (nth 8 sg) (cadr g) dl)) ghosts) (setq cutW (cons sg cutW))))))
  ;; 새 벽 외곽: 양옆이 벽 몸 안이면 벽 속 선. 벽 몸 테두리 위(한쪽만 벽 몸)면 — 새 벽 바깥쪽이 벽 몸이면 벽 속 선,
  ;; 아니면 바깥 테두리인데 남는 기존 벽선과 겹쳤으면 뺌 (선이 둘 겹치지 않게)
  (setq newfn (function (lambda (e t0 t1 / tm m nr pl pr vl vr nl n2)
                 (setq tm (* 0.5 (+ t0 t1)) m (GH:sat e tm) nr (GH:perp (GH:stan e tm))
                       pl (GH:v+ m (GH:v* nr dl)) pr (GH:v- m (GH:v* nr dl))
                       vl (GH:jn-at ghosts pl) vr (GH:jn-at ghosts pr))
                 (cond
                   ((and vl vr) (setq used (GH:setnth (GH:setnth used vl T) vr T)) nil)
                   ((or vl vr)
                    (setq nl (GH:jn-at nb pl) n2 (GH:jn-at nb pr))
                    (cond ((and nl (not n2) vr) (setq used (GH:setnth used vr T)) nil)
                          ((and n2 (not nl) vl) (setq used (GH:setnth used vl T)) nil)
                          ((and (not (nth 3 e)) (GH:jn-on-line exl m (GH:stan e tm) (* 10.0 on))) nil)
                          (T T)))
                   (T T)))))
  ;; 기존 벽선: 양옆이 모두 새 벽이나 벽 몸 안 — 한쪽은 새 벽, 한쪽은 벽 몸
  (setq exfn (function (lambda (e t0 t1 / tm m nr pl pr vl vr nl n2)
                (setq tm (* 0.5 (+ t0 t1)) m (GH:sat e tm) nr (GH:perp (GH:stan e tm))
                      pl (GH:v+ m (GH:v* nr dl)) pr (GH:v- m (GH:v* nr dl))
                      vl (GH:jn-at ghosts pl) vr (GH:jn-at ghosts pr))
                (if (or vl vr)
                  (progn
                    (setq nl (GH:jn-at nb pl) n2 (GH:jn-at nb pr))
                    (not (and (or nl n2) (or vl nl) (or vr n2))))
                  T))))
  (foreach x wr
    (setq r (cdr x))
    (if (and r (setq res (GH:jn-carve (caddr r) (cadddr r) (append cutG exl) newfn on)))
      (setq out (append out (GH:jn-write r (car res))))
      (setq out (append out (list (car x))))))
  (foreach r recs
    (if (and (vl-some '(lambda (g) (GH:box-ov (nth 4 r) (cadr g) dl)) ghosts)
             (setq res (GH:jn-carve (caddr r) (cadddr r) (append cutG cutW) exfn on)))
      (progn (GH:jn-write r (car res)) (setq nex (1+ nex)))))
  (list out (length (vl-remove nil used)) nex))

;; 지운 벽의 열린 끝(pts)에 맞닿아 있던 기존 벽선의 틈을 메움 — 지난 맞물림이 연 입 (다시 만들기 전에 닫아 두고 새로 맞물림).
;; 끝이 pts 에 있고 한 줄 위에서 서로 마주 보는 두 끝(lim 안 · 가까운 것부터): 같은 폴리선의 두 끝이면 닫고, 아니면 두 길을 한 선으로 이음
;; (입의 두 꼭짓점은 한 변 위라 뺌 — 선 + 선 = 선 하나, 폴리선이 끼면 폴리선 하나) → 메운 수
(defun GH:jn-heal (pts lays sp skip lim / ext tol bx rs ends i n vs a b v d best bd cnt go ra rb va vb mg)
  (setq cnt 0)
  (if pts
    (progn
      (setq ext 0.0)
      (foreach p pts (setq ext (max ext (abs (car p)) (abs (cadr p))) bx (if bx (GH:box+ bx p) (GH:box2 p p))))
      (setq tol (max 1e-3 (* ext 1e-9))
            bx (list (- (car bx) lim) (- (cadr bx) lim) (+ (caddr bx) lim) (+ (cadddr bx) lim))
            rs (vl-remove-if '(lambda (r) (caddr r)) (GH:jn-gather lays sp skip bx))
            go T)
      (while go
        (setq ends nil i 0 best nil bd nil)
        (foreach r rs
          (if r
            (progn
              (setq vs (cadddr r) n (length vs))
              (if (and (< (abs (cadr (car vs))) 1e-12) (vl-some '(lambda (q) (GH:near q (car (car vs)) tol)) pts))
                (setq ends (cons (list i T (car (car vs)) (GH:vunit (GH:v- (car (car vs)) (car (cadr vs))))) ends)))
              (if (and (< (abs (cadr (nth (- n 2) vs))) 1e-12) (vl-some '(lambda (q) (GH:near q (car (last vs)) tol)) pts))
                (setq ends (cons (list i nil (car (last vs)) (GH:vunit (GH:v- (car (last vs)) (car (nth (- n 2) vs))))) ends)))))
          (setq i (1+ i)))
        (foreach a ends
          (foreach b ends
            (setq v (GH:v- (nth 2 b) (nth 2 a)) d (GH:vlen v))
            (if (and (or (/= (car a) (car b)) (and (cadr a) (not (cadr b))))
                     (> d tol) (<= d lim)
                     (> (GH:dot v (nth 3 a)) 0.0) (<= (abs (GH:crs (nth 3 a) v)) (max tol (* 1e-6 d)))
                     (< (GH:dot (nth 3 a) (nth 3 b)) -0.9999)
                     (or (null bd) (< d bd)))
              (setq best (list a b) bd d))))
        (if (null best)
          (setq go nil)
          (progn
            (setq a (car best) b (cadr best) ra (nth (car a) rs) rb (nth (car b) rs) cnt (1+ cnt))
            (if (= (car a) (car b))
              (progn
                (setq vs (cadddr ra))
                (if (> (length vs) 4) (setq vs (reverse (cdr (reverse (cdr vs))))))
                (GH:jn-set (car ra) (cadr ra) (list T vs))
                (setq rs (GH:setnth rs (car a) nil)))
              (progn
                (setq va (if (cadr a) (GH:jn-rev (cadddr ra)) (cadddr ra))
                      vb (if (cadr b) (cadddr rb) (GH:jn-rev (cadddr rb)))
                      mg (append (reverse (cdr (reverse va))) (cdr vb)))
                (if (or (/= (cadr ra) "LINE") (= (cadr rb) "LINE"))
                  (progn
                    (GH:jn-set (car ra) (cadr ra) (list nil mg))
                    (entdel (car rb))
                    (setq rs (GH:setnth (GH:setnth rs (car a) (list (car ra) (cadr ra) nil mg)) (car b) nil)))
                  (progn
                    (GH:jn-set (car rb) (cadr rb) (list nil mg))
                    (entdel (car ra))
                    (setq rs (GH:setnth (GH:setnth rs (car b) (list (car rb) (cadr rb) nil mg)) (car a) nil)))))))))))
  cnt)

;;; ══════════════════════════════════════════════════════════════════════════
;;;  GH — 예전 방식 (1.5 그대로, 1.8.0~ 다시 GH): 두께 하나를 묻고 고른 중심선마다 띠를 만들어 합친다.
;;;   · 판정 · 미리보기 · 기록(HY_SKEL · 묶음) 없음 — 다시 고르면 새 벽이 하나 더 생긴다 (지난 벽을 지우고 다시는 GHS).
;;;   · 두께는 HyGhThick 를 기억 (GHS 의 외벽 · 내벽 두께와 따로). 벽 · 중심선 레이어 · L 옵션은 GHS 와 같은 것.
;;;   · 기존 벽선과 맞물림 (1.9.0~): 띠를 만들기 전에 GH:jn-plan (끝 고침 · 채움 띠), 폴리선으로 이은 뒤 GH:jn-trim — GHS 와 같은 셈.
;;; ══════════════════════════════════════════════════════════════════════════

;; 끝점 P 의 두 꼭짓점 (왼쪽 오른쪽) — V_out = P 에서 선 안쪽으로 가는 방향
(defun GH:miter-points (P V_out obj curves half tol / touches inner c o2 st d2 u1 u2 S lenS b phi sn D M1 M2 L_dir R_dir PL)
  (foreach o curves
    (if (not (equal obj o))
      (progn
        (setq c (vlax-curve-getClosestPointTo o P))
        (if (< (distance P c) tol)
          (progn
            (setq touches (cons o touches))
            (if (and (>= (distance c (vlax-curve-getStartPoint o)) tol) (>= (distance c (vlax-curve-getEndPoint o)) tol))
              (setq inner T)))))))
  (setq u1 (GH:unit V_out) L_dir (list (- (cadr u1)) (car u1)) R_dir (list (cadr u1) (- (car u1))))
  (if (or (null touches) inner (> (length touches) 1))
    ;; 혼자 끝 · T자 · 세 갈래 이상: 평평하게
    (list (list (+ (car P) (* (car L_dir) half)) (+ (cadr P) (* (cadr L_dir) half)))
          (list (+ (car P) (* (car R_dir) half)) (+ (cadr P) (* (cadr R_dir) half))))
    ;; L자: 마이터
    (progn
      (setq o2 (car touches)
            st (< (distance (vlax-curve-getClosestPointTo o2 P) (vlax-curve-getStartPoint o2)) tol)
            d2 (vlax-curve-getFirstDeriv o2 (if st (vlax-curve-getStartParam o2) (vlax-curve-getEndParam o2)))
            u2 (GH:unit (if st d2 (mapcar '- d2)))
            S (list (+ (car u1) (car u2)) (+ (cadr u1) (cadr u2)))
            lenS (sqrt (+ (* (car S) (car S)) (* (cadr S) (cadr S)))))
      (if (< lenS 0.001)
        (setq b L_dir D half)                                           ; 일직선으로 이어짐
        (setq b (list (/ (car S) lenS) (/ (cadr S) lenS))
              phi (GH:acos (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2))))
              sn (sin (/ phi 2.0))
              D (if (< sn 0.05) (* half 5.0) (/ half sn))))             ; 너무 뾰족하면 줄임
      (setq M1 (list (+ (car P) (* D (car b))) (+ (cadr P) (* D (cadr b))))
            M2 (list (- (car P) (* D (car b))) (- (cadr P) (* D (cadr b))))
            PL (list (+ (car P) (* (car L_dir) half)) (+ (cadr P) (* (cadr L_dir) half))))
      (if (< (distance M1 PL) (distance M2 PL)) (list M1 M2) (list M2 M1)))))

;; 스플라인 → 지금 공간에 임시 폴리선 (닫힌 스플라인은 닫힌 폴리선). 못 만들면 nil
(defun GH:spl->pl (o spc tol / len vs pl i closed z)
  (setq len (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o))
        closed (vlax-curve-isClosed o)
        z (caddr (vlax-curve-getStartPoint o)))
  (if (> len 1e-6)
    (progn
      (setq vs (GH:sp-fit o 0.0 len tol 0))
      (if (not closed) (setq vs (append vs (list (list (GH:2d (vlax-curve-getEndPoint o)) 0.0)))))
      (setq pl (vlax-invoke spc 'AddLightWeightPolyline (apply 'append (mapcar 'car vs))) i 0)
      (foreach v vs (if (/= (cadr v) 0.0) (vla-SetBulge pl i (cadr v))) (setq i (1+ i)))
      (if closed (vla-put-Closed pl :vlax-true))
      (if z (vla-put-Elevation pl z))
      pl)))

;; 벽 두께 묻기 (L = 레이어) → 두께
(defun GH:ask-thick (dist / x)
  (while (progn (initget 6 "L") (= (type (setq x (getdist (strcat "\n벽 두께 [레이어(L)] <" (rtos dist 2 2) ">: ")))) 'STR))
    (GH:layer-opts))
  (cond (x) (dist)))

(defun GH:classic ( / *error* doc undo_open sv dist half tol ss i o curves spc regs fail p1 p2 pts1 pts2 L1 R1 L2 R2 pl cen base todo x lines ssj k n0
                tmp locked npl nbad lay nspl wl mark e made nw mv srcs jax jpcs jrecs jn jb1 jb3 jbands tr jnn)
  (defun *error* (msg)
    (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
    (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        dist (cond ((getenv "HyGhThick") (atof (getenv "HyGhThick"))) (*WUX_DIST*) (200.0)))
  (princ "\n[알림] GH — 예전 방식 (두께 하나). 외벽 · 내벽 판정 미리보기는 GHS 입니다.")
  (setq dist (GH:ask-thick dist))
  (setenv "HyGhThick" (rtos dist 2 8))
  (setq *WUX_DIST* dist)
  (prompt "\n벽 중심선(선·호·폴리선·스플라인)을 고르세요: ")
  ;; 2D 폴리선까지 (POLYLINE 중 3D 폴리선 8 · 메시 16 · 다면 메시 64 는 뺌)
  (if (null (setq ss (ssget '((-4 . "<OR") (0 . "LINE,ARC,LWPOLYLINE,SPLINE")
                                (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 88) (-4 . "NOT>") (-4 . "AND>")
                              (-4 . "OR>")))))
    (princ "\n고른 중심선이 없습니다.")
    (progn
      (setq half (/ dist 2.0) tol (min 1.0 (/ half 10.0)) i 0 n0 0 npl 0 nspl 0 nbad 0 fail 0 spc (GH:space))
      (setq sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO" "PEDITACCEPT")))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)
      (while (< i (sslength ss))
        (setq o (vlax-ename->vla-object (ssname ss i)) srcs (cons (ssname ss i) srcs))
        ;; 스플라인: 호로 이은 임시 폴리선으로 바꿔 폴리선과 같이 (임시 폴리선도 끝나면 지움)
        (if (= (vla-get-ObjectName o) "AcDbSpline")
          (if (setq x (vl-catch-all-apply 'GH:spl->pl (list o spc (min 0.5 (/ half 20.0)))))
            (if (vl-catch-all-error-p x) (setq nbad (1+ nbad) o nil) (setq tmp (cons x tmp) o x nspl (1+ nspl) npl (1- npl)))
            (setq n0 (1+ n0) o nil)))
        (cond ((null o) nil)
              ((wcmatch (vla-get-ObjectName o) "AcDbPolyline,AcDb2dPolyline")
          ;; 폴리선: 원본은 두고 분해한 조각(선·호)을 중심선으로 — 끝나면 조각만 지움
          (progn
            (setq lay (vla-Item (vla-get-Layers doc) (vla-get-Layer o)))
            (if (and (= (vla-get-Lock lay) :vlax-true) (not (member lay locked)))
              (progn (vla-put-Lock lay :vlax-false) (setq locked (cons lay locked))))
            (setq x (vl-catch-all-apply 'vlax-invoke (list o 'Explode)))
            (if (or (vl-catch-all-error-p x) (null x))
              (setq nbad (1+ nbad))
              (progn
                (setq npl (1+ npl))
                (foreach y x
                  (setq tmp (cons y tmp))
                  (if (and (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc")
                           (> (vlax-curve-getDistAtParam y (vlax-curve-getEndParam y)) 1e-6))
                    (setq curves (cons y curves))))))))   ; 겹친 마디(길이 0)는 조용히 뺌
              ((> (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)) 1e-6) (setq curves (cons o curves)))
              (T (setq n0 (1+ n0))))
        (setq i (1+ i)))
      ;; 기존 벽선과 맞물림 (1.9.0~) — 벽 레이어의 기록 · 연결 없는 이중선 벽에 닿은 혼자 끝은 그 벽 몸 가운데 선까지 늘이거나 줄여 만듦 (아래 jn-trim 이 정리)
      (setq wl (GH:wall-layer))
      (foreach o curves
        (if (and (setq x (vl-catch-all-apply 'GH:axes-of (list (vlax-vla-object->ename o) (min 0.5 (/ half 20.0))))) (not (vl-catch-all-error-p x)))
          (foreach a (car x) (setq jax (cons (append a (list dist)) jax)))))
      (if (and (GH:jn-on-p) (setq jpcs (GH:wprep (reverse jax))))
        (progn
          (setq jrecs (vl-catch-all-apply 'GH:jn-gather
                        (list (list wl) (GH:space-of (car srcs)) (append srcs (mapcar 'vlax-vla-object->ename tmp)) (GH:jn-box jax (* 6.0 (GH:jn-cap dist))))))
          (if (vl-catch-all-error-p jrecs) (setq jrecs nil))
          (if jrecs
            (progn
              (setq jn (vl-catch-all-apply 'GH:jn-plan (list jpcs (GH:jn-lines jrecs) (GH:jn-cap dist))))
              (if (vl-catch-all-error-p jn) (setq jn nil))))))
      ;; 선마다 띠 → 영역
      (foreach o curves
        (setq p1 (vlax-curve-getStartPoint o) p2 (vlax-curve-getEndPoint o)
              pts1 (GH:miter-points p1 (vlax-curve-getFirstDeriv o (vlax-curve-getStartParam o)) o curves half tol)
              pts2 (GH:miter-points p2 (mapcar '- (vlax-curve-getFirstDeriv o (vlax-curve-getEndParam o))) o curves half tol))
        (if (and jn (setq x (GH:jn-ov-at (cadr jn) (GH:2d p1) tol))) (setq pts1 x))
        (if (and jn (setq x (GH:jn-ov-at (cadr jn) (GH:2d p2) tol))) (setq pts2 x))
        (setq L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2) jb1 0.0 jb3 0.0)
        ;; L1 → R1 (시작 끝) → L2 (오른쪽 면) → R2 (끝 쪽) → L1 (왼쪽 면)
        (setq pl (vlax-invoke spc 'AddLightWeightPolyline
                              (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2))))
        (vla-put-Closed pl :vlax-true)
        (if (= (vla-get-ObjectName o) "AcDbArc")
          (progn
            ;; 반시계 호: 오른쪽 면(바깥)은 반시계로 R1→L2, 왼쪽 면(안)은 시계로 R2→L1 — 면마다 중심에서 본 각도로
            (setq cen (vlax-get o 'Center)
                  jb1 (GH:tan (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0))
                  jb3 (- (GH:tan (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0))))
            (vla-SetBulge pl 1 jb1)
            (vla-SetBulge pl 3 jb3)))
        (if jn (setq jbands (cons (GH:bandsegs (list (GH:2d L1) (GH:2d R1) (GH:2d L2) (GH:2d R2) jb1 jb3)) jbands)))
        (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
        (if (and (not (vl-catch-all-error-p x)) x) (setq regs (append regs x)) (setq fail (1+ fail)))
        (vla-Delete pl))
      ;; 기존 벽 끝과의 틈(꺾어 나간 모서리의 바깥 등)을 채우는 조각도 같이 합침 (1.9.0~ — GH:jn-fill)
      (if jn
        (foreach fl (caddr jn)
          (setq pl (vlax-invoke spc 'AddLightWeightPolyline (apply 'append fl)))
          (vla-put-Closed pl :vlax-true)
          (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
          (if (and (not (vl-catch-all-error-p x)) x)
            (setq regs (append regs x) jbands (cons (GH:jn-polysegs fl) jbands)))
          (vla-Delete pl)))
      ;; 폴리선을 나눈 임시 조각 지우기 · 잠깐 푼 레이어 다시 잠금
      (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
      (setq tmp nil)
      (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
      (setq locked nil)
      (if (null regs)
        (princ "\n[주의] 벽체를 만들지 못했습니다.")
        (progn
          ;; 합치기 — 못 합친 조각은 따로 분해 (영역으로 남기지 않음)
          (setq base (car regs) todo (list base))
          (foreach r (cdr regs)
            (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Boolean (list base 0 r)))
              (setq todo (cons r todo) fail (1+ fail))))
          ;; 영역이 남지 않을 때까지 분해
          (while todo
            (setq o (car todo) todo (cdr todo))
            (foreach y (vlax-invoke o 'Explode)
              (if (= (vla-get-ObjectName y) "AcDbRegion") (setq todo (cons y todo)) (setq lines (cons y lines))))
            (vla-Delete o))
          (setq ssj (ssadd))
          (foreach y lines
            (vl-catch-all-apply 'vla-put-Layer (list y (getvar "CLAYER")))
            (vl-catch-all-apply 'vla-put-Color (list y 256))
            (ssadd (vlax-vla-object->ename y) ssj))
          (setvar "PEDITACCEPT" 1)
          (setq mark (entlast))
          (command "_.PEDIT" "_M" ssj "" "_J" (/ tol 10.0) "")
          (setq k 0)
          (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))
          ;; 이은 벽을 벽 레이어로 (1.5.0~ — 잇기는 지금 레이어에서: 벽 레이어가 잠기거나 얼어도 이어지게)
          (setq wl (GH:wall-layer) nw 0)
          (setq e (if mark (entnext mark) (entnext)))
          (while e
            (if (wcmatch (cdr (assoc 0 (entget e))) "LWPOLYLINE,LINE,ARC") (setq made (cons e made)))
            (setq e (entnext e)))
          (foreach y lines (if (not (vlax-erased-p y)) (setq made (cons (vlax-vla-object->ename y) made))))
          (if (/= (strcase wl) (strcase (getvar "CLAYER")))
            (foreach e made
              (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Layer (list (vlax-ename->vla-object e) wl))))
                (setq nw (1+ nw)))))
          ;; 새 벽 외곽 중 기존 벽 몸 안 토막 · 기존 벽선 중 새 벽에 싸인 토막을 뺌 (1.9.0~)
          (if (and jn made)
            (progn
              (setq tr (vl-catch-all-apply 'GH:jn-trim (list made (reverse jbands) (car jn) jrecs)))
              (setq jnn (if (vl-catch-all-error-p tr) -1 (cadr tr)))))
          (setq mv (GH:move-cens srcs))
          (princ (strcat "\n[완료] 중심선 " (itoa (length curves)) "개로 벽체를 만들어 폴리선으로 이었습니다 (두께 " (rtos dist 2 2)
                         " · 벽 " wl (GH:cen-note mv)
                         (if (and jnn (> jnn 0)) (strcat " · 기존 벽선과 " (itoa jnn) "곳 맞물림") "")
                         (if (> npl 0) (strcat " · 폴리선 " (itoa npl) "개는 마디마다 나눠 셈") "")
                         (if (> nspl 0) (strcat " · 스플라인 " (itoa nspl) "개는 호로 이어 셈") "") ")."
                         (if (> n0 0) (strcat " 길이 0 인 선 " (itoa n0) "개는 건너뜀.") "")
                         (if (> nbad 0) (strcat "\n[주의] 나누지 못한 폴리선·스플라인 " (itoa nbad) "개는 건너뛰었습니다.") "")
                         (if (and jnn (< jnn 0)) "\n[주의] 기존 벽선과 맞물리다 멈췄습니다 — 닿은 곳을 확인해 주세요." "")
                         (if (> fail 0) (strcat "\n[주의] 합치지 못한 조각 " (itoa fail) "개는 따로 폴리선이 되었습니다 (겹친 곳 확인).") "")))))
      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)))
  (princ))

(defun c:GH () (GH:classic))
(defun c:GHS () (GH:main nil))
(defun c:GHL () (GH:main T))

;;; ══════════════════════════════════════════════════════════════════════════
;;;  GHL 연결 — 중심선을 고치면 명령이 끝날 때 벽을 다시 만듦 (중심선마다 제 두께)
;;; ══════════════════════════════════════════════════════════════════════════

;; 연결 표시 → (역할 연결번호 두께) 또는 nil
(defun GH:tag (e / x)
  (if (and e (setq x (cdr (assoc "HY_GHL" (cdr (assoc -3 (entget e '("HY_GHL"))))))))
    (list (cdr (nth 0 x)) (cdr (nth 1 x)) (cdr (nth 2 x)))))

;; 잠긴 레이어의 객체도 표시만은 고칠 수 있게 잠깐 풀었다 다시 잠금
(defun GH:unlocked (e fn / lay x)
  (setq lay (vla-Item (vla-get-Layers (vla-get-ActiveDocument (vlax-get-acad-object))) (cdr (assoc 8 (entget e)))))
  (if (= (vla-get-Lock lay) :vlax-true)
    (progn
      (vla-put-Lock lay :vlax-false)
      (setq x (vl-catch-all-apply fn (list e)))
      (vla-put-Lock lay :vlax-true))
    (setq x (vl-catch-all-apply fn (list e))))
  (if (vl-catch-all-error-p x) nil x))

(defun GH:set-tag (e role net thick)
  (if (null (tblsearch "APPID" "HY_GHL")) (regapp "HY_GHL"))
  (GH:unlocked e (function (lambda (e)
    (entmod (append (vl-remove-if '(lambda (x) (= (car x) -3)) (entget e))
                    (list (list -3 (list "HY_GHL" (cons 1000 role) (cons 1000 net) (cons 1040 (float thick)))))))))))

;; 연결 번호만 바꿈 (두께 · 종류 · 기준 · 중정 씨앗은 그대로)
(defun GH:retag-net (e net / v)
  (if (setq v (GH:xd e "HY_GHL"))
    (GH:put-xd e "HY_GHL" (cons (car v) (cons (cons 1000 net) (cddr v))))))

(defun GH:clear-tag (e) (GH:unlocked e (function (lambda (e) (entmod (list (cons -1 e) '(-3 ("HY_GHL"))))))))

;; 모양만 (핸들 · 소유 · 반응자 빼고) — 바뀌었는지 견줄 글
(defun GH:geo (e / d)
  (if (setq d (entget e))
    (vl-prin1-to-string (vl-remove-if '(lambda (x) (member (car x) '(-1 -2 5 102 330 360))) d))))

;; 연결된 것 모두 → ((ename 핸들 역할 연결번호 모양) ...)
(defun GH:scan ( / ss i e tg out)
  (if (setq ss (ssget "_X" '((-3 ("HY_GHL")))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (if (setq tg (GH:tag e))
          (setq out (cons (list e (cdr (assoc 5 (entget e))) (car tg) (cadr tg) (GH:geo e)) out)))
        (setq i (1+ i)))))
  out)

;; 벽 모양 서명 — 꼭짓점 · 볼록 값을 1 단위로 반올림해 정렬 (시작점 · 순서가 달라도 같은 모양이면 같음)
(defun GH:wall-sig (enames / out d)
  (foreach e enames
    (if (setq d (entget e))
      (foreach x d
        (cond ((= (car x) 10) (setq out (cons (strcat "P" (rtos (cadr x) 2 0) "," (rtos (caddr x) 2 0)) out)))
              ((and (= (car x) 42) (/= (cdr x) 0.0)) (setq out (cons (strcat "B" (rtos (cdr x) 2 3)) out)))))))
  (strcat (itoa (length enames)) "|" (apply 'strcat (mapcar '(lambda (s) (strcat s ";")) (acad_strlsort out)))))

;; 선 · 호 조각 → (시작 끝 볼록) — 호는 반시계
(defun GH:seg (o / a)
  (if (= (vla-get-ObjectName o) "AcDbArc")
    (progn
      (setq a (vla-get-TotalAngle o))
      (list (GH:2d (vlax-curve-getStartPoint o)) (GH:2d (vlax-curve-getEndPoint o)) (/ (sin (/ a 4.0)) (cos (/ a 4.0)))))
    (list (GH:2d (vlax-curve-getStartPoint o)) (GH:2d (vlax-curve-getEndPoint o)) 0.0)))

(defun GH:rev (s) (list (cadr s) (car s) (- (caddr s))))

;; 조각 잇기 (PEDIT 결합 대신 — 명령 리액터 안에서도 됨) → 이어진 조각 목록들
(defun GH:chain (segs tol / out ch go hit ns)
  (while segs
    (setq ch (list (car segs)) segs (cdr segs) go T)
    (while go
      (setq hit nil)
      (foreach s segs
        (if (not hit)
          (cond ((< (distance (car s) (cadr (last ch))) tol) (setq hit s ns s))
                ((< (distance (cadr s) (cadr (last ch))) tol) (setq hit s ns (GH:rev s))))))
      (if hit
        (setq ch (append ch (list ns)) segs (vl-remove-if '(lambda (x) (eq x hit)) segs))
        (setq go nil)))
    (setq go T)
    (while go
      (setq hit nil)
      (foreach s segs
        (if (not hit)
          (cond ((< (distance (cadr s) (car (car ch))) tol) (setq hit s ns s))
                ((< (distance (car s) (car (car ch))) tol) (setq hit s ns (GH:rev s))))))
      (if hit
        (setq ch (cons ns ch) segs (vl-remove-if '(lambda (x) (eq x hit)) segs))
        (setq go nil)))
    (setq out (cons ch out)))
  out)

;; 연결된 중심선들 → 벽 (중심선마다 제 두께) → (벽 enames, 못 읽은 중심선 수, 못 합친 조각 수). 명령 · 실행 취소 표시를 쓰지 않음.
(defun GH:net-walls (cens layer / doc spc axes th ax nbad z r)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)) nbad 0)
  (foreach e cens
    (if (null spc)
      (setq spc (if (= (strcase (cond ((cdr (assoc 410 (entget e)))) ("Model"))) "MODEL") (vla-get-ModelSpace doc) (vla-get-PaperSpace doc))))
    (setq th (nth 2 (GH:tag e)))
    (if (and th (> th 0) (setq ax (GH:axes-of e (min 0.5 (/ th 40.0)))))
      (progn
        (if (null z) (setq z (caddr ax)))
        (foreach a (car ax) (setq axes (cons (append a (list th)) axes))))
      (setq nbad (1+ nbad))))
  (setq r (GH:make-walls (reverse axes) layer spc z))
  (list (car r) nbad (cadr r)))

(defun GH:locked-p (e / l)
  (and (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e))))) (= 4 (logand 4 (cdr (assoc 70 l))))))

;; 연결을 풂 — 중심선은 뼈대 기록(HY_SKEL)으로 남김 (그린 선 자리를 알아서 다시 GH 로 골라도 두 번 옮기지 않게)
(defun GH:unlink-net (net / n f)
  (setq n 0)
  (foreach r (GH:scan)
    (if (= (nth 3 r) net)
      (progn
        (if (and (= (nth 2 r) "C") (setq f (GH:tag-full (car r))) (nth 2 f) (> (nth 2 f) 0))
          (GH:skel-tag (car r) (nth 2 f) (cdddr f) net))
        (GH:clear-tag (car r))
        (if (= (nth 2 r) "W") (GH:wall-tag (car r) net))
        (setq n (1+ n)))))
  n)

(defun GH:say (msg) (princ (strcat "\n[알림] GHL: " msg)))

;; 명령이 끝난 뒤: 지난 상태(*GH:snap*)와 견주어 연결마다 벽을 다시 만들거나 연결을 푼다
(defun GH:sync ( / cur nets old now oldh nowh erC erW newC newW modC modW cens wallsE thick lay res newWalls netId q)
  (setq cur (GH:scan))
  (foreach r (append *GH:snap* cur) (if (not (member (nth 3 r) nets)) (setq nets (cons (nth 3 r) nets))))
  (foreach net nets
    (setq old (vl-remove-if-not '(lambda (r) (= (nth 3 r) net)) *GH:snap*)
          now (vl-remove-if-not '(lambda (r) (= (nth 3 r) net)) cur)
          oldh (mapcar 'cadr old) nowh (mapcar 'cadr now)
          erC nil erW nil newC nil newW nil modC nil modW nil)
    (foreach r old
      (if (not (member (cadr r) nowh)) (if (= (nth 2 r) "C") (setq erC (cons r erC)) (setq erW (cons r erW)))))
    (foreach r now
      (setq q (assoc (cadr r) (mapcar 'cdr old)))
      (cond ((null (member (cadr r) oldh)) (if (= (nth 2 r) "C") (setq newC (cons r newC)) (setq newW (cons r newW))))
            ((/= (nth 4 r) (nth 3 q)) (if (= (nth 2 r) "C") (setq modC (cons r modC)) (setq modW (cons r modW))))))
    (cond
      ((not (or erC erW newC newW modC modW)) nil)
      ;; 통째로 복사 — 복사본은 새 연결로 (중심선마다 두께 · 종류는 그대로)
      ((and newC newW (null erC) (null erW) (null modC) (null modW))
       (setq netId (strcat "N" (cadr (car newC))))
       (foreach r (append newC newW) (vl-catch-all-apply 'GH:retag-net (list (car r) netId))))
      ;; 중심선은 그대로인데 벽만 바뀜 — 손댄 벽이니 풀고 그대로
      ((not (or erC newC modC))
       (GH:unlink-net net)
       (GH:say "벽을 직접 고쳐서 그 벽의 연결을 풀었습니다 (벽은 그대로)."))
      (T
       (setq cens (mapcar 'car (vl-remove-if-not '(lambda (r) (= (nth 2 r) "C")) now))
             wallsE (mapcar 'car (vl-remove-if-not '(lambda (r) (= (nth 2 r) "W")) now)))
       (cond
         ((null cens)
          (GH:unlink-net net)
          (GH:say "중심선이 모두 없어져 연결을 풀었습니다 (벽은 그대로)."))
         ((vl-some '(lambda (e) (not (wcmatch (cdr (assoc 0 (entget e))) "LINE,ARC,CIRCLE,LWPOLYLINE,POLYLINE,SPLINE"))) cens)
          (GH:unlink-net net)
          (GH:say "중심선이 벽을 만들 수 없는 모양(타원 등)이 되어 연결을 풀었습니다 (벽은 그대로)."))
         ((vl-some 'GH:locked-p wallsE)
          (GH:say "벽이 잠긴 레이어에 있어 다시 만들지 않았습니다."))
         (T
          (setq thick (nth 2 (GH:tag (car cens)))
                lay (cond (wallsE (cdr (assoc 8 (entget (car wallsE)))))
                          ((and (setq q (vl-catch-all-apply 'GH:wall-layer)) (not (vl-catch-all-error-p q))) q)
                          ((getvar "CLAYER")))
                res (GH:net-walls cens lay)
                newWalls (car res))
          (cond
            ((null newWalls)
             (GH:unlink-net net)
             (GH:say "벽을 다시 만들지 못해 연결을 풀었습니다 (벽은 그대로)."))
            ((and (or erW newW modW) (/= (GH:wall-sig wallsE) (GH:wall-sig newWalls)))
             (foreach e newWalls (entdel e))
             (GH:unlink-net net)
             (GH:say "벽도 직접 고쳐서 다시 만들지 않고 연결을 풀었습니다 (고친 벽 그대로)."))
            (T
             (foreach e wallsE (entdel e))
             (foreach e newWalls (GH:set-tag e "W" net thick))))))))))

;; --- 리액터: 명령 · 리습이 시작할 때 연결 상태를 적어 두고, 끝날 때 견줌 (안쪽 명령은 바깥이 끝날 때 한 번) ---
(defun GH:on-start (r a / s)
  (if (null *GH:depth*) (setq *GH:depth* 0))
  (if (= *GH:depth* 0)
    (progn
      (setq s (if (= (type (car a)) 'STR) (strcase (car a)) "")
            *GH:skip* (or (member s '("U" "UNDO" "REDO" "MREDO" "OOPS")) (wcmatch s "(C:GH*"))
            *GH:snap* (if (and *GH:on* (not *GH:skip*)) (GH:scan)))))
  (setq *GH:depth* (1+ *GH:depth*)))

(defun GH:on-end (r a / x)
  (setq *GH:depth* (max 0 (1- (cond (*GH:depth*) (1)))))
  (if (= *GH:depth* 0)
    (progn
      (if (and *GH:on* *GH:snap* (not *GH:skip*))
        (if (vl-catch-all-error-p (setq x (vl-catch-all-apply 'GH:sync)))
          (princ (strcat "\n[오류] GHL: " (vl-catch-all-error-message x)))))
      (setq *GH:snap* nil *GH:skip* nil))))

(defun GH:arm ( / )
  (foreach k '(:vlr-command-reactor :vlr-lisp-reactor)
    (foreach g (vlr-reactors k)
      (foreach r (cdr g) (if (= (vlr-data r) "GH_LINK") (vlr-remove r)))))
  (vlr-command-reactor "GH_LINK" '((:vlr-commandWillStart . GH:on-start) (:vlr-commandEnded . GH:on-end)
                                   (:vlr-commandCancelled . GH:on-end) (:vlr-commandFailed . GH:on-end)))
  (vlr-lisp-reactor "GH_LINK" '((:vlr-lispWillStart . GH:on-start) (:vlr-lispEnded . GH:on-end) (:vlr-lispCancelled . GH:on-end)))
  (setq *GH:on* T *GH:depth* 0))

(defun c:GHN ( / ss i tg nets n)
  (prompt "\n연결을 풀 벽·중심선을 고르세요 (Enter = 도면 전체): ")
  (setq ss (ssget '((-3 ("HY_GHL")))) n 0)
  (if ss
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (if (and (setq tg (GH:tag (ssname ss i))) (not (member (cadr tg) nets))) (setq nets (cons (cadr tg) nets)))
        (setq i (1+ i))))
    (foreach r (GH:scan) (if (not (member (nth 3 r) nets)) (setq nets (cons (nth 3 r) nets)))))
  (foreach net nets (setq n (+ n (GH:unlink-net net))))
  (if (> n 0)
    (princ (strcat "\n[완료] 연결 " (itoa (length nets)) "개를 풀었습니다 (객체 " (itoa n) "개 — 벽 · 중심선은 그대로)."))
    (princ "\n[알림] 연결된 벽이 없습니다."))
  (princ))

;; 불러올 때: 연결이 남은 도면이면 다시 켬 (출력 없음)
(setq *GH:depth* 0 *GH:snap* nil *GH:skip* nil)
(if (and (tblsearch "APPID" "HY_GHL") (ssget "_X" '((-3 ("HY_GHL"))))) (GH:arm))

(princ)
