;;; ==============================================================================
;;;  GH — 중심선(선·호·폴리선·스플라인)으로 이중선 벽체를 만들고 교차부를 맞물려 폴리선으로
;;;
;;;  벽 두께(직접 넣거나 두 점 클릭 · 기억)를 정하고 중심선을 고르면, 선마다 두께만큼 띠를 만들어
;;;  끝끼리 만나는 곳(L자)은 마이터로 맞물리고 혼자 끝·T자·세 갈래 이상은 평평하게 끝낸 뒤, 띠를 모두 합쳐 폴리선으로 남긴다.
;;;   · 결과는 벽 레이어 · ByLayer, 지금 공간에 (1.5.0~). 고른 중심선은 중심선 레이어로 옮긴다 — 모양은 그대로.
;;;     레이어 이름은 YGN CAD 레이어 이름표(벽 · 벽 중심선)를 따르고, YGN CAD 가 없으면 도면층 색상표(CTB 대응표)대로 3_WALL · 1_CEN.
;;;     없는 레이어는 색상표 색 · 선종류로 만든다 (3_WALL 색 3 · 1_CEN 색 1 CENTER — 연구실 CTB 로 뽑으면 그 두께). 있는 레이어는 그대로.
;;;     두께를 물을 때 L 로 바꿈 (* = 벽은 지금 레이어 · 중심선은 안 옮김, . = 처음 이름 — 기억). 축선(그리드) · Y·GN 중심선 · 잠긴 레이어의 선은 안 옮김.
;;;   · 폴리선 중심선(예: 바깥 벽 사각형)은 마디마다 임시로 나눠(직선 → 선, 볼록 구간 → 호) 선과 똑같이 맞물리고,
;;;     다 쓴 조각은 지운다 — 원래 폴리선은 그대로. 잠긴 레이어의 폴리선은 잠깐 풀었다 다시 잠근다. 3D 폴리선·메시는 고르지 않는다.
;;;   · 스플라인 중심선은 계산할 때만 호로 이은 폴리선(바이아크 — 이음매마다 접선이 이어짐, 오차 0.5 · 얇은 벽은 두께의 1/40)으로 바꿔
;;;     폴리선과 똑같이 셈 — 벽은 호로 이어진 매끈한 폴리선, 원래 스플라인은 그대로.
;;;   · 길이 0 인 선은 건너뛴다 (예전: 0 으로 나눠 멈추고 영역이 남음). 끝이 닿았다고 보는 거리는 두께에 맞춤 (최대 1).
;;;   · 호 벽은 양쪽 면이 같은 중심의 호가 되도록 면마다 볼록 값을 따로 계산한다.
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;;
;;;  GHL — GH 와 같은 벽을 만들되 중심선과 '연결'해 둔다 (GH 는 그대로 — 연결이 필요할 때만 GHL).
;;;   · 연결된 중심선을 옮기거나(MOVE · STRETCH · 그립) CRVE 로 곡률을 주면, 명령이 끝날 때 그 벽을 다시 만든다.
;;;   · 벽을 직접 고치면(자르기 · 옮기기 · 지우기) 그 벽의 연결을 풀고 손대지 않는다 — 고친 벽은 그대로 남는다.
;;;     중심선과 벽을 같이 옮긴 것처럼 다시 만들어도 똑같으면 연결을 유지한다.
;;;   · 중심선이 스플라인이어도 된다 (CRVE 출력이 스플라인이어도 따라감). 중심선을 모두 지우거나 타원 등이 되면 연결을 풀고 벽은 남긴다. 연결된 것을 통째로 복사하면 복사본은 따로 연결된다.
;;;   · U · REDO 는 따라가지 않는다. Y·GN 중심선은 고르지 않는다.
;;;  GHN — 연결 풀기(확정). 고른 것이 속한 연결만, Enter 면 도면 전체. 벽 · 중심선은 그대로 남는다.
;;;  연결 표시 = XDATA HY_GHL (C|W, 연결 번호, 두께). 도면을 다시 열면 리습을 불러올 때 연결이 다시 켜진다.
;;; ==============================================================================

(defun GH:acos (x)
  (cond ((>= x 1.0) 0.0) ((<= x -1.0) pi) (T (atan (sqrt (- 1.0 (* x x))) x))))

(defun GH:unit (v / l)
  (setq l (sqrt (+ (* (car v) (car v)) (* (cadr v) (cadr v)))))
  (list (/ (car v) l) (/ (cadr v) l)))

;; 끝점 P 의 두 꼭짓점 (왼쪽 오른쪽) — V_out = P 에서 선 안쪽으로 가는 방향
(defun GH:miter-points (P V_out obj curves half tol / touches inner c o2 st d2 u1 u2 S lenS b phi sn D M1 M2 L_dir R_dir PL)
  (foreach o curves
    (if (not (equal obj o))
      (progn
        (setq c (vlax-curve-getClosestPointTo o P))
        (if (< (distance P c) tol)
          (progn
            (setq touches (cons o touches))
            (if (and (>= (distance c (vlax-curve-getStartPoint o)) tol) (>= (distance c (vlax-curve-getEndPoint o)) tol))
              (setq inner T)))))))
  (setq u1 (GH:unit V_out) L_dir (list (- (cadr u1)) (car u1)) R_dir (list (cadr u1) (- (car u1))))
  (if (or (null touches) inner (> (length touches) 1))
    ;; 혼자 끝 · T자 · 세 갈래 이상: 평평하게
    (list (list (+ (car P) (* (car L_dir) half)) (+ (cadr P) (* (cadr L_dir) half)))
          (list (+ (car P) (* (car R_dir) half)) (+ (cadr P) (* (cadr R_dir) half))))
    ;; L자: 마이터
    (progn
      (setq o2 (car touches)
            st (< (distance (vlax-curve-getClosestPointTo o2 P) (vlax-curve-getStartPoint o2)) tol)
            d2 (vlax-curve-getFirstDeriv o2 (if st (vlax-curve-getStartParam o2) (vlax-curve-getEndParam o2)))
            u2 (GH:unit (if st d2 (mapcar '- d2)))
            S (list (+ (car u1) (car u2)) (+ (cadr u1) (cadr u2)))
            lenS (sqrt (+ (* (car S) (car S)) (* (cadr S) (cadr S)))))
      (if (< lenS 0.001)
        (setq b L_dir D half)                                           ; 일직선으로 이어짐
        (setq b (list (/ (car S) lenS) (/ (cadr S) lenS))
              phi (GH:acos (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2))))
              sn (sin (/ phi 2.0))
              D (if (< sn 0.05) (* half 5.0) (/ half sn))))             ; 너무 뾰족하면 줄임
      (setq M1 (list (+ (car P) (* D (car b))) (+ (cadr P) (* D (cadr b))))
            M2 (list (- (car P) (* D (car b))) (- (cadr P) (* D (cadr b))))
            PL (list (+ (car P) (* (car L_dir) half)) (+ (cadr P) (* (cadr L_dir) half))))
      (if (< (distance M1 PL) (distance M2 PL)) (list M1 M2) (list M2 M1)))))

;; 각도 a→b 를 dir(+1 반시계 / -1 시계) 방향으로 잰 크기 (0 ~ 2π)
(defun GH:sweep (a b dir / d)
  (setq d (* dir (- b a)))
  (while (< d 0.0) (setq d (+ d (* 2 pi))))
  (while (>= d (* 2 pi)) (setq d (- d (* 2 pi))))
  d)

;; --- 스플라인 중심선 → 호로 이은 임시 폴리선 (계산용 — 원래 스플라인은 그대로) ---
;; 구간마다 양 끝 위치·접선이 같은 두 호(바이아크)로 맞추고, 스플라인과 tol 넘게 벗어나면 반으로 나눠 다시.
;; 이웃 구간과 접선이 이어져 폴리선 중심선처럼 마디마다 매끈하게 맞물린다.
(defun GH:sp-pt (o d) (GH:2d (vlax-curve-getPointAtDist o d)))
(defun GH:sp-tan (o d) (GH:unit (GH:2d (vlax-curve-getFirstDeriv o (vlax-curve-getParamAtDist o d)))))
(defun GH:v- (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun GH:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun GH:crs (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
;; s→e 호, 시작 접선 tg 에서 정한 볼록 값
(defun GH:bul-s (s e tg / c) (setq c (GH:v- e s)) (/ (sin (/ (atan (GH:crs tg c) (GH:dot tg c)) 2.0)) (cos (/ (atan (GH:crs tg c) (GH:dot tg c)) 2.0))))
;; s→e 호, 끝 접선 tg 에서 정한 볼록 값
(defun GH:bul-e (s e tg / c) (setq c (GH:v- e s)) (/ (sin (/ (atan (GH:crs c tg) (GH:dot c tg)) 2.0)) (cos (/ (atan (GH:crs c tg) (GH:dot c tg)) 2.0))))
;; 점 p 와 호(s e bu) 사이 거리
(defun GH:d-arc (p s e bu / c L r cen a0 ap sw k)
  (setq c (GH:v- e s) L (distance s e))
  (cond
    ((< L 1e-12) (distance p s))
    ((< (abs bu) 1e-9)
     (setq k (max 0.0 (min 1.0 (/ (GH:dot (GH:v- p s) c) (* L L)))))
     (distance p (list (+ (car s) (* k (car c))) (+ (cadr s) (* k (cadr c))))))
    (T
     (setq r (/ (* L (+ 1.0 (* bu bu))) (* 4.0 (abs bu)))
           k (/ (* L (- 1.0 (* bu bu))) (* 4.0 bu))
           cen (list (+ (* 0.5 (+ (car s) (car e))) (* k (- (/ (cadr c) L))))
                     (+ (* 0.5 (+ (cadr s) (cadr e))) (* k (/ (car c) L))))
           a0 (angle cen s) ap (angle cen p) sw (* 4.0 (atan (abs bu))))
     (if (<= (GH:sweep a0 ap (if (> bu 0) 1 -1)) sw)
       (abs (- (distance p cen) r))
       (min (distance p s) (distance p e))))))
;; d0~d1 구간을 바이아크로 → ((시작점 볼록) …), 끝점은 다음 구간 시작점
(defun GH:sp-fit (o d0 d1 tol dep / p1 p2 t1 t2 v tt c dd pm b1 b2 k dm mx)
  (setq p1 (GH:sp-pt o d0) p2 (GH:sp-pt o d1) t1 (GH:sp-tan o d0) t2 (GH:sp-tan o d1)
        v (GH:v- p2 p1) tt (list (+ (car t1) (car t2)) (+ (cadr t1) (cadr t2))) c (- 1.0 (GH:dot t1 t2)))
  (setq dd (cond ((> c 1e-9) (/ (+ (- (GH:dot v tt)) (sqrt (+ (* (GH:dot v tt) (GH:dot v tt)) (* 2.0 c (GH:dot v v))))) (* 2.0 c)))
                 ((> (abs (GH:dot v t2)) 1e-12) (/ (GH:dot v v) (* 4.0 (GH:dot v t2))))))
  (if dd
    (setq pm (list (* 0.5 (+ (car p1) (* dd (car t1)) (car p2) (- (* dd (car t2)))))
                   (* 0.5 (+ (cadr p1) (* dd (cadr t1)) (cadr p2) (- (* dd (cadr t2))))))
          b1 (GH:bul-s p1 pm t1) b2 (GH:bul-e pm p2 t2)))
  (setq mx (if dd 0.0 1e99) k 1)
  (while (and dd (< k 8) (<= mx tol))
    (setq dm (GH:sp-pt o (+ d0 (* (- d1 d0) (/ k 8.0))))
          mx (max mx (min (GH:d-arc dm p1 pm b1) (GH:d-arc dm pm p2 b2)))
          k (1+ k)))
  (if (or (<= mx tol) (>= dep 10) (< (- d1 d0) (* 4.0 tol)))
    (if dd (list (list p1 b1) (list pm b2)) (list (list p1 0.0)))
    (append (GH:sp-fit o d0 (* 0.5 (+ d0 d1)) tol (1+ dep))
            (GH:sp-fit o (* 0.5 (+ d0 d1)) d1 tol (1+ dep)))))
;; 스플라인 → 지금 공간에 임시 폴리선 (닫힌 스플라인은 닫힌 폴리선). 못 만들면 nil
(defun GH:spl->pl (o spc tol / len vs pl i closed z)
  (setq len (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o))
        closed (vlax-curve-isClosed o)
        z (caddr (vlax-curve-getStartPoint o)))
  (if (> len 1e-6)
    (progn
      (setq vs (GH:sp-fit o 0.0 len tol 0))
      (if (not closed) (setq vs (append vs (list (list (GH:2d (vlax-curve-getEndPoint o)) 0.0)))))
      (setq pl (vlax-invoke spc 'AddLightWeightPolyline (apply 'append (mapcar 'car vs))) i 0)
      (foreach v vs (if (/= (cadr v) 0.0) (vla-SetBulge pl i (cadr v))) (setq i (1+ i)))
      (if closed (vla-put-Closed pl :vlax-true))
      (if z (vla-put-Elevation pl z))
      pl)))

;; --- 벽 · 중심선 레이어 (1.5.0~) ---
;; 도면층 색상표 줄 (CTBTABLE · YGN CAD 레이어 색상표와 같음): (이름 색 [선종류])
(defun GH:ctb-rows ()
  '(("1_CEN" 1 "CENTER") ("2_CON" 2) ("3_WALL" 3) ("4_WIN" 4) ("5_ETC" 5) ("6_FUN" 6) ("7_TEXT" 7)
    ("8_HAT" 8) ("9_ELE" 9) ("10_COL" 4) ("11_DOT" 7 "DOT") ("12_GRI" 9) ("13_SHEET" 40)))

;; key "wall" | "wall_cen" → 레이어 이름 ("*" = 벽은 지금 레이어 · 중심선은 안 옮김).
;; GH 의 L 로 정한 것 > YGN CAD 레이어 이름표 (ygn-layer — 없으면 건너뜀) > 처음 이름 3_WALL · 1_CEN
(defun GH:lay-name (key / v x)
  (setq v (getenv (if (= key "wall") "HyGhWallLayer" "HyGhCenLayer")))
  (cond ((and v (/= v "")) v)
        ((and (setq x (vl-catch-all-apply 'ygn-layer (list key))) (not (vl-catch-all-error-p x)) (= (type x) 'STR) (/= x "")) x)
        ((= key "wall") "3_WALL")
        (T "1_CEN")))

(defun GH:lay-show (key / n)
  (setq n (GH:lay-name key))
  (cond ((/= n "*") n) ((= key "wall") "지금 레이어") (T "안 옮김")))

;; 없으면 만듦 — 이름이 색상표 줄이면 그 색 · 선종류, 아니면 벽 색 3 · 중심선 색 1 CENTER. 있으면 그대로. → 이름
(defun GH:ensure-layer (name key / row col lt)
  (if (not (tblsearch "LAYER" name))
    (progn
      (setq row (assoc (strcase name) (GH:ctb-rows))
            col (cond (row (cadr row)) ((= key "wall") 3) (T 1))
            lt (cond (row (caddr row)) ((= key "wall") nil) (T "CENTER")))
      (if (and lt (not (tblsearch "LTYPE" lt)))
        (vl-catch-all-apply 'vla-Load (list (vla-get-Linetypes (vla-get-ActiveDocument (vlax-get-acad-object))) lt
                                            (if (= (getvar "MEASUREMENT") 1) "acadiso.lin" "acad.lin"))))
      (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                     (cons 2 name) '(70 . 0) (cons 62 col) (cons 6 (if (and lt (tblsearch "LTYPE" lt)) lt "Continuous"))))))
  name)

;; 벽을 놓을 레이어 (없으면 만듦)
(defun GH:wall-layer ( / n)
  (setq n (GH:lay-name "wall"))
  (if (= n "*") (getvar "CLAYER") (GH:ensure-layer n "wall")))

(defun GH:layer-locked-p (name / l) (and (setq l (tblsearch "LAYER" name)) (= 4 (logand 4 (cdr (assoc 70 l))))))

;; 고른 중심선을 중심선 레이어로 — 축선(그리드 레이어 · YGN 축선 HY_GRID) · Y·GN 중심선 · 잠긴 레이어 · 이미 그 레이어는 그대로.
;; → (옮긴 수 잠겨서 못 옮긴 수 레이어 이름)
(defun GH:move-cens (enames / name d lay moved lk)
  (setq name (GH:lay-name "wall_cen") moved 0 lk 0)
  (if (/= name "*")
    (foreach e enames
      (if (and (setq d (entget e '("HY_GRID" "WUX_CENTER")))
               (setq lay (cdr (assoc 8 d)))
               (/= (strcase lay) (strcase name))
               (not (assoc -3 d))
               (not (wcmatch (strcase lay) "*GRID*,*_GRI*,*그리드*,*축선*,*축렬*")))
        (if (or (GH:locked-p e) (GH:layer-locked-p name))
          (setq lk (1+ lk))
          (progn
            (GH:ensure-layer name "wall_cen")
            (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Layer (list (vlax-ename->vla-object e) name))))
              (setq moved (1+ moved))))))))
  (list moved lk name))

;; (옮긴 수 잠긴 수 이름) → 알림 조각
(defun GH:cen-note (mv)
  (strcat (if (> (car mv) 0) (strcat " · 중심선 " (itoa (car mv)) "개는 " (caddr mv) " 으로") "")
          (if (> (cadr mv) 0) (strcat " · 잠긴 중심선 " (itoa (cadr mv)) "개는 그대로") "")))

;; L — 벽 · 중심선 레이어 (기억: HyGhWallLayer · HyGhCenLayer, 빈 값 = YGN CAD 이름표 · 처음 이름)
(defun GH:layer-opts ( / v)
  (foreach k '(("wall" "HyGhWallLayer" "\n벽 레이어 (* = 지금 레이어, . = 처음 이름) <")
               ("wall_cen" "HyGhCenLayer" "\n중심선을 옮길 레이어 (* = 옮기지 않음, . = 처음 이름) <"))
    (setq v (getstring T (strcat (caddr k) (GH:lay-name (car k)) ">: ")))
    (cond ((= v "") nil)
          ((= v ".") (setenv (cadr k) ""))
          ((or (= v "*") (snvalid v)) (setenv (cadr k) v))
          (T (princ "\n[주의] 레이어 이름으로 쓸 수 없는 글자가 있어 그대로 둡니다."))))
  (princ (strcat "\n[알림] 벽 " (GH:lay-show "wall") " · 중심선 " (GH:lay-show "wall_cen"))))

;; 벽 두께 묻기 (L = 레이어) → 두께
(defun GH:ask-thick (dist / x)
  (while (progn (initget 6 "L") (= (type (setq x (getdist (strcat "\n벽 두께 [레이어(L)] <" (rtos dist 2 2) ">: ")))) 'STR))
    (GH:layer-opts))
  (cond (x) (dist)))

(defun GH:space ( / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc)))

(defun c:GH ( / *error* doc undo_open sv dist half tol ss i o curves spc regs fail p1 p2 pts1 pts2 L1 R1 L2 R2 pl cen base todo x lines ssj k n0
                tmp locked npl nbad lay nspl wl mark e made nw mv srcs)
  (defun *error* (msg)
    (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
    (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        dist (cond ((getenv "HyGhThick") (atof (getenv "HyGhThick"))) (*WUX_DIST*) (200.0)))
  (setq dist (GH:ask-thick dist))
  (setenv "HyGhThick" (rtos dist 2 8))
  (setq *WUX_DIST* dist)
  (prompt "\n벽 중심선(선·호·폴리선·스플라인)을 고르세요: ")
  ;; 2D 폴리선까지 (POLYLINE 중 3D 폴리선 8 · 메시 16 · 다면 메시 64 는 뺌)
  (if (null (setq ss (ssget '((-4 . "<OR") (0 . "LINE,ARC,LWPOLYLINE,SPLINE")
                                (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 88) (-4 . "NOT>") (-4 . "AND>")
                              (-4 . "OR>")))))
    (princ "\n고른 중심선이 없습니다.")
    (progn
      (setq half (/ dist 2.0) tol (min 1.0 (/ half 10.0)) i 0 n0 0 npl 0 nspl 0 nbad 0 fail 0 spc (GH:space))
      (setq sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO" "PEDITACCEPT")))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)
      (while (< i (sslength ss))
        (setq o (vlax-ename->vla-object (ssname ss i)) srcs (cons (ssname ss i) srcs))
        ;; 스플라인: 호로 이은 임시 폴리선으로 바꿔 폴리선과 같이 (임시 폴리선도 끝나면 지움)
        (if (= (vla-get-ObjectName o) "AcDbSpline")
          (if (setq x (vl-catch-all-apply 'GH:spl->pl (list o spc (min 0.5 (/ half 20.0)))))
            (if (vl-catch-all-error-p x) (setq nbad (1+ nbad) o nil) (setq tmp (cons x tmp) o x nspl (1+ nspl) npl (1- npl)))
            (setq n0 (1+ n0) o nil)))
        (cond ((null o) nil)
              ((wcmatch (vla-get-ObjectName o) "AcDbPolyline,AcDb2dPolyline")
          ;; 폴리선: 원본은 두고 분해한 조각(선·호)을 중심선으로 — 끝나면 조각만 지움
          (progn
            (setq lay (vla-Item (vla-get-Layers doc) (vla-get-Layer o)))
            (if (and (= (vla-get-Lock lay) :vlax-true) (not (member lay locked)))
              (progn (vla-put-Lock lay :vlax-false) (setq locked (cons lay locked))))
            (setq x (vl-catch-all-apply 'vlax-invoke (list o 'Explode)))
            (if (or (vl-catch-all-error-p x) (null x))
              (setq nbad (1+ nbad))
              (progn
                (setq npl (1+ npl))
                (foreach y x
                  (setq tmp (cons y tmp))
                  (if (and (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc")
                           (> (vlax-curve-getDistAtParam y (vlax-curve-getEndParam y)) 1e-6))
                    (setq curves (cons y curves))))))))   ; 겹친 마디(길이 0)는 조용히 뺌
              ((> (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)) 1e-6) (setq curves (cons o curves)))
              (T (setq n0 (1+ n0))))
        (setq i (1+ i)))
      ;; 선마다 띠 → 영역
      (foreach o curves
        (setq p1 (vlax-curve-getStartPoint o) p2 (vlax-curve-getEndPoint o)
              pts1 (GH:miter-points p1 (vlax-curve-getFirstDeriv o (vlax-curve-getStartParam o)) o curves half tol)
              pts2 (GH:miter-points p2 (mapcar '- (vlax-curve-getFirstDeriv o (vlax-curve-getEndParam o))) o curves half tol)
              L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2))
        ;; L1 → R1 (시작 끝) → L2 (오른쪽 면) → R2 (끝 쪽) → L1 (왼쪽 면)
        (setq pl (vlax-invoke spc 'AddLightWeightPolyline
                              (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2))))
        (vla-put-Closed pl :vlax-true)
        (if (= (vla-get-ObjectName o) "AcDbArc")
          (progn
            ;; 반시계 호: 오른쪽 면(바깥)은 반시계로 R1→L2, 왼쪽 면(안)은 시계로 R2→L1 — 면마다 중심에서 본 각도로
            (setq cen (vlax-get o 'Center))
            (vla-SetBulge pl 1 (/ (sin (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0)) (cos (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0))))
            (vla-SetBulge pl 3 (- (/ (sin (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0)) (cos (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0)))))))
        (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
        (if (and (not (vl-catch-all-error-p x)) x) (setq regs (append regs x)) (setq fail (1+ fail)))
        (vla-Delete pl))
      ;; 폴리선을 나눈 임시 조각 지우기 · 잠깐 푼 레이어 다시 잠금
      (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
      (setq tmp nil)
      (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
      (setq locked nil)
      (if (null regs)
        (princ "\n[주의] 벽체를 만들지 못했습니다.")
        (progn
          ;; 합치기 — 못 합친 조각은 따로 분해 (영역으로 남기지 않음)
          (setq base (car regs) todo (list base))
          (foreach r (cdr regs)
            (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Boolean (list base 0 r)))
              (setq todo (cons r todo) fail (1+ fail))))
          ;; 영역이 남지 않을 때까지 분해
          (while todo
            (setq o (car todo) todo (cdr todo))
            (foreach y (vlax-invoke o 'Explode)
              (if (= (vla-get-ObjectName y) "AcDbRegion") (setq todo (cons y todo)) (setq lines (cons y lines))))
            (vla-Delete o))
          (setq ssj (ssadd))
          (foreach y lines
            (vl-catch-all-apply 'vla-put-Layer (list y (getvar "CLAYER")))
            (vl-catch-all-apply 'vla-put-Color (list y 256))
            (ssadd (vlax-vla-object->ename y) ssj))
          (setvar "PEDITACCEPT" 1)
          (setq mark (entlast))
          (command "_.PEDIT" "_M" ssj "" "_J" (/ tol 10.0) "")
          (setq k 0)
          (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))
          ;; 이은 벽을 벽 레이어로 (1.5.0~ — 잇기는 지금 레이어에서: 벽 레이어가 잠기거나 얼어도 이어지게)
          (setq wl (GH:wall-layer) nw 0)
          (if (/= (strcase wl) (strcase (getvar "CLAYER")))
            (progn
              (setq e (if mark (entnext mark) (entnext)))
              (while e
                (if (wcmatch (cdr (assoc 0 (entget e))) "LWPOLYLINE,LINE,ARC") (setq made (cons e made)))
                (setq e (entnext e)))
              (foreach y lines (if (not (vlax-erased-p y)) (setq made (cons (vlax-vla-object->ename y) made))))
              (foreach e made
                (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Layer (list (vlax-ename->vla-object e) wl))))
                  (setq nw (1+ nw))))))
          (setq mv (GH:move-cens srcs))
          (princ (strcat "\n[완료] 중심선 " (itoa (length curves)) "개로 벽체를 만들어 폴리선으로 이었습니다 (두께 " (rtos dist 2 2)
                         " · 벽 " wl (GH:cen-note mv)
                         (if (> npl 0) (strcat " · 폴리선 " (itoa npl) "개는 마디마다 나눠 셈") "")
                         (if (> nspl 0) (strcat " · 스플라인 " (itoa nspl) "개는 호로 이어 셈") "") ")."
                         (if (> n0 0) (strcat " 길이 0 인 선 " (itoa n0) "개는 건너뜀.") "")
                         (if (> nbad 0) (strcat "\n[주의] 나누지 못한 폴리선·스플라인 " (itoa nbad) "개는 건너뛰었습니다.") "")
                         (if (> fail 0) (strcat "\n[주의] 합치지 못한 조각 " (itoa fail) "개는 따로 폴리선이 되었습니다 (겹친 곳 확인).") "")))))
      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)))
  (princ))

;;; ==============================================================================
;;;  GHL — 중심선과 연결된 벽체
;;; ==============================================================================

(defun GH:2d (p) (list (car p) (cadr p)))

;; 연결 표시 → (역할 연결번호 두께) 또는 nil
(defun GH:tag (e / x)
  (if (and e (setq x (cdr (assoc "HY_GHL" (cdr (assoc -3 (entget e '("HY_GHL"))))))))
    (list (cdr (nth 0 x)) (cdr (nth 1 x)) (cdr (nth 2 x)))))

;; 잠긴 레이어의 객체도 표시만은 고칠 수 있게 잠깐 풀었다 다시 잠금
(defun GH:unlocked (e fn / lay x)
  (setq lay (vla-Item (vla-get-Layers (vla-get-ActiveDocument (vlax-get-acad-object))) (cdr (assoc 8 (entget e)))))
  (if (= (vla-get-Lock lay) :vlax-true)
    (progn
      (vla-put-Lock lay :vlax-false)
      (setq x (vl-catch-all-apply fn (list e)))
      (vla-put-Lock lay :vlax-true))
    (setq x (vl-catch-all-apply fn (list e))))
  (if (vl-catch-all-error-p x) nil x))

(defun GH:set-tag (e role net thick)
  (if (null (tblsearch "APPID" "HY_GHL")) (regapp "HY_GHL"))
  (GH:unlocked e (function (lambda (e)
    (entmod (append (vl-remove-if '(lambda (x) (= (car x) -3)) (entget e))
                    (list (list -3 (list "HY_GHL" (cons 1000 role) (cons 1000 net) (cons 1040 (float thick)))))))))))

(defun GH:clear-tag (e) (GH:unlocked e (function (lambda (e) (entmod (list (cons -1 e) '(-3 ("HY_GHL"))))))))

;; 모양만 (핸들 · 소유 · 반응자 빼고) — 바뀌었는지 견줄 글
(defun GH:geo (e / d)
  (if (setq d (entget e))
    (vl-prin1-to-string (vl-remove-if '(lambda (x) (member (car x) '(-1 -2 5 102 330 360))) d))))

;; 연결된 것 모두 → ((ename 핸들 역할 연결번호 모양) ...)
(defun GH:scan ( / ss i e tg out)
  (if (setq ss (ssget "_X" '((-3 ("HY_GHL")))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (if (setq tg (GH:tag e))
          (setq out (cons (list e (cdr (assoc 5 (entget e))) (car tg) (cadr tg) (GH:geo e)) out)))
        (setq i (1+ i)))))
  out)

;; 벽 모양 서명 — 꼭짓점 · 볼록 값을 1 단위로 반올림해 정렬 (시작점 · 순서가 달라도 같은 모양이면 같음)
(defun GH:wall-sig (enames / out d)
  (foreach e enames
    (if (setq d (entget e))
      (foreach x d
        (cond ((= (car x) 10) (setq out (cons (strcat "P" (rtos (cadr x) 2 0) "," (rtos (caddr x) 2 0)) out)))
              ((and (= (car x) 42) (/= (cdr x) 0.0)) (setq out (cons (strcat "B" (rtos (cdr x) 2 3)) out)))))))
  (strcat (itoa (length enames)) "|" (apply 'strcat (mapcar '(lambda (s) (strcat s ";")) (acad_strlsort out)))))

;; 선 · 호 조각 → (시작 끝 볼록) — 호는 반시계
(defun GH:seg (o / a)
  (if (= (vla-get-ObjectName o) "AcDbArc")
    (progn
      (setq a (vla-get-TotalAngle o))
      (list (GH:2d (vlax-curve-getStartPoint o)) (GH:2d (vlax-curve-getEndPoint o)) (/ (sin (/ a 4.0)) (cos (/ a 4.0)))))
    (list (GH:2d (vlax-curve-getStartPoint o)) (GH:2d (vlax-curve-getEndPoint o)) 0.0)))

(defun GH:rev (s) (list (cadr s) (car s) (- (caddr s))))

;; 조각 잇기 (PEDIT 결합 대신 — 명령 리액터 안에서도 됨) → 이어진 조각 목록들
(defun GH:chain (segs tol / out ch go hit ns)
  (while segs
    (setq ch (list (car segs)) segs (cdr segs) go T)
    (while go
      (setq hit nil)
      (foreach s segs
        (if (not hit)
          (cond ((< (distance (car s) (cadr (last ch))) tol) (setq hit s ns s))
                ((< (distance (cadr s) (cadr (last ch))) tol) (setq hit s ns (GH:rev s))))))
      (if hit
        (setq ch (append ch (list ns)) segs (vl-remove-if '(lambda (x) (eq x hit)) segs))
        (setq go nil)))
    (setq go T)
    (while go
      (setq hit nil)
      (foreach s segs
        (if (not hit)
          (cond ((< (distance (cadr s) (car (car ch))) tol) (setq hit s ns s))
                ((< (distance (car s) (car (car ch))) tol) (setq hit s ns (GH:rev s))))))
      (if hit
        (setq ch (cons ns ch) segs (vl-remove-if '(lambda (x) (eq x hit)) segs))
        (setq go nil)))
    (setq out (cons ch out)))
  out)

;; 중심선(ename) → 벽 폴리선을 만들어 (벽 enames, 못 나눈 폴리선 수, 못 합친 조각 수). 명령 · 실행 취소 표시 · 시스템 변수를 쓰지 않음.
(defun GH:walls (enames dist layer / doc spc half tol curves tmp locked lay o x regs fail base todo pieces segs walls nbad
                                     p1 p2 pts1 pts2 L1 R1 L2 R2 pl cen closed vs i b)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        half (/ dist 2.0) tol (min 1.0 (/ half 10.0)) fail 0 nbad 0)
  (foreach e enames
    (setq o (vlax-ename->vla-object e))
    (if (null spc)
      (setq spc (if (= (strcase (cond ((cdr (assoc 410 (entget e)))) ("Model"))) "MODEL")
                  (vla-get-ModelSpace doc) (vla-get-PaperSpace doc))))
    (if (= (vla-get-ObjectName o) "AcDbSpline")
      (if (and (setq x (vl-catch-all-apply 'GH:spl->pl (list o spc (min 0.5 (/ half 20.0))))) (not (vl-catch-all-error-p x)))
        (setq tmp (cons x tmp) o x)
        (setq o nil nbad (1+ nbad))))
    (cond
      ((null o) nil)
      ((wcmatch (vla-get-ObjectName o) "AcDbPolyline,AcDb2dPolyline")
       (setq lay (vla-Item (vla-get-Layers doc) (vla-get-Layer o)))
       (if (and (= (vla-get-Lock lay) :vlax-true) (not (member lay locked)))
         (progn (vla-put-Lock lay :vlax-false) (setq locked (cons lay locked))))
       (setq x (vl-catch-all-apply 'vlax-invoke (list o 'Explode)))
       (if (or (vl-catch-all-error-p x) (null x))
         (setq nbad (1+ nbad))
         (foreach y x
           (setq tmp (cons y tmp))
           (if (and (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc")
                    (> (vlax-curve-getDistAtParam y (vlax-curve-getEndParam y)) 1e-6))
             (setq curves (cons y curves))))))
      ((wcmatch (vla-get-ObjectName o) "AcDbLine,AcDbArc")
       (if (> (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)) 1e-6) (setq curves (cons o curves))))
      (T (setq nbad (1+ nbad)))))
  ;; 선마다 띠 → 영역 (GH 와 같은 계산)
  (foreach o curves
    (setq p1 (vlax-curve-getStartPoint o) p2 (vlax-curve-getEndPoint o)
          pts1 (GH:miter-points p1 (vlax-curve-getFirstDeriv o (vlax-curve-getStartParam o)) o curves half tol)
          pts2 (GH:miter-points p2 (mapcar '- (vlax-curve-getFirstDeriv o (vlax-curve-getEndParam o))) o curves half tol)
          L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2))
    (setq pl (vlax-invoke spc 'AddLightWeightPolyline
                          (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2))))
    (vla-put-Closed pl :vlax-true)
    (if (= (vla-get-ObjectName o) "AcDbArc")
      (progn
        (setq cen (vlax-get o 'Center))
        (vla-SetBulge pl 1 (/ (sin (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0)) (cos (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0))))
        (vla-SetBulge pl 3 (- (/ (sin (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0)) (cos (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0)))))))
    (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
    (if (and (not (vl-catch-all-error-p x)) x) (setq regs (append regs x)) (setq fail (1+ fail)))
    (vla-Delete pl))
  (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
  (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
  (if regs
    (progn
      (setq base (car regs) todo (list base))
      (foreach r (cdr regs)
        (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Boolean (list base 0 r)))
          (setq todo (cons r todo) fail (1+ fail))))
      (while todo
        (setq o (car todo) todo (cdr todo))
        (foreach y (vlax-invoke o 'Explode)
          (if (= (vla-get-ObjectName y) "AcDbRegion") (setq todo (cons y todo)) (setq pieces (cons y pieces))))
        (vla-Delete o))
      (foreach y pieces
        (if (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc") (setq segs (cons (GH:seg y) segs)))
        (vla-Delete y))
      ;; 이어 붙여 폴리선으로
      (foreach ch (GH:chain (reverse segs) (max 1e-6 (/ tol 10.0)))
        (setq closed (< (distance (cadr (last ch)) (car (car ch))) (max 1e-6 (/ tol 10.0)))
              vs (mapcar 'car ch))
        (if (not closed) (setq vs (append vs (list (cadr (last ch))))))
        (if (> (length vs) 1)
          (progn
            (setq pl (vlax-invoke spc 'AddLightWeightPolyline (apply 'append vs)) i 0)
            (foreach s ch
              (if (and (< i (length vs)) (/= (setq b (caddr s)) 0.0)) (vla-SetBulge pl i b))
              (setq i (1+ i)))
            (if closed (vla-put-Closed pl :vlax-true))
            (vl-catch-all-apply 'vla-put-Layer (list pl layer))
            (vl-catch-all-apply 'vla-put-Color (list pl 256))
            (setq walls (cons (vlax-vla-object->ename pl) walls)))))))
  (list (reverse walls) nbad fail))

(defun GH:locked-p (e / l)
  (and (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e))))) (= 4 (logand 4 (cdr (assoc 70 l))))))

(defun GH:unlink-net (net / n)
  (setq n 0)
  (foreach r (GH:scan) (if (= (nth 3 r) net) (progn (GH:clear-tag (car r)) (setq n (1+ n)))))
  n)

(defun GH:say (msg) (princ (strcat "\n[알림] GHL: " msg)))

;; 명령이 끝난 뒤: 지난 상태(*GH:snap*)와 견주어 연결마다 벽을 다시 만들거나 연결을 푼다
(defun GH:sync ( / cur nets old now oldh nowh erC erW newC newW modC modW cens wallsE thick lay res newWalls netId q)
  (setq cur (GH:scan))
  (foreach r (append *GH:snap* cur) (if (not (member (nth 3 r) nets)) (setq nets (cons (nth 3 r) nets))))
  (foreach net nets
    (setq old (vl-remove-if-not '(lambda (r) (= (nth 3 r) net)) *GH:snap*)
          now (vl-remove-if-not '(lambda (r) (= (nth 3 r) net)) cur)
          oldh (mapcar 'cadr old) nowh (mapcar 'cadr now)
          erC nil erW nil newC nil newW nil modC nil modW nil)
    (foreach r old
      (if (not (member (cadr r) nowh)) (if (= (nth 2 r) "C") (setq erC (cons r erC)) (setq erW (cons r erW)))))
    (foreach r now
      (setq q (assoc (cadr r) (mapcar 'cdr old)))
      (cond ((null (member (cadr r) oldh)) (if (= (nth 2 r) "C") (setq newC (cons r newC)) (setq newW (cons r newW))))
            ((/= (nth 4 r) (nth 3 q)) (if (= (nth 2 r) "C") (setq modC (cons r modC)) (setq modW (cons r modW))))))
    (cond
      ((not (or erC erW newC newW modC modW)) nil)
      ;; 통째로 복사 — 복사본은 새 연결로
      ((and newC newW (null erC) (null erW) (null modC) (null modW))
       (setq netId (strcat "N" (cadr (car newC))) thick (nth 2 (GH:tag (car (car newC)))))
       (foreach r (append newC newW) (vl-catch-all-apply 'GH:set-tag (list (car r) (nth 2 r) netId thick))))
      ;; 중심선은 그대로인데 벽만 바뀜 — 손댄 벽이니 풀고 그대로
      ((not (or erC newC modC))
       (GH:unlink-net net)
       (GH:say "벽을 직접 고쳐서 그 벽의 연결을 풀었습니다 (벽은 그대로)."))
      (T
       (setq cens (mapcar 'car (vl-remove-if-not '(lambda (r) (= (nth 2 r) "C")) now))
             wallsE (mapcar 'car (vl-remove-if-not '(lambda (r) (= (nth 2 r) "W")) now)))
       (cond
         ((null cens)
          (GH:unlink-net net)
          (GH:say "중심선이 모두 없어져 연결을 풀었습니다 (벽은 그대로)."))
         ((vl-some '(lambda (e) (not (wcmatch (cdr (assoc 0 (entget e))) "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE"))) cens)
          (GH:unlink-net net)
          (GH:say "중심선이 벽을 만들 수 없는 모양(타원 등)이 되어 연결을 풀었습니다 (벽은 그대로)."))
         ((vl-some 'GH:locked-p wallsE)
          (GH:say "벽이 잠긴 레이어에 있어 다시 만들지 않았습니다."))
         (T
          (setq thick (nth 2 (GH:tag (car cens)))
                lay (cond (wallsE (cdr (assoc 8 (entget (car wallsE)))))
                          ((and (setq q (vl-catch-all-apply 'GH:wall-layer)) (not (vl-catch-all-error-p q))) q)
                          ((getvar "CLAYER")))
                res (GH:walls cens thick lay)
                newWalls (car res))
          (cond
            ((null newWalls)
             (GH:unlink-net net)
             (GH:say "벽을 다시 만들지 못해 연결을 풀었습니다 (벽은 그대로)."))
            ((and (or erW newW modW) (/= (GH:wall-sig wallsE) (GH:wall-sig newWalls)))
             (foreach e newWalls (entdel e))
             (GH:unlink-net net)
             (GH:say "벽도 직접 고쳐서 다시 만들지 않고 연결을 풀었습니다 (고친 벽 그대로)."))
            (T
             (foreach e wallsE (entdel e))
             (foreach e newWalls (GH:set-tag e "W" net thick))))))))))

;; --- 리액터: 명령 · 리습이 시작할 때 연결 상태를 적어 두고, 끝날 때 견줌 (안쪽 명령은 바깥이 끝날 때 한 번) ---
(defun GH:on-start (r a / s)
  (if (null *GH:depth*) (setq *GH:depth* 0))
  (if (= *GH:depth* 0)
    (progn
      (setq s (if (= (type (car a)) 'STR) (strcase (car a)) "")
            *GH:skip* (or (member s '("U" "UNDO" "REDO" "MREDO" "OOPS")) (wcmatch s "(C:GH*"))
            *GH:snap* (if (and *GH:on* (not *GH:skip*)) (GH:scan)))))
  (setq *GH:depth* (1+ *GH:depth*)))

(defun GH:on-end (r a / x)
  (setq *GH:depth* (max 0 (1- (cond (*GH:depth*) (1)))))
  (if (= *GH:depth* 0)
    (progn
      (if (and *GH:on* *GH:snap* (not *GH:skip*))
        (if (vl-catch-all-error-p (setq x (vl-catch-all-apply 'GH:sync)))
          (princ (strcat "\n[오류] GHL: " (vl-catch-all-error-message x)))))
      (setq *GH:snap* nil *GH:skip* nil))))

(defun GH:arm ( / )
  (foreach k '(:vlr-command-reactor :vlr-lisp-reactor)
    (foreach g (vlr-reactors k)
      (foreach r (cdr g) (if (= (vlr-data r) "GH_LINK") (vlr-remove r)))))
  (vlr-command-reactor "GH_LINK" '((:vlr-commandWillStart . GH:on-start) (:vlr-commandEnded . GH:on-end)
                                   (:vlr-commandCancelled . GH:on-end) (:vlr-commandFailed . GH:on-end)))
  (vlr-lisp-reactor "GH_LINK" '((:vlr-lispWillStart . GH:on-start) (:vlr-lispEnded . GH:on-end) (:vlr-lispCancelled . GH:on-end)))
  (setq *GH:on* T *GH:depth* 0))

(defun c:GHL ( / *error* doc undo_open dist ss i e tg cens skipped wux net res walls lay locked mv)
  (defun *error* (msg)
    (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        dist (cond ((getenv "HyGhThick") (atof (getenv "HyGhThick"))) (*WUX_DIST*) (200.0)))
  (setq dist (GH:ask-thick dist))
  (setenv "HyGhThick" (rtos dist 2 8))
  (setq *WUX_DIST* dist)
  (prompt "\n연결할 벽 중심선(선·호·폴리선·스플라인)을 고르세요: ")
  (if (null (setq ss (ssget '((-4 . "<OR") (0 . "LINE,ARC,LWPOLYLINE,SPLINE")
                                (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 88) (-4 . "NOT>") (-4 . "AND>")
                              (-4 . "OR>")))))
    (princ "\n고른 중심선이 없습니다.")
    (progn
      (setq i 0 skipped 0 wux 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (cond ((GH:tag e) (setq skipped (1+ skipped)))
              ((assoc -3 (entget e '("WUX_CENTER"))) (setq wux (1+ wux)))
              ((> (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)) 1e-6) (setq cens (cons e cens))))
        (setq i (1+ i)))
      (if (null cens)
        (princ "\n[알림] 연결할 중심선이 없습니다 (이미 연결된 것 · Y·GN 중심선은 건너뜀).")
        (progn
          (vla-StartUndoMark doc)
          (setq undo_open T
                net (strcat "N" (cdr (assoc 5 (entget (car cens)))))
                lay (GH:wall-layer)
                res (GH:walls (reverse cens) dist lay)
                walls (car res))
          (if (null walls)
            (princ "\n[주의] 벽체를 만들지 못했습니다.")
            (progn
              (if (null (tblsearch "APPID" "HY_GHL")) (regapp "HY_GHL"))
              (foreach c cens (GH:set-tag c "C" net dist))
              (foreach w walls (GH:set-tag w "W" net dist))
              (setq mv (GH:move-cens cens))
              (GH:arm)
              (princ (strcat "\n[완료] 중심선 " (itoa (length cens)) "개로 벽체를 만들고 연결했습니다 (두께 " (rtos dist 2 2)
                             " · 벽 " lay (GH:cen-note mv) ") — 중심선을 고치면 벽이 따라갑니다. 확정: GHN"
                             (if (> (cadr res) 0) (strcat "\n[주의] 나누지 못한 폴리선 " (itoa (cadr res)) "개는 건너뛰었습니다.") "")
                             (if (> (caddr res) 0) (strcat "\n[주의] 합치지 못한 조각 " (itoa (caddr res)) "개는 따로 폴리선이 되었습니다.") "")))))
          (vla-EndUndoMark doc)
          (setq undo_open nil)))
      (if (> skipped 0) (princ (strcat "\n[알림] 이미 연결된 중심선 " (itoa skipped) "개는 건너뛰었습니다 (다시 하려면 GHN 으로 풀고).")))
      (if (> wux 0) (princ (strcat "\n[알림] Y·GN 중심선 " (itoa wux) "개는 건너뛰었습니다.")))))
  (princ))

(defun c:GHN ( / ss i tg nets n)
  (prompt "\n연결을 풀 벽·중심선을 고르세요 (Enter = 도면 전체): ")
  (setq ss (ssget '((-3 ("HY_GHL")))) n 0)
  (if ss
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (if (and (setq tg (GH:tag (ssname ss i))) (not (member (cadr tg) nets))) (setq nets (cons (cadr tg) nets)))
        (setq i (1+ i))))
    (foreach r (GH:scan) (if (not (member (nth 3 r) nets)) (setq nets (cons (nth 3 r) nets)))))
  (foreach net nets (setq n (+ n (GH:unlink-net net))))
  (if (> n 0)
    (princ (strcat "\n[완료] 연결 " (itoa (length nets)) "개를 풀었습니다 (객체 " (itoa n) "개 — 벽 · 중심선은 그대로)."))
    (princ "\n[알림] 연결된 벽이 없습니다."))
  (princ))

;; 불러올 때: 연결이 남은 도면이면 다시 켬 (출력 없음)
(setq *GH:depth* 0 *GH:snap* nil *GH:skip* nil)
(if (and (tblsearch "APPID" "HY_GHL") (ssget "_X" '((-3 ("HY_GHL"))))) (GH:arm))

(princ)
