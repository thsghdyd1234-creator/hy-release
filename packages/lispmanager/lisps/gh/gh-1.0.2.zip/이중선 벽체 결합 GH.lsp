;; ======================================================================
;; [GH] 이중선 벽체 결합 (교차점 마이터 계산)
;; - 직사각형을 늘려 생기는 겹침·요철이 없게 함
;; - 두 선의 안쪽·바깥쪽 교차 좌표를 계산해 맞물리게 결합
;; - 예각이 너무 작으면 평면(Bevel)으로 마감
;; - 영역(Region)을 끝까지 분해해 지우고 폴리선으로 자동 결합
;; - [리습매니저 1.0.1] 보조 함수를 GH:acos · GH:miter-points 로 바꾸고 c:GH 안에서만 쓰게 함
;;   (예전 이름 WUX-acos · trp-get-miter-points 는 Y·GN과 같아서, GH를 쓰고 나면 Y가 인자 수 오류로 멈췄음)
;; ======================================================================

(defun c:GH (/ GH:acos GH:miter-points ss dist tmp_dist half_dist i obj curveObjs p1 p2 deriv1_start V_out1 deriv1_end V_out2 pts1 pts2 L1 R1 L2 R2 ptsArray pline mspace arr regions regList baseReg targetObjs finalLines subObjs subList exObj cur_layer objType dTheta bulge ssJoin old_peditaccept)
  (vl-load-com)
  (setvar "CMDECHO" 0)

  ;; 1. 아크코사인 보조 함수
  (defun GH:acos (x)
    (cond
      ((>= x 1.0) 0.0)
      ((<= x -1.0) pi)
      (T (atan (sqrt (- 1.0 (* x x))) x))
    )
  )

  ;; 2. 교차점(마이터) 계산
  (defun GH:miter-points (P V_out obj curveObjs half_dist / touches hasInterior closestPt otherObj isOtherStart isOtherEnd deriv2 V_out2 len1 len2 u1 u2 S lenS b dot phi sin_hp D M1 M2 L_dir R_dir P_L_approx)
    (setq touches nil hasInterior nil)
    ;; 교차점 분석
    (foreach otherObj curveObjs
      (if (not (equal obj otherObj))
        (progn
          (setq closestPt (vlax-curve-getClosestPointTo otherObj P))
          (if (< (distance P closestPt) 0.001)
            (progn
              (setq touches (cons otherObj touches))
              (setq isOtherStart (< (distance closestPt (vlax-curve-getStartPoint otherObj)) 0.001))
              (setq isOtherEnd (< (distance closestPt (vlax-curve-getEndPoint otherObj)) 0.001))
              (if (and (not isOtherStart) (not isOtherEnd))
                (setq hasInterior T) ;; T자 교차 판별
              )
            )
          )
        )
      )
    )
    
    ;; 현재 선의 방향 벡터 및 좌/우 직각 방향 설정
    (setq len1 (sqrt (+ (* (car V_out) (car V_out)) (* (cadr V_out) (cadr V_out)))))
    (setq u1 (list (/ (car V_out) len1) (/ (cadr V_out) len1)))
    (setq L_dir (list (- (cadr u1)) (car u1)))
    (setq R_dir (list (cadr u1) (- (car u1))))
    
    (if (or (null touches) hasInterior (> (length touches) 1))
      ;; [끝이 비었거나 T자 교차] 평면 마감(Flat Cap) 반환
      (list
        (list (+ (car P) (* (car L_dir) half_dist)) (+ (cadr P) (* (cadr L_dir) half_dist)))
        (list (+ (car P) (* (car R_dir) half_dist)) (+ (cadr P) (* (cadr R_dir) half_dist)))
      )
      ;; [L자 교차] 교차점(마이터) 계산
      (progn
        (setq otherObj (car touches))
        (setq closestPt (vlax-curve-getClosestPointTo otherObj P))
        (setq isOtherStart (< (distance closestPt (vlax-curve-getStartPoint otherObj)) 0.001))
        
        (if isOtherStart
          (setq deriv2 (vlax-curve-getFirstDeriv otherObj (vlax-curve-getStartParam otherObj)))
          (setq deriv2 (vlax-curve-getFirstDeriv otherObj (vlax-curve-getEndParam otherObj)))
        )
        
        (setq V_out2 (if isOtherStart deriv2 (list (- (car deriv2)) (- (cadr deriv2)) (- (caddr deriv2)))))
        (setq len2 (sqrt (+ (* (car V_out2) (car V_out2)) (* (cadr V_out2) (cadr V_out2)))))
        (setq u2 (list (/ (car V_out2) len2) (/ (cadr V_out2) len2)))
        
        (setq S (list (+ (car u1) (car u2)) (+ (cadr u1) (cadr u2))))
        (setq lenS (sqrt (+ (* (car S) (car S)) (* (cadr S) (cadr S)))))
        
        (if (< lenS 0.001)
          (setq b L_dir D half_dist) ;; 평행일 때 처리
          (progn
            (setq b (list (/ (car S) lenS) (/ (cadr S) lenS)))
            (setq dot (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2))))
            (setq phi (GH:acos dot))
            (setq sin_hp (sin (/ phi 2.0)))
            
            ;; 뾰족함 한계값
            (if (< sin_hp 0.05) 
              (setq D (* half_dist 5.0))
              (setq D (/ half_dist sin_hp))
            )
          )
        )
        
        ;; M1, M2가 모서리 꼭짓점이 됨
        (setq M1 (list (+ (car P) (* D (car b))) (+ (cadr P) (* D (cadr b)))))
        (setq M2 (list (- (car P) (* D (car b))) (- (cadr P) (* D (cadr b)))))
        
        (setq P_L_approx (list (+ (car P) (* (car L_dir) half_dist)) (+ (cadr P) (* (cadr L_dir) half_dist))))
        
        (if (< (distance M1 P_L_approx) (distance M2 P_L_approx))
          (list M1 M2) ;; M1이 왼쪽, M2가 오른쪽
          (list M2 M1)
        )
      )
    )
  )

  ;; 3. 메인 실행부
  (if (not *WUX_DIST*) (setq *WUX_DIST* 200.0))
  (setq tmp_dist (getreal (strcat "\n벽체 전체 두께 입력 <" (rtos *WUX_DIST* 2 0) ">: ")))
  (if tmp_dist (setq *WUX_DIST* tmp_dist))
  (setq dist *WUX_DIST*)

  (if (setq ss (ssget '((0 . "LINE,ARC"))))
    (progn
      (setq half_dist (/ dist 2.0) cur_layer (getvar "CLAYER") mspace (vla-get-ModelSpace (vla-get-ActiveDocument (vlax-get-acad-object))))
      (setq i 0 curveObjs nil)
      (while (< i (sslength ss))
        (setq curveObjs (cons (vlax-ename->vla-object (ssname ss i)) curveObjs))
        (setq i (1+ i))
      )

      (princ (strcat "\n" (itoa (length curveObjs)) "개 객체의 모서리(마이터) 좌표를 계산하는 중..."))

      (setq regList nil)
      (foreach obj curveObjs
        (setq p1 (vlax-curve-getStartPoint obj) p2 (vlax-curve-getEndPoint obj))
        
        ;; 시작점(p1)의 정밀 꼭짓점 획득
        (setq deriv1_start (vlax-curve-getFirstDeriv obj (vlax-curve-getStartParam obj)))
        (setq V_out1 deriv1_start) 
        (setq pts1 (GH:miter-points p1 V_out1 obj curveObjs half_dist))
        
        ;; 끝점(p2)의 정밀 꼭짓점 획득
        (setq deriv1_end (vlax-curve-getFirstDeriv obj (vlax-curve-getEndParam obj)))
        (setq V_out2 (list (- (car deriv1_end)) (- (cadr deriv1_end)) (- (caddr deriv1_end))))
        (setq pts2 (GH:miter-points p2 V_out2 obj curveObjs half_dist))
        
        ;; 꼭짓점 4개
        (setq L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2))
        (setq objType (vla-get-ObjectName obj))

        (if (= objType "AcDbLine")
          (progn
            (setq ptsArray (vlax-make-safearray vlax-vbDouble '(0 . 7)))
            (vlax-safearray-fill ptsArray (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2)))
            (setq pline (vla-AddLightWeightPolyline mspace ptsArray))
            (vla-put-Closed pline :vlax-true)
          )
        )

        (if (= objType "AcDbArc")
          (progn
            (setq dTheta (- (vla-get-EndAngle obj) (vla-get-StartAngle obj)))
            (if (< dTheta 0.0) (setq dTheta (+ dTheta (* 2 pi))))
            (setq bulge (/ (sin (/ dTheta 4.0)) (cos (/ dTheta 4.0))))
            
            (setq ptsArray (vlax-make-safearray vlax-vbDouble '(0 . 7)))
            (vlax-safearray-fill ptsArray (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2)))
            (setq pline (vla-AddLightWeightPolyline mspace ptsArray))
            (vla-put-Closed pline :vlax-true)
            (vla-SetBulge pline 1 bulge)
            (vla-SetBulge pline 3 (- bulge))
          )
        )

        (setq arr (vlax-make-safearray vlax-vbObject '(0 . 0)))
        (vlax-safearray-put-element arr 0 pline)
        (setq regions (vl-catch-all-apply 'vla-AddRegion (list mspace arr)))
        (if (not (vl-catch-all-error-p regions)) (setq regList (append regList (vlax-safearray->list (vlax-variant-value regions)))))
        (vla-delete pline)
      )

      (if regList
        (progn
          (setq baseReg (car regList))
          (foreach reg (cdr regList) (vl-catch-all-apply 'vla-boolean (list baseReg acUnion reg)))
          
          ;; ====================================================================
          ;; 영역(Region)이 남지 않을 때까지 분해 (반복)
          ;; ====================================================================
          (setq targetObjs (list baseReg) finalLines nil)
          (while targetObjs
            (setq obj (car targetObjs)
                  targetObjs (cdr targetObjs))
            (if (and (vlax-read-enabled-p obj)
                     (= (vla-get-ObjectName obj) "AcDbRegion"))
              (progn
                (setq subObjs (vl-catch-all-apply 'vla-Explode (list obj)))
                (if (not (vl-catch-all-error-p subObjs))
                  (progn
                    (setq subList (vlax-safearray->list (vlax-variant-value subObjs)))
                    (setq targetObjs (append subList targetObjs))
                    (vla-delete obj) ;; 영역 즉시 삭제
                  )
                )
              )
              (if (vlax-read-enabled-p obj)
                (setq finalLines (cons obj finalLines))
              )
            )
          )
          
          ;; ====================================================================
          ;; 분해된 선을 폴리선으로 자동 결합
          ;; ====================================================================
          (setq ssJoin (ssadd))
          (foreach exObj finalLines
            (vl-catch-all-apply 'vla-put-Layer (list exObj cur_layer))
            (vl-catch-all-apply 'vla-put-color (list exObj 256))
            ;; 결합을 위해 엔티티 이름을 선택셋에 추가
            (ssadd (vlax-vla-object->ename exObj) ssJoin)
          )
          
          (if (> (sslength ssJoin) 0)
            (progn
              (setq old_peditaccept (getvar "PEDITACCEPT"))
              (setvar "PEDITACCEPT" 1)
              ;; PEDIT 명령어로 선택셋의 모든 선/호를 하나의 폴리선으로 결합
              (vl-cmdf "_.PEDIT" "_M" ssJoin "" "_J" "0.01" "")
              (setvar "PEDITACCEPT" old_peditaccept)
            )
          )
          ;; ====================================================================

          (princ "\n[완료] 벽체를 만들고 폴리선으로 결합했습니다.")
        )
      )
    )
  )
  (setvar "CMDECHO" 1)
  (princ)
)