;;; ==============================================================================
;;;  GH — 중심선(선·호·폴리선)으로 이중선 벽체를 만들고 교차부를 맞물려 폴리선으로
;;;
;;;  벽 두께(직접 넣거나 두 점 클릭 · 기억)를 정하고 중심선을 고르면, 선마다 두께만큼 띠를 만들어
;;;  끝끼리 만나는 곳(L자)은 마이터로 맞물리고 혼자 끝·T자·세 갈래 이상은 평평하게 끝낸 뒤, 띠를 모두 합쳐 폴리선으로 남긴다.
;;;   · 결과는 지금 레이어 · ByLayer, 지금 공간에. 중심선은 그대로 남는다.
;;;   · 폴리선 중심선(예: 바깥 벽 사각형)은 마디마다 임시로 나눠(직선 → 선, 볼록 구간 → 호) 선과 똑같이 맞물리고,
;;;     다 쓴 조각은 지운다 — 원래 폴리선은 그대로. 잠긴 레이어의 폴리선은 잠깐 풀었다 다시 잠근다. 3D 폴리선·메시는 고르지 않는다.
;;;   · 길이 0 인 선은 건너뛴다 (예전: 0 으로 나눠 멈추고 영역이 남음). 끝이 닿았다고 보는 거리는 두께에 맞춤 (최대 1).
;;;   · 호 벽은 양쪽 면이 같은 중심의 호가 되도록 면마다 볼록 값을 따로 계산한다.
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun GH:acos (x)
  (cond ((>= x 1.0) 0.0) ((<= x -1.0) pi) (T (atan (sqrt (- 1.0 (* x x))) x))))

(defun GH:unit (v / l)
  (setq l (sqrt (+ (* (car v) (car v)) (* (cadr v) (cadr v)))))
  (list (/ (car v) l) (/ (cadr v) l)))

;; 끝점 P 의 두 꼭짓점 (왼쪽 오른쪽) — V_out = P 에서 선 안쪽으로 가는 방향
(defun GH:miter-points (P V_out obj curves half tol / touches inner c o2 st d2 u1 u2 S lenS b phi sn D M1 M2 L_dir R_dir PL)
  (foreach o curves
    (if (not (equal obj o))
      (progn
        (setq c (vlax-curve-getClosestPointTo o P))
        (if (< (distance P c) tol)
          (progn
            (setq touches (cons o touches))
            (if (and (>= (distance c (vlax-curve-getStartPoint o)) tol) (>= (distance c (vlax-curve-getEndPoint o)) tol))
              (setq inner T)))))))
  (setq u1 (GH:unit V_out) L_dir (list (- (cadr u1)) (car u1)) R_dir (list (cadr u1) (- (car u1))))
  (if (or (null touches) inner (> (length touches) 1))
    ;; 혼자 끝 · T자 · 세 갈래 이상: 평평하게
    (list (list (+ (car P) (* (car L_dir) half)) (+ (cadr P) (* (cadr L_dir) half)))
          (list (+ (car P) (* (car R_dir) half)) (+ (cadr P) (* (cadr R_dir) half))))
    ;; L자: 마이터
    (progn
      (setq o2 (car touches)
            st (< (distance (vlax-curve-getClosestPointTo o2 P) (vlax-curve-getStartPoint o2)) tol)
            d2 (vlax-curve-getFirstDeriv o2 (if st (vlax-curve-getStartParam o2) (vlax-curve-getEndParam o2)))
            u2 (GH:unit (if st d2 (mapcar '- d2)))
            S (list (+ (car u1) (car u2)) (+ (cadr u1) (cadr u2)))
            lenS (sqrt (+ (* (car S) (car S)) (* (cadr S) (cadr S)))))
      (if (< lenS 0.001)
        (setq b L_dir D half)                                           ; 일직선으로 이어짐
        (setq b (list (/ (car S) lenS) (/ (cadr S) lenS))
              phi (GH:acos (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2))))
              sn (sin (/ phi 2.0))
              D (if (< sn 0.05) (* half 5.0) (/ half sn))))             ; 너무 뾰족하면 줄임
      (setq M1 (list (+ (car P) (* D (car b))) (+ (cadr P) (* D (cadr b))))
            M2 (list (- (car P) (* D (car b))) (- (cadr P) (* D (cadr b))))
            PL (list (+ (car P) (* (car L_dir) half)) (+ (cadr P) (* (cadr L_dir) half))))
      (if (< (distance M1 PL) (distance M2 PL)) (list M1 M2) (list M2 M1)))))

;; 각도 a→b 를 dir(+1 반시계 / -1 시계) 방향으로 잰 크기 (0 ~ 2π)
(defun GH:sweep (a b dir / d)
  (setq d (* dir (- b a)))
  (while (< d 0.0) (setq d (+ d (* 2 pi))))
  (while (>= d (* 2 pi)) (setq d (- d (* 2 pi))))
  d)

(defun GH:space ( / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc)))

(defun c:GH ( / *error* doc undo_open sv dist half tol ss i o curves spc regs fail p1 p2 pts1 pts2 L1 R1 L2 R2 pl cen base todo x lines ssj k n0
                tmp locked npl nbad lay)
  (defun *error* (msg)
    (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
    (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        dist (cond ((getenv "HyGhThick") (atof (getenv "HyGhThick"))) (*WUX_DIST*) (200.0)))
  (initget 6)
  (setq dist (cond ((getdist (strcat "\n벽 두께 <" (rtos dist 2 2) ">: "))) (dist)))
  (setenv "HyGhThick" (rtos dist 2 8))
  (setq *WUX_DIST* dist)
  (prompt "\n벽 중심선(선·호·폴리선)을 고르세요: ")
  ;; 2D 폴리선까지 (POLYLINE 중 3D 폴리선 8 · 메시 16 · 다면 메시 64 는 뺌)
  (if (null (setq ss (ssget '((-4 . "<OR") (0 . "LINE,ARC,LWPOLYLINE")
                                (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 88) (-4 . "NOT>") (-4 . "AND>")
                              (-4 . "OR>")))))
    (princ "\n고른 중심선이 없습니다.")
    (progn
      (setq half (/ dist 2.0) tol (min 1.0 (/ half 10.0)) i 0 n0 0 npl 0 nbad 0 fail 0 spc (GH:space))
      (setq sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO" "PEDITACCEPT")))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)
      (while (< i (sslength ss))
        (setq o (vlax-ename->vla-object (ssname ss i)))
        (if (wcmatch (vla-get-ObjectName o) "AcDbPolyline,AcDb2dPolyline")
          ;; 폴리선: 원본은 두고 분해한 조각(선·호)을 중심선으로 — 끝나면 조각만 지움
          (progn
            (setq lay (vla-Item (vla-get-Layers doc) (vla-get-Layer o)))
            (if (and (= (vla-get-Lock lay) :vlax-true) (not (member lay locked)))
              (progn (vla-put-Lock lay :vlax-false) (setq locked (cons lay locked))))
            (setq x (vl-catch-all-apply 'vlax-invoke (list o 'Explode)))
            (if (or (vl-catch-all-error-p x) (null x))
              (setq nbad (1+ nbad))
              (progn
                (setq npl (1+ npl))
                (foreach y x
                  (setq tmp (cons y tmp))
                  (if (and (wcmatch (vla-get-ObjectName y) "AcDbLine,AcDbArc")
                           (> (vlax-curve-getDistAtParam y (vlax-curve-getEndParam y)) 1e-6))
                    (setq curves (cons y curves)))))))   ; 겹친 마디(길이 0)는 조용히 뺌
          (if (> (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)) 1e-6) (setq curves (cons o curves)) (setq n0 (1+ n0))))
        (setq i (1+ i)))
      ;; 선마다 띠 → 영역
      (foreach o curves
        (setq p1 (vlax-curve-getStartPoint o) p2 (vlax-curve-getEndPoint o)
              pts1 (GH:miter-points p1 (vlax-curve-getFirstDeriv o (vlax-curve-getStartParam o)) o curves half tol)
              pts2 (GH:miter-points p2 (mapcar '- (vlax-curve-getFirstDeriv o (vlax-curve-getEndParam o))) o curves half tol)
              L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2))
        ;; L1 → R1 (시작 끝) → L2 (오른쪽 면) → R2 (끝 쪽) → L1 (왼쪽 면)
        (setq pl (vlax-invoke spc 'AddLightWeightPolyline
                              (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2))))
        (vla-put-Closed pl :vlax-true)
        (if (= (vla-get-ObjectName o) "AcDbArc")
          (progn
            ;; 반시계 호: 오른쪽 면(바깥)은 반시계로 R1→L2, 왼쪽 면(안)은 시계로 R2→L1 — 면마다 중심에서 본 각도로
            (setq cen (vlax-get o 'Center))
            (vla-SetBulge pl 1 (/ (sin (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0)) (cos (/ (GH:sweep (angle cen R1) (angle cen L2) 1) 4.0))))
            (vla-SetBulge pl 3 (- (/ (sin (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0)) (cos (/ (GH:sweep (angle cen R2) (angle cen L1) -1) 4.0)))))))
        (setq x (vl-catch-all-apply 'vlax-invoke (list spc 'AddRegion (list pl))))
        (if (and (not (vl-catch-all-error-p x)) x) (setq regs (append regs x)) (setq fail (1+ fail)))
        (vla-Delete pl))
      ;; 폴리선을 나눈 임시 조각 지우기 · 잠깐 푼 레이어 다시 잠금
      (foreach y tmp (vl-catch-all-apply 'vla-Delete (list y)))
      (setq tmp nil)
      (foreach l locked (vl-catch-all-apply 'vla-put-Lock (list l :vlax-true)))
      (setq locked nil)
      (if (null regs)
        (princ "\n[주의] 벽체를 만들지 못했습니다.")
        (progn
          ;; 합치기 — 못 합친 조각은 따로 분해 (영역으로 남기지 않음)
          (setq base (car regs) todo (list base))
          (foreach r (cdr regs)
            (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Boolean (list base 0 r)))
              (setq todo (cons r todo) fail (1+ fail))))
          ;; 영역이 남지 않을 때까지 분해
          (while todo
            (setq o (car todo) todo (cdr todo))
            (foreach y (vlax-invoke o 'Explode)
              (if (= (vla-get-ObjectName y) "AcDbRegion") (setq todo (cons y todo)) (setq lines (cons y lines))))
            (vla-Delete o))
          (setq ssj (ssadd))
          (foreach y lines
            (vl-catch-all-apply 'vla-put-Layer (list y (getvar "CLAYER")))
            (vl-catch-all-apply 'vla-put-Color (list y 256))
            (ssadd (vlax-vla-object->ename y) ssj))
          (setvar "PEDITACCEPT" 1)
          (command "_.PEDIT" "_M" ssj "" "_J" (/ tol 10.0) "")
          (setq k 0)
          (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))
          (princ (strcat "\n[완료] 중심선 " (itoa (length curves)) "개로 벽체를 만들어 폴리선으로 이었습니다 (두께 " (rtos dist 2 2)
                         (if (> npl 0) (strcat " · 폴리선 " (itoa npl) "개는 마디마다 나눠 셈") "") ")."
                         (if (> n0 0) (strcat " 길이 0 인 선 " (itoa n0) "개는 건너뜀.") "")
                         (if (> nbad 0) (strcat "\n[주의] 나누지 못한 폴리선 " (itoa nbad) "개는 건너뛰었습니다.") "")
                         (if (> fail 0) (strcat "\n[주의] 합치지 못한 조각 " (itoa fail) "개는 따로 폴리선이 되었습니다 (겹친 곳 확인).") "")))))
      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)))
  (princ))

(princ)
