;;; ==============================================================================
;;;  AM — 면적표 생성
;;;
;;;  실 이름을 넣고 그 실 안쪽을 클릭하기를 되풀이한다. 실마다 클릭한 점에 이름 · m2 · PY 세 줄을 적고,
;;;  이름 칸에서 Enter 로 끝내면 면적표(실 이름 · m2 · PY · 합계)를 놓는다.
;;;   · 경계는 새로 생긴 것만 본다 (예전: 마지막 객체를 경계로 알고 지워 버릴 수 있었음)
;;;   · 경계는 캐드 명령의 옵션 키워드 없이 찾는다 (bpoly — 1.1.1: 캐드 판에 따라 -BOUNDARY 옵션 키워드가 거절됐음)
;;;   · 섬 빼기(기본 끔) · 틈 허용(기본 50mm) · 글자 높이는 옵션으로, 기억한다
;;;   · 직전 실 취소(U) · ESC 로 끝내도 기록은 남아 다음 AM 에서 표(T)로 표만 만들 수 있다
;;;   · 평 = m2 × 0.3025, 합계 = 표에 적힌 값의 합 (칸과 합계가 어긋나지 않게)
;;;   · 도면 단위(INSUNITS)가 m · cm 여도 맞게 환산. 실 하나·표 = 실행 취소 한 번씩(U).
;;; ==============================================================================

(defun am:units ( / u)
  (setq u (getvar "INSUNITS"))
  (cond ((= u 6) '(1.0 0.05 0.3)) ((= u 5) '(1e-4 5.0 30.0)) (T '(1e-6 50.0 300.0))))

;; 경계 찾기에 쓰는 시스템 변수 (이 캐드에 있는 것만) 의 지금 값
(defun am:hpvars ( )
  (vl-remove-if '(lambda (v) (null (cdr v)))
    (mapcar '(lambda (v) (cons v (getvar v))) '("HPGAPTOL" "HPBOUND" "HPISLANDDETECTIONMODE" "HPISLANDDETECTION"))))

;; 점 p(UCS) 둘레 경계 → 새로 생긴 폴리선들 (넓은 것부터, islands 가 아니면 바깥 둘레 하나만) / 없으면 nil.
;;  캐드 명령의 옵션 키워드를 쓰지 않는다 — 캐드 판에 따라 -BOUNDARY 의 옵션 키워드가 거절되어 '옵션 키워드가 유효하지 않음' 뒤 멈췄음.
;;  bpoly 함수로 찾고, 그 함수가 오류면 옵션 없는 -BOUNDARY 로. 틈 · 섬 · 폴리선으로 만들기는 시스템 변수로 넘기고 바로 원래대로.
(defun am:bound (p gap islands / e0 e out old k)
  (setq e0 (entlast) old (am:hpvars))
  (foreach v (list (cons "HPGAPTOL" gap) '("HPBOUND" . 1) (cons "HPISLANDDETECTIONMODE" (if islands 1 0)) '("HPISLANDDETECTION" . 1))
    (if (assoc (car v) old) (vl-catch-all-apply 'setvar (list (car v) (cdr v)))))
  (if (vl-catch-all-error-p (vl-catch-all-apply 'bpoly (list p)))
    (progn
      (command "_.-BOUNDARY" "_non" p "")
      (setq k 0)
      (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))))
  (foreach v old (vl-catch-all-apply 'setvar (list (car v) (cdr v))))
  (setq e (if e0 (entnext e0) (entnext)))
  (while e
    (if (and (entget e) (wcmatch (cdr (assoc 0 (entget e))) "LWPOLYLINE,POLYLINE")) (setq out (cons e out)))
    (setq e (entnext e)))
  (setq out (vl-sort out '(lambda (a b) (> (vla-get-Area (vlax-ename->vla-object a)) (vla-get-Area (vlax-ename->vla-object b))))))
  (if (and (cdr out) (not islands))
    (progn (foreach x (cdr out) (entdel x)) (setq out (list (car out)))))
  out)

;; 세 줄 글자 (MTEXT, 가운데) — UCS 방향
(defun am:label (s p h)
  (entmake (list '(0 . "MTEXT") '(100 . "AcDbEntity") '(100 . "AcDbMText") (cons 10 (trans p 1 0)) (cons 40 h)
                 '(41 . 0.0) '(71 . 5) '(72 . 5) (cons 1 s) (cons 7 (getvar "TEXTSTYLE"))
                 (cons 11 (trans '(1.0 0.0 0.0) 1 0 T)) (cons 210 (trans '(0.0 0.0 1.0) 1 0 T))))
  (entlast))

(defun am:r2 (x) (/ (fix (+ (* (abs x) 100.0) 0.5)) (if (minusp x) -100.0 100.0)))
(defun am:s2 (x / s) (setq s (rtos x 2 2)) (if (not (vl-string-search "." s)) (strcat s ".00")
                                              (if (= (- (strlen s) (vl-string-search "." s)) 2) (strcat s "0") s)))

;; 표: rows = ((이름 m2 평) …) — 값은 소수 둘째 자리 수
(defun am:table (rows p h / doc spc tbl r tm tp)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        spc (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
        tbl (vla-AddTable spc (vlax-3d-point (trans p 1 0)) (+ (length rows) 3) 3 (* 2.2 h) (* 8.0 h)))
  (vla-SetTextHeight tbl 7 h)
  (vla-SetColumnWidth tbl 0 (* 12.0 h))
  (vla-SetText tbl 0 0 "면적 산출표")
  (vla-SetText tbl 1 0 "실 이름")
  (vla-SetText tbl 1 1 "면적 (m2)")
  (vla-SetText tbl 1 2 "면적 (PY)")
  (setq r 2 tm 0.0 tp 0.0)
  (foreach row rows
    (vla-SetText tbl r 0 (car row))
    (vla-SetText tbl r 1 (am:s2 (cadr row)))
    (vla-SetText tbl r 2 (am:s2 (caddr row)))
    (setq tm (+ tm (cadr row)) tp (+ tp (caddr row)) r (1+ r)))
  (vla-SetText tbl r 0 "합 계")
  (vla-SetText tbl r 1 (am:s2 tm))
  (vla-SetText tbl r 2 (am:s2 tp))
  tbl)

(defun c:AM ( / *error* doc sv undo_open un name pt ents area m2 py lab rows labs v tp)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if rows
      (progn
        (setq *am_last* (reverse rows))
        (princ (strcat "\n[알림] 실 " (itoa (length rows)) "개 기록은 남겨 두었습니다. AM 에서 표(T)를 고르면 표만 만듭니다."))))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (cons (cons "CMDECHO" (getvar "CMDECHO")) (am:hpvars))
        un (am:units))
  (setvar "CMDECHO" 0)
  (if (null *am_gap*) (setq *am_gap* (cadr un)))
  (if (null *am_h*) (setq *am_h* (if (> (getvar "TEXTSIZE") (* 20.0 (caddr un) 0.01)) (getvar "TEXTSIZE") (caddr un))))
  ;; 1. 실마다 이름 → 클릭
  (while
    (progn
      (setq name (getstring T (strcat "\n실 이름 [" (if rows "직전 취소=U / " "") (if (and *am_last* (null rows)) "지난 기록으로 표=T / " "")
                                      "섬 빼기=I " (if *am_isl* "켬" "끔") " / 글자 높이=H / 틈=G] <끝>: ")))
      (/= name ""))
    (cond
      ((and rows (= (strcase name) "U"))
       (if (entget (car labs)) (entdel (car labs)))
       (princ (strcat "\n[" (car (car rows)) "] 을(를) 지웠습니다."))
       (setq rows (cdr rows) labs (cdr labs)))
      ((and *am_last* (null rows) (= (strcase name) "T"))
       (setq rows (reverse *am_last*) *am_last* nil)
       (princ (strcat "\n지난 기록 " (itoa (length rows)) "개로 표를 만듭니다. Enter 를 누르세요.")))
      ((= (strcase name) "I") (setq *am_isl* (not *am_isl*)))
      ((= (strcase name) "H") (initget 6) (if (setq v (getdist (strcat "\n글자 높이 <" (rtos *am_h* 2 2) ">: "))) (setq *am_h* v)))
      ((= (strcase name) "G") (initget 4) (if (setq v (getdist (strcat "\n틈 허용 <" (rtos *am_gap* 2 2) ">: "))) (setq *am_gap* v)))
      ((setq pt (getpoint (strcat "\n[" name "] 의 안쪽을 클릭하세요: ")))
       (vla-StartUndoMark doc)
       (setq undo_open T)
       (setq ents (am:bound pt *am_gap* *am_isl*))
       (if (null ents)
         (princ (strcat "\n[주의] 닫힌 경계를 찾지 못했습니다 (틈 " (rtos *am_gap* 2 2) " · 화면 밖). [" name "] 은(는) 적지 않았습니다."))
         (progn
           (setq area (- (vla-get-Area (vlax-ename->vla-object (car ents)))
                         (apply '+ (mapcar '(lambda (e) (vla-get-Area (vlax-ename->vla-object e))) (cdr ents))))
                 m2 (am:r2 (* area (car un)))
                 py (am:r2 (* area (car un) 0.3025)))
           (foreach e ents (entdel e))
           (setq lab (am:label (strcat name "\\P" (am:s2 m2) " m2\\P" (am:s2 py) " PY") pt *am_h*)
                 rows (cons (list name m2 py) rows)
                 labs (cons lab labs))
           (princ (strcat "\n[" name "] " (am:s2 m2) " m2 · " (am:s2 py) " PY"
                          (if (cdr ents) (strcat " (섬 " (itoa (length (cdr ents))) "개 뺌)") "")))))
       (vla-EndUndoMark doc)
       (setq undo_open nil))))
  ;; 2. 표
  (if rows
    (progn
      (setq tp (getpoint "\n면적표를 놓을 곳(왼쪽 위)을 클릭하세요 <표 없이 끝>: "))
      (if tp
        (progn
          (vla-StartUndoMark doc)
          (setq undo_open T)
          (am:table (reverse rows) tp *am_h*)
          (vla-EndUndoMark doc)
          (setq undo_open nil *am_last* nil)
          (princ (strcat "\n[완료] 실 " (itoa (length rows)) "개의 면적표를 만들었습니다.")))
        (progn
          (setq *am_last* (reverse rows))
          (princ "\n[알림] 표는 만들지 않았습니다. 다음 AM 에서 표(T)로 만들 수 있습니다.")))
      (setq rows nil))
    (princ "\n적은 실이 없어 표를 만들지 않습니다."))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
