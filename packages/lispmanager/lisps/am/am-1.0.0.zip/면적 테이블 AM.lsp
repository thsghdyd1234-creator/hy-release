(defun c:AM ( / pt bpoly area_mm area_m2 area_py room_name data_list table_pt objTable i row total_m2 total_py old_cmd )
  (vl-load-com)
  (setq old_cmd (getvar "cmdecho"))
  (setvar "cmdecho" 0)
  (setq data_list '())
  (setq total_m2 0.0)
  (setq total_py 0.0)

  (princ "\n[Area Master] 실 이름을 입력하고 내부를 클릭하세요. (명령 종료: 이름 입력창에서 Enter)")

  ;; --- 1단계: 데이터 수집 (버그 수정됨) ---
  ;; getstring이 ""(빈 문자열)과 같지 않을 때만(/=) 루프가 돌아가도록 조건 변경
  (while (/= (setq room_name (getstring T "\n실 이름 입력 (종료는 Enter): ")) "")
    (prompt (strcat "\n[" room_name "]의 내부 점을 클릭하세요: "))
    (if (setq pt (getpoint))
      (progn
        (command "-boundary" "A" "O" "P" "" pt "")
        (setq bpoly (entlast))
        (if (and bpoly (= (cdr (assoc 0 (entget bpoly))) "LWPOLYLINE"))
          (progn
            (command "_.area" "_O" bpoly)
            (setq area_mm (getvar "area"))
            
            ;; 단위 환산
            (setq area_m2 (/ area_mm 1000000.0))
            (setq area_py (/ area_m2 3.3058))
            
            ;; 총합계 누적
            (setq total_m2 (+ total_m2 area_m2))
            (setq total_py (+ total_py area_py))
            
            ;; 도면에 3줄 텍스트 배치 (이름 / m2 / PY)
            (command "_.mtext" pt "_J" "_MC" "_W" 0 (strcat room_name "\\P" (rtos area_m2 2 2) " m2\\P" (rtos area_py 2 2) " PY") "")
            
            ;; 리스트에 데이터 저장
            (setq data_list (cons (list room_name (rtos area_m2 2 2) (rtos area_py 2 2)) data_list))
            
            (entdel bpoly)
            (princ (strcat "\n" room_name " 기록 완료."))
          )
          (princ "\n[오류] 닫힌 경계가 아닙니다.")
        )
      )
    )
  )

  ;; --- 2단계: 테이블 생성 (엔터를 쳐서 루프를 빠져나오면 여기로 진입) ---
  (if (> (length data_list) 0)
    (progn
      (setq data_list (reverse data_list))
      (setq table_pt (getpoint "\n면적표를 배치할 지점을 클릭하세요: "))
      
      (if table_pt
        (progn
          ;; 표 생성
          (setq objTable (vla-addtable 
                           (vla-get-modelspace (vla-get-activedocument (vlax-get-acad-object)))
                           (vlax-3d-point table_pt)
                           (+ (length data_list) 3) 3 10 35)) 
          
          ;; 헤더 작성
          (vla-settext objTable 0 0 "면적 산출표")
          (vla-settext objTable 1 0 "실 이름")
          (vla-settext objTable 1 1 "면적 (m2)")
          (vla-settext objTable 1 2 "면적 (PY)")
          
          ;; 데이터 채우기
          (setq row 2)
          (foreach item data_list
            (vla-settext objTable row 0 (car item))
            (vla-settext objTable row 1 (cadr item))
            (vla-settext objTable row 2 (caddr item))
            (setq row (1+ row))
          )
          
          ;; 마지막 줄에 '총합계' 추가
          (vla-settext objTable row 0 "합 계")
          (vla-settext objTable row 1 (rtos total_m2 2 2))
          (vla-settext objTable row 2 (rtos total_py 2 2))
          
          (princ "\n면적표 생성이 완료되었습니다!")
        )
      )
    )
    (princ "\n기록된 데이터가 없어 표를 생성하지 않습니다.")
  )

  (setvar "cmdecho" old_cmd)
  (princ)
)