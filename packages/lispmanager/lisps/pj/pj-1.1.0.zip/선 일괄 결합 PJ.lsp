;;; ============================================================
;;; PJ.lsp  -  선/호/폴리선 정리 후 일괄 결합 · 세그먼트 최적화
;;; 명령: PJ
;;;
;;; 처리 순서
;;;   1. 선(LINE)·호(ARC)는 LW폴리선으로 변환
;;;   2. 2D 헤비 폴리선은 LW폴리선으로 변환 (맞춤/스플라인은 해제)
;;;      스플라인(SPLINE)·타원(ELLIPSE)은 현 오차 기준으로 분할해 LW폴리선으로 변환
;;;   3. 닫힌 폴리선 열기 (닫는 변은 끝에 첫 점을 더해 남김)
;;;   4. 법선이 뒤집힌(0,0,-1) 객체 보정
;;;   5. 고도/Z값 0으로 평탄화
;;;   6. 겹친(연속 중복) 정점 제거, 길이 0 객체 삭제
;;;   7. PEDIT 다중 결합 (결합 형식 = 둘 다, 퍼지 거리 적용)
;;;   8. 끝점이 시작점과 만나는 폴리선은 다시 닫음
;;;   9. 세그먼트 최적화 - 한 직선 위의 조각은 선분 하나로, 한 원 위의 조각은 호 하나로 합침.
;;;      합친 선이 원래 선에서 허용 오차보다 멀어지지 않을 때만 합친다 (꺾인 모서리는 그대로).
;;;      퍼지 거리 질문에서 O 로 허용 오차를 바꾸거나 0 으로 끈다 (캐드를 끌 때까지 기억).
;;;
;;; 제외: 3D 폴리선, 메쉬, 기울어진 평면의 객체 (건드리지 않음). 폭이 있는 폴리선은 최적화하지 않음.
;;; 참고: 1~6 에서 다시 만든 객체는 XDATA·하이퍼링크가 유지되지 않음 (8·9 는 객체를 그대로 고침)
;;; ============================================================

(vl-load-com)

(setq *PJ-FUZZ-DEFAULT* 1.0          ; 퍼지 거리 기본값
      *PJ-TOL*          1e-4         ; 겹친 정점 판정 허용오차
      *PJ-SPL-TOL*      0.01         ; 스플라인 변환 시 곡선과 폴리선 사이 최대 오차 (도면 단위)
      *PJ-SPL-INIT*     16           ; 스플라인 초기 분할 수 (S자 굴곡 누락 방지)
      *PJ-ARC-MAX*      (* 1.5 pi))  ; 최적화로 합친 호 하나의 최대 중심각

;;; ---------- 유틸 ----------
(defun pj:g (k d df) (if (assoc k d) (cdr (assoc k d)) df))

(defun pj:flip-p (n)   ; 법선 (0,0,-1)
  (and (equal (car n) 0.0 1e-9) (equal (cadr n) 0.0 1e-9) (< (caddr n) 0.0)))

(defun pj:tilt-p (n)   ; Z축과 평행하지 않은 법선
  (not (and (equal (car n) 0.0 1e-9) (equal (cadr n) 0.0 1e-9))))

(defun pj:props (d)    ; 유지할 공통 속성
  (vl-remove-if-not
    '(lambda (x) (member (car x) '(8 6 62 370 48 420 430 440 39)))
    d))

(defun pj:take (l m / out)   ; 앞에서 m 개
  (repeat m (setq out (cons (car l) out) l (cdr l)))
  (reverse out))

(defun pj:skip (l m)         ; 앞에서 m 개를 뺀 나머지
  (repeat m (setq l (cdr l)))
  l)

;;; 정점 레코드: (점2D 시작폭 끝폭 볼록)
(defun pj:lw-verts (d / vs cur)
  (foreach x d
    (cond
      ((= (car x) 10)
       (if cur (setq vs (cons cur vs)))
       (setq cur (list (cdr x) 0.0 0.0 0.0)))
      ((and cur (= (car x) 40)) (setq cur (list (car cur) (cdr x) (caddr cur) (cadddr cur))))
      ((and cur (= (car x) 41)) (setq cur (list (car cur) (cadr cur) (cdr x) (cadddr cur))))
      ((and cur (= (car x) 42)) (setq cur (list (car cur) (cadr cur) (caddr cur) (cdr x))))))
  (if cur (setq vs (cons cur vs)))
  (reverse vs))

(defun pj:hv-verts (e fitted / v d all has16 fl p vs)
  (setq v (entnext e))
  (while (and v (= (cdr (assoc 0 (setq d (entget v)))) "VERTEX"))
    (setq all (cons d all) v (entnext v)))
  (setq all (reverse all))
  ;; 스플라인 맞춤이면 원래 조정점(16)만, 곡선 맞춤이면 생성 정점(1) 제외
  (setq has16 (vl-some '(lambda (x) (= 16 (logand 16 (pj:g 70 x 0)))) all))
  (foreach d all
    (setq fl (pj:g 70 d 0) p (cdr (assoc 10 d)))
    (if (if has16 (= 16 (logand 16 fl)) (zerop (logand 1 fl)))
      (setq vs (cons (list (list (car p) (cadr p))
                           (pj:g 40 d 0.0) (pj:g 41 d 0.0)
                           (if fitted 0.0 (pj:g 42 d 0.0)))
                     vs))))
  (reverse vs))

(defun pj:dedupe (vs / out)
  ;; 같은 자리 정점은 앞 정점 위치 + 뒤 정점의 세그먼트 속성으로 합침
  (foreach v vs
    (if (and out (< (distance (car v) (car (car out))) *PJ-TOL*))
      (setq out (cons (cons (car (car out)) (cdr v)) (cdr out)))
      (setq out (cons v out))))
  (reverse out))

(defun pj:make-lw (props fl elev vs)
  (entmake
    (append
      (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity"))
      props
      (list '(100 . "AcDbPolyline")
            (cons 90 (length vs)) (cons 70 fl) (cons 38 elev))
      (apply 'append
        (mapcar '(lambda (v)
                   (list (cons 10 (car v)) (cons 40 (cadr v))
                         (cons 41 (caddr v)) (cons 42 (cadddr v))))
                vs))
      (list '(210 0.0 0.0 1.0))))
  (entlast))

;;; 있는 LW폴리선 목록 d 의 정점만 vs (점 시작폭 끝폭 볼록) 로 바꾼 목록 — entmod 용 (핸들·XDATA 그대로)
(defun pj:new-list (d vs closed / x hd)
  (while (and d (/= (car (car d)) 10))
    (setq x (car d) d (cdr d)
          hd (cons (cond ((= (car x) 90) (cons 90 (length vs)))
                         ((= (car x) 70) (cons 70 (if closed (logior (cdr x) 1) (logand (cdr x) (~ 1)))))
                         (T x))
                   hd)))
  (append (reverse hd)
          (apply 'append
            (mapcar '(lambda (v)
                       (list (cons 10 (car v)) (cons 40 (cadr v)) (cons 41 (caddr v)) (cons 42 (cadddr v))))
                    vs))
          (vl-remove-if '(lambda (x) (member (car x) '(10 40 41 42 91))) d)))

;;; ---------- 정리 (결과 ename 반환, 제외/삭제는 nil) ----------
(defun pj:fix (e d vs fl elev force / n nv changed)
  (setq n (pj:g 210 d '(0.0 0.0 1.0)) changed force)
  (if (pj:tilt-p n)
    (progn (setq cSkip (1+ cSkip)) nil)
    (progn
      (if (= 1 (logand fl 1))
        ;; 열 때 닫는 변이 사라지지 않게 끝에 첫 점을 더함 (끝 점이 첫 점과 같으면 아래 겹친 정점 제거가 합침)
        (setq vs (append vs (list (list (car (car vs)) 0.0 0.0 0.0)))
              fl (1- fl) cOpen (1+ cOpen) changed T))
      (if (pj:flip-p n)
        (setq vs (mapcar '(lambda (v)
                            (list (list (- (car (car v))) (cadr (car v)))
                                  (cadr v) (caddr v) (- (cadddr v))))
                         vs)
              elev (- elev) cFlip (1+ cFlip) changed T))
      (if (/= elev 0.0)
        (setq elev 0.0 cFlat (1+ cFlat) changed T))
      (setq nv (pj:dedupe vs))
      (if (< (length nv) (length vs))
        (setq cDup (+ cDup (- (length vs) (length nv))) changed T))
      (cond
        ((< (length nv) 2) (entdel e) (setq cZero (1+ cZero)) nil)
        (changed
         (setq n (pj:make-lw (pj:props d) (logand fl 128) elev nv))
         (entdel e)
         n)
        (T e)))))

(defun pj:fix-line (e d / p q)
  (setq p (cdr (assoc 10 d)) q (cdr (assoc 11 d)))
  (if (or (/= 0.0 (caddr p)) (/= 0.0 (caddr q))) (setq cFlat (1+ cFlat)))
  ;; 선 끝점은 WCS 기준이므로 법선(210)은 무시
  (pj:fix e (vl-remove (assoc 210 d) d)
          (list (list (list (car p) (cadr p)) 0.0 0.0 0.0)
                (list (list (car q) (cadr q)) 0.0 0.0 0.0))
          0 0.0 T))

(defun pj:fix-arc (e d / c c2 r s en da bul)
  (setq c  (cdr (assoc 10 d))
        c2 (list (car c) (cadr c))
        r  (cdr (assoc 40 d))
        s  (cdr (assoc 50 d))
        en (cdr (assoc 51 d))
        da (- en s))
  (if (<= da 0.0) (setq da (+ da (* 2 pi))))
  (setq bul (/ (sin (/ da 4.0)) (cos (/ da 4.0))))
  (pj:fix e d
          (list (list (polar c2 s r) 0.0 0.0 bul)
                (list (polar c2 en r) 0.0 0.0 0.0))
          0 (caddr c) T))

;;; ---------- 스플라인/타원 → 폴리선 ----------
(defun pj:dseg (p a b / dx dy l2 u)   ; 점 p와 선분 ab 사이 거리 (2D)
  (setq dx (- (car b) (car a)) dy (- (cadr b) (cadr a)) l2 (+ (* dx dx) (* dy dy)))
  (if (< l2 1e-20)
    (distance p a)
    (progn
      (setq u (/ (+ (* (- (car p) (car a)) dx) (* (- (cadr p) (cadr a)) dy)) l2))
      (setq u (max 0.0 (min 1.0 u)))
      (distance p (list (+ (car a) (* u dx)) (+ (cadr a) (* u dy)))))))

(defun pj:p2 (p) (list (car p) (cadr p)))

(defun pj:sub (e a b pa pb dep tol / m pm)   ; 오차가 tol 이하가 될 때까지 이분할
  (setq m (/ (+ a b) 2.0) pm (pj:p2 (vlax-curve-getPointAtParam e m)))
  (if (and (< dep 12) (> (pj:dseg pm pa pb) tol))
    (append (pj:sub e a m pa pm (1+ dep) tol) (pj:sub e m b pm pb (1+ dep) tol))
    (list pb)))

(defun pj:fix-curve (e d tol / t0 t1 k a b pa pb pts)
  (setq t0 (vlax-curve-getStartParam e) t1 (vlax-curve-getEndParam e)
        pa (pj:p2 (vlax-curve-getPointAtParam e t0)) pts (list pa) k 0)
  (repeat *PJ-SPL-INIT*
    (setq a  (+ t0 (* (- t1 t0) (/ k (float *PJ-SPL-INIT*))))
          k  (1+ k)
          b  (+ t0 (* (- t1 t0) (/ k (float *PJ-SPL-INIT*))))
          pb (pj:p2 (vlax-curve-getPointAtParam e b))
          pts (append pts (pj:sub e a b pa pb 0 tol))
          pa pb))
  (setq cSpl (1+ cSpl))
  ;; 점은 WCS 기준이므로 법선(210) 무시, Z는 버림
  (pj:fix e (vl-remove (assoc 210 d) d)
          (mapcar '(lambda (p) (list p 0.0 0.0 0.0)) pts)
          0 0.0 T))

;;; ---------- 다시 닫기 ----------
;;; 열린 폴리선의 끝 점이 첫 점과 같으면 끝 점을 빼고 닫음 (닫는 변 = 마지막 조각)
(defun pj:reclose (e / d vs)
  (setq d (entget e) vs (pj:lw-verts d))
  (if (and (= 0 (logand (pj:g 70 d 0) 1)) (> (length vs) 2)
           (< (distance (car (car vs)) (car (last vs))) *PJ-TOL*))
    (progn
      (entmod (pj:new-list d (pj:take vs (1- (length vs))) T))
      (entupd e)
      T)))

;;; ---------- 세그먼트 최적화 ----------
;;; 조각 레코드: (시작점 볼록 안쪽점) — 안쪽점 = 호 조각 위의 점 7개 (직선 조각은 nil), 마지막 레코드는 끝점.
;;; 몇 조각을 하나로 합칠 때는 합친 선이 원래 선(꼭짓점 · 호 위의 점 · 직선 조각)에서 tol 안이고
;;; 원래 선의 순서대로 나아갈 때만 합친다 (되돌아가는 선 · 꺾인 모서리는 안 합침).

(defun pj:arc-pts (p q b / c th mid ux uy r o a0 k out)   ; 호 조각 위의 안쪽 점 7개
  (setq c   (distance p q)
        th  (* 4.0 (atan b))
        mid (list (/ (+ (car p) (car q)) 2.0) (/ (+ (cadr p) (cadr q)) 2.0))
        ux  (/ (- (cadr p) (cadr q)) c)                              ; 현의 왼쪽 법선
        uy  (/ (- (car q) (car p)) c)
        r   (/ c (* 2.0 (/ (sin (/ th 2.0)) (cos (/ th 2.0)))))      ; 현 가운데에서 중심까지 (부호 있음)
        o   (list (+ (car mid) (* ux r)) (+ (cadr mid) (* uy r)))
        r   (distance o p)
        a0  (angle o p)
        k   1)
  (repeat 7
    (setq out (cons (polar o (+ a0 (* th (/ k 8.0))) r) out) k (1+ k)))
  (reverse out))

(defun pj:recs (vs / out)   ; (점 볼록) 목록 → 조각 레코드
  (while vs
    (setq out (cons (list (car (car vs)) (cadr (car vs))
                          (if (and (cdr vs) (> (abs (cadr (car vs))) 1e-9))
                            (pj:arc-pts (car (car vs)) (car (cadr vs)) (cadr (car vs)))))
                    out)
          vs (cdr vs)))
  (reverse out))

(defun pj:inner (r k)   ; k 번째 조각에서 볼 점: 시작 꼭짓점(첫 조각은 빼고) + 호 위의 점
  (if (= k 0) (caddr (car r)) (cons (car (car r)) (caddr (car r)))))

;;; rs 의 첫 꼭짓점부터 m 조각을 선분 하나로 합칠 수 있는가
(defun pj:line-ok (rs m tol / a b ux uy l k r t0 tt p ok)
  (setq a (car (car rs)) b (car (nth m rs))
        ux (- (car b) (car a)) uy (- (cadr b) (cadr a))
        l (sqrt (+ (* ux ux) (* uy uy))))
  (if (> l 1e-9)
    (progn
      (setq ux (/ ux l) uy (/ uy l) t0 0.0 ok T k 0 r rs)
      (while (and ok (< k m))
        (foreach p (pj:inner r k)
          (if ok
            (progn
              (setq tt (+ (* (- (car p) (car a)) ux) (* (- (cadr p) (cadr a)) uy)))
              (if (or (> (abs (- (* (- (cadr p) (cadr a)) ux) (* (- (car p) (car a)) uy))) tol) ; 선에서 거리
                      (< tt (- t0 tol))                                                       ; 되돌아감
                      (> tt (+ l tol)))
                (setq ok nil)
                (if (> tt t0) (setq t0 tt))))))
        (setq r (cdr r) k (1+ k)))
      ok)))

(defun pj:circ3 (a b c / bx by cx cy dd b2 c2)   ; 세 점을 지나는 원의 중심 (a 를 원점으로 계산 — 큰 좌표에서도 정확)
  (setq bx (- (car b) (car a)) by (- (cadr b) (cadr a))
        cx (- (car c) (car a)) cy (- (cadr c) (cadr a))
        dd (* 2.0 (- (* bx cy) (* by cx))))
  (if (/= dd 0.0)
    (progn
      (setq b2 (+ (* bx bx) (* by by)) c2 (+ (* cx cx) (* cy cy)))
      (list (+ (car a) (/ (- (* cy b2) (* by c2)) dd))
            (+ (cadr a) (/ (- (* bx c2) (* cx b2)) dd))))))

;;; rs 의 첫 꼭짓점부터 m 조각을 호 하나로 합칠 수 있으면 그 호의 볼록 값, 아니면 nil
(defun pj:arc-ok (rs m tol / a b bx by l k r p pts segs h hm c o dir va rr th u ux uy tola w f fp ok)
  (setq a (car (car rs)) b (car (nth m rs))
        bx (- (car b) (car a)) by (- (cadr b) (cadr a))
        l (sqrt (+ (* bx bx) (* by by))) hm 0.0 k 0 r rs)
  (if (> l 1e-9)
    (progn
      ;; 볼 점 (차례대로) · 직선 조각 · 현에서 가장 먼 점 c
      (while (< k m)
        (foreach p (pj:inner r k)
          (setq pts (cons p pts)
                h (abs (- (* bx (- (cadr p) (cadr a))) (* by (- (car p) (car a))))))
          (if (> h hm) (setq hm h c p)))
        (if (null (caddr (car r))) (setq segs (cons (list (car (car r)) (car (cadr r))) segs)))
        (setq r (cdr r) k (1+ k)))
      (if (not (and c (> hm (* 1e-9 l l)) (setq o (pj:circ3 a b c))))
        ;; 한 직선 위 = 반지름이 끝없는 호 — 더 길게 보면 호가 될 수 있으니 직선으로 맞으면 통과 (볼록 0)
        (if (pj:line-ok rs m tol) 0.0)
        (progn
          (setq dir (if (> (- (* (- (car c) (car a)) by) (* (- (cadr c) (cadr a)) bx)) 0.0) 1.0 -1.0)  ; a→c→b 가 반시계면 1
                va  (list (- (car a) (car o)) (- (cadr a) (cadr o)))
                rr  (sqrt (+ (* (car va) (car va)) (* (cadr va) (cadr va))))
                th  (atan (* dir (- (* (car va) (- (cadr b) (cadr o))) (* (cadr va) (- (car b) (car o)))))
                          (+ (* (car va) (- (car b) (car o))) (* (cadr va) (- (cadr b) (cadr o))))))
          (if (<= th 0.0) (setq th (+ th (* 2.0 pi))))
          (if (and (<= th *PJ-ARC-MAX*) (> rr tol))
            (progn
              ;; 호 가운데 방향 u 에서 잰 각 f: 차례대로 -th/2 → th/2
              (setq u (+ (atan (cadr va) (car va)) (* dir (/ th 2.0)))
                    ux (cos u) uy (sin u) tola (/ tol rr) fp (- (/ th 2.0)) ok T)
              (foreach p (reverse pts)
                (if ok
                  (progn
                    (setq w (list (- (car p) (car o)) (- (cadr p) (cadr o))))
                    (if (> (abs (- (sqrt (+ (* (car w) (car w)) (* (cadr w) (cadr w)))) rr)) tol)
                      (setq ok nil)
                      (progn
                        (setq f (atan (* dir (- (* ux (cadr w)) (* uy (car w))))
                                      (+ (* ux (car w)) (* uy (cadr w)))))
                        (if (or (< f (- fp tola)) (> f (+ (/ th 2.0) tola)))
                          (setq ok nil)
                          (if (> f fp) (setq fp f))))))))
              ;; 직선 조각이 원 안으로 tol 보다 깊이 들어가지 않는지 (원 중심에서 가장 가까운 점)
              (foreach p segs
                (if (and ok (< (pj:dseg o (car p) (cadr p)) (- rr tol))) (setq ok nil)))
              (if ok (* dir (/ (sin (/ th 4.0)) (cos (/ th 4.0))))))))))))

;;; fn 이 되는 가장 긴 조각 수 (1 = 원래 조각 그대로). 두 배씩 늘려 보고 사이를 반씩 좁힌다.
(defun pj:longest (fn rs n tol / lo hi m)
  (setq lo 1 hi (1+ n) m 2)
  (while (and (< m hi) (apply fn (list rs m tol)))
    (setq lo m m (* m 2)))
  (if (< m hi) (setq hi m))
  (while (> (- hi lo) 1)
    (setq m (/ (+ lo hi) 2))
    (if (apply fn (list rs m tol)) (setq lo m) (setq hi m)))
  lo)

;;; 열린 사슬 하나 최적화 → (점 볼록) 목록
(defun pj:opt-chain (rs tol / out n eps a ml ma bg m me mae x)
  (setq n (1- (length rs)) eps (* 0.001 tol))
  (while (> n 0)
    (setq a  (car (car rs))
          ml (pj:longest 'pj:line-ok rs n tol)
          ma (if (> n 1) (pj:longest 'pj:arc-ok rs n tol) 1)
          bg (if (> ma ml) (pj:arc-ok rs ma tol)))
    ;; 현에서 tol 안으로 납작한 호는 쓰지 않음 (선분이 맞음)
    (if (and bg (<= (* 0.5 (abs bg) (distance a (car (nth ma rs)))) tol)) (setq bg nil))
    (setq m  (if bg ma ml)
          bg (cond (bg) ((> ml 1) 0.0) (T (cadr (car rs)))))
    ;; 원래부터 곧은 선·호(오차 eps 안)가 고른 길이의 반 이상이면 거기서 끊음
    ;; — 곧은 벽선 끝이 이어지는 곡선 쪽으로 넘어가 미세하게 기울거나, 정확한 호의 반지름이 바뀌지 않게
    (if (> m 1)
      (progn
        (setq me  (pj:longest 'pj:line-ok rs m eps)
              mae (pj:longest 'pj:arc-ok rs m eps)
              x   (max me mae))
        (if (and (< x m) (>= (distance a (car (nth x rs))) (* 0.5 (distance a (car (nth m rs))))))
          (setq m  x
                bg (cond ((> mae me) (pj:arc-ok rs mae eps))
                         ((> me 1) 0.0)
                         (T (cadr (car rs))))))))
    (setq out (cons (list a bg) out)
          rs (pj:skip rs m) n (- n m)))
  (reverse (cons (list (car (car rs)) 0.0) out)))

(defun pj:turn (pv v nv / x)   ; 꼭짓점 v 에서 꺾이는 각 (pv→v 끝 접선과 v→nv 시작 접선 사이)
  (setq x (- (- (angle (car v) (car nv)) (* 2.0 (atan (cadr v))))
             (+ (angle (car pv) (car v)) (* 2.0 (atan (cadr pv))))))
  (atan (sin x) (cos x)))

(defun pj:seam (vs / i best bi)   ; 닫힌 폴리선: 가장 많이 꺾인 꼭짓점에서 시작하게 돌림
  (setq i 0 best -1.0 bi 0)
  (foreach x (mapcar '(lambda (pv v nv) (abs (pj:turn pv v nv)))
                     (cons (last vs) vs) vs (append (cdr vs) (list (car vs))))
    (if (> x best) (setq best x bi i))
    (setq i (1+ i)))
  (append (pj:skip vs bi) (pj:take vs bi)))

;;; LW폴리선 하나 최적화 (객체를 그대로 고침). 세그먼트 수를 sBefore · sAfter 에 더함
(defun pj:optimize (e tol / d vs closed n nv)
  (setq d (entget e) closed (= 1 (logand (pj:g 70 d 0) 1)) vs (pj:lw-verts d) n (length vs))
  (cond
    ((< n 2) nil)
    ((or (/= 0.0 (pj:g 43 d 0.0))
         (vl-some '(lambda (v) (or (/= 0.0 (cadr v)) (/= 0.0 (caddr v)))) vs))
     (setq cWide (1+ cWide)) nil)
    (T
     (setq vs (mapcar '(lambda (v) (list (car v) (cadddr v))) (pj:dedupe vs)))
     (if (and closed (> (length vs) 2) (< (distance (car (car vs)) (car (last vs))) *PJ-TOL*))
       (setq vs (pj:take vs (1- (length vs)))))
     (if (< (length vs) 2)
       nil
       (progn
         (if closed
           (setq vs (pj:seam vs)
                 vs (append vs (list (list (car (car vs)) 0.0)))))
         (setq nv (pj:opt-chain (pj:recs vs) tol))
         (if closed (setq nv (pj:take nv (1- (length nv)))))
         (setq sBefore (+ sBefore (if closed n (1- n)))
               sAfter  (+ sAfter (if closed (length nv) (1- (length nv)))))
         (if (/= (length nv) n)
           (progn
             (entmod (pj:new-list d (mapcar '(lambda (v) (list (car v) 0.0 0.0 (cadr v))) nv) closed))
             (entupd e)
             (setq cOpt (1+ cOpt))))
         T)))))

(defun pj:unit-tol (/ u)   ; 최적화 허용 오차 기본값 = 0.5mm 를 도면 단위로
  (setq u (getvar "INSUNITS"))
  (cond ((= u 6) 0.0005) ((= u 5) 0.05) ((= u 1) 0.02) ((= u 2) 0.0016) (T 0.5)))

(defun pj:opt-str (v) (if (> v 0.0) (strcat "허용 오차 " (rtos v 2 4)) "끔"))

(defun pj:tally (pairs / out)   ; ((이름 . 수) …) 중 0 이 아닌 것만 한 줄로
  (foreach p pairs
    (if (> (cdr p) 0)
      (setq out (strcat (if out (strcat out " · ") "") (car p) " " (itoa (cdr p))))))
  out)

;;; ---------- 메인 ----------
(defun c:PJ (/ *error* doc sv undo_open ss fz x v tol spl i e d typ fl fit ne lst nss res e0 n0 n1
               cOpen cDup cFlip cFlat cZero cSkip cFit cSpl cClose cWide cOpt sBefore sAfter)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (defun *error* (msg / v)
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (if (null *pj-opt-tol*) (setq *pj-opt-tol* (pj:unit-tol)))
  (setq cOpen 0 cDup 0 cFlip 0 cFlat 0 cZero 0 cSkip 0 cFit 0 cSpl 0 cClose 0 cWide 0 cOpt 0 sBefore 0 sAfter 0)
  (princ (strcat "\n현재 설정: 세그먼트 최적화 " (pj:opt-str *pj-opt-tol*)))
  (prompt "\n결합할 선·호·폴리선·스플라인을 고르세요 (잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget ":L" '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE,ELLIPSE")))))
    (princ "\n고른 객체가 없습니다.")
    (progn
      ;; 퍼지 거리 (O = 최적화 허용 오차 바꾸기)
      (while (progn
               (initget 4 "Optimize")
               (= "Optimize" (setq fz (getdist (strcat "\n퍼지 거리 입력 또는 [최적화(O)] <"
                                                       (rtos *PJ-FUZZ-DEFAULT* 2 4) ">: ")))))
        (initget 4)
        (if (setq x (getdist (strcat "\n세그먼트 최적화 허용 오차 (0 = 끔) <" (rtos *pj-opt-tol* 2 4) ">: ")))
          (setq *pj-opt-tol* x))
        (princ (strcat "\n현재 설정: 세그먼트 최적화 " (pj:opt-str *pj-opt-tol*))))
      (if (null fz) (setq fz *PJ-FUZZ-DEFAULT*))
      ;; 최적화를 하면 스플라인 분할은 허용 오차의 1/10 안으로 (합친 뒤 오차가 허용 오차를 크게 넘지 않게)
      (setq tol *pj-opt-tol*
            spl (if (> tol 0.0) (min *PJ-SPL-TOL* (* 0.1 tol)) *PJ-SPL-TOL*))

      (setq sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO" "PEDITACCEPT")))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)

      ;; 1) 정리
      (setq n0 (sslength ss) i 0)
      (repeat n0
        (setq e (ssname ss i) i (1+ i) d (entget e) typ (cdr (assoc 0 d)))
        (setq ne
          (cond
            ((= typ "LINE") (pj:fix-line e d))
            ((= typ "ARC")  (pj:fix-arc e d))
            ((member typ '("SPLINE" "ELLIPSE")) (pj:fix-curve e d spl))
            ((= typ "LWPOLYLINE")
             (pj:fix e d (pj:lw-verts d) (pj:g 70 d 0) (pj:g 38 d 0.0) nil))
            ((= typ "POLYLINE")
             (setq fl (pj:g 70 d 0))
             (if (/= 0 (logand fl 88))          ; 8 3D, 16 메쉬, 64 폴리면
               (progn (setq cSkip (1+ cSkip)) nil)
               (progn
                 (setq fit (/= 0 (logand fl 6))) ; 2 곡선맞춤, 4 스플라인
                 (if fit (setq cFit (1+ cFit)))
                 (pj:fix e d (pj:hv-verts e fit) fl
                         (caddr (cdr (assoc 10 d))) T))))))
        (if ne (setq lst (cons ne lst))))

      ;; 2) 결합
      (setq nss (ssadd))
      (foreach x lst (if (entget x) (ssadd x nss)))
      (setq e0 (entlast))
      (if (> (sslength nss) 1)
        (progn
          (setvar "PEDITACCEPT" 1)
          (command "_.PEDIT" "_M" nss "" "_J" "_J" "_B" fz "")
          (setq i 0)
          (while (and (> (getvar "CMDACTIVE") 0) (< (setq i (1+ i)) 5)) (command ""))))

      ;; 3) 결과 = 남은 폴리선 + 결합으로 새로 생긴 폴리선
      (setq res (ssadd))
      (foreach x lst (if (entget x) (ssadd x res)))
      (setq e (if e0 (entnext e0) (entnext)))
      (while e
        (if (= (cdr (assoc 0 (entget e))) "LWPOLYLINE") (ssadd e res))
        (setq e (entnext e)))

      ;; 4) 다시 닫기 · 세그먼트 최적화
      (setq n1 (sslength res) i 0)
      (repeat n1
        (setq e (ssname res i) i (1+ i))
        (if (pj:reclose e) (setq cClose (1+ cClose)))
        (if (> tol 0.0) (pj:optimize e tol)))

      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)

      (princ (strcat "\n[완료] 객체 " (itoa n0) "개를 폴리선 " (itoa n1) "개로 결합했습니다 (퍼지 거리 " (rtos fz 2 4) ")."))
      (if (> tol 0.0)
        (princ (strcat "\n       세그먼트 최적화 (" (pj:opt-str tol) "): " (itoa sBefore) "개 → " (itoa sAfter) "개"
                       (if (> cWide 0) (strcat " (폭 있는 폴리선 " (itoa cWide) "개는 그대로)") ""))))
      (if (setq x (pj:tally (list (cons "닫힘 해제" cOpen) (cons "다시 닫음" cClose) (cons "겹친 정점 제거" cDup)
                                  (cons "맞춤 해제" cFit) (cons "스플라인·타원 변환" cSpl) (cons "법선 보정" cFlip)
                                  (cons "고도 0 정리" cFlat) (cons "길이 0 삭제" cZero)
                                  (cons "제외(3D·기울어진 객체)" cSkip))))
        (princ (strcat "\n       " x)))
      (if (> n1 0) (sssetfirst nil res))))
  (princ))

(princ)
