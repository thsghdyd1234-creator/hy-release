;;; ============================================================
;;; PJ.lsp  -  선/호/폴리선 정리 후 일괄 결합
;;; 명령: PJ
;;;
;;; 처리 순서
;;;   1. 선(LINE)·호(ARC)는 LW폴리선으로 변환
;;;   2. 2D 헤비 폴리선은 LW폴리선으로 변환 (맞춤/스플라인은 해제)
;;;      스플라인(SPLINE)·타원(ELLIPSE)은 현 오차 기준으로 분할해 LW폴리선으로 변환
;;;   3. 닫힌 폴리선 열기
;;;   4. 법선이 뒤집힌(0,0,-1) 객체 보정
;;;   5. 고도/Z값 0으로 평탄화
;;;   6. 겹친(연속 중복) 정점 제거, 길이 0 객체 삭제
;;;   7. PEDIT 다중 결합 (결합 형식 = 둘 다, 퍼지 거리 적용)
;;;
;;; 제외: 3D 폴리선, 메쉬, 기울어진 평면의 객체 (건드리지 않음)
;;; 참고: 재생성된 객체는 XDATA·하이퍼링크가 유지되지 않음
;;; ============================================================

(vl-load-com)

(setq *PJ-FUZZ-DEFAULT* 1.0   ; 퍼지 거리 기본값
      *PJ-TOL*          1e-4  ; 겹친 정점 판정 허용오차
      *PJ-SPL-TOL*      0.01  ; 스플라인 변환 시 곡선과 폴리선 사이 최대 오차 (도면 단위)
      *PJ-SPL-INIT*     16)   ; 스플라인 초기 분할 수 (S자 굴곡 누락 방지)

;;; ---------- 유틸 ----------
(defun pj:g (k d df) (if (assoc k d) (cdr (assoc k d)) df))

(defun pj:flip-p (n)   ; 법선 (0,0,-1)
  (and (equal (car n) 0.0 1e-9) (equal (cadr n) 0.0 1e-9) (< (caddr n) 0.0)))

(defun pj:tilt-p (n)   ; Z축과 평행하지 않은 법선
  (not (and (equal (car n) 0.0 1e-9) (equal (cadr n) 0.0 1e-9))))

(defun pj:props (d)    ; 유지할 공통 속성
  (vl-remove-if-not
    '(lambda (x) (member (car x) '(8 6 62 370 48 420 430 440 39)))
    d))

;;; 정점 레코드: (점2D 시작폭 끝폭 볼록)
(defun pj:lw-verts (d / vs cur)
  (foreach x d
    (cond
      ((= (car x) 10)
       (if cur (setq vs (cons cur vs)))
       (setq cur (list (cdr x) 0.0 0.0 0.0)))
      ((and cur (= (car x) 40)) (setq cur (list (car cur) (cdr x) (caddr cur) (cadddr cur))))
      ((and cur (= (car x) 41)) (setq cur (list (car cur) (cadr cur) (cdr x) (cadddr cur))))
      ((and cur (= (car x) 42)) (setq cur (list (car cur) (cadr cur) (caddr cur) (cdr x))))))
  (if cur (setq vs (cons cur vs)))
  (reverse vs))

(defun pj:hv-verts (e fitted / v d all has16 fl p vs)
  (setq v (entnext e))
  (while (and v (= (cdr (assoc 0 (setq d (entget v)))) "VERTEX"))
    (setq all (cons d all) v (entnext v)))
  (setq all (reverse all))
  ;; 스플라인 맞춤이면 원래 조정점(16)만, 곡선 맞춤이면 생성 정점(1) 제외
  (setq has16 (vl-some '(lambda (x) (= 16 (logand 16 (pj:g 70 x 0)))) all))
  (foreach d all
    (setq fl (pj:g 70 d 0) p (cdr (assoc 10 d)))
    (if (if has16 (= 16 (logand 16 fl)) (zerop (logand 1 fl)))
      (setq vs (cons (list (list (car p) (cadr p))
                           (pj:g 40 d 0.0) (pj:g 41 d 0.0)
                           (if fitted 0.0 (pj:g 42 d 0.0)))
                     vs))))
  (reverse vs))

(defun pj:dedupe (vs / out)
  ;; 같은 자리 정점은 앞 정점 위치 + 뒤 정점의 세그먼트 속성으로 합침
  (foreach v vs
    (if (and out (< (distance (car v) (car (car out))) *PJ-TOL*))
      (setq out (cons (cons (car (car out)) (cdr v)) (cdr out)))
      (setq out (cons v out))))
  (reverse out))

(defun pj:make-lw (props fl elev vs)
  (entmake
    (append
      (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity"))
      props
      (list '(100 . "AcDbPolyline")
            (cons 90 (length vs)) (cons 70 fl) (cons 38 elev))
      (apply 'append
        (mapcar '(lambda (v)
                   (list (cons 10 (car v)) (cons 40 (cadr v))
                         (cons 41 (caddr v)) (cons 42 (cadddr v))))
                vs))
      (list '(210 0.0 0.0 1.0))))
  (entlast))

;;; ---------- 정리 (결과 ename 반환, 제외/삭제는 nil) ----------
(defun pj:fix (e d vs fl elev force / n nv changed)
  (setq n (pj:g 210 d '(0.0 0.0 1.0)) changed force)
  (if (pj:tilt-p n)
    (progn (setq cSkip (1+ cSkip)) nil)
    (progn
      (if (= 1 (logand fl 1))
        (setq fl (1- fl) cOpen (1+ cOpen) changed T))
      (if (pj:flip-p n)
        (setq vs (mapcar '(lambda (v)
                            (list (list (- (car (car v))) (cadr (car v)))
                                  (cadr v) (caddr v) (- (cadddr v))))
                         vs)
              elev (- elev) cFlip (1+ cFlip) changed T))
      (if (/= elev 0.0)
        (setq elev 0.0 cFlat (1+ cFlat) changed T))
      (setq nv (pj:dedupe vs))
      (if (< (length nv) (length vs))
        (setq cDup (+ cDup (- (length vs) (length nv))) changed T))
      (cond
        ((< (length nv) 2) (entdel e) (setq cZero (1+ cZero)) nil)
        (changed
         (setq n (pj:make-lw (pj:props d) (logand fl 128) elev nv))
         (entdel e)
         n)
        (T e)))))

(defun pj:fix-line (e d / p q)
  (setq p (cdr (assoc 10 d)) q (cdr (assoc 11 d)))
  (if (or (/= 0.0 (caddr p)) (/= 0.0 (caddr q))) (setq cFlat (1+ cFlat)))
  ;; 선 끝점은 WCS 기준이므로 법선(210)은 무시
  (pj:fix e (vl-remove (assoc 210 d) d)
          (list (list (list (car p) (cadr p)) 0.0 0.0 0.0)
                (list (list (car q) (cadr q)) 0.0 0.0 0.0))
          0 0.0 T))

(defun pj:fix-arc (e d / c c2 r s en da bul)
  (setq c  (cdr (assoc 10 d))
        c2 (list (car c) (cadr c))
        r  (cdr (assoc 40 d))
        s  (cdr (assoc 50 d))
        en (cdr (assoc 51 d))
        da (- en s))
  (if (<= da 0.0) (setq da (+ da (* 2 pi))))
  (setq bul (/ (sin (/ da 4.0)) (cos (/ da 4.0))))
  (pj:fix e d
          (list (list (polar c2 s r) 0.0 0.0 bul)
                (list (polar c2 en r) 0.0 0.0 0.0))
          0 (caddr c) T))

;;; ---------- 스플라인/타원 → 폴리선 ----------
(defun pj:dseg (p a b / dx dy l2 u)   ; 점 p와 선분 ab 사이 거리 (2D)
  (setq dx (- (car b) (car a)) dy (- (cadr b) (cadr a)) l2 (+ (* dx dx) (* dy dy)))
  (if (< l2 1e-20)
    (distance p a)
    (progn
      (setq u (/ (+ (* (- (car p) (car a)) dx) (* (- (cadr p) (cadr a)) dy)) l2))
      (setq u (max 0.0 (min 1.0 u)))
      (distance p (list (+ (car a) (* u dx)) (+ (cadr a) (* u dy)))))))

(defun pj:p2 (p) (list (car p) (cadr p)))

(defun pj:sub (e a b pa pb dep / m pm)   ; 오차가 기준 이하가 될 때까지 이분할
  (setq m (/ (+ a b) 2.0) pm (pj:p2 (vlax-curve-getPointAtParam e m)))
  (if (and (< dep 12) (> (pj:dseg pm pa pb) *PJ-SPL-TOL*))
    (append (pj:sub e a m pa pm (1+ dep)) (pj:sub e m b pm pb (1+ dep)))
    (list pb)))

(defun pj:fix-curve (e d / t0 t1 k a b pa pb pts)
  (setq t0 (vlax-curve-getStartParam e) t1 (vlax-curve-getEndParam e)
        pa (pj:p2 (vlax-curve-getPointAtParam e t0)) pts (list pa) k 0)
  (repeat *PJ-SPL-INIT*
    (setq a  (+ t0 (* (- t1 t0) (/ k (float *PJ-SPL-INIT*))))
          k  (1+ k)
          b  (+ t0 (* (- t1 t0) (/ k (float *PJ-SPL-INIT*))))
          pb (pj:p2 (vlax-curve-getPointAtParam e b))
          pts (append pts (pj:sub e a b pa pb 0))
          pa pb))
  (setq cSpl (1+ cSpl))
  ;; 점은 WCS 기준이므로 법선(210) 무시, Z는 버림
  (pj:fix e (vl-remove (assoc 210 d) d)
          (mapcar '(lambda (p) (list p 0.0 0.0 0.0)) pts)
          0 0.0 T))

;;; ---------- 메인 ----------
(defun c:PJ (/ *error* doc oldEcho oldAcc ss fz i e d typ fl fit ne lst nss res
               n0 n1 cOpen cDup cFlip cFlat cZero cSkip cFit cSpl)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (defun *error* (msg)
    (if oldAcc  (setvar "PEDITACCEPT" oldAcc))
    (if oldEcho (setvar "CMDECHO" oldEcho))
    (vla-EndUndoMark doc)
    (if (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*BREAK*"))
      (princ (strcat "\n[PJ] 오류: " msg)))
    (princ))

  (setq cOpen 0 cDup 0 cFlip 0 cFlat 0 cZero 0 cSkip 0 cFit 0 cSpl 0)
  (prompt "\n결합할 선/호/폴리선/스플라인 선택: ")
  (if (setq ss (ssget ":L" '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE,ELLIPSE"))))
    (progn
      (initget 4)
      (setq fz (getdist (strcat "\n퍼지 거리 <" (rtos *PJ-FUZZ-DEFAULT* 2 4) ">: ")))
      (if (null fz) (setq fz *PJ-FUZZ-DEFAULT*))

      (vla-StartUndoMark doc)
      (setq oldEcho (getvar "CMDECHO") oldAcc (getvar "PEDITACCEPT"))
      (setvar "CMDECHO" 0)

      ;; 1) 정리
      (setq n0 (sslength ss) i 0)
      (repeat n0
        (setq e (ssname ss i) i (1+ i) d (entget e) typ (cdr (assoc 0 d)))
        (setq ne
          (cond
            ((= typ "LINE") (pj:fix-line e d))
            ((= typ "ARC")  (pj:fix-arc e d))
            ((member typ '("SPLINE" "ELLIPSE")) (pj:fix-curve e d))
            ((= typ "LWPOLYLINE")
             (pj:fix e d (pj:lw-verts d) (pj:g 70 d 0) (pj:g 38 d 0.0) nil))
            ((= typ "POLYLINE")
             (setq fl (pj:g 70 d 0))
             (if (/= 0 (logand fl 88))          ; 8 3D, 16 메쉬, 64 폴리면
               (progn (setq cSkip (1+ cSkip)) nil)
               (progn
                 (setq fit (/= 0 (logand fl 6))) ; 2 곡선맞춤, 4 스플라인
                 (if fit (setq cFit (1+ cFit)))
                 (pj:fix e d (pj:hv-verts e fit) fl
                         (caddr (cdr (assoc 10 d))) T))))))
        (if ne (setq lst (cons ne lst))))

      ;; 2) 결합
      (setq nss (ssadd))
      (foreach x lst (if (entget x) (ssadd x nss)))
      (if (> (sslength nss) 1)
        (progn
          (setvar "PEDITACCEPT" 1)
          (command "_.PEDIT" "_M" nss "" "_J" "_J" "_B" fz "")))

      ;; 3) 결과
      (setq res (ssadd))
      (foreach x lst (if (entget x) (ssadd x res)))
      (setq n1 (sslength res))

      (setvar "PEDITACCEPT" oldAcc)
      (setvar "CMDECHO" oldEcho)
      (vla-EndUndoMark doc)

      (princ (strcat "\n[PJ] " (itoa n0) "개 → " (itoa n1) "개 (퍼지 " (rtos fz 2 4) ")"))
      (princ (strcat "\n     닫힘 해제 " (itoa cOpen)
                     " / 겹친 정점 제거 " (itoa cDup)
                     " / 맞춤 해제 " (itoa cFit)
                     " / 스플라인·타원 변환 " (itoa cSpl)
                     " / 법선 보정 " (itoa cFlip)
                     " / 고도 0 정리 " (itoa cFlat)))
      (princ (strcat "\n     길이 0 삭제 " (itoa cZero)
                     " / 제외(3D·기울어진 객체) " (itoa cSkip)))
      (if (> n1 0) (sssetfirst nil res))))
  (princ))

(princ)
