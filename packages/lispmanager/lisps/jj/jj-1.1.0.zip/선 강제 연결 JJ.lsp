;;; ==============================================================================
;;;  JJ — 같은 직선 위의 선을 하나로 (간격 상관없이)
;;;
;;;  선을 고르면 같은 직선 위에 있는 선끼리(사선 포함) 가장 바깥 두 끝까지 늘린 선 하나로 합친다.
;;;   · 간격은 보지 않는다 — 문·창 개구부 건너편 선까지 이어지므로 합칠 선만 고를 것.
;;;   · 같은 레이어 · 같은 높이(Z)의 선끼리만 (창틀·문틀 선이 벽선에 흡수되지 않게, 3D 선이 섞이지 않게).
;;;   · 가장 긴 선을 늘리고(핸들·속성 유지) 나머지를 지운다. 잠긴 레이어는 빠진다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 선 → (ename 시작점 끝점 방향각[0,π) 레이어 Z) / 길이 0·기운(Z 가 다른) 선은 nil
(defun jj:rec (e / ed p q a)
  (setq ed (entget e) p (cdr (assoc 10 ed)) q (cdr (assoc 11 ed)))
  (if (and (equal (caddr p) (caddr q) 1e-6) (> (distance (list (car p) (cadr p)) (list (car q) (cadr q))) 1e-6))
    (progn
      (setq a (angle p q))
      (if (>= a pi) (setq a (- a pi)))
      (if (> a (- pi 1e-9)) (setq a 0.0))
      (list e p q a (strcase (cdr (assoc 8 ed))) (caddr p)))))

;; 점 p 에서 선(시작 b · 방향 u)까지 거리
(defun jj:dist (p b u)
  (abs (- (* (car u) (- (cadr p) (cadr b))) (* (cadr u) (- (car p) (car b))))))

;; 같은 직선 후보 묶음 하나를 합침 → 지운 선 수
(defun jj:merge (grp / b u ok ts t0 t1 ed z n)
  (setq b (car (vl-sort grp '(lambda (x y) (> (distance (cadr x) (caddr x)) (distance (cadr y) (caddr y)))))))
  (setq u (list (cos (nth 3 b)) (sin (nth 3 b))))
  (foreach r grp
    (if (and (< (jj:dist (cadr r) (cadr b) u) 1e-4) (< (jj:dist (caddr r) (cadr b) u) 1e-4)) (setq ok (cons r ok))))
  (setq n 0)
  (if (cdr ok)
    (progn
      (foreach r ok
        (foreach p (list (cadr r) (caddr r))
          (setq ts (cons (+ (* (car u) (- (car p) (car (cadr b)))) (* (cadr u) (- (cadr p) (cadr (cadr b))))) ts))))
      (setq t0 (apply 'min ts) t1 (apply 'max ts) z (nth 5 b) ed (entget (car b)))
      (setq ed (subst (list 10 (+ (car (cadr b)) (* t0 (car u))) (+ (cadr (cadr b)) (* t0 (cadr u))) z) (assoc 10 ed) ed)
            ed (subst (list 11 (+ (car (cadr b)) (* t1 (car u))) (+ (cadr (cadr b)) (* t1 (cadr u))) z) (assoc 11 ed) ed))
      (if (entmod ed)
        (foreach r ok
          (if (not (eq (car r) (car b))) (progn (entdel (car r)) (setq n (1+ n))))))))
  n)

(defun c:JJ ( / *error* doc undo_open ss i r recs ref runs run cur grp key parts n)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n합칠 선을 고르세요 (같은 직선 위면 간격 상관없이 이어짐, 잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L" '((0 . "LINE")))))
    (princ "\n고른 선이 없습니다.")
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (if (setq r (jj:rec (ssname ss i))) (setq recs (cons r recs)))
        (setq i (1+ i)))
      (setq ref (if recs (cadr (car recs))) n 0)
      ;; 방향각으로 줄 세우고, 거의 같은 방향끼리 → 원점(ref)에서 직선까지 거리로 → 레이어·Z 로 나눈다
      (setq recs (vl-sort recs '(lambda (x y) (< (nth 3 x) (nth 3 y)))))
      (while recs
        (setq run (list (car recs)) recs (cdr recs))
        (while (and recs (< (- (nth 3 (car recs)) (nth 3 (car run))) 1e-6))
          (setq run (cons (car recs) run) recs (cdr recs)))
        (setq run (mapcar '(lambda (x) (append x (list (jj:dist (cadr x) ref (list (cos (nth 3 x)) (sin (nth 3 x))))))) run)
              run (vl-sort run '(lambda (x y) (< (nth 6 x) (nth 6 y)))))
        (while run
          (setq grp (list (car run)) run (cdr run))
          (while (and run (< (- (nth 6 (car run)) (nth 6 (car grp))) 1e-3))
            (setq grp (cons (car run) grp) run (cdr run)))
          (if (cdr grp)
            (progn
              (setq parts nil)
              (foreach x grp
                (setq key (list (nth 4 x) (/ (fix (* (nth 5 x) 1e4)) 1e4)))
                (if (setq cur (assoc key parts))
                  (setq parts (subst (cons key (cons x (cdr cur))) cur parts))
                  (setq parts (cons (list key x) parts))))
              (foreach pt parts
                (if (> (length (cdr pt)) 1)
                  (progn
                    (if (not undo_open) (progn (vla-StartUndoMark doc) (setq undo_open T)))
                    (setq n (+ n (jj:merge (cdr pt)))))))))))
      (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
      (princ (if (> n 0) (strcat "\n[완료] 선 " (itoa n) "개를 같은 직선 위의 선에 합쳤습니다.")
                 "\n[알림] 같은 직선 위에 있는 선(같은 레이어·높이)이 없습니다."))))
  (princ))

(princ)
