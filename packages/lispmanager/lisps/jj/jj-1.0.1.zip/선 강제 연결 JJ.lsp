(defun c:JJ ( / ss i j ent1 ent2 data1 data2 p1 p2 p3 p4 z fuzz merged
                dist12 cp1 cp2 d3 d4 pts maxDist pA pB tmpDist n m)
  
  ;; 오차 허용치 (미세하게 틀어진 선을 같은 선상으로 인식하기 위함)
  (setq fuzz 1e-4) 
  
  (prompt "\n정리할 선들을 드래그하여 선택하세요 (사선 포함, 간격 무시 연결): ")
  (if (and (setq ss (ssget '((0 . "LINE")))) (> (sslength ss) 1))
    (progn
      (setq i 0)
      (while (< i (1- (sslength ss)))
        (setq ent1 (ssname ss i))
        (if (entget ent1) ; 선이 아직 있는지 확인
          (progn
            (setq data1 (entget ent1)
                  p1 (cdr (assoc 10 data1))
                  p2 (cdr (assoc 11 data1))
                  z (caddr p1) ; Z좌표 기준 유지
            )
            (setq j (1+ i) merged nil)
            (while (and (< j (sslength ss)) (not merged))
              (setq ent2 (ssname ss j))
              (if (entget ent2)
                (progn
                  (setq data2 (entget ent2)
                        p3 (cdr (assoc 10 data2))
                        p4 (cdr (assoc 11 data2))
                  )
                  
                  ;; 1. 두 선이 동일 선상(Collinear)인지 판별
                  ;; 기준선 P1-P2의 2D 길이 계산
                  (setq dist12 (distance (list (car p1) (cadr p1)) (list (car p2) (cadr p2))))
                  
                  (if (> dist12 1e-6) ; 길이가 0인 점 오류 선 방지
                    (progn
                      ;; P3, P4에서 P1-P2 연장선까지의 수직거리 계산 (외적 활용)
                      (setq cp1 (abs (- (* (- (car p2) (car p1)) (- (cadr p3) (cadr p1)))
                                        (* (- (cadr p2) (cadr p1)) (- (car p3) (car p1))))))
                      (setq cp2 (abs (- (* (- (car p2) (car p1)) (- (cadr p4) (cadr p1)))
                                        (* (- (cadr p2) (cadr p1)) (- (car p4) (car p1))))))
                      
                      (setq d3 (/ cp1 dist12)
                            d4 (/ cp2 dist12))
                      
                      ;; 두 점 모두 연장선으로부터의 수직거리가 오차범위(fuzz) 이내면 같은 사선으로 봄
                      (if (and (< d3 fuzz) (< d4 fuzz))
                        (progn
                          ;; 2. 동일 선상임이 확인되면, 4개의 점 중 가장 멀리 떨어진 두 점(양 끝점)을 찾음
                          (setq pts (list p1 p2 p3 p4)
                                maxDist 0.0)
                          (setq n 0)
                          (while (< n 3)
                            (setq m (1+ n))
                            (while (< m 4)
                              (setq tmpDist (distance (nth n pts) (nth m pts)))
                              (if (> tmpDist maxDist)
                                (setq maxDist tmpDist
                                      pA (nth n pts)
                                      pB (nth m pts)))
                              (setq m (1+ m))
                            )
                            (setq n (1+ n))
                          )
                          
                          ;; 3. 찾은 가장 외곽의 두 점(pA, pB)으로 첫 번째 선(ent1)을 늘림
                          (setq data1 (subst (cons 10 (list (car pA) (cadr pA) z)) (assoc 10 data1) data1))
                          (setq data1 (subst (cons 11 (list (car pB) (cadr pB) z)) (assoc 11 data1) data1))
                          (entmod data1)
                          
                          ;; 합쳐진 두 번째 선(ent2)은 삭제
                          (entdel ent2)
                          (setq merged T)
                        )
                      )
                    )
                  )
                )
              )
              (setq j (1+ j))
            )
            ;; 병합이 발생했다면, 길어진 새 선을 기준으로 주변 선들을 다시 검사하기 위해 인덱스 유지
            (if merged (setq i (1- i)))
          )
        )
        (setq i (1+ i))
      )
      (princ "\n[완료] 선을 연결했습니다. (사선 포함)")
    )
    (princ "\n충분한 선이 선택되지 않았습니다.")
  )
  (princ)
)