;;; ==============================================================================
;;;  XX — 닫힌 공간에 X자 보이드 표시
;;;  YGN CAD 가 켜진 캐드에서는 XX 가 YGN CAD 보이드(X + 보이드 글자 — 면적 계산 · 스케치업이 앎)로 돌고, 이 리습은 YGN CAD 없는 캐드용.
;;;
;;;  공간 안을 클릭할 때마다 그 공간의 경계를 찾아, 가운데에서 네 귀퉁이 쪽으로 처음 닿는 벽까지 X 를 VOID 레이어에 그린다.
;;;  여러 공간을 이어서 클릭하고 Enter 로 끝낸다. 오목한(ㄱ·ㄷ자) 공간은 클릭한 곳을 가운데로 쓴다.
;;;   · VOID 레이어(색 8 · HIDDEN)가 없을 때만 만들고, 지금 레이어는 바꾸지 않는다 (예전: 첫 실행 뒤 지금 레이어가 VOID 로 남음).
;;;   · 경계는 bpoly 로 임시로 만들었다 지운다 (명령 없이). 클릭 하나 = 실행 취소 한 번(U). UCS 를 돌려 둔 화면에서도 맞는 자리에 그린다.
;;; ==============================================================================

(defun xx:space ( / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc)))

;; VOID 레이어 준비 (없을 때만 — 색 8, HIDDEN 선 종류가 있으면 HIDDEN)
(defun xx:layer ( / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (not (tblsearch "LTYPE" "HIDDEN"))
    (vl-catch-all-apply 'vla-Load (list (vla-get-Linetypes doc) "HIDDEN" (if (= (getvar "MEASUREMENT") 1) "acadiso.lin" "acad.lin"))))
  (if (not (tblsearch "LAYER" "VOID"))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   '(2 . "VOID") '(70 . 0) '(62 . 8) (cons 6 (if (tblsearch "LTYPE" "HIDDEN") "HIDDEN" "Continuous"))))))

;; 경계 폴리선의 꼭짓점 (월드 2D)
(defun xx:verts (e / out)
  (foreach g (entget e) (if (= (car g) 10) (setq out (cons (list (cadr g) (caddr g)) out))))
  (reverse out))

(defun xx:inside (p poly / n i j a b in)
  (setq n (length poly) j (1- n) i 0)
  (while (< i n)
    (setq a (nth i poly) b (nth j poly))
    (if (and (not (eq (> (cadr a) (cadr p)) (> (cadr b) (cadr p))))
             (< (car p) (+ (car a) (/ (* (- (car b) (car a)) (- (cadr p) (cadr a))) (- (cadr b) (cadr a))))))
      (setq in (not in)))
    (setq j i i (1+ i)))
  in)

;; c 에서 q 쪽으로 쏜 선이 경계에 처음 닿는 점 / 없으면 nil
(defun xx:hit (c q len bnd / ray r pts)
  (if (> (distance c q) 1e-6)
    (progn
      (setq ray (vla-AddLine (xx:space) (vlax-3d-point c) (vlax-3d-point (polar c (angle c q) len)))
            r (vlax-invoke ray 'IntersectWith bnd acExtendNone))
      (vla-Delete ray)
      (while r (setq pts (cons (list (car r) (cadr r) (caddr r)) pts) r (cdddr r)))
      (car (vl-sort pts '(lambda (a b) (< (distance c a) (distance c b))))))))

(defun c:XX ( / *error* doc undo_open sv p w e0 e new bnd o a b c len tr tl bl br n)
  (defun *error* (msg)
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)) n 0
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO")))
  (setvar "CMDECHO" 0)
  (while (setq p (getpoint "\n보이드(X)를 넣을 닫힌 공간 안을 클릭하세요 <Enter = 끝>: "))
    (setq w (trans p 1 0) e0 (entlast) new nil)
    (vla-StartUndoMark doc)
    (setq undo_open T)
    (xx:layer)
    ;; 경계 — 명령(-BOUNDARY) 없이 bpoly (1.2.0: 캐드 판에 따라 -BOUNDARY 옵션 키워드가 거절되어 '옵션 키워드가 유효하지 않음' 뒤 멈췄음)
    (vl-catch-all-apply 'bpoly (list p))
    (setq e (if e0 (entnext e0) (entnext)))
    (while e (if (= (cdr (assoc 0 (entget e))) "LWPOLYLINE") (setq new (cons e new))) (setq e (entnext e)))
    ;; 섬 둘레까지 생겼으면 가장 넓은 것(바깥 둘레)을 맨 앞으로
    (setq new (vl-sort new '(lambda (x y) (> (vla-get-Area (vlax-ename->vla-object x)) (vla-get-Area (vlax-ename->vla-object y))))))
    (if (null new)
      (princ "\n[주의] 닫힌 공간을 찾지 못했습니다. 선이 끊겨 있는지 보세요.")
      (progn
        (setq bnd (vlax-ename->vla-object (car new)))
        (vla-GetBoundingBox bnd 'a 'b)
        (setq a (vlax-safearray->list a) b (vlax-safearray->list b)
              c (list (/ (+ (car a) (car b)) 2.0) (/ (+ (cadr a) (cadr b)) 2.0) (caddr w))
              len (* 2.0 (distance a b)))
        (if (not (xx:inside c (xx:verts (car new)))) (setq c w))        ; 오목한 공간: 가운데가 밖이면 클릭한 곳
        (setq tr (xx:hit c (list (car b) (cadr b) (caddr c)) len bnd)
              tl (xx:hit c (list (car a) (cadr b) (caddr c)) len bnd)
              bl (xx:hit c (list (car a) (cadr a) (caddr c)) len bnd)
              br (xx:hit c (list (car b) (cadr a) (caddr c)) len bnd))
        (foreach pr (list (list tr bl) (list tl br))
          (if (and (car pr) (cadr pr))
            (entmake (list '(0 . "LINE") '(8 . "VOID") (cons 10 (car pr)) (cons 11 (cadr pr))))))
        (foreach x new (entdel x))
        (setq n (1+ n))))
    (vla-EndUndoMark doc)
    (setq undo_open nil))
  (foreach v sv (setvar (car v) (cdr v)))
  (if (> n 0) (princ (strcat "\n[완료] 보이드 표시 " (itoa n) "개를 VOID 레이어에 그렸습니다.")))
  (princ))

(princ)
