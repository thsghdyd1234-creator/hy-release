(defun c:XX ( / pt old_osnap old_layer ent vla_ent minpt maxpt p1 p2 p3 p4 midpt diag_len get-closest-int final_TR final_TL final_BL final_BR )
  (vl-load-com)
  
  ;; 1. 선종류 및 레이어 자동 설정
  (if (not (tblsearch "LTYPE" "HIDDEN"))
    (vl-catch-all-apply 'vl-cmdf (list "-linetype" "load" "HIDDEN" "acadiso.lin" ""))
  )
  (if (not (tblsearch "LTYPE" "HIDDEN"))
    (vl-catch-all-apply 'vl-cmdf (list "-linetype" "load" "HIDDEN" "acad.lin" ""))
  )
  (if (not (tblsearch "LAYER" "VOID"))
    (vl-cmdf "-layer" "m" "VOID" "c" "8" "" "L" "HIDDEN" "" "")
    (vl-cmdf "-layer" "L" "HIDDEN" "VOID" "")
  )

  ;; 2. 메인 실행부
  (setq pt (getpoint "\n보이드(X)를 생성할 닫힌 내부 공간을 클릭하세요: "))
  (if pt
    (progn
      (setq old_osnap (getvar "OSMODE"))
      (setq old_layer (getvar "CLAYER")) ; 기존에 사용 중이던 레이어 저장
      (setvar "OSMODE" 0)

      ;; 경계선 생성
      (setq ent (bpoly pt))

      (if ent
        (progn
          (setq vla_ent (vlax-ename->vla-object ent))
          
          ;; 바운딩 박스(가상의 외곽 사각형) 좌표 추출
          (vla-getboundingbox vla_ent 'minpt 'maxpt)
          (setq p1 (vlax-safearray->list minpt)) ; 좌측 하단 (BL)
          (setq p2 (vlax-safearray->list maxpt)) ; 우측 상단 (TR)
          (setq p1 (list (car p1) (cadr p1) 0.0))
          (setq p2 (list (car p2) (cadr p2) 0.0))
          (setq p3 (list (car p1) (cadr p2) 0.0)) ; 좌측 상단 (TL)
          (setq p4 (list (car p2) (cadr p1) 0.0)) ; 우측 하단 (BR)

          ;; 중심점(Center) 계산
          (setq midpt (list (/ (+ (car p1) (car p2)) 2.0) (/ (+ (cadr p1) (cadr p2)) 2.0) 0.0))
          
          ;; 도면 크기에 비례하여 충분히 긴 선을 긋기 위한 거리 설정
          (setq diag_len (* 2.0 (distance p1 p2)))

          ;; 중심에서 모서리 방향으로 선을 그어 처음 닿는 벽(교차점)을 찾는 함수
          (defun get-closest-int (p_start p_target / ang p_end temp_line intPtsVar pts allPts)
            (if (> (distance p_start p_target) 0.001)
              (progn
                (setq ang (angle p_start p_target))
                (setq p_end (polar p_start ang diag_len))
                
                ;; 가상의 조사선(Ray) 생성
                (setq temp_line (vla-AddLine
                                  (vla-get-ModelSpace (vla-get-ActiveDocument (vlax-get-acad-object)))
                                  (vlax-3d-point p_start)
                                  (vlax-3d-point p_end)
                                )
                )
                
                ;; 경계선과 조사선이 만나는 모든 교차점 추출
                (setq intPtsVar (vla-IntersectWith temp_line vla_ent acExtendNone))
                (setq pts nil)
                (if (> (vlax-variant-type intPtsVar) 8192)
                  (setq pts (vlax-safearray->list (vlax-variant-value intPtsVar)))
                )
                (vla-delete temp_line) ; 계산 끝난 가상선 삭제
                
                ;; 좌표 리스트 정리
                (setq allPts nil)
                (while pts
                  (setq allPts (cons (list (car pts) (cadr pts) (caddr pts)) allPts))
                  (setq pts (cdddr pts))
                )
                
                ;; 교차점 중 중심(p_start)에서 가장 '가까운' 점 하나만 추출
                (if allPts
                  (car (vl-sort allPts (function (lambda (a b) (< (distance p_start a) (distance p_start b))))))
                  nil
                )
              )
              nil
            )
          )

          ;; 4개 방향(우상, 좌상, 좌하, 우하)으로 교차점 찾기
          (setq final_TR (get-closest-int midpt p2))
          (setq final_TL (get-closest-int midpt p3))
          (setq final_BL (get-closest-int midpt p1))
          (setq final_BR (get-closest-int midpt p4))

          ;; 선 그리기
          (setvar "CLAYER" "VOID")
          
          (if (and final_TR final_BL)
            (vl-cmdf "line" "_non" final_TR "_non" final_BL "")
          )
          (if (and final_TL final_BR)
            (vl-cmdf "line" "_non" final_TL "_non" final_BR "")
          )

          ;; 임시 경계선 삭제
          (entdel ent)
          (princ "\n[완료] 보이드(X) 표시를 만들었습니다.")
        )
        (princ "\n닫힌 공간을 찾을 수 없습니다. 선이 끊겨있는지 확인해 주세요.")
      )
      
      (setvar "OSMODE" old_osnap)
      (setvar "CLAYER" old_layer) ; 작업 완료 후 원래 레이어로 복귀
    )
  )
  (princ)
)