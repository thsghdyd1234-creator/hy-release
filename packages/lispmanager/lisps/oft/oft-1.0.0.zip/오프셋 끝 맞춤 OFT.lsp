;;; ============================================================
;;; OFT.lsp  -  오프셋 끝 맞춤 (오프셋한 선의 끝을 원래 선이 닿아 있던 선까지 늘이거나 자름)
;;; 명령: OFT
;;;
;;; 1. 오프셋 거리를 정한다 (기억 — 환경 변수 HyOftDist).
;;; 2. 오프셋할 선을 누른다 — 선 · 호 · 열린 폴리선.
;;;    원래 선의 두 끝에 닿아 있는 선(벽선 · 경계선 · 축선 …)을 찾아 둔다.
;;; 3. 오프셋할 쪽을 찍는다 → 만든 선의 끝을 그 선까지 늘이거나 자른다 (모자라면 늘이고, 넘치면 자름).
;;;    다시 찍으면 방금 만든 선에서 한 번 더 (같은 간격으로 여러 줄).
;;;      N  개수 — 찍은 쪽으로 n 줄을 한 번에
;;;      D  거리 바꾸기
;;;      S  원래 선에서 다시 (방금 만든 선이 아니라) — 원래 선의 반대쪽을 찍으면 저절로 원래 선에서
;;;      U  되돌리기 — 방금 만든 것을 지움
;;;    Enter · Space · 오른쪽 클릭 = 이 선은 끝 → 다른 선을 누르거나 Enter 로 끝.
;;; 끝이 닿은 선이 여럿이면(모서리) 가장 가까운 것까지. 닿은 선 너머로는 그 선을 늘인 줄까지 맞춘다
;;; (닿은 선이 짧아 만나지 않을 때). 끝에 닿은 선이 없으면 그 끝은 그대로 둔다.
;;; 원래 선 · 닿아 있던 선은 건드리지 않는다. 한 번 실행 = 실행 취소 한 번(U).
;;; 평면(XY)에서 잰다 — 법선이 위(+Z)가 아닌 호 · 폴리선은 오프셋만 하고 끝은 그대로.
;;; ============================================================

(vl-load-com)
(setq *oft-version* "1.0.0")

;;; ---------- 2D 벡터 (월드 XY) ----------
(defun OFT:2d (p) (list (car p) (cadr p)))
(defun OFT:v- (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun OFT:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun OFT:crs (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
(defun OFT:len (a) (sqrt (OFT:dot a a)))
(defun OFT:unit (a / l) (setq l (OFT:len a)) (if (> l 1e-12) (list (/ (car a) l) (/ (cadr a) l))))
;; 각도를 (-π, π] 로
(defun OFT:wrap (a)
  (while (> a pi) (setq a (- a (* 2 pi))))
  (while (<= a (- pi)) (setq a (+ a (* 2 pi))))
  a)
;; 각도를 [0, 2π) 로
(defun OFT:wrap2 (a)
  (while (< a 0.0) (setq a (+ a (* 2 pi))))
  (while (>= a (* 2 pi)) (setq a (- a (* 2 pi))))
  a)

(defun OFT:flat-p (d / n) (setq n (cdr (assoc 210 d))) (or (null n) (equal n '(0.0 0.0 1.0) 1e-9)))

;; 오프셋할 수 있는 선인가 → nil 이면 까닭 글
(defun OFT:why-not (e / d tp)
  (setq d (entget e) tp (cdr (assoc 0 d)))
  (cond ((not (member tp '("LINE" "ARC" "LWPOLYLINE"))) "선 · 호 · 열린 폴리선만 됩니다 (닫힌 선 · 원은 OFFSET 으로).")
        ((and (= tp "LWPOLYLINE") (= 1 (logand 1 (cdr (assoc 70 d))))) "닫힌 폴리선은 끝이 없습니다 (OFFSET 으로).")
        ((OFT:locked-p e) "잠긴 레이어의 선입니다.")))

(defun OFT:locked-p (e / l)
  (and (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e))))) (= 4 (logand 4 (cdr (assoc 70 l))))))

;; 선 길이
(defun OFT:length (e) (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)))

;; 끝 하나 = (자리 바깥쪽 방향) — i 0 = 시작, 1 = 끝
(defun OFT:end (e i / p d)
  (if (= i 0)
    (setq p (vlax-curve-getStartPoint e) d (mapcar '- (vlax-curve-getFirstDeriv e (vlax-curve-getStartParam e))))
    (setq p (vlax-curve-getEndPoint e) d (vlax-curve-getFirstDeriv e (vlax-curve-getEndParam e))))
  (list (OFT:2d p) (OFT:unit (OFT:2d d))))

;; 점 p 에 닿은 선들 (excl 빼고) — 화면 걸침 고르기 먼저, 없으면 지금 공간 전체에서 (화면 밖 끝)
(defun OFT:touching (p excl tol / flt out)
  (setq flt '((0 . "LINE,ARC,CIRCLE,LWPOLYLINE,POLYLINE,SPLINE,ELLIPSE,XLINE,RAY")))
  (setq out (OFT:near (ssget "_C" (trans (list (- (car p) tol) (- (cadr p) tol) 0.0) 0 1)
                               (trans (list (+ (car p) tol) (+ (cadr p) tol) 0.0) 0 1) flt)
                      p excl tol))
  (if (null out)
    (setq out (OFT:near (ssget "_X" (append flt (list (cons 410 (getvar "CTAB"))))) p excl tol)))
  out)

;; 고른 것 중 점 p 에서 tol 안에 닿은 것
(defun OFT:near (ss p excl tol / i e q out)
  (if ss
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) i (1+ i))
        (if (not (member e excl))
          (progn
            (setq q (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list e (list (car p) (cadr p) 0.0))))
            (if (and q (not (vl-catch-all-error-p q)) (< (distance (OFT:2d q) p) tol))
              (setq out (cons e out))))))))
  (reverse out))

;; 호(볼록 b) 중심 · 반지름 — p0 → p1
(defun OFT:bulge-arc (p0 p1 b / r)
  (setq r (/ (* (distance p0 p1) (1+ (* b b))) 4.0 b))
  (list (polar p0 (+ (angle p0 p1) (- (/ pi 2.0) (* 2.0 (atan b)))) r) (abs r)))

;; 끝 구간 → (kind 끝점 다른점 [중심 반지름 방향]) — kind "L" | "A", 방향 = 바깥으로 갈 때 반시계 +1 / 시계 -1
(defun OFT:seg (e i / d tp vs n p0 p1 b ca c r)
  (setq d (entget e) tp (cdr (assoc 0 d)))
  (cond
    ((= tp "LINE")
     (setq p0 (OFT:2d (cdr (assoc 10 d))) p1 (OFT:2d (cdr (assoc 11 d))))
     (if (= i 0) (list "L" p0 p1) (list "L" p1 p0)))
    ((= tp "ARC")
     (setq c (OFT:2d (cdr (assoc 10 d))) r (cdr (assoc 40 d))
           p0 (polar c (cdr (assoc 50 d)) r) p1 (polar c (cdr (assoc 51 d)) r))
     ;; 호는 늘 반시계 — 시작 끝에서 바깥 = 시계, 끝 끝에서 바깥 = 반시계
     (if (= i 0) (list "A" p0 p1 c r -1) (list "A" p1 p0 c r 1)))
    ((= tp "LWPOLYLINE")
     (setq vs (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) d))
           n (length vs))
     (setq b (OFT:bulges d))
     (if (= i 0)
       (setq p0 (nth 0 vs) p1 (nth 1 vs) b (nth 0 b))
       (setq p0 (nth (1- n) vs) p1 (nth (- n 2) vs) b (- (nth (- n 2) b))))
     ;; b 는 끝점 → 다른점 쪽으로 잰 볼록 (끝 쪽 구간을 거꾸로 따라감)
     (if (equal b 0.0 1e-12)
       (list "L" p0 p1)
       (progn
         (setq ca (OFT:bulge-arc p1 p0 (- b)))
         ;; 다른점 → 끝점이 반시계(-b > 0)면 끝점에서 바깥도 반시계
         (list "A" p0 p1 (car ca) (cadr ca) (if (> (- b) 0) 1 -1)))))))

;; 폴리선 꼭짓점마다 볼록 (꼭짓점 수만큼)
(defun OFT:bulges (d / out seen x)
  (foreach x d
    (cond ((= (car x) 10) (if seen (setq out (cons 0.0 out))) (setq seen T))
          ((and (= (car x) 42) seen) (setq out (cons (cdr x) out) seen nil))))
  (if seen (setq out (cons 0.0 out)))
  (reverse out))

;; 끝 구간을 따로 그린 임시 객체 (늘여서 만나는 점을 구하려고) → vla 객체
(defun OFT:tmp (sg z / c r a0 a1)
  (if (= (car sg) "L")
    (entmakex (list '(0 . "LINE") (list 10 (car (cadr sg)) (cadr (cadr sg)) z) (list 11 (car (caddr sg)) (cadr (caddr sg)) z)))
    (progn
      (setq c (nth 3 sg) r (nth 4 sg)
            a0 (angle c (cadr sg)) a1 (angle c (caddr sg)))
      (entmakex (list '(0 . "ARC") (list 10 (car c) (cadr c) z) (cons 40 r)
                      (cons 50 (if (= (nth 5 sg) 1) a1 a0)) (cons 51 (if (= (nth 5 sg) 1) a0 a1)))))))

;; 끝 구간 위에서 끝점부터 바깥으로 잰 거리 (자르면 음수)
(defun OFT:along (sg p / c d)
  (if (= (car sg) "L")
    (OFT:dot (OFT:v- p (cadr sg)) (OFT:unit (OFT:v- (cadr sg) (caddr sg))))
    (progn
      (setq c (nth 3 sg)
            d (* (nth 5 sg) (OFT:wrap (- (angle c p) (angle c (cadr sg))))))
      (* d (nth 4 sg)))))

;; 끝 구간 길이
(defun OFT:seg-len (sg / c a)
  (if (= (car sg) "L")
    (distance (cadr sg) (caddr sg))
    (progn
      (setq c (nth 3 sg)
            a (OFT:wrap2 (* (nth 5 sg) (- (angle c (cadr sg)) (angle c (caddr sg))))))
      (* a (nth 4 sg)))))

;; 만나는 점들 (mode 1 = 이 선만 늘임, 3 = 닿은 선도 늘임)
(defun OFT:hits (tmp b mode / r out)
  (setq r (vl-catch-all-apply 'vlax-invoke (list tmp 'IntersectWith (vlax-ename->vla-object b) mode)))
  (if (and r (not (vl-catch-all-error-p r)))
    (while r
      (setq out (cons (list (car r) (cadr r)) out) r (cdddr r))))
  out)

;; 끝을 닿은 선까지 → 새 끝점 또는 nil (못 맞춤) / 'SAME (이미 닿음)
(defun OFT:target (e i bounds reach tol / sg z tmp L best bs s p mode b)
  (setq sg (OFT:seg e i)
        z (caddr (vlax-curve-getStartPoint e))
        L (OFT:seg-len sg))
  (if (setq tmp (OFT:tmp sg z))
    (progn
      (setq tmp (vlax-ename->vla-object tmp))
      (foreach mode '(1 3)
        (if (null best)
          (foreach b bounds
            (if (not (vlax-erased-p (vlax-ename->vla-object b)))
              (foreach p (OFT:hits tmp b mode)
                (setq s (OFT:along sg p))
                (if (and (> s (- (* 0.999 L))) (<= (abs s) reach) (or (null best) (< (abs s) bs)))
                  (setq best p bs (abs s))))))))
      (vla-Delete tmp)))
  (cond ((null best) nil)
        ((< bs tol) 'SAME)
        (T best)))

;; 끝점을 p 로 (같은 구간 모양 그대로)
(defun OFT:move-end (e i p / d tp c n k out sg ang b0 vs z)
  (setq d (entget e) tp (cdr (assoc 0 d)))
  (cond
    ((= tp "LINE")
     (setq k (if (= i 0) 10 11) z (caddr (cdr (assoc k d))))
     (entmod (subst (list k (car p) (cadr p) z) (assoc k d) d)))
    ((= tp "ARC")
     (setq c (OFT:2d (cdr (assoc 10 d))) k (if (= i 0) 50 51))
     (entmod (subst (cons k (angle c p)) (assoc k d) d)))
    ((= tp "LWPOLYLINE")
     (setq sg (OFT:seg e i)
           vs (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) d))
           n (length vs))
     ;; 볼록 다시: 다른점 → 새 끝점, 같은 중심 · 같은 방향
     (if (= (car sg) "A")
       (setq c (nth 3 sg)
             ang (OFT:wrap2 (* (nth 5 sg) (- (angle c p) (angle c (caddr sg)))))
             b0 (* (nth 5 sg) (/ (sin (/ ang 4.0)) (cos (/ ang 4.0))))))
     ;; 시작 끝: 구간 0 = 새점 → 다른점 (방향 반대) · 끝 끝: 구간 n-2 = 다른점 → 새점
     (if (and b0 (= i 0)) (setq b0 (- b0)))
     (setq k -1 out nil)
     (foreach x d
       (cond ((= (car x) 10)
              (setq k (1+ k))
              (setq out (cons (if (= k (if (= i 0) 0 (1- n))) (list 10 (car p) (cadr p)) x) out)))
             ((and b0 (= (car x) 42) (= k (if (= i 0) 0 (- n 2))))
              (setq out (cons (cons 42 b0) out)))
             (T (setq out (cons x out)))))
     (entmod (reverse out))))
  (entupd e))

;; 선 e 를 쪽 pick 으로 d 만큼 → 새 ename 또는 까닭 글
(defun OFT:offset-to (e d pick / o r cand best bd q s)
  (setq o (vlax-ename->vla-object e))
  (foreach s (list d (- d))
    (setq r (vl-catch-all-apply 'vlax-invoke (list o 'Offset s)))
    (if (and r (not (vl-catch-all-error-p r)))
      (foreach x r (setq cand (cons x cand)))))
  (foreach x cand
    (setq q (vlax-curve-getClosestPointTo x (list (car pick) (cadr pick) 0.0)))
    (if (or (null best) (< (distance (OFT:2d q) pick) bd))
      (setq best x bd (distance (OFT:2d q) pick))))
  (foreach x cand (if (not (eq x best)) (vla-Delete x)))
  (if best (vlax-vla-object->ename best) "오프셋하지 못했습니다 (호가 너무 작아지는 쪽인지 확인)."))

;; 점 p 가 선 e 의 어느 쪽인가 → 1 (왼쪽) / -1 (오른쪽) / 0
(defun OFT:side (e p / q d c)
  (setq q (vlax-curve-getClosestPointTo e (list (car p) (cadr p) 0.0))
        d (vlax-curve-getFirstDeriv e (vlax-curve-getParamAtPoint e q))
        c (OFT:crs (OFT:2d d) (OFT:v- p (OFT:2d q))))
  (cond ((> c 1e-9) 1) ((< c -1e-9) -1) (T 0)))

;; 끝 맞춤 한 번 → (맞춘 수 못 맞춘 수)
(defun OFT:fit (e ends reach tol / i ok bad t1 bs)
  (setq i 0 ok 0 bad 0)
  (foreach bs ends
    (if bs
      (progn
        (setq t1 (OFT:target e i bs reach tol))
        (cond ((null t1) (setq bad (1+ bad)))
              ((= t1 'SAME) nil)
              ((not (vl-catch-all-error-p (vl-catch-all-apply 'OFT:move-end (list e i t1)))) (setq ok (1+ ok)))
              (T (setq bad (1+ bad))))))
    (setq i (1+ i)))
  (list ok bad))

(defun OFT:ask-dist (cur / x)
  (initget 6)
  (setq x (getdist (strcat "\n오프셋 거리 <" (rtos cur 2 4) ">: ")))
  (cond (x (setenv "HyOftDist" (rtos x 2 8)) x) (cur)))

(defun c:OFT (/ *error* doc undo_open dist src e why tol ends ref batches made ok bad r p n k go nb nf excl lastb x sd rsd)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (defun *error* (msg)
    (if (= (type e) 'ENAME) (redraw e 4))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (setq dist (cond ((and (getenv "HyOftDist") (> (atof (getenv "HyOftDist")) 0.0)) (atof (getenv "HyOftDist")))
                   ((> (getvar "OFFSETDIST") 0.0) (getvar "OFFSETDIST"))
                   (100.0)))
  (setq dist (OFT:ask-dist dist) made 0 ok 0 bad 0)
  (vla-StartUndoMark doc)
  (setq undo_open T)
  (while (progn (initget "D") (setq src (entsel (strcat "\n오프셋할 선을 누르세요 [거리(D)] <끝> (거리 " (rtos dist 2 4) "): "))))
    (cond
      ((= src "D") (setq dist (OFT:ask-dist dist)))
      ((setq why (OFT:why-not (setq e (car src)))) (princ (strcat "\n[주의] " why)))
      (T
       (setq tol (max 1e-3 (* 1e-6 (OFT:length e)))
             excl (list e)
             ends (list (OFT:touching (car (OFT:end e 0)) excl tol) (OFT:touching (car (OFT:end e 1)) excl tol))
             ref e rsd 0 batches nil go T)
       (redraw e 3)
       (setq nb (length (vl-remove nil (mapcar '(lambda (x) (if x T)) ends))))
       (princ (cond ((= nb 2) "\n[알림] 두 끝이 닿은 선까지 맞춥니다.")
                    ((= nb 1) (strcat "\n[알림] " (if (car ends) "시작" "끝") " 쪽 끝만 닿은 선이 있어 그 끝을 맞춥니다."))
                    (T "\n[알림] 끝에 닿은 선이 없어 오프셋만 합니다.")))
       (while go
         (initget "N D S U")
         (setq p (getpoint "\n오프셋할 쪽을 찍으세요 [개수(N)/거리(D)/원래 선에서(S)/되돌리기(U)] <다음 선>: "))
         (cond
           ((null p) (setq go nil))
           ((= p "D") (setq dist (OFT:ask-dist dist)))
           ((= p "S") (setq ref e rsd 0) (princ "\n[알림] 다음은 원래 선에서 오프셋합니다."))
           ((= p "U")
            (if (setq lastb (car batches))
              (progn
                (foreach x lastb (if (entget x) (entdel x)))
                (setq made (- made (length lastb)) batches (cdr batches)
                      ref (if (car batches) (car (car batches)) e)
                      rsd (if (eq ref e) 0 (OFT:side e (OFT:2d (vlax-curve-getPointAtDist ref (/ (OFT:length ref) 2.0))))))
                (princ (strcat "\n[알림] " (itoa (length lastb)) "줄을 지웠습니다.")))
              (princ "\n[주의] 되돌릴 것이 없습니다.")))
           (T
            (setq n 1)
            (if (= p "N")
              (progn
                (initget 6)
                (setq n (cond ((getint "\n몇 줄 <2>: ")) (2)))
                (setq p (getpoint "\n오프셋할 쪽을 찍으세요: "))))
            (if p
              (progn
                (setq p (OFT:2d (trans p 1 0)) k 0 lastb nil sd (OFT:side e p))
                ;; 원래 선의 반대쪽을 찍으면 원래 선에서 다시 (만든 줄 위로 되돌아가지 않게)
                (if (and (/= rsd 0) (/= sd rsd)) (setq ref e))
                (while (< k n)
                  (setq r (OFT:offset-to ref dist p))
                  (if (= (type r) 'STR)
                    (progn (princ (strcat "\n[주의] " r)) (setq k n))
                    (progn
                      (setq excl (cons r excl) lastb (cons r lastb) made (1+ made))
                      ;; 원래 선에서 멀수록 끝이 더 많이 움직일 수 있음 — 그 거리의 60배까지 (닿은 선과 1° 쯤 비스듬해도)
                      (setq nf (OFT:fit r ends (* 60.0 dist (length excl)) tol)
                            ok (+ ok (car nf)) bad (+ bad (cadr nf)) ref r rsd sd k (1+ k)))))
                (if lastb (setq batches (cons lastb batches))))))))
       (redraw e 4))))
  (vla-EndUndoMark doc)
  (setq undo_open nil)
  (if (> made 0)
    (princ (strcat "\n[완료] " (itoa made) "줄 오프셋 · 끝 " (itoa ok) "곳을 닿은 선까지 맞췄습니다."
                   (if (> bad 0) (strcat "\n[주의] 닿은 선과 만나지 않는 끝 " (itoa bad) "곳은 그대로 두었습니다.") ""))))
  (princ))
