;;; ==============================================================================
;;;  ALL — 그룹·가구·문을 벽선에 맞추기 (모드 기억)
;;;
;;;  모드 1 (그룹 정렬): 기준 벽선을 클릭하고 그룹·블록을 고르면, 묶음마다 바깥 점(선 끝 · 블록 자기 방향 상자의 모서리) 중
;;;         벽선에 가장 가까운 점을 벽선에 붙인다.
;;;         · 묶음 = 그룹(이름 없는 그룹 포함) 하나 또는 그룹에 들지 않은 블록 하나 — 섞여 고른 벽선·치수·해치는 옮기지 않는다.
;;;         · 기준 방향은 클릭한 곳의 벽 방향 (꺾인 폴리선은 클릭한 구간).
;;;         · 회전 허용이면 묶음을 벽 방향에 맞춰 돌린다 — 이미 맞춘 묶음은 다시 돌지 않는다 (블록은 그 회전, 그룹은 가장 긴 선 방향으로 판단).
;;;         · 끝나면 [뒤집기(F)] 로 벽선 기준 안/밖을 바꾸고 Enter 로 끝낸다 (마우스로 바뀌지 않음).
;;;  모드 2 (가구 벽면 밀착): 벽선을 클릭하고 블록 안의 뒷선(직선)을 클릭하면, 뒷선이 벽과 나란하게 (덜 돌리는 쪽으로) 돌려 뒷선을 벽에 붙인다.
;;;         마우스를 벽 반대쪽으로 옮기거나 Tab·F 를 누르면 뒷선을 클릭한 자리를 축으로 벽 반대쪽으로 넘어간다. 클릭·Enter = 끝.
;;;  모드 3 (문 코너 밀착): 벽선과 문 블록을 고르면, 문마다 자기 축(블록 X 방향)으로 가장 가까운 벽까지 문 끝을 붙인다 (사선 문도).
;;;  잠긴 레이어는 빠진다. UCS 를 돌려 둔 화면에서도 맞다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; ── 공통 ─────────────────────────────────────────────────
(defun all:pick (msg / sel)
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel msg))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  sel)

;; 클릭한 곳의 곡선 방향 → (곡선 위 점 각도) (월드) / 곡선이 아니면 nil
(defun all:tangent (sel / o p d)
  (setq o (vlax-ename->vla-object (car sel)))
  (if (not (vl-catch-all-error-p (setq p (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list o (trans (cadr sel) 1 0))))))
    (if (not (vl-catch-all-error-p (setq d (vl-catch-all-apply 'vlax-curve-getFirstDeriv (list o (vlax-curve-getParamAtPoint o p))))))
      (list (list (car p) (cadr p) 0.0) (angle '(0 0 0) d)))))

;; 점 p 의 선(점 a · 방향 ang)에서 부호 있는 거리 (왼쪽 +)
(defun all:sdist (p a ang)
  (- (* (cos ang) (- (cadr p) (cadr a))) (* (sin ang) (- (car p) (car a)))))

(defun all:rot (p c ang / dx dy)
  (setq dx (- (car p) (car c)) dy (- (cadr p) (cadr c)))
  (list (+ (car c) (- (* dx (cos ang)) (* dy (sin ang)))) (+ (cadr c) (+ (* dx (sin ang)) (* dy (cos ang)))) 0.0))

;; (-π, π] 로
(defun all:norm (a)
  (while (> a pi) (setq a (- a (* 2 pi))))
  (while (<= a (- pi)) (setq a (+ a (* 2 pi))))
  a)

;; (-π/4, π/4] 로 (90° 단위 나머지)
(defun all:q90 (a / q)
  (setq q (/ pi 2) a (rem a q))
  (if (< a 0) (setq a (+ a q)))
  (if (> a (/ q 2)) (- a q) a))

;; 그룹 (330 반응자로) / 없으면 nil
(defun all:group (e / g)
  (foreach it (member '(102 . "{ACAD_REACTORS") (entget e))
    (if (and (not g) (= (car it) 330) (= (cdr (assoc 0 (entget (cdr it)))) "GROUP")) (setq g (cdr it))))
  g)

(defun all:box (o / a b)
  (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
    (list (vlax-safearray->list a) (vlax-safearray->list b))))

;; 선을 기준으로 뒤집는 행렬
(defun all:mirror (a ang / c2 s2 x y)
  (setq c2 (cos (* 2 ang)) s2 (sin (* 2 ang)) x (car a) y (cadr a))
  (vlax-tmatrix (list (list c2 s2 0.0 (- x (+ (* x c2) (* y s2))))
                      (list s2 (- c2) 0.0 (+ y (- (* y c2) (* x s2))))
                      '(0.0 0.0 1.0 0.0) '(0.0 0.0 0.0 1.0))))

;; 경계 상자 → 네 모서리
(defun all:corners (b)
  (list (car b) (list (car (cadr b)) (cadr (car b)) 0.0) (cadr b) (list (car (car b)) (cadr (cadr b)) 0.0)))

;; 객체의 바깥 점들 (월드): 선 = 두 끝, 꺾은 폴리선 = 꼭짓점, 블록 = 자기 방향 상자의 네 모서리, 그 밖 = 경계 상자 모서리
;; (돌아간 블록·그룹도 실제 모양으로 붙게 — 월드 상자는 실제보다 커서 사선 벽과 틈이 생김)
(defun all:pts (o / nm b r ins pl out)
  (setq nm (vla-get-ObjectName o))
  (cond
    ((= nm "AcDbLine") (list (vlax-get o 'StartPoint) (vlax-get o 'EndPoint)))
    ((and (= nm "AcDbPolyline") (setq pl (all:pairs (vlax-get o 'Coordinates))) (all:flat-p o (length pl)))
     (mapcar '(lambda (p) (list (car p) (cadr p) 0.0)) pl))
    ((= nm "AcDbBlockReference")
     (setq r (vla-get-Rotation o) ins (vlax-get o 'InsertionPoint))
     (if (/= r 0.0) (vla-Rotate o (vlax-3d-point ins) (- r)))
     (setq b (all:box o))
     (if (/= r 0.0) (vla-Rotate o (vlax-3d-point ins) r))
     (if b (foreach p (all:corners b) (setq out (cons (all:rot p ins r) out))))
     out)
    ((setq b (all:box o)) (all:corners b))))

;; 볼록(호) 구간이 없는 폴리선인지
(defun all:flat-p (o n / i ok)
  (setq i 0 ok T)
  (while (and ok (< i n))
    (if (/= (vla-GetBulge o i) 0.0) (setq ok nil))
    (setq i (1+ i)))
  ok)

;; (x y x y …) → ((x y) …)
(defun all:pairs (l / out)
  (while (cdr l) (setq out (cons (list (car l) (cadr l)) out) l (cddr l)))
  (reverse out))

;; nentsel 행렬로 점 옮기기
(defun all:xf (p m / z)
  (setq z (if (caddr p) (caddr p) 0.0))
  (mapcar '(lambda (i) (+ (* (car p) (nth i (nth 0 m))) (* (cadr p) (nth i (nth 1 m))) (* z (nth i (nth 2 m))) (nth i (nth 3 m))))
          '(0 1 2)))

;; ── 모드 1 ───────────────────────────────────────────────
(defun all:mode1 (sub / sel tg base ang ss i e g cl hit objs n pts c rd cur ins long len lo d o moved key)
  (setq sel (all:pick "\n기준 벽선을 클릭하세요 (클릭한 곳의 방향으로): "))
  (cond
    ((null sel) (princ "\n벽선을 고르지 않았습니다."))
    ((null (setq tg (all:tangent sel))) (princ "\n[주의] 선·호·폴리선을 클릭하세요."))
    ((progn (setq base (car tg) ang (cadr tg))
            (prompt "\n맞출 그룹·블록을 고르세요 (잠긴 레이어는 빠짐): ")
            (null (setq ss (ssget "_:L")))) (princ "\n고른 객체가 없습니다."))
    (T
     ;; 묶음: 그룹 하나 또는 그룹에 들지 않은 블록 하나
     (setq i 0)
     (while (< i (sslength ss))
       (setq e (ssname ss i) g (all:group e))
       (cond (g (if (setq hit (assoc g cl)) (setq cl (subst (cons g (cons e (cdr hit))) hit cl)) (setq cl (cons (list g e) cl))))
             ((= (cdr (assoc 0 (entget e))) "INSERT") (setq cl (cons (list e e) cl))))
       (setq i (1+ i)))
     (setq n 0)
     (foreach k cl
       (setq objs (mapcar 'vlax-ename->vla-object (cdr k)) pts nil)
       (foreach o objs (setq pts (append (all:pts o) pts)))
       (if pts
         (progn
           (setq c (list (/ (+ (apply 'min (mapcar 'car pts)) (apply 'max (mapcar 'car pts))) 2.0)
                         (/ (+ (apply 'min (mapcar 'cadr pts)) (apply 'max (mapcar 'cadr pts))) 2.0) 0.0)
                 rd 0.0)
           (if (= sub "2")
             (progn
               ;; 지금 방향: 블록이 있으면 그 회전, 없으면 가장 긴 선
               (setq ins (vl-remove-if-not '(lambda (o) (= (vla-get-ObjectName o) "AcDbBlockReference")) objs) cur nil)
               (if ins
                 (setq cur (vla-get-Rotation (car ins)))
                 (progn (setq long 0.0)
                        (foreach o objs
                          (if (and (= (vla-get-ObjectName o) "AcDbLine") (> (setq len (vla-get-Length o)) long))
                            (setq long len cur (vla-get-Angle o))))))
               (if cur
                 (setq rd (if (and ins (= (length objs) 1))
                            ;; 블록 하나: 벽 방향과 그 반대 중 가까운 쪽으로
                            (if (<= (abs (all:norm (- ang cur))) (abs (all:norm (- (+ ang pi) cur))))
                              (all:norm (- ang cur))
                              (all:norm (- (+ ang pi) cur)))
                            ;; 그룹: 90° 단위로 가장 조금 돌려 맞춤 (이미 맞으면 0)
                            (all:q90 (- ang cur)))))))
           ;; 돌린 뒤 꼭짓점 중 벽선에 가장 가까운 점
           (setq lo nil)
           (foreach p pts
             (setq d (all:sdist (all:rot p c rd) base ang))
             (if (or (null lo) (< (abs d) (abs lo))) (setq lo d)))
           (foreach o objs
             (if (/= rd 0.0) (vla-Rotate o (vlax-3d-point c) rd))
             (vla-Move o (vlax-3d-point '(0.0 0.0 0.0))
                       (vlax-3d-point (list (* lo (sin ang)) (- (* lo (cos ang))) 0.0))))
           (setq moved (append objs moved) n (1+ n)))))
     (if (= n 0)
       (princ "\n[알림] 고른 것 중 그룹·블록이 없습니다.")
       (progn
         (princ (strcat "\n묶음 " (itoa n) "개를 벽선에 붙였습니다" (if (= sub "2") " (벽 방향으로 회전)" "") "."))
         ;; 안/밖 뒤집기 (키로만)
         (while (progn
                  (initget "Flip")
                  (setq key (getkword "\n안/밖 [뒤집기(F)] <Enter = 끝>: "))
                  (= key "Flip"))
           (foreach o moved (vla-TransformBy o (all:mirror base ang))))
         (princ (strcat "\n[완료] 그룹·블록 " (itoa n) "개를 벽선에 맞췄습니다.")))))))

;; ── 모드 2 ───────────────────────────────────────────────
(defun all:mode2 ( / sel tg base ang ns sub m blk o ed pa pb la delta c pk pr proj q pv bx side gr code p go)
  (setq sel (all:pick "\n붙일 벽선을 클릭하세요: "))
  (cond
    ((null sel) (princ "\n벽선을 고르지 않았습니다."))
    ((null (setq tg (all:tangent sel))) (princ "\n[주의] 선·호·폴리선을 클릭하세요."))
    ((progn (setq base (car tg) ang (cadr tg))
            (setvar "ERRNO" 0)
            (while (and (null (setq ns (nentsel "\n벽에 붙일 블록 안의 뒷선(직선)을 클릭하세요: "))) (= (getvar "ERRNO") 7))
              (princ "\n빗나갔습니다. 다시 클릭하세요.") (setvar "ERRNO" 0))
            (null ns)) (princ "\n블록을 고르지 않았습니다."))
    ((or (null (cadddr ns)) (/= (cdr (assoc 0 (entget (car ns)))) "LINE"))
     (princ "\n[주의] 블록 안의 직선(LINE)을 클릭하세요."))
    ((progn (setq blk (last (cadddr ns)) o (vlax-ename->vla-object blk))
            (vl-catch-all-error-p (vl-catch-all-apply 'vla-Move (list o (vlax-3d-point '(0.0 0.0 0.0)) (vlax-3d-point '(0.0 0.0 0.0))))))
     (princ "\n[주의] 잠긴 레이어의 블록은 옮길 수 없습니다."))
    (T
     (setq sub (car ns) m (caddr ns) ed (entget sub)
           pa (all:xf (cdr (assoc 10 ed)) m) pb (all:xf (cdr (assoc 11 ed)) m)
           la (angle pa pb)
           ;; 뒷선이 벽과 나란하게 — 두 방향 중 덜 돌리는 쪽
           delta (all:norm (- ang la))
           delta (if (> (abs delta) (/ pi 2)) (- delta (if (> delta 0) pi (- pi))) delta)
           c (vlax-get o 'InsertionPoint)
           pk (trans (cadr ns) 1 0))
     ;; 블록 기준점으로 돌림 → 뒷선 위 점을 벽선에 수직으로 붙임
     (vla-Rotate o (vlax-3d-point c) delta)
     (setq pr (all:rot pa c delta)
           proj (polar pr (+ ang (/ pi 2)) (- (all:sdist pr base ang))))
     (vla-Move o (vlax-3d-point pr) (vlax-3d-point proj))
     ;; 뒤집는 축: 뒷선을 클릭한 곳을 벽에 내린 점 (그 자리에서 벽 반대쪽으로 넘어감)
     (setq q (mapcar '+ (all:rot pk c delta) (mapcar '- proj pr))
           pv (polar q (+ ang (/ pi 2)) (- (all:sdist q base ang)))
           bx (all:box o)
           side (> (all:sdist (mapcar '(lambda (a b) (/ (+ a b) 2.0)) (car bx) (cadr bx)) base ang) 0)
           go T)
     (prompt "\n마우스를 벽 반대쪽으로 옮기거나 Tab·F 로 뒤집고, 클릭·Enter 로 끝내세요.")
     (while go
       (setq gr (grread T 15 0) code (car gr))
       (cond
         ((= code 5)
          (setq p (trans (cadr gr) 1 0))
          (if (not (eq (> (all:sdist p base ang) 0) side))
            (progn (vla-Rotate o (vlax-3d-point pv) pi) (setq side (not side)))))
         ((and (= code 2) (member (cadr gr) '(9 70 102 12601)))                  ; Tab F f ㄹ
          (vla-Rotate o (vlax-3d-point pv) pi) (setq side (not side)))
         ((member code '(2 3 11 25)) (setq go nil))))
     (princ "\n[완료] 가구를 벽에 붙였습니다."))))

;; ── 모드 3 ───────────────────────────────────────────────
(defun all:mode3 ( / sw sd i ed walls n miss o ins rot u best side d hit a b e2 box ep em mv)
  (prompt "\n코너를 이루는 벽선을 고르세요: ")
  (cond
    ((null (setq sw (ssget '((0 . "LINE"))))) (princ "\n고른 벽선이 없습니다."))
    ((progn (prompt "\n코너에 붙일 문 블록을 고르세요 (잠긴 레이어는 빠짐): ")
            (null (setq sd (ssget "_:L" '((0 . "INSERT")))))) (princ "\n고른 문이 없습니다."))
    (T
     (setq i 0)
     (while (< i (sslength sw))
       (setq ed (entget (ssname sw i)) walls (cons (list (cdr (assoc 10 ed)) (cdr (assoc 11 ed))) walls) i (1+ i)))
     (setq i 0 n 0 miss 0)
     (while (< i (sslength sd))
       (setq o (vlax-ename->vla-object (ssname sd i)) ins (vlax-get o 'InsertionPoint) rot (vla-get-Rotation o)
             u (list (cos rot) (sin rot)) best nil)
       ;; 문 축(양쪽)과 벽선이 만나는 가장 가까운 점
       (foreach w walls
         (if (setq hit (inters (list (car ins) (cadr ins)) (list (+ (car ins) (car u)) (+ (cadr ins) (cadr u)))
                               (list (car (car w)) (cadr (car w))) (list (car (cadr w)) (cadr (cadr w))) nil))
           (if (<= (abs (- (+ (distance (car w) (append hit '(0.0))) (distance (append hit '(0.0)) (cadr w))) (distance (car w) (cadr w)))) 0.1)
             (progn
               (setq d (+ (* (car u) (- (car hit) (car ins))) (* (cadr u) (- (cadr hit) (cadr ins)))))
               (if (or (null best) (< (abs d) (abs best))) (setq best d))))))
       (if (null best)
         (setq miss (1+ miss))
         (progn
           ;; 문의 축 방향 길이: 잠시 0° 로 돌려 상자를 잼
           (vla-Rotate o (vlax-3d-point ins) (- rot))
           (setq box (all:box o))
           (vla-Rotate o (vlax-3d-point ins) rot)
           (setq ep (- (car (cadr box)) (car ins)) em (- (car ins) (car (car box)))
                 mv (if (> best 0) (- best ep) (+ best em)))
           (vla-Move o (vlax-3d-point '(0.0 0.0 0.0)) (vlax-3d-point (list (* mv (car u)) (* mv (cadr u)) 0.0)))
           (setq n (1+ n))))
       (setq i (1+ i)))
     (princ (strcat "\n[완료] 문 " (itoa n) "개를 코너에 붙였습니다"
                    (if (> miss 0) (strcat " (" (itoa miss) "개는 축 위에 벽이 없어 그대로)") "") ".")))))

(defun c:ALL ( / *error* doc undo_open sv mode sub)
  (defun *error* (msg)
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (redraw)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        mode (cond ((getenv "HyAllMode")) ("1")) sub (cond ((getenv "HyAllSub")) ("1")))
  (initget "1 2 3")
  (setq mode (cond ((getkword (strcat "\n모드 [그룹 정렬(1)/가구 벽면 밀착(2)/문 코너 밀착(3)] <" mode ">: "))) (mode)))
  (setenv "HyAllMode" mode)
  (if (= mode "1")
    (progn
      (initget "1 2")
      (setq sub (cond ((getkword (strcat "\n회전 [회전 안 함(1)/벽 방향으로 회전(2)] <" sub ">: "))) (sub)))
      (setenv "HyAllSub" sub)))
  (setq sv (list (cons "CMDECHO" (getvar "CMDECHO"))))
  (setvar "CMDECHO" 0)
  (vla-StartUndoMark doc)
  (setq undo_open T)
  (cond ((= mode "1") (all:mode1 sub)) ((= mode "2") (all:mode2)) (T (all:mode3)))
  (vla-EndUndoMark doc)
  (setq undo_open nil)
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
