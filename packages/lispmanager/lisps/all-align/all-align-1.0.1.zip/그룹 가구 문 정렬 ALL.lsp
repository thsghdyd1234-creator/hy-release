(vl-load-com)

;; ==============================================================================
;; [전역 변수 초기화] 마지막 사용 모드 기억
;; ==============================================================================
(if (null *ALL_LAST_MODE*) (setq *ALL_LAST_MODE* "1"))
(if (null *ALL_LAST_SUBMODE1*) (setq *ALL_LAST_SUBMODE1* "1")) ;; 1: 회전 안 함, 2: 회전 허용

(defun c:ALL ( / mode mode_prompt sub_prompt sub_mode old_cmdecho
                 get-group is-left transform-pt ang-diff get-mirror-matrix 
                 ref_ent ref_obj p1 p2 ref_ang ss i e grp clusters existing key ents min_x min_y max_x max_y valid pt1 pt2 cx cy delta p1_move p2_move total_groups obj
                 wallEnt wallData wallP1 wallP2 wallAng nentData blkEnt blkData blkIns pickPt p_nea p_end p_mid currentLineAng delta_ang dist ang0 p_rot perpAng p_perp blkIns_new currentFacing loop gr grCode grPt mouseSide
                 ssWalls ssDoors wallLines wPts doorEnt objDoor insPt rot pA pB pInt lenWall distWall distToP1 distToP2 intList1 intList2 dist1 dist2 ptTarget1 ptTarget2 ptTarget bMin bMax moveAng movePt
                 local-dist-to-line local-rotate-pt ptCenter current_rot rot_diff c1 c2 c3 c4 r1 r2 r3 r4 d1 d2 d3 d4 d_list min_d den ux uy move_x move_y d
                 wallObj pickWall closePt param deriv subEnt mat parents pA_local pB_local pA_wcs pB_wcs
                 is_block edata a1 a2 target_rot active_objs mirr_mat first_gr
               )

  ;; 명령 실행 중 명령창에 불필요한 메시지가 나오지 않게 함
  (setq old_cmdecho (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)

  ;; ----------------------------------------------------------------------------
  ;; [내부 함수] 1. 그룹 ID 찾기
  ;; ----------------------------------------------------------------------------
  (defun get-group (ent / ed dicts grp item item_ed)
    (setq ed (entget ent))
    (setq grp nil)
    (if (setq dicts (member '(102 . "{ACAD_REACTORS") ed))
      (foreach item dicts
        (if (and (= (car item) 330) (not grp))
          (if (not (vl-catch-all-error-p (setq item_ed (vl-catch-all-apply 'entget (list (cdr item))))))
            (if (and item_ed (= (cdr (assoc 0 item_ed)) "GROUP"))
              (setq grp (cdr item))
            )
          )
        )
      )
    )
    grp
  )

  ;; ----------------------------------------------------------------------------
  ;; [내부 함수] 2. 외적을 이용한 좌/우(방향) 판별 함수
  ;; ----------------------------------------------------------------------------
  (defun is-left (p1 p2 p / val)
    (setq val (- (* (- (car p2) (car p1)) (- (cadr p) (cadr p1)))
                 (* (- (cadr p2) (cadr p1)) (- (car p) (car p1)))))
    (if (> val 0) t nil)
  )

  ;; ----------------------------------------------------------------------------
  ;; [내부 함수] 3. 행렬로 점 변환 (nentsel 결과용)
  ;; ----------------------------------------------------------------------------
  (defun transform-pt (pt mat / x y z)
    (setq x (car pt) y (cadr pt) z (caddr pt))
    (if (null z) (setq z 0.0))
    (list
      (+ (* x (car (nth 0 mat))) (* y (car (nth 1 mat))) (* z (car (nth 2 mat))) (car (nth 3 mat)))
      (+ (* x (cadr (nth 0 mat))) (* y (cadr (nth 1 mat))) (* z (cadr (nth 2 mat))) (cadr (nth 3 mat)))
      (+ (* x (caddr (nth 0 mat))) (* y (caddr (nth 1 mat))) (* z (caddr (nth 2 mat))) (caddr (nth 3 mat)))
    )
  )

  ;; ----------------------------------------------------------------------------
  ;; [내부 함수] 4. 두 각도 사이의 최소 회전 차이 계산
  ;; ----------------------------------------------------------------------------
  (defun ang-diff (a b / d)
    (setq d (rem (abs (- a b)) (* 2.0 pi)))
    (if (> d pi) (- (* 2.0 pi) d) d)
  )

  ;; ----------------------------------------------------------------------------
  ;; [내부 함수] 5. 선분을 기준으로 하는 반사(Mirror) 변환 행렬(4x4) 생성
  ;; (객체의 그룹 속성·핸들을 유지한 채 제자리에서 반전하기 위함)
  ;; ----------------------------------------------------------------------------
  (defun get-mirror-matrix (pA pB / x1 y1 a c2 s2)
    (setq x1 (car pA) y1 (cadr pA))
    (setq a (angle pA pB))
    (setq c2 (cos (* 2.0 a)) s2 (sin (* 2.0 a)))
    (vlax-tmatrix
      (list
        (list c2 s2 0.0 (- x1 (+ (* x1 c2) (* y1 s2))))
        (list s2 (- c2) 0.0 (+ y1 (- (* y1 c2) (* x1 s2))))
        (list 0.0 0.0 1.0 0.0)
        (list 0.0 0.0 0.0 1.0)
      )
    )
  )

  ;; ==============================================================================
  ;; [모드 선택 UI]
  ;; ==============================================================================
  (initget "1 2 3")
  (setq mode_prompt (strcat "\n작업 모드를 선택하세요 [1: 그룹정렬(사선대응+In/Out) / 2: 가구 벽면밀착 / 3: 문 코너밀착] <" *ALL_LAST_MODE* ">: "))
  (setq mode (getkword mode_prompt))

  (if (null mode)
    (setq mode *ALL_LAST_MODE*)
    (setq *ALL_LAST_MODE* mode)
  )

  (cond
    ;; ==============================================================================
    ;; 모드 1: 그룹 정렬 (사선 인식, 마우스로 안/밖 반전)
    ;; ==============================================================================
    ((= mode "1")
      (initget "1 2")
      (setq sub_prompt (strcat "\n[모드 1] 그룹 객체의 회전 여부를 선택하세요 [1: 회전 허용 안 함 / 2: 회전 허용] <" *ALL_LAST_SUBMODE1* ">: "))
      (setq sub_mode (getkword sub_prompt))
      
      (if (null sub_mode)
        (setq sub_mode *ALL_LAST_SUBMODE1*)
        (setq *ALL_LAST_SUBMODE1* sub_mode)
      )

      (prompt "\n[모드 1: 정렬 ALL] 기준이 될 벽선(가로/세로/사선 모두 가능)을 선택하세요: ")
      (setq ref_ent (car (entsel)))

      (if ref_ent
        (progn
          (setq ref_obj (vlax-ename->vla-object ref_ent))
          (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vlax-curve-getStartPoint (list ref_obj))))
            (progn
              (setq p1 (vlax-curve-getStartPoint ref_obj))
              (setq p2 (vlax-curve-getEndPoint ref_obj))
              (setq ref_ang (angle p1 p2))

              (if (>= ref_ang pi)
                (setq ref_ang (- ref_ang pi))
              )

              (prompt "\n[정렬 ALL] 정렬할 그룹 도면들을 한 번에 넓게 드래그하세요: ")
              (setq ss (ssget))

              (if ss
                (progn
                  (defun local-dist-to-line (ln1 ln2 pt / ax ay bx by px py num den)
                    (setq ax (car ln1) ay (cadr ln1) bx (car ln2) by (cadr ln2) px (car pt) py (cadr pt))
                    (setq num (- (* (- bx ax) (- py ay)) (* (- by ay) (- px ax))))
                    (setq den (distance ln1 ln2))
                    (if (= den 0.0) 0.0 (/ num den))
                  )

                  (defun local-rotate-pt (pt center ang / cx cy px py dx dy cosA sinA)
                    (setq cx (car center) cy (cadr center) px (car pt) py (cadr pt) dx (- px cx) dy (- py cy) cosA (cos ang) sinA (sin ang))
                    (list (+ cx (- (* dx cosA) (* dy sinA))) (+ cy (+ (* dx sinA) (* dy cosA))) 0.0)
                  )

                  (setq clusters '())
                  (setq i 0)
                  (while (< i (sslength ss))
                    (setq e (ssname ss i))
                    (setq grp (get-group e))
                    (if (not grp) (setq grp e))
                    (setq existing (assoc grp clusters))
                    (if existing
                      (setq clusters (subst (append existing (list e)) existing clusters))
                      (setq clusters (cons (list grp e) clusters))
                    )
                    (setq i (1+ i))
                  )

                  (setq total_groups 0)
                  (foreach cluster clusters
                    (setq key (car cluster))
                    (setq ents (cdr cluster))
                    (setq min_x 1e99 min_y 1e99 max_x -1e99 max_y -1e99 valid nil)

                    ;; BoundingBox 추출
                    (foreach e ents
                      (setq obj (vlax-ename->vla-object e))
                      (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'minPt 'maxPt))))
                        (progn
                          (setq pt1 (vlax-safearray->list minPt))
                          (setq pt2 (vlax-safearray->list maxPt))
                          (setq min_x (min min_x (car pt1))) (setq min_y (min min_y (cadr pt1)))
                          (setq max_x (max max_x (car pt2))) (setq max_y (max max_y (cadr pt2)))
                          (setq valid T)
                        )
                      )
                    )

                    (if valid
                      (progn
                        ;; 블록(INSERT) 판별 및 기준점 추출
                        (setq is_block nil blkIns nil current_rot 0.0)
                        (foreach e ents
                          (setq edata (entget e))
                          (if (= (cdr (assoc 0 edata)) "INSERT")
                            (progn
                              (setq is_block T)
                              (setq blkIns (cdr (assoc 10 edata)))
                              (setq current_rot (vla-get-Rotation (vlax-ename->vla-object e)))
                            )
                          )
                        )

                        (if is_block
                          (setq ptCenter blkIns)
                          (setq ptCenter (list (/ (+ min_x max_x) 2.0) (/ (+ min_y max_y) 2.0) 0.0))
                        )

                        (if (= sub_mode "2")
                          (if is_block
                            (progn
                              (setq a1 ref_ang a2 (+ ref_ang pi))
                              (if (<= (ang-diff current_rot a1) (ang-diff current_rot a2))
                                (setq target_rot a1)
                                (setq target_rot a2)
                              )
                              (setq rot_diff (- target_rot current_rot))
                            )
                            (progn
                              (setq rot_diff (rem ref_ang (/ pi 2.0)))
                              (if (> rot_diff (/ pi 4.0)) (setq rot_diff (- rot_diff (/ pi 2.0))))
                              (if (< rot_diff (- (/ pi 4.0))) (setq rot_diff (+ rot_diff (/ pi 2.0))))
                            )
                          )
                          (setq rot_diff 0.0)
                        )

                        (if is_block
                          (setq min_d (local-dist-to-line p1 p2 ptCenter))
                          (progn
                            (setq c1 (list min_x min_y 0.0) c2 (list max_x min_y 0.0) c3 (list max_x max_y 0.0) c4 (list min_x max_y 0.0))
                            (setq r1 (local-rotate-pt c1 ptCenter rot_diff))
                            (setq r2 (local-rotate-pt c2 ptCenter rot_diff))
                            (setq r3 (local-rotate-pt c3 ptCenter rot_diff))
                            (setq r4 (local-rotate-pt c4 ptCenter rot_diff))

                            (setq d1 (local-dist-to-line p1 p2 r1))
                            (setq d2 (local-dist-to-line p1 p2 r2))
                            (setq d3 (local-dist-to-line p1 p2 r3))
                            (setq d4 (local-dist-to-line p1 p2 r4))

                            (setq d_list (list d1 d2 d3 d4))
                            (setq min_d (car d_list))
                            (foreach d (cdr d_list)
                              (if (< (abs d) (abs min_d)) (setq min_d d))
                            )
                          )
                        )

                        (setq den (distance p1 p2))
                        (if (> den 0.0)
                          (progn
                            (setq ux (/ (- (cadr p1) (cadr p2)) den))
                            (setq uy (/ (- (car p2) (car p1)) den))
                            (setq move_x (* (- min_d) ux))
                            (setq move_y (* (- min_d) uy))

                            (setq p1_move (vlax-3d-point '(0.0 0.0 0.0)))
                            (setq p2_move (vlax-3d-point (list move_x move_y 0.0)))

                            (foreach e ents
                              (setq obj (vlax-ename->vla-object e))
                              (if (/= rot_diff 0.0)
                                (vla-Rotate obj (vlax-3d-point ptCenter) rot_diff)
                              )
                              (vla-Move obj p1_move p2_move)
                            )
                            (setq total_groups (1+ total_groups))
                          )
                        )
                      )
                    )
                  )
                  
                  ;; ==============================================================================
                  ;; 일괄 정렬 후 마우스 위치에 따라 안/밖 방향 반전
                  ;; ==============================================================================
                  (if (> total_groups 0)
                    (progn
                      ;; 이동된 모든 객체의 VLA-OBJECT 수집
                      (setq active_objs '())
                      (foreach cluster clusters
                        (foreach e (cdr cluster)
                          (setq active_objs (cons (vlax-ename->vla-object e) active_objs))
                        )
                      )
                      
                      ;; 벽선 기준 대칭(Mirror) 행렬 생성
                      (setq mirr_mat (get-mirror-matrix p1 p2))
                      
                      (prompt "\n마우스를 움직여 문(가구)의 방향(방 안쪽/바깥쪽)을 결정하고, 좌클릭하여 확정하세요.")
                      
                      (setq loop T)
                      (setq first_gr (grread T 15 0))
                      (if (= (car first_gr) 5)
                        (setq currentFacing (is-left p1 p2 (cadr first_gr)))
                        (setq currentFacing T)
                      )

                      (while loop
                        (setq gr (grread T 15 0))
                        (setq grCode (car gr) grPt (cadr gr))

                        (cond
                          ((= grCode 5) ; 마우스 이동 감지
                            (setq mouseSide (is-left p1 p2 grPt))
                            ;; 마우스가 벽선을 넘어가면 모든 객체를 제자리에서 즉시 뒤집음
                            (if (/= mouseSide currentFacing)
                              (progn
                                (foreach obj active_objs
                                  (vla-TransformBy obj mirr_mat)
                                )
                                (setq currentFacing mouseSide)
                              )
                            )
                          )
                          ((= grCode 3) (setq loop nil)) ; 마우스 좌클릭 시 종료
                          ((or (= grCode 2) (= grCode 11) (= grCode 25)) (setq loop nil)) ; 우클릭/엔터 등
                        )
                      )
                      ;; 최종 메시지 출력
                      (if (= sub_mode "2")
                        (princ (strcat "\n[완료] 정렬과 방향 설정을 마쳤습니다. 총 " (itoa total_groups) "개의 캐드 그룹이 사선 벽에 맞춰 정렬되었습니다."))
                        (princ (strcat "\n[완료] 총 " (itoa total_groups) "개의 캐드 그룹이 '회전 없이' 선에 밀착되었습니다."))
                      )
                    )
                  )
                )
                (princ "\n선택된 객체가 없습니다.")
              )
            )
          )
        )
      )
    )

    ;; ==============================================================================
    ;; 모드 2: 가구 벽면 밀착 (변환 행렬로 각도 계산)
    ;; ==============================================================================
    ((= mode "2")
      (prompt "\n[가구 벽면 밀착] 1. 기준이 될 벽체 선(LINE, ARC, POLYLINE 모두 가능)을 선택하세요: ")
      (setq wallEnt (entsel))
      
      (if wallEnt
        (progn
          (setq wallObj (vlax-ename->vla-object (car wallEnt)))
          (setq pickWall (cadr wallEnt))
          (setq closePt (vlax-curve-getClosestPointTo wallObj pickWall))
          (setq param (vlax-curve-getParamAtPoint wallObj closePt))
          (setq deriv (vlax-curve-getFirstDeriv wallObj param))
          (setq wallAng (angle '(0 0 0) deriv))
          
          (setq wallP1 closePt)
          (setq wallP2 (polar closePt wallAng 10.0))

          (prompt "\n[가구 벽면 밀착] 2. 벽에 붙일 블록 내부의 '뒷선(LINE)'을 클릭하세요: ")
          (setq nentData (nentsel))
          
          (if nentData
            (progn
              (setq subEnt (car nentData))
              (setq pickPt (cadr nentData))
              (setq mat (caddr nentData))
              (setq parents (cadddr nentData))
              
              (setq blkEnt (if parents (last parents) subEnt))
              (setq blkData (entget blkEnt))
              (setq blkIns (cdr (assoc 10 blkData)))
              (if (null blkIns) (setq blkIns pickPt))

              (setq subData (entget subEnt))
              (if (= (cdr (assoc 0 subData)) "LINE")
                (progn
                  (setq pA_local (cdr (assoc 10 subData)))
                  (setq pB_local (cdr (assoc 11 subData)))
                  
                  (if mat
                    (progn
                      (setq pA_wcs (transform-pt pA_local mat))
                      (setq pB_wcs (transform-pt pB_local mat))
                    )
                    (progn
                      (setq pA_wcs pA_local)
                      (setq pB_wcs pB_local)
                    )
                  )

                  (setq currentLineAng (angle pA_wcs pB_wcs))
                  (setq delta_ang (- wallAng currentLineAng))

                  (setq dist (distance blkIns pickPt))
                  (setq ang0 (angle blkIns pickPt))
                  (command "_.ROTATE" blkEnt "" "_non" blkIns (/ (* delta_ang 180.0) pi))
                  
                  (setq p_rot (polar blkIns (+ ang0 delta_ang) dist))
                  (setq perpAng (+ wallAng (/ pi 2.0)))
                  (setq p_perp (inters p_rot (polar p_rot perpAng 1.0) wallP1 wallP2 nil))

                  (command "_.MOVE" blkEnt "" "_non" p_rot "_non" p_perp)

                  (setq blkIns_new (polar blkIns (angle p_rot p_perp) (distance p_rot p_perp)))
                  (setq currentFacing (is-left wallP1 wallP2 blkIns_new))

                  (prompt "\n마우스를 움직여 방향을 확인하고, 좌클릭하여 확정하세요.")
                  
                  (setq loop T)
                  (while loop
                    (setq gr (grread T 15 0))
                    (setq grCode (car gr))
                    (setq grPt (cadr gr))  

                    (cond
                      ((= grCode 5)
                        (setq mouseSide (is-left wallP1 wallP2 grPt))
                        (if (/= mouseSide currentFacing)
                          (progn
                            (command "_.ROTATE" blkEnt "" "_non" p_perp "180")
                            (setq currentFacing mouseSide)
                          )
                        )
                      )
                      ((= grCode 3) (setq loop nil))
                      ((or (= grCode 2) (= grCode 11) (= grCode 25)) (setq loop nil))
                    )
                  )
                  (princ "\n[완료] 배치했습니다.")
                )
                (princ "\n[오류] 블록 내부의 '직선(LINE)' 부분을 정확히 클릭해야 합니다.")
              )
            )
            (princ "\n블록 내부 객체를 선택하지 않았습니다.")
          )
        )
        (princ "\n벽체 선을 선택하지 않았습니다.")
      )
    )

    ;; ==============================================================================
    ;; 모드 3: 문 코너 벽면 밀착
    ;; ==============================================================================
    ((= mode "3")
      (prompt "\n[모드 3: 문 코너밀착] 1. 코너를 형성하는 벽선(LINE)들을 드래그 선택하세요: ")
      (if (setq ssWalls (ssget '((0 . "LINE"))))
        (progn
          (setq wallLines nil i 0)
          (repeat (sslength ssWalls)
            (setq ent (entget (ssname ssWalls i)))
            (setq wallLines (cons (list (list (cadr (assoc 10 ent)) (caddr (assoc 10 ent)) 0.0)
                                        (list (cadr (assoc 11 ent)) (caddr (assoc 11 ent)) 0.0)) 
                                  wallLines))
            (setq i (1+ i))
          )
          
          (prompt "\n[모드 3: 문 코너밀착] 2. 코너로 밀착시킬 문(BLOCK)들을 드래그 선택하세요: ")
          (if (setq ssDoors (ssget '((0 . "INSERT"))))
            (progn
              (setq i 0)
              (repeat (sslength ssDoors)
                (setq doorEnt (ssname ssDoors i))
                (setq objDoor (vlax-ename->vla-object doorEnt))
                
                (setq ent (entget doorEnt))
                (setq insPt (list (cadr (assoc 10 ent)) (caddr (assoc 10 ent)) 0.0))
                (setq rot (vla-get-Rotation objDoor)) 
                
                (setq p1 (polar insPt rot 10000.0))
                (setq p2 (polar insPt (+ rot pi) 10000.0))
                
                (setq intList1 nil intList2 nil)
                
                (foreach wPts wallLines
                  (setq pA (car wPts) pB (cadr wPts))
                  (if (setq pInt (inters insPt p1 pA pB nil))
                    (progn
                      (setq lenWall (distance pA pB))
                      (setq distWall (+ (distance pA pInt) (distance pInt pB)))
                      (if (<= (abs (- distWall lenWall)) 0.1)
                        (progn
                          (setq distToP1 (distance pInt p1))
                          (setq distToP2 (distance pInt p2))
                          (if (< distToP1 distToP2)
                            (setq intList1 (cons pInt intList1))
                            (setq intList2 (cons pInt intList2))
                          )
                        )
                      )
                    )
                  )
                )
                
                (setq dist1 999999.0 dist2 999999.0)
                (if intList1 (setq dist1 (apply 'min (mapcar '(lambda (pt) (distance insPt pt)) intList1))))
                (if intList2 (setq dist2 (apply 'min (mapcar '(lambda (pt) (distance insPt pt)) intList2))))
                
                (setq ptTarget1 nil ptTarget2 nil ptTarget nil)
                (if intList1 (setq ptTarget1 (car (vl-remove-if-not '(lambda (pt) (= (distance insPt pt) dist1)) intList1))))
                (if intList2 (setq ptTarget2 (car (vl-remove-if-not '(lambda (pt) (= (distance insPt pt) dist2)) intList2))))

                (vla-GetBoundingBox objDoor 'bMin 'bMax)
                (setq bMin (vlax-safearray->list bMin)
                      bMax (vlax-safearray->list bMax))

                (cond
                  ((and (< dist1 dist2) (/= dist1 999999.0)) (setq ptTarget ptTarget1))
                  ((and (< dist2 dist1) (/= dist2 999999.0)) (setq ptTarget ptTarget2))
                  (t (princ "\n[주의] 유효한 교차 코너를 찾지 못했습니다."))
                )

                (if ptTarget
                  (progn
                    (setq moveAng (angle insPt ptTarget))
                    (cond
                      ((or (<= moveAng (/ pi 4)) (> moveAng (* pi 1.75)))
                       (setq movePt (list (car bMax) (cadr insPt) 0.0)))
                      ((and (> moveAng (/ pi 4)) (<= moveAng (* pi 0.75)))
                       (setq movePt (list (car insPt) (cadr bMax) 0.0)))
                      ((and (> moveAng (* pi 0.75)) (<= moveAng (* pi 1.25)))
                       (setq movePt (list (car bMin) (cadr insPt) 0.0)))
                      ((and (> moveAng (* pi 1.25)) (<= moveAng (* pi 1.75)))
                       (setq movePt (list (car insPt) (cadr bMin) 0.0)))
                    )
                    (command "_.MOVE" doorEnt "" "_non" movePt "_non" ptTarget)
                  )
                )
                (setq i (1+ i))
              )
              (princ "\n[완료] 문을 코너에 맞춰 정렬했습니다.")
            )
            (princ "\n문을 선택하지 않았습니다.")
          )
        )
        (princ "\n벽선을 선택하지 않았습니다.")
      )
    )
  )
  
  ;; 종료 전 시스템 변수 원상복구
  (setvar "CMDECHO" old_cmdecho)
  (princ)
)