;;; ==============================================================================
;;;  G1 · G2 · G3 — 그룹 단위로 숨기기 · 다시 보이기
;;;
;;;  G1 = 고른 객체가 든 그룹(그룹의 객체 전부)을 숨김
;;;  G2 = 지금 공간의 모든 그룹을 숨김
;;;  G3 = 숨긴 것을 모두 다시 보이기 (UNISOLATEOBJECTS)
;;;
;;;  숨기기는 캐드 기본 HIDEOBJECTS 를 쓴다 — 도면에 저장되지 않고(닫았다 열면 다 보임), 상태 막대에 격리 표시가 켜진다.
;;;  G3 · 8 · UNISOLATEOBJECTS 는 같은 것을 되살린다 (블록 6·7 로 숨긴 것도 함께).
;;;  예전 판(1.0)으로 숨겨 도면에 저장된 그룹 객체도 G3 가 다시 보이게 한다 (잠긴 레이어의 것은 빼고 알림).
;;; ==============================================================================

;; 지금 공간 이름 (배치 탭의 뷰포트 안이면 모형)
(defun g123:space ()
  (if (or (= (getvar "TILEMODE") 1) (/= (getvar "CVPORT") 1)) "Model" (getvar "CTAB")))

;; 그룹 모음 → ((그룹 객체 . (멤버 이름 …)) …)
(defun g123:groups ( / out mem)
  (vlax-for g (vla-get-Groups (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setq mem nil)
    (vlax-for o g (setq mem (cons (vlax-vla-object->ename o) mem)))
    (setq out (cons (cons g mem) out)))
  out)

;; 멤버 목록 → 지금 공간에 있고 보이는 것만 선택 집합으로
(defun g123:hide (mem / ss sp n sv)
  (setq ss (ssadd) sp (strcase (g123:space)))
  (foreach e mem
    (if (and (entget e) (= (strcase (cdr (assoc 410 (entget e)))) sp) (/= (cdr (assoc 60 (entget e))) 1)
             (not (ssmemb e ss)))
      (ssadd e ss)))
  (setq n (sslength ss))
  (if (> n 0)
    (progn
      (setq sv (getvar "CMDECHO"))
      (setvar "CMDECHO" 0)
      (command "_.HIDEOBJECTS" ss "")
      (setvar "CMDECHO" sv)))
  n)

(defun g123:err (msg)
  (if g123_sv (setvar "CMDECHO" g123_sv))
  (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
    (princ (strcat "\n[오류] " msg)))
  (princ))

(defun c:G1 ( / *error* g123_sv ss mem n)
  (setq *error* g123:err g123_sv (getvar "CMDECHO"))
  (vl-load-com)
  (prompt "\n숨길 그룹의 객체를 고르세요: ")
  (if (setq ss (ssget))
    (progn
      (foreach g (g123:groups)
        (if (vl-some '(lambda (e) (ssmemb e ss)) (cdr g))
          (setq mem (append (cdr g) mem))))
      (cond
        ((null mem) (princ "\n고른 객체는 그룹에 들어 있지 않습니다."))
        ((= (setq n (g123:hide mem)) 0) (princ "\n그 그룹의 객체는 이미 숨겨져 있습니다."))
        (T (princ (strcat "\n[완료] 그룹 객체 " (itoa n) "개를 숨겼습니다. 다시 보이기: G3")))))
    (princ "\n고른 객체가 없습니다."))
  (princ))

(defun c:G2 ( / *error* g123_sv mem n)
  (setq *error* g123:err g123_sv (getvar "CMDECHO"))
  (vl-load-com)
  (foreach g (g123:groups) (setq mem (append (cdr g) mem)))
  (cond
    ((null mem) (princ "\n[알림] 도면에 그룹이 없습니다."))
    ((= (setq n (g123:hide mem)) 0) (princ "\n지금 공간에 숨길 그룹 객체가 없습니다."))
    (T (princ (strcat "\n[완료] 그룹 객체 " (itoa n) "개를 숨겼습니다. 다시 보이기: G3"))))
  (princ))

(defun c:G3 ( / *error* g123_sv n lk o)
  (setq *error* g123:err g123_sv (getvar "CMDECHO"))
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (command "_.UNISOLATEOBJECTS")
  (setvar "CMDECHO" g123_sv)
  ;; 예전 판이 도면에 저장한 숨김 (Visible 끔) 되살리기
  (setq n 0 lk 0)
  (foreach g (g123:groups)
    (foreach e (cdr g)
      (if (and (entget e) (= (cdr (assoc 60 (entget e))) 1))
        (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Visible (list (vlax-ename->vla-object e) :vlax-true)))
          (setq lk (1+ lk))
          (setq n (1+ n))))))
  (princ (strcat "\n[완료] 숨긴 객체를 모두 다시 보이게 했습니다"
                 (if (> n 0) (strcat " (예전 판으로 숨겨 저장된 그룹 객체 " (itoa n) "개 포함)") "")
                 "."
                 (if (> lk 0) (strcat "\n[주의] 잠긴 레이어의 숨은 객체 " (itoa lk) "개는 그대로입니다 (ULALL 뒤 다시 G3).") "")))
  (princ))

(princ)
