;;; ==========================================================================
;;; [단축키 6] 선택한 그룹만 숨기기 (유저 제공 초고속 로직 반영)
;;; ==========================================================================
(defun c:G1 (/ ss dict item grp_data mem_lst is_hit m vla_ent cnt)
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (princ "\n[단축키 6: 선택 그룹 숨기기] 숨길 그룹을 선택하세요.")

  (if (setq ss (ssget))
    (progn
      (setq dict (dictsearch (namedobjdict) "ACAD_GROUP"))
      (setq cnt 0)

      (if dict
        (foreach item dict
          (if (= (car item) 350)
            (progn
              (setq grp_data (entget (cdr item)))
              (setq mem_lst nil)
              
              ;; 그룹 멤버 추출
              (foreach data grp_data
                (if (= (car data) 340)
                  (setq mem_lst (cons (cdr data) mem_lst))
                )
              )

              ;; 선택 객체에 포함되는지 고속 판별
              (setq is_hit nil)
              (foreach m mem_lst
                (if (ssmemb m ss) (setq is_hit T))
              )

              ;; 포함되어 있다면 즉시 숨김
              (if is_hit
                (foreach m mem_lst
                  ;; 객체가 도면에 실제로 존재하는지 확인 (에러 방지)
                  (if (entget m)
                    (progn
                      (setq vla_ent (vlax-ename->vla-object m))
                      (if (= (vl-catch-all-apply 'vla-get-Visible (list vla_ent)) :vlax-true)
                        (progn
                          (vla-put-Visible vla_ent :vlax-false)
                          (setq cnt (1+ cnt))
                        )
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
      (if (> cnt 0)
        (princ (strcat "\n⚡ 처리 완료: 선택한 그룹 객체 [" (itoa cnt) "] 개 숨김."))
        (princ "\n선택한 객체 중 그룹이 없거나 이미 숨겨져 있습니다.")
      )
    )
  )
  (princ)
)

;;; ==========================================================================
;;; [단축키 7] 도면 내의 모든 그룹 숨기기
;;; ==========================================================================
(defun c:G2 (/ dict item grp_data m vla_ent cnt)
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (setq dict (dictsearch (namedobjdict) "ACAD_GROUP"))
  (setq cnt 0)

  (if dict
    (foreach item dict
      (if (= (car item) 350)
        (progn
          (setq grp_data (entget (cdr item)))
          (foreach data grp_data
            (if (= (car data) 340)
              (progn
                (setq m (cdr data))
                (if (entget m) ; 객체 존재 유무 확인
                  (progn
                    (setq vla_ent (vlax-ename->vla-object m))
                    (if (= (vl-catch-all-apply 'vla-get-Visible (list vla_ent)) :vlax-true)
                      (progn
                        (vla-put-Visible vla_ent :vlax-false)
                        (setq cnt (1+ cnt))
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    )
  )
  (princ (strcat "\n⚡ 쾌속 처리: 도면 내 모든 그룹 객체 [" (itoa cnt) "] 개 숨김 완료."))
  (princ)
)

;;; ==========================================================================
;;; [단축키 8] 숨겨진 모든 그룹 켜기 (복구)
;;; ==========================================================================
(defun c:G3 (/ dict item grp_data m vla_ent cnt)
  (vl-load-com)
  (setvar "CMDECHO" 0)
  (setq dict (dictsearch (namedobjdict) "ACAD_GROUP"))
  (setq cnt 0)

  (if dict
    (foreach item dict
      (if (= (car item) 350)
        (progn
          (setq grp_data (entget (cdr item)))
          (foreach data grp_data
            (if (= (car data) 340)
              (progn
                (setq m (cdr data))
                (if (entget m) ; 객체 존재 유무 확인
                  (progn
                    (setq vla_ent (vlax-ename->vla-object m))
                    ;; 보이지 않는(:vlax-false) 상태인 객체만 켜기
                    (if (= (vl-catch-all-apply 'vla-get-Visible (list vla_ent)) :vlax-false)
                      (progn
                        (vla-put-Visible vla_ent :vlax-true)
                        (setq cnt (1+ cnt))
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    )
  )
  (princ (strcat "\n💡 쾌속 처리: 숨겨졌던 모든 그룹 객체 [" (itoa cnt) "] 개 표시 완료."))
  (princ)
)