;;; ==============================================================================
;;;  ULALL — 모든 레이어 잠금 풀기
;;;  (LCANV 밑그림 레이어 · 격리 '잠금+흐리게'로 잠긴 레이어도 같이 풀린다)
;;; ==============================================================================

(defun c:ULALL ( / n)
  (vl-load-com)
  (setq n 0)
  (vlax-for L (vla-get-Layers (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (= (vla-get-Lock L) :vlax-true) (progn (vla-put-Lock L :vlax-false) (setq n (1+ n)))))
  (princ (if (> n 0) (strcat "\n[완료] 레이어 " (itoa n) "개의 잠금을 풀었습니다.") "\n[알림] 잠긴 레이어가 없습니다."))
  (princ))

(princ)
