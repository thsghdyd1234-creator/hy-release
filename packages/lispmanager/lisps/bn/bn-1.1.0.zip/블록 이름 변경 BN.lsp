;;; ==============================================================================
;;;  BN — 클릭한 블록의 이름 바꾸기
;;;
;;;  블록을 클릭하고 새 이름을 넣는다 (지금 이름이 함께 보이고, 공백 든 이름도 됨).
;;;  동적 블록은 원본 정의(EffectiveName)의 이름을 바꾼다 — 같은 블록의 모든 인스턴스가 함께 바뀐다.
;;;  대소문자만 바꾸는 것도 된다. 이름 없는 블록(*…)·외부 참조 안 블록(|)은 바꾸지 않는다.
;;; ==============================================================================

(defun c:BN ( / *error* doc undo_open sel o old new blk r)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n이름을 바꿀 블록을 클릭하세요: ")))
              (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n고른 블록이 없습니다."))
    ((/= (cdr (assoc 0 (entget (car sel)))) "INSERT") (princ "\n[주의] 블록이 아닙니다."))
    ((progn (setq o (vlax-ename->vla-object (car sel)) old (vla-get-EffectiveName o))
            (wcmatch old "`**,*|*"))
     (princ (strcat "\n[주의] [" old "] 은(는) 이름 없는 블록이거나 외부 참조 안의 블록이라 바꿀 수 없습니다.")))
    (T
     (setq new (getstring T (strcat "\n새 이름 (지금 [" old "]) <Enter = 그대로>: ")))
     (cond
       ((or (= new "") (= new old)) (princ "\n이름을 그대로 두었습니다."))
       ((not (snvalid new)) (princ (strcat "\n[주의] [" new "] 은(는) 블록 이름으로 쓸 수 없습니다 (< > / \\ \" : ; ? * | , = ` 는 안 됨).")))
       ((and (tblsearch "BLOCK" new) (/= (strcase new) (strcase old)))
        (princ (strcat "\n[주의] 도면에 이미 [" new "] 블록이 있습니다.")))
       (T
        (vla-StartUndoMark doc)
        (setq undo_open T
              blk (vla-Item (vla-get-Blocks doc) old)
              r (vl-catch-all-apply 'vla-put-Name (list blk new)))
        (vla-EndUndoMark doc)
        (setq undo_open nil)
        (if (and (not (vl-catch-all-error-p r)) (= (vla-get-Name blk) new))
          (princ (strcat "\n[완료] 블록 이름을 [" old "] 에서 [" new "] (으)로 바꿨습니다."))
          (princ (strcat "\n[주의] 이름을 바꾸지 못했습니다"
                         (if (vl-catch-all-error-p r) (strcat ": " (vl-catch-all-error-message r)) "") ".")))))))
  (princ))

(princ)
