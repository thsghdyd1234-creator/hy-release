(defun c:BN ( / sel ent blkName newName )
  (vl-load-com)
  
  ;; 1. 사용자에게 블록 선택 요청 (단일 객체만 선택되도록 설정)
  (prompt "\n이름을 변경할 블록을 선택하세요: ")
  (if (setq sel (ssget "_+.:E:S" '((0 . "INSERT"))))
    (progn
      ;; 2. 선택한 블록의 데이터 가져오기
      (setq ent (ssname sel 0))
      (setq blkName (cdr (assoc 2 (entget ent))))
      
      (princ (strcat "\n현재 블록 이름: [" blkName "]"))
      
      ;; 3. 새로운 블록 이름 입력받기
      (setq newName (getstring "\n새로운 블록 이름을 입력하세요: "))
      
      ;; 4. 이름 변경 실행 조건 확인
      (if (and newName (/= newName ""))
        (if (tblsearch "BLOCK" newName)
          ;; 이미 같은 이름의 블록이 도면에 있으면 중단
          (princ (strcat "\n[오류] 도면에 이미 [" newName "] 블록이 있습니다."))
          (progn
            ;; 캐드 -RENAME 명령으로 이름 변경 (명령창 표시 끔)
            (command "_.-RENAME" "_B" blkName newName)
            (princ (strcat "\n[완료] 블록 이름을 [" blkName "]에서 [" newName "](으)로 바꿨습니다."))
          )
        )
        (princ "\n[알림] 새 이름을 입력하지 않아 취소했습니다.")
      )
    )
    (princ "\n블록을 선택하지 않았거나 잘못된 객체를 선택했습니다.")
  )
  (princ)
)