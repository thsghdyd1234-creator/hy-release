;;; ============================================================
;;;  MLSP / MLX  - 도로 그리기 + 가로망 교차부 정리
;;;
;;;  [MLSP] 도로 그리기
;;;   직선(L)/곡선(S) : 다음 구간 모드 전환 (그리는 중에도)
;;;   반경(R)         : 직선 꺾임점 중심선 반경 (0 = 자동 — 폭에 맞춘 최소값)
;;;   완화(T)         : 클로소이드 완화곡선 길이 L (0 = 원호만, L = A^2 / R)
;;;   폭(W)           : 일반 다중선(차선 없음)으로 그리기
;;;   차로(N)         : 도로로 그리기 — 편도 차로 수/차로 폭/중앙분리대/여유폭 → 전체 폭 자동
;;;   되돌리기(U) / 닫기(C) 또는 첫 점 다시 클릭 = 순환도로 / 미리보기(V) 켜고 끄기
;;;   점 하나 찍을 때마다 확정 → 명령이 끝난 뒤 Ctrl+Z 한 번에 점 하나씩 되돌아감
;;;   Enter·스페이스·오른쪽 클릭 = 완료 + 교차부 자동 정리 (ESC 는 그린 데까지 남기고 정리는 안 함)
;;;   시작 전: 자리맞추기(J), 마감(C), 중심선 표시(E), 기존객체(X — 선·폴리선을 이어 도로로)
;;;
;;;  [도로 단면] 중앙분리대 > 편도 2차로 이상 황색 복선 > 편도 1차로 황색 단선,
;;;   차선 점선(중심선 거리 기준으로 모든 차로 정렬)·차도외측선을 자동으로 그림
;;;   레이어: ROAD_중앙선/중앙분리대/차선/차도외측선/정지선/노면표시
;;;   점선은 실제 짧은 폴리선으로 끊어 그림 (일러스트레이터로 넘기기 좋게)
;;;
;;;  [MLX] 가로망 교차부 정리
;;;   도로의 아무 부분이나(경계선·차선·중심선) 고르면 맞닿은 도로망 전체를 다시 그림:
;;;   교차부 안쪽 자르기 → 모서리 곡선필렛(F) / 가각전제(C) / 없음(N), 반경(R), 전제길이(D)
;;;   → 진입 차로 정지선 + 정지선 앞 실선 → 차선 점선. 노면표시(M)에서 치수 조정,
;;;   회전 화살표 자동 배치는 기본 꺼짐 (화살표는 RDS 로 놓기)
;;;
;;;  구조
;;;   - 중심선(경로)은 MLSP_CL 레이어(출력 안 함)에 남고 XDATA(MLSP)로
;;;     폭/자리맞추기/마감/중심선 표시/원래 레이어/편도 차로 수/차로 폭/분리대/여유폭을 저장
;;;   - 경계선·마감선·모서리·노면선은 생성물(XDATA MLSPG = 주인 중심선 핸들) → 다시 그릴 때 지우고 새로
;;;   - 도로 고치기 = 중심선을 고친 뒤 MLX
;;; ============================================================
(vl-load-com)

(or *mlsp-w*    (setq *mlsp-w*    200.0))
(or *mlsp-j*    (setq *mlsp-j*    "Zero"))
(or *mlsp-cap*  (setq *mlsp-cap*  "Yes"))
(or *mlsp-ctr*  (setq *mlsp-ctr*  "No"))
(or *mlsp-r*    (setq *mlsp-r*    1000.0))
(or *mlsp-ls*   (setq *mlsp-ls*   0.0))
(or *mlsp-mode* (setq *mlsp-mode* "Line"))
(or *mlsp-cm*   (setq *mlsp-cm*   "Fillet"))
(or *mlsp-cr*   (setq *mlsp-cr*   500.0))
(or *mlsp-cd*   (setq *mlsp-cd*   300.0))

;; ---- 도로 단면 (편도 차로 수 0 = 일반 다중선 모드) ----
(or *rd-lanes* (setq *rd-lanes* 0))        ; 편도 차로 수
(or *rd-lw*    (setq *rd-lw*    3500.0))   ; 차로 폭
(or *rd-med*   (setq *rd-med*   0.0))      ; 중앙분리대 폭 (0 = 황색 복선)
(or *rd-sh*    (setq *rd-sh*    500.0))    ; 차도외측선 ~ 도로 경계 여유폭
(or *rd-cg*    (setq *rd-cg*    300.0))    ; 황색 복선 간격
;; ---- 노면 표시 (표현용 기본값, MLX 노면(M)에서 변경) ----
(or *rd-sb*    (setq *rd-sb*    3000.0))   ; 정지선 후퇴: 교차 도로 경계에서
(or *rd-sl*    (setq *rd-sl*    30000.0))  ; 정지선 앞 차선 실선 구간
(or *rd-dd*    (setq *rd-dd*    3000.0))   ; 차선 점선 길이
(or *rd-dg*    (setq *rd-dg*    5000.0))   ; 차선 점선 간격
(or *rd-ad*    (setq *rd-ad*    5000.0))   ; 화살표 끝 ~ 정지선 거리
(or *rd-al*    (setq *rd-al*    5000.0))   ; 화살표 길이
(or *rd-stopfull* (setq *rd-stopfull* "No")) ; 정지선 양방향 전폭 여부
(or *rd-su*    (setq *rd-su*    3500.0))   ; 심볼 기준 크기 (차로폭 기준, 모든 도로 공통 — RDS 와 같이 씀)
(or *rd-autoarrow* (setq *rd-autoarrow* "No"))   ; 회전 화살표 자동 배치 (기본 끔 — 화살표는 RDS 로)
(setq *rd-pre* "ROAD_")                    ; 노면 표시 레이어 접두어
(or *mlsp-pv* (setq *mlsp-pv* "Yes"))      ; 그리는 중 실시간 미리보기

;;; ============================================================
;;;  유틸
;;; ============================================================
(defun mlsp:v- (a b) (mapcar '- a b))
(defun mlsp:v+ (a b) (mapcar '+ a b))
(defun mlsp:vx (v s) (mapcar '(lambda (x) (* x s)) v))
(defun mlsp:len (v) (sqrt (apply '+ (mapcar '* v v))))
(defun mlsp:unit (v / l)
  (setq l (mlsp:len v))
  (if (> l 1e-12) (mlsp:vx v (/ 1.0 l)) v))
(defun mlsp:dot (a b) (apply '+ (mapcar '* a b)))
(defun mlsp:cross2 (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
(defun mlsp:tan (a) (/ (sin a) (cos a)))
(defun mlsp:flat (p) (list (car p) (cadr p) *mlsp-z*))
(defun mlsp:lnorm (d) (list (- (cadr d)) (car d) 0.0))

(defun mlsp:doc () (vla-get-ActiveDocument (vlax-get-acad-object)))
(defun mlsp:ms () (vla-get-ModelSpace (mlsp:doc)))
(defun mlsp:clen (e) (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)))
(defun mlsp:handle (e) (cdr (assoc 5 (entget e))))

(defun mlsp:jname (j) (cond ((= j "Top") "위") ((= j "Bottom") "아래") (t "영")))
(defun mlsp:mname () (if (= *mlsp-mode* "Line") "직선" "곡선"))
(defun mlsp:cname ()
  (cond ((= *mlsp-cm* "Fillet")  (strcat "곡선필렛 R=" (rtos *mlsp-cr* 2 2)))
        ((= *mlsp-cm* "Chamfer") (strcat "가각전제 " (rtos *mlsp-cd* 2 2)))
        (t "없음")))

(defun mlsp:secname ()
  (if (> *rd-lanes* 0)
    (strcat "도로 - 편도 " (itoa *rd-lanes*) "차로(왕복 " (itoa (* 2 *rd-lanes*)) "차로) x " (rtos *rd-lw* 2 0)
            (if (> *rd-med* 0) (strcat ", 중분대 " (rtos *rd-med* 2 0)) ", 황색복선")
            ", 여유 " (rtos *rd-sh* 2 0))
    (strcat "일반 다중선 (폭 " (rtos *mlsp-w* 2 0) ")")))

(defun mlsp:status ()
  (princ (strcat "\n단면: " (mlsp:secname)))
  (princ (strcat "\n현재: 폭=" (rtos *mlsp-w* 2 2)
                 ", 반경=" (rtos *mlsp-r* 2 2)
                 ", 완화L=" (rtos *mlsp-ls* 2 2)
                 ", 모드=" (mlsp:mname)
                 ", 자리맞추기=" (mlsp:jname *mlsp-j*)
                 ", 마감=" (if (= *mlsp-cap* "Yes") "예" "아니오")
                 ", 중심선표시=" (if (= *mlsp-ctr* "Yes") "예" "아니오")))
  (princ))

;;; ---------- 레이어 / XDATA ----------
(defun mlsp:setup (/ ly)
  (if (not (tblsearch "APPID" "MLSP"))  (regapp "MLSP"))
  (if (not (tblsearch "APPID" "MLSPG")) (regapp "MLSPG"))
  (if (not (tblsearch "LAYER" "MLSP_CL"))
    (progn
      (setq ly (vla-Add (vla-get-Layers (mlsp:doc)) "MLSP_CL"))
      (vla-put-Color ly 8)
      (vla-put-Plottable ly :vlax-false))))

(defun mlsp:get-xd (e / x)
  (if (setq x (cadr (assoc -3 (entget e '("MLSP")))))
    (mapcar 'cdr (cdr x))))          ; (w j cap ctr layer lanes lw med sh)

(defun mlsp:gen-owner (e / x)
  (if (setq x (cadr (assoc -3 (entget e '("MLSPG")))))
    (cdr (assoc 1005 (cdr x)))))

;; 생성물 태그 (+ 복사로 딸려온 경로 XDATA 제거), 레이어 지정
(defun mlsp:fin (e own lay / o)
  (entmod (append (entget e)
                  (list (list -3 (list "MLSP") (cons "MLSPG" (list (cons 1005 own)))))))
  (if lay
    (progn (setq o (vlax-ename->vla-object e))
           (vla-put-Layer o lay)
           (vla-put-Color o 256)))
  e)

;; 경로 등록: 현재 설정을 XDATA로 저장하고 MLSP_CL 레이어로
(defun mlsp:register (pe / old lay o)
  (mlsp:setup)
  (mlsp:road-w)
  (setq old (mlsp:get-xd pe)
        lay (cdr (assoc 8 (entget pe))))
  (if (and old (= (strcase lay) "MLSP_CL")) (setq lay (nth 4 old)))
  (if (= (strcase lay) "MLSP_CL") (setq lay (getvar "CLAYER")))
  (entmod (append (entget pe)
                  (list (list -3 (list "MLSP"
                                       (cons 1040 *mlsp-w*)
                                       (cons 1000 *mlsp-j*)
                                       (cons 1070 (if (= *mlsp-cap* "Yes") 1 0))
                                       (cons 1070 (if (= *mlsp-ctr* "Yes") 1 0))
                                       (cons 1000 lay)
                                       (cons 1070 *rd-lanes*)
                                       (cons 1040 *rd-lw*)
                                       (cons 1040 *rd-med*)
                                       (cons 1040 *rd-sh*))))))
  (setq o (vlax-ename->vla-object pe))
  (vla-put-Layer o "MLSP_CL")
  (vla-put-Color o 256)
  pe)

;;; ---------- 오프셋 ----------
(defun mlsp:offset (obj d / r)
  (setq r (vl-catch-all-apply 'vla-Offset (list obj d)))
  (if (vl-catch-all-error-p r) nil
    (vlax-safearray->list (vlax-variant-value r))))

;; 양(+) 오프셋이 진행방향 왼쪽이면 1, 오른쪽이면 -1
(defun mlsp:leftsign (obj tst-d / e pm p0 d1 tst q)
  (setq e  (vlax-vla-object->ename obj)
        pm (/ (+ (vlax-curve-getStartParam e) (vlax-curve-getEndParam e)) 2.0)
        p0 (vlax-curve-getPointAtParam e pm)
        d1 (vlax-curve-getFirstDeriv e pm)
        tst (mlsp:offset obj tst-d))
  (if tst
    (progn
      (setq q (vlax-curve-getClosestPointTo (vlax-vla-object->ename (car tst)) p0))
      (foreach o tst (vla-Delete o))
      (if (> (mlsp:cross2 d1 (mlsp:v- q p0)) 0.0) 1 -1))
    1))

;; 왼쪽(+) 기준 횡방향 오프셋 목록
(defun mlsp:offs-of (w j)
  (cond ((= j "Top")    (list 0.0 (- w)))
        ((= j "Bottom") (list 0.0 w))
        (t (list (/ w 2.0) (/ w -2.0)))))

;;; ============================================================
;;;  경로 생성 (직선/곡선 혼합 + 원호/클로소이드)
;;; ============================================================
(defun mlsp:runs (pts modes / runs m pl)
  (setq pl (list (car pts)) m (car modes) pts (cdr pts))
  (foreach md modes
    (if (/= md m)
      (setq runs (cons (cons m (reverse pl)) runs)
            pl   (list (car pl))
            m    md))
    (setq pl (cons (car pts) pl) pts (cdr pts)))
  (reverse (cons (cons m (reverse pl)) runs)))

;; 클로소이드 로컬 좌표 (s = 0..ls, n등분), Simpson 적분
(defun mlsp:spiral (r ls n / c h x y out i s0 s1 sm)
  (setq c (/ 1.0 (* 2.0 r ls)) h (/ ls n) x 0.0 y 0.0 out (list '(0.0 0.0)) i 0)
  (repeat n
    (setq s0 (* i h) s1 (+ s0 h) sm (+ s0 (/ h 2.0)))
    (setq x (+ x (* (/ h 6.0) (+ (cos (* c s0 s0)) (* 4.0 (cos (* c sm sm))) (cos (* c s1 s1)))))
          y (+ y (* (/ h 6.0) (+ (sin (* c s0 s0)) (* 4.0 (sin (* c sm sm))) (sin (* c s1 s1))))))
    (setq out (cons (list x y) out) i (1+ i)))
  (reverse out))

;; 꺾임점 b 곡선 정점 목록 ((pt bulge) ...): 클로소이드-원호-클로소이드
(defun mlsp:vert-curve (b u1 u2 th sg r ls lim fmin / ths sp xs ys p k ts f n1 n2 tsp stp dc out fail)
  (if (> ls (* r th)) (setq ls (* r th)))             ; 2θs ≤ Δ
  (setq ths (/ ls (* 2.0 r)))
  (if (> ls 1e-9)
    (setq sp (mlsp:spiral r ls 24) xs (car (last sp)) ys (cadr (last sp)))
    (setq sp nil xs 0.0 ys 0.0))
  (setq p  (- ys (* r (- 1.0 (cos ths))))
        k  (- xs (* r (sin ths)))
        ts (+ (* (+ r p) (mlsp:tan (/ th 2.0))) k))
  (if (> ts lim)                                      ; 구간 부족 → 형상 비례 축소
    (setq f  (/ lim ts) ts lim *mlsp-shrunk* t
          sp (mapcar '(lambda (q) (mlsp:vx q f)) sp)
          fail (< (* r f) fmin)))                     ; 축소하면 안쪽이 뒤집힐 정도면 포기
  (setq n1  (mlsp:lnorm u1) n2 (mlsp:lnorm u2)
        tsp (mlsp:v- b (mlsp:vx u1 ts))
        stp (mlsp:v+ b (mlsp:vx u2 ts))
        dc  (- th (* 2.0 ths)))
  (if sp
    (progn
      (foreach q sp
        (setq out (cons (list (mlsp:v+ tsp (mlsp:v+ (mlsp:vx u1 (car q)) (mlsp:vx n1 (* sg (cadr q))))) 0.0) out)))
      (setq out (cons (list (car (car out)) (* sg (mlsp:tan (/ dc 4.0)))) (cdr out)))   ; SC→CS 원호
      (foreach q (reverse sp)
        (setq out (cons (list (mlsp:v+ stp (mlsp:v+ (mlsp:vx u2 (- (car q))) (mlsp:vx n2 (* sg (cadr q))))) 0.0) out))))
    (setq out (list (list stp 0.0) (list tsp (* sg (mlsp:tan (/ th 4.0)))))))
  (if fail nil (reverse out)))

;; 회전 안쪽으로 가장 먼 경계까지 거리
(defun mlsp:inner-off (sg / offs)
  (setq offs (mlsp:offs-of *mlsp-w* *mlsp-j*))
  (max 0.0 (if (> sg 0.0) (apply 'max offs) (- (apply 'min offs)))))

;; 자동 보정 최소 중심선 반경: 안쪽 경계 반경이 (안쪽 거리의 절반) 이상 남도록
;;  예) 폭 15m 도로 → 중심선 최소 11.25m, 안쪽 경계 최소 3.75m
;;  자리맞추기 위/아래로 경로 쪽으로 도는 경우도 최소한 둥글게 (전체 폭의 1/4)
(defun mlsp:rmin (sg)
  (max (* 1.5 (mlsp:inner-off sg)) (* 0.25 *mlsp-w*)))

;; 이보다 작으면 안쪽 경계가 뒤집힘
(defun mlsp:rflip (sg) (* 1.02 (mlsp:inner-off sg)))

(defun mlsp:fillet-run (pl r ls / n i a b c u1 u2 l1 l2 th sg re lim1 lim2 out vc)
  (setq n (length pl) out (list (list (car pl) 0.0)) i 1)
  (while (< i (1- n))
    (setq a  (nth (1- i) pl) b (nth i pl) c (nth (1+ i) pl)
          u1 (mlsp:unit (mlsp:v- b a))
          u2 (mlsp:unit (mlsp:v- c b))
          l1 (distance a b) l2 (distance b c)
          th (if (and (> l1 1e-9) (> l2 1e-9)) (atan (abs (mlsp:cross2 u1 u2)) (mlsp:dot u1 u2)) 0.0))
    (if (or (< l1 1e-9) (< l2 1e-9) (< th 1e-6) (> th (- pi 1e-6)))
      (setq out (cons (list b 0.0) out))
      (progn
        (setq sg (if (> (mlsp:cross2 u1 u2) 0.0) 1.0 -1.0)
              re (max r (mlsp:rmin sg)))
        (if (and (> r 0.0) (> re r)) (setq *mlsp-rclamp* t))
        (setq lim1 (if (= i 1) l1 (/ l1 2.0))
              lim2 (if (= i (- n 2)) l2 (/ l2 2.0))
              vc   (mlsp:vert-curve b u1 u2 th sg re ls (min lim1 lim2) (mlsp:rflip sg)))
        (if vc
          (setq out (append (reverse vc) out))
          (setq out (cons (list b 0.0) out) *mlsp-sharp* t))))
    (setq i (1+ i)))
  (reverse (cons (list (last pl) 0.0) out)))

(defun mlsp:dedup (vl / out)
  (foreach v vl
    (if (and out (equal (car v) (car (car out)) 1e-8))
      (setq out (cons v (cdr out)))
      (setq out (cons v out))))
  (reverse out))

(defun mlsp:mk-pline (vl closed)
  (setq vl (mlsp:dedup vl))
  (entmake
    (append
      (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 (getvar "CLAYER"))
            '(100 . "AcDbPolyline") (cons 90 (length vl)) (cons 70 (if closed 1 0)) (cons 38 *mlsp-z*))
      (apply 'append
        (mapcar '(lambda (v) (list (cons 10 (list (car (car v)) (cadr (car v))))
                                   (cons 42 (cadr v))))
                vl))))
  (entlast))

(defun mlsp:end-tan (p0 p1 p2)
  (if p2
    (mlsp:unit (mlsp:v- (mlsp:vx (mlsp:unit (mlsp:v- p1 p0)) 2.0)
                        (mlsp:unit (mlsp:v- p2 p0))))
    (mlsp:unit (mlsp:v- p1 p0))))

(defun mlsp:mk-spline (pl t0 t1 / arr)
  (setq arr (vlax-make-safearray vlax-vbDouble (cons 0 (1- (* 3 (length pl))))))
  (vlax-safearray-fill arr (apply 'append pl))
  (vlax-vla-object->ename
    (vla-AddSpline (mlsp:ms) arr (vlax-3d-point t0) (vlax-3d-point t1))))

;; 스플라인 → 점 목록 (방향 5도 이내로 촘촘히) 후 스플라인 삭제
(defun mlsp:spl->pts (e / pts)
  (setq pts (mlsp:sub-pts e 0.0 (mlsp:clen e)))
  (entdel e)
  pts)

;; 경로 생성: 직선 구간(반경·완화곡선)과 곡선 구간을 이어서 **폴리선 하나**로
;;  - JOIN을 쓰지 않으므로 조각으로 갈라져 생기는 가짜 교차로(정지선)가 없음
;;  - 폴리선 오프셋은 스플라인 오프셋보다 안정적 (경계선·차선 누락 방지)
(defun mlsp:build (pts modes / runs k m pl prev next pp np rp t0 t1 vl seg)
  (setq runs (mlsp:runs pts modes) k 0)
  (foreach run runs
    (setq m (car run) pl (cdr run)
          prev (if (> k 0) (nth (1- k) runs))
          next (nth (1+ k) runs))
    (if (= m "Line")
      (setq seg (mlsp:fillet-run pl *mlsp-r* *mlsp-ls*)
            vl  (append vl (if vl (cdr seg) seg)))
      (progn
        (setq rp (reverse pl))
        (setq t0 (if prev
                   (progn (setq pp (reverse (cdr prev)))
                          (mlsp:unit (mlsp:v- (car pp) (cadr pp))))
                   (mlsp:end-tan (car pl) (cadr pl) (caddr pl))))
        (setq t1 (if next
                   (progn (setq np (cdr next))
                          (mlsp:unit (mlsp:v- (cadr np) (car np))))
                   (mlsp:vx (mlsp:end-tan (car rp) (cadr rp) (caddr rp)) -1.0)))
        (setq seg (mapcar '(lambda (p) (list p 0.0)) (mlsp:spl->pts (mlsp:mk-spline pl t0 t1)))
              vl  (append vl (if vl (cdr seg) seg)))))
    (setq k (1+ k)))
  (list (mlsp:mk-pline vl nil)))

;; 닫힌 꺾은선 경로: 첫 구간 중간점에서 시작해 모든 꼭짓점을 곡선 처리
(defun mlsp:build-closed (pts / m vl)
  (setq m  (mlsp:v+ (car pts) (mlsp:vx (mlsp:v- (cadr pts) (car pts)) 0.25))   ; 이음매: 중간점 대신 1/4 지점
        vl (mlsp:fillet-run (append (list m) (cdr pts) (list m)) *mlsp-r* *mlsp-ls*))
  (mlsp:mk-pline (reverse (cdr (reverse vl))) t))

;; 끝점이 맞닿은 선분들을 꺾은선 사슬로 연결. 항목 = (layer p0 p1 ...)
;;  - 정확히 두 선만 만나는 점에서만 이어 붙임 (= 도로가 꺾이는 곳)
;;  - 세 갈래 이상 만나는 점(T·Y·十자)은 잇지 않고 각자 끝나게 → 교차로로 처리
(defun mlsp:chains (items / ends deg out cur found tol cp q)
  (setq tol 1e-4)
  (foreach it items
    (setq ends (cons (cadr it) (cons (last it) ends))))
  (defun mlsp:chain-deg (p / n)                         ; p에서 끝나는 선 개수
    (setq n 0)
    (foreach e ends (if (equal e p tol) (setq n (1+ n))))
    n)
  (while items
    (setq cur (car items) items (cdr items) found t)
    (while (and found (not (equal (cadr cur) (last cur) tol)))
      (setq found nil cp (cdr cur))
      (foreach it items
        (if (not found)
          (progn
            (setq q (cdr it))
            (cond
              ((and (equal (last cp) (car q) tol) (= (mlsp:chain-deg (last cp)) 2))
               (setq cp (append cp (cdr q)) found it))
              ((and (equal (last cp) (last q) tol) (= (mlsp:chain-deg (last cp)) 2))
               (setq cp (append cp (cdr (reverse q))) found it))
              ((and (equal (car cp) (last q) tol) (= (mlsp:chain-deg (car cp)) 2))
               (setq cp (append q (cdr cp)) found it))
              ((and (equal (car cp) (car q) tol) (= (mlsp:chain-deg (car cp)) 2))
               (setq cp (append (reverse q) (cdr cp)) found it))))))
      (if found
        (setq cur (cons (car cur) cp) items (vl-remove found items))))
    (setq out (cons cur out)))
  out)

(defun mlsp:uniq-pts (pts / out)
  (foreach p pts
    (if (not (and out (equal p (car out) 1e-6))) (setq out (cons p out))))
  (reverse out))

;; 기존 객체 → 도로 경로
;;  선/곡선 없는 폴리선: 연결해서 꺾임점마다 반경·완화곡선 적용 (원본 대체)
;;  스플라인/호/원/타원/곡선 폴리선: 그대로 경로로 등록
(defun mlsp:convert (ss / i e ed typ z pts items dels direct paths ch pe closed)
  (repeat (setq i (sslength ss))
    (setq e (ssname ss (setq i (1- i))) ed (entget e) typ (cdr (assoc 0 ed)))
    (cond
      ((= typ "LINE")
       (setq items (cons (list (cdr (assoc 8 ed)) (cdr (assoc 10 ed)) (cdr (assoc 11 ed))) items)
             dels  (cons e dels)))
      ((and (= typ "LWPOLYLINE")
            (not (vl-some '(lambda (x) (and (= (car x) 42) (/= (cdr x) 0.0))) ed)))
       (setq z   (if (assoc 38 ed) (cdr (assoc 38 ed)) 0.0)
             pts (mapcar '(lambda (x) (list (cadr x) (caddr x) z))
                         (vl-remove-if-not '(lambda (x) (= (car x) 10)) ed)))
       (if (= 1 (logand 1 (cdr (assoc 70 ed)))) (setq pts (append pts (list (car pts)))))
       (setq items (cons (cons (cdr (assoc 8 ed)) pts) items)
             dels  (cons e dels)))
      (t (setq direct (cons e direct)))))
  (setq *mlsp-shrunk* nil *mlsp-rclamp* nil *mlsp-sharp* nil)
  (foreach ch (mlsp:chains items)
    (setq *mlsp-z* (caddr (cadr ch))
          pts (mlsp:uniq-pts (mapcar 'mlsp:flat (cdr ch)))
          closed (and (> (length pts) 3) (equal (car pts) (last pts) 1e-4)))
    (if (> (length pts) 1)
      (progn
        (setq pe (if closed
                   (mlsp:build-closed pts)
                   (car (mlsp:build pts (mapcar '(lambda (x) "Line") (cdr pts))))))
        (vla-put-Layer (vlax-ename->vla-object pe) (car ch))
        (setq paths (cons (mlsp:register pe) paths)))))
  (foreach e dels (entdel e))
  (foreach e direct (setq paths (cons (mlsp:register e) paths)))
  (mlsp:net-run paths)                                ; 생성 + 교차부 정리 (맞닿은 기존 도로 포함)
  (if *mlsp-rclamp* (princ "\n[알림] 일부 꺾임점은 반경이 폭에 비해 작아 자동으로 키웠습니다."))
  (if *mlsp-shrunk* (princ "\n[알림] 일부 꺾임점은 구간이 짧아 곡선을 줄였습니다."))
  (if *mlsp-sharp*  (princ "\n[알림] 일부 꺾임점은 구간이 너무 짧아 곡선 대신 각지게 처리했습니다."))
  (princ (strcat "\n[완료] 도로 " (itoa (length paths)) "개로 바꿨습니다.")))

(defun mlsp:join (ents / e0 surv ce)
  (if (= (length ents) 1)
    (car ents)
    (progn
      (setq e0 (entlast) ce (getvar "CMDECHO"))
      (setvar "CMDECHO" 0)
      (vl-cmdf "_.JOIN")
      (foreach e ents (vl-cmdf e))
      (vl-cmdf "")
      (setvar "CMDECHO" ce)
      (setq surv (vl-remove-if-not 'entget ents))
      (if (not (eq e0 (entlast)))
        (setq surv (cons (entlast) (vl-remove (entlast) surv))))
      (if (= (length surv) 1) (car surv) nil))))

;;; ============================================================
;;;  도로 네트워크 생성 (MLSP / MLX 공용)
;;; ============================================================

;; 기존 생성물 삭제
(defun mlsp:del-gen (paths / hs ss i e)
  (setq hs (mapcar 'mlsp:handle paths))
  (if (setq ss (ssget "_X" '((-3 ("MLSPG")))))
    (repeat (setq i (sslength ss))
      (setq e (ssname ss (setq i (1- i))))
      (if (member (mlsp:gen-owner e) hs) (entdel e)))))

;; 닫힌 폴리선 → 시작=끝인 열린 폴리선 (같은 모양)
;;  닫힌 선은 BREAK가 "어느 쪽"을 지울지 예측이 안 돼서 교차부에서 엉뚱한 쪽이 통째로 사라짐
;;  → 순환도로의 경계선·노면선은 열어서 다룸 (모양은 그대로)
(defun mlsp:open-pl (e / ed vs bs)
  (setq ed (entget e))
  (if (and (= (cdr (assoc 0 ed)) "LWPOLYLINE") (= 1 (logand 1 (cdr (assoc 70 ed)))))
    (progn
      (foreach x ed
        (cond ((= (car x) 10) (setq vs (cons (cdr x) vs) bs (cons 0.0 bs)))
              ((= (car x) 42) (setq bs (cons (cdr x) (cdr bs))))))
      (setq vs (reverse vs) bs (reverse bs)
            vs (append vs (list (car vs)))
            bs (append bs (list 0.0)))
      (entmake
        (append
          (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (assoc 8 ed) '(100 . "AcDbPolyline")
                (cons 90 (length vs)) '(70 . 0)
                (cons 38 (if (assoc 38 ed) (cdr (assoc 38 ed)) 0.0)))
          (apply 'append (mapcar '(lambda (v b) (list (cons 10 v) (cons 42 b))) vs bs))))
      (entdel e)
      (entlast))
    e))

;; 경로 → 경계선 2개 (생성물)
(defun mlsp:gen-edges (pe dat / o lay own offs sgn out ok r)
  (setq o    (vlax-ename->vla-object pe)
        lay  (nth 4 dat)
        own  (mlsp:handle pe)
        offs (mlsp:offs-of (nth 0 dat) (nth 1 dat))
        sgn  (mlsp:leftsign o (max 1e-4 (/ (mlsp:clen pe) 1000.0)))
        ok   t)
  (foreach d offs
    (setq r (if (equal d 0.0 1e-9) (list (vla-Copy o)) (mlsp:offset o (* sgn d))))
    (if r
      (foreach ob r (setq out (cons (mlsp:fin (mlsp:open-pl (vlax-vla-object->ename ob)) own lay) out)))
      (setq ok nil)))
  (if ok (reverse out)
    (progn (foreach e out (entdel e)) nil)))

;; pt가 도로 pe의 폭 띠 안에 있는가 (offs: 왼쪽+ 횡방향)
;; ext: 도로 끝 너머로 띠를 연장하는 거리 (T자 교차로에서 끝이 주도로 중심에 물린 경우 등)
(defun mlsp:in-band (pt pe offs strict ext / tol cp par d1 v s lo hi)
  (setq tol 1e-4
        cp  (vlax-curve-getClosestPointTo pe pt)
        par (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list pe cp)))
  (if (or (null par) (vl-catch-all-error-p par))
    nil
    (progn
      (setq d1 (mlsp:unit (vlax-curve-getFirstDeriv pe par))
            v  (mlsp:v- pt cp)
            v  (list (car v) (cadr v) 0.0)
            s  (mlsp:cross2 d1 v)
            lo (apply 'min offs) hi (apply 'max offs))
      (and (<= (abs (mlsp:dot d1 v)) (+ (if ext ext 0.0) (max tol (* 1e-3 (mlsp:len v)))))   ; 도로 끝 바깥 제외
           (if strict
             (and (> s (+ lo tol)) (< s (- hi tol)))
             (and (>= s (- lo tol)) (<= s (+ hi tol))))))))

(defun mlsp:in-other-band (pt own roads strict extp / hit ownrd ext)
  (setq ownrd (assoc own roads)
        ext   (if (and extp ownrd) (mlsp:hw ownrd) 0.0))
  (foreach rd roads
    (if (and (not hit) (not (eq (car rd) own))
             (mlsp:in-band pt (car rd) (cadr rd) strict ext))
      (setq hit t)))
  hit)

(defun mlsp:ix-obj (o1 o2 mode / r out)
  (setq r (vl-catch-all-apply 'vlax-invoke (list o1 'IntersectWith o2 mode)))
  (if (and r (not (vl-catch-all-error-p r)))
    (while r
      (setq out (cons (list (car r) (cadr r) (caddr r)) out) r (cdddr r))))
  out)

(defun mlsp:ix (e f)
  (mlsp:ix-obj (vlax-ename->vla-object e) (vlax-ename->vla-object f) 0))

;; 곡선 pc를 두 점 사이에서 끊어 제거. 새로 생긴 조각 ename 반환
(defun mlsp:break-pts (pc p0 p1 / L d0 d1 tmp mid e0)
  (setq L  (mlsp:clen pc)
        d0 (vlax-curve-getDistAtPoint pc (vlax-curve-getClosestPointTo pc p0))
        d1 (vlax-curve-getDistAtPoint pc (vlax-curve-getClosestPointTo pc p1)))
  (if (and d0 d1)
    (progn
      (if (> d0 d1) (setq tmp d0 d0 d1 d1 tmp))
      (cond
        ((and (< d0 1e-6) (> d1 (- L 1e-6))) (entdel pc) nil)
        ((< (- d1 d0) 1e-6) nil)
        (t
         (setq p0   (vlax-curve-getPointAtDist pc d0)
               p1   (vlax-curve-getPointAtDist pc (min d1 L))
               mid  (vlax-curve-getPointAtDist pc (/ (+ d0 d1) 2.0))
               e0   (entlast))
         (vl-cmdf "_.BREAK" (list pc (trans mid 0 1)) "_F" (trans p0 0 1) (trans p1 0 1))
         (if (not (eq e0 (entlast))) (entlast)))))))

;; 경계선 e에서 다른 도로 띠 안에 들어간 구간 제거 → 남은 조각 목록
(defun mlsp:trim-edge (e own pts roads extp / L ds bnd i a b rng pcs pc nw)
  (setq L   (mlsp:clen e)
        ds  (vl-sort (vl-remove nil
                       (mapcar '(lambda (p) (vlax-curve-getDistAtPoint e (vlax-curve-getClosestPointTo e p))) pts))
                     '<)
        bnd (append (list 0.0) ds (list L))
        i   0)
  (while (< i (1- (length bnd)))
    (setq a (nth i bnd) b (nth (1+ i) bnd))
    (if (and (> (- b a) 1e-6)
             (mlsp:in-other-band (vlax-curve-getPointAtDist e (/ (+ a b) 2.0)) own roads t extp))
      (if (and rng (equal (cadr (car rng)) a 1e-6))
        (setq rng (cons (list (car (car rng)) b) (cdr rng)))
        (setq rng (cons (list a b) rng))))
    (setq i (1+ i)))
  ;; 끊기 전에 점으로 변환 (시작점, 끝점, 중간점)
  (setq rng (mapcar '(lambda (r) (list (vlax-curve-getPointAtDist e (car r))
                                       (vlax-curve-getPointAtDist e (cadr r))
                                       (vlax-curve-getPointAtDist e (/ (+ (car r) (cadr r)) 2.0))))
                    rng)
        pcs (list e))
  (foreach r rng
    (setq pc (vl-some '(lambda (z)
                         (if (and (entget z)
                                  (< (distance (caddr r) (vlax-curve-getClosestPointTo z (caddr r))) 1e-6))
                           z))
                      pcs))
    (if (and pc (setq nw (mlsp:break-pts pc (car r) (cadr r))))
      (setq pcs (cons nw pcs))))
  (setq pcs (vl-remove-if-not 'entget pcs))
  (foreach z pcs (mlsp:fin z (mlsp:handle own) nil))
  pcs)

;;; ---------- 모서리 ----------
(defun mlsp:tdir (e atstart)
  (if atstart
    (mlsp:unit (vlax-curve-getFirstDeriv e (vlax-curve-getStartParam e)))
    (mlsp:vx (mlsp:unit (vlax-curve-getFirstDeriv e (vlax-curve-getEndParam e))) -1.0)))

;; e를 r만큼, 상대 도로 방향(tdir) 쪽으로 오프셋한 임시 객체
(defun mlsp:side-off (e r x tdir / o res q)
  (setq o (vlax-ename->vla-object e))
  (foreach d (list r (- r))
    (if (and (null res) (setq res (mlsp:offset o d)))
      (progn
        (foreach x2 (cdr res) (vla-Delete x2))
        (setq res (car res)
              q   (vlax-curve-getClosestPointTo (vlax-vla-object->ename res) x))
        (if (<= (mlsp:dot (mlsp:v- q x) tdir) 0.0)
          (progn (vla-Delete res) (setq res nil))))))
  res)

(defun mlsp:corner-fillet (x e1 s1 e2 s2 r / t1 t2 o1 o2 pts c q1 q2 a1 a2 tmp)
  (setq t1 (mlsp:tdir e1 s1) t2 (mlsp:tdir e2 s2)
        o1 (mlsp:side-off e1 r x t2)
        o2 (mlsp:side-off e2 r x t1))
  (if (and o1 o2)
    (progn
      (setq pts (mlsp:ix-obj o1 o2 0))
      (if (null pts) (setq pts (mlsp:ix-obj o1 o2 3)))
      (setq c (car (vl-sort pts '(lambda (a b) (< (distance a x) (distance b x))))))))
  (if o1 (vla-Delete o1))
  (if o2 (vla-Delete o2))
  (if c
    (progn
      (setq q1 (vlax-curve-getClosestPointTo e1 c)
            q2 (vlax-curve-getClosestPointTo e2 c))
      (mlsp:break-pts e1 x q1)
      (mlsp:break-pts e2 x q2)
      (setq a1 (angle c q1) a2 (angle c q2))
      (if (> (rem (+ (- a2 a1) (* 4.0 pi)) (* 2.0 pi)) pi)
        (setq tmp a1 a1 a2 a2 tmp))
      (vlax-vla-object->ename
        (vla-AddArc (mlsp:ms) (vlax-3d-point c) (distance c q1) a1 a2)))
    (progn (princ "\n[주의] 모서리를 곡선으로 처리할 수 없습니다 (반경이 너무 크거나 구간이 짧음).") nil)))

(defun mlsp:corner-chamfer (x e1 s1 e2 s2 d / L1 L2 p1 p2)
  (setq L1 (mlsp:clen e1) L2 (mlsp:clen e2))
  (if (or (>= d L1) (>= d L2))
    (progn (princ "\n[주의] 가각을 자를 수 없습니다 (전제길이가 구간보다 김).") nil)
    (progn
      (setq p1 (vlax-curve-getPointAtDist e1 (if s1 d (- L1 d)))
            p2 (vlax-curve-getPointAtDist e2 (if s2 d (- L2 d))))
      (mlsp:break-pts e1 x p1)
      (mlsp:break-pts e2 x p2)
      (vlax-vla-object->ename
        (vla-AddLine (mlsp:ms) (vlax-3d-point p1) (vlax-3d-point p2))))))

;; pcs: ((ename owner-ename) ...)
(defun mlsp:corners (pcs / ends a b cs res)
  (foreach pp pcs
    (if (and (entget (car pp)) (not (vlax-curve-isClosed (car pp))))
      (setq ends (cons (list (vlax-curve-getStartPoint (car pp)) (car pp) (cadr pp) t)
                       (cons (list (vlax-curve-getEndPoint (car pp)) (car pp) (cadr pp) nil) ends)))))
  (while ends
    (setq a (car ends) ends (cdr ends)
          b (vl-remove-if-not
              '(lambda (z) (and (not (eq (caddr z) (caddr a)))
                                (< (distance (car z) (car a)) 1e-3)))
              ends))
    (if (= (length b) 1)
      (setq ends (vl-remove (car b) ends)
            cs   (cons (list a (car b)) cs))))
  (foreach c cs
    (setq a (car c) b (cadr c))
    (if (and (entget (cadr a)) (entget (cadr b)))
      (if (setq res (if (= *mlsp-cm* "Fillet")
                      (mlsp:corner-fillet (car a) (cadr a) (cadddr a) (cadr b) (cadddr b) *mlsp-cr*)
                      (mlsp:corner-chamfer (car a) (cadr a) (cadddr a) (cadr b) (cadddr b) *mlsp-cd*)))
        (mlsp:fin res (mlsp:handle (caddr a)) (nth 4 (mlsp:get-xd (caddr a))))))))

;;; ---------- 마감선 / 중심선 표시 ----------
(defun mlsp:line-e (p1 p2)
  (vlax-vla-object->ename (vla-AddLine (mlsp:ms) (vlax-3d-point p1) (vlax-3d-point p2))))

(defun mlsp:caps-center (rd roads / pe offs dat lay own lo hi p d n)
  (setq pe (car rd) offs (cadr rd) dat (cadddr rd)
        lay (nth 4 dat) own (mlsp:handle pe)
        lo (apply 'min offs) hi (apply 'max offs))
  (if (and (= (nth 2 dat) 1)
           (not (vlax-curve-isClosed pe))
           (not (equal (vlax-curve-getStartPoint pe) (vlax-curve-getEndPoint pe) 1e-6)))
    (foreach sp (list t nil)
      (setq p (if sp (vlax-curve-getStartPoint pe) (vlax-curve-getEndPoint pe))
            d (mlsp:unit (vlax-curve-getFirstDeriv pe
                           (if sp (vlax-curve-getStartParam pe) (vlax-curve-getEndParam pe))))
            n (mlsp:lnorm d))
      (if (not (mlsp:in-other-band p pe roads nil nil))     ; 다른 도로에 물린 끝은 마감 안 함
        (mlsp:fin (mlsp:line-e (mlsp:v+ p (mlsp:vx n lo)) (mlsp:v+ p (mlsp:vx n hi))) own lay))))
  (if (and (= (nth 3 dat) 1) (= (nth 1 dat) "Zero"))
    (mlsp:fin (vlax-vla-object->ename (vla-Copy (vlax-ename->vla-object pe))) own lay)))

;;; ============================================================
;;;  도로 단면 / 노면표시
;;; ============================================================
(defun mlsp:nz (x) (if x x 0))

;; 단면 → 전체 폭
(defun mlsp:road-w ()
  (if (> *rd-lanes* 0)
    (setq *mlsp-w* (+ *rd-med* (* 2.0 (+ (* *rd-lanes* *rd-lw*) *rd-sh*)))
          *mlsp-j* "Zero")))

(defun mlsp:rlay (kind / nm col ly)
  (setq nm  (strcat *rd-pre*
                    (cdr (assoc kind '(("YEL" . "중앙선") ("MED" . "중앙분리대") ("LANE" . "차선")
                                       ("EDGE" . "차도외측선") ("STOP" . "정지선") ("ARROW" . "노면표시")))))
        col (cdr (assoc kind '(("YEL" . 2) ("MED" . 3) ("LANE" . 7) ("EDGE" . 7) ("STOP" . 7) ("ARROW" . 7)))))
  (if (not (tblsearch "LAYER" nm))
    (progn (setq ly (vla-Add (vla-get-Layers (mlsp:doc)) nm))
           (vla-put-Color ly col)))
  nm)

(defun mlsp:poly (pts closed / z)
  (setq z (caddr (car pts)) pts (mlsp:uniq-pts pts))
  (entmake
    (append
      (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 (getvar "CLAYER"))
            '(100 . "AcDbPolyline") (cons 90 (length pts)) (cons 70 (if closed 1 0))
            (cons 38 (if z z 0.0)))
      (mapcar '(lambda (p) (cons 10 (list (car p) (cadr p)))) pts)))
  (entlast))

(defun mlsp:expand (offs d) (list (+ (apply 'max offs) d) (- (apply 'min offs) d)))
(defun mlsp:hw (rd) (max (abs (apply 'min (cadr rd))) (abs (apply 'max (cadr rd)))))
;; 곡선 위 거리 (스플라인에서 getDistAtPoint가 nil을 주는 경우 대비)
(defun mlsp:dist-at (e p / cp d par)
  (setq cp (vlax-curve-getClosestPointTo e p)
        d  (vl-catch-all-apply 'vlax-curve-getDistAtPoint (list e cp)))
  (if (and d (not (vl-catch-all-error-p d)))
    d
    (progn
      (setq par (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list e cp)))
      (if (and par (not (vl-catch-all-error-p par)))
        (vlax-curve-getDistAtParam e par)
        (mlsp:dist-scan e cp)))))

;; 최후 수단: 샘플링 + 국소 탐색
(defun mlsp:dist-scan (e p / L n i best bd d a b m1 m2)
  (setq L (mlsp:clen e) n 400 i 0 bd 1e99)
  (repeat (1+ n)
    (setq d (distance p (vlax-curve-getPointAtDist e (* L (/ (float i) n)))))
    (if (< d bd) (setq bd d best i))
    (setq i (1+ i)))
  (setq a (* L (/ (float (max 0 (1- best))) n))
        b (* L (/ (float (min n (1+ best))) n)))
  (repeat 40
    (setq m1 (+ a (/ (- b a) 3.0)) m2 (- b (/ (- b a) 3.0)))
    (if (< (distance p (vlax-curve-getPointAtDist e m1)) (distance p (vlax-curve-getPointAtDist e m2)))
      (setq b m2) (setq a m1)))
  (/ (+ a b) 2.0))

(defun mlsp:tan-at (e s / L)
  (setq L (mlsp:clen e) s (max 0.0 (min s L)))
  (mlsp:unit (vlax-curve-getFirstDeriv e (vlax-curve-getParamAtDist e s))))

;; 단계별 오류 격리: 한 단계가 실패해도 나머지는 계속, 원인은 출력
(defun mlsp:safe (fn args label / r)
  (setq r (vl-catch-all-apply fn args))
  (if (vl-catch-all-error-p r)
    (progn (princ (strcat "\n[오류] " label " 단계: " (vl-catch-all-error-message r))) nil)
    r))
(defun mlsp:closed-p (e)
  (or (vlax-curve-isClosed e)
      (equal (vlax-curve-getStartPoint e) (vlax-curve-getEndPoint e) 1e-6)))

;; 경로에서 단면대로 노면 선 생성 → ((ename kind path) ...)
(defun mlsp:gen-marks (pe dat / lanes lw med sh c0 o sgn own lst out r k)
  (setq lanes (mlsp:nz (nth 5 dat)) lw (nth 6 dat) med (nth 7 dat) sh (nth 8 dat)
        c0 (/ med 2.0) o (vlax-ename->vla-object pe) own (mlsp:handle pe)
        sgn (mlsp:leftsign o (max 1e-4 (/ (mlsp:clen pe) 1000.0))))
;; 중앙: 중앙분리대 > 편도 2차로 이상은 황색 복선 > 편도 1차로는 황색 단선
  ;;  (도로교통법 시행규칙 별표 6: 중앙분리대 없는 편도 2차로 이상 도로 중앙에 황색 복선)
  (setq lst (cond ((> med 0)     (list (list c0 "MED") (list (- c0) "MED")))
                  ((>= lanes 2)  (list (list (/ *rd-cg* 2.0) "YEL") (list (/ *rd-cg* -2.0) "YEL")))
                  (t             (list (list 0.0 "YEL")))))
  (setq k 1)
  (while (< k lanes)
    (setq lst (append lst (list (list (+ c0 (* k lw)) "LANE") (list (- (+ c0 (* k lw))) "LANE")))
          k   (1+ k)))
  (if (> sh 0)
    (setq lst (append lst (list (list (+ c0 (* lanes lw)) "EDGE") (list (- (+ c0 (* lanes lw))) "EDGE")))))
  (foreach it lst
    (if (setq r (if (equal (car it) 0.0 1e-9) (list (vla-Copy o)) (mlsp:offset o (* sgn (car it)))))
      (foreach ob r                                   ; 오프셋이 여러 조각으로 나와도 전부 관리
        (setq out (cons (list (mlsp:fin (mlsp:open-pl (vlax-vla-object->ename ob)) own (mlsp:rlay (cadr it)))
                              (cadr it) pe (car it))
                        out)))))
  out)

;; 확장 띠 경계선 (임시, 노면선 자르기용)
(defun mlsp:band-curves (rd / o sgn out r)
  (setq o (vlax-ename->vla-object (car rd))
        sgn (mlsp:leftsign o (max 1e-4 (/ (mlsp:clen (car rd)) 1000.0))))
  (foreach d (cadr rd)
    (if (setq r (mlsp:offset o (* sgn d)))
      (setq out (append (mapcar 'vlax-vla-object->ename r) out))))
  out)

(defun mlsp:ang (u v) (abs (atan (mlsp:cross2 u v) (mlsp:dot u v))))

;; 차선의 실제 선(오프셋 결과) e 위 거리 u ↔ 중심선 거리 s 대응표 ((u . s) ...)
;;  차선 모양은 AutoCAD 오프셋이 정리한 그대로 쓰고(모서리 안쪽 겹침 없음),
;;  점선 위치만 중심선 거리로 맞춤 → 모든 차로 정렬 유지
(defun mlsp:umap (e pe / Le Lp cl step u h t0 s prev add tab)
  (setq Le (mlsp:clen e) Lp (mlsp:clen pe) cl (mlsp:closed-p pe)
        step (max 1e-3 (min (* 0.25 *rd-dd*) (/ Le 2.0)))
        u 0.0 add 0.0
        prev (mlsp:dist-at pe (vlax-curve-getPointAtDist e 0.0))
        tab (list (cons 0.0 prev)))
  (while (< u (- Le 1e-6))
    (setq h (min step (- Le u)) t0 (mlsp:tan-at e u))
    (while (and (> h 1e-3) (> (mlsp:ang t0 (mlsp:tan-at e (+ u h))) 0.087))
      (setq h (/ h 2.0)))
    (setq u (+ u h) s (+ add (mlsp:dist-at pe (vlax-curve-getPointAtDist e u))))
    (if cl                                            ; 순환도로 이음매 넘어갈 때 거리 이어붙이기
      (cond ((< s (- prev (/ Lp 2.0))) (setq add (+ add Lp) s (+ s Lp)))
            ((> s (+ prev (/ Lp 2.0))) (setq add (- add Lp) s (- s Lp)))))
    (setq prev s tab (cons (cons u s) tab)))
  (reverse tab))

;; 중심선 거리 sv → 차선 위 거리 u
(defun mlsp:u-at (tab sv / r a b)
  (while (and (cdr tab) (null r))
    (setq a (car tab) b (cadr tab))
    (if (or (and (<= (cdr a) sv) (<= sv (cdr b)))
            (and (>= (cdr a) sv) (>= sv (cdr b))))
      (setq r (if (equal (cdr a) (cdr b) 1e-9)
                (car a)
                (+ (car a) (* (- (car b) (car a)) (/ (- sv (cdr a)) (- (cdr b) (cdr a))))))))
    (setq tab (cdr tab)))
  r)

;; 차선 e의 u0~u1 부분 점 목록 (꺾이는 곳은 촘촘히)
(defun mlsp:sub-pts (e u0 u1 / tmp step u h t0 pts)
  (if (> u0 u1) (setq tmp u0 u0 u1 u1 tmp))
  (setq step (max 1e-3 (min (* 0.5 *rd-dd*) (- u1 u0)))
        u u0 pts (list (vlax-curve-getPointAtDist e u0)))
  (while (< u (- u1 1e-6))
    (setq h (min step (- u1 u)) t0 (mlsp:tan-at e u))
    (while (and (> h 1e-3) (> (mlsp:ang t0 (mlsp:tan-at e (+ u h))) 0.087))
      (setq h (/ h 2.0)))
    (setq u (+ u h) pts (cons (vlax-curve-getPointAtDist e u) pts)))
  (reverse pts))

;; 중심선 거리 sa~sb 구간을 차선 e 위에 그림
(defun mlsp:seg (e tab sa sb own lay / u0 u1)
  (setq u0 (mlsp:u-at tab sa) u1 (mlsp:u-at tab sb))
  (if (and u0 u1 (> (abs (- u1 u0)) 1e-6))
    (mlsp:fin (mlsp:poly (mlsp:sub-pts e u0 u1) nil) own lay)))

;; a~b 구간 점선 (중심선 거리 기준 공통 패턴 → 모든 차로 정렬)
;;  차선 위 실제 길이가 20% 넘게 늘거나 줄어드는 점선(급한 모서리 걸침)은 생략
(defun mlsp:dash-range (e tab a b own lay / p k ds de u0 u1)
  (setq p (+ *rd-dd* *rd-dg*) k (fix (/ a p)))
  (if (< a 0) (setq k (1- k)))
  (while (< (setq ds (* k p)) b)
    (setq de (min (+ ds *rd-dd*) b) ds (max ds a))
    (if (>= (- de ds) (* 0.5 *rd-dd*))
      (progn
        (setq u0 (mlsp:u-at tab ds) u1 (mlsp:u-at tab de))
        (if (and u0 u1 (< (abs (- (/ (abs (- u1 u0)) (- de ds)) 1.0)) 0.35))
          (mlsp:fin (mlsp:poly (mlsp:sub-pts e u0 u1) nil) own lay))))
    (setq k (1+ k))))

;; 곡선 구간 점선: 차선 자체 길이 기준, 온전한 점선만 고르게 배치 (양끝 여백 균등)
(defun mlsp:dash-own (e tab sa sb own lay / u0 u1 tmp len n used u k)
  (setq u0 (mlsp:u-at tab sa) u1 (mlsp:u-at tab sb))
  (if (and u0 u1)
    (progn
      (if (> u0 u1) (setq tmp u0 u0 u1 u1 tmp))
      (setq len (- u1 u0)
            n   (fix (/ (+ len *rd-dg*) (+ *rd-dd* *rd-dg*))))
      (if (> n 0)
        (progn
          (setq used (- (* n (+ *rd-dd* *rd-dg*)) *rd-dg*)
                u (+ u0 (/ (- len used) 2.0)) k 0)
          (repeat n
            (mlsp:fin (mlsp:poly (mlsp:sub-pts e u (+ u *rd-dd*)) nil) own lay)
            (setq u (+ u *rd-dd* *rd-dg*))))))))

;; 비상용: 선 자체 길이 기준 점선 (정렬은 안 맞지만 항상 그려짐)
(defun mlsp:dash-simple (e own / lay L p u)
  (setq lay (cdr (assoc 8 (entget e))) L (mlsp:clen e) p (+ *rd-dd* *rd-dg*) u 0.0)
  (while (< u L)
    (if (>= (- (min (+ u *rd-dd*) L) u) (* 0.5 *rd-dd*))
      (mlsp:fin (mlsp:poly (mlsp:sub-pts e u (min (+ u *rd-dd*) L)) nil) own lay))
    (setq u (+ u p)))
  (entdel e))

;; 중심선에서 급하게 꺾이는 구간 찾기 → ((시작거리 끝거리) ...)
;;  기준: 곡률반경 < 도로 반폭의 1.6배 (자동 최소 반경 수준의 모서리. 일반 곡선 도로는 점선 유지)
(defun mlsp:corner-zones (pe hw / L step s s1 t0 t1 tight z0 zones)
  (setq L (mlsp:clen pe) step (max (/ hw 4.0) (/ L 3000.0)) s 0.0 t0 (mlsp:tan-at pe 0.0))
  (while (< s L)
    (setq s1 (min L (+ s step)) t1 (mlsp:tan-at pe s1)
          tight (> (* hw (/ (mlsp:ang t0 t1) (max 1e-9 (- s1 s)))) 0.62))
    (cond ((and tight (null z0)) (setq z0 s))
          ((and (not tight) z0) (setq zones (cons (list z0 s (mlsp:zkind z0 s hw)) zones) z0 nil)))
    (setq s s1 t0 t1))
  (if z0 (setq zones (cons (list z0 L (mlsp:zkind z0 L hw)) zones)))
  (reverse zones))

;; 꺾임 구간 종류: 아주 짧으면(각진 꼭짓점) sharp, 아니면 둥근 곡선 curve
(defun mlsp:zkind (a b hw) (if (< (- b a) (* 0.6 hw)) 'sharp 'curve))

;; 차선 → 점선
;;  - 진입 차로 실선 구간(solids): 정지선 앞, 진입 쪽 차선만
;;  - 꺾이는 구간(zones): 모서리를 따라 ㄱ자로 이어진 차선 한 토막 + 앞뒤 간격
;;  - 나머지: 중심선 거리 기준 공통 점선 패턴 (모든 차로 정렬)
(defun mlsp:dashify (e pe lat solids zones / lay own tab lo hi side rngs mg cur a b r)
  (setq lay (cdr (assoc 8 (entget e))) own (mlsp:handle pe)
        tab (mlsp:umap e pe)
        lo  (apply 'min (mapcar 'cdr tab))
        hi  (apply 'max (mapcar 'cdr tab))
        side (if (> lat 0) 1 -1))
  (if (> (- hi lo) 1e-6)
    (progn
      ;; (시작 끝 앞간격? 뒤간격?)
      (foreach sd solids
        (if (and (eq (car sd) pe) (= (cadddr sd) side))
          (progn
            (setq a (max lo (cadr sd)) b (min hi (caddr sd)))
            (if (> (- b a) 1e-6) (setq rngs (cons (list a b nil nil 'solid) rngs))))))
      (foreach z zones
        (setq a (max lo (- (car z) *rd-dd*)) b (min hi (+ (cadr z) *rd-dd*)))
        (if (> (- b a) 1e-6)
          (setq rngs (cons (list a b t t (caddr z)) rngs))))
      ;; 정렬 + 겹치는 구간 병합
      (foreach r (vl-sort rngs '(lambda (x y) (< (car x) (car y))))
        (if (and mg (<= (car r) (cadr (car mg))))
          (setq mg (cons (list (car (car mg))
                               (max (cadr (car mg)) (cadr r))
                               (caddr (car mg))
                               (if (> (cadr r) (cadr (car mg))) (cadddr r) (cadddr (car mg)))
                               (if (member (nth 4 r) '(solid sharp)) (nth 4 r) (nth 4 (car mg))))
                         (cdr mg)))
          (setq mg (cons r mg))))
      (setq cur lo)
      (foreach r (reverse mg)
        (setq a (car r) b (cadr r))
        (mlsp:dash-range e tab cur (if (caddr r) (- a *rd-dg*) a) own lay)
        (if (> (- b (max cur a)) 1e-6)
          (if (eq (nth 4 r) 'curve)
            (mlsp:dash-own e tab (max cur a) b own lay)       ; 둥근 곡선: 고른 점선
            (mlsp:seg e tab (max cur a) b own lay)))          ; 실선 구간 / 날카로운 ㄱ자
        (setq cur (max cur (if (cadddr r) (+ b *rd-dg*) b))))
      (if (< cur hi) (mlsp:dash-range e tab cur hi own lay))
      (entdel e))))

;; 경로 pa를 sX에서 dir 방향으로 걸어 도로 B 확장 띠를 벗어나는 지점 (없으면 nil)
(defun mlsp:wrap (pa s / L)
  (if (mlsp:closed-p pa)
    (progn (setq L (mlsp:clen pa)) (- s (* L (fix (/ (if (< s 0) (- s L) s) L)))))
    s))

(defun mlsp:exit-st (pa sX dir rdB ext / L offs step lo hi s n cl)
  (setq L (mlsp:clen pa) cl (mlsp:closed-p pa) offs (mlsp:expand (cadr rdB) *rd-sb*)
        step (* 0.25 (+ (mlsp:hw rdB) *rd-sb*)) lo sX n 0)
  (while (and (null hi) (< n 400))
    (setq s (+ lo (* dir step)) n (1+ n))
    (cond ((and (not cl) (or (< s 0.0) (> s L))) (setq hi 'end))
          ((mlsp:in-band (vlax-curve-getPointAtDist pa (mlsp:wrap pa s)) (car rdB) offs nil ext) (setq lo s))
          (t (setq hi s))))
  (if (and hi (not (eq hi 'end)))
    (progn
      (repeat 40
        (setq s (/ (+ lo hi) 2.0))
        (if (mlsp:in-band (vlax-curve-getPointAtDist pa (mlsp:wrap pa s)) (car rdB) offs nil ext)
          (setq lo s) (setq hi s)))
      (mlsp:wrap pa (/ (+ lo hi) 2.0)))))

;; 차로별 진행 방향 배정 (안쪽 차로부터) → ((좌 직 우) ...)
(defun mlsp:lane-moves (n l s r / inner outer mid out k)
  (if (= n 1)
    (list (list l s r))
    (progn
      (setq inner (cond (l (list t nil nil)) (s (list nil t nil)) (t (list nil nil r)))
            outer (cond (r (list nil s t)) (s (list nil t nil)) (t (list l nil nil)))
            mid   (cond (s (list nil t nil)) (l (list t nil nil)) (t (list nil nil r)))
            out   (list inner) k 2)
      (while (< k n) (setq out (cons mid out) k (1+ k)))
      (reverse (cons outer out)))))

;; 원호 점 목록 (cx,cy 중심, a0→a1, n등분)
(defun mlsp:arcpts (cx cy r a0 a1 n / out i a)
  (setq i 0)
  (repeat (1+ n)
    (setq a (+ a0 (* (- a1 a0) (/ (float i) n)))
          out (cons (list (+ cx (* r (cos a))) (+ cy (* r (sin a)))) out)
          i (1+ i)))
  (reverse out))

;; 화살표 외곽선 (로컬: +x 진행, +y 왼쪽) - 좌/직/우 조합을 한 덩어리 닫힌 선으로
;;  u: 심볼 기준 단위(차로폭 기준), la: 화살표 길이
;;  - 줄기 폭·머리 크기는 모든 종류가 동일 (스케일 통일)
;;  - 회전 화살표는 꺾이는 곳을 원호로 라운드 처리, 직진과 겹치는 곳은 갈라지는 형태
;;  - 모든 종류가 시작점(꼬리 끝)과 끝점(머리 끝)이 같은 위치 = 전체 길이 동일
(defun mlsp:arrow-local (l s r u la / sw hw hl rb yh xb xos x0 p a0 a1)
  ;; 회전 위치: 직진이 있으면 줄기 중간에서 갈라지고,
  ;;           회전만 있으면 머리 윗선이 직진 화살표 끝(la)과 같도록 꼬리를 늘림 → 모든 화살표 전체 길이 동일
  (setq sw (* 0.05 u) hw (* 0.15 u) hl (* 0.22 u) rb (* 0.12 u) yh (* 0.20 u)
        xb (if s (* 0.45 la) (- la rb hw))
        xos (+ xb (* 2.0 (sqrt (* rb sw))))
        x0  (+ xb (sqrt (- (* (+ rb sw) (+ rb sw)) (* rb rb))))
        p   (list (list 0.0 (- sw))))
  ;; 우회전 가지
  (if r
    (progn
      (setq p (append p
                (list (list xb (- sw)))
                (cdr (mlsp:arcpts xb (- rb) (- rb sw) (/ pi 2.0) 0.0 10))
                (list (list (- (+ xb rb) sw) (- yh)) (list (- (+ xb rb) hw) (- yh))
                      (list (+ xb rb) (- (+ yh hl)))
                      (list (+ xb rb hw) (- yh)) (list (+ xb rb sw) (- yh)) (list (+ xb rb sw) (- rb)))))
      (setq a1 (cond (s (atan (- rb sw) (- xos xb)))
                     (l (atan rb (- x0 xb)))
                     (t (/ pi 2.0))))
      (setq p (append p (cdr (mlsp:arcpts xb (- rb) (+ rb sw) 0.0 a1 10))))))
  ;; 직진 머리
  (if s
    (setq p (append p (list (list (- la hl) (- sw)) (list (- la hl) (- hw)) (list la 0.0)
                            (list (- la hl) hw) (list (- la hl) sw)))))
  ;; 좌회전 가지
  (if l
    (progn
      (setq a0 (cond (s (atan (- sw rb) (- xos xb)))
                     (r (atan (- rb) (- x0 xb)))
                     (t (setq p (append p (list (list xb (- sw))))) (/ pi -2.0))))
      (setq p (append p
                (mlsp:arcpts xb rb (+ rb sw) a0 0.0 10)
                (list (list (+ xb rb sw) yh) (list (+ xb rb hw) yh) (list (+ xb rb) (+ yh hl))
                      (list (- (+ xb rb) hw) yh) (list (- (+ xb rb) sw) yh) (list (- (+ xb rb) sw) rb))
                (cdr (mlsp:arcpts xb rb (- rb sw) 0.0 (/ pi -2.0) 10))))))
  (append p (list (list 0.0 sw))))

(defun mlsp:arrow (o f n mv lw own)
  (mlsp:fin
    (mlsp:poly (mapcar '(lambda (q) (mlsp:v+ o (mlsp:v+ (mlsp:vx f (car q)) (mlsp:vx n (cadr q)))))
                       (mlsp:arrow-local (car mv) (cadr mv) (caddr mv)
                                         (min lw *rd-su*)
                                         (* *rd-al* (/ (min lw *rd-su*) *rd-su*))))
               t)
    own (mlsp:rlay "ARROW")))

(defun mlsp:mark-line (p1 p2 own kind)
  (mlsp:fin (mlsp:line-e p1 p2) own (mlsp:rlay kind)))

;; 두 도로의 만나는 점 찾기 → ((A위의 점 B위의 점) ...)
;;  중심선끼리 교차 + 한 도로의 끝이 상대 도로 폭 안에 들어간 경우(중심선까지 안 닿아도)
(defun mlsp:junctions (rdA rdB / pa pb cand out lim)
  (setq pa (car rdA) pb (car rdB)
        lim (max (mlsp:hw rdA) (mlsp:hw rdB)))
  (foreach x (mlsp:ix pa pb) (setq cand (cons (list x x) cand)))
  (if (not (mlsp:closed-p pa))
    (foreach e (list (vlax-curve-getStartPoint pa) (vlax-curve-getEndPoint pa))
      (if (mlsp:in-band e pb (cadr rdB) nil nil)
        (setq cand (cons (list e (vlax-curve-getClosestPointTo pb e)) cand)))))
  (if (not (mlsp:closed-p pb))
    (foreach e (list (vlax-curve-getStartPoint pb) (vlax-curve-getEndPoint pb))
      (if (mlsp:in-band e pa (cadr rdA) nil nil)
        (setq cand (cons (list (vlax-curve-getClosestPointTo pa e) e) cand)))))
  (foreach c (reverse cand)            ; 같은 교차로 중복 제거 (중심선 교점 우선)
    (if (not (vl-some '(lambda (o) (< (distance (car o) (car c)) lim)) out))
      (setq out (cons c out))))
  out)

;; 교차로 접근부: 정지선 / 중분대 끝 / 회전 화살표
(defun mlsp:approach-one (rdA rdB xp dir / dat lanes lw med c0 cs pa pb own plen LB hwA
                                         sX sXB sP sB sl tA nl q fX tB legs a l s r k)
  (setq dat (cadddr rdA) lanes (mlsp:nz (nth 5 dat))
        pa (car rdA) pb (car rdB) own (mlsp:handle pa)
        lw (nth 6 dat) med (nth 7 dat) c0 (/ med 2.0)
        cs (cond ((> med 0) c0) ((>= lanes 2) (/ *rd-cg* 2.0)) (t 0.0))
        plen (mlsp:clen pa) LB (mlsp:clen pb) hwA (mlsp:hw rdA)
        sX (mlsp:dist-at pa (car xp)) sXB (mlsp:dist-at pb (cadr xp)))
  (if (setq sP (mlsp:exit-st pa sX dir rdB (+ hwA *rd-sb*)))
    (progn
      ;; 정지선 (진행 방향 오른쪽 = 진입 차로)
      (setq tA (mlsp:tan-at pa sP) nl (mlsp:lnorm tA)
            q  (vlax-curve-getPointAtDist pa sP))
      (mlsp:mark-line (mlsp:v+ q (mlsp:vx nl (* dir cs)))
                      (mlsp:v+ q (mlsp:vx nl (* dir (+ c0 (* lanes lw)))))
                      own "STOP")
      (if (= *rd-stopfull* "Yes")
        (mlsp:mark-line (mlsp:v- q (mlsp:vx nl (* dir cs)))
                        (mlsp:v- q (mlsp:vx nl (* dir (+ c0 (* lanes lw)))))
                        own "STOP"))
      (if (> med 0)
        (mlsp:mark-line (mlsp:v+ q (mlsp:vx nl c0)) (mlsp:v- q (mlsp:vx nl c0)) own "MED"))
      ;; 갈 수 있는 방향
      (setq fX (mlsp:vx (mlsp:tan-at pa sX) (- dir)) l nil s nil r nil)
      (if (mlsp:exit-st pa sX (- dir) rdB (+ hwA *rd-sb*)) (setq s t))
      (setq tB (mlsp:tan-at pb sXB) legs nil)
      (if (or (mlsp:closed-p pb) (> (- LB sXB) hwA)) (setq legs (cons tB legs)))
      (if (or (mlsp:closed-p pb) (> sXB hwA)) (setq legs (cons (mlsp:vx tB -1.0) legs)))
      ;; 상대 도로로 갈라지는 방향은 각도 크기가 아니라 "어느 쪽"인지로 판단
      ;;  (비스듬한 교차로에서 25도만 꺾여도 왼쪽으로 가면 좌회전 = 반대 차로를 가로지름)
      ;;  직진은 내 도로가 교차로 너머로 이어질 때. 내 도로가 끝나는 경우에만
      ;;  거의 일직선(20도 이내)으로 이어지는 가지를 직진으로 봄
      (foreach leg legs
        (setq a (atan (mlsp:cross2 fX leg) (mlsp:dot fX leg)))
        (cond ((> (abs a) (* 0.95 pi)) nil)                       ; 되돌아가는 방향
              ((and (not s) (< (abs a) (* pi (/ 20.0 180.0)))) (setq s t))
              ((> a 0.0) (setq l t))
              (t (setq r t))))
      ;; 화살표
      (setq sB (+ sP (* dir (+ *rd-ad* *rd-al*))))
      (if (and (= *rd-autoarrow* "Yes") (or l s r) (>= sB 0.0) (<= sB plen))
        (progn
          (setq tA (mlsp:tan-at pa sB) nl (mlsp:lnorm tA)
                q  (vlax-curve-getPointAtDist pa sB) k 1)
          (foreach mv (mlsp:lane-moves lanes l s r)
            (if (or (car mv) (cadr mv) (caddr mv))
              (mlsp:arrow (mlsp:v+ q (mlsp:vx nl (* dir (+ c0 (* (- k 0.5) lw)))))
                          (mlsp:vx tA (- dir)) (mlsp:lnorm (mlsp:vx tA (- dir)))
                          mv lw own))
            (setq k (1+ k)))))
      ;; 실선 구간: 정지선에서 진입 쪽으로 (도로 길이 30% 이내)
      (setq sl (min *rd-sl* (* 0.3 plen)))
      (list pa (min sP (+ sP (* dir sl))) (max sP (+ sP (* dir sl))) dir))))

;; 모든 접근부 처리 → 실선 구간 목록
(defun mlsp:approaches (roads / out res n)
  (setq n 0)
  (foreach rdA roads
    (if (> (mlsp:nz (nth 5 (cadddr rdA))) 0)
      (foreach rdB roads
        (if (not (eq (car rdB) (car rdA)))
          (foreach xp (mlsp:junctions rdA rdB)
            (foreach dir '(-1 1)
              (if (setq res (mlsp:safe 'mlsp:approach-one (list rdA rdB xp dir) "정지선·화살표"))
                (setq out (cons res out) n (1+ n)))))))))
  (princ (strcat "\n[알림] 정지선 " (itoa n) "곳을 그렸습니다."))
  out)

;; 메인: paths 재생성, corners=t 이면 교차부 처리
(defun mlsp:gen-net (paths corners / roads dat eds recs pts pcs net roadsX mks mpcs tmps solids czones)
  (mlsp:setup)
  (mlsp:del-gen paths)
  (foreach pe paths
    (if (setq dat (mlsp:get-xd pe))
      (if (setq eds (mlsp:gen-edges pe dat))
        (setq roads (cons (list pe (mlsp:offs-of (nth 0 dat) (nth 1 dat)) eds dat) roads))
        (princ "\n[주의] 오프셋할 수 없는 도로 하나를 건너뛰었습니다 (폭이 곡률 반경보다 크거나 선이 스스로 교차)."))))
  (setq roads (reverse roads)
        net   (and corners (cdr roads)))
  ;; 노면 선
  (foreach rd roads
    (if (> (mlsp:nz (nth 5 (cadddr rd))) 0)
      (setq mks (append (mlsp:gen-marks (car rd) (cadddr rd)) mks))))
  (if net
    (progn
      (setq roadsX (mapcar '(lambda (rd) (list (car rd) (mlsp:expand (cadr rd) *rd-sb*) (caddr rd) (cadddr rd)))
                           roads))
      ;; 1) 경계선 교차점 수집 (자르기 전 원본 기준)
      (foreach rd roads
        (foreach e (caddr rd)
          (setq pts nil)
          (foreach rd2 roads
            (if (not (eq (car rd2) (car rd)))
              (foreach f (caddr rd2) (setq pts (append (mlsp:ix e f) pts)))))
          (setq recs (cons (list e (car rd) pts) recs))))
      ;; 2) 교차부 안쪽 잘라내기
      (foreach rc recs
        (foreach pc (mlsp:trim-edge (car rc) (cadr rc) (caddr rc) roads nil)
          (setq pcs (cons (list pc (cadr rc)) pcs))))
      ;; 3) 모서리
      (if (/= *mlsp-cm* "None") (mlsp:corners pcs))
      ;; 4) 노면 선: 교차 도로 + 정지선 후퇴 범위 안 잘라내기
      (if mks
        (progn
          (setq tmps (mapcar '(lambda (rd) (cons (car rd) (mlsp:band-curves rd))) roadsX))
          (foreach m mks
            (setq pts nil)
            (foreach tc tmps
              (if (not (eq (car tc) (caddr m)))
                (foreach c (cdr tc) (setq pts (append (mlsp:ix (car m) c) pts)))))
            (foreach pc (mlsp:trim-edge (car m) (caddr m) pts roadsX t)
              (setq mpcs (cons (list pc (cadr m) (caddr m) (cadddr m)) mpcs))))
          (foreach tc tmps (foreach c (cdr tc) (if (entget c) (entdel c))))
          (setq mks mpcs)))))
  ;; 정지선 / 화살표 → 진입 차로 실선 구간
  (if net (setq solids (mlsp:safe 'mlsp:approaches (list roads) "정지선·화살표")))
  ;; 차선 점선화 (선마다 오류 격리)
  (foreach m mks
    (if (and (= (cadr m) "LANE") (entget (car m)))
      (progn
        (if (not (assoc (caddr m) czones))
          (setq czones (cons (cons (caddr m)
                                   (mlsp:safe 'mlsp:corner-zones
                                              (list (caddr m) (mlsp:hw (assoc (caddr m) roads)))
                                              "모서리 탐색"))
                             czones)))
        (mlsp:safe 'mlsp:dashify
                   (list (car m) (caddr m) (cadddr m) solids (cdr (assoc (caddr m) czones)))
                   "차선 점선")
        ;; 위에서 처리되지 못하고 원래 실선이 남았으면 → 단순 점선
        (if (entget (car m))
          (mlsp:safe 'mlsp:dash-simple (list (car m) (mlsp:handle (caddr m))) "차선 단순 점선")))))
  (foreach rd roads (mlsp:caps-center rd roads))
  (princ))

;;; ---------- 교차부 정리 실행 (MLSP 그리기·기존객체 변환·MLX 공용) ----------
(defun mlsp:bbox (e pad / mn mx)
  (vla-GetBoundingBox (vlax-ename->vla-object e) 'mn 'mx)
  (list (mapcar '- (vlax-safearray->list mn) (list pad pad 0.0))
        (mapcar '+ (vlax-safearray->list mx) (list pad pad 0.0))))

(defun mlsp:bb-hit (a b)
  (and (<= (car (car a)) (car (cadr b))) (<= (car (car b)) (car (cadr a)))
       (<= (cadr (car a)) (cadr (cadr b))) (<= (cadr (car b)) (cadr (cadr a)))))

;; 대상 도로 + 맞닿을 수 있는 기존 도로들 (연결된 것끼리 계속 확장)
;;  이웃 도로도 재생성되므로, 그 이웃의 다른 교차부까지 같이 다시 정리해야 깨지지 않음
(defun mlsp:with-neighbors (paths / all ss i e bbs out queue cur bb)
  (if (setq ss (ssget "_X" '((-3 ("MLSP")))))
    (repeat (setq i (sslength ss))
      (setq e (ssname ss (setq i (1- i))))
      (setq all (cons (cons e (mlsp:bbox e (nth 0 (mlsp:get-xd e)))) all))))
  (setq out paths queue paths)
  (while queue
    (setq cur (car queue) queue (cdr queue)
          bb  (mlsp:bbox cur (nth 0 (mlsp:get-xd cur))))
    (foreach a all
      (if (and (not (member (car a) out)) (mlsp:bb-hit bb (cdr a)))
        (setq out (cons (car a) out) queue (append queue (list (car a)))))))
  out)

(defun mlsp:net-run (paths / os ce r all)
  (setq os (getvar "OSMODE") ce (getvar "CMDECHO")
        all (mlsp:with-neighbors (vl-remove-if-not 'entget paths)))
  (setvar "OSMODE" 0) (setvar "CMDECHO" 0)
  (setq r (vl-catch-all-apply 'mlsp:gen-net (list all t)))
  (setvar "OSMODE" os) (setvar "CMDECHO" ce)
  (if (vl-catch-all-error-p r)
    (princ (strcat "\n[오류] 교차부 정리: " (vl-catch-all-error-message r))))
  (length all))

;;; ============================================================
;;;  미리보기 / 옵션
;;; ============================================================
(defun mlsp:getnum (msg cur bits / v)
  (initget bits)
  (if (setq v (getdist (strcat msg " <" (rtos cur 2 2) ">: "))) v cur))

(defun mlsp:chk-r ()
  (princ))   ; 반경은 꺾임점마다 자동 보정되므로 별도 경고 없음

;; 차로(N) = 도로 모드 (차로 수 1부터), 폭(W) = 일반 다중선 모드
(defun mlsp:set-section (/ v)
  (if (< *rd-lanes* 1) (setq *rd-lanes* 1))
  (initget 6)                                           ; 0·음수 불가
  (if (setq v (getint (strcat "\n한 방향 차로 수 (편도 — 2 = 왕복 4차로) <" (itoa *rd-lanes*) ">: ")))
    (setq *rd-lanes* v))
  (if (> *rd-lanes* 0)
    (progn
      (setq *rd-lw*  (mlsp:getnum "\n차로 폭" *rd-lw* 6)
            *rd-med* (mlsp:getnum "\n중앙분리대 폭 (0=황색 복선)" *rd-med* 4))
      (if (= *rd-med* 0.0) (setq *rd-cg* (mlsp:getnum "\n황색 복선 간격" *rd-cg* 6)))
      (setq *rd-sh* (mlsp:getnum "\n외측 여유폭 (차도외측선~도로 경계, 0=외측선 없음)" *rd-sh* 4))
      (mlsp:road-w)
      (princ (strcat "\n[알림] 왕복 " (itoa (* 2 *rd-lanes*)) "차로, 도로 전체 폭 " (rtos *mlsp-w* 2 0)
                     "로 그립니다 (폭(W) 대신 이 값을 씁니다)."))
      (mlsp:chk-r))))

(defun mlsp:set-w ()
  (setq *mlsp-w* (mlsp:getnum "\n폭" *mlsp-w* 6))
  (if (> *rd-lanes* 0)
    (progn (setq *rd-lanes* 0)
           (princ "\n[알림] 일반 다중선으로 바꿨습니다 (차선 없음). 도로로 돌아가려면 차로(N)를 고르세요.")))
  (mlsp:chk-r))

(defun mlsp:set-just (/ k)
  (initget "Top Zero Bottom")
  (if (setq k (getkword (strcat "\n자리맞추기 [위(T)/영(Z)/아래(B)] <" (mlsp:jname *mlsp-j*) ">: ")))
    (setq *mlsp-j* k)))

(defun mlsp:set-yn (msg cur / k)
  (initget "Yes No")
  (if (setq k (getkword (strcat msg " [예(Y)/아니오(N)] <" (if (= cur "Yes") "예" "아니오") ">: ")))
    k cur))

;;; ============================================================
;;;  MLSP 그리기
;;; ============================================================
;;; ---------- 순환(닫힌) 경로 ----------
(defun mlsp:sub (l a b / out i)
  (setq i 0)
  (foreach x l
    (if (and (>= i a) (< i b)) (setq out (cons x out)))
    (setq i (1+ i)))
  (reverse out))

;; pts: p0 ... p(n-1) p0  /  modes: n개
(defun mlsp:build-loop (pts modes / n k ring t0 m)
  (setq n (length modes) ring (mlsp:sub pts 0 n))
  (cond
    ;; 전부 직선: 모든 꼭짓점 곡선 처리된 닫힌 폴리선
    ((not (member "Spline" modes)) (list (mlsp:build-closed pts)))
    ;; 전부 곡선: 이음매 접선을 앞뒤 점 방향으로 맞춘 닫힌 스플라인
    ((not (member "Line" modes))
     (setq t0 (mlsp:unit (mlsp:v- (cadr pts) (nth (1- n) pts))))
     (list (mlsp:mk-pline (mapcar '(lambda (p) (list p 0.0))
                                  (reverse (cdr (reverse (mlsp:spl->pts (mlsp:mk-spline pts t0 t0))))))
                          t)))
    ;; 혼합: 첫 직선 구간 중간점을 이음매로 삼아 열린 경로로 생성
    (t
     (setq k 0)
     (while (/= (nth k modes) "Line") (setq k (1+ k)))
     (setq m (mlsp:v+ (nth k pts) (mlsp:vx (mlsp:v- (nth (1+ k) pts) (nth k pts)) 0.25)))
     (mlsp:build (cons m (append (mlsp:sub ring (1+ k) n) (mlsp:sub ring 0 (1+ k)) (list m)))
                 (cons "Line" (append (mlsp:sub modes (1+ k) n) (mlsp:sub modes 0 k) (list "Line")))))))

;;; ---------- 실시간 미리보기 ----------
;; 볼록(bulge) 구간 → 점들
(defun mlsp:bulge-pts (p1 p2 b n / c m nl d r th a1 out i)
  (if (equal b 0.0 1e-9)
    (list p2)
    (progn
      (setq c  (distance p1 p2)
            m  (mlsp:vx (mlsp:v+ p1 p2) 0.5)
            nl (mlsp:lnorm (mlsp:unit (mlsp:v- p2 p1)))
            d  (* (/ c 2.0) (/ (- 1.0 (* b b)) (* 2.0 b)))
            m  (mlsp:v+ m (mlsp:vx nl d))                       ; 원 중심
            r  (distance m p1)
            th (* 4.0 (atan b))
            a1 (angle m p1) i 1)
      (repeat n
        (setq out (cons (list (+ (car m) (* r (cos (+ a1 (* th (/ (float i) n))))))
                              (+ (cadr m) (* r (sin (+ a1 (* th (/ (float i) n))))))
                              (caddr p1))
                        out)
              i (1+ i)))
      (reverse out))))

;; 3차 에르미트 곡선
(defun mlsp:herm (p0 p1 m0 m1 n / out i u h00 h10 h01 h11)
  (setq i 1)
  (repeat n
    (setq u (/ (float i) n)
          h00 (+ (* 2.0 u u u) (* -3.0 u u) 1.0)
          h10 (+ (* u u u) (* -2.0 u u) u)
          h01 (+ (* -2.0 u u u) (* 3.0 u u))
          h11 (- (* u u u) (* u u)))
    (setq out (cons (mapcar '(lambda (a b c d) (+ (* h00 a) (* h10 b) (* h01 c) (* h11 d))) p0 m0 p1 m1) out)
          i (1+ i)))
  (reverse out))

;; 미리보기용 중심선 점 목록 (최종 생성과 같은 규칙: 직선=반경/완화곡선, 곡선=접선 맞춤)
(defun mlsp:pv-center (pts modes / runs k m pl prev next pp np rp t0 t1 tn vl out i a b d)
  (setq runs (mlsp:runs pts modes) k 0 out (list (car pts)))
  (foreach run runs
    (setq m (car run) pl (cdr run)
          prev (if (> k 0) (nth (1- k) runs))
          next (nth (1+ k) runs))
    (if (= m "Line")
      (progn
        (setq vl (mlsp:dedup (mlsp:fillet-run pl *mlsp-r* *mlsp-ls*)) i 0)
        (setq out (append out (list (car (car vl)))))
        (while (< i (1- (length vl)))
          (setq out (append out (mlsp:bulge-pts (car (nth i vl)) (car (nth (1+ i) vl)) (cadr (nth i vl)) 8))
                i (1+ i))))
      (progn
        (setq rp (reverse pl))
        (setq t0 (if prev
                   (progn (setq pp (reverse (cdr prev))) (mlsp:unit (mlsp:v- (car pp) (cadr pp))))
                   (mlsp:end-tan (car pl) (cadr pl) (caddr pl))))
        (setq t1 (if next
                   (progn (setq np (cdr next)) (mlsp:unit (mlsp:v- (cadr np) (car np))))
                   (mlsp:vx (mlsp:end-tan (car rp) (cadr rp) (caddr rp)) -1.0)))
        ;; 점마다 접선
        (setq tn (list t0) i 1)
        (while (< i (1- (length pl)))
          (setq tn (append tn (list (mlsp:unit (mlsp:v+ (mlsp:unit (mlsp:v- (nth (1+ i) pl) (nth i pl)))
                                                       (mlsp:unit (mlsp:v- (nth i pl) (nth (1- i) pl)))))))
                i (1+ i)))
        (setq tn (append tn (list t1)) i 0)
        (while (< i (1- (length pl)))
          (setq a (nth i pl) b (nth (1+ i) pl) d (distance a b)
                out (append out (mlsp:herm a b (mlsp:vx (nth i tn) d) (mlsp:vx (nth (1+ i) tn) d) 16))
                i (1+ i)))))
    (setq k (1+ k)))
  (mlsp:uniq-pts out))

;; 미리보기 (grvecs 임시 표시): 중심선 노란색 + 도로 경계 하늘색
;;  경계는 중심선 점마다 앞뒤 방향 평균의 법선으로 띄움 (모서리에서도 끊기지 않게)
(defun mlsp:pv-draw (pts modes / cp offs nrm vec i n d0 d1)
  (if (cdr pts)
    (progn
      (setq cp (mlsp:pv-center pts modes) n (length cp)
            offs (vl-remove-if '(lambda (o) (equal o 0.0 1e-9)) (mlsp:offs-of *mlsp-w* *mlsp-j*))
            i 0)
      ;; 커서가 마지막 점 위에 있으면(방금 클릭 직후) 그릴 게 없음
      (if (< n 2) (setq n 0))
      ;; 점마다 법선
      (repeat n
        (setq d0 (if (> i 0) (mlsp:unit (mlsp:v- (nth i cp) (nth (1- i) cp))))
              d1 (if (< i (1- n)) (mlsp:unit (mlsp:v- (nth (1+ i) cp) (nth i cp))))
              nrm (cons (mlsp:lnorm (mlsp:unit (cond ((and d0 d1) (mlsp:v+ d0 d1)) (d0 d0) (d1 d1) (t '(1.0 0.0 0.0))))) nrm)
              i (1+ i)))
      (setq nrm (reverse nrm) i 0)
      (while (< i (1- n))
        (setq vec (append vec (list 2 (trans (nth i cp) 0 1) (trans (nth (1+ i) cp) 0 1))))
        (foreach o offs
          (setq vec (append vec (list 4 (trans (mlsp:v+ (nth i cp) (mlsp:vx (nth i nrm) o)) 0 1)
                                        (trans (mlsp:v+ (nth (1+ i) cp) (mlsp:vx (nth (1+ i) nrm) o)) 0 1)))))
        (setq i (1+ i)))
      (if vec (grvecs vec)))))

;;; ---- 미리보기 중 입력 보조: 스냅(마커 포함) / 직교 / 좌표 입력 ----
(defun mlsp:px () (/ (getvar "VIEWSIZE") (cadr (getvar "SCREENSIZE"))))   ; 화면 1픽셀 크기

;; 현재 OSMODE → 스냅 모드 목록 (근처점은 맨 뒤 = 최후 순위)
(defun mlsp:osmode-list (/ m lst)
  (setq m (getvar "OSMODE"))
  (if (and (> m 0) (= 0 (logand m 16384)))
    (foreach b '((1 . "_end") (2 . "_mid") (4 . "_cen") (8 . "_nod") (16 . "_qua") (32 . "_int")
                 (64 . "_ins") (128 . "_per") (2048 . "_app") (512 . "_nea"))
      (if (/= 0 (logand m (car b))) (setq lst (cons (cdr b) lst)))))
  (reverse lst))

;; 커서 p(UCS) 근처 스냅 → (점 . 모드) / nil
(defun mlsp:snap2 (p / ap best bd sp d)
  (setq ap (* 1.5 (getvar "APERTURE") (mlsp:px)) bd 1e99)
  (foreach md (mlsp:osmode-list)
    (if (and (or (null best) (/= md "_nea"))          ; 다른 스냅이 잡히면 근처점은 무시
             (setq sp (osnap p md))
             (< (setq d (distance (list (car p) (cadr p)) (list (car sp) (cadr sp)))) ap)
             (or (/= md "_nea") (null best))
             (< d bd))
      (setq bd d best (cons sp md))))
  best)

(defun mlsp:ring (pl / v i n)
  (setq i 0 n (length pl))
  (repeat n
    (setq v (append v (list 30 (nth i pl) (nth (rem (1+ i) n) pl))) i (1+ i)))
  v)

;; AutoCAD와 비슷한 모양의 스냅 마커
(defun mlsp:marker (c md s / x y z)
  (setq x (car c) y (cadr c) z (caddr c))
  (cond
    ((member md '("_end" "_ins"))
     (mlsp:ring (list (list (- x s) (- y s) z) (list (+ x s) (- y s) z) (list (+ x s) (+ y s) z) (list (- x s) (+ y s) z))))
    ((= md "_mid")
     (mlsp:ring (list (list (- x s) (- y s) z) (list (+ x s) (- y s) z) (list x (+ y s) z))))
    ((= md "_qua")
     (mlsp:ring (list (list x (- y s) z) (list (+ x s) y z) (list x (+ y s) z) (list (- x s) y z))))
    ((member md '("_cen" "_nod"))
     (mlsp:ring (mapcar '(lambda (a) (list (+ x (* s (cos a))) (+ y (* s (sin a))) z))
                        '(0.0 0.785 1.571 2.356 3.142 3.927 4.712 5.498))))
    ((= md "_nea")
     (mlsp:ring (list (list (- x s) (- y s) z) (list (+ x s) (+ y s) z) (list (- x s) (+ y s) z) (list (+ x s) (- y s) z))))
    ((= md "_per")
     (list 30 (list (- x s) (- y s) z) (list (+ x s) (- y s) z)
           30 (list (- x s) (- y s) z) (list (- x s) (+ y s) z)
           30 (list (- x s) y z) (list x y z)
           30 (list x y z) (list x (- y s) z)))
    (t (list 30 (list (- x s) (- y s) z) (list (+ x s) (+ y s) z)
             30 (list (- x s) (+ y s) z) (list (+ x s) (- y s) z)))))

;; 직교 모드 (F8) 반영
(defun mlsp:ortho (base p)
  (if (= 1 (getvar "ORTHOMODE"))
    (if (> (abs (- (car p) (car base))) (abs (- (cadr p) (cadr base))))
      (list (car p) (cadr base) (caddr base))
      (list (car base) (cadr p) (caddr base)))
    p))

;; 타이핑한 좌표 해석 (UCS): x,y / @dx,dy / @거리<각도 / 거리(커서 방향)
(defun mlsp:parse-input (buf lastu cur / rel b i x y d a)
  (setq rel (= (substr buf 1 1) "@") b (if rel (substr buf 2) buf))
  (cond
    ((setq i (vl-string-search "<" b))
     (setq d (distof (substr b 1 i)) a (angtof (substr b (+ i 2))))
     (if (and d a) (polar (if rel lastu (list 0.0 0.0 (caddr lastu))) a d)))
    ((setq i (vl-string-search "," b))
     (setq x (distof (substr b 1 i)) y (distof (substr b (+ i 2))))
     (if (and x y)
       (if rel
         (list (+ (car lastu) x) (+ (cadr lastu) y) (caddr lastu))
         (list x y (caddr lastu)))))
    ((and (not rel) cur (setq d (distof b)))
     (polar lastu (angle lastu cur) d))))

;; 미리보기하며 다음 점 받기 → UCS 점 / 키워드 문자열 / nil(완료)
(defun mlsp:pv-getpoint (pts modes msg / gr code val res done k cur hit buf lastu keymap)
  (setq lastu (trans (last pts) 0 1) buf ""
        keymap '(("L" . "Line") ("S" . "Spline") ("R" . "Radius") ("T" . "Transition")
                 ("W" . "Width") ("N" . "Nlane") ("U" . "Undo") ("C" . "Close") ("V" . "preView")))
  (princ msg)
  (while (not done)
    (setq gr (grread t 15 0) code (car gr) val (cadr gr))
    (cond
      ;; 마우스 이동: 중심선 미리보기 + 스냅 마커
      ((= code 5)
       (setq hit (mlsp:snap2 val)
             cur (if hit (car hit) (mlsp:ortho lastu val)))
       (redraw)
       (if (equal (mlsp:flat (trans cur 1 0)) (last pts) 1e-6)
         (mlsp:pv-draw pts modes)
         (mlsp:pv-draw (append pts (list (mlsp:flat (trans cur 1 0)))) (append modes (list *mlsp-mode*))))
       (if hit (grvecs (mlsp:marker (car hit) (cdr hit) (* 6.0 (mlsp:px))))))
      ;; 클릭
      ((= code 3)
       (setq *mlsp-kwjust* nil
             hit (mlsp:snap2 val)
             res (if hit (car hit) (mlsp:ortho lastu val))
             done t))
      ;; 우클릭 = 완료
      ((or (= code 11) (= code 25)) (setq res nil done t))
      ;; 키보드
      ((= code 2)
       (cond
         ;; 글자 키 직후의 Enter/Space는 무시 (AutoCAD 습관대로 "L + Enter"를 쳐도 완료되지 않게)
         ((and (member val '(13 32)) (= buf "") *mlsp-kwjust*)
          (setq *mlsp-kwjust* nil))
         ((member val '(13 32))
          (if (= buf "")
            (setq res nil done t)
            (if (setq res (mlsp:parse-input buf lastu cur))
              (setq done t)
              (progn (princ "\n[주의] 입력을 해석할 수 없습니다.") (princ msg) (setq buf "")))))
         ((= val 8)
          (if (> (strlen buf) 0)
            (progn (setq buf (substr buf 1 (1- (strlen buf)))) (princ (chr 8)) (princ " ") (princ (chr 8)))))
         ((or (and (>= val 48) (<= val 57)) (member val '(46 44 64 60 45)))
          (setq buf (strcat buf (chr val))) (princ (chr val)))
         ((and (= buf "") (setq k (cdr (assoc (strcase (chr val)) keymap))))
          ;; 값 입력이 따로 없는 즉시 적용 키만 표시 (반경·폭 등은 입력창이 Enter를 받음)
          (setq *mlsp-kwjust* (if (member k '("Line" "Spline" "Undo" "preView")) t nil)
                res k done t))
         (t (setq *mlsp-kwjust* nil))))))
  (redraw)
  res)

;;; ---------- 점마다 확정 (점 하나 = Ctrl+Z 한 번) ----------
(defun mlsp:step (doc) (vla-EndUndoMark doc) (vla-StartUndoMark doc))

(defun mlsp:commit (pts modes closed / ents e)
  (if *mlsp-cur*
    (progn
      (mlsp:del-gen (vl-remove-if-not 'entget *mlsp-cur*))
      (foreach x *mlsp-cur* (if (entget x) (entdel x)))))
  (setq *mlsp-cur* nil)
  (if (cdr pts)
    (progn
      (setq ents (if closed (mlsp:build-loop pts modes) (mlsp:build pts modes)))
      (if (setq e (mlsp:join ents))
        (setq *mlsp-cur* (list (mlsp:register e)))
        (progn
          (setq ents (vl-remove-if-not 'entget ents))
          (foreach x ents (mlsp:register x))
          (setq *mlsp-cur* ents)))
      (mlsp:gen-net *mlsp-cur* nil))))

(defun mlsp:draw (p0 doc / pts modes go pt closed msg)
  (setq *mlsp-cur* nil *mlsp-shrunk* nil *mlsp-rclamp* nil *mlsp-sharp* nil *mlsp-kwjust* nil
        *mlsp-z* (caddr (trans p0 1 0))
        pts (list (mlsp:flat (trans p0 1 0)))
        go t)
  (while go
    (setq msg (strcat "\n다음 점 <" (mlsp:mname) ", 폭 " (rtos *mlsp-w* 2 0)
                      ", R " (rtos *mlsp-r* 2 0) ", L " (rtos *mlsp-ls* 2 0)
                      "> [직선(L)/곡선(S)/반경(R)/완화(T)/폭(W)/차로(N)/되돌리기(U)/닫기(C)/미리보기(V)] <완료>: "))
    (if (= *mlsp-pv* "Yes")
      (setq pt (mlsp:pv-getpoint pts modes msg))
      (progn
        (initget "Line Spline Radius Transition Width Nlane Undo Close preView")
        (setq pt (getpoint (trans (last pts) 0 1) msg))
        (if (and (null pt) *mlsp-kwjust*) (setq pt "Nop"))   ; V 직후 Enter는 무시
        (setq *mlsp-kwjust* nil)))
    ;; 첫 점을 다시 찍으면 닫기
    (if (and (listp pt) pt (> (length pts) 2)
             (equal (mlsp:flat (trans pt 1 0)) (car pts) 1e-6))
      (setq pt "Close"))
    (cond
      ((null pt) (setq go nil))
      ((= pt "Line")   (setq *mlsp-mode* "Line"))
      ((= pt "Spline") (setq *mlsp-mode* "Spline"))
      ((= pt "preView")
       (setq *mlsp-pv* (if (= *mlsp-pv* "Yes") "No" "Yes"))
       (princ (if (= *mlsp-pv* "Yes")
                "\n[알림] 미리보기를 켰습니다 (스냅·직교·좌표 입력 가능 — 극좌표 추적은 V로 끄고 쓰세요)."
                "\n[알림] 미리보기를 껐습니다 (AutoCAD 기본 입력).")))
      ((= pt "Radius")
       (setq *mlsp-r* (mlsp:getnum "\n꺾임점 반경 (0=자동, 폭에 맞춰 최소값 보정)" *mlsp-r* 4))
       (mlsp:chk-r) (mlsp:step doc) (mlsp:commit pts modes nil))
      ((= pt "Transition")
       (setq *mlsp-ls* (mlsp:getnum "\n클로소이드 길이 L (0=원호만)" *mlsp-ls* 4))
       (mlsp:step doc) (mlsp:commit pts modes nil))
      ((= pt "Width")
       (mlsp:set-w) (mlsp:step doc) (mlsp:commit pts modes nil))
      ((= pt "Nlane")
       (mlsp:set-section) (mlsp:step doc) (mlsp:commit pts modes nil))
      ((= pt "Undo")
       (if (cdr pts)
         (progn
           (setq pts   (reverse (cdr (reverse pts)))
                 modes (reverse (cdr (reverse modes))))
           (mlsp:step doc) (mlsp:commit pts modes nil))
         (princ "\n[알림] 더 되돌릴 점이 없습니다.")))
      ((= pt "Close")
       (if (> (length pts) 2)
         (progn
           (setq pts   (append pts (list (car pts)))
                 modes (append modes (list *mlsp-mode*))
                 go nil)
           (mlsp:step doc) (mlsp:commit pts modes t))
         (princ "\n[알림] 닫으려면 점이 3개 이상 있어야 합니다.")))
      ((listp pt)
       (setq pt (mlsp:flat (trans pt 1 0)))
       (if (equal pt (last pts) 1e-8)
         (princ "\n[알림] 같은 점이라 건너뛰었습니다.")
         (progn
           (setq pts   (append pts (list pt))
                 modes (append modes (list *mlsp-mode*)))
           (mlsp:step doc) (mlsp:commit pts modes nil))))))
  (if *mlsp-rclamp* (princ "\n[알림] 일부 꺾임점은 입력 반경이 폭에 비해 작아 자동으로 키웠습니다."))
  (if *mlsp-shrunk* (princ "\n[알림] 일부 꺾임점은 구간이 짧아 곡선을 줄였습니다."))
  (if *mlsp-sharp*  (princ "\n[알림] 일부 꺾임점은 구간이 너무 짧아 곡선 대신 각지게 처리했습니다."))
  (if (vl-remove-if-not 'entget *mlsp-cur*)
    (progn (mlsp:step doc) (mlsp:net-run *mlsp-cur*)))
  (setq *mlsp-cur* nil))

(defun c:MLSP (/ *error* doc pt go ss i lst)
  (setq doc (mlsp:doc))
  (defun *error* (msg)
    ;; ESC: 마지막으로 확정된 형상은 그대로 둠
    (setq *mlsp-cur* nil)
    (if (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*BREAK*"))
      (princ (strcat "\n[오류] " msg)))
    (vla-EndUndoMark doc)
    (princ))
  (vla-StartUndoMark doc)
  (mlsp:setup)
  (mlsp:status)
  (setq go t)
  (while go
    (initget "Line Spline Radius Transition Width Nlane Justify Cap cEnter eXisting")
    (setq pt (getpoint (strcat "\n시작점 <" (mlsp:mname)
                               "> 또는 [직선(L)/곡선(S)/반경(R)/완화(T)/폭(W)/차로(N)/자리맞추기(J)/마감(C)/중심선(E)/기존객체(X)]: ")))
    (cond
      ((= pt "Line")       (setq *mlsp-mode* "Line"))
      ((= pt "Spline")     (setq *mlsp-mode* "Spline"))
      ((= pt "Radius")     (setq *mlsp-r* (mlsp:getnum "\n꺾임점 반경 (0=자동, 폭에 맞춰 최소값 보정)" *mlsp-r* 4)) (mlsp:chk-r))
      ((= pt "Transition") (setq *mlsp-ls* (mlsp:getnum "\n클로소이드 길이 L (0=원호만)" *mlsp-ls* 4)))
      ((= pt "Width")      (mlsp:set-w))
      ((= pt "Nlane")      (mlsp:set-section))
      ((= pt "Justify")    (mlsp:set-just))
      ((= pt "Cap")        (setq *mlsp-cap* (mlsp:set-yn "\n양끝 마감선" *mlsp-cap*)))
      ((= pt "cEnter")     (setq *mlsp-ctr* (mlsp:set-yn "\n중심선 표시 (영 자리맞추기)" *mlsp-ctr*)))
      ((= pt "eXisting")
       (princ "\n도로로 만들 객체를 선택하세요 (지금 폭·반경·완화곡선을 씀): ")
       (if (setq ss (ssget '((0 . "SPLINE,LWPOLYLINE,POLYLINE,ARC,LINE,CIRCLE,ELLIPSE"))))
         (mlsp:convert ss))
       (setq go nil))
      ((and pt (listp pt)) (mlsp:draw pt doc) (setq go nil))
      (t (setq go nil)))
    (if go (mlsp:status)))
  (vla-EndUndoMark doc)
  (princ))

;;; ============================================================
;;;  MLX 가로망 정리
;;; ============================================================
;; 선택 세트 → 도로 경로 목록
;;  경로 자체(MLSP XDATA) + 도로가 만든 생성물(MLSPG 태그 → 주인 경로)
;;  레이어가 아니라 태그로 판단: 경계선은 사용자 레이어에 있어서 레이어로는 구분 불가
(defun mlsp:paths-from-ss (ss / i e h pe out)
  (setq i 0)
  (repeat (sslength ss)
    (setq e (ssname ss i) i (1+ i) pe nil)
    (cond
      ((mlsp:get-xd e) (setq pe e))
      ((setq h (mlsp:gen-owner e))
       (setq pe (handent h))
       (if (not (and pe (entget pe) (mlsp:get-xd pe))) (setq pe nil))))
    (if (and pe (not (member pe out))) (setq out (cons pe out))))
  (reverse out))

(defun c:MLX (/ *error* doc os ce go k ss i paths undo_open)
  (setq doc (mlsp:doc) os (getvar "OSMODE") ce (getvar "CMDECHO"))
  (defun *error* (msg)
    (setvar "OSMODE" os) (setvar "CMDECHO" ce)
    (if (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*BREAK*"))
      (princ (strcat "\n[오류] " msg)))
    (if undo_open (vla-EndUndoMark doc))
    (princ))
  (mlsp:setup)
  (setq go t)
  (while go
    (princ (strcat "\n모서리 처리: " (mlsp:cname)))
    (initget "Fillet Chamfer None Radius Distance Marking")
    (setq k (getkword "\n옵션 [곡선필렛(F)/가각전제(C)/없음(N)/반경(R)/전제길이(D)/노면표시(M)] <도로 선택>: "))
    (cond
      ((null k) (setq go nil))
      ((member k '("Fillet" "Chamfer" "None")) (setq *mlsp-cm* k))
      ((= k "Radius")   (setq *mlsp-cr* (mlsp:getnum "\n모서리 곡선 반경" *mlsp-cr* 6)))
      ((= k "Distance") (setq *mlsp-cd* (mlsp:getnum "\n가각 전제길이 (교차점에서 각 경계선 따라)" *mlsp-cd* 6)))
      ((= k "Marking")
       (setq *rd-sb* (mlsp:getnum "\n정지선 후퇴 (교차 도로 경계에서)" *rd-sb* 4)
             *rd-sl* (mlsp:getnum "\n정지선 앞 차선 실선 구간 길이" *rd-sl* 4)
             *rd-dd* (mlsp:getnum "\n차선 점선 길이" *rd-dd* 6)
             *rd-dg* (mlsp:getnum "\n차선 점선 간격" *rd-dg* 6)
             *rd-ad* (mlsp:getnum "\n화살표 끝 ~ 정지선 거리" *rd-ad* 4)
             *rd-al* (mlsp:getnum "\n화살표 길이" *rd-al* 6)
             *rd-su* (mlsp:getnum "\n심볼 기준 크기 (기준 차로폭, 이보다 좁은 차로만 축소)" *rd-su* 6)
             *rd-stopfull* (mlsp:set-yn "\n정지선 양방향 전폭 (아니오=진입 차로만)" *rd-stopfull*)
             *rd-autoarrow* (mlsp:set-yn "\n회전 화살표 자동 배치" *rd-autoarrow*)))))
  (princ "\n도로를 선택하세요 (경계선·차선·중심선 등 도로의 어느 부분이든 — 영역으로 한꺼번에 골라도 됩니다): ")
  (if (and (setq ss (ssget))
           (setq paths (mlsp:paths-from-ss ss)))
    (progn
      (vla-StartUndoMark doc)
      (setq undo_open t)
      (setq i (mlsp:net-run (reverse paths)))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 도로 " (itoa i) "개를 정리했습니다 (고른 도로 " (itoa (length paths)) "개 + 맞닿은 도로)."))))
  (princ))

(princ)
