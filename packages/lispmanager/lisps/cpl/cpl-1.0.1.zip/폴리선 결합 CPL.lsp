(defun c:CPL (/ ss old_pedit fuzz)
  (vl-load-com)
  ;; 시스템 변수 백업 (선택한 객체를 폴리선으로 전환하겠냐는 질문 끄기)
  (setq old_pedit (getvar "PEDITACCEPT"))
  (setvar "PEDITACCEPT" 1)
  
  (prompt "\n폴리선으로 결합할 선(Line, Arc, Polyline)들을 선택하세요: ")
  
  ;; 선, 원호, 폴리선만 필터링해서 선택
  (if (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE"))))
    (progn
      ;; 틈 거리를 직접 입력하거나 화면에서 두 점을 클릭해 잴 수 있음
      (setq fuzz (getdist "\n결합할 최대 허용 오차(Fuzz Distance) 입력 또는 두 점 클릭 <0.1>: "))
      
      ;; Enter만 누르면 기본값 0.1 (도면 축척에 따라 1.0 등으로 바꿀 수 있음)
      (if (not fuzz) (setq fuzz 0.1))

      (command "_.undo" "_begin")
      
      ;; 변수화된 fuzz 값을 PEDIT 명령어에 적용
      (command "_.pedit" "_M" ss "" "_J" fuzz "")
      
      (command "_.undo" "_end")
      (prompt (strcat "\n선택한 " (itoa (sslength ss)) "개의 객체를 오차범위 [" (rtos fuzz 2 3) "] 안에서 폴리선으로 결합했습니다."))
    )
    (prompt "\n선택된 객체가 없습니다.")
  )
  
  ;; 시스템 변수 원상 복구
  (setvar "PEDITACCEPT" old_pedit)
  (princ)
)