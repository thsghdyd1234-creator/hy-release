;;; ==============================================================================
;;;  CPL — 선·호·폴리선을 폴리선으로 잇기 (PEDIT 결합)
;;;
;;;  객체를 고르고 틈 허용치(직접 넣거나 두 점 클릭 · 기억)를 정하면 PEDIT 여러 개(M) 결합으로 잇는다.
;;;  3D 폴리선·메시는 빠지고, 잠긴 레이어도 빠진다. 결과 폴리선 수를 알려 주고 골라 둔다.
;;;  PEDITACCEPT 는 결합하는 동안만 바꾸고 되돌린다 (중간에 ESC 해도). 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun c:CPL ( / *error* doc undo_open sv ss fz e0 e out i k)
  (defun *error* (msg)
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n폴리선으로 이을 선·호·폴리선을 고르세요 (잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L" '((-4 . "<OR") (0 . "LINE,ARC,LWPOLYLINE")
                                    (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 88) (-4 . "NOT>") (-4 . "AND>")
                                    (-4 . "OR>")))))
    (princ "\n고른 객체가 없습니다.")
    (progn
      (setq fz (if (getenv "HyCplFuzz") (atof (getenv "HyCplFuzz")) 0.1))
      (initget 4)
      (setq fz (cond ((getdist (strcat "\n이을 틈 허용치 (직접 넣거나 두 점 클릭) <" (rtos fz 2 3) ">: "))) (fz)))
      (setenv "HyCplFuzz" (rtos fz 2 8))
      (setq sv (mapcar '(lambda (v) (cons v (getvar v))) '("PEDITACCEPT" "CMDECHO")) e0 (entlast))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "PEDITACCEPT" 1)
      (setvar "CMDECHO" 0)
      (command "_.PEDIT" "_M" ss "" "_J" fz "")
      (setq k 0)
      (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))   ; 정밀도 같은 추가 질문은 기본값으로
      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      ;; 결과 폴리선: 고른 폴리선 중 남은 것 + 새로 생긴 폴리선
      (setq out (ssadd) i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (if (and (entget e) (wcmatch (cdr (assoc 0 (entget e))) "*POLYLINE")) (ssadd e out))
        (setq i (1+ i)))
      (setq e (if e0 (entnext e0) (entnext)))
      (while e
        (if (wcmatch (cdr (assoc 0 (entget e))) "*POLYLINE") (ssadd e out))
        (setq e (entnext e)))
      (if (> (sslength out) 0) (sssetfirst nil out))
      (princ (strcat "\n[완료] 객체 " (itoa (sslength ss)) "개를 이어 폴리선 " (itoa (sslength out)) "개가 되었습니다 (틈 허용치 "
                     (rtos fz 2 3) ")."))))
  (princ))

(princ)
