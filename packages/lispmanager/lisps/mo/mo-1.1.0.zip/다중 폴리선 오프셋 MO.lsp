;;; ==============================================================================
;;;  MO — 여러 폴리선 한 번에 오프셋
;;;
;;;  거리와 방향 [안(I)/밖(O)/양쪽(B)] 을 고르고 닫힌 폴리선·원을 고르면 한꺼번에 간격띄우기 한다.
;;;   · 안/밖은 양쪽으로 띄워 본 결과의 넓이로 판단 (결과가 여러 조각이어도 모두)
;;;   · 시작점과 끝점이 같은 폴리선도 닫힌 것으로 본다. 잠긴 레이어는 빠진다.
;;;   · 띄우지 못한 것은 끝에 골라 둔다 (그립). 거리·방향은 기억한다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun mo:kind (o)
  ;; T = 닫힘 표시가 있거나 원, SAME = 닫힘 표시 없이 시작점과 끝점이 같은 폴리선 (점 넷 이상), nil = 열림
  (cond ((= (vla-get-ObjectName o) "AcDbCircle") T)
        ((= (vla-get-Closed o) :vlax-true) T)
        ((and (> (cdr (assoc 90 (entget (vlax-vla-object->ename o)))) 3)
              (equal (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o) 1e-4))
         'SAME)))

;; SAME 폴리선의 닫힌 임시 사본: 겹친 마지막 점을 빼고 닫는다 (그대로 띄우면 시작 모서리가 꺾이지 않고 벌어짐)
(defun mo:closed-copy (o / c ed n k out)
  (setq c (vla-Copy o) ed (entget (vlax-vla-object->ename c)) n (cdr (assoc 90 ed)) k 0)
  (foreach g ed
    (if (= (car g) 10) (setq k (1+ k)))
    (cond ((and (= k n) (member (car g) '(10 40 41 42 91))))
          ((= (car g) 90) (setq out (cons (cons 90 (1- n)) out)))
          ((= (car g) 70) (setq out (cons (cons 70 (logior 1 (cdr g))) out)))
          (T (setq out (cons g out)))))
  (entmod (reverse out))
  (entupd (vlax-vla-object->ename c))
  c)

;; 한쪽으로 띄운 결과 (객체 목록) / 실패면 nil
(defun mo:offset (o d / r)
  (setq r (vl-catch-all-apply 'vla-Offset (list o d)))
  (if (not (vl-catch-all-error-p r)) (vlax-safearray->list (vlax-variant-value r))))

(defun mo:area (lst) (apply '+ (mapcar '(lambda (x) (vla-get-Area x)) lst)))
(defun mo:del (lst) (foreach x lst (vl-catch-all-apply 'vla-Delete (list x))))

(defun c:MO ( / *error* doc undo_open d side ss i e o kind src a0 r1 r2 in out ok fail n)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (null *mo_side*) (setq *mo_side* "I"))
  (initget 6 "I O B")
  (setq d (getdist (strcat "\n간격 [안(I)/밖(O)/양쪽(B) — 지금 " (cdr (assoc *mo_side* '(("I" . "안") ("O" . "밖") ("B" . "양쪽"))))
                           "]" (if *mo_dist* (strcat " <" (rtos *mo_dist* 2 2) ">") "") ": ")))
  (while (member d '("I" "O" "B"))
    (setq *mo_side* d)
    (initget 6 "I O B")
    (setq d (getdist (strcat "\n간격 (" (cdr (assoc *mo_side* '(("I" . "안") ("O" . "밖") ("B" . "양쪽")))) ")"
                             (if *mo_dist* (strcat " <" (rtos *mo_dist* 2 2) ">") "") ": "))))
  (if (and (null d) *mo_dist*) (setq d *mo_dist*))
  (cond
    ((null d) (princ "\n간격을 넣지 않았습니다."))
    ((progn (setq *mo_dist* d side *mo_side*)
            (prompt "\n간격띄우기 할 닫힌 폴리선·원을 고르세요 (잠긴 레이어는 빠짐): ")
            (null (setq ss (ssget "_:L" '((0 . "LWPOLYLINE,CIRCLE"))))))
     (princ "\n고른 객체가 없습니다."))
    (T
     (vla-StartUndoMark doc)
     (setq undo_open T i 0 n 0 fail (ssadd))
     (while (< i (sslength ss))
       (setq e (ssname ss i) o (vlax-ename->vla-object e) ok nil)
       (if (setq kind (mo:kind o))
         (progn
           (setq src (if (= kind 'SAME) (mo:closed-copy o) o)
                 a0 (vla-get-Area o) r1 (mo:offset src d) r2 (mo:offset src (- d)) in nil out nil)
           (if (= kind 'SAME) (vla-Delete src))
           ;; 넓이가 원래보다 작은 결과 = 안, 큰 결과 = 밖
           (foreach r (list r1 r2)
             (if r
               (cond ((and (null in) (< (mo:area r) a0)) (setq in r))
                     ((and (null out) (> (mo:area r) a0)) (setq out r))
                     (T (mo:del r)))))
           (cond
             ((= side "I") (mo:del out) (setq ok in))
             ((= side "O") (mo:del in) (setq ok out))
             (T (setq ok (or in out)))))
         nil)
       (if ok (setq n (1+ n)) (ssadd e fail))
       (setq i (1+ i)))
     (vla-EndUndoMark doc)
     (setq undo_open nil)
     (princ (strcat "\n[완료] " (itoa n) "개를 " (rtos d 2 2) " 만큼 "
                    (cdr (assoc side '(("I" . "안쪽으로") ("O" . "바깥으로") ("B" . "양쪽으로")))) " 띄웠습니다."))
     (if (> (sslength fail) 0)
       (progn
         (sssetfirst nil fail)
         (princ (strcat "\n[주의] " (itoa (sslength fail)) "개는 띄우지 못해 골라 두었습니다 (열린 폴리선 · 간격이 너무 큼)."))))))
  (princ))

(princ)
