(defun c:MO ( / dist ss i count ent vlaObj origArea var1 var2 objList1 objList2 area1 area2 keepObj targetArea )
  (vl-load-com)
  
  ;; 1. 오프셋 거리 입력
  (setq dist (getdist "\n안쪽으로 오프셋할 거리(두께)를 입력하세요: "))
  (if dist
    (progn
      ;; 2. 폴리선 드래그 선택 (LWPOLYLINE만 필터링)
      (prompt "\n안쪽으로 오프셋할 닫힌 폴리선들을 모두 선택하세요: ")
      (if (setq ss (ssget '((0 . "LWPOLYLINE"))))
        (progn
          (setq count 0 i 0)
          
          ;; 3. 선택한 객체들을 하나씩 순회
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (setq vlaObj (vlax-ename->vla-object ent))
            
            ;; 닫힌(Closed) 폴리선인지 확인
            (if (= (vla-get-Closed vlaObj) :vlax-true)
              (progn
                (setq origArea (vla-get-Area vlaObj))
                
                ;; 4. 양/음수 양방향으로 가상 오프셋 시도 (오류 무시)
                (setq var1 (vl-catch-all-apply 'vla-offset (list vlaObj dist)))
                (setq var2 (vl-catch-all-apply 'vla-offset (list vlaObj (- dist))))
                
                (setq objList1 nil objList2 nil area1 nil area2 nil)
                
                ;; 첫 번째 방향 결과 확인
                (if (not (vl-catch-all-error-p var1))
                  (progn
                    (setq objList1 (vlax-safearray->list (vlax-variant-value var1)))
                    (setq area1 (vla-get-Area (car objList1)))
                  )
                )
                
                ;; 두 번째 방향 결과 확인
                (if (not (vl-catch-all-error-p var2))
                  (progn
                    (setq objList2 (vlax-safearray->list (vlax-variant-value var2)))
                    (setq area2 (vla-get-Area (car objList2)))
                  )
                )
                
                ;; 5. 두 결과 중 면적이 더 작은 것을 '안쪽'으로 판별하여 유지
                (cond
                  ((and area1 area2)
                    (if (< area1 area2)
                      (progn (setq keepObj (car objList1)) (mapcar 'vla-delete objList2))
                      (progn (setq keepObj (car objList2)) (mapcar 'vla-delete objList1))
                    )
                  )
                  (area1 (setq keepObj (car objList1)))
                  (area2 (setq keepObj (car objList2)))
                  (t (setq keepObj nil))
                )
                
                ;; 6. 최종 검증: 새로 생성된 객체의 면적이 원본보다 작아야만 인정
                (if keepObj
                  (if (< (vla-get-Area keepObj) origArea)
                    (setq count (1+ count))
                    (mapcar 'vla-delete (list keepObj)) ;; 면적이 크면 바깥쪽으로 나간 오류이므로 삭제
                  )
                )
              )
              (princ "\n[주의] 닫히지 않은(Open) 폴리선은 건너뜁니다.")
            )
            (setq i (1+ i))
          )
          (princ (strcat "\n[완료] 총 " (itoa count) "개의 폴리선이 [" (rtos dist) "] 만큼 안쪽으로 오프셋되었습니다."))
        )
        (princ "\n선택된 폴리선이 없습니다.")
      )
    )
    (princ "\n오프셋 거리가 입력되지 않았습니다.")
  )
  (princ)
)