;;; ============================================================
;;;  SDC — 문 개구부 타공
;;;
;;;  모드 1: 이미 놓인 문 블록을 골라 한꺼번에 개구부를 뚫는다. 문마다 블록 축척(경첩·여는 쪽)을 보고,
;;;          벽 두께는 문마다 잰다(맞은편 벽선을 못 찾으면 입력한 두께).
;;;  모드 2: 점을 찍어 문을 넣고, 마우스로 각도를 돌린 뒤 경첩 쪽·여는 쪽을 골라 뚫는다.
;;;
;;;  자르기는 IDD 와 같다 — 선으로 된 벽은 두 벽선과 그 사이의 평행한 벽선만 직접 잘라 낸다(TRIM 없음, 중심선 그대로).
;;;  폴리선 벽은 펜스 자르기. 문틀선은 벽선 레이어, 개구부 경계는 '개구부-문' 레이어(색 6).
;;;  전제: 블록 기준점 = 개구부 모서리, +X = 문 폭 방향, +Y = 벽 안쪽.
;;; ============================================================

;; ── 보조 (IDD 와 같은 계산) ─────────────────────────────
(defun sdc:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun sdc:sub (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b)) (- (caddr a) (caddr b))))
(defun sdc:add (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b)) (+ (caddr a) (caddr b))))
(defun sdc:mul (a k) (list (* (car a) k) (* (cadr a) k) (* (caddr a) k)))
(defun sdc:dir (ang) (list (cos ang) (sin ang) 0.0))
(defun sdc:p3 (p) (if (caddr p) p (list (car p) (cadr p) 0.0)))
(defun sdc:para-p (a b) (< (abs (sin (- a b))) 0.0175))

(defun sdc:mklayer (name color)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 color) '(6 . "Continuous")))))

(defun sdc:locked-p (lay / r)
  (setq r (tblsearch "LAYER" lay))
  (and r (= 4 (logand 4 (cdr (assoc 70 r))))))

(defun sdc:ltype (ed / lt)
  (setq lt (cdr (assoc 6 ed)))
  (if (or (null lt) (= (strcase lt) "BYLAYER"))
    (setq lt (cdr (assoc 6 (tblsearch "LAYER" (cdr (assoc 8 ed)))))))
  (if lt lt "Continuous"))

;; 벽선으로 볼 수 있는지 — 중심선·그리드·개구부 레이어는 아님. wall_lay(없으면 nil) 이거나 실선이면 벽선.
(defun sdc:wall-like-p (ed wall_lay / lay lt)
  (setq lay (strcase (cdr (assoc 8 ed)))
        lt (strcase (sdc:ltype ed)))
  (cond
    ((wcmatch lt "*CENTER*,*DASHDOT*,*PHANTOM*,*CEN*,*ACAD_ISO04*,*ACAD_ISO10*") nil)
    ((wcmatch lay "*CEN*,*중심*,*C`.L*,*GRID*,*그리드*,개구부*") nil)
    ((and wall_lay (= lay (strcase wall_lay))) T)
    ((wcmatch lt "CONTINUOUS,BYBLOCK") T)))

(defun sdc:segs (ent / ed typ obj n i out)
  (setq ed (entget ent) typ (cdr (assoc 0 ed)))
  (cond
    ((= typ "LINE") (list (list (sdc:p3 (cdr (assoc 10 ed))) (sdc:p3 (cdr (assoc 11 ed))))))
    ((= typ "LWPOLYLINE")
     (setq obj (vlax-ename->vla-object ent)
           n (fix (+ 0.5 (vlax-curve-getEndParam obj)))
           i 0)
     (while (< i n)
       (if (equal (vla-getbulge obj i) 0.0 1e-9)
         (setq out (cons (list (vlax-curve-getPointAtParam obj i) (vlax-curve-getPointAtParam obj (1+ i))) out)))
       (setq i (1+ i)))
     (reverse out))))

(defun sdc:foot (pt s ext / p1 p2 v L2 k)
  (setq p1 (car s) p2 (cadr s) v (sdc:sub p2 p1) L2 (sdc:dot v v))
  (if (< L2 1e-12)
    p1
    (progn
      (setq k (/ (sdc:dot (sdc:sub pt p1) v) L2))
      (if (not ext) (setq k (max 0.0 (min 1.0 k))))
      (sdc:add p1 (sdc:mul v k)))))

(defun sdc:over-p (pt s / v k)
  (setq v (sdc:sub (cadr s) (car s)))
  (if (< (sdc:dot v v) 1e-12)
    nil
    (progn
      (setq k (/ (sdc:dot (sdc:sub pt (car s)) v) (sdc:dot v v)))
      (and (> k -1e-6) (< k (+ 1.0 1e-6))))))

(defun sdc:ss-around (p r flt / u)
  (setq u (trans p 0 1))
  (ssget "_C" (list (- (car u) r) (- (cadr u) r)) (list (+ (car u) r) (+ (cadr u) r)) flt))

(defun sdc:ss-list (ss / i out)
  (setq i 0)
  (if ss (while (< i (sslength ss)) (setq out (cons (ssname ss i) out) i (1+ i))))
  (reverse out))

;; 문 기준점 base 에서 벽 안쪽(n) 으로 맞은편 벽선까지 → (두께 벽면들 벽선레이어), 못 찾으면 nil
;;   u = 문 폭 방향. base 를 지나는 평행선이 있으면 그 레이어를 먼저 본다.
(defun sdc:measure (base u n / ss face_lay faces best d s2 foot rank)
  (setq ss (sdc:ss-list (sdc:ss-around base 1100.0 '((0 . "LINE,LWPOLYLINE")))))
  ;; 기준점이 놓인 벽면
  (foreach e ss
    (foreach s (sdc:segs e)
      (if (and (> (distance (car s) (cadr s)) 1e-6)
               (sdc:para-p (angle (car s) (cadr s)) (angle '(0 0 0) u))
               (< (distance base (sdc:foot base s T)) 1.0)
               (sdc:wall-like-p (entget e) nil))
        (setq face_lay (cdr (assoc 8 (entget e))) faces (cons e faces)))))
  (foreach e ss
    (foreach s2 (sdc:segs e)
      (if (and (> (distance (car s2) (cadr s2)) 1e-6)
               (sdc:para-p (angle (car s2) (cadr s2)) (angle '(0 0 0) u))
               (sdc:over-p base s2))
        (progn
          (setq foot (sdc:foot base s2 T)
                d (sdc:dot (sdc:sub foot base) n))
          (if (and (>= d 30.0) (<= d 1000.0) (sdc:wall-like-p (entget e) face_lay))
            (progn
              (setq rank (if (and face_lay (= (strcase (cdr (assoc 8 (entget e)))) (strcase face_lay))) 0 1))
              (if (or (null best) (< rank (car best)) (and (= rank (car best)) (< d (cadr best))))
                (setq best (list rank d e)))))))))
  (if best
    (list (cadr best) (cons (caddr best) faces) (if face_lay face_lay (cdr (assoc 8 (entget (caddr best))))))))

(defun sdc:piece (s e t0 t1 a b / pa pb)
  (setq pa (sdc:add s (sdc:mul (sdc:sub e s) (/ (- a t0) (- t1 t0))))
        pb (sdc:add s (sdc:mul (sdc:sub e s) (/ (- b t0) (- t1 t0)))))
  (if (<= t0 t1) (list pa pb) (list pb pa)))

(defun sdc:set-ends (ed pq)
  (subst (cons 10 (car pq)) (assoc 10 ed) (subst (cons 11 (cadr pq)) (assoc 11 ed) ed)))

(defun sdc:cut-line (ent lo u dw / ed s e t0 t1 tmin tmax k1 k2 ed2)
  (setq ed (entget ent)
        s (sdc:p3 (cdr (assoc 10 ed))) e (sdc:p3 (cdr (assoc 11 ed)))
        t0 (sdc:dot (sdc:sub s lo) u) t1 (sdc:dot (sdc:sub e lo) u)
        tmin (min t0 t1) tmax (max t0 t1))
  (if (and (< tmin (- dw 0.01)) (> tmax 0.01) (> (abs (- t1 t0)) 1e-6))
    (progn
      (setq k1 (if (< tmin -0.01) (list tmin 0.0))
            k2 (if (> tmax (+ dw 0.01)) (list dw tmax)))
      (cond
        ((and k1 k2)
         (setq ed2 (vl-remove-if '(lambda (g) (member (car g) '(-1 5 102 330 360))) ed))
         (entmod (sdc:set-ends ed (sdc:piece s e t0 t1 (car k1) (cadr k1))))
         (entmake (sdc:set-ends ed2 (sdc:piece s e t0 t1 (car k2) (cadr k2)))))
        (k1 (entmod (sdc:set-ends ed (sdc:piece s e t0 t1 (car k1) (cadr k1)))))
        (k2 (entmod (sdc:set-ends ed (sdc:piece s e t0 t1 (car k2) (cadr k2)))))
        (T (entdel ent)))
      T)))

;; 개구부 [lo, lo + u·dw] × [0, thk·n] 를 뚫는다 → 자른 벽선 수
(defun sdc:cut-opening (lo u n dw thk faces wall_lay / hi c3 c4 cnt poly_faces ed s e a b box pol mid f_top f_bot)
  (setq hi (sdc:add lo (sdc:mul u dw))
        c3 (sdc:add hi (sdc:mul n thk))
        c4 (sdc:add lo (sdc:mul n thk))
        cnt 0)
  (setq box (sdc:ss-around (sdc:mul (sdc:add lo c3) 0.5) (+ (/ (max dw thk) 2.0) 60.0) '((0 . "LINE,LWPOLYLINE"))))
  (foreach ent (sdc:ss-list box)
    (setq ed (entget ent))
    (cond
      ((sdc:locked-p (cdr (assoc 8 ed))) nil)
      ((= (cdr (assoc 0 ed)) "LINE")
       (setq s (sdc:p3 (cdr (assoc 10 ed))) e (sdc:p3 (cdr (assoc 11 ed)))
             a (sdc:dot (sdc:sub s lo) n) b (sdc:dot (sdc:sub e lo) n))
       (if (and (> (distance s e) 1e-6)
                (sdc:para-p (angle s e) (angle '(0 0 0) u))
                (> (min a b) -1.0) (< (max a b) (+ thk 1.0))
                (or (member ent faces) (sdc:wall-like-p ed wall_lay)))
         (if (sdc:cut-line ent lo u dw) (setq cnt (1+ cnt)))))
      ((and (= (cdr (assoc 0 ed)) "LWPOLYLINE") (or (member ent faces) (sdc:wall-like-p ed wall_lay)))
       (setq poly_faces (cons ent poly_faces)))))
  (if poly_faces
    (progn
      (setq pol (entmakex (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 wall_lay) '(100 . "AcDbPolyline")
                                '(90 . 4) '(70 . 1) (cons 38 (caddr lo))
                                (cons 10 (sdc:add lo (sdc:mul n -50.0))) (cons 10 (sdc:add hi (sdc:mul n -50.0)))
                                (cons 10 (sdc:add hi (sdc:mul n (+ thk 50.0)))) (cons 10 (sdc:add lo (sdc:mul n (+ thk 50.0)))))))
      (setq mid (sdc:add lo (sdc:mul u (/ dw 2.0)))
            f_top (sdc:add mid (sdc:mul n (+ thk 10.0)))
            f_bot (sdc:add mid (sdc:mul n -10.0)))
      (command "_.-view" "_s" "SDC_TMP")
      (setq *sdc:view* T)
      (command "_.zoom" "_c" "_non" (trans mid 0 1) (* (max dw thk) 3.0))
      (vl-catch-all-apply
        '(lambda () (command "_.trim" pol "" "_f" "_non" (trans f_top 0 1) "_non" (trans f_bot 0 1) "" "")))
      (if (entget pol) (entdel pol))
      (command "_.-view" "_r" "SDC_TMP")
      (command "_.-view" "_d" "SDC_TMP")
      (setq *sdc:view* nil)
      (setq cnt (+ cnt (length poly_faces)))))
  (if (> cnt 0)
    (progn
      (entmake (list '(0 . "LINE") (cons 8 wall_lay) (cons 10 lo) (cons 11 c4)))
      (entmake (list '(0 . "LINE") (cons 8 wall_lay) (cons 10 hi) (cons 11 c3)))
      (entmake (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(8 . "개구부-문") '(100 . "AcDbPolyline")
                     '(90 . 4) '(70 . 1) (cons 38 (caddr lo))
                     (cons 10 lo) (cons 10 hi) (cons 10 c3) (cons 10 c4)))))
  cnt)

;; 문 블록의 X 방향 폭 (회전 0 기준, 축척 그대로)
(defun sdc:block-width (obj / mn mx r)
  (setq r (vla-get-Rotation obj))
  (vla-put-Rotation obj 0.0)
  (vla-GetBoundingBox obj 'mn 'mx)
  (vla-put-Rotation obj r)
  (- (car (vlax-safearray->list mx)) (car (vlax-safearray->list mn))))

;; 놓인 문 하나: 블록 축척으로 개구부 틀 → 두께(재거나 tw) → 뚫기. 돌려줌: 자른 벽선 수
(defun sdc:cut-door (ent dw tw / ed base rot xs ys u n m thk faces wall_lay lo w)
  (setq ed (entget ent)
        base (sdc:p3 (cdr (assoc 10 ed)))
        rot (cdr (assoc 50 ed))
        xs (cond ((cdr (assoc 41 ed))) (1.0))
        ys (cond ((cdr (assoc 42 ed))) (1.0))
        u (sdc:dir (if (< xs 0) (+ rot pi) rot))
        n (sdc:dir (if (< ys 0) (- rot (/ pi 2.0)) (+ rot (/ pi 2.0)))))
  (if (= (type dw) 'STR)
    (setq w (* (abs xs) (sdc:block-width (vlax-ename->vla-object ent))))
    (setq w dw))
  (setq m (sdc:measure base u n))
  (if m
    (setq thk (car m) faces (cadr m) wall_lay (caddr m))
    (setq thk (abs tw) faces nil wall_lay (getvar "CLAYER")))
  ;; 개구부는 lo 에서 u 방향 — u 가 뒤집혀 있어도 [base, base + u·w]
  (setq lo base)
  (sdc:cut-opening lo u n w thk faces wall_lay))

;; ============================================================
(defun c:SDC ( / *error* doc space sv undo_open door_pending mode dw tw dw_in tw_in ss i ent n_ok n_none
                 validBlk blkName cutOpt insPt base obj rot u n mid loop gr code pm lx ly nx ny curX curY ins
                 m thk faces wall_lay lo hi cnt)

  (defun *error* (msg)
    (if undo_open
      (progn
        (vla-EndUndoMark doc)
        (setq undo_open nil)
        (if door_pending (command-s "_.U"))))
    (if *sdc:view*
      (progn (command-s "_.-view" "_r" "SDC_TMP") (command-s "_.-view" "_d" "SDC_TMP") (setq *sdc:view* nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        space (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("OSMODE" "CMDECHO" "TRIMEXTENDMODE" "EDGEMODE")))

  ;; ---- 모드 · 폭 · 두께 ----
  (if (null *sdc_mode*) (setq *sdc_mode* "1"))
  (initget "1 2")
  (setq mode (getkword (strcat "\n작업 모드 [1: 놓인 문 한꺼번에 / 2: 새 문 넣으며] <" *sdc_mode* ">: ")))
  (if mode (setq *sdc_mode* mode) (setq mode *sdc_mode*))

  (if (null *sdc_dw*) (setq *sdc_dw* 900.0))
  (if (= mode "1")
    (progn
      (initget 6 "B")
      (setq dw_in (getdist (strcat "\n문 폭(개구부 크기) [블록 폭(B)] <"
                                   (if (= *sdc_dw* "블록") "블록 폭" (rtos *sdc_dw* 2 0)) ">: ")))
      (cond ((equal dw_in "B") (setq *sdc_dw* "블록")) (dw_in (setq *sdc_dw* dw_in))))
    (progn
      (if (= *sdc_dw* "블록") (setq *sdc_dw* 900.0))
      (initget 6)
      (setq dw_in (getdist (strcat "\n문 폭(개구부 크기) <" (rtos *sdc_dw* 2 0) ">: ")))
      (if dw_in (setq *sdc_dw* dw_in))))
  (setq dw *sdc_dw*)

  (if (null *sdc_tw*) (setq *sdc_tw* 200.0))
  (initget 2)
  (setq tw_in (getdist (strcat "\n벽 두께 — 맞은편 벽선을 못 찾을 때 씀 <" (rtos *sdc_tw* 2 0) ">: ")))
  (if tw_in (setq *sdc_tw* (abs tw_in)))
  (setq tw *sdc_tw*)

  (setvar "CMDECHO" 0)
  (setvar "OSMODE" 0)
  (setvar "TRIMEXTENDMODE" 0)
  (setvar "EDGEMODE" 0)
  (sdc:mklayer "개구부-문" 6)

  (cond
    ;; ==========================================
    ;; [모드 1] 놓인 문 한꺼번에
    ;; ==========================================
    ((= mode "1")
     (setq ss (ssget "_I" '((0 . "INSERT"))))
     (if ss
       (sssetfirst nil nil)
       (progn
         (prompt "\n개구부를 뚫을 문 블록을 고르세요: ")
         (setq ss (ssget '((0 . "INSERT"))))))
     (if (not ss)
       (princ "\n고른 문 블록이 없습니다.")
       (progn
         (vla-StartUndoMark doc)
         (setq undo_open T i 0 n_ok 0 n_none 0)
         (while (< i (sslength ss))
           (setq ent (ssname ss i))
           (if (> (sdc:cut-door ent dw tw) 0) (setq n_ok (1+ n_ok)) (setq n_none (1+ n_none)))
           (setq i (1+ i)))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (princ (strcat "\n문 " (itoa n_ok) "개의 개구부를 뚫었습니다."))
         (if (> n_none 0)
           (princ (strcat " (" (itoa n_none) "개는 자를 벽선이 없어 건너뜀 — 이미 뚫렸거나 잠긴 레이어)"))))))

    ;; ==========================================
    ;; [모드 2] 새 문 넣으며
    ;; ==========================================
    ((= mode "2")
     (if (null *sdc_blk*) (setq *sdc_blk* "DOOR"))
     (setq validBlk nil)
     (while (not validBlk)
       (setq blkName (getstring T (strcat "\n넣을 문 블록 이름 <" *sdc_blk* ">: ")))
       (if (= blkName "") (setq blkName *sdc_blk*))
       (cond
         ((tblsearch "BLOCK" blkName) (setq validBlk T *sdc_blk* blkName))
         ((= blkName *sdc_blk*)
          (princ (strcat "\n[오류] 도면에 '" blkName "' 블록이 없습니다."))
          (setq validBlk "끝"))
         (T (princ (strcat "\n[오류] 도면에 '" blkName "' 블록이 없습니다. 다시 입력하세요 (그만두려면 Enter).")))))
     (if (= validBlk T)
       (progn
         (if (not *sdc_cut_opt*) (setq *sdc_cut_opt* "1"))
         (initget "1 2")
         (setq cutOpt (getkword (strcat "\n타공 여부 [1: 타공 함 / 2: 넣기만] <" *sdc_cut_opt* ">: ")))
         (if cutOpt (setq *sdc_cut_opt* cutOpt))

         (while (setq insPt (getpoint "\n문 기준점(개구부 모서리)을 클릭하세요 (끝내기: Enter): "))
           (setq base (trans insPt 1 0))
           (vla-StartUndoMark doc)
           (setq undo_open T door_pending T)
           ;; UCS X 방향으로 넣고 마우스로 돌림
           (setq obj (vla-InsertBlock space (vlax-3d-point base) blkName 1.0 1.0 1.0
                                      (angle '(0 0 0) (trans '(1 0 0) 1 0 T))))
           (setq ent (vlax-vla-object->ename obj))
           (prompt "\n마우스를 움직여 문의 각도를 맞추고 클릭하세요: ")
           (command "_.rotate" ent "" "_non" insPt pause)
           (setq rot (vla-get-Rotation obj)
                 u (sdc:dir rot)
                 n (sdc:dir (+ rot (/ pi 2.0)))
                 mid (sdc:add base (sdc:mul u (/ dw 2.0))))
           ;; 두께: 기준점에서 +Y(벽 안쪽)로 맞은편 벽선, 못 찾으면 tw
           (setq m (sdc:measure base u n))
           (if m
             (setq thk (car m) faces (cadr m) wall_lay (caddr m))
             (setq thk tw faces nil wall_lay (getvar "CLAYER")))

           (prompt "\n마우스로 경첩 쪽(좌/우)과 여는 쪽(안/밖)을 고르고 클릭하세요 (Enter = 지금 모양): ")
           (setq curX 1 curY 1 loop T)
           (while loop
             (setq gr (grread T 15 0) code (car gr))
             (cond
               ((and (member code '(3 5)) (listp (cadr gr)))
                (setq pm (trans (cadr gr) 1 0)
                      lx (sdc:dot (sdc:sub pm mid) u)
                      ly (sdc:dot (sdc:sub pm mid) n)
                      nx (if (>= lx 0.0) 1 -1)
                      ny (if (>= ly 0.0) 1 -1))
                (if (or (/= nx curX) (/= ny curY))
                  (progn
                    (setq curX nx curY ny
                          ins (if (= curX 1) base (sdc:add base (sdc:mul u dw))))
                    ;; 여는 쪽을 뒤집으면 기준점을 맞은편 벽면으로 — 문틀은 벽 안에 그대로
                    (if (< curY 0) (setq ins (sdc:add ins (sdc:mul n thk))))
                    (if (vl-catch-all-error-p
                          (vl-catch-all-apply
                            '(lambda ()
                               (vla-put-InsertionPoint obj (vlax-3d-point ins))
                               (vla-put-XScaleFactor obj (float curX))
                               (vla-put-YScaleFactor obj (float curY)))))
                      (princ "\n[주의] 이 블록은 뒤집을 수 없습니다 (축척 고정 블록)."))
                    (vla-Update obj)))
                (if (= code 3) (setq loop nil)))
               ((and (= code 2) (member (cadr gr) '(13 32))) (setq loop nil))
               ((member code '(11 25)) (setq loop nil))))

           ;; 개구부는 문 모양과 상관없이 [base, base + u·dw] × [0, thk·n]
           (if (= *sdc_cut_opt* "1")
             (progn
               (setq cnt (sdc:cut-opening base u n dw thk faces wall_lay))
               (if (= cnt 0) (princ "\n[주의] 자를 벽선이 없습니다 (잠긴 레이어인지 확인하세요)."))))
           (setq door_pending nil)
           (vla-EndUndoMark doc)
           (setq undo_open nil))
         (princ "\n문 넣기를 마쳤습니다.")))))

  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
