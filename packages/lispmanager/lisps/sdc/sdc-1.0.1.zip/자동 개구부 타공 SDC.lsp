(defun c:SDC ( / old_os old_echo old_err old_lay old_trim old_edge old_mirr mode dw tw 
                 ss i ent entData insPt rot xs ys ang_X ang_Y thk dist_Y1 dist_Y2 
                 f_dist1 f_dist2 p1 p2 p3 p4 base_X mid_X f_top f_bot cap1_s cap1_e 
                 cap2_s cap2_e pol blkEnt validBlk blkName cutOpt blkLayer
                 loop gr code pt ang_to_pt rel_ang local_x local_y newXScale newYScale curXScale curYScale 
                 base_insPt current_insPt y_dir )
  (vl-load-com)

  ;; 1. 현재 상태 백업
  (setq old_os (getvar "osmode"))
  (setq old_echo (getvar "cmdecho"))
  (setq old_lay (getvar "clayer"))
  (setq old_trim (getvar "TRIMEXTENDMODE"))
  (setq old_edge (getvar "EDGEMODE"))
  (setq old_mirr (getvar "MIRRTEXT"))

  ;; 2. 오류 처리
  (setq old_err *error*)
  (defun *error* (msg)
    (if old_os (setvar "osmode" old_os))
    (if old_echo (setvar "cmdecho" old_echo))
    (if old_lay (setvar "clayer" old_lay))
    (if old_trim (setvar "TRIMEXTENDMODE" old_trim))
    (if old_edge (setvar "EDGEMODE" old_edge))
    (if old_mirr (setvar "MIRRTEXT" old_mirr))

    (if (tblsearch "VIEW" "TEMP_VIEW_SDC")
      (progn
        (command "_.view" "_r" "TEMP_VIEW_SDC")
        (command "_.view" "_d" "TEMP_VIEW_SDC")
      )
    )

    (while (> (getvar "cmdactive") 0) (command))
    (if (= 8 (logand 8 (getvar "undoctl"))) (command "_.undo" "_end"))
    (if (not (member msg '("Function cancelled" "quit / exit abort")))
      (princ (strcat "\n[오류] " msg))
    )
    (setq *error* old_err)
    (princ)
  )

  ;; 3. 모드 선택 및 공통 설정
  (initget "1 2")
  (setq mode (getkword "\n작업 모드 선택 [1: 기존 문 일괄 타공 / 2: 새 문 연속 삽입 및 타공] <1>: "))
  (if (not mode) (setq mode "1"))

  (setq dw (getreal "\n문의 폭(개구부 크기)을 입력하세요 <900>: "))
  (if (not dw) (setq dw 900.0))

  (setq tw (getreal "\n벽체 두께를 입력하세요 (반대 방향일 경우 - 입력) <200>: "))
  (if (not tw) (setq tw 200.0))

  (setvar "cmdecho" 0)
  (if old_trim (setvar "TRIMEXTENDMODE" 0))
  (if old_edge (setvar "EDGEMODE" 0))
  (setvar "MIRRTEXT" 0)

  (if (not (tblsearch "LAYER" "개구부-문"))
    (command "_.-layer" "_m" "개구부-문" "_c" "6" "" "")
  )

  ;; ==========================================
  ;; [모드 1] 기존 블록 선택 후 일괄 타공
  ;; ==========================================
  (if (= mode "1")
    (progn
      (setq ss (ssget "_I" '((0 . "INSERT"))))
      (if ss (sssetfirst nil nil)) 

      (if (not ss)
        (progn
          (prompt "\n정리할 기존 문 블록들을 선택하세요: ")
          (setq ss (ssget '((0 . "INSERT"))))
        )
      )

      (if ss
        (progn
          (setvar "osmode" 0)
          (while (> (getvar "cmdactive") 0) (command)) 
          (command "_.undo" "_begin")
          (command "_.view" "_s" "TEMP_VIEW_SDC")

          (setq i 0)
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (setq entData (entget ent))
            (setq insPt (cdr (assoc 10 entData))) 
            (setq rot (cdr (assoc 50 entData)))   
            
            (setq xs (cdr (assoc 41 entData))) 
            (setq ys (cdr (assoc 42 entData))) 
            
            (setq ang_X (if (< xs 0) (+ rot pi) rot))
            (setq ang_Y (if (< ys 0) (- rot (/ pi 2)) (+ rot (/ pi 2))))
            (setq thk tw)

            (if (>= thk 0)
              (progn
                (setq dist_Y1 (+ thk 50.0))
                (setq dist_Y2 -50.0)
                (setq f_dist1 (+ thk 10.0))
                (setq f_dist2 -10.0)
              )
              (progn
                (setq dist_Y1 50.0)
                (setq dist_Y2 (- thk 50.0))
                (setq f_dist1 10.0)
                (setq f_dist2 (- thk 10.0))
              )
            )

            (setq base_X (polar insPt ang_X dw))
            (setq p1 (polar insPt ang_Y dist_Y1))
            (setq p2 (polar insPt ang_Y dist_Y2))
            (setq p3 (polar base_X ang_Y dist_Y2))
            (setq p4 (polar base_X ang_Y dist_Y1))

            (setq cap1_s insPt)
            (setq cap1_e (polar insPt ang_Y thk))
            (setq cap2_s base_X)
            (setq cap2_e (polar base_X ang_Y thk))
            
            (setq mid_X (polar insPt ang_X (/ dw 2.0)))
            
            (command "_.zoom" "_C" mid_X (* dw 3.0))

            (setvar "clayer" old_lay)
            (command "_.pline" p1 p2 p3 p4 "_C")
            (setq pol (entlast))
            
            (setq f_top (polar mid_X ang_Y f_dist1))
            (setq f_bot (polar mid_X ang_Y f_dist2))
            
            (vl-catch-all-apply
              (function (lambda ()
                (command "_.trim" pol "" "_F" f_top f_bot "" "")
              ))
            )
            
            (while (> (getvar "cmdactive") 0) (command)) 
            (if (entget pol) (entdel pol))

            (command "_.line" cap1_s cap1_e "")
            (command "_.line" cap2_s cap2_e "")

            (setvar "clayer" "개구부-문")
            (command "_.pline" cap1_s cap1_e cap2_e cap2_s "_C")
            (setvar "clayer" old_lay) 

            (setq i (1+ i))
          )
          
          (if (tblsearch "VIEW" "TEMP_VIEW_SDC")
            (progn
              (command "_.view" "_r" "TEMP_VIEW_SDC")
              (command "_.view" "_d" "TEMP_VIEW_SDC")
            )
          )

          (command "_.undo" "_end")
          (prompt (strcat "\n총 " (itoa (sslength ss)) "개의 문 일괄 정리를 완료했습니다. (모드 1)"))
        )
        (prompt "\n선택된 문 블록이 없습니다.")
      )
    )
  )

  ;; ==========================================
  ;; [모드 2] 새 블록 연속 삽입 및 타공 (제자리에서 방향 반전)
  ;; ==========================================
  (if (= mode "2")
    (progn
      (setq validBlk nil)
      (while (not validBlk)
        (setq blkName (getstring "\n삽입할 문 블록 이름을 입력하세요 <DOOR>: "))
        (if (= blkName "") (setq blkName "DOOR"))

        (if (tblsearch "BLOCK" blkName)
          (setq validBlk T)
          (prompt (strcat "\n[오류] 도면에 '" blkName "' 블록이 없습니다. 다시 확인하세요."))
        )
      )

      (if (not *sdc_cut_opt*) (setq *sdc_cut_opt* "1")) 
      (initget "1 2")
      (setq cutOpt (getkword (strcat "\n타공 여부 선택 [1: 타공 함 / 2: 타공 안 함] <" *sdc_cut_opt* ">: ")))
      (if cutOpt (setq *sdc_cut_opt* cutOpt))

      (while (setq insPt (getpoint "\n블록 삽입 기준점을 클릭하세요 (종료하려면 Enter): "))
        (command "_.undo" "_begin")
        (command "_.view" "_s" "TEMP_VIEW_SDC")

        (setvar "osmode" 0)
        (command "_.-insert" blkName "_non" insPt 1.0 1.0 0.0)
        (setq blkEnt (entlast))

        ;; -------------------------------------------------------------
        ;; 삽입한 블록을 블록 정의의 레이어로 바로 변경
        (setq blkLayer (cdr (assoc 8 (tblsearch "BLOCK" blkName))))
        (setq entData (entget blkEnt))
        (setq entData (subst (cons 8 blkLayer) (assoc 8 entData) entData))
        (entmod entData)
        ;; -------------------------------------------------------------

        (setvar "osmode" old_os)
        (prompt "\n마우스를 움직여 문의 각도를 맞추고 클릭하세요: ")
        (command "_.rotate" blkEnt "" "_non" insPt pause)

        ;; 블록의 회전 각도 및 초기 데이터 갱신 (위에서 entData를 변경했으므로 다시 로드)
        (setq entData (entget blkEnt))
        (setq rot (cdr (assoc 50 entData)))
        
        ;; 최초 삽입점과 개구부 중심점을 고정값으로 계산
        (setq base_insPt insPt)
        (setq mid_X (polar base_insPt rot (/ dw 2.0)))
        
        (prompt "\n마우스를 상하좌우로 움직여 문의 개폐 방향을 결정하고 클릭하세요: ")
        (setq loop T curXScale 1.0 curYScale 1.0)
        
        (while loop
          (setq gr (grread T 15 0))
          (setq code (car gr) pt (cadr gr))
          
          (if (and (or (= code 5) (= code 3)) pt (not (equal base_insPt pt 1e-4)))
            (progn
              ;; 중심점(mid_X) 대비 마우스의 상대 좌표 계산
              (setq ang_to_pt (angle mid_X pt))
              (setq rel_ang (- ang_to_pt rot))
              
              ;; X, Y 지역 좌표계로 분해
              (setq local_x (* (distance mid_X pt) (cos rel_ang)))
              (setq local_y (* (distance mid_X pt) (sin rel_ang)))
              
              ;; 마우스가 중심점의 좌/우, 위/아래 어디에 있는지에 따라 스케일 결정
              (setq newXScale (if (>= local_x 0.0) 1.0 -1.0))
              (setq newYScale (if (>= local_y 0.0) 1.0 -1.0))
              
              ;; 방향이 바뀌었을 때만 업데이트
              (if (or (/= newXScale curXScale) (/= newYScale curYScale))
                (progn
                  (setq curXScale newXScale curYScale newYScale)
                  
                  ;; X축이 뒤집히면, 삽입점 자체를 문 폭(dw)만큼 반대편으로 밀어줌 
                  (setq current_insPt (if (= curXScale 1.0) 
                                          base_insPt 
                                          (polar base_insPt rot dw)))
                  
                  ;; 삽입점(10) 업데이트
                  (setq entData (subst (cons 10 current_insPt) (assoc 10 entData) entData))
                  
                  ;; X축 스케일(41), Y축 스케일(42) 업데이트
                  (if (assoc 41 entData)
                    (setq entData (subst (cons 41 curXScale) (assoc 41 entData) entData))
                    (setq entData (append entData (list (cons 41 curXScale))))
                  )
                  (if (assoc 42 entData)
                    (setq entData (subst (cons 42 curYScale) (assoc 42 entData) entData))
                    (setq entData (append entData (list (cons 42 curYScale))))
                  )
                  (entmod entData)
                  (entupd blkEnt)
                )
              )
            )
          )
          
          (if (= code 3) ; 좌클릭 시 방향 확정
            (setq loop nil)
          )
        )

        ;; 타공 옵션이 '1(타공 함)'일 때만 트림 실행
        (if (= *sdc_cut_opt* "1")
          (progn
            (setq xs curXScale)
            (setq ys curYScale)
            (setq y_dir curYScale) ; Y스케일 방향을 두께 방향에 반영
            
            ;; 타공 기준은 움직인 위치가 아니라 처음 찍은 base_insPt로 고정
            (setq ang_X rot)
            (setq ang_Y (+ rot (/ pi 2.0)))
            (setq thk (* tw y_dir)) 

            (if (>= thk 0)
              (progn
                (setq dist_Y1 (+ thk 50.0))
                (setq dist_Y2 -50.0)
                (setq f_dist1 (+ thk 10.0))
                (setq f_dist2 -10.0)
              )
              (progn
                (setq dist_Y1 50.0)
                (setq dist_Y2 (- thk 50.0))
                (setq f_dist1 10.0)
                (setq f_dist2 (- thk 10.0))
              )
            )

            (setq base_X (polar base_insPt ang_X dw))
            (setq p1 (polar base_insPt ang_Y dist_Y1))
            (setq p2 (polar base_insPt ang_Y dist_Y2))
            (setq p3 (polar base_X ang_Y dist_Y2))
            (setq p4 (polar base_X ang_Y dist_Y1))

            (setq cap1_s base_insPt)
            (setq cap1_e (polar base_insPt ang_Y thk))
            (setq cap2_s base_X)
            (setq cap2_e (polar base_X ang_Y thk))
            
            (command "_.zoom" "_C" mid_X (* dw 3.0))

            (setvar "clayer" old_lay)
            (command "_.pline" p1 p2 p3 p4 "_C")
            (setq pol (entlast))

            (setq f_top (polar mid_X ang_Y f_dist1))
            (setq f_bot (polar mid_X ang_Y f_dist2))

            (vl-catch-all-apply
              (function (lambda ()
                (command "_.trim" pol "" "_F" f_top f_bot "" "")
              ))
            )

            (while (> (getvar "cmdactive") 0) (command))
            (if (entget pol) (entdel pol))

            (command "_.line" cap1_s cap1_e "")
            (command "_.line" cap2_s cap2_e "")

            (setvar "clayer" "개구부-문")
            (command "_.pline" cap1_s cap1_e cap2_e cap2_s "_C")
            (setvar "clayer" old_lay)
          ) 
        )

        (if (tblsearch "VIEW" "TEMP_VIEW_SDC")
          (progn
            (command "_.view" "_r" "TEMP_VIEW_SDC")
            (command "_.view" "_d" "TEMP_VIEW_SDC")
          )
        )

        (command "_.undo" "_end")
        (setvar "osmode" old_os)
      )
      (prompt "\n연속 삽입 작업을 완료했습니다. (모드 2)")
    )
  )

  ;; 4. 정상 종료 시 복구
  (if old_os (setvar "osmode" old_os))
  (if old_echo (setvar "cmdecho" old_echo))
  (if old_lay (setvar "clayer" old_lay))
  (if old_trim (setvar "TRIMEXTENDMODE" old_trim))
  (if old_edge (setvar "EDGEMODE" old_edge))
  (if old_mirr (setvar "MIRRTEXT" old_mirr))
  (setq *error* old_err)
  
  (princ)
)