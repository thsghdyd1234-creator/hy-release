(defun c:DTS ( / ss i ent ed entType ds new-h txtCount dimCount ssDim )
  (vl-load-com)
  (prompt "\nDIMSCALE에 맞춰 크기를 바꿀 [문자]와 [치수]를 모두 드래그하세요: ")
  
  ;; TEXT, MTEXT, DIMENSION 세 가지 객체를 모두 선택할 수 있도록 필터링 해제
  (if (setq ss (ssget '((0 . "TEXT,MTEXT,DIMENSION"))))
    (progn
      ;; 1. 현재 DIMSCALE 값 가져오기
      (setq ds (getvar "DIMSCALE"))
      (if (or (not ds) (= ds 0.0)) (setq ds 1.0))
      
      ;; 2. 일반 텍스트용 새로운 높이 계산 (500 x DIMSCALE)
      (setq new-h (* 500.0 ds))
      
      (setq i 0 txtCount 0 dimCount 0)
      (setq ssDim (ssadd)) ;; 치수만 따로 모아 둘 목록
      
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq ed (entget ent))
        (setq entType (cdr (assoc 0 ed)))
        
        (cond
          ;; [경우 1] 선택된 객체가 일반 텍스트(TEXT, MTEXT)일 때
          ((wcmatch entType "*TEXT")
            (if (assoc 40 ed)
              (setq ed (subst (cons 40 new-h) (assoc 40 ed) ed))
              (setq ed (append ed (list (cons 40 new-h))))
            )
            (entmod ed)
            (setq txtCount (1+ txtCount))
          )
          ;; [경우 2] 선택된 객체가 치수선(DIMENSION)일 때
          ((= entType "DIMENSION")
            (ssadd ent ssDim) ;; 목록에 추가
            (setq dimCount (1+ dimCount))
          )
        )
        (setq i (1+ i))
      )
      
      ;; 3. 모아 둔 치수를 현재 DIMSTYLE·DIMSCALE로 한 번에 업데이트
      (if (> dimCount 0)
        (command "_.-DIMSTYLE" "_A" ssDim "")
      )
      
      (prompt (strcat "\n[완료] 일반 텍스트 " (itoa txtCount) "개 (크기 " (rtos new-h 2 1) ") / 치수선 " (itoa dimCount) "개 크기를 바꿨습니다."))
    )
    (prompt "\n[알림] 선택된 객체가 없습니다.")
  )
  (princ)
)