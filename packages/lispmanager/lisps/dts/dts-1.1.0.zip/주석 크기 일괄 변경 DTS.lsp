;;; ==============================================================================
;;;  DTS — 주석 크기 일괄 변경 (치수 축척 기준)
;;;
;;;  문자(TEXT · MTEXT)와 치수를 고르면
;;;   · 문자 높이 = 배율 × 치수 글자 크기(DIMTXT × DIMSCALE) — 기본 배율 2 (연구실 1:100 이면 예전과 같은 500)
;;;     표준 도면(DIMTXT 2.5 · DIMSCALE 100)에서도 같은 크기가 나온다. 높이를 직접 넣으면 그 배율을 기억.
;;;     MTEXT 안의 높이 코드(\H250;)는 지우고, 폭을 정한 MTEXT 는 폭도 같은 비율로 (줄바꿈 그대로)
;;;   · 치수: 그 치수의 축척(DIMSCALE 재지정)만 지금 DIMSCALE 로 — 치수 스타일·다른 재지정은 그대로
;;;  잠긴 레이어 · 주석 축척(annotative) 문자는 건너뛴다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun dts:base ( / s b)
  (setq s (getvar "DIMSCALE"))
  (if (<= s 0.0) (setq s 1.0))
  (setq b (* (getvar "DIMTXT") s))
  (if (< b 20.0) 250.0 b))

;; MTEXT 글자에서 절대 높이 코드 \H숫자; 를 뺀다 (\H2x; 같은 비율 코드는 그대로, \\ 는 글자 \)
(defun dts:strip-h (s / out i n c j k)
  (setq out "" i 1 n (strlen s))
  (while (<= i n)
    (setq c (substr s i 1))
    (cond
      ((and (= c "\\") (< i n) (= (substr s (1+ i) 1) "\\")) (setq out (strcat out "\\\\") i (+ i 2)))
      ((and (= c "\\") (< i n) (member (substr s (1+ i) 1) '("H" "h"))
            (setq j (vl-string-search ";" s i))
            (not (wcmatch (substr s (+ i 2) (- j i 1)) "*[xX]*")))
       (setq i (+ j 2)))
      (T (setq out (strcat out c) i (1+ i)))))
  out)

(defun dts:annotative-p (e) (assoc -3 (entget e '("AcadAnnotative"))))

(defun c:DTS ( / *error* doc undo_open ss base h ds i e ed typ old nt nd na o w)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n크기를 맞출 문자와 치수를 고르세요 (잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L" '((0 . "TEXT,MTEXT,DIMENSION")))))
    (princ "\n고른 객체가 없습니다.")
    (progn
      (setq base (dts:base) ds (getvar "DIMSCALE"))
      (if (<= ds 0.0) (setq ds 1.0))
      (if (null *dts_k*) (setq *dts_k* 2.0))
      (initget 6)
      (if (setq h (getdist (strcat "\n문자 높이 <" (rtos (* *dts_k* base) 2 1) ">: ")))
        (setq *dts_k* (/ h base))
        (setq h (* *dts_k* base)))
      (vla-StartUndoMark doc)
      (setq undo_open T i 0 nt 0 nd 0 na 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) ed (entget e) typ (cdr (assoc 0 ed)))
        (cond
          ((and (wcmatch typ "*TEXT") (dts:annotative-p e)) (setq na (1+ na)))
          ((= typ "TEXT")
           (entmod (subst (cons 40 h) (assoc 40 ed) ed))
           (setq nt (1+ nt)))
          ((= typ "MTEXT")
           (setq old (cdr (assoc 40 ed)) o (vlax-ename->vla-object e))
           (vla-put-TextString o (dts:strip-h (vla-get-TextString o)))
           (if (and (> (setq w (vla-get-Width o)) 0.0) (> old 0.0)) (vla-put-Width o (* w (/ h old))))
           (vla-put-Height o h)
           (setq nt (1+ nt)))
          ((= typ "DIMENSION")
           (vla-put-ScaleFactor (vlax-ename->vla-object e) ds)
           (setq nd (1+ nd))))
        (setq i (1+ i)))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 문자 " (itoa nt) "개 (높이 " (rtos h 2 1) ") · 치수 " (itoa nd) "개 (축척 " (rtos ds 2 2) ")를 맞췄습니다."))
      (if (> na 0) (princ (strcat "\n[알림] 주석 축척 문자 " (itoa na) "개는 건너뛰었습니다.")))))
  (princ))

(princ)
