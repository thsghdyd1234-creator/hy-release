(defun c:sl ( / ss i ent lay layList dcl_file dcl_id dcl_status sel_idx_str idx_list sel_layers iso_ss found_layers f)
  (vl-load-com)
  (prompt "\n레이어를 확인할 객체들을 드래그하여 선택하세요 (블록 제외): ")

  ;; 1. 블록(INSERT)을 제외하고 객체 선택 받기
  (if (setq ss (ssget '((0 . "~INSERT"))))
    (progn
      ;; 2. 선택한 객체들에서 레이어 이름 추출 및 중복 제거
      (setq layList nil i 0)
      (repeat (sslength ss)
        (setq ent (entget (ssname ss i)))
        (setq lay (cdr (assoc 8 ent)))
        (if (not (member lay layList))
          (setq layList (append layList (list lay)))
        )
        (setq i (1+ i))
      )
      
      ;; 레이어 이름을 알파벳 순으로 정렬
      (setq layList (vl-sort layList '<))

      ;; 3. 팝업창(DCL) 파일 동적 생성 
      ;; (multiple_select = true; 옵션을 추가하여 다중 선택 허용)
      (setq dcl_file (vl-filename-mktemp "lay_sel.dcl"))
      (setq f (open dcl_file "w"))
      (write-line "layseldlg : dialog { label = \"분리할 레이어 선택 (Ctrl/Shift로 다중선택)\";" f)
      (write-line "  : list_box { key = \"laylist\"; width = 35; height = 15; allow_accept = true; multiple_select = true; }" f)
      (write-line "  ok_cancel; }" f)
      (close f)

      ;; 4. 팝업창 로드 및 화면에 띄우기
      (setq dcl_id (load_dialog dcl_file))
      (if (not (new_dialog "layseldlg" dcl_id))
        (exit)
      )

      ;; 리스트 박스에 추출한 레이어 목록 채우기
      (start_list "laylist")
      (foreach l layList (add_list l))
      (end_list)

      ;; 기본 선택값 설정 및 선택된 인덱스 문자열 변수 초기화
      (set_tile "laylist" "0")
      (setq sel_idx_str "0") 

      ;; 다중 선택 시 인덱스들이 띄어쓰기로 구분된 문자열로 반환됨 (예: "0 2 3")
      (action_tile "laylist" "(setq sel_idx_str $value)")

      ;; 확인 / 취소 버튼 동작 설정
      (action_tile "accept" "(done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")

      ;; 대화상자 실행 및 사용자가 누른 버튼 상태 저장
      (setq dcl_status (start_dialog))
      (unload_dialog dcl_id)
      (vl-file-delete dcl_file) ; 임시 팝업창 파일 삭제

      ;; 5. [확인] 버튼을 누르고 레이어가 정상적으로 선택되었을 때 Layiso 실행
      (if (= dcl_status 1)
        (progn
          ;; "0 2 3" 형태의 문자열을 리스트 (0 2 3)으로 변환
          (setq idx_list (read (strcat "(" sel_idx_str ")")))
          
          ;; 선택된 인덱스에 해당하는 레이어 이름들을 리스트로 모음
          (setq sel_layers nil)
          (foreach idx idx_list
            (setq sel_layers (append sel_layers (list (nth idx layList))))
          )

          ;; 선택된 레이어들의 객체를 하나씩 추출하여 새로운 선택 셋(Selection Set) 만들기
          (setq iso_ss (ssadd))
          (setq found_layers nil)
          (setq i 0)
          
          ;; 사용자가 처음 선택했던(ss) 객체들을 돌면서, 필요한 레이어의 객체를 찾음
          (while (and (< i (sslength ss)) 
                      (< (length found_layers) (length sel_layers))) ; 필요한 레이어를 다 찾으면 반복 종료
            (setq ent (ssname ss i))
            (setq lay (cdr (assoc 8 (entget ent))))
            
            ;; 이 객체의 레이어가 사용자가 선택한 레이어 목록에 있고, 아직 선택 셋에 안 담은 레이어라면
            (if (and (member lay sel_layers) (not (member lay found_layers)))
              (progn
                (ssadd ent iso_ss) ; 선택 셋에 추가
                (setq found_layers (append found_layers (list lay))) ; 찾은 레이어 목록에 기록
              )
            )
            (setq i (1+ i))
          )

          ;; 찾은 객체 모음(iso_ss)을 이용해 LAYISO 실행
          (if (> (sslength iso_ss) 0)
            (progn
              (prompt "\n선택한 레이어만 분리(LAYISO)합니다.\n")
              (command "LAYISO" iso_ss "")
            )
          )
        )
        (prompt "\n명령을 취소했습니다.\n")
      )
    )
    (prompt "\n선택된 객체가 없습니다. (블록은 선택에서 빠집니다)\n")
  )
  (princ)
)

(prompt "\n[SL] 로드했습니다. 레이어를 골라 분리하려면 SL을 입력하세요.")
(princ)