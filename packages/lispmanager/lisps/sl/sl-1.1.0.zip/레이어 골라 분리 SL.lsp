;;; ==============================================================================
;;;  SL — 겹친 선 중에서 고른 레이어만 분리 (LAYISO)
;;;
;;;  객체를 고르면 그 레이어 목록(레이어마다 고른 객체 수)을 대화상자로 띄운다. 여러 개는 Ctrl / Shift.
;;;  고른 레이어만 남기고 LAYISO 한다 — 되돌리기는 LAYUNISO. 끄기/잠금+흐리게는 LAYISO 설정을 따른다.
;;;  블록은 선택에서 빠진다.
;;; ==============================================================================

;; 임시 대화상자 파일 → 경로 / 못 쓰면 nil
(defun sl:dcl ( / path f)
  (setq path (vl-filename-mktemp "hy_sl.dcl"))
  (if (setq f (open path "w"))
    (progn
      (write-line "hy_sl : dialog { label = \"분리할 레이어 고르기 (여러 개: Ctrl / Shift)\";" f)
      (write-line "  : list_box { key = \"laylist\"; width = 48; height = 16; tabs = \"38\"; allow_accept = true; multiple_select = true; }" f)
      (write-line "  : text { key = \"msg\"; width = 48; }" f)
      (write-line "  ok_cancel; }" f)
      (close f)
      path)))

(defun c:SL ( / *error* sv ss i e lay hit cnt path id st pick iso sel)
  (defun *error* (msg)
    (if (and id (> id 0)) (unload_dialog id))
    (if (and path (findfile path)) (vl-file-delete path))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (setq sv (list (cons "CMDECHO" (getvar "CMDECHO"))))
  (prompt "\n레이어를 볼 객체를 고르세요 (블록은 빠짐): ")
  (if (null (setq ss (ssget '((0 . "~INSERT")))))
    (princ "\n고른 객체가 없습니다.")
    (progn
      ;; 레이어마다 (이름 객체 수 첫 객체)
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) lay (cdr (assoc 8 (entget e))))
        (if (setq hit (assoc lay cnt))
          (setq cnt (subst (list lay (1+ (cadr hit)) (caddr hit)) hit cnt))
          (setq cnt (cons (list lay 1 e) cnt)))
        (setq i (1+ i)))
      (setq cnt (vl-sort cnt '(lambda (a b) (< (strcase (car a)) (strcase (car b))))))
      (cond
        ((or (null (setq path (sl:dcl))) (< (setq id (load_dialog path)) 0) (not (new_dialog "hy_sl" id)))
         (princ "\n[오류] 대화상자를 열지 못했습니다."))
        (T
         (start_list "laylist")
         (foreach r cnt (add_list (strcat (car r) "\t" (itoa (cadr r)) "개")))
         (end_list)
         (set_tile "laylist" "0")
         (set_tile "msg" (strcat "레이어 " (itoa (length cnt)) "개 · 객체 " (itoa (sslength ss)) "개"))
         (setq pick "0")
         (action_tile "laylist" "(setq pick $value)")
         (action_tile "accept" "(done_dialog 1)")
         (action_tile "cancel" "(done_dialog 0)")
         (setq st (start_dialog))
         (cond
           ((/= st 1) (princ "\n그만두었습니다."))
           ((= pick "") (princ "\n고른 레이어가 없습니다."))
           (T
            (setq iso (ssadd))
            (foreach k (read (strcat "(" pick ")"))
              (setq sel (cons (car (nth k cnt)) sel))
              (ssadd (caddr (nth k cnt)) iso))
            (setvar "CMDECHO" 0)
            (command "_.LAYISO" iso "")
            (princ (strcat "\n[완료] 레이어 " (itoa (length sel)) "개만 남겼습니다: "
                           (substr (apply 'strcat (mapcar '(lambda (x) (strcat ", " x)) (reverse sel))) 3)
                           ". 되돌리려면 LAYUNISO."))))))))
  (if (and id (> id 0)) (unload_dialog id))
  (if (and path (findfile path)) (vl-file-delete path))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
