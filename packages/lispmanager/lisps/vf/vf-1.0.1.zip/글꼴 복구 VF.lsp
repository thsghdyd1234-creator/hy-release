(defun c:VF (/ doc styles st)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq styles (vla-get-TextStyles doc))

  (vlax-for st styles
    ;; 1. 기본 폰트를 캐드 표준 영문 폰트인 txt.shx로 지정
    (vl-catch-all-apply 'vla-put-fontfile (list st "txt.shx"))
    
    ;; 2. 한글 깨짐을 방지하는 캐드 표준 빅폰트 whgtxt.shx 지정
    (vl-catch-all-apply 'vla-put-BigFontFile (list st "whgtxt.shx"))
  )
  
  ;; 화면 새로고침
  (vla-Regen doc acAllViewports)
  (princ "\n[완료] 모든 문자 스타일의 글꼴을 캐드 기본 글꼴(txt.shx + whgtxt.shx)로 바꿨습니다.")
  (princ)
)