;;; ==============================================================================
;;;  VF — 글자가 안 보일 때 글꼴 바꾸기 · 되돌리기
;;;
;;;  Enter = 이 PC 에서 글꼴 파일을 찾지 못하는 문자 스타일만 캐드 기본 글꼴(txt.shx + whgtxt.shx)로 바꾼다.
;;;          멀쩡한 트루타입(맑은 고딕 등)·SHX 스타일은 그대로 — 폭·줄바꿈·출력이 달라지지 않는다.
;;;  전부(A) = 예전처럼 모든 스타일을 바꾼다.   되돌리기(U) = VF 가 바꾸기 전 글꼴로 되돌린다.
;;;  바꾸기 전 글꼴 이름은 도면에 적어 둔다(HY_VF) — 저장한 뒤에도 VF → U 로 되돌릴 수 있다.
;;;  외부 참조 스타일(이름에 |)은 바꿀 수 없어서 수만 알린다.
;;; ==============================================================================

;; 글꼴 파일을 찾을 수 있는지 (SHX 는 지원 경로, 트루타입은 윈도우 글꼴 폴더까지)
(defun vf:found-p (f / ext base)
  (cond
    ((= f "") T)                                        ; 글꼴 이름(typeface)으로 정한 트루타입 — 확인하지 않음
    ((findfile f) T)
    (T
     (setq ext (vl-filename-extension f) base (vl-filename-base f))
     (if ext (setq ext (strcase ext T)))
     (cond
       ((member ext '(".ttf" ".ttc" ".otf"))
        (vl-some '(lambda (d) (and d (findfile (strcat d "\\" base ext))))
                 (list (if (getenv "WINDIR") (strcat (getenv "WINDIR") "\\Fonts"))
                       (if (getenv "LOCALAPPDATA") (strcat (getenv "LOCALAPPDATA") "\\Microsoft\\Windows\\Fonts")))))
       ((null ext) (findfile (strcat f ".shx")))))))

(defun c:VF ( / *error* doc undo_open mode st name font big rec n ok xr)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (initget "All Undo")
  (setq mode (getkword "\n글꼴 바꾸기 [못 찾는 글꼴만 <Enter>/전부(A)/되돌리기(U)]: "))
  (vla-StartUndoMark doc)
  (setq undo_open T n 0 ok 0 xr 0)
  (if (= mode "Undo")
    ;; 되돌리기
    (progn
      (vlax-for s (vla-get-TextStyles doc)
        (if (setq rec (vlax-ldata-get "HY_VF" (strcase (vla-get-Name s))))
          (progn
            (vl-catch-all-apply 'vla-put-FontFile (list s (car rec)))
            (vl-catch-all-apply 'vla-put-BigFontFile (list s (cadr rec)))
            (vlax-ldata-delete "HY_VF" (strcase (vla-get-Name s)))
            (setq n (1+ n)))))
      (vla-Regen doc 1)
      (princ (if (> n 0) (strcat "\n[완료] 문자 스타일 " (itoa n) "개를 VF 전 글꼴로 되돌렸습니다.")
                 "\n[알림] VF 로 바꾼 문자 스타일이 없습니다.")))
    (progn
      (vlax-for s (vla-get-TextStyles doc)
        (setq name (vla-get-Name s) font (vla-get-FontFile s) big (vla-get-BigFontFile s))
        (cond
          ((wcmatch name "*|*") (setq xr (1+ xr)))
          ((and (/= mode "All") (vf:found-p font) (or (= big "") (vf:found-p big))) (setq ok (1+ ok)))
          (T
           ;; 처음 바꿀 때의 글꼴만 적어 둔다 (여러 번 해도 원래 글꼴이 남게)
           (if (null (vlax-ldata-get "HY_VF" (strcase name))) (vlax-ldata-put "HY_VF" (strcase name) (list font big)))
           (if (or (= mode "All") (not (vf:found-p font)))
             (progn (vl-catch-all-apply 'vla-put-FontFile (list s "txt.shx"))
                    (vl-catch-all-apply 'vla-put-BigFontFile (list s "whgtxt.shx")))
             (vl-catch-all-apply 'vla-put-BigFontFile (list s "whgtxt.shx")))      ; 큰 글꼴만 없음
           (setq n (1+ n)))))
      (vla-Regen doc 1)
      (princ (strcat "\n[완료] 문자 스타일 " (itoa n) "개의 글꼴을 txt.shx + whgtxt.shx 로 바꿨습니다"
                     (if (> ok 0) (strcat " (글꼴이 있는 " (itoa ok) "개는 그대로)") "") "."
                     (if (> n 0) " 되돌리려면 VF → U." "")
                     (if (> xr 0) (strcat "\n[알림] 외부 참조 문자 스타일 " (itoa xr) "개는 바꿀 수 없습니다 (FONTALT 로 대체 글꼴을 정하세요).") "")))))
  (vla-EndUndoMark doc)
  (setq undo_open nil)
  (princ))

(princ)
