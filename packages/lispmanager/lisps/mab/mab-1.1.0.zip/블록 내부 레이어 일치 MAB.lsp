;;; ==============================================================================
;;;  MAB — 블록을 기준 객체의 레이어로 (블록 안 객체까지)
;;;
;;;  1. 기준 객체를 클릭 (그 레이어로 맞춘다) — 0 레이어로(Z): 블록 안은 0 레이어 + ByLayer 로 (설정 기억)
;;;  2. 블록을 고른다 (잠긴 레이어는 빠짐)
;;;   · 고른 블록과 그 속성은 기준 레이어로.
;;;   · 블록 정의 안(중첩 블록까지)은 기준 레이어로, 0 레이어로(Z)면 0 레이어 + ByLayer 로 — 그러면 블록마다
;;;     자기 레이어를 따라가므로 고르지 않은 같은 블록은 보이는 모습이 바뀌지 않는다 (색이 레이어를 따라감).
;;;   · 블록 정의는 이름마다 한 번만 고친다. 동적 블록은 원본 정의까지 함께, 외부 참조는 고치지 않는다.
;;;   · 같은 블록의 다른 인스턴스도 정의를 함께 쓰므로 바뀐다 — 몇 개인지 알려 준다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 와일드카드 글자 앞에 `
(defun mab:esc (s / out)
  (setq out "")
  (foreach c (vl-string->list s)
    (setq out (strcat out (if (member c (vl-string->list "#@.*?~[]`,-")) "`" "") (chr c))))
  out)

;; 블록 정의 고치기 (중첩까지, 한 정의는 한 번만 — mab_done 은 c:MAB 의 지역 변수)
(defun mab:fix-def (doc name lay / b)
  (if (and (not (member (strcase name) mab_done))
           (not (wcmatch name "*|*"))
           (not (vl-catch-all-error-p (setq b (vl-catch-all-apply 'vla-Item (list (vla-get-Blocks doc) name)))))
           (= (vla-get-IsXRef b) :vlax-false) (= (vla-get-IsLayout b) :vlax-false))
    (progn
      (setq mab_done (cons (strcase name) mab_done))
      (vlax-for o b
        (if (vl-catch-all-error-p
              (vl-catch-all-apply '(lambda () (vla-put-Layer o (if *mab_zero* "0" lay)) (if *mab_zero* (vla-put-Color o 256))) nil))
          (setq mab_fail (1+ mab_fail)))
        (if (= (vla-get-ObjectName o) "AcDbBlockReference")
          (progn
            (mab:fix-def doc (vla-get-Name o) lay)
            (if (/= (vla-get-Name o) (vla-get-EffectiveName o)) (mab:fix-def doc (vla-get-EffectiveName o) lay))))))))

(defun c:MAB ( / *error* doc undo_open sel lay ss i o n mab_done mab_fail names all others)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (while (progn
           (setvar "ERRNO" 0)
           (initget "Zero")
           (setq sel (entsel (strcat "\n기준 객체를 클릭하세요 (그 레이어로 맞춤) [0 레이어로(Z) — 지금 블록 안은 "
                                     (if *mab_zero* "0 레이어 + ByLayer" "기준 레이어") "]: ")))
           (cond ((= sel "Zero") (setq *mab_zero* (not *mab_zero*)) T)
                 ((and (null sel) (= (getvar "ERRNO") 7)) (princ "\n빗나갔습니다. 다시 클릭하세요.") T))))
  (cond
    ((null sel) (princ "\n기준 객체를 고르지 않았습니다."))
    ((progn (setq lay (cdr (assoc 8 (entget (car sel)))))
            (prompt (strcat "\n[" lay "] 레이어로 맞출 블록을 고르세요 (잠긴 레이어는 빠짐): "))
            (null (setq ss (ssget "_:L" '((0 . "INSERT"))))))
     (princ "\n고른 블록이 없습니다."))
    (T
     (vla-StartUndoMark doc)
     (setq undo_open T i 0 n 0 mab_fail 0)
     (while (< i (sslength ss))
       (setq o (vlax-ename->vla-object (ssname ss i)))
       (vla-put-Layer o lay)
       (if (= (vla-get-HasAttributes o) :vlax-true)
         (foreach a (vlax-invoke o 'GetAttributes) (vl-catch-all-apply 'vla-put-Layer (list a lay))))
       (mab:fix-def doc (vla-get-Name o) lay)
       (if (/= (vla-get-Name o) (vla-get-EffectiveName o)) (mab:fix-def doc (vla-get-EffectiveName o) lay))
       (setq n (1+ n) i (1+ i)))
     ;; 같은 정의를 쓰는 다른 인스턴스 수
     (setq names (apply 'strcat (mapcar '(lambda (x) (strcat "," (mab:esc x))) mab_done)) others 0)
     (if (and (> (strlen names) 1) (setq all (ssget "_X" (list '(0 . "INSERT") (cons 2 (substr names 2))))))
       (progn (setq i 0)
              (while (< i (sslength all))
                (if (not (ssmemb (ssname all i) ss)) (setq others (1+ others)))
                (setq i (1+ i)))))
     (vla-Regen doc 1)
     (vla-EndUndoMark doc)
     (setq undo_open nil)
     (princ (strcat "\n[완료] 블록 " (itoa n) "개를 [" lay "] 레이어로, 블록 정의 " (itoa (length mab_done)) "개의 안을 "
                    (if *mab_zero* "0 레이어 + ByLayer 로" (strcat "[" lay "] 레이어로")) " 바꿨습니다."
                    (if (> others 0) (strcat " 같은 블록의 다른 인스턴스 " (itoa others) "개도 함께 바뀝니다"
                                             (if *mab_zero* " (모습은 각자 레이어를 따름)" "") ".") "")
                    (if (> mab_fail 0) (strcat "\n[주의] 블록 안 객체 " (itoa mab_fail) "개는 바꾸지 못했습니다.") "")))))
  (princ))

(princ)
