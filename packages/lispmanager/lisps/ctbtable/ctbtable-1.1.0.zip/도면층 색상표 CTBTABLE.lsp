;;; ==============================================================================
;;;  CTBTABLE — 도면층 색상표(CTB 대응표) 그리기
;;;
;;;  1_CEN … 13_SHEET 레이어 13개를 없을 때만 만들고(있는 레이어의 색·선 종류는 그대로), 클릭한 왼쪽 위 기준으로 표를 그린다.
;;;  글자 높이(기본 1000 = 1:100 · 기억)에 맞춰 표 전체 크기가 바뀐다. 지금 레이어는 바꾸지 않는다.
;;;  UCS 를 돌려 둔 화면에서도 화면 방향으로 그린다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun ctb:rows () '(("1_CEN" "CENTER" 1 "0.08" "중심선") ("2_CON" "CONTINUOUS" 2 "0.35" "골조, 구조체")
                 ("3_WALL" "CONTINUOUS" 3 "0.24" "일반 벽체") ("4_WIN" "CONTINUOUS" 4 "0.13" "창호 및 문")
                 ("5_ETC" "CONTINUOUS" 5 "0.10" "기타 (마감 등)") ("6_FUN" "CONTINUOUS" 6 "0.10" "가구 및 집기")
                 ("7_TEXT" "CONTINUOUS" 7 "0.18" "문자 및 치수") ("8_HAT" "CONTINUOUS" 8 "0.08" "해치")
                 ("9_ELE" "CONTINUOUS" 9 "0.10" "입면선") ("10_COL" "CONTINUOUS" 4 "기본값" "기둥")
                 ("11_DOT" "DOT" 7 "기본값" "점선 / 은선") ("12_GRI" "CONTINUOUS" 9 "기본값" "그리드")
                 ("13_SHEET" "CONTINUOUS" 40 "기본값" "도면틀 / 뷰포트")))

;; 레이어가 없을 때만 만든다
(defun ctb:layer (name lt col / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and (/= (strcase lt) "CONTINUOUS") (not (tblsearch "LTYPE" lt)))
    (vl-catch-all-apply 'vla-Load (list (vla-get-Linetypes doc) lt (if (= (getvar "MEASUREMENT") 1) "acadiso.lin" "acad.lin"))))
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 col) (cons 6 (if (tblsearch "LTYPE" lt) lt "Continuous"))))))

(defun c:CTBTABLE ( / *error* doc undo_open h k p0 rot w q made i r cy)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        h (if (getenv "HyCtbTextH") (atof (getenv "HyCtbTextH")) 1000.0))
  (initget 6)
  (setq h (cond ((getdist (strcat "\n글자 높이 (표 크기가 따라 바뀜) <" (rtos h 2 2) ">: "))) (h)))
  (setenv "HyCtbTextH" (rtos h 2 8))
  (if (setq p0 (getpoint "\n표의 왼쪽 위 점을 클릭하세요: "))
    (progn
      (setq k (/ h 1000.0)                                            ; 크기 비율 (1000 기준)
            rot (angle '(0 0 0) (trans '(1 0 0) 1 0 T)))                ; UCS X 방향
      ;; UCS 의 (dx, dy) 자리 → 월드 점
      (defun w (dx dy) (trans (list (+ (car p0) (* k dx)) (- (cadr p0) (* k dy)) (caddr p0)) 1 0))
      (defun q (dx dy s ht lay)
        (entmakex (list '(0 . "TEXT") (cons 8 lay) (cons 10 (w dx dy)) (cons 11 (w dx dy)) (cons 40 (* k ht))
                        (cons 1 s) (cons 50 rot) '(72 . 1) '(73 . 2))))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (foreach r (ctb:rows) (ctb:layer (nth 0 r) (nth 1 r) (nth 2 r)))
      ;; 바깥 테두리 · 가로선 15 · 세로선 4 (0 레이어)
      (entmake (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(8 . "0") '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
                     (cons 10 (w 0 0)) (cons 10 (w 56000 0)) (cons 10 (w 56000 48000)) (cons 10 (w 0 48000))))
      (setq i 1)
      (while (< i 15)
        (entmake (list '(0 . "LINE") '(8 . "0") (cons 10 (w 0 (* i 3200))) (cons 11 (w 56000 (* i 3200)))))
        (setq i (1+ i)))
      (foreach dx '(10000 24000 30000 38000)
        (entmake (list '(0 . "LINE") '(8 . "0") (cons 10 (w dx 3200)) (cons 11 (w dx 48000)))))
      ;; 글자
      (q 28000 1600 "CTB & LAYER SETTINGS" 1200 "0")
      (foreach c '((5000 "LAYER") (17000 "LINETYPE") (27000 "COLOR") (34000 "WIDTH") (47000 "비고"))
        (q (car c) 4800 (cadr c) 1000 "0"))
      (setq i 2)
      (foreach r (ctb:rows)
        (setq cy (+ (* i 3200) 1600))
        (q 5000 cy (nth 0 r) 1000 (nth 0 r))
        (q 17000 cy (nth 1 r) 1000 (nth 0 r))
        (q 27000 cy (itoa (nth 2 r)) 1000 (nth 0 r))
        (q 34000 cy (nth 3 r) 1000 (nth 0 r))
        (q 47000 cy (nth 4 r) 1000 (nth 0 r))
        (setq i (1+ i)))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 도면층 색상표를 그렸습니다 (글자 높이 " (rtos h 2 2) ", 없는 레이어만 새로 만듦).")))
    (princ "\n그만두었습니다."))
  (princ))

(princ)
