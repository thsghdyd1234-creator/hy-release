(defun c:CTBTABLE ( / old_echo old_osmode P0 X0 Y0 i r data cy lay_name c_idx)
  ;; 기존 시스템 변수 저장 및 에코/스냅 끄기
  (setq old_echo (getvar "CMDECHO"))
  (setq old_osmode (getvar "OSMODE"))
  (setvar "CMDECHO" 0)
  (setvar "OSMODE" 0)

  ;; 1. 필요 선종류(CENTER, DOT) 로드 시도
  (vl-load-com)
  (foreach ltype '("CENTER" "DOT")
    (if (null (tblsearch "LTYPE" ltype))
      (vl-catch-all-apply 'vla-load (list (vla-get-Linetypes (vla-get-activedocument (vlax-get-acad-object))) ltype "acad.lin"))
    )
  )

  ;; 2. 레이어 13개 실제 생성 및 설정
  (command "-layer"
    "m" "1_CEN"    "c" "1"  "" "l" "CENTER" ""
    "m" "2_CON"    "c" "2"  "" "l" "CONTINUOUS" ""
    "m" "3_WALL"   "c" "3"  "" "l" "CONTINUOUS" ""
    "m" "4_WIN"    "c" "4"  "" "l" "CONTINUOUS" ""
    "m" "5_ETC"    "c" "5"  "" "l" "CONTINUOUS" ""
    "m" "6_FUN"    "c" "6"  "" "l" "CONTINUOUS" ""
    "m" "7_TEXT"   "c" "7"  "" "l" "CONTINUOUS" ""
    "m" "8_HAT"    "c" "8"  "" "l" "CONTINUOUS" ""
    "m" "9_ELE"    "c" "9"  "" "l" "CONTINUOUS" ""
    "m" "10_COL"   "c" "4"  "" "l" "CONTINUOUS" ""
    "m" "11_DOT"   "c" "7"  "" "l" "DOT" ""
    "m" "12_GRI"   "c" "9"  "" "l" "CONTINUOUS" ""
    "m" "13_SHEET" "c" "40" "" "l" "CONTINUOUS" ""
    "s" "0" ; 레이어 생성을 마치고 현재 도면층을 '0'번으로 강제 변경
    ""
  )

  ;; 3. 표 작도를 위한 기준점 입력
  (setq P0 (getpoint "\n표를 삽입할 좌측 상단 기준점을 클릭하세요: "))
  (if P0
    (progn
      (setq X0 (car P0))
      (setq Y0 (cadr P0))

      ;; [선 그리기 - 0 레이어, 문자 높이 1000 기준 크기]
      ;; 전체 외곽선 (너비 56000, 총 높이 48000)
      (command "RECTANG" (list X0 Y0) (list (+ X0 56000.0) (- Y0 48000.0)))

      ;; 가로선 (행 구분선, 총 15행. 행 높이 3200)
      (setq i 1)
      (while (< i 15)
        (command "LINE" (list X0 (- Y0 (* i 3200.0))) (list (+ X0 56000.0) (- Y0 (* i 3200.0))) "")
        (setq i (1+ i))
      )

      ;; 세로선 (열 구분선)
      (foreach dx '(10000.0 24000.0 30000.0 38000.0)
        (command "LINE" (list (+ X0 dx) (- Y0 3200.0)) (list (+ X0 dx) (- Y0 48000.0)) "")
      )

      ;; [문자 삽입 함수 - 동적 레이어 적용]
      (defun make-text (cx cy str hgt lay)
        (entmakex (list
          '(0 . "TEXT")
          (cons 8 lay)        
          (cons 10 (list cx cy 0.0))
          (cons 11 (list cx cy 0.0))
          (cons 40 hgt)       
          (cons 1 str)        
          '(62 . 256)         ; 색상 BYLAYER 고정
          '(72 . 1)           
          '(73 . 2)           
        ))
      )

      ;; 제목(Title) 행 텍스트 (높이 1200)
      (make-text (+ X0 28000.0) (- Y0 1600.0) "CTB & LAYER SETTINGS" 1200.0 "0")
      
      ;; 머리글(Header) 행 텍스트 (높이 1000)
      (setq cy (- Y0 4800.0))
      (make-text (+ X0 5000.0) cy "LAYER" 1000.0 "0")
      (make-text (+ X0 17000.0) cy "LINETYPE" 1000.0 "0")
      (make-text (+ X0 27000.0) cy "COLOR" 1000.0 "0")
      (make-text (+ X0 34000.0) cy "WIDTH" 1000.0 "0")
      (make-text (+ X0 47000.0) cy "비고" 1000.0 "0")

      ;; 레이어 데이터 및 테이블 내용 (13개)
      (setq data '(
        ("1_CEN"    "CENTER"     "1"  "0.08"   "중심선")
        ("2_CON"    "CONTINUOUS" "2"  "0.35"   "골조, 구조체")
        ("3_WALL"   "CONTINUOUS" "3"  "0.24"   "일반 벽체")
        ("4_WIN"    "CONTINUOUS" "4"  "0.13"   "창호 및 문")
        ("5_ETC"    "CONTINUOUS" "5"  "0.10"   "기타 (마감 등)")
        ("6_FUN"    "CONTINUOUS" "6"  "0.10"   "가구 및 집기")
        ("7_TEXT"   "CONTINUOUS" "7"  "0.18"   "문자 및 치수")
        ("8_HAT"    "CONTINUOUS" "8"  "0.08"   "해치")
        ("9_ELE"    "CONTINUOUS" "9"  "0.10"   "입면선")
        ("10_COL"   "CONTINUOUS" "4"  "기본값" "기둥")
        ("11_DOT"   "DOT"        "7"  "기본값" "점선 / 은선")
        ("12_GRI"   "CONTINUOUS" "9"  "기본값" "그리드")
        ("13_SHEET" "CONTINUOUS" "40" "기본값" "도면틀 / 뷰포트")
      ))

      ;; 데이터 문자를 각 레이어에 맞춰 삽입 (높이 1000)
      (setq r 2)
      (foreach item data
        (setq cy (- Y0 (* r 3200.0) 1600.0))
        (setq lay_name (nth 0 item)) 
        
        (make-text (+ X0 5000.0) cy (nth 0 item) 1000.0 lay_name)
        (make-text (+ X0 17000.0) cy (nth 1 item) 1000.0 lay_name)
        (make-text (+ X0 27000.0) cy (nth 2 item) 1000.0 lay_name)
        (make-text (+ X0 34000.0) cy (nth 3 item) 1000.0 lay_name)
        (make-text (+ X0 47000.0) cy (nth 4 item) 1000.0 lay_name)
        (setq r (1+ r))
      )

      (princ "\n[완료] 문자 높이 1000 기준 도면층 표를 만들었습니다.")
    )
    (princ "\n작업이 취소되었습니다.")
  )

  ;; 시스템 변수 원상 복구
  (setvar "OSMODE" old_osmode)
  (setvar "CMDECHO" old_echo)
  (princ)
)