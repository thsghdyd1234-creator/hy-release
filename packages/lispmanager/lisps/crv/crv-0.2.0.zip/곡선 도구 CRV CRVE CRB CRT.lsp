;;; ============================================================
;;; 곡선 도구 CRV CRVE CRB CRT.lsp
;;; 일러스트레이터 곡률 도구처럼 캐드 곡선 그리기·편집 + 곡선 잇기·접선 도구
;;;
;;; 명령
;;;   CRV   곡선 그리기
;;;   CRVE  곡선 편집 (CRV로 만든 곡선 + 일반 폴리선·선·호·원·스플라인)
;;;   CRB   블렌드 - 두 곡선 끝을 매끈하게 잇기 (호 2개 / 곡률까지 잇는 스플라인, BLEND 대신)
;;;   CRT   접선 - 점→원 / 두 원 공통접선 / 기존 선을 원에 붙이기
;;;
;;; CRV  그리기
;;;   클릭              점 추가 (찍은 점을 모두 지나도록 곡선이 알아서 휨)
;;;   더블클릭 / X       방금 찍은 점을 꺾인 점으로 (한 번 더 하면 매끈한 점)
;;;   첫 점 클릭 / C     닫기
;;;   U / Backspace     마지막 점 취소
;;;   Enter·Space·우클릭 완료
;;;   좌표 입력          x,y   @dx,dy   @거리<각도   거리(커서 방향)
;;;
;;; CRVE  편집
;;;   점 클릭 → 이동 → 클릭   점 옮기기 (캐드 그립 방식, 좌표 입력 가능)
;;;   점 더블클릭 / X        매끈 ↔ 꺾임 전환
;;;   곡선 위 클릭           점 추가
;;;   D / Backspace         커서 아래 점 삭제
;;;   C 닫기 전환   U 되돌리기   Esc 편집 전체 취소(원래대로)
;;;   Enter·Space·우클릭     옮기던 점이 있으면 그 자리에 놓기, 없으면 완료
;;;
;;; 공통 옵션
;;;   O  출력: 폴리선(호 근사, 기본) / 스플라인(미리보기 모양 그대로)
;;;   T  장력: 1.0 기본, 작을수록 팽팽하게 / 클수록 둥글게
;;;
;;; 곡선 규칙: 매끈한 점은 앞·뒤 점과 함께 지나는 원의 접선을 따름
;;;            → 한 원 위의 점들은 정확한 원호(반지름 그대로)로 나옴
;;; 점 표시: ○ 매끈한 점  □ 꺾인 점
;;; 찍은 점과 종류는 객체 XDATA(HY_CURVE)에 저장되어
;;; 이동·회전·축척·대칭 후에도 처음 찍은 점 그대로 다시 편집됨
;;; CRB  블렌드 (두 곡선을 이을 끝 쪽으로 차례로 클릭, 같은 곡선 양 끝 = 닫힌 모양)
;;;   스플라인이 끼면 스플라인 블렌드, 선·호·폴리선끼리는 호 블렌드가 기본 (S로 전환)
;;;   호 블렌드      호 두 개, 끝에서 접선 유지, 결과 = 폴리선
;;;                  가운데 점 클릭 → 이동 → 클릭으로 모양 조절
;;;                  기본 모양 = 한쪽으로만 도는 가장 완만한 모양 (한 원호 / 직선+호), 필요할 때만 S자
;;;   스플라인 블렌드 3차 스플라인, 곡률까지 이어짐(G2, G로 G1 전환), 결과 = 스플라인
;;;                  양 끝 핸들 클릭 → 이동 → 클릭으로 모양 조절 (일러스트 핸들처럼)
;;;   D 기본 모양   J 원래 곡선과 합치기 켬/끔   (J·G 설정은 기억됨)
;;;   그 밖 클릭·Enter·우클릭 확정
;;;
;;; CRT  접선
;;;   원·호(폴리선 호 구간도)를 접점이 생길 쪽에서 클릭 → 시작점 클릭 = 접선
;;;   F 반대쪽 접점   C 두 번째 원과 공통접선 (4개 중 커서 가까운 것)
;;;   L 기존 선(LINE·폴리선 직선 끝 구간)을 원에 붙이기: 고정끝 기준 회전(R) / 평행이동(P)
;;;
;;; 설정 파일: %APPDATA%\hy\CRV.json  (없으면 기본값 / 리습매니저 연동용)
;;; ============================================================

(vl-load-com)

(setq *crv-ver* "0.2.0"
      *crv-app* "HY_CURVE")

;;; ============================================================
;;;  설정 (CRV.json)
;;; ============================================================
(defun crv:cfg-path (/ ad)
  (if (setq ad (getenv "APPDATA")) (strcat ad "\\hy\\CRV.json")))

(defun crv:json-read (path / f ln s)
  (if (setq f (open path "r"))
    (progn
      (setq s "")
      (while (setq ln (read-line f)) (setq s (strcat s ln " ")))
      (close f)
      (crv:json-parse s))))

;; 평면 JSON 객체 {"키": 값, ...} → (("키" . 값) ...)
(defun crv:json-parse (s / i n c w toks res)
  (setq i 1 n (strlen s))
  (while (<= i n)
    (setq c (substr s i 1))
    (cond
      ((= c "\"")
       (setq w "" i (1+ i))
       (while (and (<= i n) (/= (setq c (substr s i 1)) "\""))
         (if (and (= c "\\") (< i n)) (setq i (1+ i) c (substr s i 1)))
         (setq w (strcat w c) i (1+ i)))
       (setq toks (cons (list 'S w) toks) i (1+ i)))
      ((member c '("{" "}" ":" ",")) (setq toks (cons c toks) i (1+ i)))
      ((member c '(" " "\t" "\n" "\r")) (setq i (1+ i)))
      (t
       (setq w "")
       (while (and (<= i n) (not (member (setq c (substr s i 1)) '("{" "}" ":" "," " " "\t" "\n" "\r"))))
         (setq w (strcat w c) i (1+ i)))
       (setq toks (cons (list 'W w) toks)))))
  (setq toks (reverse toks))
  (while toks
    (if (and (listp (car toks)) (car toks) (eq (car (car toks)) 'S) (equal (cadr toks) ":"))
      (setq res (cons (cons (cadr (car toks)) (crv:json-val (caddr toks))) res)
            toks (cdddr toks))
      (setq toks (cdr toks))))
  (reverse res))

(defun crv:json-val (v / w)
  (cond
    ((or (null v) (not (listp v))) nil)
    ((eq (car v) 'S) (cadr v))
    ((equal (setq w (cadr v)) "true") t)
    ((member w '("false" "null")) nil)
    ((or (vl-string-search "." w) (vl-string-search "e" w) (vl-string-search "E" w)) (atof w))
    (t (atoi w))))

;; 숫자 → JSON 문자열 (DIMZIN과 상관없이 0.5 형태)
(defun crv:fmt (x / s)
  (setq s (rtos x 2 4))
  (cond ((= (substr s 1 1) ".") (strcat "0" s))
        ((= (substr s 1 2) "-.") (strcat "-0" (substr s 2)))
        (t s)))

(defun crv:num (v df lo hi)
  (if (numberp v) (max lo (min hi v)) df))

(defun crv:cfg-load (/ p lst o)
  (setq p (crv:cfg-path))
  (if (and p (findfile p)) (setq lst (crv:json-read p)))
  (setq o (cdr (assoc "output" lst)))
  (setq *crv-out*    (if (and (eq (type o) 'STR) (= (strcase o t) "spline")) "spline" "pline")
        *crv-ten*    (float (crv:num (cdr (assoc "tension" lst)) 1.0 0.3 2.0))
        *crv-tolset* (float (crv:num (cdr (assoc "tolerance" lst)) 0.0 0.0 1.0e9))
        *crv-pcol*   (fix (crv:num (cdr (assoc "preview_color" lst)) 4 1 255))
        *crv-acol*   (fix (crv:num (cdr (assoc "anchor_color" lst)) 2 1 255))
        *crv-dbl*    (fix (crv:num (cdr (assoc "dblclick_ms" lst)) 400 150 1000))
        *crv-bjoin*  (if (equal (cdr (assoc "blend_join" lst)) 0) 0 1)
        *crv-bg2*    (if (equal (cdr (assoc "blend_g2" lst)) 0) 0 1)))

(defun crv:cfg-save (/ p f dir)
  (if (setq p (crv:cfg-path))
    (progn
      (setq dir (vl-filename-directory p))
      (if (not (vl-file-directory-p dir)) (vl-mkdir dir))
      (if (setq f (open p "w"))
        (progn
          (write-line "{" f)
          (write-line (strcat "  \"output\": \"" *crv-out* "\",") f)
          (write-line (strcat "  \"tension\": " (crv:fmt *crv-ten*) ",") f)
          (write-line (strcat "  \"tolerance\": " (crv:fmt *crv-tolset*) ",") f)
          (write-line (strcat "  \"preview_color\": " (itoa *crv-pcol*) ",") f)
          (write-line (strcat "  \"anchor_color\": " (itoa *crv-acol*) ",") f)
          (write-line (strcat "  \"dblclick_ms\": " (itoa *crv-dbl*) ",") f)
          (write-line (strcat "  \"blend_join\": " (itoa *crv-bjoin*) ",") f)
          (write-line (strcat "  \"blend_g2\": " (itoa *crv-bg2*)) f)
          (write-line "}" f)
          (close f))))))

;;; ============================================================
;;;  벡터 (UCS 2D)
;;; ============================================================
(defun crv:v+ (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))
(defun crv:v- (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun crv:vx (a s) (list (* (car a) s) (* (cadr a) s)))
(defun crv:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun crv:crs (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
(defun crv:len (a) (sqrt (crv:dot a a)))
(defun crv:dist (a b) (crv:len (crv:v- a b)))
(defun crv:unit (a / d) (if (> (setq d (crv:len a)) 1e-12) (crv:vx a (/ 1.0 d))))
(defun crv:lnorm (a) (list (- (cadr a)) (car a)))          ; 왼쪽 법선
(defun crv:mid (a b) (list (* 0.5 (+ (car a) (car b))) (* 0.5 (+ (cadr a) (cadr b)))))
(defun crv:2d (p) (list (car p) (cadr p)))
(defun crv:3 (p) (list (car p) (cadr p) *crv-z*))

(defun crv:near-seg (p a b / ab l2 s)
  (setq ab (crv:v- b a) l2 (crv:dot ab ab))
  (if (< l2 1e-24)
    a
    (progn
      (setq s (max 0.0 (min 1.0 (/ (crv:dot (crv:v- p a) ab) l2))))
      (crv:v+ a (crv:vx ab s)))))

(defun crv:d-seg (p a b) (crv:dist p (crv:near-seg p a b)))

(defun crv:ang-norm (a / tp)
  (setq tp (* 2.0 pi) a (rem a tp))
  (if (< a 0.0) (+ a tp) a))

(defun crv:cross3 (a b)
  (list (- (* (cadr a) (caddr b)) (* (caddr a) (cadr b)))
        (- (* (caddr a) (car b)) (* (car a) (caddr b)))
        (- (* (car a) (cadr b)) (* (cadr a) (car b)))))

(defun crv:len3 (a) (sqrt (+ (* (car a) (car a)) (* (cadr a) (cadr a)) (* (caddr a) (caddr a)))))

;;; ============================================================
;;;  앵커 (x y 종류)   종류 0 = 매끈 / 1 = 꺾임
;;; ============================================================
(defun crv:mk (p c) (list (float (car p)) (float (cadr p)) c))
(defun crv:apt (a) (list (car a) (cadr a)))
(defun crv:corner-p (a) (= 1 (caddr a)))

(defun crv:toggle (as k / i res)
  (setq i 0)
  (foreach a as
    (setq res (cons (if (= i k) (list (car a) (cadr a) (- 1 (caddr a))) a) res)
          i (1+ i)))
  (reverse res))

(defun crv:setpt (as k p / i res)
  (setq i 0)
  (foreach a as
    (setq res (cons (if (= i k) (list (float (car p)) (float (cadr p)) (caddr a)) a) res)
          i (1+ i)))
  (reverse res))

(defun crv:insert (as k p / i res)
  (setq i 0)
  (foreach a as
    (setq res (cons a res))
    (if (= i k) (setq res (cons (crv:mk p 0) res)))
    (setq i (1+ i)))
  (reverse res))

(defun crv:del (as k / i res)
  (if (> (length as) 2)
    (progn
      (setq i 0)
      (foreach a as
        (if (/= i k) (setq res (cons a res)))
        (setq i (1+ i)))
      (reverse res))
    (progn (princ "\n점이 2개 이상 있어야 합니다.") as)))

;;; ============================================================
;;;  곡선 계산 : 앵커 → 베지에
;;;  매끈한 점의 접선 = 앞·뒤 점과 함께 지나는 원의 접선
;;;  핸들 길이 = 그 원호를 베지에로 옮길 때의 길이 (세 점이 원 위면 정확한 원호)
;;; ============================================================

;; 점마다 접선 (꺾인 점·열린 끝 = nil)
(defun crv:tangents (as closed / n i pv nx v1 v2 a2 c2 s lim res)
  (setq n (length as) i 0)
  (foreach a as
    (setq s nil)
    (if (and (> n 1) (not (crv:corner-p a)) (or closed (and (> i 0) (< i (1- n)))))
      (progn
        (setq pv (crv:apt (nth (if (= i 0) (1- n) (1- i)) as))
              nx (crv:apt (nth (if (= i (1- n)) 0 (1+ i)) as))
              v1 (crv:v- (crv:apt a) pv)
              v2 (crv:v- nx (crv:apt a))
              a2 (crv:dot v1 v1)
              c2 (crv:dot v2 v2))
        (cond
          ((and (< a2 1e-20) (< c2 1e-20)) (setq s nil))
          ((< a2 1e-20) (setq s (crv:unit v2)))
          ((< c2 1e-20) (setq s (crv:unit v1)))
          (t
           (setq s   (crv:v+ (crv:vx v1 (/ 1.0 a2)) (crv:vx v2 (/ 1.0 c2)))
                 lim (* 1e-9 (+ (/ 1.0 (sqrt a2)) (/ 1.0 (sqrt c2)))))
           (setq s (if (> (crv:len s) lim) (crv:unit s) (crv:unit (crv:lnorm v1))))))))
    (setq res (cons s res) i (1+ i)))
  (reverse res))

;; 현(u)에 대해 접선 반사 = 같은 원호의 반대쪽 끝 접선
(defun crv:refl (tg u) (crv:v- (crv:vx u (* 2.0 (crv:dot tg u))) tg))

;; 원호 핸들 길이: 현 길이 d, 접선과 현이 이루는 각 α → 2d / 3(1+cosα)  (반원에서 상한)
(defun crv:hlen (d tg u ten)
  (* ten (/ (* 2.0 d) (* 3.0 (+ 1.0 (max 0.0 (min 1.0 (crv:dot tg u))))))))

;; 구간 하나 → (p0 c0 c1 p1 직선여부)
(defun crv:seg (p0 t0 p1 t1 ten / ch d u)
  (setq ch (crv:v- p1 p0) d (crv:len ch))
  (cond
    ((< d 1e-12) (list p0 p0 p1 p1 t))
    ((and (null t0) (null t1))
     (list p0 (crv:v+ p0 (crv:vx ch (/ 1.0 3.0))) (crv:v+ p0 (crv:vx ch (/ 2.0 3.0))) p1 t))
    (t
     (setq u (crv:vx ch (/ 1.0 d)))
     (if (null t0) (setq t0 (crv:refl t1 u)))
     (if (null t1) (setq t1 (crv:refl t0 u)))
     (list p0
           (crv:v+ p0 (crv:vx t0 (crv:hlen d t0 u ten)))
           (crv:v- p1 (crv:vx t1 (crv:hlen d t1 u ten)))
           p1
           nil))))

;; 앵커 목록 → 베지에 구간 목록
(defun crv:bez (as closed ten / n tg i j res)
  (setq n (length as))
  (if (> n 1)
    (progn
      (setq tg (crv:tangents as closed) i 0)
      (repeat (if closed n (1- n))
        (setq j   (if (= i (1- n)) 0 (1+ i))
              res (cons (crv:seg (crv:apt (nth i as)) (nth i tg) (crv:apt (nth j as)) (nth j tg) ten) res)
              i   (1+ i)))
      (reverse res))))

;; 베지에 위의 점 (0~1)
(defun crv:bpt (b s / m)
  (setq m (- 1.0 s))
  (crv:v+ (crv:v+ (crv:vx (car b) (* m m m)) (crv:vx (cadr b) (* 3.0 m m s)))
          (crv:v+ (crv:vx (caddr b) (* 3.0 m s s)) (crv:vx (cadddr b) (* s s s)))))

;; 구간 → 점 n개 (시작점 제외)  원호 구간은 진짜 원호 위의 점
(defun crv:tess (b n / i bu res)
  (cond
    ((nth 4 b) (list (cadddr b)))
    ((setq bu (crv:circ-b b))
     (setq i 1)
     (repeat n
       (setq res (cons (crv:arc-at (car b) (cadddr b) bu (/ (float i) n)) res) i (1+ i)))
     (reverse res))
    (t
     (setq i 1)
     (repeat n
       (setq res (cons (crv:bpt b (/ (float i) n)) res) i (1+ i)))
     (reverse res))))

;; 화면 표시용 분할 수 (픽셀 기준)
(defun crv:nseg (b px)
  (if (nth 4 b)
    1
    (fix (min 64.0 (max 2.0 (/ (+ (crv:dist (car b) (cadr b))
                                   (crv:dist (cadr b) (caddr b))
                                   (crv:dist (caddr b) (cadddr b)))
                                (* 4.0 px)))))))

(defun crv:path-pts (bz px / res)
  (if bz (setq res (list (car (car bz)))))
  (foreach b bz
    (foreach q (crv:tess b (crv:nseg b px)) (setq res (cons q res))))
  (reverse res))

;; 베지에 반으로 나누기
(defun crv:split (b / q0 q1 q2 r0 r1 s)
  (setq q0 (crv:mid (car b) (cadr b))
        q1 (crv:mid (cadr b) (caddr b))
        q2 (crv:mid (caddr b) (cadddr b))
        r0 (crv:mid q0 q1)
        r1 (crv:mid q1 q2)
        s  (crv:mid r0 r1))
  (list (list (car b) q0 r0 s nil) (list s r1 q2 (cadddr b) nil)))

;; 시작·끝 접선
(defun crv:btan0 (b)
  (cond ((crv:unit (crv:v- (cadr b) (car b))))
        ((crv:unit (crv:v- (caddr b) (car b))))
        ((crv:unit (crv:v- (cadddr b) (car b))))))

(defun crv:btan1 (b)
  (cond ((crv:unit (crv:v- (cadddr b) (caddr b))))
        ((crv:unit (crv:v- (cadddr b) (cadr b))))
        ((crv:unit (crv:v- (cadddr b) (car b))))))

;;; ============================================================
;;;  폴리선 출력 : 베지에 → 호 (바이아크 + 오차 검사 + 같은 원 합치기)
;;; ============================================================

;; 볼록 호 → (중심 반지름 시작각 사이각), 직선이면 nil
(defun crv:arc-geo (s e bu / th c cc)
  (if (> (abs bu) 1e-12)
    (progn
      (setq th (* 4.0 (atan bu)) c (crv:v- e s))
      (if (> (crv:len c) 1e-14)
        (progn
          (setq cc (crv:v+ (crv:mid s e)
                           (crv:vx (crv:lnorm c) (* 0.5 (/ (cos (* 0.5 th)) (sin (* 0.5 th)))))))
          (list cc (crv:dist cc s) (angle cc s) th))))))

;; 호 위의 점 (비율 f)
(defun crv:arc-at (s e bu f / g a)
  (if (setq g (crv:arc-geo s e bu))
    (progn
      (setq a (+ (caddr g) (* f (cadddr g))))
      (list (+ (car (car g)) (* (cadr g) (cos a))) (+ (cadr (car g)) (* (cadr g) (sin a)))))
    (crv:v+ s (crv:vx (crv:v- e s) f))))

;; 점 → 호(또는 직선) 거리
(defun crv:d-arc (p s e bu / g f)
  (if (setq g (crv:arc-geo s e bu))
    (progn
      (setq f (if (> (cadddr g) 0.0)
                (crv:ang-norm (- (angle (car g) p) (caddr g)))
                (crv:ang-norm (- (caddr g) (angle (car g) p)))))
      (if (<= f (abs (cadddr g)))
        (abs (- (crv:dist p (car g)) (cadr g)))
        (min (crv:dist p s) (crv:dist p e))))
    (crv:d-seg p s e)))

;; 시작 접선 기준 볼록 / 끝 접선 기준 볼록 (뒤를 향하면 nil)
(defun crv:bulge-s (s e tg / c a)
  (setq c (crv:v- e s))
  (if (< (crv:len c) 1e-12)
    0.0
    (if (< (abs (setq a (atan (crv:crs tg c) (crv:dot tg c)))) (* 0.98 pi))
      (/ (sin (* 0.5 a)) (cos (* 0.5 a))))))

(defun crv:bulge-e (s e tg / c a)
  (setq c (crv:v- e s))
  (if (< (crv:len c) 1e-12)
    0.0
    (if (< (abs (setq a (atan (crv:crs c tg) (crv:dot c tg)))) (* 0.98 pi))
      (/ (sin (* 0.5 a)) (cos (* 0.5 a))))))

;; 바이아크: 양 끝 접선을 지키는 호 두 개 → ((시작점 볼록) (중간점 볼록))
(defun crv:biarc (b / p1 p2 t1 t2 v tt den vt s d pm b1 b2)
  (setq p1 (car b) p2 (cadddr b) t1 (crv:btan0 b) t2 (crv:btan1 b))
  (if (and t1 t2 (> (crv:dist p1 p2) 1e-12))
    (progn
      (setq v   (crv:v- p2 p1)
            tt  (crv:v+ t1 t2)
            den (* 2.0 (- 1.0 (crv:dot t1 t2)))
            vt  (crv:dot v tt)
            s   (sqrt (max 0.0 (+ (* vt vt) (* den (crv:dot v v))))))
      (setq d (if (>= vt 0.0)
                (if (> (+ vt s) 1e-14) (/ (crv:dot v v) (+ vt s)))
                (if (> den 1e-14) (/ (- s vt) den))))
      (if (and d (> d 1e-12))
        (progn
          (setq pm (crv:vx (crv:v+ (crv:v+ p1 p2) (crv:vx (crv:v- t1 t2) d)) 0.5)
                b1 (crv:bulge-s p1 pm t1)
                b2 (crv:bulge-e pm p2 t2))
          (if (and b1 b2) (list (list p1 b1) (list pm b2))))))))

(defun crv:d-arcs (p arcs pe / best i n e d)
  (setq n (length arcs) i 0)
  (foreach a arcs
    (setq e    (if (< i (1- n)) (car (nth (1+ i) arcs)) pe)
          d    (crv:d-arc p (car a) e (cadr a))
          best (if best (min best d) d)
          i    (1+ i)))
  best)

(defun crv:d-poly (p poly / best d)
  (while (cdr poly)
    (setq d    (crv:d-seg p (car poly) (cadr poly))
          best (if best (min best d) d)
          poly (cdr poly)))
  (if best best 0.0))

;; 베지에와 호 목록 사이 최대 거리 (양쪽에서 표본)
(defun crv:dev (b arcs / mx i n pe poly e)
  (setq mx 0.0 i 1 pe (cadddr b))
  (repeat 15
    (setq mx (max mx (crv:d-arcs (crv:bpt b (/ i 16.0)) arcs pe)) i (1+ i)))
  (setq poly (cons (car b) (crv:tess b 64)) n (length arcs) i 0)
  (foreach a arcs
    (setq e (if (< i (1- n)) (car (nth (1+ i) arcs)) pe))
    (foreach f '(0.2 0.4 0.6 0.8)
      (setq mx (max mx (crv:d-poly (crv:arc-at (car a) e (cadr a) f) poly))))
    (setq i (1+ i)))
  mx)

;; 거의 직선인 베지에
(defun crv:flat-p (b tol / p0 ch l2 lim ok k)
  (setq p0 (car b) ch (crv:v- (cadddr b) p0) l2 (crv:dot ch ch) lim (* 0.25 tol) ok t)
  (if (< l2 1e-24)
    nil
    (progn
      (foreach c (list (cadr b) (caddr b))
        (setq k (/ (crv:dot ch (crv:v- c p0)) l2))
        (if (or (> (abs (/ (crv:crs ch (crv:v- c p0)) (sqrt l2))) lim) (< k -1e-6) (> k 1.000001))
          (setq ok nil)))
      ok)))

;; 원호로 만든 구간인지 (양 끝 접선이 현에 대칭 + 원호 핸들 길이) → 정확한 호 하나로 출력
(defun crv:circ-p (b / u t0 t1 a0 d h)
  (and (setq u (crv:unit (crv:v- (cadddr b) (car b))))
       (setq t0 (crv:unit (crv:v- (cadr b) (car b))))
       (setq t1 (crv:unit (crv:v- (cadddr b) (caddr b))))
       (< (abs (- (setq a0 (atan (crv:crs t0 u) (crv:dot t0 u))) (atan (crv:crs u t1) (crv:dot u t1)))) 1e-9)
       (<= (abs a0) (+ (* 0.5 pi) 1e-9))
       (setq d (crv:dist (car b) (cadddr b)) h (/ (* 2.0 d) (* 3.0 (+ 1.0 (cos a0)))))
       (< (abs (- (crv:dist (car b) (cadr b)) h)) (* 1e-9 d))
       (< (abs (- (crv:dist (caddr b) (cadddr b)) h)) (* 1e-9 d))))

;; 원호 구간이면 그 볼록값, 아니면 nil
(defun crv:circ-b (b)
  (if (and (not (nth 4 b)) (crv:circ-p b)) (crv:bulge-s (car b) (cadddr b) (crv:btan0 b))))

;; 호 → 3차 베지에 조각들 (90° 이하씩, 스플라인 출력용)
(defun crv:arc-bez (s e bu / g cc r th k i a1 a2 h p0 p1 res)
  (setq g  (crv:arc-geo s e bu)
        cc (car g) r (cadr g) th (cadddr g)
        k  (max 1 (fix (+ 0.999999 (/ (abs th) (* 0.5 pi)))))
        i  0)
  (repeat k
    (setq a1  (+ (caddr g) (* th (/ (float i) k)))
          a2  (+ (caddr g) (* th (/ (float (1+ i)) k)))
          h   (* r (/ 4.0 3.0) (/ (sin (/ (- a2 a1) 4.0)) (cos (/ (- a2 a1) 4.0))))
          p0  (if (= i 0) s (list (+ (car cc) (* r (cos a1))) (+ (cadr cc) (* r (sin a1)))))
          p1  (if (= i (1- k)) e (list (+ (car cc) (* r (cos a2))) (+ (cadr cc) (* r (sin a2)))))
          res (cons (list p0
                          (crv:v+ p0 (crv:vx (list (- (sin a1)) (cos a1)) h))
                          (crv:v- p1 (crv:vx (list (- (sin a2)) (cos a2)) h))
                          p1
                          nil)
                    res)
          i   (1+ i)))
  (reverse res))

;; 베지에 → 호 목록 ((시작점 볼록) ...)  허용오차 tol 안에 들 때까지 나눔
(defun crv:fit (b tol dep / arcs sp bu)
  (cond
    ((nth 4 b) (list (list (car b) 0.0)))
    ((crv:flat-p b tol) (list (list (car b) 0.0)))
    ((setq bu (crv:circ-b b)) (list (list (car b) bu)))
    ((and (setq arcs (crv:biarc b)) (<= (crv:dev b arcs) tol)) arcs)
    ((> dep 0)
     (setq sp (crv:split b))
     (append (crv:fit (car sp) tol (1- dep)) (crv:fit (cadr sp) tol (1- dep))))
    (arcs arcs)
    (t (list (list (car b) 0.0)))))

;; 구간 가운데 점
(defun crv:seg-mid (s e bu) (crv:arc-at s e bu 0.5))

;; 이어진 두 구간을 하나로 (직선+직선 / 같은 원 위의 호+호) → 새 볼록 또는 nil
(defun crv:try-merge (cs ne cb nb smp tol / th bu ok)
  (cond
    ((and (< (abs cb) 1e-9) (< (abs nb) 1e-9)) (setq bu 0.0))
    ((and (>= (abs cb) 1e-9) (>= (abs nb) 1e-9) (> (* cb nb) 0.0))
     (setq th (+ (* 4.0 (atan cb)) (* 4.0 (atan nb))))
     (if (<= (abs th) (+ pi 1e-6))
       (setq bu (/ (sin (/ th 4.0)) (cos (/ th 4.0)))))))
  (if bu
    (progn
      (setq ok t)
      (foreach p smp
        (if (and ok (> (crv:d-arc p cs ne bu) (* 0.5 tol))) (setq ok nil)))
      (if ok bu))))

;; 정점 ((점 볼록 고정) ...) 에서 합칠 수 있는 구간 합치기 (고정 정점 = 꺾인 점·끝점은 유지)
(defun crv:pl-merge (vs closed tol / n i v nx out smp cs cb cand)
  (setq n (length vs))
  (if (< n 3)
    vs
    (progn
      (setq out (list (car vs))
            smp (list (crv:seg-mid (car (car vs)) (car (cadr vs)) (cadr (car vs))))
            i   1)
      (while (< i n)
        (setq v    (nth i vs)
              nx   (cond ((< i (1- n)) (car (nth (1+ i) vs))) (closed (car (car vs))))
              cs   (car (car out))
              cb   (cadr (car out))
              cand nil)
        (if (and nx (not (caddr v)))
          (setq cand (crv:try-merge cs nx cb (cadr v)
                                    (cons (car v) (cons (crv:seg-mid (car v) nx (cadr v)) smp))
                                    tol)))
        (if cand
          (setq out (cons (list cs cand (caddr (car out))) (cdr out))
                smp (cons (car v) (cons (crv:seg-mid (car v) nx (cadr v)) smp)))
          (setq out (cons v out)
                smp (if nx (list (crv:seg-mid (car v) nx (cadr v))))))
        (setq i (1+ i)))
      (reverse out))))

;; 같은 자리 정점 정리
(defun crv:pl-dedup (vs closed / out)
  (foreach v vs
    (if (and out (< (crv:dist (car v) (car (car out))) 1e-9))
      (setq out (cons (list (car v) (cadr v) (if (or (caddr v) (caddr (car out))) t)) (cdr out)))
      (setq out (cons v out))))
  (setq out (reverse out))
  (if (and closed (cdr out) (< (crv:dist (car (last out)) (car (car out))) 1e-9))
    (setq out (reverse (cdr (reverse out)))))
  out)

;; 베지에 목록 → 폴리선 정점 ((점 볼록 고정) ...)
(defun crv:bez->pl (bz closed tol locks / vs lk pcs)
  (foreach b bz
    (setq lk    (car locks)
          locks (cdr locks)
          pcs   (crv:fit b tol 10)
          vs    (cons (list (car (car pcs)) (cadr (car pcs)) lk) vs))
    (foreach x (cdr pcs) (setq vs (cons (list (car x) (cadr x) nil) vs))))
  (if (not closed) (setq vs (cons (list (cadddr (last bz)) 0.0 t) vs)))
  (crv:pl-merge (crv:pl-dedup (reverse vs) closed) closed tol))

;; 앵커마다 고정 여부 (꺾인 점, 시작점)
(defun crv:locks (as / i res)
  (setq i 0)
  (foreach a as
    (setq res (cons (if (or (crv:corner-p a) (= i 0)) t) res) i (1+ i)))
  (reverse res))

;; 베지에 목록 → 스플라인 (조정점 매듭)  매듭 3중 = 베지에 그대로, 꺾인 점 가능
;; 원호 구간은 90° 이하 조각으로 나눠 원에 가깝게
(defun crv:bez->spl (bz / pcs bu n cvs kn i)
  (foreach b bz
    (if (setq bu (crv:circ-b b))
      (foreach x (crv:arc-bez (car b) (cadddr b) bu) (setq pcs (cons x pcs)))
      (setq pcs (cons b pcs))))
  (setq pcs (reverse pcs) n (length pcs))
  (foreach b pcs (setq cvs (cons (caddr b) (cons (cadr b) (cons (car b) cvs)))))
  (setq cvs (reverse (cons (cadddr (last pcs)) cvs))
        kn  (list 0.0 0.0 0.0 0.0)
        i   1)
  (repeat (1- n)
    (setq kn (cons (float i) (cons (float i) (cons (float i) kn))) i (1+ i)))
  (setq kn (reverse (cons (float n) (cons (float n) (cons (float n) (cons (float n) kn))))))
  (list cvs kn))

;; 폴리선 근사 허용오차 (설정 0 = 곡선 크기의 1/10000)
(defun crv:tol (as / xs ys dx dy)
  (if (> *crv-tolset* 0.0)
    *crv-tolset*
    (progn
      (setq xs (mapcar 'car as) ys (mapcar 'cadr as)
            dx (- (apply 'max xs) (apply 'min xs))
            dy (- (apply 'max ys) (apply 'min ys)))
      (max 1e-8 (* 1e-4 (sqrt (+ (* dx dx) (* dy dy))))))))

;;; ============================================================
;;;  객체 데이터 (DXF)
;;; ============================================================
(defun crv:ucsz () (trans '(0.0 0.0 1.0) 1 0 t))
(defun crv:w (p) (trans (list (car p) (cadr p) *crv-z*) 1 0))

;; XDATA : CRV1, 닫힘, 출력, 장력, 오차(축척 따라감), { 점(1011, 객체 따라 이동) 종류 ... }
(defun crv:xd (as closed out ten tol / res)
  (if (<= (length as) 400)
    (progn
      (setq res (list '(1002 . "}")))
      (foreach a (reverse as)
        (setq res (cons (cons 1011 (crv:w a)) (cons (cons 1070 (caddr a)) res))))
      (setq res (append (list (cons 1000 "CRV1")
                              (cons 1070 (if closed 1 0))
                              (cons 1070 (if (= out "spline") 1 0))
                              (cons 1040 (float ten))
                              (cons 1041 (float tol))
                              (cons 1002 "{"))
                        res))
      (list (list -3 (cons *crv-app* res))))))

(defun crv:dxf-pl (vs closed props xd / nrm vo)
  (setq nrm (crv:ucsz)
        vo  (mapcar '(lambda (v) (cons (trans (list (car (car v)) (cadr (car v)) *crv-z*) 1 nrm) (cadr v))) vs))
  (append
    (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity"))
    props
    (list '(100 . "AcDbPolyline")
          (cons 90 (length vo))
          (cons 70 (if closed 1 0))
          (cons 38 (caddr (car (car vo)))))
    (apply 'append (mapcar '(lambda (v) (list (list 10 (car (car v)) (cadr (car v))) (cons 42 (cdr v)))) vo))
    (list (cons 210 nrm))
    xd))

(defun crv:dxf-spl (bz props xd / s)
  (setq s (crv:bez->spl bz))
  (append
    (list '(0 . "SPLINE") '(100 . "AcDbEntity"))
    props
    (list '(100 . "AcDbSpline")
          (cons 210 (crv:ucsz))
          '(70 . 8) '(71 . 3)
          (cons 72 (length (cadr s)))
          (cons 73 (length (car s)))
          '(74 . 0) '(42 . 1.0e-10) '(43 . 1.0e-10))
    (mapcar '(lambda (k) (cons 40 k)) (cadr s))
    (mapcar '(lambda (p) (cons 10 (crv:w p))) (car s))
    xd))

;; 앵커 → 만들 객체의 DXF 목록
(defun crv:dxf (as closed out ten props / bz tol)
  (setq bz (crv:bez as closed ten) tol (crv:tol as))
  (if bz
    (if (= out "spline")
      (crv:dxf-spl bz props (crv:xd as closed out ten tol))
      (crv:dxf-pl (crv:bez->pl bz closed tol (crv:locks as)) closed props (crv:xd as closed out ten tol)))))

;; 새 객체 속성 = 현재 레이어·색·선종류·선가중치
(defun crv:cur-props (/ c lt lw res)
  (setq res (list (cons 8 (getvar "CLAYER")))
        c   (strcase (getvar "CECOLOR"))
        lt  (getvar "CELTYPE")
        lw  (getvar "CELWEIGHT"))
  (cond ((= c "BYBLOCK") (setq res (append res '((62 . 0)))))
        ((and (/= c "BYLAYER") (> (atoi c) 0)) (setq res (append res (list (cons 62 (atoi c)))))))
  (if (not (member (strcase lt) '("BYLAYER" ""))) (setq res (append res (list (cons 6 lt)))))
  (if (and (numberp lw) (/= lw -1)) (setq res (append res (list (cons 370 lw)))))
  res)

;; 원래 객체에서 유지할 속성
(defun crv:props (d)
  (vl-remove-if-not '(lambda (x) (member (car x) '(8 6 62 370 48 420 430 440))) d))

(defun crv:drop (lst k) (repeat k (setq lst (cdr lst))) lst)

;; XDATA 읽기 → (앵커 닫힘 출력 장력 z 오차) 또는 nil
(defun crv:xd-read (e / x lst closed out ten tol as p)
  (if (and (setq x (cdr (assoc -3 (entget e (list *crv-app*)))))
           (setq lst (cdr (assoc *crv-app* x)))
           (equal (car lst) '(1000 . "CRV1")))
    (progn
      (setq closed (= 1 (cdr (nth 1 lst)))
            out    (if (= 1 (cdr (nth 2 lst))) "spline" "pline")
            ten    (cdr (nth 3 lst))
            tol    (cdr (nth 4 lst))
            lst    (crv:drop lst 6))
      (while (and lst (= (car (car lst)) 1011))
        (setq p   (trans (cdr (car lst)) 0 1)
              as  (cons (crv:mk p (cdr (cadr lst))) as)
              lst (cddr lst)))
      (if (cdr as) (list (reverse as) closed out ten (caddr p) tol)))))

;;; ============================================================
;;;  기존 객체 읽기 (CRV 정보가 없는 객체)
;;; ============================================================
(defun crv:o2u (p elev nrm) (trans (list (car p) (cadr p) elev) nrm 1))

;; LW폴리선 정점 ((x y) 볼록) - OCS
(defun crv:lw-verts (d / vs cur)
  (foreach x d
    (cond
      ((= (car x) 10)
       (if cur (setq vs (cons cur vs)))
       (setq cur (list (cdr x) 0.0)))
      ((and cur (= (car x) 42)) (setq cur (list (car cur) (cdr x))))))
  (if cur (setq vs (cons cur vs)))
  (reverse vs))

(defun crv:lw-dedup (vs closed / out)
  (foreach v vs
    (if (and out (< (crv:dist (car v) (car (car out))) 1e-9))
      (setq out (cons v (cdr out)))
      (setq out (cons v out))))
  (setq out (reverse out))
  (if (and closed (cdr out) (< (crv:dist (car (last out)) (car (car out))) 1e-9))
    (setq out (reverse (cdr (reverse out)))))
  out)

;; 호를 90° 이하 조각으로 나누는 중간점들
(defun crv:arc-ins (s e bu / g k i res)
  (if (setq g (crv:arc-geo s e bu))
    (progn
      (setq k (max 2 (fix (+ 0.999999 (/ (abs (cadddr g)) (* 0.5 pi))))) i 1)
      (repeat (1- k)
        (setq res (cons (crv:arc-at s e bu (/ (float i) k)) res) i (1+ i)))
      (reverse res))))

;; 폴리선: 꼭짓점 = 꺾인 점, 호 구간은 중간점(매끈)을 넣어 그대로 재현
(defun crv:imp-lw (d / nrm elev closed vs n i q res)
  (setq nrm    (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        elev   (cond ((cdr (assoc 38 d))) (0.0))
        closed (= 1 (logand 1 (cdr (assoc 70 d))))
        vs     (crv:lw-dedup (crv:lw-verts d) closed)
        n      (length vs)
        i      0)
  (foreach v vs
    (setq res (cons (crv:mk (crv:o2u (car v) elev nrm) 1) res))
    (if (and (> (abs (cadr v)) 1e-9) (or closed (< i (1- n))))
      (progn
        (setq q (car (nth (if (= i (1- n)) 0 (1+ i)) vs)))
        (foreach ip (crv:arc-ins (car v) q (cadr v))
          (setq res (cons (crv:mk (crv:o2u ip elev nrm) 0) res)))))
    (setq i (1+ i)))
  (if vs (list (reverse res) closed "pline" 1.0 (caddr (crv:o2u (car (car vs)) elev nrm)))))

(defun crv:imp-arc (d / nrm c r a0 th k i res p)
  (setq nrm (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        c   (cdr (assoc 10 d))
        r   (cdr (assoc 40 d))
        a0  (cdr (assoc 50 d))
        th  (crv:ang-norm (- (cdr (assoc 51 d)) a0)))
  (if (< th 1e-9) (setq th (* 2.0 pi)))
  (setq k (max 2 (fix (+ 0.999999 (/ th (* 0.5 pi))))) i 0)
  (repeat (1+ k)
    (setq p   (trans (list (+ (car c) (* r (cos (+ a0 (* th (/ (float i) k))))))
                           (+ (cadr c) (* r (sin (+ a0 (* th (/ (float i) k))))))
                           (caddr c))
                     nrm 1)
          res (cons (crv:mk p (if (or (= i 0) (= i k)) 1 0)) res)
          i   (1+ i)))
  (list (reverse res) nil "pline" 1.0 (caddr p)))

(defun crv:imp-circle (d / nrm c r res p)
  (setq nrm (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        c   (cdr (assoc 10 d))
        r   (cdr (assoc 40 d)))
  (foreach a (list 0.0 (* 0.5 pi) pi (* 1.5 pi))
    (setq p   (trans (list (+ (car c) (* r (cos a))) (+ (cadr c) (* r (sin a))) (caddr c)) nrm 1)
          res (cons (crv:mk p 0) res)))
  (list (reverse res) t "pline" 1.0 (caddr p)))

(defun crv:uniq-nums (lst / res)
  (foreach x lst (if (or (null res) (> (abs (- x (car res))) 1e-9)) (setq res (cons x res))))
  (reverse res))

(defun crv:sample-curve (e n closed / l i res)
  (setq l (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)) i 0)
  (repeat (if closed n (1+ n))
    (setq res (cons (vlax-curve-getPointAtDist e (* l (/ (float i) n))) res) i (1+ i)))
  (reverse res))

;; 스플라인: 맞춤점이 있으면 맞춤점, 없으면 매듭 위치의 곡선 점 (모양이 조금 달라질 수 있음)
(defun crv:imp-spl (e d / closed pts sp ep res)
  (setq closed (/= 0 (logand (cdr (assoc 70 d)) 3))
        pts    (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 11)) d)))
  (if (null pts)
    (progn
      (setq sp (vlax-curve-getStartParam e) ep (vlax-curve-getEndParam e))
      (foreach k (crv:uniq-nums (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 40)) d)))
        (if (and (>= k (- sp 1e-9)) (<= k (+ ep 1e-9)))
          (setq res (cons (vlax-curve-getPointAtParam e (max sp (min ep k))) res))))
      (setq pts (reverse res))
      (if (< (length pts) 4) (setq pts (crv:sample-curve e 8 closed)))))
  (setq pts (mapcar '(lambda (p) (trans p 0 1)) pts))
  (if (and closed (cdr pts) (< (crv:dist (crv:2d (car pts)) (crv:2d (last pts))) 1e-9))
    (setq pts (reverse (cdr (reverse pts)))))
  (if (cdr pts)
    (list (mapcar '(lambda (p) (crv:mk p 0)) pts) closed "spline" 1.0 (caddr (car pts)))))

(defun crv:import (e / d typ p q)
  (setq d (entget e) typ (cdr (assoc 0 d)))
  (cond
    ((= typ "LWPOLYLINE") (crv:imp-lw d))
    ((= typ "LINE")
     (setq p (trans (cdr (assoc 10 d)) 0 1) q (trans (cdr (assoc 11 d)) 0 1))
     (list (list (crv:mk p 1) (crv:mk q 1)) nil "pline" 1.0 (caddr p)))
    ((= typ "ARC") (crv:imp-arc d))
    ((= typ "CIRCLE") (crv:imp-circle d))
    ((= typ "SPLINE") (crv:imp-spl e d))))

;;; ============================================================
;;;  저장된 점과 실제 모양이 같은지 (STRETCH·TRIM 등으로 바뀌었는지)
;;; ============================================================
(defun crv:lw-ucs (d / nrm elev flip)
  (setq nrm  (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        elev (cond ((cdr (assoc 38 d))) (0.0))
        flip (< (apply '+ (mapcar '* nrm (crv:ucsz))) 0.0))
  (mapcar '(lambda (v) (list (crv:2d (crv:o2u (car v) elev nrm)) (if flip (- (cadr v)) (cadr v))))
          (crv:lw-verts d)))

;; 점 → 폴리선 정점 목록 거리
(defun crv:d-pl (p vs closed / best d l)
  (setq l vs)
  (while (cdr l)
    (setq d    (crv:d-arc p (car (car l)) (car (cadr l)) (cadr (car l)))
          best (if best (min best d) d)
          l    (cdr l)))
  (if (and closed (cdr vs))
    (setq d    (crv:d-arc p (car (car l)) (car (car vs)) (cadr (car l)))
          best (if best (min best d) d)))
  (cond (best) (vs (crv:dist p (car (car vs)))) (t 0.0)))

;; 정점 + 호 가운데 점
(defun crv:pl-samples (vs closed / res l)
  (setq l vs)
  (while l
    (setq res (cons (car (car l)) res))
    (cond
      ((cdr l) (setq res (cons (crv:seg-mid (car (car l)) (car (cadr l)) (cadr (car l))) res)))
      (closed (setq res (cons (crv:seg-mid (car (car l)) (car (car vs)) (cadr (car l))) res))))
    (setq l (cdr l)))
  res)

(defun crv:pl-near (src dst closed lim / ok)
  (setq ok t)
  (foreach p (crv:pl-samples src closed)
    (if (and ok (> (crv:d-pl p dst closed) lim)) (setq ok nil)))
  ok)

(defun crv:sync-p (e dat / d typ as closed ten tol bz cvs act)
  (setq d      (entget e)
        typ    (cdr (assoc 0 d))
        as     (nth 0 dat)
        closed (nth 1 dat)
        ten    (nth 3 dat)
        tol    (nth 5 dat))
  (if (or (null tol) (<= tol 0.0)) (setq tol (crv:tol as)))
  (setq bz (crv:bez as closed ten))
  (cond
    ((null bz) nil)
    ((= typ "SPLINE")
     (setq cvs (car (crv:bez->spl bz))
           act (mapcar '(lambda (x) (crv:2d (trans (cdr x) 0 1)))
                       (vl-remove-if-not '(lambda (x) (= (car x) 10)) d)))
     (and (= (length cvs) (length act))
          (vl-every '(lambda (a b) (< (crv:dist a b) (* 0.01 tol))) cvs act)))
    ((= typ "LWPOLYLINE")
     (if (eq closed (= 1 (logand 1 (cdr (assoc 70 d)))))
       (progn
         (setq act (crv:lw-ucs d) cvs (crv:bez->pl bz closed tol (crv:locks as)))
         (or (crv:pl-same act cvs (* 0.01 tol))                  ; 보통은 정점이 그대로 같음 (빠름)
             (crv:pl-twin act cvs closed (* 3.0 tol))))))))     ; 아니면 모양으로 비교

;; 정점·볼록이 하나하나 같은지
(defun crv:pl-same (a b lim)
  (and (= (length a) (length b))
       (vl-every '(lambda (p q) (and (< (crv:dist (car p) (car q)) lim) (< (abs (- (cadr p) (cadr q))) 1e-6)))
                 a b)))

(defun crv:pl-twin (a b closed lim)
  (and (crv:pl-near a b closed lim) (crv:pl-near b a closed lim)))

;;; ============================================================
;;;  화면 표시 (grvecs)
;;; ============================================================
(defun crv:px () (/ (getvar "VIEWSIZE") (cadr (getvar "SCREENSIZE"))))

;; 점 목록 → grvecs 목록 (색 시작점 끝점 ...)
(defun crv:vlines (col pts closed / res f)
  (setq f (car pts))
  (while (cdr pts)
    (setq res (cons (crv:3 (cadr pts)) (cons (crv:3 (car pts)) (cons col res)))
          pts (cdr pts)))
  (if (and closed f) (setq res (cons (crv:3 f) (cons (crv:3 (car pts)) (cons col res)))))
  (reverse res))

(defun crv:sq (x y r)
  (list (list (- x r) (- y r)) (list (+ x r) (- y r)) (list (+ x r) (+ y r))
        (list (- x r) (+ y r)) (list (- x r) (- y r))))

(defun crv:ring (x y r / i a res)
  (setq i 0)
  (repeat 13
    (setq a   (* i (/ pi 6.0))
          res (cons (list (+ x (* r (cos a))) (+ y (* r (sin a)))) res)
          i   (1+ i)))
  res)

;; 표시 모양 (스냅 마커는 AutoCAD와 비슷하게)
(defun crv:shape (p r kind / x y)
  (setq x (car p) y (cadr p))
  (cond
    ((member kind '("sq" "end")) (list (crv:sq x y r)))
    ((member kind '("ring" "cen" "nod")) (list (crv:ring x y r)))
    ((= kind "mid")
     (list (list (list (- x r) (- y (* 0.6 r))) (list (+ x r) (- y (* 0.6 r))) (list x (+ y r))
                 (list (- x r) (- y (* 0.6 r))))))
    ((= kind "qua")
     (list (list (list x (- y r)) (list (+ x r) y) (list x (+ y r)) (list (- x r) y) (list x (- y r)))))
    ((member kind '("int" "app"))
     (list (list (list (- x r) (- y r)) (list (+ x r) (+ y r)))
           (list (list (- x r) (+ y r)) (list (+ x r) (- y r)))))
    ((= kind "per")
     (list (list (list (- x r) (+ y r)) (list (- x r) (- y r)) (list (+ x r) (- y r)))
           (list (list (- x r) y) (list x y) (list x (- y r)))))
    ((= kind "nea")
     (list (list (list (- x r) (+ y r)) (list (+ x r) (+ y r)) (list (- x r) (- y r))
                 (list (+ x r) (- y r)) (list (- x r) (+ y r)))))
    ((= kind "ins") (list (crv:sq x y r) (crv:sq x y (* 0.5 r))))
    ((= kind "plus")
     (list (list (list (- x r) y) (list (+ x r) y)) (list (list x (- y r)) (list x (+ y r)))))
    (t (list (crv:sq x y r)))))

(defun crv:vshape (col p r kind / res)
  (foreach pl (crv:shape p r kind)
    (foreach x (crv:vlines col pl nil) (setq res (cons x res))))
  (reverse res))

;; 앵커 표시: 매끈 = ○, 꺾임 = □, hi 번째는 크게 hcol 색으로
(defun crv:anchor-vecs (as hi hcol px / i r res)
  (setq i 0 r (* 4.0 px))
  (foreach a as
    (foreach x (if (equal i hi)
                 (crv:vshape hcol (crv:apt a) (* 1.7 r) (if (crv:corner-p a) "sq" "ring"))
                 (crv:vshape *crv-acol* (crv:apt a) r (if (crv:corner-p a) "sq" "ring")))
      (setq res (cons x res)))
    (setq i (1+ i)))
  (reverse res))

(defun crv:show-path (bz px)
  (if bz (grvecs (crv:vlines *crv-pcol* (crv:path-pts bz px) nil))))

;;; ============================================================
;;;  입력 보조 : 스냅 마커 / 직교 / 좌표 입력 / 키
;;; ============================================================
(setq *crv-snaps* '((1 . "end") (2 . "mid") (4 . "cen") (8 . "nod") (16 . "qua")
                    (32 . "int") (64 . "ins") (128 . "per") (2048 . "app")))

;; OSMODE 스냅 중 커서에서 가장 가까운 것 → (점 . 종류) / 근처점은 다른 스냅이 없을 때만
(defun crv:snap (p / m lim best bd sp d)
  (setq m (getvar "OSMODE"))
  (if (and (> m 0) (= 0 (logand m 16384)))
    (progn
      (setq lim (* 1.5 (max 8 (getvar "APERTURE")) (crv:px)))
      (foreach b *crv-snaps*
        (if (and (/= 0 (logand m (car b)))
                 (setq sp (osnap p (strcat "_" (cdr b))))
                 (< (setq d (crv:dist (crv:2d sp) (crv:2d p))) lim)
                 (or (null bd) (< d bd)))
          (setq bd d best (cons sp (cdr b)))))
      (if (and (null best) (/= 0 (logand m 512)) (setq sp (osnap p "_nea")))
        (setq best (cons sp "nea")))))
  best)

(defun crv:ortho (base p / d)
  (if (and base (= 1 (getvar "ORTHOMODE")))
    (progn
      (setq d (crv:v- p base))
      (if (>= (abs (car d)) (abs (cadr d)))
        (list (car p) (cadr base))
        (list (car base) (cadr p))))
    p))

;; 스냅 또는 직교를 거친 커서 위치
(defun crv:cursor (val base / snp)
  (if (setq snp (crv:snap val))
    (list (crv:2d (car snp)) snp)
    (list (crv:ortho base (crv:2d val)) nil)))

;; 좌표 입력 → UCS 2D 점 (base 기준점, dirp 커서 방향 참고점)
(defun crv:parse (s base dirp / rel i d a u)
  (if (setq rel (= (substr s 1 1) "@")) (setq s (substr s 2)))
  (cond
    ((= s "") (if rel base))
    ((setq i (vl-string-search "<" s))
     (setq d (atof (substr s 1 i))
           a (* pi (/ (atof (substr s (+ i 2))) 180.0)))
     (crv:v+ (if rel base '(0.0 0.0)) (list (* d (cos a)) (* d (sin a)))))
    ((setq i (vl-string-search "," s))
     (setq a (list (atof (substr s 1 i)) (atof (substr s (+ i 2)))))
     (if rel (crv:v+ base a) a))
    ((and (not rel) dirp (setq u (crv:unit (crv:v- dirp base))))
     (crv:v+ base (crv:vx u (atof s))))))

(defun crv:numkey-p (v) (or (and (>= v 48) (<= v 57)) (member v '(44 45 46 60 64))))

;; 키 코드 → 대문자 한 글자 (한글 자판 상태여도 같은 자리의 영문 키로)
(setq *crv-hangul* '((12609 . "A") (12640 . "B") (12618 . "C") (12615 . "D") (12599 . "E") (12601 . "F")
                     (12622 . "G") (12631 . "H") (12625 . "I") (12627 . "J") (12623 . "K") (12643 . "L")
                     (12641 . "M") (12636 . "N") (12624 . "O") (12628 . "P") (12610 . "Q") (12593 . "R")
                     (12596 . "S") (12613 . "T") (12629 . "U") (12621 . "V") (12616 . "W") (12620 . "X")
                     (12635 . "Y") (12619 . "Z")))

(defun crv:key (v)
  (cond
    ((and (> v 32) (< v 127)) (strcase (chr v)))
    ((cdr (assoc v *crv-hangul*)))
    (t "")))

(defun crv:bs (s)
  (princ (chr 8)) (princ " ") (princ (chr 8))
  (substr s 1 (1- (strlen s))))

(defun crv:ms (/ v)
  (if (setq v (getvar "MILLISECS")) v (fix (* 86400000.0 (rem (getvar "DATE") 1.0)))))

(defun crv:out-name (o) (if (= o "spline") "스플라인" "폴리선"))

(defun crv:ask-ten (cur / v)
  (initget 6)
  (setq v (getreal (strcat "\n장력 (기본 1.0 — 작을수록 팽팽하게, 클수록 둥글게) <" (rtos cur 2 2) ">: ")))
  (if v (max 0.3 (min 2.0 v)) cur))

(defun crv:toggle-out ()
  (setq *crv-out* (if (= *crv-out* "spline") "pline" "spline"))
  (crv:cfg-save)
  (princ (strcat "\n[알림] 출력을 " (crv:out-name *crv-out*) "으로 바꿨습니다.")))

(defun crv:ncorner (as) (length (vl-remove-if-not 'crv:corner-p as)))

;;; ============================================================
;;;  CRV : 그리기
;;; ============================================================
(defun crv:draw-prompt ()
  (princ "\n다음 점 또는 [닫기(C)/꺾기(X)/되돌리기(U)/출력(O)/장력(T)] <완료>: "))

;; 미리보기: 커서 위치를 다음 점으로 넣었을 때의 곡선 (closing이면 닫힌 모양)
(defun crv:draw-show (as cur snp closing / px tmp)
  (setq px (crv:px))
  (redraw)
  (setq tmp (cond (closing as)
                  ((and cur (> (crv:dist cur (crv:apt (last as))) 1e-9)) (append as (list (crv:mk cur 0))))
                  (t as)))
  (if (cdr tmp) (crv:show-path (crv:bez tmp closing *crv-ten*) px))
  (grvecs (crv:anchor-vecs as (if closing 0) 3 px))
  (if snp (grvecs (crv:vshape 30 (crv:2d (car snp)) (* 5.0 px) (cdr snp)))))

(defun crv:add (as p)
  (if (< (crv:dist p (crv:apt (last as))) 1e-9)
    (progn (princ "\n같은 자리라 건너뛰었습니다.") as)
    (progn (setvar "LASTPOINT" (crv:3 p)) (append as (list (crv:mk p 0))))))

(defun crv:undo-last (as)
  (if (cdr as)
    (progn (setq as (reverse (cdr (reverse as)))) (setvar "LASTPOINT" (crv:3 (crv:apt (last as)))) as)
    (progn (princ "\n더 지울 점이 없습니다.") as)))

(defun crv:draw (/ p0 go)
  (setq go t)
  (while go
    (initget "Edit Output Tension")
    (setq p0 (getpoint (strcat "\n첫 점 <" (crv:out-name *crv-out*) ", 장력 " (rtos *crv-ten* 2 2)
                               "> 또는 [편집(E)/출력(O)/장력(T)]: ")))
    (cond
      ((null p0) (setq go nil))
      ((listp p0) (setq go nil) (crv:draw-from p0))
      ((= p0 "Edit") (setq go nil) (crv:edit-cmd))
      ((= p0 "Output") (crv:toggle-out))
      ((= p0 "Tension") (setq *crv-ten* (crv:ask-ten *crv-ten*)) (crv:cfg-save)))))

(defun crv:draw-from (p0 / as closed go gr code val px raw cr cur pt buf now dbl lcms lcpt ch)
  (setq *crv-z* (caddr p0)
        as      (list (crv:mk p0 0))
        buf     ""
        go      t
        lcms    (crv:ms)
        lcpt    (crv:2d p0))
  (setvar "LASTPOINT" p0)
  (princ "\n[알림] 클릭 = 점 추가 · 더블클릭 = 꺾인 점 · 첫 점 클릭 = 닫기 · Enter = 완료")
  (crv:draw-prompt)
  (while go
    (setq gr (grread t 13 0) code (car gr) val (cadr gr) px (crv:px))
    (cond
      ;; 마우스 이동: 커서를 다음 점으로 넣은 곡선 미리보기 / 첫 점 위면 닫힌 모양
      ((= code 5)
       (setq raw (crv:2d val))
       (if (and (cdr as) (< (crv:dist raw (crv:apt (car as))) (* 7.0 px)))
         (crv:draw-show as nil nil t)
         (progn
           (setq cr (crv:cursor val (crv:apt (last as))) cur (car cr))
           (crv:draw-show as cur (cadr cr) nil))))
      ;; 클릭: 점 추가 / 더블클릭 = 꺾인 점 / 첫 점 = 닫기
      ((= code 3)
       (setq raw  (crv:2d val)
             now  (crv:ms)
             dbl  (and lcms (<= (- now lcms) *crv-dbl*) (< (crv:dist raw lcpt) (* 5.0 px)))
             lcms (if dbl nil now)
             lcpt raw)
       (cond
         (dbl (setq as (crv:toggle as (1- (length as)))))
         ((and (cdr as) (< (crv:dist raw (crv:apt (car as))) (* 7.0 px)))
          (setq closed t go nil))
         (t (setq as (crv:add as (car (crv:cursor val (crv:apt (last as))))))))
       (if go (crv:draw-show as nil nil nil)))
      ;; 우클릭 = 완료
      ((member code '(11 25)) (setq go nil))
      ;; 키보드
      ((= code 2)
       (cond
         ((and (member val '(13 32)) (/= buf ""))
          (if (setq pt (crv:parse buf (crv:apt (last as)) cur))
            (setq as (crv:add as pt))
            (princ "\n[주의] 입력을 읽을 수 없습니다."))
          (setq buf "")
          (crv:draw-prompt)
          (crv:draw-show as nil nil nil))
         ((member val '(13 32)) (setq go nil))
         ((= val 8)
          (if (/= buf "")
            (setq buf (crv:bs buf))
            (setq as (crv:undo-last as)))
          (crv:draw-show as nil nil nil))
         ((crv:numkey-p val) (setq buf (strcat buf (chr val))) (princ (chr val)))
         ((/= buf "") nil)
         (t
          (setq ch (crv:key val))
          (cond
            ((= ch "C")
             (if (cdr as) (setq closed t go nil) (princ "\n점이 2개 이상이어야 닫을 수 있습니다.")))
            ((= ch "X") (setq as (crv:toggle as (1- (length as)))))
            ((= ch "U") (setq as (crv:undo-last as)))
            ((= ch "O") (crv:toggle-out) (crv:draw-prompt))
            ((= ch "T") (setq *crv-ten* (crv:ask-ten *crv-ten*)) (crv:cfg-save) (crv:draw-prompt)))
          (if go (crv:draw-show as nil nil nil)))))))
  (redraw)
  (crv:finish as closed))

(defun crv:finish (as closed / e)
  (if (< (length as) 2)
    (princ "\n[알림] 점이 2개 이상 있어야 해서 만들지 않았습니다.")
    (progn
      (vla-StartUndoMark *crv-doc*)
      (setq *crv-undo* t)
      (setq e (entmake (crv:dxf as closed *crv-out* *crv-ten* (crv:cur-props))))
      (if (and (null e) (= *crv-out* "spline"))
        (progn
          (princ "\n[주의] 스플라인을 만들 수 없어 폴리선으로 만듭니다.")
          (setq e (entmake (crv:dxf as closed "pline" *crv-ten* (crv:cur-props))))))
      (vla-EndUndoMark *crv-doc*)
      (setq *crv-undo* nil)
      (if e
        (princ (strcat "\n[완료] " (if (= (cdr (assoc 0 e)) "SPLINE") "스플라인" "폴리선")
                       "을 만들었습니다 — 점 " (itoa (length as)) "개 (꺾인 점 " (itoa (crv:ncorner as)) "개)"
                       (if (assoc 90 e) (strcat ", 정점 " (itoa (cdr (assoc 90 e))) "개") "")
                       (if (> (length as) 400) ". 점이 400개를 넘어 다시 편집할 정보는 저장하지 않았습니다." ".")))
        (princ "\n[오류] 곡선을 만들 수 없습니다.")))))

;;; ============================================================
;;;  CRVE : 편집
;;; ============================================================
(defun crv:pick (/ ss e s typ ok)
  (setq ss (ssget "_I" '((0 . "LWPOLYLINE,LINE,ARC,CIRCLE,SPLINE"))))
  (if (and ss (= 1 (sslength ss)))
    (progn (setq e (ssname ss 0)) (sssetfirst nil nil))
    (while (not ok)
      (setvar "ERRNO" 0)
      (setq s (entsel "\n편집할 곡선을 고르세요 (폴리선·선·호·원·스플라인): "))
      (cond
        ((and (null s) (= 52 (getvar "ERRNO"))) (setq ok t))
        ((null s) (princ "\n고른 객체가 없습니다."))
        ((wcmatch (setq typ (cdr (assoc 0 (entget (car s))))) "LWPOLYLINE,LINE,ARC,CIRCLE,SPLINE")
         (setq e (car s) ok t))
        ((= typ "POLYLINE") (princ "\n[주의] 옛 2D 폴리선은 CONVERTPOLY 로 경량 폴리선으로 바꾼 뒤 고르세요."))
        (t (princ (strcat "\n[주의] 편집할 수 없는 객체입니다: " typ))))))
  e)

(defun crv:edit-cmd (/ e)
  (if (setq e (crv:pick)) (crv:edit e)))

(defun crv:locked-p (d / l)
  (and (setq l (tblsearch "LAYER" (cdr (assoc 8 d))))
       (= 4 (logand 4 (cdr (assoc 70 l))))))

(defun crv:plane-ok (d / typ zs n)
  (setq typ (cdr (assoc 0 d)))
  (cond
    ((= typ "LINE")
     (equal (caddr (trans (cdr (assoc 10 d)) 0 1)) (caddr (trans (cdr (assoc 11 d)) 0 1)) 1e-6))
    ((= typ "SPLINE")
     (setq zs (mapcar '(lambda (x) (caddr (trans (cdr x) 0 1)))
                      (vl-remove-if-not '(lambda (x) (member (car x) '(10 11))) d)))
     (vl-every '(lambda (v) (equal v (car zs) 1e-6)) zs))
    (t
     (setq n (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0))))
     (< (crv:len3 (crv:cross3 n (crv:ucsz))) 1e-6))))

(defun crv:edit (e / d dat re)
  (setq d (entget e))
  (cond
    ((crv:locked-p d) (princ "\n[주의] 잠긴 레이어의 객체는 편집할 수 없습니다."))
    ((not (crv:plane-ok d))
     (princ "\n[주의] 지금 UCS 평면과 곡선 평면이 다릅니다. 곡선 평면에 맞춘 UCS 에서 다시 실행하세요."))
    (t
     (setq dat (crv:xd-read e))
     (if (and dat (not (crv:sync-p e dat)))
       (progn
         (initget "Saved Current")
         (if (equal "Current"
                    (getkword "\n다른 명령으로 모양이 바뀐 곡선입니다 [저장된 점으로 편집(S)/지금 모양으로 다시 읽기(C)] <S>: "))
           (setq dat nil re t))))
     (if (null dat)
       (progn
         (setq dat (crv:import e))
         (if (and dat (= (cdr (assoc 0 d)) "SPLINE"))
           (princ "\n[알림] 일반 스플라인은 곡선 위 점을 다시 읽어서 모양이 조금 달라질 수 있습니다."))))
     (if (and dat (cdr (car dat)))
       (crv:edit-loop e d dat re)
       (princ "\n[오류] 이 객체에서 점을 읽을 수 없습니다.")))))

(defun crv:edit-prompt (out ten)
  (princ (strcat "\n<" (crv:out-name out) ", 장력 " (rtos ten 2 2)
                 "> [삭제(D)/꺾기(X)/닫기(C)/출력(O)/장력(T)/되돌리기(U)] <완료>: ")))

(defun crv:edit-show (as closed ten hi ext / px)
  (setq px (crv:px))
  (redraw)
  (crv:show-path (crv:bez as closed ten) px)
  (grvecs (crv:anchor-vecs as hi 1 px))
  (if ext (grvecs ext)))

(defun crv:edit-loop (e d dat chg / as closed out ten hist go gr code val px raw cr hov hc mv mv0
                                     lcms lcpt now dbl k buf pt ch ext)
  (setq as      (nth 0 dat)
        closed  (nth 1 dat)
        out     (nth 2 dat)
        ten     (nth 3 dat)
        *crv-z* (cond ((nth 4 dat)) (0.0))
        go      t
        buf     "")
  (vla-StartUndoMark *crv-doc*)
  (setq *crv-undo* t *crv-edit-e* e)
  (entmod (list (cons -1 e) '(60 . 1)))                 ; 원래 객체는 편집하는 동안 숨김
  (princ "\n[알림] 점 클릭 = 이동 · 더블클릭 = 매끈/꺾임 · 곡선 위 클릭 = 점 추가 · Esc = 취소")
  (crv:edit-prompt out ten)
  (crv:edit-show as closed ten nil nil)
  (while go
    (setq gr (grread t 13 0) code (car gr) val (cadr gr) px (crv:px) ext nil)
    (cond
      ;; 마우스 이동: 옮기는 중이면 점을 따라 움직이고, 아니면 점·곡선 위 표시
      ((= code 5)
       (setq raw (crv:2d val))
       (if mv
         (progn
           (setq cr (crv:cursor val mv0)
                 as (crv:setpt as mv (car cr)))
           (if (cadr cr) (setq ext (crv:vshape 30 (crv:2d (car (cadr cr))) (* 5.0 px) (cdr (cadr cr)))))
           (crv:edit-show as closed ten mv ext))
         (progn
           (setq hov (crv:hit-anchor raw as px)
                 hc  (if (null hov) (crv:hit-curve raw as closed ten px)))
           (if hc (setq ext (crv:vshape 3 (cadr hc) (* 5.0 px) "plus")))
           (crv:edit-show as closed ten hov ext))))
      ;; 클릭
      ((= code 3)
       (setq raw  (crv:2d val)
             now  (crv:ms)
             dbl  (and lcms (<= (- now lcms) *crv-dbl*) (< (crv:dist raw lcpt) (* 5.0 px)))
             lcms (if dbl nil now)
             lcpt raw
             k    nil)
       (cond
         ;; 더블클릭 = 매끈 ↔ 꺾임
         (dbl
          (if mv
            (setq as (crv:setpt as mv mv0) k mv mv nil)
            (if (setq k (crv:hit-anchor raw as px)) (setq hist (cons (list as closed) hist))))
          (if k (setq as (crv:toggle as k) chg t)))
         ;; 옮기던 점 놓기
         (mv
          (setq as (crv:setpt as mv (car (crv:cursor val mv0))) mv nil chg t))
         ;; 점 집기
         ((setq k (crv:hit-anchor raw as px))
          (setq hist (cons (list as closed) hist) mv k mv0 (crv:apt (nth k as))))
         ;; 곡선 위 = 점 추가
         ((setq hc (crv:hit-curve raw as closed ten px))
          (setq hist (cons (list as closed) hist)
                as   (crv:insert as (car hc) (cadr hc))
                hov  nil
                chg  t)))
       (crv:edit-show as closed ten mv nil))
      ;; 우클릭 = 옮기던 점 놓기 / 완료
      ((member code '(11 25))
       (if mv (setq mv nil chg t) (setq go nil))
       (if go (crv:edit-show as closed ten nil nil)))
      ;; 키보드
      ((= code 2)
       (cond
         ((and (member val '(13 32)) (/= buf ""))
          (if (and mv (setq pt (crv:parse buf mv0 (crv:apt (nth mv as)))))
            (setq as (crv:setpt as mv pt) mv nil chg t)
            (princ "\n[주의] 옮길 점을 먼저 클릭한 뒤 좌표를 입력하세요."))
          (setq buf "")
          (crv:edit-prompt out ten))
         ((member val '(13 32)) (if mv (setq mv nil chg t) (setq go nil)))
         ((= val 8)
          (if (/= buf "")
            (setq buf (crv:bs buf))
            (if (setq k (cond (mv) (hov)))
              (setq hist (cons (list as closed) hist) as (crv:del as k) mv nil hov nil chg t))))
         ((crv:numkey-p val) (setq buf (strcat buf (chr val))) (princ (chr val)))
         ((/= buf "") nil)
         (t
          (setq ch (crv:key val) k (cond (mv) (hov)))
          (cond
            ((= ch "D")
             (if k
               (setq hist (cons (list as closed) hist) as (crv:del as k) mv nil hov nil chg t)
               (princ "\n지울 점 위에 커서를 올리고 D 를 누르세요.")))
            ((= ch "X")
             (if k
               (progn
                 (if (null mv) (setq hist (cons (list as closed) hist)))
                 (setq as (crv:toggle as k) chg t))
               (princ "\n바꿀 점 위에 커서를 올리고 X 를 누르세요.")))
            ((= ch "C")
             (setq hist (cons (list as closed) hist) closed (not closed) chg t)
             (princ (if closed "\n[알림] 닫았습니다." "\n[알림] 열었습니다.")))
            ((= ch "O")
             (setq out (if (= out "spline") "pline" "spline") chg t)
             (princ (strcat "\n[알림] 출력을 " (crv:out-name out) "으로 바꿨습니다."))
             (crv:edit-prompt out ten))
            ((= ch "T")
             (setq ten (crv:ask-ten ten) chg t)
             (crv:edit-prompt out ten))
            ((= ch "U")
             (if hist
               (setq as (car (car hist)) closed (cadr (car hist)) hist (cdr hist) mv nil hov nil)
               (princ "\n되돌릴 작업이 없습니다."))))))
       (if go (crv:edit-show as closed ten (cond (mv) (hov)) nil)))))
  (redraw)
  (crv:edit-commit e d as closed out ten chg))

;; 점 hit (7픽셀)
(defun crv:hit-anchor (p as px / i best bd d)
  (setq i 0)
  (foreach a as
    (if (and (< (setq d (crv:dist p (crv:apt a))) (* 7.0 px)) (or (null bd) (< d bd)))
      (setq bd d best i))
    (setq i (1+ i)))
  best)

;; 곡선 hit (6픽셀) → (구간번호 곡선위점)
(defun crv:hit-curve (p as closed ten px / i best bd pts q d)
  (setq i 0)
  (foreach b (crv:bez as closed ten)
    (setq pts (cons (car b) (crv:tess b (crv:nseg b px))))
    (while (cdr pts)
      (setq q (crv:near-seg p (car pts) (cadr pts)) d (crv:dist p q))
      (if (and (< d (* 6.0 px)) (or (null bd) (< d bd))) (setq bd d best (list i q)))
      (setq pts (cdr pts)))
    (setq i (1+ i)))
  best)

(defun crv:edit-commit (e d as closed out ten chg / lst ne)
  (cond
    ((not chg)
     (entmod (list (cons -1 e) '(60 . 0)))
     (princ "\n[알림] 바뀐 것이 없습니다."))
    (t
     (setq lst (crv:dxf as closed out ten (cons '(60 . 0) (crv:props d))))
     (cond
       ((null lst) nil)
       ((and (= (cdr (assoc 0 d)) "LWPOLYLINE") (= out "pline") (entmod (cons (cons -1 e) lst)))
        (entupd e)
        (setq ne e))
       ((entmake lst) (setq ne (entlast)) (entdel e)))
     (if ne
       (princ (strcat "\n[완료] " (crv:out-name out) "으로 고쳤습니다 — 점 " (itoa (length as))
                      "개 (꺾인 점 " (itoa (crv:ncorner as)) "개)."))
       (progn
         (entmod (list (cons -1 e) '(60 . 0)))
         (princ "\n[오류] 곡선을 만들 수 없어 원래대로 두었습니다.")))))
  (setq *crv-edit-e* nil)
  (vla-EndUndoMark *crv-doc*)
  (setq *crv-undo* nil))

;;; ============================================================
;;;  공용 : 폴리선 정점 도구
;;; ============================================================
;; 정점 목록 → 구간 목록 ((시작 끝 볼록) ...)
(defun crv:pl-segs (vs closed / l res)
  (setq l vs)
  (while (cdr l)
    (setq res (cons (list (car (car l)) (car (cadr l)) (cadr (car l))) res) l (cdr l)))
  (if (and closed (cdr vs)) (setq res (cons (list (car (car l)) (car (car vs)) (cadr (car l))) res)))
  (reverse res))

;; 정점 목록 → 화면용 점들
(defun crv:pl-pts (vs closed px / res n i)
  (setq res (list (car (car vs))))
  (foreach sg (crv:pl-segs vs closed)
    (setq n (if (< (abs (caddr sg)) 1e-9)
              1
              (fix (min 64.0 (max 4.0 (/ (* (crv:dist (car sg) (cadr sg)) (+ 1.0 (abs (caddr sg)))) (* 4.0 px))))))
          i 1)
    (repeat n
      (setq res (cons (crv:arc-at (car sg) (cadr sg) (caddr sg) (/ (float i) n)) res) i (1+ i))))
  (reverse res))

;; 정점 목록 방향 뒤집기 ((점 볼록) ...)
(defun crv:vrev (vs / bl res)
  (setq bl (cdr (reverse (mapcar 'cadr vs))))
  (foreach v (reverse vs)
    (setq res (cons (list (car v) (if (and bl (/= (car bl) 0.0)) (- (car bl)) 0.0)) res)
          bl  (cdr bl)))
  (reverse res))

;; 정점 목록 크기 (대각선)
(defun crv:vs-size (vs / xs ys)
  (setq xs (mapcar '(lambda (v) (car (car v))) vs) ys (mapcar '(lambda (v) (cadr (car v))) vs))
  (max 1e-9 (distance (list (apply 'min xs) (apply 'min ys)) (list (apply 'max xs) (apply 'max ys)))))

;; 호 곡률 (1/반지름), 직선 0
(defun crv:arc-k (s e bu)
  (if (< (abs bu) 1e-12) 0.0 (/ (* 4.0 (abs bu)) (* (crv:dist s e) (+ 1.0 (* bu bu))))))

;; 구간 설명: 직선 길이 / R 반지름
(defun crv:piece-str (s e bu)
  (if (< (abs bu) 1e-12)
    (strcat "직선 " (rtos (crv:dist s e) 2 2))
    (strcat "R" (rtos (/ 1.0 (crv:arc-k s e bu)) 2 2))))

;; 객체 → UCS 정점 목록 ((점 볼록) ...) (선·호·LW폴리선)
(defun crv:ent-verts (e / d typ nrm th flip)
  (setq d (entget e) typ (cdr (assoc 0 d)))
  (cond
    ((= typ "LWPOLYLINE") (crv:lw-ucs d))
    ((= typ "LINE")
     (list (list (crv:2d (trans (cdr (assoc 10 d)) 0 1)) 0.0)
           (list (crv:2d (trans (cdr (assoc 11 d)) 0 1)) 0.0)))
    ((= typ "ARC")
     (setq nrm  (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
           th   (crv:ang-norm (- (cdr (assoc 51 d)) (cdr (assoc 50 d))))
           flip (< (apply '+ (mapcar '* nrm (crv:ucsz))) 0.0))
     (if (< th 1e-12) (setq th (* 2.0 pi)))
     (list (list (crv:2d (trans (vlax-curve-getStartPoint e) 0 1))
                 (* (if flip -1.0 1.0) (/ (sin (/ th 4.0)) (cos (/ th 4.0)))))
           (list (crv:2d (trans (vlax-curve-getEndPoint e) 0 1)) 0.0)))))

;;; ============================================================
;;;  CRB : 호 블렌드 (BLEND 대신 - 호 두 개로 잇기)
;;; ============================================================

;; 고른 끝 정보 → (객체 끝점(UCS) 바깥쪽접선 "S"|"E")
(defun crv:end-info (e pk / ps pe)
  (setq ps (trans (vlax-curve-getStartPoint e) 0 1)
        pe (trans (vlax-curve-getEndPoint e) 0 1))
  (if (< (crv:dist (crv:2d pk) (crv:2d ps)) (crv:dist (crv:2d pk) (crv:2d pe)))
    (list e ps (crv:unit (crv:vx (crv:2d (trans (vlax-curve-getFirstDeriv e (vlax-curve-getStartParam e)) 0 1 t)) -1.0)) "S")
    (list e pe (crv:unit (crv:2d (trans (vlax-curve-getFirstDeriv e (vlax-curve-getEndParam e)) 0 1 t))) "E")))

(defun crv:pick-end (msg / s d typ ok res)
  (while (not ok)
    (setvar "ERRNO" 0)
    (setq s (entsel msg))
    (cond
      ((and (null s) (= 52 (getvar "ERRNO"))) (setq ok t))
      ((null s) (princ "\n고른 객체가 없습니다."))
      ((not (wcmatch (setq typ (cdr (assoc 0 (setq d (entget (car s)))))) "LINE,ARC,LWPOLYLINE,SPLINE,ELLIPSE,CIRCLE"))
       (princ (strcat "\n[주의] 이을 수 없는 객체입니다: " typ)))
      ((vlax-curve-isClosed (car s)) (princ "\n[주의] 닫힌 곡선은 끝이 없습니다. 열린 곡선을 고르세요."))
      ((not (crv:plane-ok d)) (princ "\n[주의] 지금 UCS 평면과 곡선 평면이 다릅니다."))
      ((null (caddr (setq res (crv:end-info (car s) (cadr s)))))
       (setq res nil)
       (princ "\n[주의] 이 끝에서 방향을 알 수 없습니다."))
      (t (setq ok t))))
  res)

(defun crv:pick-end2 (a / b ok)
  (while (not ok)
    (setq b (crv:pick-end "\n이을 두 번째 곡선의 끝 쪽을 클릭하세요: "))
    (if (and b (eq (car a) (car b)) (= (cadddr a) (cadddr b)))
      (princ "\n[주의] 첫 번째와 같은 끝입니다. 다른 끝을 고르세요.")
      (setq ok t)))
  b)

;; 같은 다리 길이 바이아크의 다리 길이
(defun crv:biarc-eqd (p1 t1 p2 t2 / v tt den vt s)
  (setq v   (crv:v- p2 p1)
        tt  (crv:v+ t1 t2)
        den (* 2.0 (- 1.0 (crv:dot t1 t2)))
        vt  (crv:dot v tt)
        s   (sqrt (max 0.0 (+ (* vt vt) (* den (crv:dot v v))))))
  (if (>= vt 0.0)
    (if (> (+ vt s) 1e-14) (/ (crv:dot v v) (+ vt s)))
    (if (> den 1e-14) (/ (- s vt) den))))

;; 바이아크: p1에서 t1 방향 출발, p2에 t2 방향 도착, 첫 다리 d1 → ((p1 b1) (연결점 b2)) 또는 nil
(defun crv:biarc-d (p1 t1 p2 t2 d1 / v den d2 q1 q2 j b1 b2)
  (setq v   (crv:v- p2 p1)
        den (+ (* 2.0 (crv:dot v t2)) (* 2.0 d1 (- 1.0 (crv:dot t1 t2)))))
  (if (and (> d1 1e-12) (> (abs den) 1e-14))
    (progn
      (setq d2 (/ (- (crv:dot v v) (* 2.0 d1 (crv:dot v t1))) den))
      (if (> d2 1e-12)
        (progn
          (setq q1 (crv:v+ p1 (crv:vx t1 d1))
                q2 (crv:v- p2 (crv:vx t2 d2))
                j  (crv:vx (crv:v+ (crv:vx q1 d2) (crv:vx q2 d1)) (/ 1.0 (+ d1 d2)))
                b1 (crv:bulge-s p1 j t1)
                b2 (crv:bulge-e j p2 t2))
          (if (and b1 b2)
            (list (list p1 (if (< (abs b1) 1e-10) 0.0 b1)) (list j (if (< (abs b2) 1e-10) 0.0 b2)))))))))

;; 모양 찾기 비용: "near" = 연결점과 커서 거리, "mm" = 더 급한 쪽 곡률 (q = p2)
(defun crv:blend-cost (r mode q)
  (if (= mode "near")
    (crv:dist (car (cadr r)) q)
    (max (crv:arc-k (car (car r)) (car (cadr r)) (cadr (car r)))
         (crv:arc-k (car (cadr r)) q (cadr (cadr r))))))

;; 한쪽으로만 도는지 (S자가 아닌지)
(defun crv:blend-mono-p (r)
  (>= (* (cadr (car r)) (cadr (cadr r))) 0.0))

;; 기본 모양: 한쪽으로만 도는 모양 중 가장 완만한 것 (한 원호 / 직선+호 / 호+직선),
;;           그런 모양이 없으면(S자가 필요하면) 가장 완만한 S자
(defun crv:blend-default (p1 t1 p2 t2 d0 / v w c x s u d2 cands best bk r k)
  (setq v (crv:v- p2 p1) w (crv:v+ t1 t2) c (crv:dot t1 t2))
  (setq cands (list d0))
  (if (> (crv:len w) 1e-9)
    (progn
      ;; 직선 + 호: p1에서 곧게 가다가 호
      (if (> (abs (setq x (crv:crs t1 w))) 1e-12)
        (progn
          (setq s (/ (crv:crs v w) x) u (/ (crv:crs t1 v) x))
          (if (and (> s 1e-9) (> u 1e-9)) (setq cands (cons (* 0.5 s) cands)))))
      ;; 호 + 직선: 호로 돌고 나서 p2까지 곧게
      (if (> (abs (setq x (crv:crs w t2))) 1e-12)
        (progn
          (setq s (/ (crv:crs w v) x) u (/ (crv:crs v t2) x))
          (if (and (> s 1e-9) (> u 1e-9))
            (progn
              (setq d2 (* 0.5 s)
                    x  (+ (* 2.0 d2 (- 1.0 c)) (* 2.0 (crv:dot v t1))))
              (if (> (abs x) 1e-14)
                (setq cands (cons (/ (- (crv:dot v v) (* 2.0 d2 (crv:dot v t2))) x) cands)))))))))
  (foreach d cands
    (if (and (setq r (crv:biarc-d p1 t1 p2 t2 d)) (crv:blend-mono-p r))
      (progn
        (setq k (crv:blend-cost r "mm" p2))
        (if (or (null bk) (< k bk)) (setq bk k best d)))))
  (cond (best) ((crv:blend-search p1 t1 p2 t2 d0 "mm" p2)) (t d0)))

(defun crv:blend-f (p1 t1 p2 t2 d0 s mode q / r)
  (if (setq r (crv:biarc-d p1 t1 p2 t2 (* d0 (expt 2.0 s)))) (crv:blend-cost r mode q) 1e300))

;; 다리 길이를 d0의 1/256~256배에서 찾기 → 가장 좋은 d1 (못 찾으면 nil)
(defun crv:blend-search (p1 t1 p2 t2 d0 mode q / k c best bc lo hi m1 m2)
  (setq k -32)
  (while (<= k 32)
    (setq c (crv:blend-f p1 t1 p2 t2 d0 (/ k 4.0) mode q))
    (if (and (< c 1e299) (or (null bc) (< c bc))) (setq bc c best k))
    (setq k (1+ k)))
  (if best
    (progn
      (setq lo (/ (- best 1) 4.0) hi (/ (+ best 1) 4.0))
      (repeat 30
        (setq m1 (+ lo (/ (- hi lo) 3.0)) m2 (- hi (/ (- hi lo) 3.0)))
        (if (< (crv:blend-f p1 t1 p2 t2 d0 m1 mode q) (crv:blend-f p1 t1 p2 t2 d0 m2 mode q))
          (setq hi m2)
          (setq lo m1)))
      (setq c (* d0 (expt 2.0 (* 0.5 (+ lo hi)))))
      (if (crv:biarc-d p1 t1 p2 t2 c) c (* d0 (expt 2.0 (/ best 4.0)))))))

(defun crv:blend-j (p1 t1 p2 t2 dd / r)
  (if (setq r (crv:biarc-d p1 t1 p2 t2 dd)) (car (cadr r))))

(defun crv:blend-show (p1 t1 p2 t2 dd hl / px r)
  (setq px (crv:px))
  (redraw)
  (if (setq r (crv:biarc-d p1 t1 p2 t2 dd))
    (progn
      (grvecs (crv:vlines *crv-pcol* (crv:pl-pts (list (car r) (cadr r) (list p2 0.0)) nil px) nil))
      (grvecs (crv:vshape (if hl 1 *crv-acol*) (car (cadr r)) (* (if hl 6.5 4.0) px) "ring"))))
  (grvecs (crv:vshape 3 p1 (* 3.0 px) "sq"))
  (grvecs (crv:vshape 3 p2 (* 3.0 px) "sq")))

(defun crv:joinable-p (a b)
  (and (wcmatch (cdr (assoc 0 (entget (car a)))) "LINE,ARC,LWPOLYLINE")
       (wcmatch (cdr (assoc 0 (entget (car b)))) "LINE,ARC,LWPOLYLINE")
       (not (crv:locked-p (entget (car a))))
       (not (crv:locked-p (entget (car b))))))

(defun crv:can-join (a b) (and (= *crv-bjoin* 1) (crv:joinable-p a b)))

(defun crv:blend-prompt (join)
  (princ (strcat "\n호 블렌드 — 가운데 점을 끌어 모양을 바꾸고 클릭·Enter 로 확정하세요 <합치기 " (if join "켬" "끔")
                 "> [기본 모양(D)/합치기(J)/스플라인 블렌드(S)]: ")))

;; 합칠 정점 목록: 첫 곡선(p1에서 끝나게) + 블렌드 + 두 번째 곡선(p2에서 시작하게)
(defun crv:join-verts (a b r same / v1 v2 res)
  (setq v1 (crv:ent-verts (car a)))
  (if (= (cadddr a) "S") (setq v1 (crv:vrev v1)))
  (setq v1  (reverse (cdr (reverse v1)))
        res (append (mapcar '(lambda (v) (list (car v) (cadr v) t)) v1)
                    (list (list (car (car r)) (cadr (car r)) t)
                          (list (car (cadr r)) (cadr (cadr r)) nil))))
  (if (not same)
    (progn
      (setq v2 (crv:ent-verts (car b)))
      (if (= (cadddr b) "E") (setq v2 (crv:vrev v2)))
      (setq res (append res (mapcar '(lambda (v) (list (car v) (cadr v) t)) v2)))))
  res)

(defun crv:blend-make (a b p1 t1 p2 t2 dd join / r k1 k2 vs same e)
  (setq r    (crv:biarc-d p1 t1 p2 t2 dd)
        k1   (crv:arc-k p1 (car (cadr r)) (cadr (car r)))
        k2   (crv:arc-k (car (cadr r)) p2 (cadr (cadr r)))
        same (eq (car a) (car b)))
  (vla-StartUndoMark *crv-doc*)
  (setq *crv-undo* t)
  (if join
    (progn
      (setq vs (crv:join-verts a b r same))
      (setq vs (crv:pl-merge (crv:pl-dedup vs same) same (* 1e-6 (crv:vs-size vs))))
      (if (setq e (entmake (crv:dxf-pl vs same (crv:props (entget (car a))) nil)))
        (progn (entdel (car a)) (if (not same) (entdel (car b))))))
    (progn
      (setq vs (crv:pl-merge (list (list p1 (cadr (car r)) t) (list (car (cadr r)) (cadr (cadr r)) nil) (list p2 0.0 t))
                             nil (* 1e-6 (crv:dist p1 p2))))
      (setq e (entmake (crv:dxf-pl vs nil (crv:cur-props) nil)))))
  (vla-EndUndoMark *crv-doc*)
  (setq *crv-undo* nil)
  (if e
    (princ (strcat "\n[완료] 블렌드를 " (if join (if same "만들어 닫힌 폴리선으로 합쳤습니다" "만들어 원래 선과 합쳤습니다") "만들었습니다")
                   " ("
                   (if (and (> (* (cadr (car r)) (cadr (cadr r))) 0.0) (< (abs (- k1 k2)) (* 1e-9 (max k1 k2))))
                     (strcat "R" (rtos (/ 1.0 k1) 2 2))
                     (strcat (crv:piece-str p1 (car (cadr r)) (cadr (car r)))
                             " + "
                             (crv:piece-str (car (cadr r)) p2 (cadr (cadr r)))))
                   ")."))
    (princ "\n[오류] 블렌드를 만들 수 없습니다.")))

(defun crv:spl-p (a) (wcmatch (cdr (assoc 0 (entget (car a)))) "SPLINE,ELLIPSE"))

;; 고른 끝에서 바깥쪽으로 나갈 때의 부호 있는 곡률 (왼쪽으로 돌면 +)
(defun crv:end-k (a / e u d1 d2 k)
  (setq e  (car a)
        u  (if (= (cadddr a) "E") (vlax-curve-getEndParam e) (vlax-curve-getStartParam e))
        d1 (crv:2d (trans (vlax-curve-getFirstDeriv e u) 0 1 t))
        d2 (crv:2d (trans (vlax-curve-getSecondDeriv e u) 0 1 t))
        k  (if (> (crv:len d1) 1e-12) (/ (crv:crs d1 d2) (expt (crv:len d1) 3)) 0.0))
  (if (= (cadddr a) "E") k (- k)))

(defun crv:blend (/ a b p1 t1 p2 t2 k1 k2 mode)
  (if (and (setq a (crv:pick-end "\n이을 첫 번째 곡선의 끝 쪽을 클릭하세요: "))
           (setq b (crv:pick-end2 a)))
    (progn
      (setq p1      (crv:2d (cadr a))
            t1      (caddr a)
            p2      (crv:2d (cadr b))
            t2      (crv:vx (caddr b) -1.0)
            *crv-z* (caddr (cadr a)))
      (cond
        ((> (abs (- (caddr (cadr a)) (caddr (cadr b)))) 1e-6) (princ "\n[주의] 두 끝의 높이(Z)가 다릅니다."))
        ((< (crv:dist p1 p2) 1e-9) (princ "\n[알림] 두 끝이 이미 붙어 있습니다."))
        (t
         ;; 스플라인이 끼면 스플라인 블렌드, 아니면 호 블렌드 (S로 전환)
         (setq k1   (crv:end-k a)
               k2   (- (crv:end-k b))
               mode (if (or (crv:spl-p a) (crv:spl-p b)) "S" "A"))
         (while mode
           (setq mode (if (= mode "A")
                        (crv:ablend a b p1 t1 p2 t2)
                        (crv:sblend a b p1 t1 k1 p2 t2 k2)))))))))

;; 호 블렌드 → 끝나면 nil, S를 누르면 "S"
(defun crv:ablend (a b p1 t1 p2 t2 / d0 dd go gr code val px raw grab hov ch join nd ret)
  (if (not (and (setq d0 (crv:biarc-eqd p1 t1 p2 t2)) (crv:biarc-d p1 t1 p2 t2 d0)))
    (progn (princ "\n[알림] 이 두 끝은 호로 이을 수 없어 스플라인 블렌드로 바꿨습니다.") "S")
    (progn
      (setq d0 (crv:blend-default p1 t1 p2 t2 d0) dd d0 go t join (crv:can-join a b))
      (if (and (= *crv-bjoin* 1) (not join))
        (princ "\n[알림] 스플라인·타원·잠긴 레이어와는 호 블렌드를 합치지 않습니다 (S = 스플라인 블렌드)."))
      (crv:blend-prompt join)
      (crv:blend-show p1 t1 p2 t2 dd nil)
      (while go
        (setq gr (grread t 13 0) code (car gr) val (cadr gr) px (crv:px))
        (cond
          ;; 마우스 이동: 잡고 있으면 연결점이 커서를 따라감
          ((= code 5)
           (setq raw (crv:2d val))
           (if grab
             (if (setq nd (crv:blend-search p1 t1 p2 t2 d0 "near" raw)) (setq dd nd))
             (setq hov (< (crv:dist raw (crv:blend-j p1 t1 p2 t2 dd)) (* 7.0 px))))
           (crv:blend-show p1 t1 p2 t2 dd (or grab hov)))
          ;; 클릭: 가운데 점 = 잡기/놓기, 그 밖 = 확정
          ((= code 3)
           (setq raw (crv:2d val))
           (cond
             (grab (setq grab nil))
             ((< (crv:dist raw (crv:blend-j p1 t1 p2 t2 dd)) (* 7.0 px)) (setq grab t))
             (t (setq go nil)))
           (if go (crv:blend-show p1 t1 p2 t2 dd grab)))
          ((member code '(11 25)) (if grab (setq grab nil) (setq go nil)))
          ((= code 2)
           (if (member val '(13 32))
             (if grab (setq grab nil) (setq go nil))
             (progn
               (setq ch (crv:key val))
               (cond
                 ((= ch "D") (setq dd d0) (princ "\n[알림] 기본 모양으로 되돌렸습니다."))
                 ((= ch "J")
                  (if (crv:joinable-p a b)
                    (progn
                      (setq *crv-bjoin* (- 1 *crv-bjoin*) join (crv:can-join a b))
                      (crv:cfg-save))
                    (princ "\n[주의] 스플라인·타원·잠긴 레이어와는 합칠 수 없습니다."))
                  (crv:blend-prompt join))
                 ((= ch "S") (setq go nil ret "S")))))
           (if go (crv:blend-show p1 t1 p2 t2 dd grab)))))
      (redraw)
      (if (not ret) (crv:blend-make a b p1 t1 p2 t2 dd join))
      ret)))

;;; ---------- 스플라인 블렌드 (곡률까지 잇는 G2 / 접선만 잇는 G1) ----------
;; 3차 B-스플라인, 조정점 6개, 매듭 0 0 0 0 1 2 3 3 3 3
;;   P0 P1 P2 = 시작점·접선·곡률,  P3 P4 P5 = 끝점·접선·곡률
;;   P1 = p1 + a·t1, P2 = P1 + a·t1 + 3·k1·a²·n1  (끝도 같은 식)
(setq *crv-sbk* '(0.0 0.0 0.0 0.0 1.0 2.0 3.0 3.0 3.0 3.0))

(defun crv:sb-cvs (p1 t1 k1 p2 t2 k2 a b g2 / q1 q4)
  (setq q1 (crv:v+ p1 (crv:vx t1 a))
        q4 (crv:v- p2 (crv:vx t2 b)))
  (list p1
        q1
        (crv:v+ (crv:v+ q1 (crv:vx t1 a)) (crv:vx (crv:lnorm t1) (if g2 (* 3.0 k1 a a) 0.0)))
        (crv:v+ (crv:v- q4 (crv:vx t2 b)) (crv:vx (crv:lnorm t2) (if g2 (* 3.0 k2 b b) 0.0)))
        q4
        p2))

;; de Boor (3차)
(defun crv:deboor (cvs kn u / p k j r d nd den al)
  (setq p 3 k 3)
  (while (and (< k (1- (length cvs))) (>= u (nth (1+ k) kn))) (setq k (1+ k)))
  (setq j 0)
  (repeat 4 (setq d (cons (nth (+ j (- k p)) cvs) d) j (1+ j)))
  (setq d (reverse d) r 1)
  (while (<= r p)
    (setq nd nil j 0)
    (repeat 4
      (if (< j r)
        (setq nd (cons (nth j d) nd))
        (setq den (- (nth (+ j 1 (- k r)) kn) (nth (+ j (- k p)) kn))
              al  (if (> den 1e-14) (/ (- u (nth (+ j (- k p)) kn)) den) 0.0)
              nd  (cons (crv:v+ (crv:vx (nth (1- j) d) (- 1.0 al)) (crv:vx (nth j d) al)) nd)))
      (setq j (1+ j)))
    (setq d (reverse nd) r (1+ r)))
  (nth p d))

(defun crv:sb-pts (cvs / i res)
  (setq i 0)
  (repeat 49 (setq res (cons (crv:deboor cvs *crv-sbk* (* 3.0 (/ i 48.0))) res) i (1+ i)))
  (reverse res))

;; 기본 핸들: 두 끝 거리의 1/5, 끝이 많이 휘었으면 고리가 안 생기게 짧게
(defun crv:sb-default (p1 t1 k1 p2 t2 k2 / l a b)
  (setq l (crv:dist p1 p2) a (* 0.2 l) b (* 0.2 l))
  (if (> (abs k1) 1e-12) (setq a (min a (/ 1.0 (* 3.0 (abs k1))))))
  (if (> (abs k2) 1e-12) (setq b (min b (/ 1.0 (* 3.0 (abs k2))))))
  (list (max a (* 1e-3 l)) (max b (* 1e-3 l))))

(defun crv:sb-hit (q p1 t1 p2 t2 aa bb px)
  (cond ((< (crv:dist q (crv:v+ p1 (crv:vx t1 aa))) (* 7.0 px)) 1)
        ((< (crv:dist q (crv:v- p2 (crv:vx t2 bb))) (* 7.0 px)) 2)))

(defun crv:sjoinable-p (a b)
  (and (not (crv:locked-p (entget (car a)))) (not (crv:locked-p (entget (car b))))))

(defun crv:can-sjoin (a b) (and (= *crv-bjoin* 1) (crv:sjoinable-p a b)))

(defun crv:sb-prompt (join)
  (princ (strcat "\n스플라인 블렌드(" (if (= *crv-bg2* 1) "G2" "G1")
                 ") — 양 끝 핸들을 끌어 모양을 바꾸고 클릭·Enter 로 확정하세요 <합치기 " (if join "켬" "끔")
                 "> [기본 모양(D)/합치기(J)/연속성 G1·G2(G)/호 블렌드(S)]: ")))

(defun crv:sb-show (p1 t1 k1 p2 t2 k2 aa bb hl / px cvs)
  (setq px  (crv:px)
        cvs (crv:sb-cvs p1 t1 k1 p2 t2 k2 aa bb (= *crv-bg2* 1)))
  (redraw)
  (grvecs (crv:vlines *crv-pcol* (crv:sb-pts cvs) nil))
  (grvecs (list 8 (crv:3 p1) (crv:3 (cadr cvs)) 8 (crv:3 p2) (crv:3 (nth 4 cvs))))
  (grvecs (crv:vshape (if (equal hl 1) 1 *crv-acol*) (cadr cvs) (* (if (equal hl 1) 6.5 4.0) px) "ring"))
  (grvecs (crv:vshape (if (equal hl 2) 1 *crv-acol*) (nth 4 cvs) (* (if (equal hl 2) 6.5 4.0) px) "ring"))
  (grvecs (crv:vshape 3 p1 (* 3.0 px) "sq"))
  (grvecs (crv:vshape 3 p2 (* 3.0 px) "sq")))

(defun crv:dxf-sb (cvs props)
  (append
    (list '(0 . "SPLINE") '(100 . "AcDbEntity"))
    props
    (list '(100 . "AcDbSpline")
          (cons 210 (crv:ucsz))
          '(70 . 8) '(71 . 3)
          (cons 72 (length *crv-sbk*))
          (cons 73 (length cvs))
          '(74 . 0) '(42 . 1.0e-10) '(43 . 1.0e-10))
    (mapcar '(lambda (k) (cons 40 k)) *crv-sbk*)
    (mapcar '(lambda (p) (cons 10 (crv:w p))) cvs)))

;; JOIN: 스플라인을 기준 객체로 → 선·호·폴리선·스플라인 모두 스플라인 하나로
(defun crv:join-cmd (ents)
  (setq *crv-echo* (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (sssetfirst nil nil)                       ; 미리 고른 객체가 JOIN에 끼지 않게
  (command "_.JOIN")
  (foreach x ents (command x))
  (command "")
  (setvar "CMDECHO" *crv-echo*)
  (setq *crv-echo* nil)
  (car ents))

(defun crv:sb-make (a b cvs join / e ok g)
  (vla-StartUndoMark *crv-doc*)
  (setq *crv-undo* t)
  (setq e (entmake (crv:dxf-sb cvs (if join (crv:props (entget (car a))) (crv:cur-props)))))
  (if (and e join)
    (progn
      (crv:join-cmd (if (eq (car a) (car b)) (list (entlast) (car a)) (list (entlast) (car a) (car b))))
      ;; JOIN 이 합쳤으면 원래 곡선은 지워져 있음
      (setq ok (null (entget (car a))))))
  (vla-EndUndoMark *crv-doc*)
  (setq *crv-undo* nil
        g (if (= *crv-bg2* 1) "G2" "G1"))
  (princ (cond
           ((null e) "\n[오류] 블렌드를 만들 수 없습니다.")
           (ok (strcat "\n[완료] 스플라인 블렌드(" g ")를 만들어 원래 곡선과 합쳤습니다."))
           (join (strcat "\n[주의] 스플라인 블렌드(" g ")를 만들었지만 원래 곡선과 합치지 못했습니다."))
           (t (strcat "\n[완료] 스플라인 블렌드(" g ")를 만들었습니다.")))))

;; 스플라인 블렌드 → 끝나면 nil, S를 누르면 "A"
(defun crv:sblend (a b p1 t1 k1 p2 t2 k2 / ab aa bb go gr code val px raw grab hov ch join mn ret)
  (setq ab   (crv:sb-default p1 t1 k1 p2 t2 k2)
        aa   (car ab)
        bb   (cadr ab)
        mn   (* 1e-3 (crv:dist p1 p2))
        go   t
        join (crv:can-sjoin a b))
  (crv:sb-prompt join)
  (crv:sb-show p1 t1 k1 p2 t2 k2 aa bb nil)
  (while go
    (setq gr (grread t 13 0) code (car gr) val (cadr gr) px (crv:px))
    (cond
      ;; 마우스 이동: 잡은 핸들은 접선 방향으로만 늘고 줄어듦
      ((= code 5)
       (setq raw (crv:2d val))
       (cond
         ((equal grab 1) (setq aa (max mn (crv:dot (crv:v- raw p1) t1))))
         ((equal grab 2) (setq bb (max mn (crv:dot (crv:v- p2 raw) t2))))
         (t (setq hov (crv:sb-hit raw p1 t1 p2 t2 aa bb px))))
       (crv:sb-show p1 t1 k1 p2 t2 k2 aa bb (cond (grab) (hov))))
      ;; 클릭: 핸들 = 잡기/놓기, 그 밖 = 확정
      ((= code 3)
       (setq raw (crv:2d val))
       (cond
         (grab (setq grab nil))
         ((setq grab (crv:sb-hit raw p1 t1 p2 t2 aa bb px)))
         (t (setq go nil)))
       (if go (crv:sb-show p1 t1 k1 p2 t2 k2 aa bb grab)))
      ((member code '(11 25)) (if grab (setq grab nil) (setq go nil)))
      ((= code 2)
       (if (member val '(13 32))
         (if grab (setq grab nil) (setq go nil))
         (progn
           (setq ch (crv:key val))
           (cond
             ((= ch "D")
              (setq ab (crv:sb-default p1 t1 k1 p2 t2 k2) aa (car ab) bb (cadr ab))
              (princ "\n[알림] 기본 모양으로 되돌렸습니다."))
             ((= ch "G")
              (setq *crv-bg2* (- 1 *crv-bg2*))
              (crv:cfg-save)
              (crv:sb-prompt join))
             ((= ch "J")
              (if (crv:sjoinable-p a b)
                (progn
                  (setq *crv-bjoin* (- 1 *crv-bjoin*) join (crv:can-sjoin a b))
                  (crv:cfg-save))
                (princ "\n[주의] 잠긴 레이어의 곡선과는 합칠 수 없습니다."))
              (crv:sb-prompt join))
             ((= ch "S") (setq go nil ret "A")))))
       (if go (crv:sb-show p1 t1 k1 p2 t2 k2 aa bb grab)))))
  (redraw)
  (if (not ret) (crv:sb-make a b (crv:sb-cvs p1 t1 k1 p2 t2 k2 aa bb (= *crv-bg2* 1)) join))
  ret)

;;; ============================================================
;;;  CRT : 접선 (점→원 / 두 원 공통접선 / 기존 선을 원에 붙이기)
;;; ============================================================
(defun crv:pol (c a r) (list (+ (car c) (* r (cos a))) (+ (cadr c) (* r (sin a)))))
(defun crv:acos (x) (atan (sqrt (max 0.0 (- 1.0 (* x x)))) x))

(defun crv:lw-z (d / nrm)
  (setq nrm (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0))))
  (caddr (crv:o2u (cdr (assoc 10 d)) (cond ((cdr (assoc 38 d))) (0.0)) nrm)))

;; 원·호 → (중심 반지름 z), 폴리선은 고른 곳에서 가장 가까운 호 구간
(defun crv:circ-of (d pk / nrm c best bd dd)
  (if (= (cdr (assoc 0 d)) "LWPOLYLINE")
    (progn
      (foreach sg (crv:pl-segs (crv:lw-ucs d) (= 1 (logand 1 (cdr (assoc 70 d)))))
        (if (> (abs (caddr sg)) 1e-9)
          (progn
            (setq dd (crv:d-arc pk (car sg) (cadr sg) (caddr sg)))
            (if (or (null bd) (< dd bd)) (setq bd dd best (crv:arc-geo (car sg) (cadr sg) (caddr sg)))))))
      (if best (list (car best) (cadr best) (crv:lw-z d))))
    (progn
      (setq nrm (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
            c   (trans (cdr (assoc 10 d)) nrm 1))
      (list (crv:2d c) (cdr (assoc 40 d)) (caddr c)))))

;; → (중심 반지름 z 고른점)
(defun crv:pick-circle (msg / s d typ ok res)
  (while (not ok)
    (setvar "ERRNO" 0)
    (setq s (entsel msg))
    (cond
      ((and (null s) (= 52 (getvar "ERRNO"))) (setq ok t))
      ((null s) (princ "\n고른 객체가 없습니다."))
      ((not (wcmatch (setq typ (cdr (assoc 0 (setq d (entget (car s)))))) "CIRCLE,ARC,LWPOLYLINE"))
       (princ (strcat "\n[주의] 원·호·폴리선의 호 구간만 고를 수 있습니다: " typ)))
      ((not (crv:plane-ok d)) (princ "\n[주의] 지금 UCS 평면과 원의 평면이 다릅니다."))
      ((setq res (crv:circ-of d (crv:2d (cadr s))))
       (setq res (append res (list (crv:2d (cadr s)))) ok t))
      (t (princ "\n[주의] 고른 곳이 직선 구간입니다. 호 구간을 고르세요."))))
  res)

;; 점에서 원에 그은 두 접점
(defun crv:tan-pts (p c r / d b f)
  (if (> (setq d (crv:dist p c)) (+ r 1e-12))
    (progn
      (setq b (angle c p) f (crv:acos (/ r d)))
      (list (crv:pol c (+ b f) r) (crv:pol c (- b f) r)))))

(defun crv:nearest (pts q / best bd d)
  (foreach p pts
    (setq d (crv:dist p q))
    (if (or (null bd) (< d bd)) (setq bd d best p)))
  best)

;; 두 원의 공통접선 ((접점1 접점2) ...) 바깥 2 + 안쪽 2
(defun crv:common-tans (c1 r1 c2 r2 / d g a res)
  (setq d (crv:dist c1 c2))
  (if (> d 1e-12)
    (progn
      (setq g (angle c1 c2))
      (if (> d (+ (abs (- r1 r2)) 1e-12))
        (progn
          (setq a (crv:acos (/ (- r1 r2) d)))
          (foreach s (list a (- a))
            (setq res (cons (list (crv:pol c1 (+ g s) r1) (crv:pol c2 (+ g s) r2)) res)))))
      (if (> d (+ r1 r2 1e-12))
        (progn
          (setq a (crv:acos (/ (+ r1 r2) d)))
          (foreach s (list a (- a))
            (setq res (cons (list (crv:pol c1 (+ g s) r1) (crv:pol c2 (+ g s pi) r2)) res)))))))
  (reverse res))

;; 후보 선분 중 점에 가장 가까운 것의 번호
(defun crv:seg-near (sols q / i best bd d)
  (setq i 0)
  (foreach s sols
    (setq d (crv:d-seg q (car s) (cadr s)))
    (if (or (null bd) (< d bd)) (setq bd d best i))
    (setq i (1+ i)))
  best)

;; 후보 선분들 표시 (k번째 강조)
(defun crv:sols-show (sols k / px i)
  (setq px (crv:px) i 0)
  (redraw)
  (foreach s sols
    (if (/= i k) (grvecs (list 8 (crv:3 (car s)) (crv:3 (cadr s)))))
    (setq i (1+ i)))
  (if k
    (progn
      (grvecs (list *crv-pcol* (crv:3 (car (nth k sols))) (crv:3 (cadr (nth k sols)))))
      (grvecs (crv:vshape *crv-acol* (car (nth k sols)) (* 4.0 px) "ring"))
      (grvecs (crv:vshape *crv-acol* (cadr (nth k sols)) (* 4.0 px) "ring")))))

;; 후보 중 고르기: 커서에 가까운 것 강조, 클릭=그것, Enter=강조된 것 → 번호 또는 nil
(defun crv:sols-pick (sols k0 msg keys / go gr code val k res ch)
  (setq k k0 go t)
  (princ msg)
  (crv:sols-show sols k)
  (while go
    (setq gr (grread t 13 0) code (car gr) val (cadr gr))
    (cond
      ((= code 5) (setq k (crv:seg-near sols (crv:2d val))) (crv:sols-show sols k))
      ((= code 3) (setq res (crv:seg-near sols (crv:2d val)) go nil))
      ((member code '(11 25)) (setq res k go nil))
      ((= code 2)
       (cond
         ((member val '(13 32)) (setq res k go nil))
         ((member (setq ch (crv:key val)) keys) (setq res ch go nil))))))
  (redraw)
  res)

(defun crv:make-line (p q / e)
  (vla-StartUndoMark *crv-doc*)
  (setq *crv-undo* t)
  (setq e (entmake (append (list '(0 . "LINE") '(100 . "AcDbEntity"))
                           (crv:cur-props)
                           (list '(100 . "AcDbLine") (cons 10 (crv:w p)) (cons 11 (crv:w q))))))
  (vla-EndUndoMark *crv-doc*)
  (setq *crv-undo* nil)
  (setvar "LASTPOINT" (crv:3 q))
  (princ (if e (strcat "\n[완료] 접선을 그렸습니다 (길이 " (rtos (crv:dist p q) 2 2) ").") "\n[오류] 선을 만들 수 없습니다.")))

(defun crv:tan-prompt ()
  (princ "\n접선 시작점 또는 [두 번째 원(C)/선 붙이기(L)/반대쪽(F)]: "))

(defun crv:tan-show (c r p hint snp / px tp)
  (setq px (crv:px))
  (redraw)
  (if (and p (setq tp (crv:nearest (crv:tan-pts p c r) hint)))
    (progn
      (grvecs (list *crv-pcol* (crv:3 p) (crv:3 tp)))
      (grvecs (crv:vshape *crv-acol* tp (* 4.0 px) "ring"))))
  (if snp (grvecs (crv:vshape 30 (crv:2d (car snp)) (* 5.0 px) (cdr snp)))))

;; 점 → 원 접선
(defun crv:tangent (/ ci c r hint go gr code val cr p tp buf ch pt)
  (if (setq ci (crv:pick-circle "\n원·호를 접점이 생길 쪽에서 클릭하세요: "))
    (progn
      (setq c (car ci) r (cadr ci) *crv-z* (caddr ci) hint (cadddr ci) go t buf "")
      (crv:tan-prompt)
      (while go
        (setq gr (grread t 13 0) code (car gr) val (cadr gr))
        (cond
          ((= code 5)
           (setq cr (crv:cursor val nil) p (car cr))
           (crv:tan-show c r p hint (cadr cr)))
          ((= code 3)
           (setq p (car (crv:cursor val nil)))
           (if (setq tp (crv:nearest (crv:tan-pts p c r) hint))
             (progn (redraw) (crv:make-line p tp) (setq go nil))
             (princ "\n[주의] 원 안쪽 점입니다. 원 밖을 클릭하세요.")))
          ((member code '(11 25)) (setq go nil))
          ((= code 2)
           (cond
             ((and (member val '(13 32)) (/= buf ""))
              (if (and (setq pt (crv:parse buf (crv:2d (getvar "LASTPOINT")) nil))
                       (setq tp (crv:nearest (crv:tan-pts pt c r) hint)))
                (progn (redraw) (crv:make-line pt tp) (setq go nil))
                (progn
                  (princ "\n[주의] 입력을 읽을 수 없거나 원 안쪽 점입니다.")
                  (setq buf "")
                  (crv:tan-prompt))))
             ((member val '(13 32)) (setq go nil))
             ((= val 8) (if (/= buf "") (setq buf (crv:bs buf))))
             ((crv:numkey-p val) (setq buf (strcat buf (chr val))) (princ (chr val)))
             ((/= buf "") nil)
             (t
              (setq ch (crv:key val))
              (cond
                ((= ch "F") (setq hint (crv:v- (crv:vx c 2.0) hint)) (crv:tan-show c r p hint nil))
                ((= ch "C") (setq go nil) (redraw) (crv:tan-2c c r hint))
                ((= ch "L") (setq go nil) (redraw) (crv:tan-attach c r hint))))))))
      (redraw))))

;; 두 원 공통접선
(defun crv:tan-2c (c1 r1 h1 / ci sols k)
  (if (setq ci (crv:pick-circle "\n두 번째 원·호를 고르세요: "))
    (cond
      ((> (abs (- *crv-z* (caddr ci))) 1e-6) (princ "\n[주의] 두 원의 높이(Z)가 다릅니다."))
      ((null (setq sols (crv:common-tans c1 r1 (car ci) (cadr ci))))
       (princ "\n[알림] 한 원이 다른 원 안에 있어 공통접선이 없습니다."))
      (t
       ;; 처음 강조: 두 원을 클릭한 쪽에 접하는 것
       (setq k (crv:sol-best sols h1 (cadddr ci)))
       (if (setq k (crv:sols-pick sols k "\n원하는 접선 가까이 클릭하세요 (Enter = 강조된 접선): " nil))
         (crv:make-line (car (nth k sols)) (cadr (nth k sols))))))))

;; 두 접점이 각각 h1, h2에 가장 가까운 후보 번호
(defun crv:sol-best (sols h1 h2 / i best bd d)
  (setq i 0)
  (foreach s sols
    (setq d (+ (crv:dist (car s) h1) (crv:dist (cadr s) h2)))
    (if (or (null bd) (< d bd)) (setq bd d best i))
    (setq i (1+ i)))
  best)

;; 붙일 선 고르기 → (객체 종류 고정끝 움직일끝 끝번호)  끝번호: 선 10/11, 폴리선 정점 번호
(defun crv:pick-attach (msg / s d typ ok res vs pk n a b)
  (while (not ok)
    (setvar "ERRNO" 0)
    (setq s (entsel msg))
    (cond
      ((and (null s) (= 52 (getvar "ERRNO"))) (setq ok t))
      ((null s) (princ "\n고른 객체가 없습니다."))
      ((crv:bad-attach-p (setq d (entget (car s)))) nil)
      (t
       (setq typ (cdr (assoc 0 d)) pk (crv:2d (cadr s)))
       (cond
         ((= typ "LINE")
          (setq a (crv:2d (trans (cdr (assoc 10 d)) 0 1)) b (crv:2d (trans (cdr (assoc 11 d)) 0 1)))
          (setq res (if (< (crv:dist pk a) (crv:dist pk b)) (list (car s) typ b a 10) (list (car s) typ a b 11))
                ok t))
         ((and (= typ "LWPOLYLINE") (= 0 (logand 1 (cdr (assoc 70 d)))))
          (setq vs (crv:lw-ucs d) n (length vs))
          (if (< (crv:dist pk (car (car vs))) (crv:dist pk (car (last vs))))
            (if (< (abs (cadr (car vs))) 1e-9)
              (setq res (list (car s) typ (car (cadr vs)) (car (car vs)) 0) ok t)
              (princ "\n[주의] 그 끝 구간이 곡선입니다. 직선 구간의 끝을 고르세요."))
            (if (< (abs (cadr (nth (- n 2) vs))) 1e-9)
              (setq res (list (car s) typ (car (nth (- n 2) vs)) (car (last vs)) (1- n)) ok t)
              (princ "\n[주의] 그 끝 구간이 곡선입니다. 직선 구간의 끝을 고르세요."))))
         (t (princ "\n[주의] 선(LINE)이나 열린 폴리선의 직선 끝 구간만 붙일 수 있습니다."))))))
  res)

(defun crv:bad-attach-p (d)
  (cond
    ((crv:locked-p d) (princ "\n[주의] 잠긴 레이어의 객체입니다.") t)
    ((not (crv:plane-ok d)) (princ "\n[주의] 지금 UCS 평면과 선의 평면이 다릅니다.") t)))

;; 붙이기 후보: 회전(고정끝 기준) / 평행이동 → ((새고정끝 새움직일끝) ...)
(defun crv:attach-sols (c r f m mode / u nl s)
  (if (= mode "P")
    (if (setq u (crv:unit (crv:v- m f)))
      (progn
        (setq nl (crv:lnorm u) s (crv:dot (crv:v- c f) nl))
        (mapcar '(lambda (dl) (list (crv:v+ f (crv:vx nl dl)) (crv:v- c (crv:vx nl (- s dl)))))
                (list (- s r) (+ s r)))))
    (mapcar '(lambda (tp) (list f tp)) (crv:tan-pts f c r))))

(defun crv:lw-setv (d k p / i nrm o res)
  (setq nrm (cond ((cdr (assoc 210 d))) ('(0.0 0.0 1.0)))
        o   (trans (list (car p) (cadr p) *crv-z*) 1 nrm)
        i   -1)
  (foreach x d
    (if (= (car x) 10)
      (progn (setq i (1+ i)) (setq res (cons (if (= i k) (list 10 (car o) (cadr o)) x) res)))
      (setq res (cons x res))))
  (reverse res))

;; 기존 선을 원에 붙이기
(defun crv:tan-attach (c r hint / at e d typ mode sols k res go)
  (if (setq at (crv:pick-attach "\n원에 붙일 선의 움직일 끝 쪽을 클릭하세요: "))
    (progn
      (setq e (car at) d (entget e) typ (cadr at) mode "R" go t)
      (if (> (abs (- *crv-z* (if (= typ "LINE") (caddr (trans (cdr (assoc 10 d)) 0 1)) (crv:lw-z d)))) 1e-6)
        (progn (princ "\n[주의] 선과 원의 높이(Z)가 다릅니다.") (setq go nil)))
      (while go
        (setq sols (crv:attach-sols c r (caddr at) (cadddr at) mode))
        (cond
          ((null sols)
           (princ (if (= mode "R")
                    "\n[주의] 고정된 끝이 원 안에 있어 회전으로는 붙일 수 없습니다 (평행이동은 P)."
                    "\n[주의] 붙일 수 없습니다."))
           (if (and (= mode "R") (= typ "LINE"))
             (setq mode "P")
             (setq go nil)))
          (t
           (setq k   (crv:seg-near sols (cadddr at))
                 res (crv:sols-pick sols k
                                    (strcat "\n붙일 위치 가까이 클릭하세요 (Enter = 강조된 위치) <"
                                            (if (= mode "R") "고정끝 기준 회전" "평행이동") ">"
                                            (if (= typ "LINE") " [회전(R)/평행이동(P)]: " ": "))
                                    (if (= typ "LINE") '("R" "P"))))
           (cond
             ((eq (type res) 'STR) (setq mode res))
             (res
              (setq go nil)
              (vla-StartUndoMark *crv-doc*)
              (setq *crv-undo* t)
              (if (= typ "LINE")
                (entmod (subst (cons (if (= (nth 4 at) 10) 11 10) (crv:w (car (nth res sols))))
                               (assoc (if (= (nth 4 at) 10) 11 10) d)
                               (subst (cons (nth 4 at) (crv:w (cadr (nth res sols)))) (assoc (nth 4 at) d) d)))
                (entmod (crv:lw-setv d (nth 4 at) (cadr (nth res sols)))))
              (vla-EndUndoMark *crv-doc*)
              (setq *crv-undo* nil)
              (princ (strcat "\n[완료] 선을 원에 붙였습니다 (" (if (= mode "R") "회전" "평행이동") ").")))
             (t (setq go nil)))))))))

;;; ============================================================
;;;  명령
;;; ============================================================
(defun crv:init ()
  (regapp *crv-app*)
  (crv:cfg-load)
  (setq *crv-doc*    (vla-get-ActiveDocument (vlax-get-acad-object))
        *crv-undo*   nil
        *crv-edit-e* nil
        *crv-z*      0.0))

;; Esc·오류: 숨긴 객체 되살리고 실행 취소 묶음 닫기
(defun crv:err (msg)
  (redraw)
  (if *crv-edit-e*
    (progn (entmod (list (cons -1 *crv-edit-e*) '(60 . 0))) (setq *crv-edit-e* nil)))
  (if *crv-undo*
    (progn (vla-EndUndoMark *crv-doc*) (setq *crv-undo* nil)))
  (if *crv-echo* (progn (setvar "CMDECHO" *crv-echo*) (setq *crv-echo* nil)))
  (if (and msg
           (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*EXIT*,*BREAK*"))
           (not (vl-string-search "취소" msg)))
    (princ (strcat "\n[오류] " msg)))
  (princ))

(defun c:CRV (/ *error*)
  (setq *error* crv:err)
  (crv:init)
  (crv:draw)
  (princ))

(defun c:CRVE (/ *error*)
  (setq *error* crv:err)
  (crv:init)
  (crv:edit-cmd)
  (princ))

(defun c:CRB (/ *error*)
  (setq *error* crv:err)
  (crv:init)
  (crv:blend)
  (princ))

(defun c:CRT (/ *error*)
  (setq *error* crv:err)
  (crv:init)
  (crv:tangent)
  (princ))

(princ)
