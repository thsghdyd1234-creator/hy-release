;;; ==============================================================================
;;;  BB — 기둥 안쪽 벽선 정리 + 기둥 윤곽 선 남기기 (스케치업 넘기기 전)
;;;
;;;  1. 기준 기둥(블록·폴리선·원)을 클릭  2. 벽과 기둥이 든 영역을 고른다
;;;  같은 기둥(같은 종류·같은 레이어, 블록은 같은 이름)마다:
;;;   · 기둥 윤곽을 분해한 선을 지금 레이어 · ByLayer 로 남긴다 (원본 기둥은 그대로 — 벽선과 이어져 면이 생기게).
;;;   · 기둥 안으로 들어간 벽선(LINE)은 윤곽에서 잘라 안쪽 조각을 버린다. 안쪽인지는 조각 가운데가 윤곽 안인지로 본다
;;;     (길쭉한 벽기둥 · ㄱ·ㄷ자 기둥 · 돌아간 기둥 · 원 기둥도 맞음).
;;;   · 잘리지 않는 벽선은 손대지 않는다 (색·선 종류·그룹·핸들 그대로). 잘린 벽선도 첫 조각은 원래 선을 고쳐 남긴다.
;;;   · 잠긴 레이어의 벽선은 그대로 두고 알린다. 폴리선 벽은 XP 로 먼저 분해할 것. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun bb:ename (o) (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))

(defun bb:box (o / a b)
  (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
    (list (vlax-safearray->list a) (vlax-safearray->list b))))

(defun bb:overlap (b1 b2 tol)
  (and (<= (car (car b1)) (+ (car (cadr b2)) tol)) (<= (car (car b2)) (+ (car (cadr b1)) tol))
       (<= (cadr (car b1)) (+ (cadr (cadr b2)) tol)) (<= (cadr (car b2)) (+ (cadr (cadr b1)) tol))))

;; 기둥 → 윤곽 곡선 목록 (분해한 사본 · 폴리선은 한 번 더 분해 · 곡선이 아닌 조각은 지움)
(defun bb:outline (o / out todo x nm)
  (setq todo (if (= (vla-get-ObjectName o) "AcDbCircle") (list (vla-Copy o)) (vlax-invoke o 'Explode)))
  (while todo
    (setq x (car todo) todo (cdr todo) nm (vla-get-ObjectName x))
    (cond ((member nm '("AcDbPolyline" "AcDb2dPolyline" "AcDbBlockReference")) (setq todo (append (vlax-invoke x 'Explode) todo)) (vla-Delete x))
          ((member nm '("AcDbLine" "AcDbArc" "AcDbCircle" "AcDbEllipse" "AcDbSpline")) (setq out (cons x out)))
          (T (vla-Delete x))))
  out)

;; 윤곽 곡선 → 평면 선분 (안쪽 판정용, 곡선은 잘게)
(defun bb:segs (curves / out o len k i p q)
  (foreach o curves
    (if (= (vla-get-ObjectName o) "AcDbLine")
      (setq out (cons (list (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o)) out))
      (progn
        (setq len (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)) k 48 i 0 p (vlax-curve-getPointAtDist o 0.0))
        (while (< i k)
          (setq i (1+ i) q (vlax-curve-getPointAtDist o (* len (/ (float i) k))))
          (if q (setq out (cons (list p q) out) p q))))))
  out)

;; 점이 윤곽 안인지 (+x 쪽 반직선이 선분을 몇 번 넘는지)
(defun bb:inside (p segs / n x)
  (setq n 0)
  (foreach s segs
    (if (not (eq (> (cadr (car s)) (cadr p)) (> (cadr (cadr s)) (cadr p))))
      (progn
        (setq x (+ (car (car s)) (/ (* (- (cadr p) (cadr (car s))) (- (car (cadr s)) (car (car s)))) (- (cadr (cadr s)) (cadr (car s))))))
        (if (> x (car p)) (setq n (1+ n))))))
  (= (rem n 2) 1))

(defun bb:mid (a b) (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b))

(defun c:BB ( / *error* doc undo_open sel ref rtyp rlay rname ss i e o typ walls cols stamps lay p a b ed cuts segs keep
                 n lk ts box pieces wb)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n기준 기둥(블록·폴리선·원)을 클릭하세요: "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n기준 기둥을 고르지 않았습니다."))
    ((not (member (setq rtyp (vla-get-ObjectName (setq ref (vlax-ename->vla-object (car sel)))))
                  '("AcDbCircle" "AcDbPolyline" "AcDb2dPolyline" "AcDbBlockReference")))
     (princ "\n[주의] 기둥은 블록·폴리선·원이어야 합니다."))
    ((progn (setq rlay (vla-get-Layer ref) rname (if (= rtyp "AcDbBlockReference") (strcase (bb:ename ref))))
            (prompt "\n벽선과 기둥이 든 영역을 고르세요: ")
            (null (setq ss (ssget '((0 . "LINE,CIRCLE,LWPOLYLINE,POLYLINE,INSERT"))))))
     (princ "\n고른 객체가 없습니다."))
    (T
     (setq i 0)
     (while (< i (sslength ss))
       (setq e (ssname ss i) o (vlax-ename->vla-object e) typ (vla-get-ObjectName o))
       (cond ((= typ "AcDbLine") (setq walls (cons e walls)))
             ((and (= typ rtyp) (= (strcase (vla-get-Layer o)) (strcase rlay))
                   (or (null rname) (= (strcase (bb:ename o)) rname)))
              (setq cols (cons o cols))))
       (setq i (1+ i)))
     (if (or (null walls) (null cols))
       (princ (strcat "\n[주의] 고른 영역에 " (if cols "벽선(LINE)이" "같은 기둥이") " 없습니다."))
       (progn
         (vla-StartUndoMark doc)
         (setq undo_open T lay (getvar "CLAYER") n 0 lk 0)
         ;; 기둥마다 윤곽 선 (지금 레이어 · ByLayer) + 안쪽 판정 선분 + 범위
         (foreach c cols
           (setq pieces (bb:outline c))
           (foreach x pieces (vl-catch-all-apply 'vla-put-Layer (list x lay)) (vl-catch-all-apply 'vla-put-Color (list x 256)))
           (setq stamps (cons (list pieces (bb:segs pieces) (bb:box c)) stamps)))
         ;; 벽선 자르기
         (foreach w walls
           (setq ed (entget w) a (cdr (assoc 10 ed)) b (cdr (assoc 11 ed)) wb (bb:box (vlax-ename->vla-object w)) cuts nil ts nil)
           (foreach st stamps
             (if (bb:overlap wb (caddr st) 0.01)
               (progn
                 (setq cuts (cons st cuts))
                 (foreach x (car st)
                   (setq p (vlax-invoke (vlax-ename->vla-object w) 'IntersectWith x acExtendNone))
                   (while p
                     (setq ts (cons (/ (distance a (list (car p) (cadr p) (caddr p))) (max (distance a b) 1e-12)) ts) p (cdddr p)))))))
           (if cuts
             (progn
               ;; 0 · 교차점 · 1 로 조각을 나누고, 어느 기둥 안에도 가운데가 없는 조각만 남김
               (setq ts (vl-sort (append '(0.0 1.0) (vl-remove-if '(lambda (x) (or (< x 1e-9) (> x (- 1 1e-9)))) ts)) '<)
                     keep nil)
               (while (cdr ts)
                 (if (> (- (cadr ts) (car ts)) 1e-9)
                   (progn
                     (setq p (bb:mid (mapcar '(lambda (x y) (+ x (* (car ts) (- y x)))) a b)
                                     (mapcar '(lambda (x y) (+ x (* (cadr ts) (- y x)))) a b)))
                     (if (not (vl-some '(lambda (st) (bb:inside p (cadr st))) cuts))
                       (setq keep (cons (list (car ts) (cadr ts)) keep)))))
                 (setq ts (cdr ts)))
               ;; 이어진 조각은 합침
               (setq keep (reverse keep) segs nil)
               (foreach k keep
                 (if (and segs (< (abs (- (car k) (cadr (car segs)))) 1e-9))
                   (setq segs (cons (list (car (car segs)) (cadr k)) (cdr segs)))
                   (setq segs (cons k segs))))
               (setq segs (reverse segs))                   ; 처음 → 끝 (첫 조각이 원래 선)
               (if (not (equal segs '((0.0 1.0)) 1e-9))
                 (cond
                   ((= 4 (logand 4 (cdr (assoc 70 (tblsearch "LAYER" (cdr (assoc 8 ed))))))) (setq lk (1+ lk)))
                   ((null segs) (entdel w) (setq n (1+ n)))
                   (T
                    (setq n (1+ n))
                    (foreach k segs
                      (setq p (list (mapcar '(lambda (x y) (+ x (* (car k) (- y x)))) a b)
                                    (mapcar '(lambda (x y) (+ x (* (cadr k) (- y x)))) a b)))
                      (if (eq k (car segs))
                        (entmod (subst (cons 10 (car p)) (assoc 10 ed) (subst (cons 11 (cadr p)) (assoc 11 ed) ed)))
                        (entmake (subst (cons 10 (car p)) (assoc 10 ed)
                                        (subst (cons 11 (cadr p)) (assoc 11 ed)
                                               (vl-remove-if '(lambda (g) (member (car g) '(-1 5 330 102))) ed))))))))))))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (princ (strcat "\n[완료] 기둥 " (itoa (length cols)) "개의 윤곽 선을 남기고 (지금 레이어), 기둥 안쪽으로 들어간 벽선 " (itoa n) "개를 정리했습니다."
                        (if (> lk 0) (strcat "\n[주의] 잠긴 레이어의 벽선 " (itoa lk) "개는 그대로입니다.") "")))))))
  (princ))

(princ)
