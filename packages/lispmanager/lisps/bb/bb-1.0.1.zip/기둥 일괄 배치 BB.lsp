(defun c:BB ( / refEnt refObj refType refLayer refBlockName ss i ent obj objType walls columns expObjs finalExpObjs totalCaps intVar sArray pts ptList p isDup len eType startPt endPt wallLayer center rad a1 a2 diff subObjs bName exObj segments new_segments tmpEnt tmpLine rawPts pFirst pLast mid1 mid2 minPt maxPt pMin pMax colCenter mid ptA ptB p1 p2)
  (vl-load-com)

  ;; 1. 기준 기둥 선택
  (setq refEnt nil)
  (while (not refEnt)
    (setq refEnt (car (entsel "\n[1단계] 기준이 되는 기둥(블록, 다각형, 원)을 클릭하세요: ")))
    (if refEnt
      (progn
        (setq refObj (vlax-ename->vla-object refEnt))
        (setq refType (vla-get-ObjectName refObj))
        (if (not (vl-position refType '("AcDbCircle" "AcDbPolyline" "AcDb2dPolyline" "AcDbBlockReference")))
          (progn (prompt "\n지원되지 않는 객체입니다.") (setq refEnt nil))
          (progn
            (setq refLayer (vla-get-Layer refObj))
            (if (= refType "AcDbBlockReference")
              (setq refBlockName (if (vlax-property-available-p refObj 'EffectiveName) (vla-get-EffectiveName refObj) (vla-get-Name refObj)))
            )
          )
        )
      )
    )
  )

  ;; 2. 전체 도면 드래그
  (prompt "\n[2단계] 벽체와 기둥이 포함된 영역을 드래그하세요: ")
  (if (setq ss (ssget '((0 . "LINE,CIRCLE,LWPOLYLINE,INSERT"))))
    (progn
      (setq walls nil columns nil i 0 totalCaps 0)

      ;; 3. 객체 분류 (기준 기둥과 같은 기둥만 수집)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        (setq objType (vla-get-ObjectName obj))

        (if (= objType "AcDbLine")
          (setq walls (cons obj walls))
          (if (and (= objType refType) (= (vla-get-Layer obj) refLayer))
            (if (= refType "AcDbBlockReference")
              (progn
                (setq bName (if (vlax-property-available-p obj 'EffectiveName) (vla-get-EffectiveName obj) (vla-get-Name obj)))
                (if (= bName refBlockName) (setq columns (cons obj columns)))
              )
              (setq columns (cons obj columns))
            )
          )
        )
        (setq i (1+ i))
      )

      ;; 4. 주 처리
      (if (and walls columns)
        (progn
          ;; =========================================================
          ;; [A] 기둥 복사 배치와 막음 선(Cap) 생성
          ;; =========================================================
          (foreach objColumn columns
            (setq expObjs nil)
            (if (or (= refType "AcDbBlockReference") (= refType "AcDbPolyline") (= refType "AcDb2dPolyline"))
              (setq expObjs (vlax-invoke objColumn 'Explode))
              (setq expObjs (list (vla-Copy objColumn))) ; 원형일 경우 복사
            )

            (setq finalExpObjs nil)
            (foreach exObj expObjs
              (setq eType (vla-get-ObjectName exObj))
              (if (or (= eType "AcDbPolyline") (= eType "AcDb2dPolyline"))
                (progn
                  (setq subObjs (vlax-invoke exObj 'Explode))
                  (setq finalExpObjs (append subObjs finalExpObjs))
                  (vla-Delete exObj)
                )
                (setq finalExpObjs (cons exObj finalExpObjs))
              )
            )

            (foreach exObj finalExpObjs
              (setq ptList nil)
              (foreach wall walls
                (setq intVar (vla-IntersectWith exObj wall acExtendNone))
                (setq sArray (vlax-variant-value intVar))
                (if (>= (vlax-safearray-get-u-bound sArray 1) 0)
                  (progn
                    (setq pts (vlax-safearray->list sArray))
                    (while pts
                      (setq p (list (car pts) (cadr pts) (caddr pts)))
                      (setq isDup nil)
                      (foreach existPt ptList
                        (if (< (distance p existPt) 0.1) (setq isDup T))
                      )
                      (if (not isDup) (setq ptList (cons p ptList)))
                      (setq pts (cdddr pts))
                    )
                  )
                )
              )

              (setq len (length ptList))
              (if (>= len 2)
                (progn
                  (setq ptList (vl-sort ptList '(lambda (a b)
                    (< (vlax-curve-getDistAtPoint exObj (vlax-curve-getClosestPointTo exObj a))
                       (vlax-curve-getDistAtPoint exObj (vlax-curve-getClosestPointTo exObj b)))
                  )))
                  (setq eType (vla-get-ObjectName exObj))
                  (setq i 0)
                  (while (< i (1- len))
                    (setq p1 (nth i ptList))
                    (setq p2 (nth (1+ i) ptList))
                    (if (< (distance p1 p2) 600.0)
                      (progn
                        (if (= eType "AcDbLine")
                          (entmake (list '(0 . "LINE") (cons 10 p1) (cons 11 p2)))
                        )
                        (if (or (= eType "AcDbArc") (= eType "AcDbCircle"))
                          (progn
                            (setq center (vlax-get exObj 'Center))
                            (setq rad (vlax-get exObj 'Radius))
                            (setq a1 (angle center p1))
                            (setq a2 (angle center p2))
                            (setq diff (abs (- a1 a2)))
                            (if (> diff pi)
                              (entmake (list '(0 . "ARC") (cons 10 center) (cons 40 rad) (cons 50 (max a1 a2)) (cons 51 (min a1 a2))))
                              (entmake (list '(0 . "ARC") (cons 10 center) (cons 40 rad) (cons 50 (min a1 a2)) (cons 51 (max a1 a2))))
                            )
                          )
                        )
                        (setq totalCaps (1+ totalCaps))
                      )
                    )
                    (setq i (+ i 2))
                  )
                )
              )
              ;; 기둥 복사 배치
              (vla-put-Layer exObj (getvar "CLAYER"))
              (vla-put-Color exObj 256)
            )
          )

          ;; =========================================================
          ;; [B] 기둥 안쪽을 판별해 벽선 자르기
          ;; =========================================================
          (foreach wall walls
            (setq startPt (vlax-get wall 'StartPoint))
            (setq endPt (vlax-get wall 'EndPoint))
            (setq wallLayer (vla-get-Layer wall))

            ;; 시작 상태의 선분 리스트 (처음에는 원래 선 1개)
            (setq segments (list (list startPt endPt)))

            ;; 각 기둥마다 차례대로 선분을 검사하고 자름
            (foreach objColumn columns
              (setq new_segments nil)

              ;; 기둥의 중심점 구하기 (Bounding Box 활용)
              (vla-GetBoundingBox objColumn 'minPt 'maxPt)
              (setq pMin (vlax-safearray->list minPt))
              (setq pMax (vlax-safearray->list maxPt))
              (setq colCenter (list (/ (+ (car pMin) (car pMax)) 2.0)
                                    (/ (+ (cadr pMin) (cadr pMax)) 2.0)
                                    (/ (+ (caddr pMin) (caddr pMax)) 2.0)))

              (foreach seg segments
                (setq ptA (car seg) ptB (cadr seg))

                ;; 선분이 너무 짧으면(오류 방지) 계산을 생략하고 유지
                (if (> (distance ptA ptB) 0.01)
                  (progn
                    ;; 현재 선분 구간만 기둥과 교차점 찾기 (임시 선 생성 후 검사)
                    (setq tmpEnt (entmakex (list '(0 . "LINE") (cons 10 ptA) (cons 11 ptB))))
                    (if tmpEnt
                      (progn
                        (setq tmpLine (vlax-ename->vla-object tmpEnt))
                        (setq intVar (vla-IntersectWith tmpLine objColumn acExtendNone))
                        (setq sArray (vlax-variant-value intVar))
                        (setq pts nil)

                        (if (>= (vlax-safearray-get-u-bound sArray 1) 0)
                          (progn
                            (setq rawPts (vlax-safearray->list sArray))
                            (while rawPts
                              (setq p (list (car rawPts) (cadr rawPts) (caddr rawPts)))
                              (setq isDup nil)
                              (foreach existPt pts (if (< (distance p existPt) 0.01) (setq isDup T)))
                              (if (not isDup) (setq pts (cons p pts)))
                              (setq rawPts (cdddr rawPts))
                            )
                          )
                        )
                        (vla-Delete tmpLine) ; 임시 선 바로 삭제

                        (if pts
                          (progn
                            ;; 시작점(ptA)에서 가까운 순으로 정렬
                            (setq pts (vl-sort pts '(lambda (p1 p2) (< (distance ptA p1) (distance ptA p2)))))
                            (setq pFirst (car pts))
                            (setq pLast (last pts))

                            (if (= (length pts) 1)
                              ;; 교차점이 1개: 선분이 기둥 내부에서 끝나거나 시작됨
                              (progn
                                (setq mid1 (list (/ (+ (car ptA) (car pFirst)) 2.0) (/ (+ (cadr ptA) (cadr pFirst)) 2.0) (/ (+ (caddr ptA) (caddr pFirst)) 2.0)))
                                (setq mid2 (list (/ (+ (car pFirst) (car ptB)) 2.0) (/ (+ (cadr pFirst) (cadr ptB)) 2.0) (/ (+ (caddr pFirst) (caddr ptB)) 2.0)))
                                ;; 두 구간의 중심점 중, 기둥의 중심(colCenter)과 더 '먼' 구간이 기둥 바깥쪽이므로 그것을 남김
                                (if (> (distance mid1 colCenter) (distance mid2 colCenter))
                                  (if (> (distance ptA pFirst) 0.01) (setq new_segments (cons (list ptA pFirst) new_segments)))
                                  (if (> (distance pFirst ptB) 0.01) (setq new_segments (cons (list pFirst ptB) new_segments)))
                                )
                              )
                              ;; 교차점이 2개 이상: 기둥을 완전히 관통함. 양 끝의 바깥쪽 선분만 남김
                              (progn
                                (if (> (distance ptA pFirst) 0.01) (setq new_segments (cons (list ptA pFirst) new_segments)))
                                (if (> (distance pLast ptB) 0.01) (setq new_segments (cons (list pLast ptB) new_segments)))
                              )
                            )
                          )
                          ;; 교차점이 없는 경우 (완전히 밖에 있거나, 완전히 안에 숨어있거나)
                          (progn
                            (setq mid (list (/ (+ (car ptA) (car ptB)) 2.0) (/ (+ (cadr ptA) (cadr ptB)) 2.0) (/ (+ (caddr ptA) (caddr ptB)) 2.0)))
                            ;; 선분의 중간점이 기둥 바운딩 박스 내부에 있으면(완전히 기둥 안) 버리고, 외부에 있으면 남김
                            (if (not (and (>= (car mid) (car pMin)) (<= (car mid) (car pMax))
                                          (>= (cadr mid) (cadr pMin)) (<= (cadr mid) (cadr pMax))))
                              (setq new_segments (cons seg new_segments))
                            )
                          )
                        )
                      )
                    )
                  )
                )
              )
              (setq segments new_segments)
            )

            ;; 남은 바깥 선분을 도면에 새로 그림
            (foreach seg segments
              (entmake (list '(0 . "LINE") (cons 8 wallLayer) (cons 10 (car seg)) (cons 11 (cadr seg))))
            )
            ;; 기둥을 관통하던 원래 벽선 삭제
            (if (vlax-write-enabled-p wall)
              (vla-Delete wall)
            )
          )

          (princ (strcat "\n[완료] " (itoa totalCaps) "개의 막음 선을 만들고 기둥 안쪽 선을 정리했습니다."))
        )
        (princ "\n선택 영역에 유효한 벽체나 기둥이 부족합니다.")
      )
    )
    (prompt "\n선택을 취소했습니다.")
  )
  (princ)
)