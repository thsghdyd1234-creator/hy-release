;;; ==============================================================================
;;;  PFR4 — 선 뼈대에서 외곽·단면(포셰) 폴리선 뽑기
;;;
;;;  1. 원본 선을 고른다 (선·호·원·타원·스플라인·폴리선만 — 치수·문자·블록은 빠짐)
;;;  2. 틈 허용치(기억)와 원본 처리[삭제(D)/유지(K) · 기억]를 정하면, 바깥 실루엣은 자동으로 찾는다 (떨어진 동도 모두)
;;;  3. 비울 안쪽 공간(실내)을 클릭한다 — U = 방금 클릭 취소, Enter = 끝 (하나도 안 찍으면 바깥 외곽선만)
;;;  4. 실루엣에서 안쪽 공간을 뺀 결과를 폴리선으로 남긴다 (구멍 둘레까지 모두 ByLayer)
;;;   · 경계는 고른 원본만으로 찾는다 — 화면 확대·주변 치수와 상관없다. 틈은 원본을 고치지 않고 HPGAPTOL 로 넘긴다.
;;;   · 원본은 결과가 나왔을 때만 지운다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun pfr4:space ( / doc)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc)))

;; e0 뒤에 새로 생긴 폴리선
(defun pfr4:new-plines (e0 / e out)
  (setq e (if e0 (entnext e0) (entnext)))
  (while e
    (if (and (entget e) (= (cdr (assoc 0 (entget e))) "LWPOLYLINE")) (setq out (cons e out)))
    (setq e (entnext e)))
  out)

(defun pfr4:area (e) (vla-get-Area (vlax-ename->vla-object e)))

;; 폴리선들 → 영역 하나 (합집합), 원래 폴리선은 지움 / 못 만들면 nil
(defun pfr4:region (plines / regs base)
  (if plines
    (progn
      (setq regs (vl-catch-all-apply 'vlax-invoke (list (pfr4:space) 'AddRegion (mapcar 'vlax-ename->vla-object plines))))
      (foreach e plines (if (entget e) (entdel e)))
      (if (and (not (vl-catch-all-error-p regs)) regs)
        (progn
          (setq base (car regs))
          (foreach r (cdr regs) (vla-Boolean base 0 r))
          base)))))

;; 영역 → 선·호로 분해 (떨어진 동이 섞인 영역은 영역들로 나뉘므로 선이 나올 때까지) → 선택 집합
(defun pfr4:explode (reg / todo o out)
  (setq todo (list reg) out (ssadd))
  (while todo
    (setq o (car todo) todo (cdr todo))
    (foreach x (vlax-invoke o 'Explode)
      (if (= (vla-get-ObjectName x) "AcDbRegion") (setq todo (cons x todo)) (ssadd (vlax-vla-object->ename x) out)))
    (vla-Delete o))
  out)

(defun c:PFR4 ( / *error* doc undo_open sv ss i o a b lo hi m box gap keep e0 outer inner p new k done reg ir pieces res)
  (defun *error* (msg)
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and box (entget box)) (entdel box))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n외곽·단면을 뽑을 원본 선을 모두 고르세요: ")
  (if (null (setq ss (ssget '((0 . "LINE,ARC,CIRCLE,ELLIPSE,SPLINE,LWPOLYLINE,POLYLINE")))))
    (princ "\n고른 선이 없습니다.")
    (progn
      (setq gap (if (getenv "HyPfr4Gap") (atof (getenv "HyPfr4Gap")) 0.0)
            keep (= (getenv "HyPfr4Keep") "K"))
      (while (progn
               (initget 4 "Delete Keep")
               (setq a (getdist (strcat "\n틈 허용치 [원본 삭제(D)/원본 유지(K) — 지금 " (if keep "유지" "삭제") "] <" (rtos gap 2 3) ">: ")))
               (cond ((= a "Delete") (setq keep nil) T) ((= a "Keep") (setq keep T) T))))
      (if a (setq gap a))
      (setenv "HyPfr4Gap" (rtos gap 2 8))
      (setenv "HyPfr4Keep" (if keep "K" "D"))
      ;; 범위
      (setq i 0)
      (while (< i (sslength ss))
        (setq o (vlax-ename->vla-object (ssname ss i)))
        (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'a 'b))))
          (setq a (vlax-safearray->list a) b (vlax-safearray->list b)
                lo (if lo (mapcar 'min lo a) a) hi (if hi (mapcar 'max hi b) b)))
        (setq i (1+ i)))
      (setq m (max (* 0.1 (max (- (car hi) (car lo)) (- (cadr hi) (cadr lo)))) (* 4 gap) 1.0)
            sv (mapcar '(lambda (v) (cons v (getvar v))) '("HPGAPTOL" "CMDECHO" "PEDITACCEPT")))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)
      (setvar "HPGAPTOL" gap)
      ;; 바깥 실루엣: 임시 상자 + 원본만으로, 상자와 도면 사이 빈 곳에서 (섬 = 동마다 실루엣)
      (setq box (entmakex (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
                                (list 10 (- (car lo) m) (- (cadr lo) m)) (list 10 (+ (car hi) m) (- (cadr lo) m))
                                (list 10 (+ (car hi) m) (+ (cadr hi) m)) (list 10 (- (car lo) m) (+ (cadr hi) m))))
            e0 (entlast))
      (ssadd box ss)
      (command "_.-BOUNDARY" "_A" "_B" "_N" ss "" "_I" "_Y" "_O" "_P" "" "_non"
               (trans (list (+ (car hi) (/ m 2.0)) (+ (cadr hi) (/ m 2.0)) 0.0) 0 1) "")
      (ssdel box ss)
      (entdel box)
      (setq new (pfr4:new-plines e0))
      (if new (setq new (vl-sort new '(lambda (x y) (> (pfr4:area x) (pfr4:area y))))))
      (cond
        ((< (length new) 2)
         (foreach e new (entdel e))
         (princ "\n[주의] 바깥 실루엣을 찾지 못했습니다 (틈이 허용치보다 큼?). 틈 허용치를 키워 다시 하세요."))
        (T
         (entdel (car new))                                      ; 상자 둘레
         (setq outer (cdr new))
         (foreach e outer (vla-put-Color (vlax-ename->vla-object e) 2))
         ;; 안쪽 공간 클릭
         (while (not done)
           (initget "Undo")
           (setq p (getpoint (strcat "\n비울 안쪽 공간을 클릭하세요 [방금 것 취소(U)] <Enter = 끝" (if inner (strcat ", 지금 " (itoa (length inner)) "곳") "") ">: ")))
           (cond
             ((null p) (setq done T))
             ((= p "Undo") (if inner (progn (entdel (car inner)) (setq inner (cdr inner))) (princ "\n취소할 공간이 없습니다.")))
             (T
              (setq e0 (entlast))
              (command "_.-BOUNDARY" "_A" "_B" "_N" ss "" "_I" "_N" "_O" "_P" "" "_non" p "")
              (setq new (pfr4:new-plines e0))
              (if (null new)
                (princ "\n[주의] 닫힌 공간을 찾지 못했습니다. 선이 끊겼는지 보세요.")
                (progn
                  (setq new (vl-sort new '(lambda (x y) (> (pfr4:area x) (pfr4:area y)))))
                  (foreach e (cdr new) (entdel e))
                  (vla-put-Color (vlax-ename->vla-object (car new)) 6)
                  (setq inner (cons (car new) inner)))))))
         ;; 실루엣 − 안쪽 공간 → 폴리선
         (setq reg (pfr4:region outer))
         (if (and reg inner (setq ir (pfr4:region inner))) (vla-Boolean reg 2 ir))
         (if (null reg)
           (princ "\n[주의] 영역을 만들지 못했습니다.")
           (progn
             (setq pieces (pfr4:explode reg) e0 (entlast))
             (setvar "PEDITACCEPT" 1)
             (command "_.PEDIT" "_M" pieces "" "_J" 0.0 "")
             (setq k 0)
             (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))
             (setq res (ssadd) i 0)
             (while (< i (sslength pieces))
               (if (entget (ssname pieces i)) (ssadd (ssname pieces i) res))
               (setq i (1+ i)))
             (foreach e (pfr4:new-plines e0) (ssadd e res))
             (setq i 0)
             (while (< i (sslength res))
               (vl-catch-all-apply 'vla-put-Color (list (vlax-ename->vla-object (ssname res i)) 256))
               (setq i (1+ i)))
             (if (and (not keep) (> (sslength res) 0))
               (progn (setq i 0)
                      (while (< i (sslength ss)) (if (entget (ssname ss i)) (entdel (ssname ss i))) (setq i (1+ i)))))
             (princ (strcat "\n[완료] 외곽·단면 " (itoa (sslength res)) "개를 뽑았습니다"
                            (if inner (strcat " (안쪽 공간 " (itoa (length inner)) "곳을 뺌)") " (바깥 외곽선)")
                            (if keep ", 원본은 그대로" ", 원본은 지움") "."))))))
      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)))
  (princ))

(princ)
