(defun c:PFR4 (/ *error* acadObj doc ss oldDel oldCmd oldPedit oldOs minx miny maxx maxy i ent vlaObj minpt maxpt margin
               p1 p3 tempRect ptExt lastEnt curEnt newEnts area maxArea maxEnt outerPoly
               ptInt innerPolys voidList lastVoid lastBeforeReg regOuter ssInner k proceed voidRegions finalWallReg outerObj innerObj
               fuzz beforePedit pEnt) ; 지역 변수 fuzz, beforePedit, pEnt 포함
  
  (vl-load-com)
  (setq acadObj (vlax-get-acad-object)
        doc (vla-get-ActiveDocument acadObj))

  ;; 오류 처리
  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*QUIT*")))
      (princ (strcat "\n[오류] " msg))
    )
    (if tempRect (if (entget tempRect) (entdel tempRect)))
    (if oldOs (setvar "OSMODE" oldOs))
    (if oldDel (setvar "DELOBJ" oldDel))
    (if oldPedit (setvar "PEDITACCEPT" oldPedit))
    (if oldCmd (setvar "CMDECHO" oldCmd))
    (vla-EndUndoMark doc)
    (princ)
  )

  ;; 실행 취소(Ctrl+Z) 그룹 시작
  (vla-StartUndoMark doc)

  (prompt "\n[PFR4 단면·외곽선 추출] 1. 바탕이 될 원본 선을 모두 드래그해 선택하세요: ")
  
  (if (setq ss (ssget))
    (progn
      ;; 조금 열린 선을 닫을 허용치 입력
      (initget 4) ; 음수 입력 방지
      (setq fuzz (getreal "\n조금 열린 선을 닫을 허용치를 입력하세요 <0>: "))
      (if (null fuzz) (setq fuzz 0.0))

      ;; 캐드 설정 저장 및 지정
      (setq oldDel (getvar "DELOBJ")
            oldCmd (getvar "CMDECHO")
            oldPedit (getvar "PEDITACCEPT")
            oldOs (getvar "OSMODE"))
      (setvar "DELOBJ" 1)
      (setvar "CMDECHO" 0)
      (setvar "OSMODE" 0)
      (setvar "PEDITACCEPT" 1) ; PEDIT 설정 미리 지정

      ;; 1. 전체 경계 상자 계산 (원본 기준)
      (setq minx 1e99 miny 1e99 maxx -1e99 maxy -1e99)
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list (vlax-ename->vla-object ent) 'minpt 'maxpt))))
          (progn
            (setq minx (min minx (car (vlax-safearray->list minpt)))
                  miny (min miny (cadr (vlax-safearray->list minpt)))
                  maxx (max maxx (car (vlax-safearray->list maxpt)))
                  maxy (max maxy (cadr (vlax-safearray->list maxpt))))
          )
        )
        (setq i (1+ i))
      )

      ;; 작은 틈 자동 결합 (PEDIT Join)
      (if (> fuzz 0.0)
        (progn
          (setq beforePedit (entlast))
          ;; 입력한 허용치(fuzz)만큼 선 연결
          (command "_.PEDIT" "_M" ss "" "_J" fuzz "")
          
          ;; PEDIT으로 새로 생긴 폴리선을 찾아 ss에 넣음
          ;; (마지막에 원본이 남지 않게 지우기 위함)
          (setq pEnt (entnext beforePedit))
          (while pEnt
            (ssadd pEnt ss)
            (setq pEnt (entnext pEnt))
          )
        )
      )

      ;; 2. 임시 사각형 생성 및 화면 확대
      (setq margin (max (* (max (- maxx minx) (- maxy miny)) 0.1) 1000.0))
      (setq p1 (list (- minx margin) (- miny margin))
            p3 (list (+ maxx margin) (+ maxy margin)))
      
      (command "_.RECTANG" "_NON" p1 "_NON" p3)
      (setq tempRect (entlast))
      (command "_.ZOOM" "_W" "_NON" p1 "_NON" p3)

      ;; 3. 바깥 빈 공간 클릭 (외곽선 추출)
      (prompt "\n[알림] 임시 경계를 만들었습니다.")
      (setq ptExt (getpoint "\n2. [바깥 클릭] 사각형 안쪽이면서 건물 외벽 바깥의 빈 곳을 클릭하세요: "))
      
      (if ptExt
        (progn
          (setq lastEnt (entlast))
          (command "_.-BOUNDARY" "_NON" ptExt "")
          
          (setq newEnts nil curEnt (entnext lastEnt))
          (while curEnt
            (setq newEnts (cons curEnt newEnts))
            (setq curEnt (entnext curEnt))
          )
          
          (if (> (length newEnts) 1)
            (progn
              (setq maxArea -1.0 maxEnt nil)
              (foreach e newEnts
                (setq area (vla-get-Area (vlax-ename->vla-object e)))
                (if (> area maxArea) (setq maxArea area maxEnt e))
              )
              ;; 임시 경계 안쪽 선 삭제
              (entdel maxEnt) 
              (setq newEnts (vl-remove maxEnt newEnts))
              (setq outerPoly (car newEnts))

              ;; 외곽선 표시 (노란색 강조)
              (vla-put-color (vlax-ename->vla-object outerPoly) 2)
              (redraw outerPoly 3)

              (setq lastBeforeReg (entlast))
              (command "_.REGION" outerPoly "")
              
              (setq regOuter nil curEnt (entnext lastBeforeReg))
              (while curEnt
                (if (= (cdr (assoc 0 (entget curEnt))) "REGION")
                  (setq regOuter curEnt)
                )
                (setq curEnt (entnext curEnt))
              )

              (if regOuter
                (progn
                  ;; 4. 안쪽 공간 연속 클릭 (표시·되돌리기 포함)
                  (setq innerPolys (ssadd))
                  (setq voidList nil)
                  (setq proceed T)
                  (while proceed
                    (initget "Undo Exit") 
                    (setq ptInt (getpoint "\n3. [안쪽 클릭] 비울 안쪽 공간을 클릭하세요 (U: 방금 클릭 취소 / Enter: 완료): "))
                    (cond
                      ((null ptInt) (setq proceed nil)) 
                      ((= ptInt "Exit") (setq proceed nil))
                      ((= ptInt "Undo")
                       ;; U 입력 때 되돌리기
                       (if voidList
                         (progn
                           (setq lastVoid (car voidList))
                           (ssdel lastVoid innerPolys)
                           (entdel lastVoid)
                           (setq voidList (cdr voidList))
                           (prompt "\n[알림] 방금 선택한 영역을 뺐습니다.")
                         )
                         (prompt "\n[알림] 더 이상 취소할 영역이 없습니다.")
                       )
                      )
                      (t
                       (setq lastEnt (entlast))
                       (vl-catch-all-apply '(lambda () (command "_.-BOUNDARY" "_NON" ptInt "")))
                       
                       (if (not (eq lastEnt (entlast)))
                         (progn
                           (setq curEnt (entlast))
                           (ssadd curEnt innerPolys)
                           (setq voidList (cons curEnt voidList))
                           
                           (vla-put-color (vlax-ename->vla-object curEnt) 6)
                           (redraw curEnt 3)
                         )
                         (prompt "\n[주의] 닫힌 영역을 찾을 수 없습니다. 선이 끊겼는지 확인하세요.")
                       )
                      )
                    )
                  )

                  ;; 5. 집합 연산으로 접점의 잔선 제거
                  (if (> (sslength innerPolys) 0)
                    (progn
                      (setq lastBeforeReg (entlast))
                      (command "_.REGION" innerPolys "")
                      
                      (setq voidRegions nil curEnt (entnext lastBeforeReg))
                      (while curEnt
                        (if (= (cdr (assoc 0 (entget curEnt))) "REGION")
                          (setq voidRegions (cons (vlax-ename->vla-object curEnt) voidRegions))
                        )
                        (setq curEnt (entnext curEnt))
                      )
                      
                      (if (> (length voidRegions) 0)
                        (progn
                          (setq innerObj (car voidRegions))
                          (if (> (length voidRegions) 1)
                            (foreach r (cdr voidRegions)
                              (vl-catch-all-apply 'vla-Boolean (list innerObj acUnion r))
                            )
                          )
                          
                          (setq outerObj (vlax-ename->vla-object regOuter))
                          (vl-catch-all-apply 'vla-Boolean (list outerObj acSubtraction innerObj))
                          
                          (setq finalWallReg (vlax-vla-object->ename outerObj))

                          ;; 6. 최종 결합 및 원본 삭제
                          (if finalWallReg
                            (progn
                              (command "_.EXPLODE" finalWallReg)
                              (setvar "PEDITACCEPT" 1)
                              (command "_.PEDIT" "_M" (ssget "_P") "" "_J" "0.0" "")
                              
                              (command "_.CHPROP" (entlast) "" "_C" "_BYLAYER" "")
                              
                              (command "_.ERASE" ss "") 
                              (prompt "\n[완료] 고른 영역의 외곽·단면선을 추출했습니다.")
                            )
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
            (prompt "\n[오류] 외곽선을 만들지 못했습니다.")
          )
        )
        (prompt "\n취소되었습니다.")
      )
      
      ;; 7. 정상 종료 시 임시 객체 정리 및 설정 복구
      (if (entget tempRect) (entdel tempRect))
      (command "_.ZOOM" "_P")
      (setvar "OSMODE" oldOs)
      (setvar "DELOBJ" oldDel)
      (setvar "PEDITACCEPT" oldPedit)
      (setvar "CMDECHO" oldCmd)
    )
    (prompt "\n선택된 객체가 없습니다.")
  )
  
  ;; 실행 취소(Ctrl+Z) 그룹 정상 종료
  (vla-EndUndoMark doc)
  (princ)
)