;;; ==============================================================================
;;;  CAP — 열린 선 끝끼리 짧은 선으로 막기
;;;
;;;  최대 간격(직접 넣거나 두 점 클릭 · 기억)을 정하고 선을 고르면, 아직 열린 끝(다른 선 끝이나 선 위에 닿지 않은 끝)끼리
;;;  가까운 짝부터 막는다 — 벽 끝의 맞은편 선과 먼저 이어지고, 개구부 건너편·대각선 끝은 뒤로 밀린다.
;;;  이미 닫힌 끝(모서리 · 문틀 선에 닿은 벽 끝)은 건드리지 않는다. 새 선은 그 끝의 선과 같은 레이어, 끝나면 골라 둔다.
;;;  한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 점 p 에서 선분 a-b 까지 거리 (2D)
(defun cap:seg-dist (p a b / dx dy l k)
  (setq dx (- (car b) (car a)) dy (- (cadr b) (cadr a)) l (+ (* dx dx) (* dy dy)))
  (setq k (if (> l 0) (max 0.0 (min 1.0 (/ (+ (* (- (car p) (car a)) dx) (* (- (cadr p) (cadr a)) dy)) l))) 0.0))
  (distance (list (car p) (cadr p)) (list (+ (car a) (* k dx)) (+ (cadr a) (* k dy)))))

(defun c:CAP ( / *error* doc undo_open d ss i e ed lines pts opens act lp rest r pairs used made n p q)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        d (if (getenv "HyCapDist") (atof (getenv "HyCapDist")) 300.0))
  (initget 6)
  (setq d (cond ((getdist (strcat "\n막을 최대 간격 (직접 넣거나 두 점 클릭) <" (rtos d 2 2) ">: "))) (d)))
  (setenv "HyCapDist" (rtos d 2 8))
  (prompt "\n끝을 막을 선을 고르세요: ")
  (if (null (setq ss (ssget '((0 . "LINE")))))
    (princ "\n고른 선이 없습니다.")
    (progn
      ;; 선 (ename a b minx maxx) · 끝점 (점 ename 레이어)
      (setq i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) ed (entget e) p (cdr (assoc 10 ed)) q (cdr (assoc 11 ed)))
        (setq lines (cons (list e p q (min (car p) (car q)) (max (car p) (car q))) lines)
              pts (cons (list p e (cdr (assoc 8 ed))) (cons (list q e (cdr (assoc 8 ed))) pts))
              i (1+ i)))
      ;; 열린 끝: 다른 선의 끝·몸통에서 0.001 안에 있지 않은 끝 (x 로 줄 세워 가까운 선만 봄)
      (setq lines (vl-sort lines '(lambda (x y) (< (nth 3 x) (nth 3 y))))
            pts (vl-sort pts '(lambda (x y) (< (car (car x)) (car (car y))))))
      (foreach pt pts
        (while (and lines (<= (nth 3 (car lines)) (+ (car (car pt)) 0.001)))
          (setq act (cons (car lines) act) lines (cdr lines)))
        (setq act (vl-remove-if '(lambda (l) (< (nth 4 l) (- (car (car pt)) 0.001))) act))
        (if (not (vl-some '(lambda (l) (and (not (eq (car l) (cadr pt))) (< (cap:seg-dist (car pt) (cadr l) (caddr l)) 0.001))) act))
          (setq opens (cons pt opens))))
      (setq opens (reverse opens))
      ;; 후보 짝: 열린 끝끼리 (다른 선) 0.001 < 거리 ≤ d — x 로 줄 세운 채 d 폭만 비교
      (setq lp opens)
      (while lp
        (setq p (car lp) rest (cdr lp))
        (while (and rest (<= (- (car (car (car rest))) (car (car p))) d))
          (setq r (car rest) rest (cdr rest))
          (if (not (eq (cadr r) (cadr p)))
            (progn
              (setq q (distance (car p) (car r)))
              (if (and (> q 0.001) (<= q d)) (setq pairs (cons (list q p r) pairs))))))
        (setq lp (cdr lp)))
      ;; 가까운 짝부터, 두 끝 모두 아직 안 쓴 것만
      (setq pairs (vl-sort pairs '(lambda (x y) (< (car x) (car y)))) made (ssadd) n 0)
      (foreach pr pairs
        (if (and (not (member (cadr pr) used)) (not (member (caddr pr) used)))
          (progn
            (if (not undo_open) (progn (vla-StartUndoMark doc) (setq undo_open T)))
            (entmake (list '(0 . "LINE") (cons 8 (caddr (cadr pr))) (cons 10 (car (cadr pr))) (cons 11 (car (caddr pr)))))
            (ssadd (entlast) made)
            (setq used (cons (cadr pr) (cons (caddr pr) used)) n (1+ n)))))
      (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
      (if (> n 0) (sssetfirst nil made))
      (princ (if (> n 0) (strcat "\n[완료] 열린 끝 " (itoa (* 2 n)) "곳을 선 " (itoa n) "개로 막았습니다 (골라 둠).")
                 "\n[알림] 최대 간격 안에 막을 열린 끝이 없습니다."))))
  (princ))

(princ)
