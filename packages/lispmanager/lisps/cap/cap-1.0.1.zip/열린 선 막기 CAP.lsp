(defun c:CAP ( / maxDist ss i ent ptList p1Data p1 e1 lay1 p2Data p2 e2 dist matched newList )
  (vl-load-com)
  
  ;; 1. 연결할 최대 간격(허용 오차 범위) 설정
  (setq maxDist (getdist "\n허용할 최대 간격(거리)을 지정하거나 입력하세요: "))
  (if (null maxDist) (exit))

  ;; 2. 연결할 선 객체 선택
  (prompt "\n끝을 막을 선들을 선택하세요: ")
  (setq ss (ssget '((0 . "LINE"))))

  (if ss
    (progn
      (setq i 0 ptList nil)
      
      ;; 3. 선택된 모든 선의 양 끝점을 리스트에 추출하여 저장
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq ptList (cons (list (cdr (assoc 10 (entget ent))) ent) ptList))
        (setq ptList (cons (list (cdr (assoc 11 (entget ent))) ent) ptList))
        (setq i (1+ i))
      )

      ;; 4. 끝점들을 비교하며 거리 내에 있으면 닫아주는 선 생성
      (while ptList
        (setq p1Data (car ptList))
        (setq p1 (car p1Data))
        (setq e1 (cadr p1Data))
        (setq lay1 (cdr (assoc 8 (entget e1)))) ; 원본 선의 레이어 가져오기
        (setq ptList (cdr ptList)) ; 현재 기준점은 리스트에서 제거

        (setq matched nil)
        (setq newList nil)

        (foreach p2Data ptList
          (if (not matched)
            (progn
              (setq p2 (car p2Data))
              (setq e2 (cadr p2Data))
              (setq dist (distance p1 p2))

              ;; 다른 선의 끝점이고, 설정한 최대 간격 이내인 경우에만
              (if (and (not (equal e1 e2)) (<= dist maxDist) (> dist 0.001))
                (progn
                  ;; 새로운 선 생성 (원본 선과 동일한 레이어 사용)
                  (entmake (list '(0 . "LINE") (cons 8 lay1) (cons 10 p1) (cons 11 p2)))
                  (setq matched T) ; 매칭 성공 (이 점은 사용 완료)
                )
                ;; 조건에 맞지 않으면 남은 비교 리스트에 유지
                (setq newList (cons p2Data newList)) 
              )
            )
            ;; 이미 짝을 찾은 상태면 나머지 점들은 그대로 보존
            (setq newList (cons p2Data newList)) 
          )
        )
        (setq ptList newList) ; 다음 비교를 위해 리스트 업데이트
      )
      (princ "\n[완료] 열린 선을 막았습니다.")
    )
    (princ "\n선택된 선이 없습니다.")
  )
  (princ)
)