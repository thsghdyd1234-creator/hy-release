;;; ==============================================================================
;;;  SSS — 기준 객체와 같은 객체 고르기 (영역 안 또는 지금 공간 전체)
;;;
;;;  1. 기준 객체를 클릭 — 기하(G) · 레이어(L) 를 켜고 끌 수 있다 (설정 기억)
;;;  2. 영역을 지정 (Enter = 지금 공간 전체)
;;;  같은 것: 블록은 같은 블록(동적 블록도 원본 이름으로), 그 밖은 같은 종류.
;;;   · 기하(G) 켜면: 선 = 길이·방향, 원 = 반지름, 호 = 반지름·벌린 각, 문자 = 높이·각도,
;;;     폴리선 = 꼭짓점 수·길이, 블록 = 축척·방향(미러 포함)까지 같아야 함
;;;   · 레이어(L) 켜면: 같은 레이어만
;;;  고른 것은 그립으로 잡아 둔다 — 다음 명령이 그대로 쓴다.
;;; ==============================================================================

;; 와일드카드 글자 앞에 ` (이름 그대로 찾기)
(defun sss:esc (s / out)
  (setq out "")
  (foreach c (vl-string->list s)
    (setq out (strcat out (if (member c (vl-string->list "#@.*?~[]`,-")) "`" "") (chr c))))
  out)

(defun sss:space ()
  (if (or (= (getvar "TILEMODE") 1) (/= (getvar "CVPORT") 1)) "Model" (getvar "CTAB")))

(defun sss:ang-eq (a b tol / d)          ; 방향 (선은 앞뒤가 같음 → π 로 접고 0·π 를 이음)
  (setq d (rem (abs (- a b)) pi))
  (< (min d (- pi d)) tol))

;; 비교할 특징 목록 (기하가 꺼져 있으면 nil)
(defun sss:key (e / ed o typ sx sy r ax ay)
  (setq ed (entget e) typ (cdr (assoc 0 ed)) o (vlax-ename->vla-object e))
  (cond
    ((= typ "LINE") (list (vla-get-Length o) (vla-get-Angle o)))
    ((= typ "CIRCLE") (list (cdr (assoc 40 ed))))
    ((= typ "ARC") (list (cdr (assoc 40 ed)) (rem (+ (- (cdr (assoc 51 ed)) (cdr (assoc 50 ed))) pi pi) (+ pi pi))))
    ((member typ '("TEXT" "MTEXT")) (list (cdr (assoc 40 ed)) (vla-get-Rotation o)))
    ((= typ "LWPOLYLINE") (list (cdr (assoc 90 ed)) (vla-get-Length o)))
    ((= typ "INSERT")
     (setq sx (cdr (assoc 41 ed)) sy (cdr (assoc 42 ed)) r (cdr (assoc 50 ed))
           ax (if (< sx 0) (+ r pi) r) ay (if (< sy 0) (- r (/ pi 2)) (+ r (/ pi 2))))
     (list (abs sx) (abs sy) (polar '(0 0) ax 1.0) (polar '(0 0) ay 1.0)))))

(defun sss:same-key (typ a b)
  (cond
    ((= typ "LINE") (and (equal (car a) (car b) 1e-3) (sss:ang-eq (cadr a) (cadr b) 1e-5)))
    ((= typ "INSERT") (and (equal (car a) (car b) (* 1e-6 (max 1.0 (car a))))
                           (equal (cadr a) (cadr b) (* 1e-6 (max 1.0 (cadr a))))
                           (equal (caddr a) (caddr b) 1e-5) (equal (cadddr a) (cadddr b) 1e-5)))
    ((member typ '("TEXT" "MTEXT")) (and (equal (car a) (car b) 1e-3) (sss:ang-eq (cadr a) (cadr b) 1e-5)))
    (T (equal a b 1e-3))))

(defun sss:name (e / o)
  (setq o (vlax-ename->vla-object e))
  (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (cdr (assoc 2 (entget e)))))

(defun c:SSS ( / sel base ed typ name lay key flt ss out i e)
  (vl-load-com)
  ;; 1. 기준 객체 (옵션: 기하 · 레이어)
  (while (progn
           (setvar "ERRNO" 0)
           (initget "Geometry Layer")
           (setq sel (entsel (strcat "\n기준 객체를 클릭하세요 [기하(G) " (if *sss_geo* "켬" "끔") "/레이어(L) "
                                     (if *sss_lay* "켬" "끔") "]: ")))
           (cond ((= sel "Geometry") (setq *sss_geo* (not *sss_geo*)) T)
                 ((= sel "Layer") (setq *sss_lay* (not *sss_lay*)) T)
                 ((and (null sel) (= (getvar "ERRNO") 7)) (princ "\n빗나갔습니다. 다시 클릭하세요.") T))))
  (if (null sel)
    (princ "\n기준 객체를 고르지 않았습니다.")
    (progn
      (setq base (car sel) ed (entget base) typ (cdr (assoc 0 ed)) lay (cdr (assoc 8 ed))
            name (if (= typ "INSERT") (sss:name base))
            key (if *sss_geo* (sss:key base))
            flt (append (list (cons 0 typ))
                        (if name (list (cons 2 (strcat (sss:esc (cdr (assoc 2 ed))) "," (sss:esc name) ",`*U*"))))
                        (if *sss_lay* (list (cons 8 (sss:esc lay))))))
      (princ (strcat "\n기준: " (if name (strcat "블록 [" name "]") typ)
                     (if *sss_geo* " · 기하 같음" "") (if *sss_lay* (strcat " · 레이어 [" lay "]") "")))
      ;; 2. 영역 (Enter = 지금 공간 전체)
      (prompt "\n찾을 영역을 지정하세요 <Enter = 지금 공간 전체>: ")
      (if (null (setq ss (ssget flt)))
        (setq ss (ssget "_X" (append flt (list (cons 410 (sss:space)))))))
      (setq out (ssadd) i 0)
      (if ss
        (while (< i (sslength ss))
          (setq e (ssname ss i))
          (if (and (or (null name) (= (strcase (sss:name e)) (strcase name)))
                   (or (null key) (sss:same-key typ key (sss:key e))))
            (ssadd e out))
          (setq i (1+ i))))
      (if (= (sslength out) 0)
        (princ "\n같은 객체가 없습니다.")
        (progn
          (sssetfirst nil out)
          (princ (strcat "\n[완료] 같은 객체 " (itoa (sslength out)) "개를 골랐습니다."
                         (if (= (getvar "PICKFIRST") 0) " PICKFIRST 가 0 이라 다음 명령에서 P(이전)로 고르세요." "")))))))
  (princ))

(princ)
