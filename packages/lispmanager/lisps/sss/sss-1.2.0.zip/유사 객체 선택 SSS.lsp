;;; ==============================================================================
;;;  SSS — 기준 객체와 같은 객체 고르기 (영역 안 또는 지금 공간 전체)
;;;
;;;  1. 기준 객체를 클릭 — 기하(G) · 레이어(L) 를 켜고 끌 수 있다 (설정 기억)
;;;  2. 영역을 지정 (Enter = 지금 공간 전체)
;;;  같은 것: 블록은 같은 블록(동적 블록도 원본 이름으로), 해치는 같은 무늬, 그 밖은 같은 종류.
;;;   · 기하(G) 켜면: 선 = 길이·방향, 원 = 반지름, 호 = 반지름·벌린 각, 타원 = 긴 반지름·비율·벌린 각,
;;;     문자 = 높이·각도, 폴리선 = 꼭짓점 수·길이·넓이, 그 밖의 곡선 = 길이·넓이, 영역 = 넓이·둘레,
;;;     해치 = 무늬 크기·각도, 치수 = 종류·치수 값,
;;;     블록 = 축척·방향(미러 포함)·동적 특성 값(폭·보이기 상태 등)까지 같아야 함
;;;   · 레이어(L) 켜면: 같은 레이어만
;;;  꺼지거나 얼린 레이어(안 보임) · 잠긴 레이어(고칠 수 없음)의 객체는 고르지 않고 개수만 알린다.
;;;  고른 것은 그립으로 잡아 둔다 — 다음 명령이 그대로 쓴다.
;;; ==============================================================================

;; 와일드카드 글자 앞에 ` (이름 그대로 찾기)
(defun sss:esc (s / out)
  (setq out "")
  (foreach c (vl-string->list s)
    (setq out (strcat out (if (member c (vl-string->list "#@.*?~[]`,-")) "`" "") (chr c))))
  out)

(defun sss:space ()
  (if (or (= (getvar "TILEMODE") 1) (/= (getvar "CVPORT") 1)) "Model" (getvar "CTAB")))

;; 길이·넓이 같음 (큰 값은 비율로 — 원점에서 먼 좌표의 넓이 계산 오차)
(defun sss:near (a b)
  (equal a b (max 1e-3 (* 1e-6 (abs a)))))

;; 방향 같음 — half 면 선처럼 앞뒤가 같음(π 로 접고 0·π 를 이음), 아니면 한 바퀴(글자 0° ≠ 180°)
(defun sss:ang-eq (a b half / p d)
  (setq p (if half pi (+ pi pi)) d (rem (abs (- a b)) p))
  (< (min d (- p d)) 1e-5))

;; 벌린 각 (0 ~ 2π, 처음 = 끝이면 한 바퀴)
(defun sss:sweep (a0 a1 / d)
  (setq d (rem (+ (- a1 a0) pi pi pi pi) (+ pi pi)))
  (if (< d 1e-9) (+ pi pi) d))

;; 같은 것의 이름 — 블록 = 원본 블록 이름, 해치 = 무늬 (그 밖은 nil = 종류만)
(defun sss:id (e ed / o)
  (cond ((= (cdr (assoc 0 ed)) "INSERT")
         (setq o (vlax-ename->vla-object e))
         (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (cdr (assoc 2 ed))))
        ((= (cdr (assoc 0 ed)) "HATCH")
         (if (= (cdr (assoc 450 ed)) 1)
           (strcat "그러데이션 " (cond ((cdr (assoc 470 ed))) ("")))
           (cdr (assoc 2 ed))))))

;; 곡선 길이 · 넓이(열린 곡선은 -1)
(defun sss:curve0 (e)
  (list (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e))
        (if (vlax-curve-isClosed e) (vlax-curve-getArea e) -1.0)))

(defun sss:curve (e / r)
  (setq r (vl-catch-all-apply 'sss:curve0 (list e)))
  (if (not (vl-catch-all-error-p r)) r))

;; 동적 블록 특성 값 ((이름 . 값) …) — Origin 은 뺌
(defun sss:dyn (o / ps out)
  (if (and (vlax-property-available-p o 'IsDynamicBlock) (= (vla-get-IsDynamicBlock o) :vlax-true)
           (not (vl-catch-all-error-p (setq ps (vl-catch-all-apply 'vlax-invoke (list o 'GetDynamicBlockProperties))))))
    (foreach p ps
      (if (/= (strcase (vla-get-PropertyName p)) "ORIGIN")
        (setq out (cons (cons (strcase (vla-get-PropertyName p)) (vlax-get p 'Value)) out)))))
  out)

;; 비교할 특징 목록 (이 종류는 기하를 비교하지 않으면 nil)
(defun sss:key (e / ed o typ sx sy r ax ay)
  (setq ed (entget e) typ (cdr (assoc 0 ed)) o (vlax-ename->vla-object e))
  (cond
    ((= typ "LINE") (list (vla-get-Length o) (vla-get-Angle o)))
    ((= typ "CIRCLE") (list (cdr (assoc 40 ed))))
    ((= typ "ARC") (list (cdr (assoc 40 ed)) (sss:sweep (cdr (assoc 50 ed)) (cdr (assoc 51 ed)))))
    ((= typ "ELLIPSE") (list (distance '(0.0 0.0 0.0) (cdr (assoc 11 ed))) (cdr (assoc 40 ed))
                             (sss:sweep (cdr (assoc 41 ed)) (cdr (assoc 42 ed)))))
    ((member typ '("TEXT" "MTEXT")) (list (cdr (assoc 40 ed)) (vla-get-Rotation o)))
    ((= typ "LWPOLYLINE") (list (cdr (assoc 90 ed)) (vla-get-Length o) (vla-get-Area o)))
    ((member typ '("POLYLINE" "SPLINE")) (sss:curve e))
    ((= typ "REGION") (list (vla-get-Area o) (vla-get-Perimeter o)))
    ((= typ "HATCH") (list (cond ((cdr (assoc 41 ed))) (1.0)) (cond ((cdr (assoc 52 ed))) (0.0))))
    ((= typ "DIMENSION") (list (logand 7 (cdr (assoc 70 ed))) (cdr (assoc 42 ed))))
    ((= typ "INSERT")
     (setq sx (cdr (assoc 41 ed)) sy (cdr (assoc 42 ed)) r (cdr (assoc 50 ed))
           ax (if (< sx 0) (+ r pi) r) ay (if (< sy 0) (- r (/ pi 2)) (+ r (/ pi 2))))
     (list (abs sx) (abs sy) (polar '(0 0) ax 1.0) (polar '(0 0) ay 1.0) (sss:dyn o)))))

(defun sss:same-val (a b)
  (cond ((and (numberp a) (numberp b)) (sss:near a b))
        ((and (= (type a) 'STR) (= (type b) 'STR)) (= (strcase a) (strcase b)))
        (T (equal a b 1e-3))))

(defun sss:same-dyn (a b)
  (and (= (length a) (length b))
       (vl-every '(lambda (x / y) (and (setq y (assoc (car x) b)) (sss:same-val (cdr x) (cdr y)))) a)))

(defun sss:same-key (typ a b)
  (cond
    ((null b) nil)
    ((= typ "LINE") (and (sss:near (car a) (car b)) (sss:ang-eq (cadr a) (cadr b) T)))
    ((member typ '("TEXT" "MTEXT" "HATCH")) (and (sss:near (car a) (car b)) (sss:ang-eq (cadr a) (cadr b) nil)))
    ((= typ "INSERT") (and (equal (car a) (car b) (* 1e-6 (max 1.0 (car a))))
                           (equal (cadr a) (cadr b) (* 1e-6 (max 1.0 (cadr a))))
                           (equal (caddr a) (caddr b) 1e-5) (equal (cadddr a) (cadddr b) 1e-5)
                           (sss:same-dyn (nth 4 a) (nth 4 b))))
    ((= typ "DIMENSION") (and (= (car a) (car b)) (sss:near (cadr a) (cadr b))))
    (T (and (= (length a) (length b)) (vl-every 'sss:same-val a b)))))

;; 안 보이는(꺼짐·얼림) 레이어와 잠긴 레이어 이름 (대문자) → (안 보임 잠김)
(defun sss:layer-states ( / d hid lck)
  (while (setq d (tblnext "LAYER" (null d)))
    (cond ((or (minusp (cdr (assoc 62 d))) (= 1 (logand 1 (cdr (assoc 70 d)))))
           (setq hid (cons (strcase (cdr (assoc 2 d))) hid)))
          ((= 4 (logand 4 (cdr (assoc 70 d))))
           (setq lck (cons (strcase (cdr (assoc 2 d))) lck)))))
  (list hid lck))

(defun c:SSS ( / sel base ed typ name lay key flt ss out i e ed2 ln st nh nl)
  (vl-load-com)
  ;; 1. 기준 객체 (옵션: 기하 · 레이어)
  (while (progn
           (setvar "ERRNO" 0)
           (initget "Geometry Layer")
           (setq sel (entsel (strcat "\n기준 객체를 클릭하세요 [기하(G) " (if *sss_geo* "켬" "끔") "/레이어(L) "
                                     (if *sss_lay* "켬" "끔") "]: ")))
           (cond ((= sel "Geometry") (setq *sss_geo* (not *sss_geo*)) T)
                 ((= sel "Layer") (setq *sss_lay* (not *sss_lay*)) T)
                 ((and (null sel) (= (getvar "ERRNO") 7)) (princ "\n빗나갔습니다. 다시 클릭하세요.") T))))
  (if (null sel)
    (princ "\n기준 객체를 고르지 않았습니다.")
    (progn
      (setq base (car sel) ed (entget base) typ (cdr (assoc 0 ed)) lay (cdr (assoc 8 ed))
            name (sss:id base ed)
            key (if *sss_geo* (sss:key base))
            flt (append (list (cons 0 typ))
                        (if (= typ "INSERT")
                          (list (cons 2 (strcat (sss:esc (cdr (assoc 2 ed))) "," (sss:esc name) ",`*U*"))))
                        (if *sss_lay* (list (cons 8 (sss:esc lay))))))
      (princ (strcat "\n기준: " (cond ((= typ "INSERT") (strcat "블록 [" name "]"))
                                      ((= typ "HATCH") (strcat "해치 [" name "]"))
                                      (typ))
                     (if key " · 기하 같음" "") (if *sss_lay* (strcat " · 레이어 [" lay "]") "")))
      (if (and *sss_geo* (null key))
        (princ (strcat "\n[알림] 이 종류(" typ ")는 기하를 비교하지 않습니다. 종류만 봅니다.")))
      ;; 2. 영역 (Enter = 지금 공간 전체)
      (prompt "\n찾을 영역을 지정하세요 <Enter = 지금 공간 전체>: ")
      (if (null (setq ss (ssget flt)))
        (setq ss (ssget "_X" (append flt (list (cons 410 (sss:space)))))))
      ;; 3. 같은 것만 — 안 보이는 레이어 · 잠긴 레이어는 세기만
      (setq st (sss:layer-states) nh 0 nl 0 out (ssadd) i 0)
      (if ss
        (while (< i (sslength ss))
          (setq e (ssname ss i) ed2 (entget e) ln (strcase (cdr (assoc 8 ed2))))
          (if (and (or (null name) (= (strcase (sss:id e ed2)) (strcase name)))
                   (or (null key) (sss:same-key typ key (sss:key e))))
            (cond ((member ln (car st)) (setq nh (1+ nh)))
                  ((member ln (cadr st)) (setq nl (1+ nl)))
                  (T (ssadd e out))))
          (setq i (1+ i))))
      (cond
        ((> (sslength out) 0)
         (if (= (getvar "PICKFIRST") 0) (command "_.SELECT" out ""))   ; P(이전) = 고른 것
         (sssetfirst nil out)
         (princ (strcat "\n[완료] 같은 객체 " (itoa (sslength out)) "개를 골랐습니다."
                        (if (= (getvar "PICKFIRST") 0) " PICKFIRST 가 0 이라 다음 명령에서 P(이전)로 고르세요." ""))))
        ((> (+ nh nl) 0) (princ "\n같은 객체가 모두 안 보이거나 잠긴 레이어에 있습니다."))
        (T (princ "\n같은 객체가 없습니다.")))
      (if (> (+ nh nl) 0)
        (princ (strcat "\n[알림] "
                       (if (> nh 0) (strcat "꺼지거나 얼린 레이어의 " (itoa nh) "개") "")
                       (if (and (> nh 0) (> nl 0)) " · " "")
                       (if (> nl 0) (strcat "잠긴 레이어의 " (itoa nl) "개") "")
                       "는 고르지 않았습니다.")))))
  (princ))

(princ)
