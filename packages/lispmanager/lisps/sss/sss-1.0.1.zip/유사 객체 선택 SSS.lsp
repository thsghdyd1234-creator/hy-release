(defun c:SSS ( / sel ent entData eType layer obj len ang rad blkName b_xs b_ys rot b_angX b_angY b_vx b_vy p1 p2 ss i checkEnt checkObj match c_len c_ang c_rad checkName c_xs c_ys c_angX c_angY c_vx c_vy finalSS )
  (vl-load-com)
  
  ;; 1. 기준 객체 선택
  (setq sel (car (entsel "\n[1단계] 기준 객체를 선택하세요 (선, 원, 블록 등): ")))
  
  (if sel
    (progn
      (setq entData (entget sel))
      (setq eType (cdr (assoc 0 entData)))
      (setq layer (cdr (assoc 8 entData)))
      (setq obj (vlax-ename->vla-object sel))

      ;; 2. 기준 객체의 기하 특성 추출
      (cond
        ((= eType "LINE")
          (setq len (vlax-get-property obj 'Length))
          (setq ang (vlax-get-property obj 'Angle))
          (if (>= ang pi) (setq ang (- ang pi)))
        )
        ((= eType "CIRCLE")
          (setq rad (cdr (assoc 40 entData)))
        )
        ((= eType "INSERT")
          (setq blkName (if (vlax-property-available-p obj 'EffectiveName) (vla-get-EffectiveName obj) (vla-get-Name obj)))
          (setq b_xs (cdr (assoc 41 entData)))
          (setq b_ys (cdr (assoc 42 entData)))
          (setq rot (cdr (assoc 50 entData)))
          (setq b_angX (if (< b_xs 0) (+ rot pi) rot))
          (setq b_angY (if (< b_ys 0) (- rot (/ pi 2)) (+ rot (/ pi 2))))
          (setq b_vx (polar '(0 0) b_angX 1.0))
          (setq b_vy (polar '(0 0) b_angY 1.0))
        )
      )

      ;; 3. 사각형 구역 지정 (구역 밖 객체 제외)
      (princ (strcat "\n대상: [" eType "] / 도면층: [" layer "]"))
      (setq p1 (getpoint "\n[2단계] 검색할 구역의 첫 번째 모서리 지정: "))
      
      (if p1
        (progn
          (setq p2 (getcorner p1 "\n반대쪽 모서리 지정: "))
          (if p2
            (progn
              ;; 도면 전체가 아니라 지정한 p1~p2 상자 안만 먼저 수집
              (setq ss (ssget "C" p1 p2 (list (cons 0 eType) (cons 8 layer))))
              (setq finalSS (ssadd))

              ;; 4. 구역 안에서 기하 조건 검사
              (if ss
                (progn
                  (setq i 0)
                  (while (< i (sslength ss))
                    (setq checkEnt (entget (ssname ss i)))
                    (setq checkObj (vlax-ename->vla-object (ssname ss i)))
                    (setq match nil)

                    (cond
                      ((= eType "LINE")
                        (setq c_len (vlax-get-property checkObj 'Length))
                        (setq c_ang (vlax-get-property checkObj 'Angle))
                        (if (>= c_ang pi) (setq c_ang (- c_ang pi)))
                        (if (and (< (abs (- len c_len)) 0.001) (< (abs (- ang c_ang)) 0.001))
                          (setq match T)
                        )
                      )
                      ((= eType "CIRCLE")
                        (setq c_rad (cdr (assoc 40 checkEnt)))
                        (if (< (abs (- rad c_rad)) 0.001) (setq match T))
                      )
                      ((= eType "INSERT")
                        (setq checkName (if (vlax-property-available-p checkObj 'EffectiveName) (vla-get-EffectiveName checkObj) (vla-get-Name checkObj)))
                        (if (= (strcase blkName) (strcase checkName))
                          (progn
                            (setq c_xs (cdr (assoc 41 checkEnt)))
                            (setq c_ys (cdr (assoc 42 checkEnt)))
                            (setq rot (cdr (assoc 50 checkEnt)))
                            (setq c_angX (if (< c_xs 0) (+ rot pi) rot))
                            (setq c_angY (if (< c_ys 0) (- rot (/ pi 2)) (+ rot (/ pi 2))))
                            (setq c_vx (polar '(0 0) c_angX 1.0))
                            (setq c_vy (polar '(0 0) c_angY 1.0))
                            (if (and (< (distance b_vx c_vx) 0.001) (< (distance b_vy c_vy) 0.001))
                              (setq match T)
                            )
                          )
                        )
                      )
                      (t (setq match T)) ;; 그 외 객체는 1차 필터(구역+레이어)로 갈음
                    )

                    (if match (ssadd (ssname ss i) finalSS))
                    (setq i (1+ i))
                  )

                  ;; 5. 스캔 결과 표시
                  (if (> (sslength finalSS) 0)
                    (progn
                      (sssetfirst nil finalSS)
                      (princ (strcat "\n지정한 구역에서 기하 조건이 일치하는 " (itoa (sslength finalSS)) "개의 객체를 선택했습니다."))
                    )
                    (princ "\n구역 안에 일치하는 객체가 없습니다.")
                  )
                )
                (princ "\n지정한 구역에 조건에 맞는 객체가 없습니다.")
              )
            )
          )
        )
        (princ "\n구역 선택이 취소되었습니다.")
      )
    )
    (princ "\n기준 객체가 선택되지 않았습니다.")
  )
  (princ)
)

(defun c:sss ( / ent vla-obj bName ss final-ss i sub-ent sub-obj sub-bName )
  (vl-load-com)
  ;; 1. 기준이 되는 블록 하나를 선택
  (setq ent (car (entsel "\n기준 블록 선택: ")))
  
  (if (and ent (= (cdr (assoc 0 (entget ent))) "INSERT"))
    (progn
      (setq vla-obj (vlax-ename->vla-object ent))
      
      ;; 2. 선택한 블록의 실제 이름(Effective Name) 추출
      (setq bName (if (vlax-property-available-p vla-obj 'EffectiveName)
                    (vla-get-EffectiveName vla-obj)
                    (vla-get-Name vla-obj)))
                    
      ;; 3. 도면 전체에서 해당 이름의 블록과 익명 블록(*U)을 1차로 모두 선택
      (setq ss (ssget (list '(0 . "INSERT") (cons 2 (strcat bName ",`*U*")))))
      (setq final-ss (ssadd)) ;; 최종 선택할 객체 목록
      
      (if ss
        (progn
          (setq i 0)
          ;; 4. 1차 선택된 블록들을 하나씩 꺼내서 실제 이름이 일치하는지 검사
          (while (< i (sslength ss))
            (setq sub-ent (ssname ss i))
            (setq sub-obj (vlax-ename->vla-object sub-ent))
            (setq sub-bName (if (vlax-property-available-p sub-obj 'EffectiveName)
                              (vla-get-EffectiveName sub-obj)
                              (vla-get-Name sub-obj)))
                              
            ;; 5. 기준 블록의 이름과 일치하면 최종 목록에 추가 (대소문자 구분 없이 비교)
            (if (= (strcase bName) (strcase sub-bName))
              (ssadd sub-ent final-ss)
            )
            (setq i (1+ i))
          )
          
          ;; 6. 최종적으로 걸러진 객체들을 화면에 그립(Grip) 상태로 선택
          (sssetfirst nil final-ss)
          (princ (strcat "\n총 " (itoa (sslength final-ss)) "개의 동일한 블록이 선택되었습니다."))
        )
      )
    )
    (princ "\n블록을 선택하지 않았습니다.")
  )
  (princ)
)