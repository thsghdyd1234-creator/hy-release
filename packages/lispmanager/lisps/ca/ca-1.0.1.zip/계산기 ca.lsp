(defun c:CA ( / dcl_id dcl_file file_ptr expr res force_real )
  (vl-load-com)
  ;; 오토캐드 내장 계산기 모듈 로드
  (if (not (type cal)) (arxload "geomcal" nil))

  ;; 정수를 실수(.0)로 강제 변환하여 오버플로우 방지
  (defun force_real ( str / i char res_str in_num has_dot )
    (setq res_str "" in_num nil has_dot nil i 1)
    (while (<= i (strlen str))
      (setq char (substr str i 1))
      (cond
        ((and (>= (ascii char) 48) (<= (ascii char) 57))
          (setq in_num t res_str (strcat res_str char))
        )
        ((= char ".")
          (setq in_num t has_dot t res_str (strcat res_str char))
        )
        (t
          (if (and in_num (not has_dot)) (setq res_str (strcat res_str ".0")))
          (setq in_num nil has_dot nil res_str (strcat res_str char))
        )
      )
      (setq i (1+ i))
    )
    (if (and in_num (not has_dot)) (setq res_str (strcat res_str ".0")))
    res_str
  )

  ;; 1. 임시 DCL 파일 자동 생성 (엔터키 인식 속성 추가)
  (setq dcl_file (vl-filename-mktemp "calcUI.dcl"))
  (setq file_ptr (open dcl_file "w"))
  (write-line "calc_dlg : dialog {" file_ptr)
  (write-line "  label = \"캐드 간편 계산기\";" file_ptr)
  ;; allow_accept = true; (입력란에서 Enter로 계산)
  (write-line "  : edit_box { key = \"expr_input\"; label = \"수식 입력:\"; edit_width = 30; allow_accept = true; }" file_ptr)
  (write-line "  : button { key = \"btn_calc\"; label = \"계산하기 (Enter)\"; is_default = true; }" file_ptr)
  (write-line "  spacer;" file_ptr)
  (write-line "  : edit_box { key = \"txt_res\"; label = \"계산 결과:\"; edit_width = 30; is_enabled = true; } " file_ptr) 
  (write-line "  spacer;" file_ptr)
  (write-line "  : button { key = \"btn_cancel\"; label = \"닫기 (Esc)\"; is_cancel = true; }" file_ptr)
  (write-line "}" file_ptr)
  (close file_ptr)

  ;; 2. DCL 로드
  (setq dcl_id (load_dialog dcl_file))
  (if (not (new_dialog "calc_dlg" dcl_id))
    (progn (princ "\nUI 로드에 실패했습니다.") (exit))
  )

  ;; 3. 계산 액션 정의
  (defun calc_action ( / safe_expr )
    (setq expr (get_tile "expr_input"))
    (if (and expr (/= expr ""))
      (progn
        (setq safe_expr (force_real expr))
        (setq res (vl-catch-all-apply 'cal (list safe_expr)))
        (if (vl-catch-all-error-p res)
          (set_tile "txt_res" "수식 오류 (잘못된 입력)")
          (if res
            (set_tile "txt_res" (rtos res 2 4))
            (set_tile "txt_res" "계산 불가")
          )
        )
      )
      (set_tile "txt_res" "")
    )
    ;; 계산 후 커서를 다시 수식 입력창으로 되돌려 연속 계산이 가능하게 함
    (mode_tile "expr_input" 2)
  )

  ;; 4. 버튼과 입력란 동작 연결 (Enter 처리)
  (action_tile "btn_calc" "(calc_action)")
  (action_tile "expr_input" "(calc_action)") ; 입력란에도 동작 연결
  (action_tile "btn_cancel" "(done_dialog)")
  
  ;; 다이얼로그 포커스를 수식 입력창으로 자동 이동
  (mode_tile "expr_input" 2)

  ;; 5. 다이얼로그 실행 및 종료 후 정리
  (start_dialog)
  (unload_dialog dcl_id)
  (vl-file-delete dcl_file)
  
  (princ)
)