;;; ==============================================================================
;;;  CA — 캐드 안 계산기 창
;;;
;;;  수식을 넣고 Enter → 결과 (소수 넷째 자리). [결과 복사] 로 클립보드에 담아 다른 명령에 붙여 넣는다.
;;;  CAL 은 정수끼리 나누면 몫만 내므로(2/3 = 0) 숫자를 실수로 바꿔 계산한다 — 1e5 · exp10(2) 같은 표기는 그대로.
;;;  점·벡터 결과는 (x, y, z) 로 보인다. 지금 명령의 입력으로 바로 넣으려면 캐드의 'CAL · QUICKCALC 도 있다.
;;; ==============================================================================

;; 정수만 실수로 ("2/3" → "2.0/3.0"), 이름 안의 숫자(exp10)·소수·지수(1e5)는 그대로
(defun ca:real (s / out i n c prev num)
  (setq out "" i 1 n (strlen s) prev "")
  (while (<= i n)
    (setq c (substr s i 1))
    (if (and (wcmatch c "#") (not (wcmatch prev "@,_,#,`.")))
      (progn
        (setq num "")
        (while (and (<= i n) (wcmatch (substr s i 1) "#")) (setq num (strcat num (substr s i 1)) i (1+ i)))
        (if (and (<= i n) (wcmatch (substr s i 1) "`.,e,E"))
          (setq out (strcat out num))                       ; 소수·지수는 그대로 이어 붙임
          (setq out (strcat out num ".0")))
        (setq prev (substr num (strlen num))))
      (setq out (strcat out c) prev c i (1+ i))))
  out)

(defun ca:fmt (r)
  (cond ((numberp r) (rtos r 2 4))
        ((and (listp r) (vl-every 'numberp r))
         (strcat "(" (substr (apply 'strcat (mapcar '(lambda (x) (strcat ", " (rtos x 2 4))) r)) 3) ")"))
        (T "계산할 수 없습니다")))

(defun ca:calc ( / e r)
  (setq e (get_tile "expr_input"))
  (if (= e "")
    (set_tile "txt_res" "")
    (progn
      (setq r (vl-catch-all-apply 'cal (list (ca:real e))))
      (set_tile "txt_res" (if (vl-catch-all-error-p r) "수식 오류" (ca:fmt r)))))
  (mode_tile "expr_input" 2))

;; 클립보드에 글자 담기 (못 하면 nil)
(defun ca:clip (s / h r)
  (setq r (vl-catch-all-apply
            '(lambda ()
               (setq h (vlax-create-object "htmlfile"))
               (vlax-invoke (vlax-get (vlax-get h 'ParentWindow) 'ClipboardData) 'SetData "Text" s))
            nil))
  (if h (vl-catch-all-apply 'vlax-release-object (list h)))
  (not (vl-catch-all-error-p r)))

(defun c:CA ( / path f id)
  (vl-load-com)
  (if (not (vl-some '(lambda (a) (wcmatch (strcase a) "*GEOMCAL*")) (arx))) (vl-catch-all-apply 'arxload (list "geomcal" nil)))
  (setq path (vl-filename-mktemp "hy_ca.dcl"))
  (if (setq f (open path "w"))
    (progn
      (write-line "hy_ca : dialog { label = \"계산기\";" f)
      (write-line "  : edit_box { key = \"expr_input\"; label = \"수식\"; edit_width = 32; allow_accept = true; }" f)
      (write-line "  : edit_box { key = \"txt_res\"; label = \"결과\"; edit_width = 32; }" f)
      (write-line "  : row { : button { key = \"btn_calc\"; label = \"계산 (Enter)\"; is_default = true; }" f)
      (write-line "          : button { key = \"btn_copy\"; label = \"결과 복사\"; }" f)
      (write-line "          : button { key = \"btn_cancel\"; label = \"닫기\"; is_cancel = true; } } }" f)
      (close f)))
  (cond
    ((or (null f) (< (setq id (load_dialog path)) 0) (not (new_dialog "hy_ca" id)))
     (princ "\n[오류] 계산기 창을 열지 못했습니다."))
    (T
     (action_tile "btn_calc" "(ca:calc)")
     (action_tile "expr_input" "(if (= $reason 1) (ca:calc))")
     (action_tile "btn_copy" "(if (ca:clip (get_tile \"txt_res\")) (set_tile \"error\" \"\") (set_tile \"error\" \"복사하지 못했습니다\"))")
     (action_tile "btn_cancel" "(done_dialog 0)")
     (mode_tile "expr_input" 2)
     (start_dialog)))
  (if (and id (> id 0)) (unload_dialog id))
  (if (findfile path) (vl-file-delete path))
  (princ))

(princ)
