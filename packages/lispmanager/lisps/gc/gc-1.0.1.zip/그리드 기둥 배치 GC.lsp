(defun c:GC ( / blkEnt blkName ss i j obj1 obj2 intPts pts finalPts pt count )
  (vl-load-com)
  
  ;; 1. 배치할 기준 기둥 블록 선택
  (setq blkEnt (car (entsel "\n기준이 될 기둥 블록을 하나 선택하세요: ")))
  (if (and blkEnt (= (cdr (assoc 0 (entget blkEnt))) "INSERT"))
    (progn
      (setq blkName (cdr (assoc 2 (entget blkEnt))))
      (prompt (strcat "\n선택된 블록: " blkName))
      
      ;; 2. 중심선(Grid) 드래그 선택
      (prompt "\n교차점을 찾을 중심선(Line/Polyline)들을 드래그하여 선택하세요: ")
      (if (setq ss (ssget '((0 . "LINE,LWPOLYLINE"))))
        (progn
          (setq pts nil)
          (setq i 0)
          
          ;; 3. 선택된 선들 간의 모든 교차점 추출
          (while (< i (1- (sslength ss)))
            (setq obj1 (vlax-ename->vla-object (ssname ss i)))
            (setq j (1+ i))
            (while (< j (sslength ss))
              (setq obj2 (vlax-ename->vla-object (ssname ss j)))
              ;; acExtendNone: 선이 연장되지 않은 실제 교차점만 찾음
              (setq intPts (vlax-invoke obj1 'IntersectWith obj2 acExtendNone))
              (if intPts
                (while intPts
                  ;; 3D 좌표(X Y Z) 리스트로 묶어서 저장
                  (setq pts (cons (list (car intPts) (cadr intPts) (caddr intPts)) pts))
                  (setq intPts (cdddr intPts))
                )
              )
              (setq j (1+ j))
            )
            (setq i (1+ i))
          )
          
          ;; 4. 중복 교차점 제거 (오차 범위 0.1 이내)
          (setq finalPts nil)
          (foreach pt pts
            (if (not (vl-some '(lambda (x) (< (distance pt x) 0.1)) finalPts))
              (setq finalPts (cons pt finalPts))
            )
          )
          
          ;; 5. 추출된 교차점마다 블록 배치
          (setq count 0)
          (foreach pt finalPts
            (entmake (list '(0 . "INSERT") (cons 2 blkName) (cons 10 pt)))
            (setq count (1+ count))
          )
          (princ (strcat "\n[완료] 총 " (itoa count) "개의 [" blkName "] 기둥이 교차점에 배치되었습니다."))
        )
        (princ "\n선택된 중심선이 없습니다.")
      )
    )
    (princ "\n유효한 블록을 선택하지 않았습니다. 기둥 '블록'을 선택해야 합니다.")
  )
  (princ)
)