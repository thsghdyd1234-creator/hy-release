;;; ==============================================================================
;;;  GC — 그리드 교차점마다 기준 기둥 블록 놓기
;;;
;;;  1. 기준 기둥 블록을 클릭
;;;  2. 그리드선 하나를 클릭 — 그 레이어의 선만 쓴다 (GRI 가 남긴 안내 사각형·벽선이 섞여도 됨, Enter = 레이어 안 가림)
;;;  3. 그리드선을 고르면, 선끼리 실제로 만나는 점마다 기준 블록의 복사본을 놓는다.
;;;   · 복사본이라 레이어·회전·축척·속성·동적 블록 설정이 기준 블록과 같다.
;;;   · 블록 상자 가운데를 교차점에 맞춘다 (기준점이 모서리인 블록도 됨).
;;;   · 이미 같은 기둥이 있는 자리는 건너뛴다 (기준 기둥 자리 · 두 번 실행해도 겹치지 않음).
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun gc:esc (s / out)
  (setq out "")
  (foreach c (vl-string->list s)
    (setq out (strcat out (if (member c (vl-string->list "#@.*?~[]`,-")) "`" "") (chr c))))
  out)

(defun gc:ename (o)
  (if (vlax-property-available-p o 'EffectiveName) (vla-get-EffectiveName o) (vla-get-Name o)))

(defun gc:mid (o / a b)
  (vla-GetBoundingBox o 'a 'b)
  (mapcar '(lambda (p q) (/ (+ p q) 2.0)) (vlax-safearray->list a) (vlax-safearray->list b)))

(defun gc:space ()
  (if (or (= (getvar "TILEMODE") 1) (/= (getvar "CVPORT") 1)) "Model" (getvar "CTAB")))

(defun c:GC ( / *error* doc undo_open sel base name bm lay ss objs pts p q i a b r tol have mv n skip)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil) (command-s "_.U")))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)) tol 1.0)
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n기준 기둥 블록을 클릭하세요: "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n기준 블록을 고르지 않았습니다."))
    ((/= (cdr (assoc 0 (entget (car sel)))) "INSERT") (princ "\n[주의] 블록이 아닙니다."))
    (T
     (setq base (vlax-ename->vla-object (car sel)) name (gc:ename base) bm (gc:mid base))
     ;; 그리드 레이어
     (setvar "ERRNO" 0)
     (while (and (null (setq sel (entsel "\n그리드선 하나를 클릭하세요 (그 레이어의 선만 씀) <Enter = 레이어 안 가림>: ")))
                 (= (getvar "ERRNO") 7))
       (princ "\n빗나갔습니다. 다시 클릭하세요.")
       (setvar "ERRNO" 0))
     (setq lay (if sel (cdr (assoc 8 (entget (car sel))))))
     (prompt (strcat "\n교차점을 찾을 그리드선을 고르세요" (if lay (strcat " ([" lay "] 레이어만)") "") ": "))
     (if (null (setq ss (ssget (append '((0 . "LINE,LWPOLYLINE")) (if lay (list (cons 8 (gc:esc lay))))))))
       (princ "\n고른 그리드선이 없습니다.")
       (progn
         ;; 범위가 겹치는 짝만 교차 계산 — L = ((객체 아래왼쪽 위오른쪽) …)
         (setq i 0)
         (while (< i (sslength ss))
           (setq a (vlax-ename->vla-object (ssname ss i)))
           (vla-GetBoundingBox a 'p 'q)
           (setq objs (cons (list a (vlax-safearray->list p) (vlax-safearray->list q)) objs) i (1+ i)))
         (while objs
           (setq a (car objs) objs (cdr objs))
           (foreach b objs
             (if (and (<= (car (cadr a)) (+ (car (caddr b)) tol)) (<= (car (cadr b)) (+ (car (caddr a)) tol))
                      (<= (cadr (cadr a)) (+ (cadr (caddr b)) tol)) (<= (cadr (cadr b)) (+ (cadr (caddr a)) tol)))
               (progn
                 (setq r (vlax-invoke (car a) 'IntersectWith (car b) acExtendNone))
                 (while r
                   (setq p (list (car r) (cadr r)) r (cdddr r))
                   (if (not (vl-some '(lambda (x) (< (distance p x) tol)) pts)) (setq pts (cons p pts))))))))
         ;; 이미 있는 같은 기둥 자리 (지금 공간)
         (if (setq ss (ssget "_X" (list '(0 . "INSERT") (cons 2 (strcat (gc:esc name) ",`*U*")) (cons 410 (gc:space)))))
           (progn
             (setq i 0)
             (while (< i (sslength ss))
               (setq a (vlax-ename->vla-object (ssname ss i)))
               (if (= (strcase (gc:ename a)) (strcase name)) (setq have (cons (gc:mid a) have)))
               (setq i (1+ i)))))
         (vla-StartUndoMark doc)
         (setq undo_open T n 0 skip 0)
         (foreach p pts
           (if (vl-some '(lambda (h) (< (distance p (list (car h) (cadr h))) tol)) have)
             (setq skip (1+ skip))
             (progn
               (setq mv (vla-Copy base))
               (vla-Move mv (vlax-3d-point bm) (vlax-3d-point (list (car p) (cadr p) (caddr bm))))
               (setq n (1+ n)))))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (princ (strcat "\n[완료] 교차점 " (itoa (length pts)) "곳에 [" name "] 기둥 " (itoa n) "개를 놓았습니다"
                        (if (> skip 0) (strcat " (이미 기둥이 있는 " (itoa skip) "곳은 건너뜀)") "") "."))))))
  (princ))

(princ)
