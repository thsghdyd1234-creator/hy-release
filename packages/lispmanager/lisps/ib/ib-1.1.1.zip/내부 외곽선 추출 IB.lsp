;;; ==============================================================================
;;;  IB — 내부 외곽선 추출
;;;
;;;  안쪽 빈 곳을 클릭할 때마다 그 둘레를 빨간 폴리선(지금 레이어)으로 만든다 (연속 클릭, Enter = 끝).
;;;   · 섬(안의 기둥 등) 둘레도 같이 만들지 옵션(기본 끔) — 만든 것은 모두 빨강 (예전: 마지막 하나만)
;;;   · 틈 허용(기본 0 = 끊긴 곳이 있으면 실패)을 옵션으로, 끝나면 HPGAPTOL 을 원래대로
;;;   · 경계는 캐드 명령의 옵션 키워드 없이 찾는다 (bpoly — 1.1.1: 캐드 판에 따라 -BOUNDARY 옵션 키워드가 거절됐음)
;;;   · 직전 것 취소(U). 클릭 하나 = 실행 취소 한 번(U). ESC 로 끝내도 전역 오류 처리는 그대로.
;;; ==============================================================================

;; 경계 찾기에 쓰는 시스템 변수 (이 캐드에 있는 것만) 의 지금 값
(defun ib:hpvars ( )
  (vl-remove-if '(lambda (v) (null (cdr v)))
    (mapcar '(lambda (v) (cons v (getvar v))) '("HPGAPTOL" "HPBOUND" "HPISLANDDETECTIONMODE" "HPISLANDDETECTION"))))

;; 점 p(UCS) 둘레 경계 → 새로 생긴 폴리선들 (넓은 것부터, islands 가 아니면 바깥 둘레 하나만) / 없으면 nil.
;;  캐드 명령의 옵션 키워드를 쓰지 않는다 — 캐드 판에 따라 -BOUNDARY 의 옵션 키워드가 거절되어 '옵션 키워드가 유효하지 않음' 뒤 멈췄음.
;;  bpoly 함수로 찾고, 그 함수가 오류면 옵션 없는 -BOUNDARY 로. 틈 · 섬 · 폴리선으로 만들기는 시스템 변수로 넘기고 바로 원래대로.
(defun ib:bound (p gap islands / e0 e out old k)
  (setq e0 (entlast) old (ib:hpvars))
  (foreach v (list (cons "HPGAPTOL" gap) '("HPBOUND" . 1) (cons "HPISLANDDETECTIONMODE" (if islands 1 0)) '("HPISLANDDETECTION" . 1))
    (if (assoc (car v) old) (vl-catch-all-apply 'setvar (list (car v) (cdr v)))))
  (if (vl-catch-all-error-p (vl-catch-all-apply 'bpoly (list p)))
    (progn
      (command "_.-BOUNDARY" "_non" p "")
      (setq k 0)
      (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))))
  (foreach v old (vl-catch-all-apply 'setvar (list (car v) (cdr v))))
  (setq e (if e0 (entnext e0) (entnext)))
  (while e
    (if (and (entget e) (wcmatch (cdr (assoc 0 (entget e))) "LWPOLYLINE,POLYLINE")) (setq out (cons e out)))
    (setq e (entnext e)))
  (setq out (vl-sort out '(lambda (a b) (> (vla-get-Area (vlax-ename->vla-object a)) (vla-get-Area (vlax-ename->vla-object b))))))
  (if (and (cdr out) (not islands))
    (progn (foreach x (cdr out) (entdel x)) (setq out (list (car out)))))
  out)

(defun c:IB ( / *error* doc sv undo_open pt made prev v)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (cons (cons "CMDECHO" (getvar "CMDECHO")) (ib:hpvars)))
  (setvar "CMDECHO" 0)
  (if (null *ib_gap*) (setq *ib_gap* 0.0))
  (while
    (progn
      (initget (if prev "I G U" "I G"))
      (setq pt (getpoint (strcat "\n외곽선을 만들 안쪽 빈 곳을 클릭하세요 [섬(I) " (if *ib_isl* "켬" "끔")
                                 "/틈(G) " (rtos *ib_gap* 2 2) (if prev "/직전 취소(U)" "") "] <끝>: "))))
    (cond
      ((= pt "I") (setq *ib_isl* (not *ib_isl*)))
      ((= pt "G") (initget 4) (if (setq v (getdist (strcat "\n틈 허용 <" (rtos *ib_gap* 2 2) ">: "))) (setq *ib_gap* v)))
      ((= pt "U")
       (foreach e prev (if (entget e) (entdel e)))
       (setq made (- made (length prev)) prev nil)
       (princ "\n직전 외곽선을 지웠습니다."))
      (T
       (vla-StartUndoMark doc)
       (setq undo_open T)
       (if (setq prev (ib:bound pt *ib_gap* *ib_isl*))
         (progn
           (foreach e prev (vla-put-Color (vlax-ename->vla-object e) 1))
           (setq made (+ (if made made 0) (length prev)))
           (princ (strcat "\n빨간 폴리선 " (itoa (length prev)) "개를 만들었습니다.")))
         (princ "\n[주의] 닫힌 경계를 찾지 못했습니다. 선이 끊겼거나(틈 옵션) 영역이 화면 밖에 있습니다."))
       (vla-EndUndoMark doc)
       (setq undo_open nil))))
  (if made (princ (strcat "\n[완료] 외곽선 " (itoa made) "개를 만들었습니다.")))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
