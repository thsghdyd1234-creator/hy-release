(defun c:IB (/ pt old_cmdecho old_err current_layer last_ent_before bnd_ent obj)
  (vl-load-com)

  ;; 1. 시스템 변수 및 오류 처리기 세팅
  (setq old_cmdecho (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)

  (command "_.UNDO" "_BE")
  (setq old_err *error*)
  (defun *error* (msg)
    (command "_.UNDO" "_E")
    (setvar "CMDECHO" old_cmdecho)
    (setq *error* old_err)
    (princ "\n[IB 종료] 작업이 취소되었습니다.")
    (princ)
  )

  (prompt "\n[내부 외곽선 추출] 폴리선을 딸 내부 공간을 클릭하세요. (연속 클릭 가능 / 종료=Enter)")
  (setq current_layer (getvar "CLAYER"))

  ;; 2. 무한 클릭 루프
  (while (setq pt (getpoint "\n내부 빈 공간 클릭: "))
    (progn
      ;; 바운더리 생성 전 마지막 객체 기억 (오류 방지용)
      (setq last_ent_before (entlast)) 
      
      ;; 바운더리 명령어 실행
      (vl-cmdf "_.-BOUNDARY" pt "")
      
      ;; 바운더리 명령어 실행 후 마지막 객체 확인
      (setq bnd_ent (entlast))
      
      ;; 🎯 방금 닫힌 폴리선이 '새롭게' 생성된 것이 맞는지 검증
      (if (not (equal last_ent_before bnd_ent))
        (progn
          (setq obj (vlax-ename->vla-object bnd_ent))
          
          ;; 레이어는 현재 레이어 유지
          (vla-put-layer obj current_layer)
          
          ;; 🎯 [핵심 변경점] 객체의 색상을 '1번(빨간색)'으로 강제 변경
          (vla-put-color obj 1) 
          
          (prompt "\n[성공] 눈에 띄는 빨간색 폴리선이 생성되었습니다.")
        )
        (prompt "\n[실패] 닫힌 경계를 찾을 수 없습니다. 선이 끊어졌는지 확인하세요.")
      )
    )
  )

  ;; 3. 종료 및 원상 복구
  (command "_.UNDO" "_E")
  (setvar "CMDECHO" old_cmdecho)
  (setq *error* old_err)
  (princ "\n[IB 완료] 내부 외곽선 추출이 종료되었습니다.")
  (princ)
)