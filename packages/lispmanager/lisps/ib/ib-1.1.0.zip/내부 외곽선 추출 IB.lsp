;;; ==============================================================================
;;;  IB — 내부 외곽선 추출
;;;
;;;  안쪽 빈 곳을 클릭할 때마다 그 둘레를 빨간 폴리선(지금 레이어)으로 만든다 (연속 클릭, Enter = 끝).
;;;   · 섬(안의 기둥 등) 둘레도 같이 만들지 옵션(기본 끔) — 만든 것은 모두 빨강 (예전: 마지막 하나만)
;;;   · 틈 허용(기본 0 = 끊긴 곳이 있으면 실패)을 옵션으로, 끝나면 HPGAPTOL 을 원래대로
;;;   · 직전 것 취소(U). 클릭 하나 = 실행 취소 한 번(U). ESC 로 끝내도 전역 오류 처리는 그대로.
;;; ==============================================================================

;; 점 p(UCS) 둘레 경계 → 새로 생긴 폴리선들 / 없으면 nil
(defun ib:bound (p gap islands / e0 e out old)
  (setq e0 (entlast) old (getvar "HPGAPTOL"))
  (setvar "HPGAPTOL" gap)
  (command "_.-BOUNDARY" "_A" "_B" "_E" "_I" (if islands "_Y" "_N") "_O" "_P" "" "_non" p "")
  (setvar "HPGAPTOL" old)
  (setq e (if e0 (entnext e0) (entnext)))
  (while e
    (if (wcmatch (cdr (assoc 0 (entget e))) "*POLYLINE") (setq out (cons e out)))
    (setq e (entnext e)))
  out)

(defun c:IB ( / *error* doc sv undo_open pt made prev v)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO" "HPGAPTOL")))
  (setvar "CMDECHO" 0)
  (if (null *ib_gap*) (setq *ib_gap* 0.0))
  (while
    (progn
      (initget (if prev "I G U" "I G"))
      (setq pt (getpoint (strcat "\n외곽선을 만들 안쪽 빈 곳을 클릭하세요 [섬(I) " (if *ib_isl* "켬" "끔")
                                 "/틈(G) " (rtos *ib_gap* 2 2) (if prev "/직전 취소(U)" "") "] <끝>: "))))
    (cond
      ((= pt "I") (setq *ib_isl* (not *ib_isl*)))
      ((= pt "G") (initget 4) (if (setq v (getdist (strcat "\n틈 허용 <" (rtos *ib_gap* 2 2) ">: "))) (setq *ib_gap* v)))
      ((= pt "U")
       (foreach e prev (if (entget e) (entdel e)))
       (setq made (- made (length prev)) prev nil)
       (princ "\n직전 외곽선을 지웠습니다."))
      (T
       (vla-StartUndoMark doc)
       (setq undo_open T)
       (if (setq prev (ib:bound pt *ib_gap* *ib_isl*))
         (progn
           (foreach e prev (vla-put-Color (vlax-ename->vla-object e) 1))
           (setq made (+ (if made made 0) (length prev)))
           (princ (strcat "\n빨간 폴리선 " (itoa (length prev)) "개를 만들었습니다.")))
         (princ "\n[주의] 닫힌 경계를 찾지 못했습니다. 선이 끊겼거나(틈 옵션) 영역이 화면 밖에 있습니다."))
       (vla-EndUndoMark doc)
       (setq undo_open nil))))
  (if made (princ (strcat "\n[완료] 외곽선 " (itoa made) "개를 만들었습니다.")))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
