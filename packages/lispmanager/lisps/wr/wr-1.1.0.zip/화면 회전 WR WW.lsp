;;; ==============================================================================
;;;  WR · WW — 사선을 수평으로 보이게 화면 돌리기 · 되돌리기 (보던 자리·크기 유지)
;;;
;;;  WR = 클릭한 곳의 방향이 수평이 되도록 UCS 를 돌리고 그 위에서 본다. 폴리선은 클릭한 구간, 호·원은 클릭한 곳의 접선,
;;;       문자·블록은 그 회전 각도. 위아래가 뒤집히지 않게 ±90° 안에서 돌린다.
;;;  WW = UCS World · 위에서 보기로 되돌린다.
;;; ==============================================================================

(defun wr:err (msg)
  (if wr_sv (setvar "CMDECHO" wr_sv))
  (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
    (princ (strcat "\n[오류] " msg)))
  (princ))

;; 고른 곳의 방향 (월드 기준 라디안) / 못 구하면 nil
(defun wr:angle (sel / e o typ p r)
  (setq e (car sel) o (vlax-ename->vla-object e) typ (cdr (assoc 0 (entget e))))
  (cond
    ((member typ '("TEXT" "MTEXT" "INSERT")) (vla-get-Rotation o))
    ((not (vl-catch-all-error-p (setq p (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list o (trans (cadr sel) 1 0))))))
     (if (not (vl-catch-all-error-p (setq r (vl-catch-all-apply 'vlax-curve-getFirstDeriv (list o (vlax-curve-getParamAtPoint o p))))))
       (angle '(0 0 0) r)))))

;; UCS 를 바꾸고 위에서 보기 — 보던 자리·크기 유지
(defun wr:view (ucs-args / ctr size)
  (setq ctr (trans (getvar "VIEWCTR") 1 0) size (getvar "VIEWSIZE"))
  (command "_.UCS" "_World")
  (if ucs-args (apply 'command (cons "_.UCS" ucs-args)))
  (command "_.PLAN" "_Current")
  (command "_.ZOOM" "_C" "_non" (trans ctr 0 1) size))

(defun c:WR ( / *error* wr_sv sel ang)
  (setq *error* wr:err wr_sv (getvar "CMDECHO"))
  (vl-load-com)
  (setvar "ERRNO" 0)
  (while (and (null (setq sel (entsel "\n수평으로 볼 선·호·폴리선(또는 문자·블록)을 클릭하세요: "))) (= (getvar "ERRNO") 7))
    (princ "\n빗나갔습니다. 다시 클릭하세요.")
    (setvar "ERRNO" 0))
  (cond
    ((null sel) (princ "\n고른 객체가 없습니다."))
    ((null (setq ang (wr:angle sel))) (princ "\n[주의] 방향을 알 수 없는 객체입니다."))
    (T
     (setq ang (rem (+ (rem ang (* 2 pi)) (* 2 pi)) (* 2 pi)))
     (if (and (> ang (/ pi 2)) (<= ang (* 1.5 pi))) (setq ang (+ ang pi)))       ; 뒤집힘 방지
     (if (> ang pi) (setq ang (- ang (* 2 pi))))
     (setvar "CMDECHO" 0)
     (wr:view (list "_Z" (strcat (rtos (* 180.0 (/ ang pi)) 2 8) "d")))
     (setvar "CMDECHO" wr_sv)
     (princ (strcat "\n[완료] 화면을 " (rtos (* 180.0 (/ ang pi)) 2 2) "° 돌렸습니다. 되돌리기: WW"))))
  (princ))

(defun c:WW ( / *error* wr_sv)
  (setq *error* wr:err wr_sv (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (wr:view nil)
  (setvar "CMDECHO" wr_sv)
  (princ "\n[완료] UCS World · 위에서 보기로 되돌렸습니다 (보던 자리 그대로).")
  (princ))

(princ)
