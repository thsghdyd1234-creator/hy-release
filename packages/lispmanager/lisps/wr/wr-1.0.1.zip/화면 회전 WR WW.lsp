;;; =========================================================================
;;; [화면 회전 및 복구 명령어 세트]
;;; 명령: WR (선택한 사선을 수평으로 회전, 화면 유지 및 뒤집힘 방지)
;;; 명령: WW (화면을 원래 WCS 좌표계로 복구, 화면 유지)
;;; =========================================================================

;;; 1. 선택한 사선을 수평으로 화면을 돌리는 명령어 (명령: WR)
(defun c:WR ( / sel ent v_ctr v_size wcs_ctr new_ctr old_cmd p1 p2 ang angDeg )
  (vl-load-com)
  (setq old_cmd (getvar "CMDECHO"))
  (setvar "CMDECHO" 0) ; 명령어 실행 과정 숨김
  
  (setq sel (entsel "\n수평으로 맞출 사선/곡선을 선택하세요: "))
  (if sel
    (progn
      (setq ent (car sel))
      
      ;; 1. 현재 화면 중심점과 확대 비율 백업
      (setq v_ctr (getvar "VIEWCTR"))
      (setq v_size (getvar "VIEWSIZE"))
      (setq wcs_ctr (trans v_ctr 1 0))
      
      ;; 2. 선택한 객체의 시작점과 끝점을 이용해 정확한 각도 계산 (오류 방지)
      (setq p1 (vlax-curve-getStartPoint (vlax-ename->vla-object ent)))
      (setq p2 (vlax-curve-getEndPoint (vlax-ename->vla-object ent)))
      (setq ang (angle p1 p2))
      
      ;; 3. 화면이 180도 뒤집히지 않게 보정
      ;; 선의 방향이 왼쪽을 향할 경우(90도 초과 ~ 270도 이하), 180도를 더해 오른쪽을 향하게 보정
      (if (and (> ang (/ pi 2.0)) (<= ang (* pi 1.5)))
        (setq ang (+ ang pi))
      )
      
      ;; 라디안을 도(Degree) 단위로 변환
      (setq angDeg (* (/ ang pi) 180.0))
      
      ;; 4. 객체 기준이 아닌 절대좌표(World) 기준으로 안전하게 Z축 회전 적용
      (command "_.UCS" "_World")
      (command "_.UCS" "_Z" angDeg)
      (command "_.PLAN" "_Current")
      
      ;; 5. 줌 복구 (작업하던 위치와 크기 그대로)
      (setq new_ctr (trans wcs_ctr 0 1))
      (command "_.ZOOM" "_Center" new_ctr v_size)
      
      (princ "\n선택한 선에 맞춰 화면이 회전되었습니다. (원래대로: WW)")
    )
    (princ "\n객체가 선택되지 않았습니다.")
  )
  (setvar "CMDECHO" old_cmd)
  (princ)
)

;;; =========================================================================

;;; 2. 화면을 원래 상태(WCS)로 복구하는 명령어 (명령: WW)
(defun c:WW ( / v_ctr v_size wcs_ctr new_ctr old_cmd )
  (setq old_cmd (getvar "CMDECHO"))
  (setvar "CMDECHO" 0) ; 명령어 실행 과정 숨김

  ;; 1. 현재 화면 중심점(UCS 기준)과 확대 비율 백업
  (setq v_ctr (getvar "VIEWCTR"))
  (setq v_size (getvar "VIEWSIZE"))
  
  ;; 2. 현재 중심점을 절대좌표(WCS)로 변환
  (setq wcs_ctr (trans v_ctr 1 0))

  ;; 3. 좌표계 및 화면을 WCS(World)로 복구
  (command "_.UCS" "_World")
  (command "_.PLAN" "_World")

  ;; 4. 백업해둔 좌표를 기준으로 원래 작업하던 위치와 크기로 즉시 줌 복구
  (setq new_ctr (trans wcs_ctr 0 1))
  (command "_.ZOOM" "_Center" new_ctr v_size)

  (setvar "CMDECHO" old_cmd)
  (princ "\n원래 좌표계(WCS)로 복구되었습니다. (작업 화면 유지)")
  (princ)
)