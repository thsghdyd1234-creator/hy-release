;; ======================================================================
;; [Y·GN] 중심선 벽체 실시간 생성 (실행 Y / 종료 GN)
;; - 중심선과 벽체 레이어가 같으면 벽체를 다른 레이어로 자동 분리
;; - ㄱ자 모서리를 마이터(연귀)로 맞춰 모서리가 찌그러지지 않음
;; - 종료(GN)하면 연결을 끊어 확정: 중심선을 지워도 벽체는 남음
;; - 명령: 실행(Y), 종료·연결 해제(GN)
;; ======================================================================

(vl-load-com)

;; --- [1] 전역 설정 ---
(if (not *WUX-THICK*) (setq *WUX-THICK* 200.0))
(setq *WUX-DIRTY-LINES* nil)
(setq *WUX-PREV-STATE* nil)
(setq *WUX-UNDO-ACTIVE* nil)
(setq *WUX-LIVE-MODE* nil)
(setq *WUX-CENTER-LAYER* nil)
(setq *WUX-WALL-LAYER* nil)
(setq *WUX-DOC* (vla-get-ActiveDocument (vlax-get-acad-object)))

(if (null (tblsearch "APPID" "WUX_PARAM")) (regapp "WUX_PARAM"))
(if (null (tblsearch "APPID" "WUX_CENTER")) (regapp "WUX_CENTER"))

(defun wux-pt-sub (p1 p2) (list (- (car p1) (car p2)) (- (cadr p1) (cadr p2)) (if (caddr p1) (+ (caddr p1) (caddr p2)) 0.0)))
(defun wux-pt-on-seg (pt p1 p2 / d) (< (abs (- (+ (distance pt p1) (distance pt p2)) (distance p1 p2))) 0.001))

(defun wux-project-pt-to-line (pt p1 p2 / dx dy dot len2 t_val)
  (setq dx (- (car p2) (car p1)) dy (- (cadr p2) (cadr p1)) len2 (+ (* dx dx) (* dy dy)))
  (if (< len2 0.0001) p1
    (progn
      (setq dot (+ (* (- (car pt) (car p1)) dx) (* (- (cadr pt) (cadr p1)) dy)))
      (setq t_val (/ dot len2))
      (list (+ (car p1) (* t_val dx)) (+ (cadr p1) (* t_val dy)) 0.0)
    )
  )
)

;; --- [2] 마이터 계산 + 고립점 정리(ㄱ자 복구) ---
(defun WUX-acos (x) (cond ((>= x 1.0) 0.0) ((<= x -1.0) pi) (T (atan (sqrt (- 1.0 (* x x))) x))))

(defun trp-get-miter-points (P V_out obj curveObjs half_dist extra / touches endpoint_meets mid_meets closestPt otherObj isStart isEnd deriv2 V_out2 len1 len2 u1 u2 S lenS b dot sin_hp D M1 M2 P_L_approx L_dir R_dir)
  (setq touches nil endpoint_meets 0 mid_meets 0)
  (foreach otherObj curveObjs
    (if (not (equal obj otherObj))
      (progn
        (setq closestPt (vlax-curve-getClosestPointTo otherObj P))
        (if (< (distance P closestPt) 1.0)
          (progn
            (setq isStart (< (distance closestPt (vlax-curve-getStartPoint otherObj)) 1.0))
            (setq isEnd (< (distance closestPt (vlax-curve-getEndPoint otherObj)) 1.0))
            (if (or isStart isEnd)
              (progn (setq endpoint_meets (1+ endpoint_meets)) (setq touches (cons otherObj touches)))
              (setq mid_meets (1+ mid_meets))
            )
          )
        )
      )
    )
  )
  
  (setq len1 (sqrt (+ (* (car V_out) (car V_out)) (* (cadr V_out) (cadr V_out)))))
  (setq u1 (list (/ (car V_out) len1) (/ (cadr V_out) len1)))
  (setq L_dir (list (- (cadr u1)) (car u1)))
  (setq R_dir (list (cadr u1) (- (car u1))))
  
  (if (or (> mid_meets 0) (/= endpoint_meets 1))
    (list
      (list (- (+ (car P) (* (car L_dir) half_dist)) (* (car u1) extra)) (- (+ (cadr P) (* (cadr L_dir) half_dist)) (* (cadr u1) extra)))
      (list (- (+ (car P) (* (car R_dir) half_dist)) (* (car u1) extra)) (- (+ (cadr P) (* (cadr R_dir) half_dist)) (* (cadr u1) extra)))
    )
    (progn
      (setq otherObj (car touches) closestPt (vlax-curve-getClosestPointTo otherObj P))
      (setq isStart (< (distance closestPt (vlax-curve-getStartPoint otherObj)) 1.0))
      (if isStart (setq deriv2 (vlax-curve-getFirstDeriv otherObj (vlax-curve-getStartParam otherObj)))
                  (setq deriv2 (vlax-curve-getFirstDeriv otherObj (vlax-curve-getEndParam otherObj))))
      (setq V_out2 (if isStart deriv2 (list (- (car deriv2)) (- (cadr deriv2)) (- (caddr deriv2)))))
      (setq len2 (sqrt (+ (* (car V_out2) (car V_out2)) (* (cadr V_out2) (cadr V_out2)))))
      (setq u2 (list (/ (car V_out2) len2) (/ (cadr V_out2) len2)))
      (setq S (list (+ (car u1) (car u2)) (+ (cadr u1) (cadr u2))))
      (setq lenS (sqrt (+ (* (car S) (car S)) (* (cadr S) (cadr S)))))
      
      (if (< lenS 0.001) (setq b L_dir D half_dist)
        (progn
          (setq b (list (/ (car S) lenS) (/ (cadr S) lenS)) dot (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2))))
          (setq sin_hp (sin (/ (WUX-acos dot) 2.0)))
          (if (< sin_hp 0.05) (setq D (* half_dist 5.0)) (setq D (/ half_dist sin_hp)))
        )
      )
      (setq M1 (list (- (+ (car P) (* D (car b))) (* (car u1) extra)) (- (+ (cadr P) (* D (cadr b))) (* (cadr u1) extra))))
      (setq M2 (list (- (- (car P) (* D (car b))) (* (car u1) extra)) (- (- (cadr P) (* D (cadr b))) (* (cadr u1) extra))))
      (setq P_L_approx (list (+ (car P) (* (car L_dir) half_dist)) (+ (cadr P) (* (cadr L_dir) half_dist))))
      (if (< (distance M1 P_L_approx) (distance M2 P_L_approx)) (list M1 M2) (list M2 M1))
    )
  )
)

;; --- [3] 데이터 태그 및 벽체 재생성 ---
(defun WUX-Set-Wall-Tag (wallEnt / exData)
  (setq exData (list -3 (list "WUX_PARAM" (cons 1000 "WALL"))))
  (vl-catch-all-apply 'entmod (list (append (entget wallEnt) (list exData))))
)
(defun WUX-Set-Center (ent / exData)
  (setq exData (list -3 (list "WUX_CENTER" (cons 1000 "TRUE"))))
  (entmod (append (entget ent) (list exData)))
)

(defun WUX-Regenerate-Walls (curveObjs / obj p1 p2 deriv1_start V_out1 deriv1_end V_out2 pts1 pts2 L1 R1 L2 R2 ptsArray pline mspace half_dist arr regions regList baseReg expRes explodedObjects extra)
  (setq mspace (vla-get-ModelSpace *WUX-DOC*))
  (setq half_dist (/ *WUX-THICK* 2.0) extra 1.0 regList nil)
  
  (foreach obj curveObjs
    (if (= (vla-get-ObjectName obj) "AcDbLine")
      (progn
        (setq p1 (vlax-curve-getStartPoint obj) p2 (vlax-curve-getEndPoint obj))
        (setq deriv1_start (vlax-curve-getFirstDeriv obj (vlax-curve-getStartParam obj)))
        (setq V_out1 deriv1_start) 
        (setq pts1 (trp-get-miter-points p1 V_out1 obj curveObjs half_dist extra))
        (setq deriv1_end (vlax-curve-getFirstDeriv obj (vlax-curve-getEndParam obj)))
        (setq V_out2 (list (- (car deriv1_end)) (- (cadr deriv1_end)) (- (caddr deriv1_end))))
        (setq pts2 (trp-get-miter-points p2 V_out2 obj curveObjs half_dist extra))
        
        (setq L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2))
        (setq ptsArray (vlax-make-safearray vlax-vbDouble '(0 . 7)))
        (vlax-safearray-fill ptsArray (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2)))
        (setq pline (vla-AddLightWeightPolyline mspace ptsArray))
        (vla-put-Closed pline :vlax-true)
        
        (setq arr (vlax-make-safearray vlax-vbObject '(0 . 0)))
        (vlax-safearray-put-element arr 0 pline)
        (setq regions (vl-catch-all-apply 'vla-AddRegion (list mspace arr)))
        (if (not (vl-catch-all-error-p regions)) (setq regList (cons (car (vlax-safearray->list (vlax-variant-value regions))) regList)))
        (vl-catch-all-apply 'vla-delete (list pline))
      )
    )
  )

  (if regList
    (progn
      (setq baseReg (car regList))
      (foreach item (cdr regList) (vl-catch-all-apply 'vla-boolean (list baseReg acUnion item)))
      (setq expRes (vl-catch-all-apply 'vla-Explode (list baseReg)))
      (if (not (vl-catch-all-error-p expRes))
        (progn
          (setq explodedObjects (vlax-safearray->list (vlax-variant-value expRes)))
          (foreach obj explodedObjects 
            (vl-catch-all-apply 'vla-put-color (list obj 256))
            (if *WUX-WALL-LAYER* (vl-catch-all-apply 'vla-put-Layer (list obj *WUX-WALL-LAYER*)))
            (WUX-Set-Wall-Tag (vlax-vla-object->ename obj))
          )
        )
      )
      (vl-catch-all-apply 'vla-delete (list baseReg))
    )
  )
)

;; --- [4] 연결 해제(확정) ---
(defun WUX-Sever-Links ( / ss i ent )
  ;; 1. 중심선의 확장 데이터(WUX_CENTER) 제거
  (if (setq ss (ssget "X" '((-3 ("WUX_CENTER")))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (entmod (list (cons -1 ent) '(-3 ("WUX_CENTER"))))
        (setq i (1+ i))
      )
    )
  )
  ;; 2. 벽체의 확장 데이터(WUX_PARAM) 제거
  (if (setq ss (ssget "X" '((-3 ("WUX_PARAM")))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (entmod (list (cons -1 ent) '(-3 ("WUX_PARAM"))))
        (setq i (1+ i))
      )
    )
  )
  ;; 3. 남은 객체 리액터 삭제
  (if (vlr-reactors :vlr-object-reactor)
    (foreach group (vlr-reactors :vlr-object-reactor)
      (foreach r (cdr group)
        (if (= (vlr-data r) "WUX_OBJ_REACT")
          (vlr-remove r)
        )
      )
    )
  )
)

;; --- [5] 실시간 갱신 리액터 ---
(defun WUX-On-Cmd-Start (reactor cmd-list / cmd ss i ent handle p1 p2)
  (setq cmd (strcase (car cmd-list)))
  (if (wcmatch cmd "*UNDO*,*U*,*OOPS*") (setq *WUX-UNDO-ACTIVE* T) (setq *WUX-UNDO-ACTIVE* nil))

  (if (and *WUX-LIVE-MODE* (not *WUX-UNDO-ACTIVE*))
    (progn
      (setq *WUX-PREV-STATE* nil)
      (if (setq ss (ssget "X" '((-3 ("WUX_CENTER")))))
        (progn
          (setq i 0)
          (while (< i (sslength ss))
            (setq ent (ssname ss i) handle (cdr (assoc 5 (entget ent))))
            (setq p1 (cdr (assoc 10 (entget ent))) p2 (cdr (assoc 11 (entget ent))))
            (setq *WUX-PREV-STATE* (cons (list handle p1 p2) *WUX-PREV-STATE*))
            (setq i (1+ i))
          )
        )
      )
    )
  )
)

(defun WUX-On-Modified (notifier reactor arg-list / handle)
  (if (and *WUX-LIVE-MODE* (not *WUX-UNDO-ACTIVE*))
    (if (vlax-read-enabled-p notifier)
      (progn
        (setq handle (vla-get-Handle notifier))
        (if (not (member handle *WUX-DIRTY-LINES*)) (setq *WUX-DIRTY-LINES* (cons handle *WUX-DIRTY-LINES*)))
      )
    )
  )
)

(defun WUX-Stretch-Orthogonal (handle code delta / ent entData oldPt p1 p2 dx dy len u_x u_y dot allowed_dx allowed_dy newPt)
  (if (and (setq ent (handent handle)) (setq entData (entget ent)))
    (progn
      (setq oldPt (cdr (assoc code entData)) p1 (cdr (assoc 10 entData)) p2 (cdr (assoc 11 entData)))
      (setq dx (- (car p2) (car p1)) dy (- (cadr p2) (cadr p1)) len (sqrt (+ (* dx dx) (* dy dy))))
      (if (> len 0.0001)
        (progn
          (setq u_x (/ dx len) u_y (/ dy len) dot (+ (* (car delta) u_x) (* (cadr delta) u_y)))
          (setq allowed_dx (* dot u_x) allowed_dy (* dot u_y))
          (if (> (+ (* allowed_dx allowed_dx) (* allowed_dy allowed_dy)) 0.0001)
            (progn
              (setq newPt (list (+ (car oldPt) allowed_dx) (+ (cadr oldPt) allowed_dy) 0.0))
              (setq entData (subst (cons code newPt) (assoc code entData) entData))
              (entmod entData) (entupd ent) T
            )
          )
        )
      )
    )
  )
)

(defun WUX-On-Cmd-Ended (reactor cmd-list / cmd lineObj entData new_p1 new_p2 oldData old_p1 old_p2 otherH op1 op2 target_pt move_delta ss i targetLines sync_needed ent obj)
  (setq cmd (strcase (car cmd-list)) sync_needed nil)
  
  (if (or *WUX-UNDO-ACTIVE* (wcmatch cmd "*UNDO*,*U*,*OOPS*"))
    (progn (setq *WUX-DIRTY-LINES* nil) (setq *WUX-UNDO-ACTIVE* nil))
    (if *WUX-LIVE-MODE*
      (progn
        (if (and *WUX-CENTER-LAYER* (wcmatch cmd "*LINE*,*COPY*,*MIRROR*,*ARRAY*,*OFFSET*,*PASTECLIP*"))
          (if (setq ss (ssget "X" (list '(0 . "LINE") (cons 8 *WUX-CENTER-LAYER*))))
            (progn
              (setq i 0)
              (while (< i (sslength ss))
                (setq ent (ssname ss i))
                (if (null (assoc -3 (entget ent '("WUX_CENTER"))))
                  (progn
                    (WUX-Set-Center ent)
                    (setq obj (vlax-ename->vla-object ent))
                    (vlr-object-reactor (list obj) "WUX_OBJ_REACT" '((:vlr-modified . WUX-On-Modified)))
                    (setq sync_needed T)
                  )
                )
                (setq i (1+ i))
              )
            )
          )
        )

        (if (wcmatch cmd "*ERASE*,*DELETE*,*TRIM*,*BREAK*,*STRETCH*,*MOVE*,*GRIP*")
          (setq sync_needed T)
        )

        (if *WUX-DIRTY-LINES*
          (progn
            (foreach handle *WUX-DIRTY-LINES*
              (if (and (setq lineObj (handent handle)) (setq entData (entget lineObj)) (setq oldData (assoc handle *WUX-PREV-STATE*)))
                (progn
                  (setq new_p1 (cdr (assoc 10 entData)) new_p2 (cdr (assoc 11 entData)))
                  (setq old_p1 (cadr oldData) old_p2 (caddr oldData))
                  (foreach item *WUX-PREV-STATE*
                    (setq otherH (car item) op1 (cadr item) op2 (caddr item))
                    (if (and (/= otherH handle) (not (member otherH *WUX-DIRTY-LINES*)))
                      (progn
                        (if (wux-pt-on-seg op1 old_p1 old_p2)
                          (progn
                            (setq target_pt (wux-project-pt-to-line op1 new_p1 new_p2))
                            (setq move_delta (wux-pt-sub target_pt op1))
                            (WUX-Stretch-Orthogonal otherH 10 move_delta)
                          )
                        )
                        (if (wux-pt-on-seg op2 old_p1 old_p2)
                          (progn
                            (setq target_pt (wux-project-pt-to-line op2 new_p1 new_p2))
                            (setq move_delta (wux-pt-sub target_pt op2))
                            (WUX-Stretch-Orthogonal otherH 11 move_delta)
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
            (setq *WUX-DIRTY-LINES* nil)
            (setq sync_needed T)
          )
        )

        (if sync_needed
          (progn
            (if (setq ss (ssget "X" '((-3 ("WUX_PARAM")))))
              (progn (setq i 0) (while (< i (sslength ss)) (vl-catch-all-apply 'entdel (list (ssname ss i))) (setq i (1+ i)))))
            
            (setq targetLines nil)
            (if (setq ss (ssget "X" '((-3 ("WUX_CENTER")))))
              (progn
                (setq i 0)
                (while (< i (sslength ss)) (setq targetLines (cons (vlax-ename->vla-object (ssname ss i)) targetLines)) (setq i (1+ i)))
                (if targetLines (WUX-Regenerate-Walls targetLines))
              )
            )
          )
        )
      )
    )
  )
)

(if *WUX-START-REACTOR* (vlr-remove *WUX-START-REACTOR*))
(if *WUX-CMD-REACTOR* (vlr-remove *WUX-CMD-REACTOR*))
(setq *WUX-START-REACTOR* (vlr-command-reactor nil '((:vlr-commandWillStart . WUX-On-Cmd-Start))))
(setq *WUX-CMD-REACTOR* (vlr-command-reactor nil '((:vlr-commandEnded . WUX-On-Cmd-Ended))))

;; --- [6] 명령: 실행 (Y) / 해제 (GN) ---

;; 6-1. 실행 명령어 (Y)
(defun c:Y ( / tmp_dist ss finalObjs obj i ent layersObj newLayer )
  (if *WUX-LIVE-MODE*
    (princ "\n[알림] 실시간 벽체 모드가 이미 켜져 있습니다. 끝내려면 GN을 입력하세요.")
    (progn
      (setq tmp_dist (getdist (strcat "\n벽체 두께 지정 <" (rtos *WUX-THICK* 2 0) ">: ")))
      (if tmp_dist (setq *WUX-THICK* tmp_dist))

      (prompt "\n[Y 실시간 벽체] 기준 중심선을 선택하세요 (새 도면이면 빈 곳을 클릭한 뒤 Enter): ")
      
      (if (setq ss (ssget '((0 . "LINE"))))
        (progn
          (setq ent (ssname ss 0))
          (setq *WUX-CENTER-LAYER* (cdr (assoc 8 (entget ent))))
        )
        (setq *WUX-CENTER-LAYER* (getvar "CLAYER"))
      )
      
      (setq *WUX-WALL-LAYER* (getvar "CLAYER"))
      
      ;; 레이어가 같으면 벽체 레이어를 자동 분리
      (if (= (strcase *WUX-CENTER-LAYER*) (strcase *WUX-WALL-LAYER*))
        (progn
          (setq *WUX-WALL-LAYER* "WUX-WALL")
          (setq layersObj (vla-get-layers *WUX-DOC*))
          (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-item (list layersObj "WUX-WALL")))
            (progn
              (setq newLayer (vla-add layersObj "WUX-WALL"))
              (vla-put-color newLayer 3) ;; 초록색(3) 지정
            )
          )
          (princ "\n[알림] 중심선과 현재 레이어가 같아서 벽체를 'WUX-WALL'(초록) 레이어에 그립니다.")
        )
      )
      
      (if ss
        (progn
          (setq finalObjs nil i 0)
          (while (< i (sslength ss))
            (setq finalObjs (cons (vlax-ename->vla-object (ssname ss i)) finalObjs))
            (WUX-Set-Center (ssname ss i))
            (setq i (1+ i))
          )
          (foreach obj finalObjs (vlr-object-reactor (list obj) "WUX_OBJ_REACT" '((:vlr-modified . WUX-On-Modified))))
          (WUX-Regenerate-Walls finalObjs)
        )
      )
      
      (setq *WUX-LIVE-MODE* T)
      (princ (strcat "\n[알림] 실시간 벽체 모드를 켰습니다. (끝내기: GN)"))
    )
  )
  (princ)
)

;; 6-2. 종료 명령어 (GN)
(defun c:GN ()
  (if *WUX-LIVE-MODE*
    (progn
      (setq *WUX-LIVE-MODE* nil)
      (WUX-Sever-Links) ;; XData와 객체 리액터 연결 해제
      (princ "\n[완료] 실시간 벽체 모드를 껐습니다. (중심선과 벽체의 연결을 끊었습니다.)")
    )
    (princ "\n[알림] 실시간 벽체 모드가 꺼져 있습니다. 켜려면 Y를 입력하세요.")
  )
  (princ)
)

(princ "\n[Y·GN] 로드했습니다.")
(princ "\n실행: Y | 종료·연결 해제: GN")
(princ)