;; ======================================================================
;; [Y·GN] 중심선 벽체 실시간 생성 (실행 Y / 종료 GN)
;; - Y: 두께를 넣고 중심선(LINE)을 고르면 벽을 만들고, 그 뒤로 중심선을 그리거나 고칠 때마다 벽을 다시 만든다
;;      · 새 중심선 = 그 명령에서 새로 생긴, 중심선 레이어의 모형 공간 LINE 만 (예전: 그 레이어의 선 전부)
;;      · 중심선을 옮기면 끝이 닿아 있던 이웃 중심선이 그 선과 만나는 점까지 따라온다 (비스듬해도)
;;      · ㄱ자 모서리는 마이터(연귀), 끝·T자는 평면으로. 중심선과 지금 레이어가 같으면 벽은 WUX-WALL(초록)
;;      · 벽은 중심선이 바뀔 때만 다시 만든다 (가구를 옮기는 등 다른 편집에는 그대로)
;; - GN: 연결(표시·리액터)을 풀어 확정 — 중심선을 지워도 벽은 남는다. 실시간이 꺼져 있어도 남은 연결을 푼다.
;; - 도면을 다시 열면 실시간은 꺼진 상태: Y 를 다시 하면 지난번 연결은 먼저 풀고(벽은 그대로) 새로 시작한다.
;; - 실시간 중에 벽을 손으로 고치면(개구부 등) 중심선이 바뀔 때 다시 만들어져 사라진다 — GN 으로 확정한 뒤 고칠 것.
;; ======================================================================

(vl-load-com)

;; --- [1] 상태 (다시 불러와도 실시간 모드·레이어는 그대로) ---
(if (not *WUX-THICK*) (setq *WUX-THICK* (cond ((distof (cond ((getenv "HyWuxThick")) ("")))) (200.0))))
(setq *WUX-DIRTY-LINES* nil *WUX-PREV-STATE* nil *WUX-UNDO-ACTIVE* nil)

(defun wux-doc () (vla-get-ActiveDocument (vlax-get-acad-object)))
(defun wux-pt-on-seg (pt p1 p2) (< (abs (- (+ (distance pt p1) (distance pt p2)) (distance p1 p2))) 0.001))
(defun wux-len (obj) (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
(defun WUX-acos (x) (cond ((>= x 1.0) 0.0) ((<= x -1.0) pi) (T (atan (sqrt (- 1.0 (* x x))) x))))

;; --- [2] 끝점 모양: 다른 선 끝 하나와만 만나면 마이터, 아니면(끝·T자·여럿) 평면 (평면만 1 만큼 내밀어 합칠 때 겹치게) ---
(defun WUX-Miter-Points (P V_out obj curveObjs half_dist extra / touches endpoint_meets mid_meets closestPt otherObj isStart
                          deriv2 V_out2 len1 len2 u1 u2 S lenS b dot sin_hp D M1 M2 P_L_approx L_dir R_dir)
  (setq touches nil endpoint_meets 0 mid_meets 0)
  (foreach otherObj curveObjs
    (if (not (equal obj otherObj))
      (progn
        (setq closestPt (vlax-curve-getClosestPointTo otherObj P))
        (if (< (distance P closestPt) 1.0)
          (if (or (< (distance closestPt (vlax-curve-getStartPoint otherObj)) 1.0)
                  (< (distance closestPt (vlax-curve-getEndPoint otherObj)) 1.0))
            (setq endpoint_meets (1+ endpoint_meets) touches (cons otherObj touches))
            (setq mid_meets (1+ mid_meets)))))))
  (setq len1 (sqrt (+ (* (car V_out) (car V_out)) (* (cadr V_out) (cadr V_out))))
        u1 (list (/ (car V_out) len1) (/ (cadr V_out) len1))
        L_dir (list (- (cadr u1)) (car u1))
        R_dir (list (cadr u1) (- (car u1))))
  (if (or (> mid_meets 0) (/= endpoint_meets 1))
    (list
      (list (- (+ (car P) (* (car L_dir) half_dist)) (* (car u1) extra)) (- (+ (cadr P) (* (cadr L_dir) half_dist)) (* (cadr u1) extra)))
      (list (- (+ (car P) (* (car R_dir) half_dist)) (* (car u1) extra)) (- (+ (cadr P) (* (cadr R_dir) half_dist)) (* (cadr u1) extra))))
    (progn
      (setq otherObj (car touches) closestPt (vlax-curve-getClosestPointTo otherObj P)
            isStart (< (distance closestPt (vlax-curve-getStartPoint otherObj)) 1.0)
            deriv2 (vlax-curve-getFirstDeriv otherObj (if isStart (vlax-curve-getStartParam otherObj) (vlax-curve-getEndParam otherObj)))
            V_out2 (if isStart deriv2 (mapcar '- deriv2))
            len2 (sqrt (+ (* (car V_out2) (car V_out2)) (* (cadr V_out2) (cadr V_out2))))
            u2 (list (/ (car V_out2) len2) (/ (cadr V_out2) len2))
            S (list (+ (car u1) (car u2)) (+ (cadr u1) (cadr u2)))
            lenS (sqrt (+ (* (car S) (car S)) (* (cadr S) (cadr S)))))
      (if (< lenS 0.001)
        (setq b L_dir D half_dist)
        (progn
          (setq b (list (/ (car S) lenS) (/ (cadr S) lenS)) dot (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2)))
                sin_hp (sin (/ (WUX-acos dot) 2.0)))
          (setq D (if (< sin_hp 0.05) (* half_dist 5.0) (/ half_dist sin_hp)))))
      ;; 마이터 꼭짓점은 정확히 (예전: 1 만큼 밀어서 바깥 모서리마다 1mm 귀가 생김)
      (setq M1 (list (+ (car P) (* D (car b))) (+ (cadr P) (* D (cadr b))))
            M2 (list (- (car P) (* D (car b))) (- (cadr P) (* D (cadr b))))
            P_L_approx (list (+ (car P) (* (car L_dir) half_dist)) (+ (cadr P) (* (cadr L_dir) half_dist))))
      (if (< (distance M1 P_L_approx) (distance M2 P_L_approx)) (list M1 M2) (list M2 M1)))))

;; --- [3] 표시 · 벽 다시 만들기 ---
(defun WUX-Set-Wall-Tag (wallEnt)
  (vl-catch-all-apply 'entmod (list (append (entget wallEnt) (list (list -3 (list "WUX_PARAM" (cons 1000 "WALL"))))))))
(defun WUX-Set-Center (ent)
  (entmod (append (entget ent) (list (list -3 (list "WUX_CENTER" (cons 1000 "TRUE")))))))

;; 영역을 끝까지 분해해 선·호로 (떨어진 벽 묶음이면 영역이 여러 개로 나옴)
(defun WUX-Deep-Explode (reg / r out)
  (setq r (vl-catch-all-apply 'vla-Explode (list reg)))
  (if (not (vl-catch-all-error-p r))
    (foreach o (vlax-safearray->list (vlax-variant-value r))
      (if (= (vla-get-ObjectName o) "AcDbRegion")
        (progn (setq out (append (WUX-Deep-Explode o) out)) (vl-catch-all-apply 'vla-Delete (list o)))
        (setq out (cons o out)))))
  out)

(defun WUX-Regenerate-Walls (curveObjs / obj p1 p2 pts1 pts2 L1 R1 L2 R2 ptsArray pline mspace half_dist arr regions regList
                               baseReg extra pieces)
  (setq mspace (vla-get-ModelSpace (wux-doc)) half_dist (/ *WUX-THICK* 2.0) extra 1.0 regList nil
        curveObjs (vl-remove-if '(lambda (o) (< (wux-len o) 1e-6)) curveObjs))
  (foreach obj curveObjs
    (if (= (vla-get-ObjectName obj) "AcDbLine")
      (progn
        (setq p1 (vlax-curve-getStartPoint obj) p2 (vlax-curve-getEndPoint obj)
              pts1 (WUX-Miter-Points p1 (vlax-curve-getFirstDeriv obj (vlax-curve-getStartParam obj)) obj curveObjs half_dist extra)
              pts2 (WUX-Miter-Points p2 (mapcar '- (vlax-curve-getFirstDeriv obj (vlax-curve-getEndParam obj))) obj curveObjs half_dist extra)
              L1 (car pts1) R1 (cadr pts1) L2 (car pts2) R2 (cadr pts2)
              ptsArray (vlax-make-safearray vlax-vbDouble '(0 . 7)))
        (vlax-safearray-fill ptsArray (list (car L1) (cadr L1) (car R1) (cadr R1) (car L2) (cadr L2) (car R2) (cadr R2)))
        (setq pline (vla-AddLightWeightPolyline mspace ptsArray))
        (vla-put-Closed pline :vlax-true)
        (setq arr (vlax-make-safearray vlax-vbObject '(0 . 0)))
        (vlax-safearray-put-element arr 0 pline)
        (setq regions (vl-catch-all-apply 'vla-AddRegion (list mspace arr)))
        (if (not (vl-catch-all-error-p regions)) (setq regList (cons (car (vlax-safearray->list (vlax-variant-value regions))) regList)))
        (vl-catch-all-apply 'vla-Delete (list pline)))))
  (if regList
    (progn
      (setq baseReg (car regList))
      ;; 합치지 못한 조각도 따로 분해해 벽으로 (예전: 영역으로 남아 쌓임)
      (foreach item (cdr regList)
        (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Boolean (list baseReg acUnion item)))
          (progn (setq pieces (append (WUX-Deep-Explode item) pieces)) (vl-catch-all-apply 'vla-Delete (list item)))))
      (setq pieces (append (WUX-Deep-Explode baseReg) pieces))
      (vl-catch-all-apply 'vla-Delete (list baseReg))
      (foreach obj pieces
        (vl-catch-all-apply 'vla-put-Color (list obj 256))
        (if *WUX-WALL-LAYER* (vl-catch-all-apply 'vla-put-Layer (list obj *WUX-WALL-LAYER*)))
        (WUX-Set-Wall-Tag (vlax-vla-object->ename obj))))))

;; --- [4] 연결 풀기 (확정) → 푼 중심선 수 ---
(defun WUX-Sever-Links ( / ss i n)
  (setq n 0)
  (if (setq ss (ssget "_X" '((-3 ("WUX_CENTER")))))
    (progn
      (setq i 0 n (sslength ss))
      (while (< i (sslength ss)) (entmod (list (cons -1 (ssname ss i)) '(-3 ("WUX_CENTER")))) (setq i (1+ i)))))
  (if (setq ss (ssget "_X" '((-3 ("WUX_PARAM")))))
    (progn
      (setq i 0)
      (while (< i (sslength ss)) (entmod (list (cons -1 (ssname ss i)) '(-3 ("WUX_PARAM")))) (setq i (1+ i)))))
  (foreach group (vlr-reactors :vlr-object-reactor)
    (foreach r (cdr group) (if (= (vlr-data r) "WUX_OBJ_REACT") (vlr-remove r))))
  n)

(defun WUX-Watch (ent)
  (vlr-object-reactor (list (vlax-ename->vla-object ent)) "WUX_OBJ_REACT"
                      '((:vlr-modified . WUX-On-Modified) (:vlr-erased . WUX-On-Modified) (:vlr-unerased . WUX-On-Modified))))

;; --- [5] 실시간 갱신 리액터 ---
(defun WUX-On-Cmd-Start (reactor cmd-list / cmd ss i ed)
  (setq cmd (strcase (car cmd-list))
        *WUX-UNDO-ACTIVE* (if (member cmd '("U" "UNDO" "OOPS" "REDO" "MREDO")) T nil))
  (if (and *WUX-LIVE-MODE* (not *WUX-UNDO-ACTIVE*))
    (progn
      (setq *WUX-PREV-STATE* nil *WUX-LAST-ENT* (entlast))
      (if (setq ss (ssget "_X" '((-3 ("WUX_CENTER")))))
        (progn
          (setq i 0)
          (while (< i (sslength ss))
            (setq ed (entget (ssname ss i))
                  *WUX-PREV-STATE* (cons (list (cdr (assoc 5 ed)) (cdr (assoc 10 ed)) (cdr (assoc 11 ed))) *WUX-PREV-STATE*)
                  i (1+ i))))))))

(defun WUX-On-Modified (notifier reactor arg-list / h)
  (if (and *WUX-LIVE-MODE* (not *WUX-UNDO-ACTIVE*))
    (progn
      (setq h (vl-catch-all-apply 'vla-get-Handle (list notifier)))
      (if (and (not (vl-catch-all-error-p h)) (not (member h *WUX-DIRTY-LINES*)))
        (setq *WUX-DIRTY-LINES* (cons h *WUX-DIRTY-LINES*))))))

;; 이웃 중심선의 끝(code 10/11)을 옮겨진 선과 만나는 점으로 (비스듬해도 맞음)
(defun WUX-Follow (handle code new_p1 new_p2 / ent ed a b q z)
  (if (and (setq ent (handent handle)) (setq ed (entget ent)))
    (progn
      (setq a (cdr (assoc 10 ed)) b (cdr (assoc 11 ed)) z (caddr (cdr (assoc code ed)))
            q (inters (list (car a) (cadr a)) (list (car b) (cadr b))
                      (list (car new_p1) (cadr new_p1)) (list (car new_p2) (cadr new_p2)) nil))
      (if (and q (> (distance (list (car q) (cadr q)) (list (car (cdr (assoc code ed))) (cadr (cdr (assoc code ed))))) 1e-9))
        (progn (entmod (subst (cons code (list (car q) (cadr q) z)) (assoc code ed) ed)) (entupd ent) T)))))

(defun WUX-On-Cmd-Ended (reactor cmd-list / e ed lineObj entData new_p1 new_p2 oldData old_p1 old_p2 otherH op1 op2 ss i targetLines sync)
  (cond
    (*WUX-UNDO-ACTIVE* (setq *WUX-DIRTY-LINES* nil *WUX-UNDO-ACTIVE* nil))
    (*WUX-LIVE-MODE*
     ;; 1. 이 명령에서 새로 생긴 중심선 (중심선 레이어 · 모형 공간 · LINE) — 복사·나뉜 조각은 표시가 따라오므로 리액터만
     (setq e (if *WUX-LAST-ENT* (entnext *WUX-LAST-ENT*) (entnext)))
     (while e
       (setq ed (entget e '("WUX_CENTER")))
       (if (and ed (= (cdr (assoc 0 ed)) "LINE") *WUX-CENTER-LAYER*
                (= (strcase (cdr (assoc 8 ed))) (strcase *WUX-CENTER-LAYER*))
                (= (cdr (assoc 410 ed)) "Model")
                (> (distance (cdr (assoc 10 ed)) (cdr (assoc 11 ed))) 1e-6))
         (progn
           (if (null (assoc -3 ed)) (WUX-Set-Center e))
           (WUX-Watch e)
           (setq sync T)))
       (setq e (entnext e)))
     ;; 2. 옮겨진 중심선 → 끝이 닿아 있던 이웃이 따라옴
     (if *WUX-DIRTY-LINES*
       (progn
         (foreach handle *WUX-DIRTY-LINES*
           (if (and (setq lineObj (handent handle)) (setq entData (entget lineObj)) (setq oldData (assoc handle *WUX-PREV-STATE*)))
             (progn
               (setq new_p1 (cdr (assoc 10 entData)) new_p2 (cdr (assoc 11 entData))
                     old_p1 (cadr oldData) old_p2 (caddr oldData))
               (if (not (and (equal new_p1 old_p1 1e-9) (equal new_p2 old_p2 1e-9)))
                 (foreach item *WUX-PREV-STATE*
                   (setq otherH (car item) op1 (cadr item) op2 (caddr item))
                   (if (and (/= otherH handle) (not (member otherH *WUX-DIRTY-LINES*)))
                     (progn
                       (if (wux-pt-on-seg op1 old_p1 old_p2) (WUX-Follow otherH 10 new_p1 new_p2))
                       (if (wux-pt-on-seg op2 old_p1 old_p2) (WUX-Follow otherH 11 new_p1 new_p2)))))))))
         (setq *WUX-DIRTY-LINES* nil sync T)))
     ;; 3. 중심선이 바뀌었을 때만 벽을 다시
     (if sync
       (progn
         (if (setq ss (ssget "_X" '((-3 ("WUX_PARAM")))))
           (progn (setq i 0) (while (< i (sslength ss)) (vl-catch-all-apply 'entdel (list (ssname ss i))) (setq i (1+ i)))))
         (setq targetLines nil)
         (if (setq ss (ssget "_X" '((0 . "LINE") (410 . "Model") (-3 ("WUX_CENTER")))))
           (progn
             (setq i 0)
             (while (< i (sslength ss)) (setq targetLines (cons (vlax-ename->vla-object (ssname ss i)) targetLines) i (1+ i)))
             (WUX-Regenerate-Walls targetLines)))
         (setq *WUX-LAST-ENT* (entlast)))))))

(if *WUX-START-REACTOR* (vlr-remove *WUX-START-REACTOR*))
(if *WUX-CMD-REACTOR* (vlr-remove *WUX-CMD-REACTOR*))
(setq *WUX-START-REACTOR* (vlr-command-reactor nil '((:vlr-commandWillStart . WUX-On-Cmd-Start))))
(setq *WUX-CMD-REACTOR* (vlr-command-reactor nil '((:vlr-commandEnded . WUX-On-Cmd-Ended)
                                                   (:vlr-commandCancelled . WUX-On-Cmd-Ended)
                                                   (:vlr-commandFailed . WUX-On-Cmd-Ended))))

;; --- [6] 명령: 실행 (Y) / 해제 (GN) ---
(defun c:Y ( / tmp ss i n0 objs)
  (if *WUX-LIVE-MODE*
    (princ "\n[알림] 실시간 벽체 모드가 이미 켜져 있습니다. 끝내려면 GN을 입력하세요.")
    (progn
      (if (null (tblsearch "APPID" "WUX_PARAM")) (regapp "WUX_PARAM"))
      (if (null (tblsearch "APPID" "WUX_CENTER")) (regapp "WUX_CENTER"))
      (if (> (setq n0 (WUX-Sever-Links)) 0)
        (princ (strcat "\n[알림] 지난번 Y 의 중심선 연결 " (itoa n0) "개를 먼저 풀었습니다 (벽은 그대로).")))
      (initget 6)
      (if (setq tmp (getdist (strcat "\n벽체 두께 <" (rtos *WUX-THICK* 2 0) ">: ")))
        (progn (setq *WUX-THICK* tmp) (setenv "HyWuxThick" (rtos tmp 2 4))))
      (prompt "\n[Y 실시간 벽체] 기준 중심선을 고르세요 (새로 그릴 거면 Enter — 지금 레이어가 중심선 레이어): ")
      (setq ss (ssget '((0 . "LINE") (410 . "Model"))))
      (setq *WUX-CENTER-LAYER* (if ss (cdr (assoc 8 (entget (ssname ss 0)))) (getvar "CLAYER"))
            *WUX-WALL-LAYER* (getvar "CLAYER"))
      (if (= (strcase *WUX-CENTER-LAYER*) (strcase *WUX-WALL-LAYER*))
        (progn
          (setq *WUX-WALL-LAYER* "WUX-WALL")
          (if (not (tblsearch "LAYER" "WUX-WALL"))
            (entmake '((0 . "LAYER") (100 . "AcDbSymbolTableRecord") (100 . "AcDbLayerTableRecord")
                       (2 . "WUX-WALL") (70 . 0) (62 . 3) (6 . "Continuous"))))
          (princ "\n[알림] 중심선과 지금 레이어가 같아서 벽체를 'WUX-WALL'(초록) 레이어에 그립니다.")))
      (if ss
        (progn
          (setq i 0)
          (while (< i (sslength ss))
            (if (and (= (strcase (cdr (assoc 8 (entget (ssname ss i))))) (strcase *WUX-CENTER-LAYER*))
                     (> (wux-len (vlax-ename->vla-object (ssname ss i))) 1e-6))
              (progn
                (WUX-Set-Center (ssname ss i))
                (WUX-Watch (ssname ss i))
                (setq objs (cons (vlax-ename->vla-object (ssname ss i)) objs))))
            (setq i (1+ i)))
          (if objs (WUX-Regenerate-Walls objs))))
      (setq *WUX-LIVE-MODE* T *WUX-LAST-ENT* (entlast))
      (princ (strcat "\n[알림] 실시간 벽체 모드를 켰습니다 — 중심선 레이어 " *WUX-CENTER-LAYER* ", 두께 " (rtos *WUX-THICK* 2 0) " (끝내기: GN)"))))
  (princ))

(defun c:GN ( / n)
  (setq n (WUX-Sever-Links))
  (cond
    (*WUX-LIVE-MODE*
     (setq *WUX-LIVE-MODE* nil)
     (princ (strcat "\n[완료] 실시간 벽체 모드를 껐습니다. 중심선 " (itoa n) "개와 벽체의 연결을 풀었습니다.")))
    ((> n 0) (princ (strcat "\n[완료] 남아 있던 중심선 연결 " (itoa n) "개를 풀었습니다.")))
    (T (princ "\n[알림] 실시간 벽체 모드가 꺼져 있습니다. 켜려면 Y를 입력하세요.")))
  (princ))

(princ)
