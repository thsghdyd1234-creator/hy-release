;;; ==============================================================================
;;;  CAP4 — 기둥 · 창호 면으로 벽 끝 막기
;;;
;;;  벽 레이어 선을 하나 클릭하고 영역을 고르면, 다른 레이어 선(기둥 · 창틀, 블록 안 선까지)을 벽선과 만나는 점마다 나눠
;;;  같은 벽의 평행한 두 면 사이에 걸친 토막만 벽 레이어로 옮깁니다. 새로 그리지 않고 있던 면을 살리므로 원 기둥은 호 그대로,
;;;  꺾인 기둥 면은 폴리선 그대로 들어갑니다.
;;;  거르는 것: 같은 벽선 위 두 점 사이 토막(작은 기둥 속) · 직각인 두 벽면 사이(기둥 모서리 대각선) · 두 면 사이 띠 밖
;;;  (잘라 둔 벽에서 기둥을 돌아가는 먼 쪽) · 닫힌 모양도 아니고 그 자리에서 벽선이 끝나지도 않는 곳(이어진 벽을 가로지르는 선)
;;;  · 중심선 · 그리드 · 은선 · 점선 · 이미 벽 레이어 선이 있는 곳.
;;;  블록은 도면에 분해하지 않고 블록 변환을 계산해 읽습니다. 교차는 상자가 겹치는 짝만 계산합니다.
;;;  벽 두께 범위는 [두께(T)]로 바꾸고 기억합니다. 한 번 실행 = 실행 취소 한 번(U), 새 선은 골라 둡니다.
;;;  YGN CAD(캐드 2025 · 2026)의 HYCAP 은 같은 규칙에 남은 열린 끝 잇기까지 합니다.
;;; ==============================================================================

;; ── 각 ──
(defun cap4:norm (a / tp)
  (setq tp (* 2.0 pi) a (rem a tp))
  (if (< a 0.0) (+ a tp) a))

(defun cap4:ccw (a b) (cap4:norm (- b a)))

(defun cap4:ang (p q)
  (if (and (equal (car p) (car q) 1e-15) (equal (cadr p) (cadr q) 1e-15)) 0.0 (atan (- (cadr q) (cadr p)) (- (car q) (car p)))))

(defun cap4:clamp (v) (max 0.0 (min 1.0 v)))

;; ── 조각: (L x0 y0 x1 y1) · (A cx cy r a0 sw) — 호는 시작 각 a0 에서 sw 만큼 (+ 반시계, − 시계) ──
(defun cap4:arc-p (p) (eq (car p) 'A))

(defun cap4:pt (p tt / g)
  (if (cap4:arc-p p)
    (progn
      (setq g (+ (nth 4 p) (* (nth 5 p) tt)))
      (list (+ (nth 1 p) (* (nth 3 p) (cos g))) (+ (nth 2 p) (* (nth 3 p) (sin g)))))
    (list (+ (nth 1 p) (* (- (nth 3 p) (nth 1 p)) tt)) (+ (nth 2 p) (* (- (nth 4 p) (nth 2 p)) tt)))))

(defun cap4:len (p)
  (if (cap4:arc-p p)
    (abs (* (nth 5 p) (nth 3 p)))
    (distance (list (nth 1 p) (nth 2 p)) (list (nth 3 p) (nth 4 p)))))

(defun cap4:sub (p t0 t1)
  (if (cap4:arc-p p)
    (list 'A (nth 1 p) (nth 2 p) (nth 3 p) (+ (nth 4 p) (* (nth 5 p) t0)) (* (nth 5 p) (- t1 t0)))
    (append '(L) (cap4:pt p t0) (cap4:pt p t1))))

;; 호 위 각 g 의 비율 (eps 라디안까지 밖 허용, 아니면 nil)
(defun cap4:arct (p g eps / s d tp)
  (setq s (abs (nth 5 p)) tp (* 2.0 pi))
  (if (> s 1e-15)
    (progn
      (setq d (if (>= (nth 5 p) 0.0) (cap4:ccw (nth 4 p) g) (cap4:ccw g (nth 4 p))))
      (cond ((<= d (+ s eps)) (/ d s))
            ((<= (- tp d) eps) (- (/ (- tp d) s)))))))

;; 상자 (x0 y0 x1 y1)
(defun cap4:box (p / a b x0 y0 x1 y1 g tt q)
  (setq a (cap4:pt p 0.0) b (cap4:pt p 1.0)
        x0 (min (car a) (car b)) x1 (max (car a) (car b)) y0 (min (cadr a) (cadr b)) y1 (max (cadr a) (cadr b)))
  (if (cap4:arc-p p)
    (foreach g (list 0.0 (* 0.5 pi) pi (* 1.5 pi))
      (setq tt (cap4:arct p g 0.0))
      (if (and tt (>= tt 0.0) (<= tt 1.0))
        (setq q (list (+ (nth 1 p) (* (nth 3 p) (cos g))) (+ (nth 2 p) (* (nth 3 p) (sin g))))
              x0 (min x0 (car q)) x1 (max x1 (car q)) y0 (min y0 (cadr q)) y1 (max y1 (cadr q))))))
  (list x0 y0 x1 y1))

;; 점 q 까지 거리
(defun cap4:dist (p q / dx dy l k c tt)
  (if (cap4:arc-p p)
    (progn
      (setq c (list (nth 1 p) (nth 2 p)))
      (if (and (> (distance c q) 1e-12) (setq tt (cap4:arct p (cap4:ang c q) 0.0)) (>= tt 0.0) (<= tt 1.0))
        (abs (- (distance c q) (nth 3 p)))
        (min (distance q (cap4:pt p 0.0)) (distance q (cap4:pt p 1.0)))))
    (progn
      (setq dx (- (nth 3 p) (nth 1 p)) dy (- (nth 4 p) (nth 2 p)) l (+ (* dx dx) (* dy dy))
            k (if (> l 1e-24) (cap4:clamp (/ (+ (* (- (car q) (nth 1 p)) dx) (* (- (cadr q) (nth 2 p)) dy)) l)) 0.0))
      (distance q (list (+ (nth 1 p) (* k dx)) (+ (nth 2 p) (* k dy)))))))

;; 폴리선 구간 a → b (볼록 g, + 반시계)
(defun cap4:bulge (a b g / chord th r ux uy k cx cy)
  (setq chord (distance a b))
  (if (or (< (abs g) 1e-9) (< chord 1e-12))
    (list 'L (car a) (cadr a) (car b) (cadr b))
    (progn
      (setq th (* 4.0 (atan g)) r (/ chord (* 2.0 (abs (sin (/ th 2.0)))))
            ux (/ (- (car b) (car a)) chord) uy (/ (- (cadr b) (cadr a)) chord)
            k (/ (* (/ chord 2.0) (cos (/ th 2.0))) (sin (/ th 2.0)))
            cx (- (/ (+ (car a) (car b)) 2.0) (* uy k)) cy (+ (/ (+ (cadr a) (cadr b)) 2.0) (* ux k)))
      (list 'A cx cy r (cap4:ang (list cx cy) a) th))))

;; ── 만나는 점: ((ta tb 점) …) — 끝을 tol 만큼 넘어도 닿음, 평행 · 겹침은 만남 아님 ──
(defun cap4:ll (a b tol / rx ry sx sy lr ls den qx qy tt u)
  (setq rx (- (nth 3 a) (nth 1 a)) ry (- (nth 4 a) (nth 2 a)) sx (- (nth 3 b) (nth 1 b)) sy (- (nth 4 b) (nth 2 b))
        lr (sqrt (+ (* rx rx) (* ry ry))) ls (sqrt (+ (* sx sx) (* sy sy))))
  (if (and (> lr 1e-12) (> ls 1e-12))
    (progn
      (setq den (- (* rx sy) (* ry sx)))
      (if (> (abs den) (* 1e-10 lr ls))
        (progn
          (setq qx (- (nth 1 b) (nth 1 a)) qy (- (nth 2 b) (nth 2 a))
                tt (/ (- (* qx sy) (* qy sx)) den) u (/ (- (* qx ry) (* qy rx)) den))
          (if (and (>= tt (- (/ tol lr))) (<= tt (+ 1.0 (/ tol lr))) (>= u (- (/ tol ls))) (<= u (+ 1.0 (/ tol ls))))
            (list (list (cap4:clamp tt) (cap4:clamp u) (cap4:pt a (cap4:clamp tt))))))))))

(defun cap4:la (s c tol swap / dx dy a fx fy dl b cc disc roots sq out tt u et eps px py)
  (setq dx (- (nth 3 s) (nth 1 s)) dy (- (nth 4 s) (nth 2 s)) a (+ (* dx dx) (* dy dy)))
  (if (and (> a 1e-24) (> (nth 3 c) 1e-12))
    (progn
      (setq fx (- (nth 1 s) (nth 1 c)) fy (- (nth 2 s) (nth 2 c)) dl (sqrt a))
      (if (<= (/ (abs (- (* fx dy) (* fy dx))) dl) (+ (nth 3 c) tol))
        (progn
          (setq b (* 2.0 (+ (* fx dx) (* fy dy))) cc (- (+ (* fx fx) (* fy fy)) (* (nth 3 c) (nth 3 c)))
                disc (- (* b b) (* 4.0 a cc)))
          (if (or (<= disc 0.0) (< (* (/ (sqrt (max 0.0 disc)) a) dl) (* tol 0.5)))
            (setq roots (list (/ (- b) (* 2.0 a))))
            (setq sq (sqrt disc) roots (list (/ (- (- b) sq) (* 2.0 a)) (/ (+ (- b) sq) (* 2.0 a)))))
          (setq et (/ tol dl) eps (/ tol (nth 3 c)))
          (foreach tt roots
            (if (and (>= tt (- et)) (<= tt (+ 1.0 et)))
              (progn
                (setq px (+ (nth 1 s) (* dx tt)) py (+ (nth 2 s) (* dy tt))
                      u (cap4:arct c (cap4:ang (list (nth 1 c) (nth 2 c)) (list px py)) eps))
                (if u
                  (setq out (cons (if swap
                                    (list (cap4:clamp u) (cap4:clamp tt) (cap4:pt c (cap4:clamp u)))
                                    (list (cap4:clamp tt) (cap4:clamp u) (cap4:pt s (cap4:clamp tt))))
                                  out))))))
          out)))))

(defun cap4:aa (a b tol / dx dy d x h2 h ux uy bx by pts out ta tb)
  (setq dx (- (nth 1 b) (nth 1 a)) dy (- (nth 2 b) (nth 2 a)) d (sqrt (+ (* dx dx) (* dy dy))))
  (if (and (> d 1e-9) (<= d (+ (nth 3 a) (nth 3 b) tol)) (>= d (- (abs (- (nth 3 a) (nth 3 b))) tol)))
    (progn
      (setq x (/ (+ (- (* (nth 3 a) (nth 3 a)) (* (nth 3 b) (nth 3 b))) (* d d)) (* 2.0 d))
            h2 (- (* (nth 3 a) (nth 3 a)) (* x x)) h (if (> h2 0.0) (sqrt h2) 0.0)
            ux (/ dx d) uy (/ dy d) bx (+ (nth 1 a) (* ux x)) by (+ (nth 2 a) (* uy x)))
      (setq pts (if (< h (* tol 0.5))
                  (list (list bx by))
                  (list (list (- bx (* uy h)) (+ by (* ux h))) (list (+ bx (* uy h)) (- by (* ux h))))))
      (foreach q pts
        (setq ta (cap4:arct a (cap4:ang (list (nth 1 a) (nth 2 a)) q) (/ tol (nth 3 a)))
              tb (cap4:arct b (cap4:ang (list (nth 1 b) (nth 2 b)) q) (/ tol (nth 3 b))))
        (if (and ta tb) (setq out (cons (list (cap4:clamp ta) (cap4:clamp tb) (cap4:pt a (cap4:clamp ta))) out))))
      out)))

(defun cap4:isect (a b tol)
  (cond ((and (not (cap4:arc-p a)) (not (cap4:arc-p b))) (cap4:ll a b tol))
        ((not (cap4:arc-p a)) (cap4:la a b tol nil))
        ((not (cap4:arc-p b)) (cap4:la b a tol T))
        (T (cap4:aa a b tol))))

;; ── 객체 → (닫힘 조각…) — 객체 자신의 좌표 (블록 안이면 블록 좌표), 평면에 누운 것만 ──
(defun cap4:pieces (ed / typ nz c r a0 sw pts bul g closed out k cx n mj rt t0 t1 i q prev)
  (setq typ (cdr (assoc 0 ed)) nz (if (assoc 210 ed) (cadddr (assoc 210 ed)) 1.0))
  (cond
    ((< (abs nz) 0.999) nil)
    ((= typ "LINE")
     (setq c (cdr (assoc 10 ed)) q (cdr (assoc 11 ed)))
     (if (> (distance (list (car c) (cadr c)) (list (car q) (cadr q))) 1e-9)
       (list nil (list 'L (car c) (cadr c) (car q) (cadr q)))))
    ((= typ "ARC")
     (setq c (cdr (assoc 10 ed)) r (cdr (assoc 40 ed)) a0 (cdr (assoc 50 ed)) sw (cap4:ccw a0 (cdr (assoc 51 ed))))
     (if (and (> sw 1e-12) (> r 1e-12))
       (if (> nz 0.0)
         (list nil (list 'A (car c) (cadr c) r a0 sw))
         (list nil (list 'A (- (car c)) (cadr c) r (- pi a0) (- sw))))))
    ((= typ "CIRCLE")
     (setq c (cdr (assoc 10 ed)) r (cdr (assoc 40 ed)) cx (if (> nz 0.0) (car c) (- (car c))))
     (if (> r 1e-12) (list T (list 'A cx (cadr c) r 0.0 pi) (list 'A cx (cadr c) r pi pi))))
    ((= typ "LWPOLYLINE")
     (foreach g ed
       (cond ((= (car g) 10) (setq pts (cons (list (if (> nz 0.0) (cadr g) (- (cadr g))) (caddr g)) pts) bul (cons 0.0 bul)))
             ((and (= (car g) 42) bul) (setq bul (cons (if (> nz 0.0) (cdr g) (- (cdr g))) (cdr bul))))))
     (setq pts (reverse pts) bul (reverse bul) closed (= 1 (logand 1 (cdr (assoc 70 ed)))) n (length pts) k 0)
     (repeat (if closed n (1- n))
       (setq q (cap4:bulge (nth k pts) (nth (rem (1+ k) n) pts) (nth k bul)))
       (if (> (cap4:len q) 1e-12) (setq out (cons q out)))
       (setq k (1+ k)))
     (if out (cons closed (reverse out))))
    ((= typ "ELLIPSE")
     ;; 타원은 잘게 나눈 선으로
     (setq c (cdr (assoc 10 ed)) mj (cdr (assoc 11 ed)) rt (cdr (assoc 40 ed)) t0 (cdr (assoc 41 ed)) t1 (cdr (assoc 42 ed))
           sw (- t1 t0))
     (if (<= sw 1e-12) (setq sw (+ sw (* 2.0 pi))))
     (setq n (max 16 (fix (+ 0.999 (/ sw (/ pi 24.0))))) i 0)
     (repeat (1+ n)
       (setq g (+ t0 (* sw (/ (float i) n)))
             q (list (+ (car c) (* (car mj) (cos g)) (* (- (* nz (cadr mj))) rt (sin g)))
                     (+ (cadr c) (* (cadr mj) (cos g)) (* nz (car mj) rt (sin g)))))
       (if prev (setq out (cons (list 'L (car prev) (cadr prev) (car q) (cadr q)) out)))
       (setq prev q i (1+ i)))
     (if out (cons (> sw (- (* 2.0 pi) 1e-9)) (reverse out))))))

;; ── 블록 변환 (a b c d tx ty): x' = a·x + b·y + tx, y' = c·x + d·y + ty ──
(defun cap4:xp (m p)
  (list (+ (* (nth 0 m) (car p)) (* (nth 1 m) (cadr p)) (nth 4 m)) (+ (* (nth 2 m) (car p)) (* (nth 3 m) (cadr p)) (nth 5 m))))

;; outer · inner (inner 먼저)
(defun cap4:compose (o i)
  (list (+ (* (nth 0 o) (nth 0 i)) (* (nth 1 o) (nth 2 i))) (+ (* (nth 0 o) (nth 1 i)) (* (nth 1 o) (nth 3 i)))
        (+ (* (nth 2 o) (nth 0 i)) (* (nth 3 o) (nth 2 i))) (+ (* (nth 2 o) (nth 1 i)) (* (nth 3 o) (nth 3 i)))
        (+ (* (nth 0 o) (nth 4 i)) (* (nth 1 o) (nth 5 i)) (nth 4 o)) (+ (* (nth 2 o) (nth 4 i)) (* (nth 3 o) (nth 5 i)) (nth 5 o))))

;; INSERT 의 변환 — 평면에 놓인 것만 (아니면 nil)
(defun cap4:ins-xf (ed / nz ins sx sy rot base cs sn a b c d tx ty)
  (setq nz (if (assoc 210 ed) (cadddr (assoc 210 ed)) 1.0))
  (if (>= (abs nz) 0.999)
    (progn
      (setq ins (cdr (assoc 10 ed)) sx (cond ((cdr (assoc 41 ed))) (1.0)) sy (cond ((cdr (assoc 42 ed))) (1.0))
            rot (cond ((cdr (assoc 50 ed))) (0.0)) base (cdr (assoc 10 (tblsearch "BLOCK" (cdr (assoc 2 ed)))))
            cs (cos rot) sn (sin rot) a (* cs sx) b (- (* sn sy)) c (* sn sx) d (* cs sy))
      (if (null base) (setq base '(0.0 0.0 0.0)))
      (setq tx (- (car ins) (+ (* a (car base)) (* b (cadr base)))) ty (- (cadr ins) (+ (* c (car base)) (* d (cadr base)))))
      (if (< nz 0.0) (list (- a) (- b) c d (- tx) ty) (list a b c d tx ty)))))

;; 조각에 변환 — 회전 · 균일 축척 · 뒤집기면 호는 호로(뒤집히면 방향이 바뀜), 고르지 않은 축척이면 잘게 나눈 선으로
(defun cap4:xpiece (m p / det eps c a n i prev q out)
  (if (not (cap4:arc-p p))
    (list (append '(L) (cap4:xp m (cap4:pt p 0.0)) (cap4:xp m (cap4:pt p 1.0))))
    (progn
      (setq det (- (* (nth 0 m) (nth 3 m)) (* (nth 1 m) (nth 2 m)))
            eps (* 1e-9 (+ (abs (nth 0 m)) (abs (nth 1 m)) (abs (nth 2 m)) (abs (nth 3 m)))))
      (if (or (and (<= (abs (- (nth 0 m) (nth 3 m))) eps) (<= (abs (+ (nth 1 m) (nth 2 m))) eps))
              (and (<= (abs (+ (nth 0 m) (nth 3 m))) eps) (<= (abs (- (nth 1 m) (nth 2 m))) eps)))
        (progn
          (setq c (cap4:xp m (list (nth 1 p) (nth 2 p))) a (cap4:xp m (cap4:pt p 0.0)))
          (list (list 'A (car c) (cadr c) (* (nth 3 p) (sqrt (abs det))) (cap4:ang c a) (if (>= det 0.0) (nth 5 p) (- (nth 5 p))))))
        (progn
          (setq n (max 8 (fix (+ 0.999 (/ (abs (nth 5 p)) (/ pi 32.0))))) i 1 prev (cap4:xp m (cap4:pt p 0.0)))
          (repeat n
            (setq q (cap4:xp m (cap4:pt p (/ (float i) n))) out (cons (append '(L) prev q) out) prev q i (1+ i)))
          (reverse out))))))

;; ── 레이어 · 선종류 ──
(defun cap4:layer-on (lay / l)
  (setq l (tblsearch "LAYER" lay))
  (or (null l) (and (>= (cdr (assoc 62 l)) 0) (= 0 (logand 1 (cdr (assoc 70 l)))))))

(defun cap4:ltype (ed lay / lt l)
  (setq lt (cdr (assoc 6 ed)))
  (if (or (null lt) (= (strcase lt) "BYLAYER"))
    (if (setq l (tblsearch "LAYER" lay)) (cond ((cdr (assoc 6 l))) ("")) "")
    (if (= (strcase lt) "BYBLOCK") "" lt)))

;; 벽 끝 막기에 안 쓰는 선 (선종류) — 중심선 · 은선 · 점선 등
(defun cap4:skip-lt (lt / u)
  (setq u (strcase (cond (lt) (""))))
  (and (/= u "") (/= u "CONTINUOUS")
       (wcmatch u "*CENTER*,*CEN*,*DASH*,*HIDDEN*,*PHANTOM*,*DOT*,*DIVIDE*,*BORDER*,ACAD_ISO0[2-9]*,ACAD_ISO1[0-5]*,JIS_*")))

;; aux 로 안 쓰는 선 (레이어 이름 · 선종류) — HYCAP 의 CapRules.SkipAux 와 같음
(defun cap4:skip-aux (lay lt)
  (or (cap4:skip-lt lt)
      (wcmatch (strcase lay) "*CEN*,*중심*,*C.L*,*GRID*,*GRI*,*그리드*,*DOT*,*HID*,*은선*,*점선*,*DIM*,*치수*,*TEXT*,*문자*,*HAT*,*해치*,*SHEET*,*도곽*,*AREA*,*면적*,*개구부*")))

;; 블록 정의 안 곡선 → ((닫힘 조각…) …) (변환 m, 0 레이어 객체는 블록이 놓인 레이어 lay 를 따름)
(defun cap4:block (nm m lay depth / bd e ed typ el pc xm out g)
  (setq bd (tblsearch "BLOCK" nm))
  (if (and bd (< depth 6) (= 0 (logand 4 (cdr (assoc 70 bd)))) (setq e (tblobjname "BLOCK" nm)))
    (progn
      (setq e (entnext e))
      (while e
        (setq ed (entget e) typ (cdr (assoc 0 ed)))
        (if (and (/= typ "ENDBLK") (/= (cdr (assoc 60 ed)) 1))
          (progn
            (setq el (cdr (assoc 8 ed)))
            (if (= el "0") (setq el lay))
            (cond
              ((not (cap4:layer-on el)))
              ((= typ "INSERT")
               (if (setq xm (cap4:ins-xf ed))
                 (setq out (append (cap4:block (cdr (assoc 2 ed)) (cap4:compose m xm) el (1+ depth)) out))))
              ((and (member typ '("LINE" "ARC" "CIRCLE" "LWPOLYLINE" "ELLIPSE")) (not (cap4:skip-aux el (cap4:ltype ed el))))
               (if (setq pc (cap4:pieces ed))
                 (setq out (cons (cons (car pc) (apply 'append (mapcar '(lambda (g) (cap4:xpiece m g)) (cdr pc)))) out)))))))
        (setq e (if (= typ "ENDBLK") nil (entnext e))))))
  out)

;; ── 토막 ──
;; 곡선 조각 목록 pcs 의 u0 → u1 (u = 조각 번호 + 비율), wrap = 끝을 지나 처음으로
(defun cap4:subpath (pcs u0 u1 wrap / n out cap4:range)
  (setq n (length pcs))
  (defun cap4:range (a b / k0 k1 t0 t1 k)
    (setq k0 (min (1- n) (fix a)) k1 (if (>= b n) (1- n) (min (1- n) (fix b))) t0 (- a k0) t1 (- b k1))
    (if (= k0 k1)
      (if (> (- t1 t0) 1e-12) (setq out (cons (cap4:sub (nth k0 pcs) t0 t1) out)))
      (progn
        (if (< t0 (- 1.0 1e-12)) (setq out (cons (cap4:sub (nth k0 pcs) t0 1.0) out)))
        (setq k (1+ k0))
        (while (< k k1) (setq out (cons (nth k pcs) out) k (1+ k)))
        (if (> t1 1e-12) (setq out (cons (cap4:sub (nth k1 pcs) 0.0 t1) out))))))
  (if wrap
    (progn (cap4:range u0 n) (cap4:range 0.0 u1))
    (cap4:range u0 u1))
  (cap4:merge (vl-remove-if '(lambda (q) (<= (cap4:len q) 1e-9)) (reverse out))))

;; 이어진 같은 원의 호 · 한 직선 위 선분을 하나로
(defun cap4:merge (path / out a b)
  (foreach b path
    (setq a (car out))
    (cond
      ((and a (cap4:arc-p a) (cap4:arc-p b) (equal (nth 1 a) (nth 1 b) 1e-9) (equal (nth 2 a) (nth 2 b) 1e-9)
            (equal (nth 3 a) (nth 3 b) 1e-9) (> (* (nth 5 a) (nth 5 b)) 0.0) (< (abs (+ (nth 5 a) (nth 5 b))) (- (* 2.0 pi) 1e-9)))
       (setq out (cons (list 'A (nth 1 a) (nth 2 a) (nth 3 a) (nth 4 a) (+ (nth 5 a) (nth 5 b))) (cdr out))))
      ((and a (not (cap4:arc-p a)) (not (cap4:arc-p b)) (> (cap4:len a) 1e-12) (> (cap4:len b) 1e-12)
            (equal (cap4:ang (cap4:pt a 0.0) (cap4:pt a 1.0)) (cap4:ang (cap4:pt b 0.0) (cap4:pt b 1.0)) 1e-12)
            (< (cap4:dist (list 'L (nth 1 a) (nth 2 a) (nth 3 b) (nth 4 b)) (cap4:pt a 1.0)) 1e-9))
       (setq out (cons (list 'L (nth 1 a) (nth 2 a) (nth 3 b) (nth 4 b)) (cdr out))))
      (T (setq out (cons b out)))))
  (reverse out))

(defun cap4:path-len (path) (apply '+ (mapcar 'cap4:len path)))

;; 길이 비율 f 의 점
(defun cap4:path-at (path f / want acc l q done)
  (setq want (* (cap4:path-len path) (cap4:clamp f)) acc 0.0)
  (while (and path (not done))
    (setq l (cap4:len (car path)))
    (if (or (<= want (+ acc l)) (null (cdr path)))
      (setq q (cap4:pt (car path) (if (< l 1e-15) 0.0 (cap4:clamp (/ (- want acc) l)))) done T)
      (setq acc (+ acc l) path (cdr path))))
  q)

;; 두 벽면 fa · fb 관계 — 평행한 곧은 면: (S ox oy ux uy nx ny 두께 lo hi), 동심 호: (C cx cy r0 r1 fa fb 두께), 아니면 nil (두께는 늘 7번째)
(defun cap4:pair (fa fb tmin tmax tol / la ux uy uxb uyb lb tk nx ny b0 b1)
  (cond
    ((and (not (cap4:arc-p fa)) (not (cap4:arc-p fb)))
     (setq la (cap4:len fa) lb (cap4:len fb))
     (if (and (> la 1e-9) (> lb 1e-9))
       (progn
         (setq ux (/ (- (nth 3 fa) (nth 1 fa)) la) uy (/ (- (nth 4 fa) (nth 2 fa)) la)
               uxb (/ (- (nth 3 fb) (nth 1 fb)) lb) uyb (/ (- (nth 4 fb) (nth 2 fb)) lb))
         (if (<= (abs (- (* ux uyb) (* uy uxb))) 0.0175)
           (progn
             (setq tk (+ (* (- (nth 1 fb) (nth 1 fa)) (- uy)) (* (- (nth 2 fb) (nth 2 fa)) ux)))
             (if (>= tk 0.0) (setq nx (- uy) ny ux) (setq nx uy ny (- ux) tk (- tk)))
             (setq b0 (+ (* (- (nth 1 fb) (nth 1 fa)) ux) (* (- (nth 2 fb) (nth 2 fa)) uy))
                   b1 (+ (* (- (nth 3 fb) (nth 1 fa)) ux) (* (- (nth 4 fb) (nth 2 fa)) uy)))
             (if (and (>= tk (- tmin tol)) (<= tk (+ tmax tol)))
               (list 'S (nth 1 fa) (nth 2 fa) ux uy nx ny tk (min 0.0 b0 b1) (max la b0 b1))))))))
    ((and (cap4:arc-p fa) (cap4:arc-p fb))
     (if (<= (distance (list (nth 1 fa) (nth 2 fa)) (list (nth 1 fb) (nth 2 fb))) (max tol (* (max (nth 3 fa) (nth 3 fb)) 0.002)))
       (progn
         (setq tk (abs (- (nth 3 fa) (nth 3 fb))))
         (if (and (>= tk (- tmin tol)) (<= tk (+ tmax tol)))
           (list 'C (nth 1 fa) (nth 2 fa) (min (nth 3 fa) (nth 3 fb)) (max (nth 3 fa) (nth 3 fb)) fa fb tk)))))))

;; 토막이 두 면 사이 띠 안 · 벽면이 있는 구간 안인지 (1/4 · 1/2 · 3/4 점)
(defun cap4:inside (rel path tol / ok q s v r g eps)
  (setq ok T)
  (foreach f '(0.25 0.5 0.75)
    (if ok
      (progn
        (setq q (cap4:path-at path f))
        (if (eq (car rel) 'S)
          (progn
            (setq s (+ (* (- (car q) (nth 1 rel)) (nth 5 rel)) (* (- (cadr q) (nth 2 rel)) (nth 6 rel)))
                  v (+ (* (- (car q) (nth 1 rel)) (nth 3 rel)) (* (- (cadr q) (nth 2 rel)) (nth 4 rel))))
            (if (or (<= s (* tol 0.25)) (>= s (- (nth 7 rel) (* tol 0.25))) (< v (- (nth 8 rel) tol)) (> v (+ (nth 9 rel) tol)))
              (setq ok nil)))
          (progn
            (setq r (distance q (list (nth 1 rel) (nth 2 rel))) g (cap4:ang (list (nth 1 rel) (nth 2 rel)) q) eps (/ tol (max (nth 4 rel) 1e-9)))
            (if (or (<= r (+ (nth 3 rel) (* tol 0.25))) (>= r (- (nth 4 rel) (* tol 0.25)))
                    (and (null (cap4:arct (nth 5 rel) g eps)) (null (cap4:arct (nth 6 rel) g eps))))
              (setq ok nil)))))))
  ok)

;; 같은 토막은 하나만 — ((토막 z) …) 를 끝점(작은 쪽 먼저)으로 줄 세워 x 가 tol 안인 이웃끼리만 비교
(defun cap4:unique (cands tol / keyed p0 p1 out rest k c q)
  (foreach c cands
    (setq p0 (cap4:pt (car (car c)) 0.0) p1 (cap4:pt (last (car c)) 1.0))
    (if (or (> (car p0) (car p1)) (and (= (car p0) (car p1)) (> (cadr p0) (cadr p1)))) (setq k p0 p0 p1 p1 k))
    (setq keyed (cons (list p0 p1 (cap4:path-at (car c) 0.5) c) keyed)))
  (setq keyed (vl-sort keyed '(lambda (a b) (< (car (car a)) (car (car b))))))
  (while keyed
    (setq k (car keyed) keyed (cdr keyed) out (cons (nth 3 k) out) rest nil q keyed)
    ;; 바로 뒤 (x 가 tol 안) 에 같은 것이 있으면 뺌
    (while (and q (<= (- (car (car (car q))) (car (car k))) tol))
      (setq c (car q) q (cdr q))
      (if (not (and (<= (distance (car c) (car k)) tol) (<= (distance (cadr c) (cadr k)) tol) (<= (distance (caddr c) (caddr k)) tol)))
        (setq rest (cons c rest))))
    (setq keyed (append (reverse rest) q)))
  out)

;; 토막 하나를 벽 레이어에 — 선 · 호 · 폴리선
(defun cap4:make (path lay z / p a0 a1 g)
  (if (= (length path) 1)
    (progn
      (setq p (car path))
      (if (cap4:arc-p p)
        (progn
          (if (>= (nth 5 p) 0.0) (setq a0 (nth 4 p) a1 (+ (nth 4 p) (nth 5 p))) (setq a0 (+ (nth 4 p) (nth 5 p)) a1 (nth 4 p)))
          (entmake (list '(0 . "ARC") (cons 8 lay) (list 10 (nth 1 p) (nth 2 p) z) (cons 40 (nth 3 p))
                         (cons 50 (cap4:norm a0)) (cons 51 (cap4:norm a1)))))
        (entmake (list '(0 . "LINE") (cons 8 lay) (list 10 (nth 1 p) (nth 2 p) z) (list 11 (nth 3 p) (nth 4 p) z)))))
    (entmake (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay) '(100 . "AcDbPolyline")
                           (cons 90 (1+ (length path))) '(70 . 0) (cons 38 z))
                     (apply 'append (mapcar '(lambda (g) (list (list 10 (car (cap4:pt g 0.0)) (cadr (cap4:pt g 0.0)))
                                                               (cons 42 (if (cap4:arc-p g) (/ (sin (/ (nth 5 g) 4.0)) (cos (/ (nth 5 g) 4.0))) 0.0))))
                                            path))
                     (list (list 10 (car (cap4:pt (last path) 1.0)) (cadr (cap4:pt (last path) 1.0))) '(42 . 0.0))))))

;; ── 명령 ──
(defun c:CAP4 ( / *error* doc undo_open unit tol tmin tmax reach wl ent ed typ el lt pc ss i e ins walls aux wrecs xrecs
                  wbox k ci pcs n box active-w active-x w x xs near pairs hits cur ms m h pr
                  made cands already rel fa fb path closed conn j a b q c cnt z)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        unit (cond ((= (getvar "INSUNITS") 5) 10.0) ((= (getvar "INSUNITS") 6) 1000.0) ((= (getvar "INSUNITS") 1) 25.4) (T 1.0))
        tol (/ 1.0 unit)
        tmin (if (getenv "HyCap4TMin") (atof (getenv "HyCap4TMin")) 30.0)
        tmax (if (getenv "HyCap4TMax") (atof (getenv "HyCap4TMax")) 600.0))
  ;; 1) 벽 레이어 — 벽선 하나 클릭 (Enter = 지난 레이어, T = 두께 범위)
  (while (not wl)
    (setvar "ERRNO" 0)
    (initget "T")
    (setq ent (entsel (strcat "\n벽 레이어의 선을 클릭하세요 [두께 범위(T)]"
                              (if (getenv "HyCap4Layer") (strcat " <" (getenv "HyCap4Layer") ">") "") ": ")))
    (cond
      ((= ent "T")
       (initget 6)
       (setq tmin (cond ((getdist (strcat "\n벽 두께 최소 <" (rtos tmin 2 0) ">: "))) (tmin)))
       (initget 6)
       (setq tmax (cond ((getdist (strcat "\n벽 두께 최대 <" (rtos tmax 2 0) ">: "))) (tmax)))
       (if (<= tmax tmin) (progn (princ "\n[주의] 최대가 최소보다 커야 합니다 — 최대를 최소 + 100 으로 했습니다.") (setq tmax (+ tmin 100.0))))
       (setenv "HyCap4TMin" (rtos tmin 2 4))
       (setenv "HyCap4TMax" (rtos tmax 2 4)))
      ((and (null ent) (getenv "HyCap4Layer") (= (getvar "ERRNO") 52)) (setq wl (getenv "HyCap4Layer")))
      ((null ent) (if (= (getvar "ERRNO") 52) (exit) (princ "\n[알림] 선을 찾지 못했습니다. 다시 클릭하세요.")))
      ((listp ent) (setq wl (cdr (assoc 8 (entget (car ent))))))))
  (setenv "HyCap4Layer" wl)
  ;; 2) 영역
  (prompt (strcat "\n막을 영역을 고르세요 — 벽선(" wl ") · 기둥 · 창호 블록이 들어가게: "))
  (if (null (setq ss (ssget)))
    (princ "\n[알림] 고른 객체가 없습니다.")
    (progn
      (setq reach (max tol (* 0.1 (/ tmax unit))) tmin (/ tmin unit) tmax (/ tmax unit) i 0)
      ;; 3) 나누기: 벽 레이어 곡선(walls) · 그 밖의 곡선(aux) · 블록(ins)
      (repeat (sslength ss)
        (setq e (ssname ss i) ed (entget e) typ (cdr (assoc 0 ed)) el (cdr (assoc 8 ed)) i (1+ i))
        (cond
          ((or (= (cdr (assoc 60 ed)) 1) (not (cap4:layer-on el))))
          ((= typ "INSERT") (setq ins (cons ed ins)))
          ((member typ '("LINE" "ARC" "CIRCLE" "LWPOLYLINE" "ELLIPSE"))
           (setq lt (cap4:ltype ed el))
           (if (= (strcase el) (strcase wl))
             (if (and (/= typ "ELLIPSE") (not (cap4:skip-lt lt)) (setq pc (cap4:pieces ed)))
               (setq walls (cons (list pc (cond ((= typ "LWPOLYLINE") (cond ((cdr (assoc 38 ed))) (0.0))) (T (cadddr (assoc 10 ed))))) walls)))
             (if (and (not (cap4:skip-aux el lt)) (setq pc (cap4:pieces ed)))
               (setq aux (cons pc aux)))))))
      (if (null walls)
        (princ (strcat "\n[알림] 고른 영역에 벽 레이어(" wl ")의 선이 없습니다."))
        (progn
          ;; 벽 조각 기록: (x0 y0 x1 y1 조각 z 시작끝? 끝끝?) — 열린 곡선의 첫 조각 시작 · 마지막 조각 끝은 '벽선 끝'
          (foreach w walls
            (setq pcs (cdr (car w)) n (length pcs) k 0
                  closed (or (car (car w)) (< (distance (cap4:pt (car pcs) 0.0) (cap4:pt (last pcs) 1.0)) tol)))
            (foreach q pcs
              (setq box (cap4:box q) wrecs (cons (list (- (car box) reach) (- (cadr box) reach) (+ (caddr box) reach) (+ (cadddr box) reach)
                                                       q (cadr w) (and (not closed) (= k 0)) (and (not closed) (= k (1- n))))
                                                 wrecs)
                    k (1+ k))))
          ;; 블록 — 벽선 둘레(두께만큼 넓힌 상자)에 걸친 것만, 분해하지 않고 변환으로
          (setq wbox (list (apply 'min (mapcar 'car wrecs)) (apply 'min (mapcar 'cadr wrecs))
                           (apply 'max (mapcar 'caddr wrecs)) (apply 'max (mapcar 'cadddr wrecs))))
          (foreach ed ins
            (if (and (setq m (cap4:ins-xf ed)) (setq box (cap4:ins-box ed))
                     (<= (car box) (+ (caddr wbox) tmax)) (>= (caddr box) (- (car wbox) tmax))
                     (<= (cadr box) (+ (cadddr wbox) tmax)) (>= (cadddr box) (- (cadr wbox) tmax)))
              (setq aux (append (cap4:block (cdr (assoc 2 ed)) m (cdr (assoc 8 ed)) 0) aux))))
          ;; 벽 둘레의 aux 곡선만 → 두 끝이 다른 곡선 끝과 이어졌는지(분해한 기둥 등) → 끝과 끝이 이어진 곡선은 하나로
          ;; (호 둘로 그린 원 기둥 · 분해한 팔각 기둥 — 캡이 이음매에 걸쳐도 찾게). aux = ((닫힘 단단함 조각…) …)
          (setq aux (reverse aux) conn (cap4:connected aux tol) k (cap4:relevant aux wrecs) ci nil j nil)
          (foreach a aux
            (if (car k) (setq ci (cons a ci) j (cons (car conn) j)))
            (setq k (cdr k) conn (cdr conn)))
          (setq aux (cap4:chains (reverse ci) (reverse j) tol))
          ;; aux 조각 기록: (x0 y0 x1 y1 곡선번호 조각번호 조각)
          (setq ci 0)
          (foreach a aux
            (setq k 0)
            (foreach q (cddr a)
              (setq box (cap4:box q) xrecs (cons (list (car box) (cadr box) (caddr box) (cadddr box) ci k q) xrecs) k (1+ k)))
            (setq ci (1+ ci)))
          ;; 4) 상자가 겹치는 짝만 (x 로 줄 세워 쓸어 가며)
          (setq wrecs (vl-sort wrecs '(lambda (p q) (< (car p) (car q))))
                xrecs (vl-sort xrecs '(lambda (p q) (< (car p) (car q)))))
          (while (or wrecs xrecs)
            (if (and wrecs (or (null xrecs) (<= (car (car wrecs)) (car (car xrecs)))))
              (progn
                (setq w (car wrecs) wrecs (cdr wrecs)
                      active-x (vl-remove-if '(lambda (p) (< (caddr p) (car w))) active-x))
                (foreach x active-x (if (and (<= (cadr w) (cadddr x)) (>= (cadddr w) (cadr x))) (setq pairs (cons (list x w) pairs))))
                (setq active-w (cons w active-w)))
              (progn
                (setq x (car xrecs) xrecs (cdr xrecs)
                      active-w (vl-remove-if '(lambda (p) (< (caddr p) (car x))) active-w))
                (foreach w active-w (if (and (<= (cadr w) (cadddr x)) (>= (cadddr w) (cadr x))) (setq pairs (cons (list x w) pairs))))
                (setq active-x (cons x active-x)))))
          ;; 5) 만나는 점 (곡선번호 u 점 벽기록) · 곡선마다 둘레 벽 조각
          (foreach pr pairs
            (setq x (car pr) w (cadr pr) near (cons (cons (nth 4 x) w) near))
            (foreach h (cap4:isect (nth 6 x) (nth 4 w) tol)
              (setq hits (cons (list (nth 4 x) (+ (nth 5 x) (car h)) (caddr h) w) hits))))
          (setq hits (vl-sort hits '(lambda (p q) (if (= (car p) (car q)) (< (cadr p) (cadr q)) (< (car p) (car q)))))
                near (vl-sort near '(lambda (p q) (< (car p) (car q)))))
          ;; 6) 곡선마다: 같은 자리는 하나로 → 이웃한 두 점 사이 토막 → 규칙
          (setq cnt 0 already 0 ci 0)
          (while hits
            (setq cur (car (car hits)) xs nil)
            (while (and hits (= (car (car hits)) cur))
              (setq h (car hits) hits (cdr hits))
              (if (and xs (<= (distance (cadr (car xs)) (caddr h)) tol))
                (setq xs (cons (list (car (car xs)) (cadr (car xs)) (cons (nth 3 h) (caddr (car xs)))) (cdr xs)))
                (setq xs (cons (list (cadr h) (caddr h) (list (nth 3 h))) xs))))
            (setq xs (reverse xs))
            ;; 이 곡선 (aux 는 곡선번호 순)
            (while (< ci cur) (setq aux (cdr aux) ci (1+ ci)))
            (setq a (car aux) pcs (cddr a) closed (car a) conn (cadr a))
            ;; 이 곡선 둘레 벽 조각
            (while (and near (< (car (car near)) cur)) (setq near (cdr near)))
            (setq ms nil)
            (while (and near (= (car (car near)) cur)) (setq ms (cons (cdr (car near)) ms) near (cdr near)))
            (if (and closed (> (length xs) 1) (<= (distance (cadr (car xs)) (cadr (last xs))) tol))
              (setq xs (cons (list (car (car xs)) (cadr (car xs)) (append (caddr (car xs)) (caddr (last xs)))) (cdr (reverse (cdr (reverse xs)))))))
            (if (> (length xs) 1)
              (progn
                (setq j 0 n (length xs))
                (repeat (if closed n (1- n))
                  (setq a (nth j xs) b (nth (rem (1+ j) n) xs) j (1+ j)
                        path (cap4:subpath pcs (car a) (car b) (>= j n)) rel nil)
                  (if (and path (> (cap4:path-len path) tol))
                    (progn
                      ;; 두 끝이 서로 다른 벽면 · 평행/동심 · 두께 범위 · 띠 안
                      (foreach fa (caddr a)
                        (foreach fb (caddr b)
                          (if (and (null rel) (not (eq fa fb)) (not (equal (nth 4 fa) (nth 4 fb) 1e-12))
                                   (setq q (cap4:pair (nth 4 fa) (nth 4 fb) tmin tmax tol)) (cap4:inside q path tol))
                            (setq rel q z (nth 5 fa)))))
                      (if (and rel
                               ;; 닫힌 모양 · 두 끝이 이어진 선 · 그 자리에서 벽선이 끝남
                               (or closed conn (cap4:end-near ms (cadr a) (nth 7 rel) reach tol) (cap4:end-near ms (cadr b) (nth 7 rel) reach tol))
                               ;; 이미 벽 레이어 선이 있음
                               (or (not (and (cap4:on-wall ms (cap4:path-at path 0.5) tol) (cap4:on-wall ms (cap4:path-at path 0.25) tol)
                                             (cap4:on-wall ms (cap4:path-at path 0.75) tol)))
                                   (progn (setq already (1+ already)) nil)))
                        (setq cands (cons (list path z) cands)))))))))
          ;; 7) 같은 토막(겹쳐 그린 기둥 등)은 하나만 — 끝점으로 줄 세워 이웃끼리 비교 → 벽 레이어에 넣기
          (foreach c (cap4:unique cands tol)
            (if (not undo_open) (progn (vla-StartUndoMark doc) (setq undo_open T)))
            (cap4:make (car c) wl (cadr c))
            (setq made (cons (entlast) made) cnt (1+ cnt)))
          (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
          (if made
            (progn
              (setq ss (ssadd))
              (foreach e made (ssadd e ss))
              (sssetfirst nil ss)))
          (princ (cond
                   ((> cnt 0) (strcat "\n[완료] 벽 끝 " (itoa cnt) "곳을 기둥 · 창호 면으로 막았습니다 (골라 둠)."
                                      (if (> already 0) (strcat " 이미 막힌 곳 " (itoa already) "곳은 건너뛰었습니다.") "")))
                   ((> already 0) (strcat "\n[알림] 이미 막혀 있습니다 (" (itoa already) "곳)."))
                   (T (strcat "\n[알림] 막을 곳이 없습니다 — 벽 두께 범위(" (rtos (* tmin unit) 2 0) " ~ " (rtos (* tmax unit) 2 0)
                              ")와 벽 레이어(" wl ")를 확인하세요."))))))))
  (princ))

;; 블록 상자 (x0 y0 x1 y1) — 없으면 nil
(defun cap4:ins-box (ed / o lo hi r)
  (setq o (vlax-ename->vla-object (cdr (assoc -1 ed)))
        r (vl-catch-all-apply 'vla-GetBoundingBox (list o 'lo 'hi)))
  (if (and (not (vl-catch-all-error-p r)) lo hi)
    (progn
      (setq lo (vlax-safearray->list lo) hi (vlax-safearray->list hi))
      (list (car lo) (cadr lo) (car hi) (cadr hi)))))

;; 열린 aux 곡선마다 두 끝이 모두 다른 곡선 끝과 닿는지 (T/nil 목록, aux 순서)
(defun cap4:connected (aux tol / pts i a p q hit out j)
  (setq i 0)
  (foreach a aux
    (setq pts (cons (list (car (cap4:pt (cadr a) 0.0)) (cadr (cap4:pt (cadr a) 0.0)) i 0)
                    (cons (list (car (cap4:pt (last a) 1.0)) (cadr (cap4:pt (last a) 1.0)) i 1) pts))
          i (1+ i)))
  (setq pts (vl-sort pts '(lambda (p q) (< (car p) (car q)))))
  (setq j pts)
  (while j
    (setq p (car j) q (cdr j))
    (while (and q (<= (- (car (car q)) (car p)) tol))
      (if (and (/= (nth 2 (car q)) (nth 2 p)) (<= (distance (list (car p) (cadr p)) (list (car (car q)) (cadr (car q)))) tol))
        (setq hit (cons (+ (* 2 (nth 2 p)) (nth 3 p)) (cons (+ (* 2 (nth 2 (car q))) (nth 3 (car q))) hit))))
      (setq q (cdr q)))
    (setq j (cdr j)))
  (setq hit (vl-sort hit '<) i 0)
  (repeat (length aux)
    (while (and hit (< (car hit) (* 2 i))) (setq hit (cdr hit)))
    (setq a (and hit (= (car hit) (* 2 i))))
    (while (and hit (= (car hit) (* 2 i))) (setq hit (cdr hit)))
    (setq out (cons (and a hit (= (car hit) (1+ (* 2 i)))) out) i (1+ i)))
  (reverse out))

;; aux 곡선마다 벽 조각 상자(wrecs, 이미 넓힘)와 상자가 겹치는지 — T/nil 목록 (x 로 줄 세워 쓸어 가며)
(defun cap4:relevant (aux wrecs / boxes i a b ws hit act w out)
  (setq i 0)
  (foreach a aux
    (setq b (cap4:box (cadr a)))
    (foreach q (cddr a)
      (setq q (cap4:box q) b (list (min (car b) (car q)) (min (cadr b) (cadr q)) (max (caddr b) (caddr q)) (max (cadddr b) (cadddr q)))))
    (setq boxes (cons (append b (list i)) boxes) i (1+ i)))
  (setq boxes (vl-sort boxes '(lambda (p q) (< (car p) (car q))))
        ws (vl-sort wrecs '(lambda (p q) (< (car p) (car q)))))
  ;; 곡선 상자가 들어올 때 지금 걸친 벽 상자들과, 벽 상자가 들어올 때 지금 걸친 곡선 상자들과
  (while (or boxes ws)
    (if (and ws (or (null boxes) (<= (car (car ws)) (car (car boxes)))))
      (progn
        (setq w (car ws) ws (cdr ws) act (vl-remove-if '(lambda (p) (< (caddr p) (car w))) act))
        (foreach b act (if (and (<= (cadr w) (cadddr b)) (>= (cadddr w) (cadr b))) (setq hit (cons (nth 4 b) hit))))
        (setq out (cons w out)))
      (progn
        (setq b (car boxes) boxes (cdr boxes) out (vl-remove-if '(lambda (p) (< (caddr p) (car b))) out))
        (if (vl-some '(lambda (w) (and (<= (cadr w) (cadddr b)) (>= (cadddr w) (cadr b)))) out) (setq hit (cons (nth 4 b) hit)))
        (setq act (cons b act)))))
  (setq hit (vl-sort hit '<) i 0 out nil)
  (foreach a aux
    (while (and hit (< (car hit) i)) (setq hit (cdr hit)))
    (setq out (cons (and hit (= (car hit) i)) out) i (1+ i)))
  (reverse out))

;; 곡선 뒤집기 (조각 순서와 방향)
(defun cap4:rev (pcs)
  (reverse (mapcar '(lambda (p) (if (cap4:arc-p p)
                                  (list 'A (nth 1 p) (nth 2 p) (nth 3 p) (+ (nth 4 p) (nth 5 p)) (- (nth 5 p)))
                                  (list 'L (nth 3 p) (nth 4 p) (nth 1 p) (nth 2 p))))
                   pcs)))

;; 끝과 끝이 이어진 열린 곡선을 하나로 — 두 곡선만 만나는 점으로만 지나가고 셋 이상 만나는 점에서는 끊음, 방향이 반대면 뒤집어 붙임.
;; aux = ((닫힘 조각…) …), solid = 곡선마다 두 끝이 이어졌는지 → ((닫힘 단단함 조각…) …)
(defun cap4:chains (aux solid tol / i a pts p win hit nid ends adj grp used out cap4:walk cap4:node-of)
  (defun cap4:node-of (ci en) (caddr (car (vl-remove-if-not '(lambda (e) (and (= (car e) ci) (= (cadr e) en))) ends))))
  (defun cap4:walk (start ci en / pcs sol rev nxt l other atn closed)
    (setq sol T)
    (while ci
      (setq used (cons ci used) a (nth ci aux) rev (= en 1)
            pcs (append pcs (if rev (cap4:rev (cdr a)) (cdr a)))
            sol (and sol (nth ci solid))
            atn (if rev 0 1)
            nxt (cap4:node-of ci atn)
            l (cdr (assoc nxt adj)))
      (if (or (= nxt start) (/= (length l) 2))
        (setq ci nil)
        (progn
          (setq other (if (and (= (car (car l)) ci) (= (cdr (car l)) atn)) (cadr l) (car l)))
          (if (member (car other) used) (setq ci nil) (setq ci (car other) en (cdr other))))))
    (setq closed (< (distance (cap4:pt (car pcs) 0.0) (cap4:pt (last pcs) 1.0)) tol))
    (setq out (cons (cons closed (cons (or closed sol) pcs)) out)))
  ;; 닫힌 곡선은 그대로, 열린 곡선은 끝점
  (setq i 0)
  (foreach a aux
    (if (or (car a) (< (distance (cap4:pt (cadr a) 0.0) (cap4:pt (last a) 1.0)) tol))
      (setq out (cons (cons T (cons T (cdr a))) out))
      (setq pts (cons (list (cap4:pt (cadr a) 0.0) i 0) (cons (list (cap4:pt (last a) 1.0) i 1) pts))))
    (setq i (1+ i)))
  ;; 끝점 번호 — x 로 줄 세워 tol 안이면 같은 번호
  (setq pts (vl-sort pts '(lambda (p q) (< (car (car p)) (car (car q))))) nid 0)
  (foreach p pts
    (setq win (vl-remove-if '(lambda (w) (< (car (car w)) (- (car (car p)) tol))) win)
          hit (vl-some '(lambda (w) (if (<= (distance (car w) (car p)) tol) (cadr w))) win))
    (if (null hit) (setq hit nid nid (1+ nid) win (cons (list (car p) hit) win)))
    (setq ends (cons (list (cadr p) (caddr p) hit) ends)))
  ;; 점마다 닿는 (곡선 . 끝)
  (foreach e ends
    (if (setq grp (assoc (caddr e) adj))
      (setq adj (subst (cons (car grp) (cons (cons (car e) (cadr e)) (cdr grp))) grp adj))
      (setq adj (cons (list (caddr e) (cons (car e) (cadr e))) adj))))
  ;; 두 곡선만 만나는 점이 아닌 곳(끝 · 갈림)에서 시작, 남은 것은 고리
  (foreach grp adj
    (if (/= (length (cdr grp)) 2)
      (foreach inc (cdr grp)
        (if (not (member (car inc) used)) (cap4:walk (car grp) (car inc) (cdr inc))))))
  (foreach e ends
    (if (and (= (cadr e) 0) (not (member (car e) used))) (cap4:walk (caddr e) (car e) 0)))
  (reverse out))

;; 점 p 에서 reach(두께 × 0.1) 안에 벽선 끝이 있는지 (둘레 벽 조각 ms 중)
(defun cap4:end-near (ms p tk reach tol / r)
  (setq r (max tol (min reach (* 0.1 tk))))
  (vl-some '(lambda (w) (or (and (nth 6 w) (<= (distance p (cap4:pt (nth 4 w) 0.0)) r))
                            (and (nth 7 w) (<= (distance p (cap4:pt (nth 4 w) 1.0)) r))))
           ms))

;; 점 p 가 벽 레이어 선 위인지 (둘레 벽 조각 ms 중)
(defun cap4:on-wall (ms p tol)
  (vl-some '(lambda (w) (<= (cap4:dist (nth 4 w) p) tol)) ms))

(princ)
