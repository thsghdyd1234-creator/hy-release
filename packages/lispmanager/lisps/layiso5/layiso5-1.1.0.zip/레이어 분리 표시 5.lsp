;;; ==============================================================================
;;;  5 — 고른 객체의 레이어만 남기고 나머지 레이어 끄기 · Enter 로 되돌리기
;;;
;;;  · 여러 객체를 고르면 그 레이어들을 모두 남긴다. 얼어 있던 레이어는 녹인다.
;;;  · 블록·외부 참조를 고르면 그 안의 레이어(중첩 블록 · 'XREF|…' 레이어 포함)도 남긴다 — 안의 선이 사라지지 않게.
;;;  · 처음 격리할 때의 레이어 상태(켜기·동결 · 지금 레이어)를 도면에 적어 두고(HY_LAYISO5),
;;;    다시 5 를 실행해 Enter 를 누르면 그대로 되돌린다. 원래 꺼 두었던 레이어는 꺼진 채로 돌아온다.
;;;    격리한 채로 또 5 를 하면 처음 상태를 그대로 두고 남길 레이어만 바꾼다.
;;;  · 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 블록 정의 안의 레이어 (중첩까지). 0 레이어는 바깥 레이어를 따르므로 뺀다.
;; l5_seen 은 c:5 의 지역 변수 — 한 블록 정의는 한 번만 본다
(defun l5:block-layers (doc name / out b)
  (if (and (not (member (strcase name) l5_seen))
           (not (vl-catch-all-error-p (setq b (vl-catch-all-apply 'vla-Item (list (vla-get-Blocks doc) name))))))
    (progn
      (setq l5_seen (cons (strcase name) l5_seen))
      (vlax-for o b
        (if (/= (vla-get-Layer o) "0") (setq out (cons (vla-get-Layer o) out)))
        (if (= (vla-get-ObjectName o) "AcDbBlockReference")
          (setq out (append (l5:block-layers doc (vla-get-Name o)) out))))))
  out)

(defun l5:restore (doc st / lays cur L)
  (setq cur (car st) lays (vla-get-Layers doc))
  ;; 지금 레이어 먼저 (녹이고 켠 뒤 지정) — 다른 레이어를 얼릴 수 있게
  (if (not (vl-catch-all-error-p (setq L (vl-catch-all-apply 'vla-Item (list lays cur)))))
    (progn (vl-catch-all-apply 'vla-put-Freeze (list L :vlax-false))
           (vla-put-ActiveLayer doc L)))
  (foreach r (cadr st)
    (if (not (vl-catch-all-error-p (setq L (vl-catch-all-apply 'vla-Item (list lays (car r))))))
      (progn
        (vla-put-LayerOn L (if (= (cadr r) 1) :vlax-true :vlax-false))
        (vl-catch-all-apply 'vla-put-Freeze (list L (if (= (caddr r) 1) :vlax-true :vlax-false)))))))

(defun c:5 ( / *error* doc undo_open ss i e o keep st lays first n off l5_seen)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        lays (vla-get-Layers doc)
        st (vlax-ldata-get "HY_LAYISO5" "state"))
  (prompt (strcat "\n남길 레이어의 객체를 고르세요" (if st " <Enter = 격리 전으로 되돌리기>" "") ": "))
  (setq ss (ssget))
  (cond
    ((and (null ss) st)
     (vla-StartUndoMark doc) (setq undo_open T)
     (l5:restore doc st)
     (vlax-ldata-delete "HY_LAYISO5" "state")
     (vla-EndUndoMark doc) (setq undo_open nil)
     (princ "\n[완료] 레이어를 격리 전 상태로 되돌렸습니다."))
    ((null ss) (princ "\n고른 객체가 없습니다."))
    (T
     ;; 남길 레이어 모으기
     (setq i 0)
     (while (< i (sslength ss))
       (setq e (ssname ss i) o (vlax-ename->vla-object e) keep (cons (strcase (vla-get-Layer o)) keep))
       (if (= (vla-get-ObjectName o) "AcDbBlockReference")
         (setq keep (append (mapcar 'strcase (l5:block-layers doc (vla-get-Name o))) keep)))
       (setq i (1+ i)))
     (vla-StartUndoMark doc) (setq undo_open T)
     ;; 처음 격리할 때만 상태를 적는다 (격리 중에 또 하면 처음 상태 유지)
     (if (null st)
       (progn
         (vlax-for L lays
           (setq st (cons (list (vla-get-Name L) (if (= (vla-get-LayerOn L) :vlax-true) 1 0)
                                (if (= (vla-get-Freeze L) :vlax-true) 1 0))
                          st)))
         (vlax-ldata-put "HY_LAYISO5" "state" (list (getvar "CLAYER") st))))
     ;; 지금 레이어가 꺼질 레이어면 남길 레이어 하나로 바꾼다 (끈 레이어에 그리지 않게)
     (setq first (vla-get-Layer (vlax-ename->vla-object (ssname ss 0))) n 0 off 0)
     (vlax-for L lays
       (if (member (strcase (vla-get-Name L)) keep)
         (progn (vla-put-LayerOn L :vlax-true)
                (vl-catch-all-apply 'vla-put-Freeze (list L :vlax-false))
                (setq n (1+ n)))))
     (if (not (member (strcase (getvar "CLAYER")) keep))
       (vla-put-ActiveLayer doc (vla-Item lays first)))
     (vlax-for L lays
       (if (and (not (member (strcase (vla-get-Name L)) keep)) (= (vla-get-LayerOn L) :vlax-true))
         (progn (vla-put-LayerOn L :vlax-false) (setq off (1+ off)))))
     (vla-EndUndoMark doc) (setq undo_open nil)
     (princ (strcat "\n[완료] 레이어 " (itoa n) "개만 남기고 " (itoa off) "개를 껐습니다 (지금 레이어: " (getvar "CLAYER")
                    "). 되돌리려면 5 → Enter."))))
  (princ))

(princ)
