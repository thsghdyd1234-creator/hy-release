(defun c:5 ( / ss i en lay layList acadObj doc layers lname currentLay)
  (vl-load-com)
  (prompt "\n남겨 둘 레이어의 객체를 선택하세요 (드래그 또는 클릭): ")
  
  (if (setq ss (ssget))
    (progn
      ;; 1. 선택한 객체의 레이어 이름 모으기 (중복 제거)
      (setq layList nil)
      (repeat (setq i (sslength ss))
        (setq en (ssname ss (setq i (1- i))))
        (setq lay (cdr (assoc 8 (entget en))))
        (if (not (member lay layList))
          (setq layList (cons lay layList))
        )
      )

      ;; 2. ActiveX 객체 가져오기
      (setq acadObj (vlax-get-acad-object))
      (setq doc (vla-get-ActiveDocument acadObj))
      (setq layers (vla-get-Layers doc))

      ;; 3. 현재 레이어를 선택된 레이어 중 첫 번째 것으로 강제 변경
      ;; (현재 레이어를 끄려 할 때 캐드가 경고를 띄우지 않게)
      (setq currentLay (car layList))
      (vla-put-ActiveLayer doc (vla-Item layers currentLay))

      ;; 4. 도면의 모든 레이어를 돌며 대상은 켜고 나머지는 끔
      (vlax-for lyr layers
        (setq lname (vla-get-Name lyr))
        (if (member lname layList)
          (progn
            (vla-put-LayerOn lyr :vlax-true) ; 레이어 켜기
            (vl-catch-all-apply 'vla-put-Freeze (list lyr :vlax-false)) ; 동결(Freeze)되어 있으면 해제
          )
          (vla-put-LayerOn lyr :vlax-false) ; 선택 안 된 레이어는 끄기(OFF)
        )
      )

      (prompt (strcat "\n[완료] 총 " (itoa (length layList)) "개의 레이어만 남기고 나머지를 껐습니다. (현재 레이어: " currentLay ")"))
    )
    (prompt "\n선택된 객체가 없습니다.")
  )
  (princ)
)