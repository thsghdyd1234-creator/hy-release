;; 명령어: LCANV (밑그림 잠금)
;; 기능: 선택한 객체를 그룹화하고, 밑그림 전용 레이어로 옮긴 뒤 잠금
(defun c:LCANV ( / ss i ent edata )
  (prompt "\n밑그림으로 쓸 객체를 선택하세요: ")
  (if (setq ss (ssget))
    (progn
      ;; 1. 밑그림 전용 레이어 생성 (없으면 8번 회색으로)
      (if (not (tblsearch "LAYER" "0_CANVAS_LOCK"))
        (command "_-layer" "_m" "0_CANVAS_LOCK" "_c" "8" "0_CANVAS_LOCK" "")
      )
      
      ;; 2. 객체 이동을 위해 임시로 레이어 잠금 해제
      (command "_-layer" "_u" "0_CANVAS_LOCK" "")

      ;; 3. 선택한 객체들을 밑그림 레이어로 일괄 이동
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq edata (subst (cons 8 "0_CANVAS_LOCK") (assoc 8 edata) edata))
        (entmod edata)
        (setq i (1+ i))
      )

      ;; 4. 객체들을 하나의 익명 그룹으로 묶기
      ;; (이미 그룹인 객체가 섞여 있어도 캐드가 알아서 상위 그룹으로 묶어줌)
      (command "_-group" "_c" "*" "" ss "")

      ;; 5. 밑그림 레이어 잠금
      (command "_-layer" "_lo" "0_CANVAS_LOCK" "")

      (prompt "\n[완료] 선택한 객체를 그룹으로 묶어 밑그림 레이어에 잠갔습니다.")
    )
    (prompt "\n선택된 객체가 없습니다.")
  )
  (princ)
)

;; 명령어: UCANV (밑그림 잠금 해제)
;; 기능: 밑그림 레이어의 잠금을 해제
(defun c:UCANV ()
  (if (tblsearch "LAYER" "0_CANVAS_LOCK")
    (progn
      (command "_-layer" "_u" "0_CANVAS_LOCK" "")
      (prompt "\n[완료] 밑그림 레이어(0_CANVAS_LOCK)의 잠금을 해제했습니다.")
    )
    (prompt "\n[알림] 밑그림 레이어가 아직 없습니다.")
  )
  (princ)
)