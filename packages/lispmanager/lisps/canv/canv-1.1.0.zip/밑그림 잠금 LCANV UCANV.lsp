;;; ==============================================================================
;;;  LCANV — 밑그림 잠금 / UCANV — 밑그림 잠금 해제
;;;
;;;  LCANV: 고른 객체를 밑그림 레이어(0_CANVAS_LOCK, 회색 8)로 옮기고 색을 ByLayer 로 바꿔 회색으로,
;;;         하나의 그룹으로 묶은 뒤 레이어를 잠근다. 지금 레이어는 바꾸지 않는다.
;;;         원래 레이어·색은 객체마다 적어 둔다 (XDATA HY_CANV) — UCANV 에서 되돌릴 수 있다.
;;;  UCANV: 밑그림 레이어 잠금을 푼다. [R] 을 고르면 밑그림을 원래 레이어·색으로 되돌린다.
;;; ==============================================================================

(defun canv:layer ( / r)
  (if (not (tblsearch "LAYER" "0_CANVAS_LOCK"))
    (entmake '((0 . "LAYER") (100 . "AcDbSymbolTableRecord") (100 . "AcDbLayerTableRecord")
               (2 . "0_CANVAS_LOCK") (70 . 0) (62 . 8) (6 . "Continuous"))))
  (setq r (tblsearch "LAYER" "0_CANVAS_LOCK"))
  (and r (not (minusp (cdr (assoc 62 r)))) (= 0 (logand 1 (cdr (assoc 70 r))))))

(defun canv:lock (flag / r)
  (setq r (entget (tblobjname "LAYER" "0_CANVAS_LOCK")))
  (entmod (subst (cons 70 (if flag (logior 4 (cdr (assoc 70 r))) (logand (~ 4) (cdr (assoc 70 r)))))
                 (assoc 70 r) r)))

;; 객체 하나(와 블록 속성)를 밑그림 레이어로 — 원래 레이어·색은 XDATA 에
(defun canv:move (ent / ed lay col)
  (setq ed (entget ent '("HY_CANV"))
        lay (cdr (assoc 8 ed))
        col (cond ((cdr (assoc 62 ed))) (256)))
  (if (and (/= (strcase lay) "0_CANVAS_LOCK") (not (assoc -3 ed)))
    (entmod (list (cons -1 ent) '(8 . "0_CANVAS_LOCK") '(62 . 256)
                  (list -3 (list "HY_CANV" (cons 1000 lay) (cons 1070 col)))))
    (entmod (list (cons -1 ent) '(8 . "0_CANVAS_LOCK") '(62 . 256)))))

(defun canv:restore (ent / ed x lay col)
  (setq ed (entget ent '("HY_CANV")) x (cdr (assoc "HY_CANV" (cdr (assoc -3 ed)))))
  (if x
    (progn
      (setq lay (cdr (assoc 1000 x)) col (cdr (assoc 1070 x)))
      (if (and lay (not (tblsearch "LAYER" lay)))
        (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                       (cons 2 lay) '(70 . 0) '(62 . 7) '(6 . "Continuous"))))
      (entmod (list (cons -1 ent) (cons 8 (if lay lay "0")) (cons 62 (if col col 256)) '(-3 ("HY_CANV"))))
      T)))

(defun canv:subents (ent / e ed out)
  ;; 블록 속성(ATTRIB) 들
  (if (= (cdr (assoc 66 (entget ent))) 1)
    (progn
      (setq e (entnext ent))
      (while (and e (/= (cdr (assoc 0 (setq ed (entget e)))) "SEQEND"))
        (setq out (cons e out) e (entnext e)))))
  out)

(defun c:LCANV ( / *error* doc sv undo_open ss i ent n)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO")))
  (prompt "\n밑그림으로 쓸 객체를 고르세요 (잠긴 레이어의 객체는 빠짐): ")
  (cond
    ((null (setq ss (ssget "_:L"))) (princ "\n고른 객체가 없습니다."))
    ((not (canv:layer)) (princ "\n[주의] 0_CANVAS_LOCK 레이어가 꺼져 있거나 동결되어 있습니다. 켜고 다시 하세요."))
    (T
     (setvar "CMDECHO" 0)
     (vla-StartUndoMark doc)
     (setq undo_open T)
     (regapp "HY_CANV")
     (canv:lock nil)
     (setq i 0 n 0)
     (while (< i (sslength ss))
       (setq ent (ssname ss i))
       (if (canv:move ent) (setq n (1+ n)))
       (foreach a (canv:subents ent) (canv:move a))
       (setq i (1+ i)))
     (command "_.-GROUP" "_C" "*" "" ss "")
     (canv:lock T)
     (vla-EndUndoMark doc)
     (setq undo_open nil)
     (princ (strcat "\n[완료] " (itoa n) "개를 밑그림 레이어(0_CANVAS_LOCK)로 옮기고 그룹으로 묶어 잠갔습니다."))))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(defun c:UCANV ( / *error* doc undo_open ans ss i n e)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (not (tblsearch "LAYER" "0_CANVAS_LOCK"))
    (princ "\n[알림] 밑그림 레이어가 아직 없습니다.")
    (progn
      (initget "U R")
      (setq ans (getkword "\n[잠금 해제(U)/원래 레이어로 되돌리기(R)] <U>: "))
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (canv:lock nil)
      (if (= ans "R")
        (progn
          (setq ss (ssget "_X" '((8 . "0_CANVAS_LOCK"))) i 0 n 0)
          (while (and ss (< i (sslength ss)))
            (setq e (ssname ss i))
            (if (canv:restore e) (setq n (1+ n)))
            (foreach a (canv:subents e) (canv:restore a))
            (setq i (1+ i)))
          (princ (strcat "\n[완료] 밑그림 " (itoa n) "개를 원래 레이어·색으로 되돌렸습니다.")))
        (princ "\n[완료] 밑그림 레이어(0_CANVAS_LOCK)의 잠금을 풀었습니다."))
      (vla-EndUndoMark doc)
      (setq undo_open nil)))
  (princ))

(princ)
