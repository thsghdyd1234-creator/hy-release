(defun c:ADQ ( / main-mode grid-mode old_os old_cmd ss i ent ed pt1 pt2 dx dy
                 v-lines h-lines min-x max-x min-y max-y blk-name dim-gap1 dim-gap2 txt-gap
                 x-num y-num p_dim1 p_dim2 ins-pt txt-pt blk-rot txt-rot
                 oldLayer oldDimassoc dimLayer
                 px py tol pts-top pts-bot pts-left pts-right p1 p2 p_dim obj-gap dim-dist1 dim-dist2 ssDim)
  (vl-load-com)
  
  ;; 1. 메인 모드 선택 (1: QDIM / 2: 자동 축렬 / 3: 4면 치수)
  (initget 1 "1 2 3")
  (setq main-mode (getkword "\n작업 모드 선택 [1: QDIM / 2: 축렬 및 이중 치수 / 3: 4면 외곽 치수]: "))

  (cond
    ;; ==========================================
    ;; [모드 1] 기본: 연관 다중 치수 기입 (QDIM)
    ;; ==========================================
    ((= main-mode "1")
      (prompt "\n[모드 1: 연관 다중 치수 기입 - QDIM (초록색 DIM)]")
      
      (command "_.UNDO" "_BE") 
      
      (setq oldLayer (getvar "CLAYER") oldDimassoc (getvar "DIMASSOC"))
      (setvar "DIMASSOC" 2)
      (setq dimLayer "DIM") 
      
      (if (not (tblsearch "LAYER" dimLayer))
        (command "-layer" "m" dimLayer "c" "3" "" "")
        (progn
          (command "-layer" "c" "3" dimLayer "")
          (setvar "CLAYER" dimLayer)
        )
      )

      (prompt "\n치수를 기입할 객체(중심선 등)를 선택하세요: ")
      (if (setq ss (ssget))
        (progn
          (command "QDIM" ss "")
          (while (> (getvar "CMDACTIVE") 0)
            (command pause)
          )
        )
        (prompt "\n[알림] 객체가 선택되지 않았습니다.")
      )

      (setvar "CLAYER" oldLayer)
      (setvar "DIMASSOC" oldDimassoc)
      (command "_.UNDO" "_E") 
      (prompt "\n[완료] 연관 치수를 기입했습니다. (초록색 DIM 레이어)")
    )

    ;; ==========================================
    ;; [모드 2] 축렬: 자동 축렬 및 이중 치수 생성
    ;; ==========================================
    ((= main-mode "2")
      (prompt "\n[모드 2: 자동 축렬 및 이중 치수 생성]")
      
      (command "_.UNDO" "_BE") 

      (setq old_os (getvar "OSMODE") old_cmd (getvar "CMDECHO"))
      (setvar "OSMODE" 0) 
      (setvar "CMDECHO" 0) 
      (setvar "ATTREQ" 0) 

      (if (not (tblsearch "LAYER" "TEXT"))
        (command "_.-LAYER" "_M" "TEXT" "_C" "3" "" "")
        (command "_.-LAYER" "_S" "TEXT" "" "")
      )
      (setvar "CLAYER" "TEXT")

      (setq dim-gap1 2500 dim-gap2 1500 txt-gap 800)

      (initget 1 "1 2")
      (setq grid-mode (getkword "\n축렬 블록 형태 [1: 원형(GRID_C) / 2: 사각형(GRID_R)]: "))
      (setq blk-name (if (= grid-mode "1") "GRID_C" "GRID_R"))

      (if (not (tblsearch "BLOCK" blk-name))
        (progn
          (alert (strcat "'" blk-name "' 블록이 없습니다. 블록을 먼저 만들어주세요."))
          (setvar "OSMODE" old_os) (setvar "CMDECHO" old_cmd) (setvar "ATTREQ" 1)
          (command "_.UNDO" "_E") 
          (exit)
        )
      )

      (prompt "\n치수선을 생성할 축선(Line)들을 전부 드래그하세요:")
      (if (setq ss (ssget '((0 . "LINE"))))
        (progn
          ;; 새로 생성될 치수들을 담을 선택셋 생성
          (setq ssDim (ssadd))
          (setq v-lines nil h-lines nil min-x 1e99 max-x -1e99 min-y 1e99 max-y -1e99)
          (setq i 0)
          (while (< i (sslength ss))
            (setq ent (ssname ss i) ed (entget ent) pt1 (cdr (assoc 10 ed)) pt2 (cdr (assoc 11 ed))
                  dx (abs (- (car pt1) (car pt2))) dy (abs (- (cadr pt1) (cadr pt2))))
            (setq min-x (min min-x (car pt1) (car pt2)) max-x (max max-x (car pt1) (car pt2))
                  min-y (min min-y (cadr pt1) (cadr pt2)) max-y (max max-y (cadr pt1) (cadr pt2)))
            (if (> dy dx) 
              (setq v-lines (append v-lines (list (list (car pt1) pt1 pt2))))
              (setq h-lines (append h-lines (list (list (cadr pt1) pt1 pt2))))
            )
            (setq i (1+ i))
          )

          ;; X축렬 치수 작성
          (if v-lines
            (progn
              (setq v-lines (vl-sort v-lines '(lambda (a b) (< (car a) (car b)))) x-num 1)
              (setq i 0)
              (while (< i (1- (length v-lines)))
                (setq p_dim1 (list (car (nth i v-lines)) (+ max-y dim-gap1)))
                (command "_.DIMLINEAR" (list (car (nth i v-lines)) max-y) (list (car (nth (1+ i) v-lines)) max-y) p_dim1)
                (ssadd (entlast) ssDim) ;; 생성된 치수를 선택셋에 추가
                (setq i (1+ i))
              )
              (if (> (length v-lines) 1)
                (progn
                  (setq p_dim1 (list (car (nth 0 v-lines)) (+ max-y dim-gap1 dim-gap2)))
                  (command "_.DIMLINEAR" (list (car (nth 0 v-lines)) max-y) (list (car (last v-lines)) max-y) p_dim1)
                  (ssadd (entlast) ssDim)
                )
              )
              (foreach item v-lines
                (setq ins-pt (list (car item) (+ max-y dim-gap1 dim-gap2 1500)))
                (setq txt-pt (if (= grid-mode "2") (list (+ (car ins-pt) txt-gap) (cadr ins-pt)) ins-pt))
                (command "_.-INSERT" blk-name ins-pt 1 1 0)
                (entmake (list '(0 . "TEXT") '(8 . "TEXT") '(62 . 3) (cons 10 txt-pt) (cons 40 500)
                               (cons 1 (strcat "X" (itoa x-num))) '(72 . 1) '(73 . 2) (cons 11 txt-pt)))
                (setq x-num (1+ x-num))
              )
            )
          )

          ;; Y축렬 치수 작성
          (if h-lines
            (progn
              (setq h-lines (vl-sort h-lines '(lambda (a b) (> (car a) (car b)))) y-num 1)
              (setq i 0)
              (while (< i (1- (length h-lines)))
                (setq p_dim1 (list (- min-x dim-gap1) (car (nth i h-lines))))
                (command "_.DIMLINEAR" (list min-x (car (nth i h-lines))) (list min-x (car (nth (1+ i) h-lines))) p_dim1)
                (ssadd (entlast) ssDim)
                (setq i (1+ i))
              )
              (if (> (length h-lines) 1)
                (progn
                  (setq p_dim1 (list (- min-x (+ dim-gap1 dim-gap2)) (car (nth 0 h-lines))))
                  (command "_.DIMLINEAR" (list min-x (car (nth 0 h-lines))) (list min-x (car (last h-lines))) p_dim1)
                  (ssadd (entlast) ssDim)
                )
              )
              (foreach item h-lines
                (setq ins-pt (list (- min-x (+ dim-gap1 dim-gap2 1500)) (car item)))
                (setq blk-rot 0 txt-rot 0 txt-pt ins-pt)
                (if (= grid-mode "2")
                  (setq blk-rot 90 txt-rot (/ pi 2) txt-pt (list (car ins-pt) (+ (cadr ins-pt) txt-gap)))
                )
                (command "_.-INSERT" blk-name ins-pt 1 1 blk-rot)
                (entmake (list '(0 . "TEXT") '(8 . "TEXT") '(62 . 3) (cons 10 txt-pt) (cons 40 500)
                               (cons 1 (strcat "Y" (itoa y-num))) '(72 . 1) '(73 . 2) (cons 11 txt-pt) (cons 50 txt-rot)))
                (setq y-num (1+ y-num))
              )
            )
          )

          ;; 현재 DIMSTYLE 설정을 생성된 치수에 적용(업데이트)
          (if (> (sslength ssDim) 0)
            (command "_.DIM" "_UPDATE" ssDim "" "_EXIT")
          )

          (prompt "\n[완료] 치수선과 축렬을 생성했습니다.")
        )
        (prompt "\n선택된 선(Line)이 없습니다.")
      )
      
      (setvar "OSMODE" old_os) (setvar "CMDECHO" old_cmd) (setvar "ATTREQ" 1)
      (command "_.UNDO" "_E") 
    )

    ;; ==========================================
    ;; [모드 3] 4면 외곽 치수 자동 기입 (띄움 500)
    ;; ==========================================
    ((= main-mode "3")
      (prompt "\n[모드 3: 4면 외곽 치수 자동 기입]")
      (command "_.UNDO" "_BE") 
      
      (setq old_os (getvar "OSMODE") old_cmd (getvar "CMDECHO") oldLayer (getvar "CLAYER"))
      (setvar "OSMODE" 0) 
      (setvar "CMDECHO" 0)

      ;; DIM 레이어 생성 및 설정
      (if (not (tblsearch "LAYER" "DIM"))
        (command "_.-LAYER" "_M" "DIM" "_C" "3" "" "")
        (progn (command "_.-LAYER" "_C" "3" "DIM" "") (setvar "CLAYER" "DIM"))
      )

      ;; 간격 설정
      (setq obj-gap 500 dim-dist1 1000 dim-dist2 1000 tol 1e-4)

      (prompt "\n치수를 기입할 전체 유닛 선(Line)들을 드래그하세요:")
      (if (setq ss (ssget '((0 . "LINE"))))
        (progn
          (setq ssDim (ssadd)) ;; 생성될 치수를 담을 선택셋
          (setq min-x 1e99 max-x -1e99 min-y 1e99 max-y -1e99)
          (setq i 0)
          (while (< i (sslength ss))
            (setq ed (entget (ssname ss i)) pt1 (cdr (assoc 10 ed)) pt2 (cdr (assoc 11 ed)))
            (setq min-x (min min-x (car pt1) (car pt2)) max-x (max max-x (car pt1) (car pt2))
                  min-y (min min-y (cadr pt1) (cadr pt2)) max-y (max max-y (cadr pt1) (cadr pt2)))
            (setq i (1+ i))
          )

          (setq pts-top nil pts-bot nil pts-left nil pts-right nil)
          (setq i 0)
          (while (< i (sslength ss))
            (setq ed (entget (ssname ss i)) pt1 (cdr (assoc 10 ed)) pt2 (cdr (assoc 11 ed)))
            (foreach pt (list pt1 pt2)
              (setq px (car pt) py (cadr pt))
              (if (equal py max-y tol) (if (not (vl-member-if '(lambda (x) (equal x px tol)) pts-top)) (setq pts-top (cons px pts-top))))
              (if (equal py min-y tol) (if (not (vl-member-if '(lambda (x) (equal x px tol)) pts-bot)) (setq pts-bot (cons px pts-bot))))
              (if (equal px min-x tol) (if (not (vl-member-if '(lambda (x) (equal x py tol)) pts-left)) (setq pts-left (cons py pts-left))))
              (if (equal px max-x tol) (if (not (vl-member-if '(lambda (x) (equal x py tol)) pts-right)) (setq pts-right (cons py pts-right))))
            )
            (setq i (1+ i))
          )

          (setq pts-top (vl-sort pts-top '<) pts-bot (vl-sort pts-bot '<)
                pts-left (vl-sort pts-left '<) pts-right (vl-sort pts-right '<))

          ;; 상단 치수
          (if (> (length pts-top) 1)
            (progn
              (setq i 0)
              (while (< i (1- (length pts-top)))
                (setq p1 (list (nth i pts-top) (+ max-y obj-gap)) p2 (list (nth (1+ i) pts-top) (+ max-y obj-gap))
                      p_dim (list (car p1) (+ max-y obj-gap dim-dist1)))
                (command "_.DIMLINEAR" p1 p2 p_dim)
                (ssadd (entlast) ssDim)
                (setq i (1+ i))
              )
              (if (> (length pts-top) 2) 
                (progn
                  (command "_.DIMLINEAR" (list (car pts-top) (+ max-y obj-gap)) (list (last pts-top) (+ max-y obj-gap)) (list (car pts-top) (+ max-y obj-gap dim-dist1 dim-dist2)))
                  (ssadd (entlast) ssDim)
                )
              )
            )
          )

          ;; 하단 치수
          (if (> (length pts-bot) 1)
            (progn
              (setq i 0)
              (while (< i (1- (length pts-bot)))
                (setq p1 (list (nth i pts-bot) (- min-y obj-gap)) p2 (list (nth (1+ i) pts-bot) (- min-y obj-gap))
                      p_dim (list (car p1) (- min-y obj-gap dim-dist1)))
                (command "_.DIMLINEAR" p1 p2 p_dim)
                (ssadd (entlast) ssDim)
                (setq i (1+ i))
              )
              (if (> (length pts-bot) 2)
                (progn
                  (command "_.DIMLINEAR" (list (car pts-bot) (- min-y obj-gap)) (list (last pts-bot) (- min-y obj-gap)) (list (car pts-bot) (- min-y obj-gap dim-dist1 dim-dist2)))
                  (ssadd (entlast) ssDim)
                )
              )
            )
          )

          ;; 좌측 치수
          (if (> (length pts-left) 1)
            (progn
              (setq i 0)
              (while (< i (1- (length pts-left)))
                (setq p1 (list (- min-x obj-gap) (nth i pts-left)) p2 (list (- min-x obj-gap) (nth (1+ i) pts-left))
                      p_dim (list (- min-x obj-gap dim-dist1) (cadr p1)))
                (command "_.DIMLINEAR" p1 p2 p_dim)
                (ssadd (entlast) ssDim)
                (setq i (1+ i))
              )
              (if (> (length pts-left) 2)
                (progn
                  (command "_.DIMLINEAR" (list (- min-x obj-gap) (car pts-left)) (list (- min-x obj-gap) (last pts-left)) (list (- min-x obj-gap dim-dist1 dim-dist2) (car pts-left)))
                  (ssadd (entlast) ssDim)
                )
              )
            )
          )

          ;; 우측 치수
          (if (> (length pts-right) 1)
            (progn
              (setq i 0)
              (while (< i (1- (length pts-right)))
                (setq p1 (list (+ max-x obj-gap) (nth i pts-right)) p2 (list (+ max-x obj-gap) (nth (1+ i) pts-right))
                      p_dim (list (+ max-x obj-gap dim-dist1) (cadr p1)))
                (command "_.DIMLINEAR" p1 p2 p_dim)
                (ssadd (entlast) ssDim)
                (setq i (1+ i))
              )
              (if (> (length pts-right) 2)
                (progn
                  (command "_.DIMLINEAR" (list (+ max-x obj-gap) (car pts-right)) (list (+ max-x obj-gap) (last pts-right)) (list (+ max-x obj-gap dim-dist1 dim-dist2) (car pts-right)))
                  (ssadd (entlast) ssDim)
                )
              )
            )
          )

          ;; 현재 DIMSTYLE 설정을 생성된 치수에 적용(업데이트)
          (if (> (sslength ssDim) 0)
            (command "_.DIM" "_UPDATE" ssDim "" "_EXIT")
          )

          (prompt "\n[완료] 4면 외곽 치수선을 생성했습니다. (객체에서 500 띄움)")
        )
        (prompt "\n선택된 선이 없습니다.")
      )
      
      (setvar "CLAYER" oldLayer) (setvar "OSMODE" old_os) (setvar "CMDECHO" old_cmd)
      (command "_.UNDO" "_E") 
    )
  )
  
  (princ)
)