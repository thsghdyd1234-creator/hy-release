;;; ==============================================================================
;;;  ADQ — 축렬 치수 자동 생성
;;;
;;;  모드 1: 빠른 치수(QDIM) — DIM 레이어, 연관 치수(DIMASSOC 2)
;;;  모드 2: 축선(세로·가로 선)으로 연속 치수 + 전체 치수 + 축렬 기호(GRID_C 원 / GRID_R 사각) + 번호(X1… · Y1…)
;;;          기준 축선을 클릭하면 그 레이어의 선만 쓴다 (Enter = 레이어 상관없이). 같은 자리의 선은 하나로 본다.
;;;          기호 블록이 없으면 기본 모양으로 만든다.
;;;          가로 치수 → 세로 치수 자리를 클릭한다 — 위·아래 / 왼쪽·오른쪽 어디든 클릭한 곳이 첫째 줄, 기호는 치수 너머로 따라간다
;;;          (Enter = 위·왼쪽 기본 자리, N = 그 방향 치수 없음).
;;;  모드 3: 고른 선 전체의 바깥 네 변에 놓인 끝점으로 치수 — 면마다 그쪽에 클릭한 자리로 바로 넣는다
;;;          (놓은 면을 다시 누르면 옮김, A = 네 면 모두, U = 마지막 면 되돌리기, Enter = 끝 · 하나도 안 놓았으면 네 면 모두 기본 자리).
;;;
;;;  간격·글자 높이는 치수 글자 크기(DIMTXT × DIMSCALE)에 맞춘다 (연구실 기본 1:100 이면 예전과 같은 값).
;;;  치수는 DIM 레이어, 축렬 기호·번호는 TEXT 레이어 (없으면 초록 3 으로 만듦 — 있으면 색을 바꾸지 않음).
;;;  UCS 기준으로 가로·세로를 본다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun adq:mklayer (name color)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 color) '(6 . "Continuous")))))

;; 레이어를 지금 레이어로 (꺼짐·동결이면 켜고 녹임)
(defun adq:use-layer (name / L)
  (adq:mklayer name 3)
  (setq L (vla-Item (vla-get-Layers (vla-get-ActiveDocument (vlax-get-acad-object))) name))
  (vla-put-LayerOn L :vlax-true)
  (if (= (vla-get-Freeze L) :vlax-true) (vla-put-Freeze L :vlax-false))
  (setvar "CLAYER" name))

;; 치수 글자 크기 기준 (연구실 1:100 = 250)
(defun adq:base ( / s b)
  (setq s (getvar "DIMSCALE"))
  (if (<= s 0.0) (setq s 1.0))
  (setq b (* (getvar "DIMTXT") s))
  (if (< b 20.0) 250.0 b))

(defun adq:ucsang () (angle '(0 0 0) (trans '(1 0 0) 1 0 T)))

;; 기호 블록이 없으면 기본 모양 (원 / 사각) — base 기준
(defun adq:grid-block (name base / r tg)
  (if (not (tblsearch "BLOCK" name))
    (progn
      (setq r (* 1.6 base) tg (* 3.2 base))
      (entmake (list '(0 . "BLOCK") (cons 2 name) '(70 . 0) '(10 0.0 0.0 0.0)))
      (if (= name "GRID_C")
        (entmake (list '(0 . "CIRCLE") '(8 . "0") '(10 0.0 0.0 0.0) (cons 40 r)))
        (entmake (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(8 . "0") '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
                       (list 10 0.0 (- r)) (list 10 (* 2.0 tg) (- r)) (list 10 (* 2.0 tg) r) (list 10 0.0 r))))
      (entmake '((0 . "ENDBLK")))
      (princ (strcat "\n[알림] " name " 블록이 없어 기본 모양으로 만들었습니다.")))))

;; 선 목록 → UCS 끝점 쌍들
(defun adq:lines (ss lay / i ed out)
  (setq i 0)
  (while (< i (sslength ss))
    (setq ed (entget (ssname ss i)))
    (if (or (null lay) (= (strcase (cdr (assoc 8 ed))) (strcase lay)))
      (setq out (cons (list (trans (cdr (assoc 10 ed)) 0 1) (trans (cdr (assoc 11 ed)) 0 1)) out)))
    (setq i (1+ i)))
  out)

;; 수 목록에서 tol 안의 것은 하나로 (정렬해서)
(defun adq:uniq (lst tol / out)
  (foreach x (vl-sort lst '<)
    (if (or (null out) (> (abs (- x (car out))) tol)) (setq out (cons x out))))
  (reverse out))

(defun adq:dim (p1 p2 pd)
  (command "_.DIMLINEAR" "_non" p1 "_non" p2 "_non" pd))

;; ── 모드 3: 면마다 ──  box = (min-x min-y max-x max-y), 면 = "T" 위 · "B" 아래 · "L" 왼쪽 · "R" 오른쪽
;; 클릭한 점이 있는 면 — 상자 밖이면 가장 많이 벗어난 쪽, 안이면 가까운 변 쪽
(defun adq:side-of (p box / best s)
  (setq best (- (cadr p) (nth 3 box)) s "T")
  (if (> (- (nth 1 box) (cadr p)) best) (setq best (- (nth 1 box) (cadr p)) s "B"))
  (if (> (- (nth 0 box) (car p)) best) (setq best (- (nth 0 box) (car p)) s "L"))
  (if (> (- (car p) (nth 2 box)) best) (setq s "R"))
  s)

(defun adq:edge (s box) (cond ((= s "T") (nth 3 box)) ((= s "B") (nth 1 box)) ((= s "L") (nth 0 box)) (T (nth 2 box))))
(defun adq:out (s) (if (member s '("T" "R")) 1.0 -1.0))
(defun adq:vert (s) (member s '("L" "R")))

;; 클릭한 점 → 그 면의 첫째 줄 (변 바깥으로 mg 는 띄움)
(defun adq:line-at (s p box mg / v lim)
  (setq v (if (adq:vert s) (car p) (cadr p))
        lim (+ (adq:edge s box) (* (adq:out s) mg)))
  (if (> (adq:out s) 0) (max v lim) (min v lim)))

;; 한 면의 치수 — 자리 vals(작은 것부터), 보조선은 변에서, 첫째 줄 line 에 연속 · 바깥 d2 에 전체 → 새로 만든 객체 목록
(defun adq:side-dims (s vals line box d2 / q e0 i out)
  (setq q (adq:edge s box) e0 (entlast) i 0)
  (if (> (length vals) 1)
    (progn
      (while (< i (1- (length vals)))
        (if (adq:vert s)
          (adq:dim (list q (nth i vals)) (list q (nth (1+ i) vals)) (list line (nth i vals)))
          (adq:dim (list (nth i vals) q) (list (nth (1+ i) vals) q) (list (nth i vals) line)))
        (setq i (1+ i)))
      (if (> (length vals) 2)
        (if (adq:vert s)
          (adq:dim (list q (car vals)) (list q (last vals)) (list (+ line (* (adq:out s) d2)) (car vals)))
          (adq:dim (list (car vals) q) (list (last vals) q) (list (car vals) (+ line (* (adq:out s) d2))))))))
  (setq e0 (if e0 (entnext e0) (entnext)))
  (while e0 (setq out (cons e0 out) e0 (entnext e0)))
  out)

;; 면 s 를 줄 line 에 (이미 놓은 면이면 지우고 옮김) → 새 목록 ((면 줄 객체…) …)
(defun adq:put (s line placed sides box d2 / old)
  (if (setq old (assoc s placed))
    (progn
      (foreach e (cddr old) (if (entget e) (entdel e)))
      (setq placed (vl-remove old placed))))
  (cons (cons s (cons line (adq:side-dims s (cdr (assoc s sides)) line box d2))) placed))

;; 면 목록 → "위 · 오른쪽"
(defun adq:names (lst / out)
  (foreach sd lst
    (setq out (if out (strcat out " · ") "")
          out (strcat out (cond ((= sd "T") "위") ((= sd "B") "아래") ((= sd "L") "왼쪽") (T "오른쪽")))))
  out)

;; 축렬 번호 — 예전처럼 초록(3)으로 (출력 펜 굵기가 그대로이게)
(defun adq:text (s pt h rot)
  (entmake (list '(0 . "TEXT") '(8 . "TEXT") '(62 . 3) (cons 10 (trans pt 1 0)) (cons 40 h) (cons 1 s) (cons 50 rot)
                 '(72 . 1) '(73 . 2) (cons 11 (trans pt 1 0)))))

(defun c:ADQ ( / *error* doc space sv undo_open main-mode grid-mode ss lns lay sel base g1 g2 tg goff th
                 xs ys min-x max-x min-y max-y i n blk ins ua tol gap d1 d2 top bot left right ed p q
                 xp yp xd yd xl yl xo yo xb yb box sides placed mg dist done)

  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        space (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("OSMODE" "CMDECHO" "CLAYER" "DIMASSOC" "ATTREQ"))
        base (adq:base))

  (if (null *adq_mode*) (setq *adq_mode* "2"))
  (initget "1 2 3")
  (setq main-mode (getkword (strcat "\n작업 모드 [1: QDIM / 2: 축렬과 이중 치수 / 3: 4면 외곽 치수] <" *adq_mode* ">: ")))
  (if main-mode (setq *adq_mode* main-mode) (setq main-mode *adq_mode*))

  (cond
    ;; ---- 모드 1: QDIM ----
    ((= main-mode "1")
     (prompt "\n치수를 기입할 객체(중심선 등)를 고르세요: ")
     (if (setq ss (ssget))
       (progn
         (vla-StartUndoMark doc)
         (setq undo_open T)
         (adq:use-layer "DIM")
         (setvar "DIMASSOC" 2)
         (command "_.QDIM" ss "")
         (while (> (getvar "CMDACTIVE") 0) (command pause))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (princ "\n[완료] 연관 치수를 기입했습니다 (DIM 레이어)."))
       (princ "\n고른 객체가 없습니다.")))

    ;; ---- 모드 2: 축렬 ----
    ((= main-mode "2")
     (if (null *adq_grid*) (setq *adq_grid* "1"))
     (initget "1 2")
     (setq grid-mode (getkword (strcat "\n축렬 기호 [1: 원형(GRID_C) / 2: 사각형(GRID_R)] <" *adq_grid* ">: ")))
     (if grid-mode (setq *adq_grid* grid-mode) (setq grid-mode *adq_grid*))
     (setq blk (if (= grid-mode "1") "GRID_C" "GRID_R"))
     (setvar "ERRNO" 0)
     (while (and (null (setq sel (entsel "\n기준 축선을 클릭하세요 — 그 레이어의 선만 씀 (Enter = 레이어 상관없이): ")))
                 (= (getvar "ERRNO") 7))
       (princ "\n빗나갔습니다. 다시 클릭하세요.")
       (setvar "ERRNO" 0))
     (setq lay (if sel (cdr (assoc 8 (entget (car sel))))))
     (prompt "\n치수를 넣을 축선(LINE)을 드래그하세요: ")
     (if (and (setq ss (ssget '((0 . "LINE")))) (setq lns (adq:lines ss lay)))
       (progn
         (setq g1 (* 10.0 base) g2 (* 6.0 base) tg (* 3.2 base) goff (* 6.0 base) th (* 2.0 base)
               tol (max 0.5 (* 0.002 base))
               ua (adq:ucsang))
         (setq min-x (apply 'min (mapcar '(lambda (l) (min (car (car l)) (car (cadr l)))) lns))
               max-x (apply 'max (mapcar '(lambda (l) (max (car (car l)) (car (cadr l)))) lns))
               min-y (apply 'min (mapcar '(lambda (l) (min (cadr (car l)) (cadr (cadr l)))) lns))
               max-y (apply 'max (mapcar '(lambda (l) (max (cadr (car l)) (cadr (cadr l)))) lns)))
         ;; 세로선의 x · 가로선의 y (같은 자리는 하나로)
         (foreach l lns
           (if (> (abs (- (cadr (car l)) (cadr (cadr l)))) (abs (- (car (car l)) (car (cadr l)))))
             (setq xs (cons (car (car l)) xs))
             (setq ys (cons (cadr (car l)) ys))))
         (setq xs (adq:uniq xs tol) ys (reverse (adq:uniq ys tol)))
         ;; 치수 자리 — 클릭한 곳이 첫째 줄 (가운데보다 위면 위쪽 · 오른쪽이면 오른쪽), Enter = 위 · 왼쪽 기본 자리
         (if (> (length xs) 1)
           (progn
             (initget "None")
             (setq xp (getpoint "\n가로 치수 자리를 클릭하세요 — 위 · 아래 어디든 클릭한 곳이 첫째 줄 [없음(N)] <위>: "))))
         (if (> (length ys) 1)
           (progn
             (initget "None")
             (setq yp (getpoint "\n세로 치수 자리를 클릭하세요 — 왼쪽 · 오른쪽 어디든 클릭한 곳이 첫째 줄 [없음(N)] <왼쪽>: "))))
         (setq xd (/= xp "None") yd (/= yp "None")
               xl (if (listp xp) (if xp (cadr xp) (+ max-y g1)) (+ max-y g1))
               yl (if (listp yp) (if yp (car yp) (- min-x g1)) (- min-x g1))
               xo (if (>= xl (/ (+ min-y max-y) 2.0)) 1.0 -1.0)
               yo (if (> yl (/ (+ min-x max-x) 2.0)) 1.0 -1.0)
               ;; 기호 자리 — 치수 너머 (치수가 없으면 예전처럼 위 · 왼쪽)
               xb (if xd (+ xl (* xo (+ g2 goff))) (+ max-y g1 g2 goff))
               yb (if yd (+ yl (* yo (+ g2 goff))) (- min-x g1 g2 goff)))
         (vla-StartUndoMark doc)
         (setq undo_open T)
         (setvar "CMDECHO" 0)
         (setvar "OSMODE" 0)
         (setvar "ATTREQ" 0)
         (adq:use-layer "TEXT")
         (adq:use-layer "DIM")
         (adq:grid-block blk base)
         ;; X 축렬 (가로 치수 — 보조선은 그쪽 끝 변에서)
         (if xs
           (progn
             (setq i 0 q (if (> xo 0) max-y min-y))
             (if xd
               (progn
                 (while (< i (1- (length xs)))
                   (adq:dim (list (nth i xs) q) (list (nth (1+ i) xs) q) (list (nth i xs) xl))
                   (setq i (1+ i)))
                 (if (> (length xs) 2)
                   (adq:dim (list (car xs) q) (list (last xs) q) (list (car xs) (+ xl (* xo g2)))))))
             (setq n 1)
             (foreach x xs
               (setq ins (list x xb))
               (vla-put-Layer (vla-InsertBlock space (vlax-3d-point (trans ins 1 0)) blk 1.0 1.0 1.0 ua) "TEXT")
               (adq:text (strcat "X" (itoa n)) (if (= grid-mode "2") (list (+ (car ins) tg) (cadr ins)) ins) th ua)
               (setq n (1+ n)))))
         ;; Y 축렬 (세로 치수, 위에서부터)
         (if ys
           (progn
             (setq i 0 q (if (> yo 0) max-x min-x))
             (if yd
               (progn
                 (while (< i (1- (length ys)))
                   (adq:dim (list q (nth i ys)) (list q (nth (1+ i) ys)) (list yl (nth i ys)))
                   (setq i (1+ i)))
                 (if (> (length ys) 2)
                   (adq:dim (list q (car ys)) (list q (last ys)) (list (+ yl (* yo g2)) (car ys))))))
             (setq n 1)
             (foreach y ys
               (setq ins (list yb y))
               (vla-put-Layer (vla-InsertBlock space (vlax-3d-point (trans ins 1 0)) blk 1.0 1.0 1.0
                                               (if (= grid-mode "2") (+ ua (/ pi 2.0)) ua)) "TEXT")
               (if (= grid-mode "2")
                 (adq:text (strcat "Y" (itoa n)) (list (car ins) (+ (cadr ins) tg)) th (+ ua (/ pi 2.0)))
                 (adq:text (strcat "Y" (itoa n)) ins th ua))
               (setq n (1+ n)))))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (princ (strcat "\n[완료] 축렬 X " (itoa (length xs)) "개 · Y " (itoa (length ys)) "개와 치수를 넣었습니다.")))
       (princ "\n고른 선이 없습니다.")))

    ;; ---- 모드 3: 4면 외곽 ----
    (T
     (prompt "\n치수를 넣을 선(LINE)을 드래그하세요: ")
     (if (and (setq ss (ssget '((0 . "LINE")))) (setq lns (adq:lines ss nil)))
       (progn
         (setq tol 0.5)
         (setq min-x (apply 'min (mapcar '(lambda (l) (min (car (car l)) (car (cadr l)))) lns))
               max-x (apply 'max (mapcar '(lambda (l) (max (car (car l)) (car (cadr l)))) lns))
               min-y (apply 'min (mapcar '(lambda (l) (min (cadr (car l)) (cadr (cadr l)))) lns))
               max-y (apply 'max (mapcar '(lambda (l) (max (cadr (car l)) (cadr (cadr l)))) lns)))
         (foreach l lns
           (foreach p l
             (if (equal (cadr p) max-y tol) (setq top (cons (car p) top)))
             (if (equal (cadr p) min-y tol) (setq bot (cons (car p) bot)))
             (if (equal (car p) min-x tol) (setq left (cons (cadr p) left)))
             (if (equal (car p) max-x tol) (setq right (cons (cadr p) right)))))
         (setq top (adq:uniq top tol) bot (adq:uniq bot tol) left (adq:uniq left tol) right (adq:uniq right tol)
               box (list min-x min-y max-x max-y)
               sides (list (cons "T" top) (cons "B" bot) (cons "L" left) (cons "R" right))
               gap (* 6.0 base) d2 (* 4.0 base) mg (* 0.5 base))   ; 첫째 줄 = 변에서 6 · 전체 +4 (1:100 = 15 · 25mm)
         (vla-StartUndoMark doc)
         (setq undo_open T)
         (setvar "CMDECHO" 0)
         (setvar "OSMODE" 0)
         (adq:use-layer "DIM")
         ;; 면마다 클릭 — 바로 넣고, 놓은 면을 다시 누르면 옮김
         (while (not done)
           (initget "All Undo")
           (setq p (getpoint (if placed
                               "\n다른 면도 클릭하세요 — 놓은 면을 다시 누르면 옮김 [네 면 모두(A)/되돌리기(U)] <끝>: "
                               "\n치수를 넣을 면 쪽을 클릭하세요 — 그쪽 면에 클릭한 자리로 [네 면 모두(A)/되돌리기(U)] <네 면 모두 기본 자리>: ")))
           (cond
             ((null p)
              (if (null placed)
                (foreach sd '("T" "B" "L" "R")
                  (setq placed (adq:put sd (+ (adq:edge sd box) (* (adq:out sd) gap)) placed sides box d2))))
              (setq done T))
             ((= p "All")
              ;; 마지막에 놓은 면의 거리로 네 면 모두 (놓은 면이 없으면 기본 거리)
              (setq dist (if placed (* (- (cadr (car placed)) (adq:edge (car (car placed)) box)) (adq:out (car (car placed)))) gap))
              (foreach sd '("T" "B" "L" "R")
                (setq placed (adq:put sd (+ (adq:edge sd box) (* (adq:out sd) dist)) placed sides box d2))))
             ((= p "Undo")
              (if placed
                (progn
                  (foreach e (cddr (car placed)) (if (entget e) (entdel e)))
                  (setq placed (cdr placed)))))
             (T
              (setq q (adq:side-of p box))
              (setq placed (adq:put q (adq:line-at q p box mg) placed sides box d2)))))
         (vla-EndUndoMark doc)
         (setq undo_open nil)
         (setq placed (vl-remove-if-not '(lambda (e) (cddr e)) placed))
         (if placed
           (princ (strcat "\n[완료] 바깥 치수를 넣었습니다 ("
                          (adq:names (reverse (mapcar 'car placed))) ", DIM 레이어)."))
           (princ "\n[알림] 치수를 넣을 자리가 없습니다 — 면마다 바깥 변 위의 끝점이 둘 이상이어야 합니다.")))
       (princ "\n고른 선이 없습니다."))))

  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
