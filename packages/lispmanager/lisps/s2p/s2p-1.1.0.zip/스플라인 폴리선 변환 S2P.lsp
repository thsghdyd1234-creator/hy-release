;;; ==============================================================================
;;;  S2P — 스플라인을 폴리선으로
;;;
;;;  정밀도(1~99, 클수록 곡선에 가깝고 꼭짓점이 많음 · 기억)를 정하고 스플라인을 고르면 하나씩 SPLINEDIT 로 바꾼다.
;;;  잠긴 레이어의 스플라인은 빠진다 (예전: SPLINEDIT 가 거부해 뒤 입력이 밀림). 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun c:S2P ( / *error* doc undo_open sv prec ss i e n k)
  (defun *error* (msg)
    (foreach v sv (setvar (car v) (cdr v)))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        prec (if (getenv "HyS2PPrec") (atoi (getenv "HyS2PPrec")) 10))
  (if (or (< prec 1) (> prec 99)) (setq prec 10))
  (initget 6)
  (setq prec (cond ((getint (strcat "\n정밀도 (1~99) <" (itoa prec) ">: "))) (prec)))
  (setq prec (max 1 (min 99 prec)))
  (setenv "HyS2PPrec" (itoa prec))
  (prompt "\n폴리선으로 바꿀 스플라인을 고르세요 (잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L" '((0 . "SPLINE")))))
    (princ "\n고른 스플라인이 없습니다.")
    (progn
      (setq sv (list (cons "CMDECHO" (getvar "CMDECHO"))) i 0 n 0)
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (setvar "CMDECHO" 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (command "_.SPLINEDIT" e "_P" prec)
        (setq k 0)
        (while (and (> (getvar "CMDACTIVE") 0) (< (setq k (1+ k)) 5)) (command ""))   ; 정밀도 같은 추가 질문은 기본값으로
        (if (null (entget e)) (setq n (1+ n)))
        (setq i (1+ i)))
      (foreach v sv (setvar (car v) (cdr v)))
      (setq sv nil)
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 스플라인 " (itoa n) "개를 폴리선으로 바꿨습니다 (정밀도 " (itoa prec) ")"
                     (if (< n (sslength ss)) (strcat ", " (itoa (- (sslength ss) n)) "개는 바꾸지 못함") "") "."))))
  (princ))

(princ)
