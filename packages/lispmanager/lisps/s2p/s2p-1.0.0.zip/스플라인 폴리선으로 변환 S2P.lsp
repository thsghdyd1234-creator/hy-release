(defun c:S2P ( / ss i ent prec curr_cmdecho)
  ;; 시스템 변수 저장 및 에코 끄기 (명령창을 깔끔하게 유지)
  (setq curr_cmdecho (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)

  ;; 폴리선 변환 정밀도 설정 (기본값: 10)
  ;; 숫자가 클수록 기존 스플라인 곡선에 가깝게 변환되지만 정점(Vertex)이 많아집니다.
  ;; 작업 환경에 맞게 이 숫자를 조절해서 사용하세요.
  (setq prec 10) 

  (prompt "\n폴리선으로 변환할 스플라인들을 선택하세요: ")
  
  ;; 도면에서 SPLINE 객체만 필터링하여 선택
  (if (setq ss (ssget '((0 . "SPLINE"))))
    (progn
      (setq i 0)
      ;; 선택된 객체들을 순회하며 변환
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        
        ;; 오토캐드의 내장 명령인 SPLINEDIT를 호출하여 폴리선(P)으로 변환
        ;; 캐드 버전에 따라 프롬프트가 다를 수 있으나 일반적인 최신 버전 기준 로직
        (command "_.SPLINEDIT" ent "_P" prec)
        
        (setq i (1+ i))
      )
      (princ (strcat "\n>> 총 " (itoa (sslength ss)) "개의 스플라인이 폴리선으로 성공적으로 변환되었습니다."))
    )
    (princ "\n>> 선택된 스플라인이 없습니다.")
  )

  ;; 시스템 변수 복구
  (setvar "CMDECHO" curr_cmdecho)
  (princ)
)