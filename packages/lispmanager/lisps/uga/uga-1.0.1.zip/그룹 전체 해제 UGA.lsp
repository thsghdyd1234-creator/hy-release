(defun c:UGA ( / doc grps count )
  (vl-load-com)
  ;; 현재 열려있는 캐드 도면 객체를 가져옴
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  ;; 도면 내의 그룹 컬렉션을 가져옴
  (setq grps (vla-get-groups doc))
  (setq count 0)

  ;; 모든 그룹을 순회하며 삭제 (객체는 남기고 그룹만 삭제)
  (vlax-for grp grps
    (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-delete (list grp))))
      (setq count (1+ count))
    )
  )

  ;; 결과 출력
  (princ (strcat "\n총 " (itoa count) "개의 그룹(중첩 포함)을 해제했습니다."))
  (princ)
)