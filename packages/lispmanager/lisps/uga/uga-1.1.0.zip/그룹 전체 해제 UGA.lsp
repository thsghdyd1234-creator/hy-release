;;; ==============================================================================
;;;  UGA — 그룹 풀기 (객체는 그대로)
;;;
;;;  도면의 그룹 수(이름 없는 그룹 포함)를 보여 주고 묻는다.
;;;   예(Y) = 모두 풀기 · 고른 것만(S) = 고른 객체가 든 그룹만 풀기 · 아니오(N)
;;;  그룹 이름을 먼저 모은 뒤 푼다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 그룹 목록 → ((이름 . 그룹 객체) …)
(defun uga:groups (doc / out)
  (vlax-for g (vla-get-Groups doc) (setq out (cons (cons (vla-get-Name g) g) out)))
  (reverse out))

;; 그룹에 고른 객체가 하나라도 들었는지
(defun uga:has (g hs / hit)
  (vlax-for o g (if (member (vla-get-Handle o) hs) (setq hit T)))
  hit)

(defun c:UGA ( / *error* doc undo_open gs unnamed ans ss i hs n fail)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        gs (uga:groups doc)
        unnamed (length (vl-remove-if-not '(lambda (x) (wcmatch (car x) "`**")) gs)))
  (if (null gs)
    (princ "\n[알림] 도면에 그룹이 없습니다.")
    (progn
      (initget "Yes No Select")
      (setq ans (getkword (strcat "\n그룹 " (itoa (length gs)) "개"
                                  (if (> unnamed 0) (strcat " (이름 없는 그룹 " (itoa unnamed) "개 포함)") "")
                                  "를 풉니다. 객체는 그대로 남습니다 [예(Y)/아니오(N)/고른 것만(S)] <N>: ")))
      (cond
        ((= ans "Select")
         (prompt "\n풀 그룹의 객체를 고르세요: ")
         (if (setq ss (ssget))
           (progn
             (setq i 0)
             (while (< i (sslength ss))
               (setq hs (cons (cdr (assoc 5 (entget (ssname ss i)))) hs) i (1+ i)))
             (setq gs (vl-remove-if-not '(lambda (x) (uga:has (cdr x) hs)) gs))
             (if (null gs) (princ "\n고른 객체는 그룹에 들어 있지 않습니다.")))
           (setq gs nil)))
        ((/= ans "Yes") (setq gs nil) (princ "\n그만두었습니다.")))
      (if gs
        (progn
          (vla-StartUndoMark doc)
          (setq undo_open T n 0 fail 0)
          (foreach x gs
            (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-Delete (list (cdr x))))
              (setq fail (1+ fail))
              (setq n (1+ n))))
          (vla-EndUndoMark doc)
          (setq undo_open nil)
          (princ (strcat "\n[완료] 그룹 " (itoa n) "개를 풀었습니다"
                         (if (> fail 0) (strcat " (" (itoa fail) "개는 풀지 못함)") "") "."))))))
  (princ))

(princ)
