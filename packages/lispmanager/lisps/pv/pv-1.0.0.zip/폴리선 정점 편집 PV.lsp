;;; ============================================================
;;; PV.lsp  -  폴리선 정점 넣기 · 빼기
;;; 명령: PV
;;;
;;; 폴리선을 하나 고른 뒤 이어서 클릭한다 (객체 스냅 · 직교 · 극좌표 추적 그대로).
;;;   선 위를 클릭      → 그 자리에 정점 넣기 (호 위면 같은 호를 둘로 나눔 — 모양 그대로)
;;;   정점을 클릭       → 그 정점 빼기
;;;                       양옆이 곧은 선이면 곧게, 같은 원 위의 호면 호 하나로,
;;;                       그 밖(곡선 위의 점)이면 양옆 점과 뺀 점을 지나는 호로 잇는다 (곡선이 꺾이지 않게)
;;;   W                 → 창 안의 정점을 한꺼번에 빼기
;;;   S                 → 다른 폴리선 (다른 폴리선 위를 바로 클릭해도 그 폴리선으로 바뀜)
;;;   U                 → 마지막 고침 되돌리기
;;;   Enter · Esc       → 끝 (명령 전체가 실행 취소 한 번)
;;; 정점은 화면에 작은 네모로 보인다. 폭이 있는 폴리선은 폭을 나눠 이어 준다.
;;; 대상: LW 폴리선 (PJ 결과 포함). 2D 헤비 폴리선 · 3D 폴리선은 고르지 않음 (CONVERTPOLY 로 바꾼 뒤).
;;; ============================================================

(vl-load-com)

;;; ---------- 정점 목록 ----------
;;; 정점 레코드: (점2D 시작폭 끝폭 볼록)  — 점은 객체 좌표계(OCS)
(defun pv:split (d / head verts tail cur in done)
  ;; d → (머리 정점들 꼬리)
  (foreach x d
    (cond
      (done (setq tail (cons x tail)))
      ((= (car x) 10)
       (if cur (setq verts (cons cur verts)))
       (setq cur (list (list (cadr x) (caddr x)) 0.0 0.0 0.0) in T))
      ((and in (= (car x) 40)) (setq cur (list (car cur) (cdr x) (caddr cur) (cadddr cur))))
      ((and in (= (car x) 41)) (setq cur (list (car cur) (cadr cur) (cdr x) (cadddr cur))))
      ((and in (= (car x) 42)) (setq cur (list (car cur) (cadr cur) (caddr cur) (cdr x))))
      ((and in (= (car x) 91)))
      (in (setq done T tail (cons x tail)))
      (T (setq head (cons x head)))))
  (if cur (setq verts (cons cur verts)))
  (list (reverse head) (reverse verts) (reverse tail)))

(defun pv:build (parts verts / head out)
  (setq head (mapcar '(lambda (x) (if (= (car x) 90) (cons 90 (length verts)) x)) (car parts)))
  (foreach v verts
    (setq out (append out (list (cons 10 (car v)) (cons 40 (cadr v)) (cons 41 (caddr v)) (cons 42 (cadddr v)) (cons 91 0)))))
  (append head out (caddr parts)))

(defun pv:closed-p (d) (= 1 (logand 1 (cdr (assoc 70 d)))))

(defun pv:nth-set (l i x / k)
  (setq k -1)
  (mapcar '(lambda (y) (if (= (setq k (1+ k)) i) x y)) l))

(defun pv:remove-at (l i / k)
  (setq k -1)
  (vl-remove-if '(lambda (y) (= (setq k (1+ k)) i)) l))

(defun pv:insert-after (l i x / k out)
  (setq k -1)
  (foreach y l
    (setq out (cons y out))
    (if (= (setq k (1+ k)) i) (setq out (cons x out))))
  (reverse out))

;;; ---------- 기하 (2D) ----------
(defun pv:sub (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun pv:add (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))
(defun pv:mul (a s) (list (* (car a) s) (* (cadr a) s)))
(defun pv:dot (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun pv:crs (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
(defun pv:len (a) (sqrt (pv:dot a a)))
(defun pv:dist (a b) (pv:len (pv:sub a b)))
(defun pv:ang (a) (atan (cadr a) (car a)))
(defun pv:polar (c a r) (list (+ (car c) (* r (cos a))) (+ (cadr c) (* r (sin a)))))

(defun pv:tan (x) (/ (sin x) (cos x)))

;;; 볼록 b 인 p1 → p2 호: (중심 반지름 시작각 쓸어가는각)
(defun pv:arc (p1 p2 b / ch l c th)
  (setq ch (pv:sub p2 p1) l (pv:len ch) th (* 4.0 (atan b)))
  (setq c (pv:add (pv:mul (pv:add p1 p2) 0.5)
                  (pv:mul (list (- (cadr ch)) (car ch)) (/ (* 0.5 (- 1.0 (* b b))) (* 2.0 b)))))
  (list c (pv:dist c p1) (pv:ang (pv:sub p1 c)) th))

;;; 각도를 0 ~ 2π 로
(defun pv:norm (a)
  (while (< a 0.0) (setq a (+ a (* 2.0 pi))))
  (while (>= a (* 2.0 pi)) (setq a (- a (* 2.0 pi))))
  a)

;;; 점 q 를 마디 (p1 p2 b) 에 붙인 자리: (점 마디안비율t 거리)
;;; 호면 t 는 쓸어 간 각의 비율 (나눌 때 볼록을 나누는 데 씀)
(defun pv:proj (p1 p2 b q / ab l2 t1 pt arc c r a0 th s d0 d1)
  (if (< (abs b) 1e-12)
    (progn
      (setq ab (pv:sub p2 p1) l2 (pv:dot ab ab))
      (setq t1 (if (< l2 1e-24) 0.0 (max 0.0 (min 1.0 (/ (pv:dot (pv:sub q p1) ab) l2)))))
      (setq pt (pv:add p1 (pv:mul ab t1)))
      (list pt t1 (pv:dist pt q)))
    (progn
      (setq arc (pv:arc p1 p2 b) c (car arc) r (cadr arc) a0 (caddr arc) th (cadddr arc))
      ;; 시작각에서 쓸어 가는 쪽으로 잰 각
      (setq s (if (> th 0.0)
                (pv:norm (- (pv:ang (pv:sub q c)) a0))
                (pv:norm (- a0 (pv:ang (pv:sub q c))))))
      (if (> s (abs th))
        ;; 호 밖 — 가까운 끝
        (progn
          (setq d0 (pv:dist q p1) d1 (pv:dist q p2))
          (if (< d0 d1) (list p1 0.0 d0) (list p2 1.0 d1)))
        (progn
          (setq pt (pv:polar c (if (> th 0.0) (+ a0 s) (- a0 s)) r))
          (list pt (/ s (abs th)) (pv:dist pt q)))))))

;;; 마디 i (verts 의 i → i+1, 닫혔으면 끝 → 처음)
(defun pv:seg-count (verts closed) (if closed (length verts) (1- (length verts))))
(defun pv:seg-pts (verts i) (list (car (nth i verts)) (car (nth (rem (1+ i) (length verts)) verts)) (cadddr (nth i verts))))

;;; 두 마디(p1 → p2 볼록 b1, p2 → p3 볼록 b2)를 하나로 이을 때의 볼록
(defun pv:join-bulge (p1 p2 p3 b1 b2 / a1 a2 th cr phi)
  (cond
    ((and (< (abs b1) 1e-12) (< (abs b2) 1e-12)) 0.0)
    ;; 같은 원 위의 호 둘 → 호 하나
    ((and (> (abs b1) 1e-12) (> (abs b2) 1e-12)
          (setq a1 (pv:arc p1 p2 b1) a2 (pv:arc p2 p3 b2))
          (< (pv:dist (car a1) (car a2)) (* 1e-6 (max 1.0 (cadr a1))))
          (equal (cadr a1) (cadr a2) (* 1e-6 (max 1.0 (cadr a1))))
          (< (abs (setq th (+ (cadddr a1) (cadddr a2)))) (- (* 2.0 pi) 1e-6)))
     (pv:tan (/ th 4.0)))
    ;; 그 밖 → 세 점을 지나는 호 (뺀 점 p2 를 지남)
    (T
     (setq cr (pv:crs (pv:sub p3 p1) (pv:sub p2 p1)))
     (if (< (abs cr) (* 1e-9 (max 1.0 (* (pv:dist p1 p3) (pv:dist p1 p3)))))
       0.0
       (progn
         ;; p2 에서 잰 끼인각 φ → 쓸어 가는 각 2(π − φ), p2 가 줄의 오른쪽이면 반시계(+)
         (setq phi (abs (- (pv:ang (pv:sub p1 p2)) (pv:ang (pv:sub p3 p2)))))
         (if (> phi pi) (setq phi (- (* 2.0 pi) phi)))
         (setq th (* 2.0 (- pi phi)))
         (if (< cr 0.0) (pv:tan (/ th 4.0)) (- (pv:tan (/ th 4.0)))))))))

;;; ---------- 고치기 ----------
;;; 마디 i 의 비율 t 자리 pt 에 정점 넣기 → 새 정점 목록
(defun pv:add-vertex (verts i pt t1 / v b th sw ew wm b1 b2)
  (setq v (nth i verts) b (cadddr v) sw (cadr v) ew (caddr v))
  (setq wm (+ sw (* t1 (- ew sw))))
  (if (< (abs b) 1e-12)
    (setq b1 0.0 b2 0.0)
    (setq th (* 4.0 (atan b)) b1 (pv:tan (/ (* th t1) 4.0)) b2 (pv:tan (/ (* th (- 1.0 t1)) 4.0))))
  (pv:insert-after (pv:nth-set verts i (list (car v) sw wm b1)) i (list pt wm ew b2)))

;;; 정점 k 빼기 → 새 정점 목록 (못 빼면 nil)
(defun pv:remove-vertex (verts k closed / n j m vj vk vm nb)
  (setq n (length verts))
  (cond
    ((< n (if closed 4 3)) nil)
    ((and (not closed) (= k 0)) (cdr verts))
    ((and (not closed) (= k (1- n)))
     (setq verts (pv:remove-at verts k))
     ;; 새 끝 정점의 볼록은 쓰이지 않으니 0
     (setq vj (last verts))
     (pv:nth-set verts (1- (length verts)) (list (car vj) (cadr vj) (caddr vj) 0.0)))
    (T
     (setq j (if (= k 0) (1- n) (1- k)) m (rem (1+ k) n))
     (setq vj (nth j verts) vk (nth k verts) vm (nth m verts))
     (setq nb (pv:join-bulge (car vj) (car vk) (car vm) (cadddr vj) (cadddr vk)))
     (pv:remove-at (pv:nth-set verts j (list (car vj) (cadr vj) (caddr vk) nb)) k))))

;;; ---------- 화면 ----------
(defun pv:pix () (/ (getvar "VIEWSIZE") (cadr (getvar "SCREENSIZE"))))
(defun pv:near () (* (pv:pix) (max 5.0 (cond ((getvar "PICKBOX")) (0)))))   ; 클릭이 정점 · 선에 붙는 거리

(defun pv:show (e / d parts s p q)
  (redraw)
  (if (and e (entget e))
    (progn
      (redraw e 3)
      (setq d (entget e) parts (pv:split d) s (* 4.0 (pv:pix)))
      (foreach v (cadr parts)
        (setq p (trans (list (car (car v)) (cadr (car v)) (pv:g 38 d 0.0)) e 1))
        (setq q (list (list (- (car p) s) (- (cadr p) s)) (list (+ (car p) s) (- (cadr p) s))
                      (list (+ (car p) s) (+ (cadr p) s)) (list (- (car p) s) (+ (cadr p) s))))
        (grdraw (nth 0 q) (nth 1 q) 2)
        (grdraw (nth 1 q) (nth 2 q) 2)
        (grdraw (nth 2 q) (nth 3 q) 2)
        (grdraw (nth 3 q) (nth 0 q) 2)))))

(defun pv:g (k d df) (if (assoc k d) (cdr (assoc k d)) df))

(defun pv:locked-p (e / l)
  (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e)))))
  (and l (= 4 (logand 4 (cdr (assoc 70 l))))))

(defun pv:ok (e / d)
  (and e (setq d (entget e)) (= "LWPOLYLINE" (cdr (assoc 0 d)))))

;;; 폴리선 고르기 (말 없음 = nil)
(defun pv:pick (/ r e)
  (while (progn
           (setq r (entsel "\n정점을 고칠 폴리선을 고르세요: "))
           (cond
             ((null r) (setq e nil) nil)
             ((not (pv:ok (setq e (car r))))
              (princ "\n[주의] LW 폴리선이 아닙니다 (2D · 3D 폴리선은 CONVERTPOLY 로 바꾼 뒤 고르세요).") T)
             ((pv:locked-p e) (princ "\n[주의] 잠긴 레이어의 폴리선입니다.") T)
             (T nil))))
  e)

;;; 점 p (UCS) 근처의 다른 LW 폴리선
(defun pv:other-at (p cur / ss i e hit)
  (if (setq ss (ssget "_C" (pv:sub (list (car p) (cadr p)) (list (pv:near) (pv:near)))
                           (pv:add (list (car p) (cadr p)) (list (pv:near) (pv:near)))
                      '((0 . "LWPOLYLINE"))))
    (progn
      (setq i 0)
      (while (and (null hit) (< i (sslength ss)))
        (setq e (ssname ss i) i (1+ i))
        (if (and (not (eq e cur)) (not (pv:locked-p e))) (setq hit e)))))
  hit)

;;; ---------- 명령 ----------
(defun c:PV (/ *error* doc undo_open e d parts verts closed p q near bi bd seg pr i n k sv hist
               nadd nrem c1 c2 ins lo hi nv)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (defun *error* (msg)
    (redraw)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))

  (setq nadd 0 nrem 0)
  ;; 미리 고른 폴리선 하나면 그것
  (if (and (setq sv (cadr (ssgetfirst))) (= 1 (sslength sv)) (pv:ok (ssname sv 0)) (not (pv:locked-p (ssname sv 0))))
    (progn (setq e (ssname sv 0)) (sssetfirst nil nil))
    (setq e (pv:pick)))
  (if e
    (progn
      (vla-StartUndoMark doc)
      (setq undo_open T)
      (while e
        (pv:show e)
        (setq d (entget e) parts (pv:split d) verts (cadr parts) closed (pv:closed-p d))
        (initget "W S U")
        (setq p (getpoint (strcat "\n선 위 = 정점 넣기 · 정점 = 빼기 (정점 " (itoa (length verts))
                                  "개) [창으로 빼기(W)/다른 폴리선(S)/되돌리기(U)] <끝>: ")))
        (cond
          ((null p) (setq e nil))
          ((= p "S") (redraw) (if (setq q (pv:pick)) (setq e q hist nil)))
          ((= p "U")
           (if hist
             (progn (entmod (car hist)) (entupd e) (setq hist (cdr hist)) (princ "\n한 번 되돌렸습니다."))
             (princ "\n되돌릴 것이 없습니다.")))
          ((= p "W")
           (if (and (setq c1 (getpoint "\n창의 첫 구석: ")) (setq c2 (getcorner c1 "\n맞은편 구석: ")))
             (progn
               (setq lo (list (min (car c1) (car c2)) (min (cadr c1) (cadr c2)))
                     hi (list (max (car c1) (car c2)) (max (cadr c1) (cadr c2))))
               ;; 창 안 정점을 뒤에서부터 하나씩 (앞 번호가 안 밀리게)
               (setq k (1- (length verts)) n 0 nv verts)
               (while (>= k 0)
                 (setq q (trans (list (car (car (nth k nv))) (cadr (car (nth k nv))) (pv:g 38 d 0.0)) e 1))
                 (if (and (<= (car lo) (car q) (car hi)) (<= (cadr lo) (cadr q) (cadr hi))
                          (setq ins (pv:remove-vertex nv k closed)))
                   (setq nv ins n (1+ n)))
                 (setq k (1- k)))
               (if (> n 0)
                 (progn
                   (setq hist (cons d hist))
                   (entmod (pv:build parts nv)) (entupd e)
                   (setq nrem (+ nrem n))
                   (princ (strcat "\n정점 " (itoa n) "개를 뺐습니다.")))
                 (princ "\n창 안에 뺄 수 있는 정점이 없습니다 (열린 선은 2개, 닫힌 선은 3개는 남겨요).")))))
          (T
           ;; 클릭한 점 → 객체 좌표계
           (setq q (trans p 1 e) q (list (car q) (cadr q)) near (pv:near))
           ;; 가장 가까운 정점
           (setq i 0 bi nil bd nil)
           (foreach v verts
             (if (or (null bd) (< (pv:dist (car v) q) bd)) (setq bd (pv:dist (car v) q) bi i))
             (setq i (1+ i)))
           ;; 가장 가까운 마디
           (setq i 0 seg nil)
           (repeat (pv:seg-count verts closed)
             (setq pr (apply 'pv:proj (append (pv:seg-pts verts i) (list q))))
             (if (or (null seg) (< (caddr pr) (caddr (cdr seg)))) (setq seg (cons i pr)))
             (setq i (1+ i)))
           (cond
             ((and bd (<= bd near))
              (if (setq nv (pv:remove-vertex verts bi closed))
                (progn
                  (setq hist (cons d hist))
                  (entmod (pv:build parts nv)) (entupd e)
                  (setq nrem (1+ nrem)))
                (princ "\n[주의] 더 뺄 수 없습니다 (열린 선은 정점 2개, 닫힌 선은 3개는 남겨요).")))
             ((and seg (<= (caddr (cdr seg)) near))
              (setq hist (cons d hist))
              (entmod (pv:build parts (pv:add-vertex verts (car seg) (cadr seg) (caddr seg))))
              (entupd e)
              (setq nadd (1+ nadd)))
             ((setq q (pv:other-at p e))
              (setq e q hist nil)
              (princ "\n다른 폴리선으로 바꿨습니다."))
             (T (princ "\n폴리선 위가 아닙니다 — 선 위나 정점을 클릭하세요."))))))
      (redraw)
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 정점 " (itoa nadd) "개를 넣고 " (itoa nrem) "개를 뺐습니다."))))
  (princ))

(princ)
