;;; ==============================================================================
;;;  SDFIX — 끊긴 끝점 찾아 맞추기 (선·폴리선 묶음 단위)
;;;
;;;  검사 반경(기본 10)과 잔선 길이(기본 0.1)를 정하고(기억) 영역을 고르면, 끝점끼리 붙은 선·폴리선을 '묶음'으로 나눈 뒤
;;;  다른 묶음까지 반경 안으로 떨어진 끝점(틈)과 아주 짧은 잔선을 찾아 하나씩 확대해 묻는다.
;;;   · 틈: [이동(M) = 묶음 전체를 옮겨 붙임 / 늘리기(F) = 그 선 끝만 늘림 / 다음(N) / 종료(X)]
;;;     기본(Enter·Space)은 선만 있는 묶음이면 늘리기, 폴리선이 든 묶음이면 이동 — 옮길 묶음은 미리 강조하고 개수를 보여 준다.
;;;     묶음이 50개를 넘으면 기본은 늘리기 (건물 외곽 전체가 몇 mm 움직이지 않게).
;;;   · 잔선: [삭제(E) / 다음(N) / 종료(X)]
;;;   · 닿았는지 볼 상대는 호·원·타원·스플라인까지 (예전: 선·폴리선만 — 기둥 원에 닿은 끝도 틈으로 봄). 잠긴 레이어는 고치지 않는다.
;;;   · 칸(격자)으로 가까운 것만 재므로 큰 도면도 빠르다. UCS 를 돌려 둔 화면에서도 맞다. 고칠 때마다 실행 취소 한 번(U).
;;;   · 다 보거나 종료하면 처음 화면으로.
;;; ==============================================================================

(defun sd:d2 (a b) (distance (list (car a) (cadr a)) (list (car b) (cadr b))))
(defun sd:floor (x / n) (setq n (fix x)) (if (and (< x 0) (/= x n)) (1- n) n))
(defun sd:istr (i) (if (< i 0) (strcat "M" (itoa (- i))) (itoa i)))
(defun sd:key (pre ix iy) (read (strcat pre (sd:istr ix) "_" (sd:istr iy))))

;; 기호 칸에 넣기 (sd_syms 는 c:SDFIX 의 지역 변수 — 끝나면 비움)
(defun sd:put (s item / v)
  (setq v (vl-symbol-value s))
  (if (not (member item v)) (progn (if (null v) (setq sd_syms (cons s sd_syms))) (set s (cons item v)))))

;; 점 p 에서 선분 a-b 까지
(defun sd:segd (p a b / dx dy l2 u)
  (setq dx (- (car b) (car a)) dy (- (cadr b) (cadr a)) l2 (+ (* dx dx) (* dy dy)))
  (setq u (if (> l2 1e-24) (max 0.0 (min 1.0 (/ (+ (* (- (car p) (car a)) dx) (* (- (cadr p) (cadr a)) dy)) l2))) 0.0))
  (sd:d2 p (list (+ (car a) (* u dx)) (+ (cadr a) (* u dy)))))

;; 곡선 → 평면 선분 (곡선은 잘게)
(defun sd:segs (e step / o typ pts n i j k b len out)
  (setq o (vlax-ename->vla-object e) typ (cdr (assoc 0 (entget e))))
  (cond
    ((= typ "LINE") (setq pts (list (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o))))
    ((= typ "LWPOLYLINE")
     (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
     (while (< i n)
       (setq b (vla-GetBulge o i) k (if (equal b 0.0 1e-12) 1 16) j 0)
       (while (< j k) (setq pts (cons (vlax-curve-getPointAtParam o (+ i (/ (float j) k))) pts) j (1+ j)))
       (setq i (1+ i)))
     (setq pts (reverse (cons (vlax-curve-getEndPoint o) pts))))
    (T
     (setq len (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)) k (max 8 (min 256 (fix (/ len (max step 1e-6))))) i 0)
     (repeat (1+ k) (setq pts (cons (vlax-curve-getPointAtDist o (* len (/ (float i) k))) pts) i (1+ i)))
     (setq pts (reverse pts))))
  (while (cdr pts)
    (if (and (car pts) (cadr pts)) (setq out (cons (list (car pts) (cadr pts)) out)))
    (setq pts (cdr pts)))
  out)

;; 선분을 지나는 칸마다 (ename a b) 를 넣음 — 칸 크기 c
(defun sd:reg (sg e c / x0 y0 x1 y1 ix iy)
  (setq x0 (sd:floor (/ (min (car (car sg)) (car (cadr sg))) c)) x1 (sd:floor (/ (max (car (car sg)) (car (cadr sg))) c))
        y0 (sd:floor (/ (min (cadr (car sg)) (cadr (cadr sg))) c)) y1 (sd:floor (/ (max (cadr (car sg)) (cadr (cadr sg))) c)))
  (if (> (* (1+ (- x1 x0)) (1+ (- y1 y0))) 4096)
    (sd:put (sd:key "SD_G" 999999 999999) (list e (car sg) (cadr sg)))    ; 아주 긴 선분은 따로
    (progn
      (setq ix x0)
      (while (<= ix x1)
        (setq iy y0)
        (while (<= iy y1) (sd:put (sd:key "SD_G" ix iy) (list e (car sg) (cadr sg))) (setq iy (1+ iy)))
        (setq ix (1+ ix))))))

;; 점 p 에서 가장 가까운 상대 (묶음 grp 의 것은 빼고) → (거리 . ename)
(defun sd:near (p grp c / ix iy best who d)
  (setq ix (sd:floor (/ (car p) c)) iy (sd:floor (/ (cadr p) c)) best 1e300)
  (foreach it (append (vl-symbol-value (sd:key "SD_G" 999999 999999))
                      (apply 'append (mapcar '(lambda (dd) (vl-symbol-value (sd:key "SD_G" (+ ix (car dd)) (+ iy (cadr dd)))))
                                             '((-1 -1) (-1 0) (-1 1) (0 -1) (0 0) (0 1) (1 -1) (1 0) (1 1)))))
    (if (and (not (member (car it) grp)) (< (setq d (sd:segd p (cadr it) (caddr it))) best))
      (setq best d who (car it))))
  (cons best who))

;; 선 · 폴리선의 끝점·꼭짓점 (월드)
(defun sd:verts (e / o n i out)
  (setq o (vlax-ename->vla-object e))
  (if (= (cdr (assoc 0 (entget e))) "LINE")
    (list (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o))
    (progn (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
           (while (<= i n) (setq out (cons (vlax-curve-getPointAtParam o i) out) i (1+ i)))
           (reverse out))))

(defun sd:locked-p (e / l)
  (setq l (tblsearch "LAYER" (cdr (assoc 8 (entget e)))))
  (and l (= 4 (logand 4 (cdr (assoc 70 l))))))

(defun sd:len (e / o) (setq o (vlax-ename->vla-object e)) (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)))

(defun c:SDFIX ( / *error* doc undo_open sd_syms tol stub ss i e typ ents seg c groups gmap seen q cur grp anchored errs
                   p r prio kw ctr size zh err ent pt tgt live g gs n fixed done)
  (defun *error* (msg)
    (foreach s sd_syms (set s nil))
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (redraw)
    (if ctr (command-s "_.ZOOM" "_C" "_non" ctr size))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        tol (if (getenv "HySdfixTol") (atof (getenv "HySdfixTol")) 10.0)
        stub (if (getenv "HySdfixStub") (atof (getenv "HySdfixStub")) 0.1))
  (initget 6)
  (setq tol (cond ((getdist (strcat "\n검사 반경 (이보다 가까이 떨어진 끝을 찾음) <" (rtos tol 2 3) ">: "))) (tol)))
  (initget 4)
  (setq stub (cond ((getdist (strcat "\n잔선 길이 (이보다 짧으면 잔선) <" (rtos stub 2 3) ">: "))) (stub)))
  (setenv "HySdfixTol" (rtos tol 2 8))
  (setenv "HySdfixStub" (rtos stub 2 8))
  (prompt "\n검사할 영역을 고르세요: ")
  (if (null (setq ss (ssget '((0 . "LINE,LWPOLYLINE,ARC,CIRCLE,ELLIPSE,SPLINE,POLYLINE")))))
    (princ "\n고른 객체가 없습니다.")
    (progn
      ;; 1. 모든 곡선을 칸에 넣음 (닿음 판정 상대)
      (setq c (max (* 2.0 tol) 1e-3) i 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i) typ (cdr (assoc 0 (entget e))))
        (foreach sg (sd:segs e tol) (sd:reg sg e c))
        (if (member typ '("LINE" "LWPOLYLINE")) (setq ents (cons e ents)))
        (setq i (1+ i)))
      ;; 2. 끝점이 0.01 안에서 맞닿은 선·폴리선 = 묶음 (점 칸으로)
      (foreach e ents
        (foreach v (sd:verts e) (sd:put (sd:key "SD_P" (sd:floor (/ (car v) 0.01)) (sd:floor (/ (cadr v) 0.01))) e)))
      (foreach e ents
        (if (not (member e seen))
          (progn
            (setq grp (list e) q (list e) seen (cons e seen))
            (while q
              (setq cur (car q) q (cdr q))
              (foreach v (sd:verts cur)
                (foreach dd '((-1 -1) (-1 0) (-1 1) (0 -1) (0 0) (0 1) (1 -1) (1 0) (1 1))
                  (foreach o (vl-symbol-value (sd:key "SD_P" (+ (sd:floor (/ (car v) 0.01)) (car dd)) (+ (sd:floor (/ (cadr v) 0.01)) (cadr dd))))
                    (if (and (not (member o seen)) (vl-some '(lambda (w) (< (sd:d2 v w) 0.01)) (sd:verts o)))
                      (setq seen (cons o seen) grp (cons o grp) q (cons o q)))))))
            (setq groups (cons grp groups))
            (foreach o grp (setq gmap (cons (cons o grp) gmap))))))
      ;; 3. 오류 찾기
      (foreach grp groups
        ;; 다른 것에 닿아 있는 묶음의 폴리선은 검사하지 않음 (예전 규칙)
        (setq anchored (vl-some '(lambda (o) (vl-some '(lambda (v) (< (car (sd:near v grp c)) 0.01)) (sd:verts o))) grp))
        (setq prio (if (vl-some '(lambda (o) (= (cdr (assoc 0 (entget o))) "LWPOLYLINE")) grp) 1 2))
        (foreach o grp
          (cond
            ((sd:locked-p o))
            ((< (sd:len o) stub) (setq errs (cons (list 0 o (vlax-curve-getStartPoint o) nil grp) errs)))
            ((and anchored (= (cdr (assoc 0 (entget o))) "LWPOLYLINE")))
            (T
             (foreach v (sd:verts o)
               ;; 같은 묶음의 다른 선 끝과 붙은 끝(모서리)은 열린 끝이 아님
               (if (not (vl-some '(lambda (w) (and (not (eq w o)) (vl-some '(lambda (x) (< (sd:d2 v x) 0.01)) (sd:verts w)))) grp))
                 (progn
                   (setq r (sd:near v grp c))
                   (if (and (>= (car r) 0.01) (< (car r) tol))
                     (setq errs (cons (list prio o v (cdr r) grp) errs))))))))))
      (foreach s sd_syms (set s nil))
      (setq sd_syms nil)
      ;; 우선순위 → 자리(왼쪽 아래부터) 순으로
      (setq errs (vl-sort errs '(lambda (a b) (if (/= (car a) (car b)) (< (car a) (car b))
                                                 (if (/= (car (caddr a)) (car (caddr b))) (< (car (caddr a)) (car (caddr b)))
                                                     (< (cadr (caddr a)) (cadr (caddr b))))))))
      (if (null errs)
        (princ "\n[완료] 끊긴 끝점·잔선이 없습니다.")
        (progn
          (setq ctr (getvar "VIEWCTR") size (getvar "VIEWSIZE") zh (* 15.0 tol) n 0)
          (princ (strcat "\n[알림] 끊긴 끝점·잔선 " (itoa (length errs)) "곳을 찾았습니다."))
          (while (and errs (not done))
            (setq err (car errs) errs (cdr errs) ent (nth 1 err) pt (nth 2 err) tgt (nth 3 err) grp (nth 4 err))
            (cond
              ((not (entget ent)))                                                  ; 이미 지워짐
              ((and tgt (or (not (entget tgt))
                            (not (vl-some '(lambda (v) (< (sd:d2 v pt) 0.01)) (sd:verts ent)))   ; 끝이 이미 옮겨짐
                            (< (sd:d2 pt (vlax-curve-getClosestPointTo tgt pt)) 0.01))))
              (T
               (command "_.ZOOM" "_C" "_non" (trans pt 0 1) zh)
               (setq g (vl-remove-if-not 'entget grp))
               (foreach o (if (= (car err) 0) (list ent) g) (redraw o 3))
               (grdraw (trans (polar pt (* pi 0.25) (/ zh 30.0)) 0 1) (trans (polar pt (* pi 1.25) (/ zh 30.0)) 0 1) 1)
               (grdraw (trans (polar pt (* pi 0.75) (/ zh 30.0)) 0 1) (trans (polar pt (* pi 1.75) (/ zh 30.0)) 0 1) 1)
               (if (= (car err) 0)
                 (progn
                   (initget "Erase Next eXit")
                   (setq kw (getkword "\n[잔선] 아주 짧은 선입니다 [삭제(E)/다음(N)/종료(X)] <삭제>: "))
                   (redraw)
                   (cond ((= kw "eXit") (setq done T))
                         ((= kw "Next"))
                         (T (vla-StartUndoMark doc) (setq undo_open T) (entdel ent) (vla-EndUndoMark doc) (setq undo_open nil) (setq n (1+ n)))))
                 (progn
                   (setq gs (length g)
                         fixed (if (and (= (car err) 1) (<= gs 50)) "Move" "F"))
                   (initget "Move F Next eXit")
                   (setq kw (getkword (strcat "\n[틈] " (rtos (sd:d2 pt (vlax-curve-getClosestPointTo tgt pt)) 2 3)
                                              " 떨어짐 — 묶음 " (itoa gs) "개 [이동(M)/늘리기(F)/다음(N)/종료(X)] <"
                                              (if (= fixed "Move") "이동" "늘리기") ">: ")))
                   (redraw)
                   (if (null kw) (setq kw fixed))
                   (setq live (vlax-curve-getClosestPointTo tgt pt))
                   (cond
                     ((= kw "eXit") (setq done T))
                     ((= kw "Next"))
                     ((= kw "Move")
                      (vla-StartUndoMark doc) (setq undo_open T)
                      (foreach o g (if (not (sd:locked-p o)) (vla-Move (vlax-ename->vla-object o) (vlax-3d-point pt) (vlax-3d-point live))))
                      (vla-EndUndoMark doc) (setq undo_open nil n (1+ n)))
                     ((/= (cdr (assoc 0 (entget ent))) "LINE")
                      (princ "\n[주의] 폴리선 꼭짓점은 늘릴 수 없습니다 — 이동(M)을 쓰세요."))
                     (T
                      (vla-StartUndoMark doc) (setq undo_open T)
                      (setq r (entget ent))
                      (setq r (subst (cons (if (< (sd:d2 (cdr (assoc 10 r)) pt) (sd:d2 (cdr (assoc 11 r)) pt)) 10 11) live)
                                     (assoc (if (< (sd:d2 (cdr (assoc 10 r)) pt) (sd:d2 (cdr (assoc 11 r)) pt)) 10 11) r) r))
                      (if (entmod r) (setq n (1+ n)))
                      (vla-EndUndoMark doc) (setq undo_open nil))))))))
          (redraw)
          (command "_.ZOOM" "_C" "_non" ctr size)
          (setq ctr nil)
          (princ (strcat "\n[완료] " (itoa n) "곳을 고쳤습니다" (if done " (중간에 끝냄)" "") "."))))))
  (princ))

(princ)
