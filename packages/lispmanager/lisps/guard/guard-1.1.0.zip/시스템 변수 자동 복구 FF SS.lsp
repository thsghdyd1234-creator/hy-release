;;; ==============================================================================
;;;  FF · SS — 리습 오류·ESC 로 꼬인 시스템 변수 되돌리기 (뒤에서 지켜봄)
;;;
;;;  불러오면 감시를 시작한다 (명령줄에는 아무것도 찍지 않음).
;;;   · 리습을 ESC·오류로 멈추면: 그 리습을 시작하기 전의 OSMODE · FILEDIA · PICKFIRST · CMDDIA · CMDECHO 로 되돌린다.
;;;   · 명령을 ESC·오류로 멈추면 (리습 밖에서): 그 명령을 시작하기 전 값으로.
;;;   · 그래서 일부러 오스냅을 꺼 둔(OSMODE 0) 것은 그대로 둔다 (예전: 명령을 취소할 때마다 다시 켬).
;;;  FF = 바로 되돌리기: FILEDIA · PICKFIRST · CMDDIA · CMDECHO 를 1 로, 오스냅은 SS 로 저장한 값(없으면 4133)으로 켬.
;;;  SS = 지금 오스냅 설정을 FF 의 기준으로 저장 (캐드를 다시 켜도 남음).
;;; ==============================================================================

(defun guard:vars () '("OSMODE" "FILEDIA" "PICKFIRST" "CMDDIA" "CMDECHO"))
(defun guard:snap () (mapcar '(lambda (v) (cons v (getvar v))) (guard:vars)))
(defun guard:back (snap)
  (foreach p snap (if (/= (getvar (car p)) (cdr p)) (vl-catch-all-apply 'setvar (list (car p) (cdr p))))))

;; 리액터 콜백 (리액터, 정보)
(defun guard:lisp-start (rx info) (setq *hyguard-lisp* (guard:snap) *hyguard-inlisp* T))
(defun guard:lisp-end (rx info) (setq *hyguard-inlisp* nil))
(defun guard:lisp-cancel (rx info)
  (if *hyguard-lisp* (vl-catch-all-apply 'guard:back (list *hyguard-lisp*)))
  (setq *hyguard-inlisp* nil))
(defun guard:cmd-start (rx info) (if (not *hyguard-inlisp*) (setq *hyguard-cmd* (guard:snap))))
(defun guard:cmd-cancel (rx info)
  (if (and (not *hyguard-inlisp*) *hyguard-cmd*) (vl-catch-all-apply 'guard:back (list *hyguard-cmd*))))

(defun guard:start ()
  (vl-load-com)
  ;; 예전 판(VarGuard…)과 이 판의 리액터를 지우고 다시 건다 (여러 번 불러와도 하나만)
  (foreach kind (list :vlr-command-reactor :vlr-lisp-reactor)
    (foreach rx (cdar (vlr-reactors kind))
      (if (member (vlr-data rx) '("VarGuardCmd" "VarGuardLisp" "HyGuardCmd" "HyGuardLisp")) (vlr-remove rx))))
  (vlr-command-reactor "HyGuardCmd" '((:vlr-commandWillStart . guard:cmd-start)
                                       (:vlr-commandCancelled . guard:cmd-cancel)
                                       (:vlr-commandFailed . guard:cmd-cancel)))
  (vlr-lisp-reactor "HyGuardLisp" '((:vlr-lispWillStart . guard:lisp-start)
                                     (:vlr-lispEnded . guard:lisp-end)
                                     (:vlr-lispCancelled . guard:lisp-cancel)))
  (princ))

(defun c:FF ( / os)
  (foreach v '("FILEDIA" "PICKFIRST" "CMDDIA" "CMDECHO") (vl-catch-all-apply 'setvar (list v 1)))
  (setq os (if (getenv "HyGuardOsmode") (atoi (getenv "HyGuardOsmode")) 4133))
  (if (<= os 0) (setq os 4133))
  (setvar "OSMODE" (logand os 16383))
  (princ (strcat "\n[완료] 파일 창·명령 대화상자·고르기 설정을 되돌리고 오스냅을 켰습니다 (" (itoa (logand os 16383)) ")."))
  (princ))

(defun c:SS ( / os)
  (setq os (logand (getvar "OSMODE") 16383))
  (if (= os 0)
    (princ "\n[주의] 켜진 오스냅이 없어 저장하지 않았습니다. 오스냅을 고른 뒤 다시 SS.")
    (progn (setenv "HyGuardOsmode" (itoa os))
           (princ (strcat "\n[완료] 지금 오스냅 설정(" (itoa os) ")을 FF 의 기준으로 저장했습니다."))))
  (princ))

(guard:start)
(princ)
