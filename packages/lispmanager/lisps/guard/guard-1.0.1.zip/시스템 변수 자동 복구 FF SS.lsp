(vl-load-com)

;; ===================================================================
;; 1. 초기 오스냅(OSNAP) 값 저장 (기본값: 4133)
;; ===================================================================
(if (null *Safe_OSMODE*)
  (setq *Safe_OSMODE* (if (> (getvar "OSMODE") 0) (getvar "OSMODE") 4133))
)

;; ===================================================================
;; 2. 시스템 변수 강제 복구 함수
;; ===================================================================
(defun Fix-SysVars (rx info / cur_os)
  ;; FILEDIA: 파일 열기/저장 창 꺼짐 방지
  (vl-catch-all-apply 'setvar (list "FILEDIA" 1))
  
  ;; PICKFIRST: 복사/붙여넣기(PASTECLIP) 및 객체 더블클릭이 안 되는 문제 방지
  (vl-catch-all-apply 'setvar (list "PICKFIRST" 1))
  
  ;; CMDDIA & CMDECHO: 명령어 대화상자 및 에코 복구
  (vl-catch-all-apply 'setvar (list "CMDDIA" 1))
  (vl-catch-all-apply 'setvar (list "CMDECHO" 1))

  ;; OSMODE: 리습 오류로 오스냅이 완전히 꺼졌을 때(0) 자동 복구
  (setq cur_os (getvar "OSMODE"))
  (if (and *Safe_OSMODE* (= cur_os 0))
    (vl-catch-all-apply 'setvar (list "OSMODE" *Safe_OSMODE*))
  )
)

;; ===================================================================
;; 3. 백그라운드 감시자(Reactor) 구동 함수
;; ===================================================================
(defun Start-SysVar-Guard ()
  ;; 중복 실행 방지
  (if (vlr-reactors :vlr-command-reactor)
    (foreach rx (cdar (vlr-reactors :vlr-command-reactor))
      (if (equal (vlr-data rx) "VarGuardCmd") (vlr-remove rx))
    )
  )
  (if (vlr-reactors :vlr-lisp-reactor)
    (foreach rx (cdar (vlr-reactors :vlr-lisp-reactor))
      (if (equal (vlr-data rx) "VarGuardLisp") (vlr-remove rx))
    )
  )
  
  ;; ESC 취소 및 명령 오류 감시
  (vlr-command-reactor "VarGuardCmd"
    '((:vlr-commandCancelled . Fix-SysVars)
      (:vlr-commandFailed . Fix-SysVars))
  )
  
  ;; 리습 도중 취소(ESC) 감시
  (vlr-lisp-reactor "VarGuardLisp"
    '((:vlr-lispCancelled . Fix-SysVars))
  )
  
  (Fix-SysVars nil nil) ; 파일을 불러올 때 한 번 복구
)

;; ===================================================================
;; 4. 수동 복구 명령어 [명령: FF]
;; ===================================================================
(defun c:FF ()
  (Fix-SysVars nil nil)
  (if *Safe_OSMODE* (setvar "OSMODE" *Safe_OSMODE*)) ; 수동 복구 때는 오스냅도 항상 복구
  (princ "\n[완료] 오스냅, 파일창, 복사/붙여넣기 설정을 복구했습니다.")
  (princ)
)

;; ===================================================================
;; 5. 내 오스냅 설정 저장 [명령: SS]
;; ===================================================================
(defun c:SS ()
  (setq *Safe_OSMODE* (getvar "OSMODE"))
  (princ (strcat "\n[완료] 현재 오스냅 설정(" (itoa *Safe_OSMODE*) ")을 복구 기준으로 저장했습니다."))
  (princ)
)

;; 스크립트 로드 시 감시자 즉시 시작
(Start-SysVar-Guard)
(princ "\n=======================================================")
(princ "\n[시스템 변수 자동 복구] 감시를 시작했습니다.")
(princ "\n리습 오류나 ESC 취소 때 시스템 변수를 자동으로 복구합니다.")
(princ "\n바로 복구: FF")
(princ "\n지금 오스냅 저장: SS")
(princ "\n=======================================================")
(princ)