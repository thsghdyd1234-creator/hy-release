;; ======================================================================
;; [XP] 폴리선을 선(LINE)으로 분해
;; - 드래그 영역 안의 폴리선을 모두 LINE으로 분해합니다.
;; ======================================================================
(defun c:xp ( / ss old_qa )
  (vl-load-com)
  (prompt "\n[XP 폴리선 분해] 선(LINE)으로 분해할 객체를 드래그하세요: ")

  ;; 블록·치수·문자는 빼고 폴리선 종류만 선택합니다.
  (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE,2DPOLYLINE"))))

  (if ss
    (progn
      ;; 여러 객체 동시 분해 허용 (QAFLAGS)
      ;; 캐드는 리습에서 EXPLODE로 여러 객체를 한 번에 분해하지 못하게 막아 두지만,
      ;; 이 숨은 변수를 1로 바꾸면 여러 폴리선을 한 번에 분해할 수 있습니다.
      (setq old_qa (getvar "QAFLAGS"))
      (setvar "QAFLAGS" 1)

      ;; 선택한 폴리선을 한 번에 분해
      (vl-cmdf "_.EXPLODE" ss "")

      ;; 시스템 변수 원상복구 (매우 중요)
      (setvar "QAFLAGS" old_qa)

      (princ (strcat "\n[완료] 총 " (itoa (sslength ss)) "개의 폴리선을 선(LINE)으로 분해했습니다."))
    )
    (princ "\n분해할 폴리선이 없습니다. (이미 선이거나 다른 객체입니다.)")
  )
  (princ)
)