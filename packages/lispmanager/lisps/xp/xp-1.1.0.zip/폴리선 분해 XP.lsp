;;; ==============================================================================
;;;  XP — 폴리선을 선으로 분해
;;;
;;;  고른 폴리선(2D·3D)을 분해한다. 직선 구간은 LINE, 호 구간은 ARC 로 남는다 (폭은 사라짐).
;;;  메시(스케치업에서 내보낸 면)는 빠지고, 잠긴 레이어도 빠진다. 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

(defun c:XP ( / *error* doc undo_open ss i o r n k)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (prompt "\n분해할 폴리선을 고르세요 (잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L" '((-4 . "<OR") (0 . "LWPOLYLINE")
                                    (-4 . "<AND") (0 . "POLYLINE") (-4 . "<NOT") (-4 . "&") (70 . 80) (-4 . "NOT>") (-4 . "AND>")
                                    (-4 . "OR>")))))
    (princ "\n고른 폴리선이 없습니다.")
    (progn
      (vla-StartUndoMark doc)
      (setq undo_open T i 0 n 0 k 0)
      (while (< i (sslength ss))
        (setq o (vlax-ename->vla-object (ssname ss i)))
        (if (not (vl-catch-all-error-p (setq r (vl-catch-all-apply 'vlax-invoke (list o 'Explode)))))
          (progn (setq k (+ k (length r)) n (1+ n)) (vla-Delete o)))
        (setq i (1+ i)))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] 폴리선 " (itoa n) "개를 선·호 " (itoa k) "개로 분해했습니다."))))
  (princ))

(princ)
