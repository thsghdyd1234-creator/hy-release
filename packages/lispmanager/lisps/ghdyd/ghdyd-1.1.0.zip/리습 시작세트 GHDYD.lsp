;;; ============================================================
;;;  GHDYD - 리습 시작세트 일괄 로더 V7
;;;  명령어: GHDYD     - 일괄 로드 (기본: 리습매니저 리습 폴더 자동 인식)
;;;          GHDYDSET  - 폴더 선택창으로 리습 폴더 변경
;;;          GHDYDLIST - 마지막으로 불러온 파일 목록 보기
;;;  * 하위폴더(3단계까지) 포함 모든 .lsp · .fas · .vlx 일괄 로드 ('_' · '.' 로 시작하는 폴더는 건너뜀: _previews · _정리됨)
;;;  * V7: 같은 이름 파일이 여러 폴더에 있으면 하나만 — 맨 위 폴더 것이 이긴다 (백업 폴더의 옛 사본이 덮지 않게).
;;;        실패한 파일은 이유를 함께 보여 주고, 목록에 있는데 폴더에 없는 파일 수도 알린다.
;;;  * V6: 리습매니저가 레지스트리 Order 에 적어 둔 '목록의 리습'을 맨 마지막에 목록 순서대로 불러온다.
;;;        같은 명령어를 가진 옛 버전 파일이 폴더에 남아 있어도 목록의 버전이 적용된다.
;;;  * V6: 명령창에는 요약 한 줄과 실패한 파일만 보여 준다 (전체 목록은 GHDYDLIST).
;;; ============================================================
(vl-load-com)

(setq *ghdyd-regkey* "HKEY_CURRENT_USER\\Software\\GHDYD_Loader")

;; 리습매니저 리습 폴더 자동 탐지 (레지스트리 Path 가 없을 때)
(defun GHDYD:ManagerFolder ( / cands hit )
  (if (getenv "USERPROFILE")
   (setq cands (list
    (strcat (getenv "USERPROFILE") "\\OneDrive\\문서\\Happy_Launcher_Data\\Shared_Lisp_Folder")
    (strcat (getenv "USERPROFILE") "\\OneDrive\\Documents\\Happy_Launcher_Data\\Shared_Lisp_Folder")
    (strcat (getenv "USERPROFILE") "\\Documents\\Happy_Launcher_Data\\Shared_Lisp_Folder"))))
  (foreach c cands (if (and (not hit) (vl-file-directory-p c)) (setq hit c)))
  hit
)

;; 폴더 선택창 (Windows 폴더 찾아보기)
(defun GHDYD:PickFolder ( / sh res self path )
  (setq sh (vlax-create-object "Shell.Application"))
  (if sh
    (progn
      (setq res (vl-catch-all-apply 'vlax-invoke-method
                  (list sh 'BrowseForFolder 0 "일괄 로드할 리습 폴더를 선택하세요 (하위폴더 포함 전체 로드)" 0)))
      (if (and res (not (vl-catch-all-error-p res)))
        (progn
          (setq self (vl-catch-all-apply 'vlax-get-property (list res 'Self)))
          (if (not (vl-catch-all-error-p self))
            (progn
              (setq path (vl-catch-all-apply 'vlax-get-property (list self 'Path)))
              (if (vl-catch-all-error-p path) (setq path nil))
            )
          )
        )
      )
      (vlax-release-object sh)
    )
  )
  (if (and path (= (type path) 'STR) (/= path "")) path nil)
)

(defun GHDYD:Norm ( p )
  (setq p (vl-string-translate "\\" "/" p))
  (if (/= (substr p (strlen p) 1) "/") (setq p (strcat p "/")))
  p
)

;; 하위 폴더 (이름이 '_' · '.' 로 시작하는 폴더는 건너뜀: _previews 그림, _정리됨 옛 파일 · 깊이 3까지, 이름순)
(defun GHDYD:SubFolders ( folder depth / out )
  (setq out (list folder))
  (if (< depth 3)
    (foreach dir (vl-sort (vl-remove "." (vl-remove ".." (vl-directory-files folder nil -1)))
                          '(lambda (a b) (< (strcase a) (strcase b))))
      (if (not (member (substr dir 1 1) '("_" ".")))
        (setq out (append out (GHDYD:SubFolders (strcat folder dir "/") (1+ depth)))))))
  out
)

(defun GHDYD:FileName ( f )
  (strcat (vl-filename-base f) (vl-filename-extension f))
)

;; 폴더의 리습 파일 .lsp · .fas · .vlx (전체 경로, 이름순) — 대소문자 섞인 확장자도 한 번씩
(defun GHDYD:Files ( folder / lst up )
  (foreach pat '("*.lsp" "*.LSP" "*.fas" "*.FAS" "*.vlx" "*.VLX")
    (foreach f (vl-directory-files folder pat 1)
      (if (not (member (strcase f) up)) (setq lst (cons f lst) up (cons (strcase f) up)))))
  (mapcar '(lambda (f) (strcat folder f))
          (vl-sort lst '(lambda (a b) (< (strcase a) (strcase b)))))
)

;; "a|b|c" → ("a" "b" "c")
(defun GHDYD:Split ( s sep / i out )
  (while (setq i (vl-string-search sep s))
    (setq out (cons (substr s 1 i) out))
    (setq s (substr s (+ i 2)))
  )
  (if (/= s "") (setq out (cons s out)))
  (reverse out)
)

;; 리습매니저가 적어 둔 목록 순서 (대문자 파일 이름). 없으면 nil
(defun GHDYD:Order ( / s )
  (setq s (vl-registry-read *ghdyd-regkey* "Order"))
  (if (and (= (type s) 'STR) (/= s "")) (mapcar 'strcase (GHDYD:Split s "|")) nil)
)

;; 일괄 로드 — 목록에 없는 파일 먼저(이름순), 목록의 파일은 맨 마지막에 목록 순서대로
;; 같은 이름은 하나만: 맨 위 폴더 것 먼저, 그다음 하위 폴더 이름순으로 처음 것
(defun GHDYD:Run ( mainFolder / seen all dup order extras managed missing ok fail failed nm r )
  (setq mainFolder (GHDYD:Norm mainFolder) dup 0)
  (foreach folder (GHDYD:SubFolders mainFolder 0)
    (foreach f (GHDYD:Files folder)
      (setq nm (strcase (GHDYD:FileName f)))
      (cond ((wcmatch nm "*GHDYD*"))
            ((member nm seen) (setq dup (1+ dup)))
            (T (setq seen (cons nm seen) all (cons f all))))))
  (setq all (reverse all))
  (setq order (GHDYD:Order))
  (foreach f all
    (if (not (member (strcase (GHDYD:FileName f)) order)) (setq extras (cons f extras)))
  )
  (setq extras (reverse extras))
  (foreach nm order
    (if (not (wcmatch nm "*GHDYD*"))
      (if (member nm seen)
        (foreach f all (if (= (strcase (GHDYD:FileName f)) nm) (setq managed (cons f managed))))
        (setq missing (cons nm missing))))
  )
  (setq managed (reverse managed))
  (setq ok 0 fail 0)
  (foreach f (append extras managed)
    (setq r (vl-catch-all-apply 'load (list f)))
    (if (vl-catch-all-error-p r)
      (setq fail (1+ fail) failed (cons (strcat (GHDYD:FileName f) " — " (vl-catch-all-error-message r)) failed))
      (setq ok (1+ ok))
    )
  )
  (setq *ghdyd-last* (append extras managed))
  (princ "\n")
  (if (= (+ ok fail) 0)
    (princ (strcat "[GHDYD] 리습 파일을 찾지 못했습니다: " mainFolder "  (폴더 바꾸기: GHDYDSET)"))
    (progn
      (princ (strcat "[GHDYD] 리습 " (itoa ok) "개 불러옴"
                     (if (> fail 0) (strcat " · 실패 " (itoa fail) "개") "")
                     (if (and order extras) (strcat " · 목록에 없는 파일 " (itoa (length extras)) "개 포함") "")
                     (if (> dup 0) (strcat " · 같은 이름 " (itoa dup) "개는 건너뜀") "")
                     (if missing (strcat " · 목록에 있는데 없는 파일 " (itoa (length missing)) "개") "")
                     "  (목록 보기: GHDYDLIST)"))
      (foreach n (reverse failed) (princ (strcat "\n   [X] " n)))
    )
  )
  (princ)
)

(defun c:GHDYDLIST ( )
  (if *ghdyd-last*
    (progn
      (princ (strcat "\n[GHDYD] 불러온 순서 (" (itoa (length *ghdyd-last*)) "개, 아래쪽이 나중):"))
      (foreach f *ghdyd-last* (princ (strcat "\n   " (GHDYD:FileName f))))
    )
    (princ "\n[GHDYD] 아직 불러온 목록이 없습니다. GHDYD를 먼저 실행하세요.")
  )
  (princ)
)

(defun c:GHDYDSET ( / p )
  (princ "\n[알림] 리습매니저 › 설정 › GHDYD 일괄 로드에서도 폴더를 바꿀 수 있습니다.")
  (setq p (GHDYD:PickFolder))
  (if p
    (progn
      (setq p (GHDYD:Norm p))
      (vl-registry-write *ghdyd-regkey* "Path" p)
      (princ (strcat "\n[GHDYD] 폴더 저장됨: " p))
      (GHDYD:Run p)
    )
    (princ "\n[GHDYD] 폴더 선택이 취소되었습니다.")
  )
  (princ)
)

(defun c:GHDYD ( / p m )
  (setq p (vl-registry-read *ghdyd-regkey* "Path"))
  (cond
    ((and p (vl-file-directory-p p)) (GHDYD:Run p))
    ((setq m (GHDYD:ManagerFolder)) (GHDYD:Run m))
    (T (princ "\n[GHDYD] 리습 폴더를 선택하세요.") (c:GHDYDSET))
  )
  (princ)
)

;; 불러오자마자 한 번 실행 (시작세트)
(c:GHDYD)
(princ)
