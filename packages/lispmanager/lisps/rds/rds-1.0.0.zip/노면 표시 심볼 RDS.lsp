;;; ============================================================
;;;  RDS - 노면 표시 심볼 꺼내기
;;;
;;;  심볼을 골라 클릭으로 배치 → 방향 지정
;;;   화살표: 직진(F) 좌(L) 우(R) 좌직(LF) 직우(FR) 좌우(LR) 전방향(LFR) 유턴(U)
;;;   횡단보도(C): 도로 양쪽 경계를 차례로 찍으면 그 폭에 맞춰 줄무늬 생성
;;;   횡단보도 예고(D): 마름모
;;;   설정(S): 심볼 기준 크기, 화살표 길이, 횡단보도 치수
;;;
;;;  놓기: 심볼 꼬리 가운데가 커서를 따라옴(AutoCAD 이동 미리보기, 스냅·극좌표 그대로)
;;;        → 진행 방향을 찍거나 각도 입력 (회전 미리보기)
;;;  Enter = 직전 심볼 다시, ESC = 끝 (놓다 만 심볼은 지움)
;;;  크기 기준(*rd-su*, *rd-al*)은 MLSP 와 같이 씀 → MLX 자동 화살표와 같은 크기
;;;  모두 닫힌 폴리선, 레이어 ROAD_노면표시 (일러스트레이터로 넘기기 좋게), 태그가 없어 MLX 가 지우지 않음
;;; ============================================================
(vl-load-com)

(or *rd-su*    (setq *rd-su*    3500.0))   ; 심볼 기준 크기 (기준 차로폭)
(or *rd-al*    (setq *rd-al*    5000.0))   ; 화살표 길이
(or *rd-pre*   (setq *rd-pre*   "ROAD_"))
(or *rds-cwd*  (setq *rds-cwd*  4000.0))   ; 횡단보도 폭 (진행 방향 길이)
(or *rds-bw*   (setq *rds-bw*   450.0))    ; 줄무늬 폭
(or *rds-bg*   (setq *rds-bg*   450.0))    ; 줄무늬 간격
(or *rds-last* (setq *rds-last* "F"))
(setq *rds-cur* nil)

(defun rds:doc () (vla-get-ActiveDocument (vlax-get-acad-object)))

(defun rds:layer (/ nm ly)
  (setq nm (strcat *rd-pre* "노면표시"))
  (if (not (tblsearch "LAYER" nm))
    (progn (setq ly (vla-Add (vla-get-Layers (rds:doc)) nm))
           (vla-put-Color ly 7)))
  nm)

(defun rds:unit (v / l)
  (setq l (sqrt (apply '+ (mapcar '* v v))))
  (if (> l 1e-12) (mapcar '(lambda (x) (/ x l)) v) v))

;;; ---------- 심볼 형상 (로컬: +x 진행, +y 왼쪽) ----------
(defun rds:arc (cx cy r a0 a1 n / out i a)
  (setq i 0)
  (repeat (1+ n)
    (setq a (+ a0 (* (- a1 a0) (/ (float i) n)))
          out (cons (list (+ cx (* r (cos a))) (+ cy (* r (sin a)))) out)
          i (1+ i)))
  (reverse out))

(defun rds:arrow (l s r u la / sw hw hl rb yh xb xos x0 p a0 a1)
  ;; 회전 위치: 직진이 있으면 줄기 중간에서 갈라지고,
  ;;           회전만 있으면 머리 윗선이 직진 화살표 끝(la)과 같도록 꼬리를 늘림 → 모든 화살표 전체 길이 동일
  (setq sw (* 0.05 u) hw (* 0.15 u) hl (* 0.22 u) rb (* 0.12 u) yh (* 0.20 u)
        xb (if s (* 0.45 la) (- la rb hw))
        xos (+ xb (* 2.0 (sqrt (* rb sw))))
        x0  (+ xb (sqrt (- (* (+ rb sw) (+ rb sw)) (* rb rb))))
        p   (list (list 0.0 (- sw))))
  ;; 우회전 가지
  (if r
    (progn
      (setq p (append p
                (list (list xb (- sw)))
                (cdr (rds:arc xb (- rb) (- rb sw) (/ pi 2.0) 0.0 10))
                (list (list (- (+ xb rb) sw) (- yh)) (list (- (+ xb rb) hw) (- yh))
                      (list (+ xb rb) (- (+ yh hl)))
                      (list (+ xb rb hw) (- yh)) (list (+ xb rb sw) (- yh)) (list (+ xb rb sw) (- rb)))))
      (setq a1 (cond (s (atan (- rb sw) (- xos xb)))
                     (l (atan rb (- x0 xb)))
                     (t (/ pi 2.0))))
      (setq p (append p (cdr (rds:arc xb (- rb) (+ rb sw) 0.0 a1 10))))))
  ;; 직진 머리
  (if s
    (setq p (append p (list (list (- la hl) (- sw)) (list (- la hl) (- hw)) (list la 0.0)
                            (list (- la hl) hw) (list (- la hl) sw)))))
  ;; 좌회전 가지
  (if l
    (progn
      (setq a0 (cond (s (atan (- sw rb) (- xos xb)))
                     (r (atan (- rb) (- x0 xb)))
                     (t (setq p (append p (list (list xb (- sw))))) (/ pi -2.0))))
      (setq p (append p
                (rds:arc xb rb (+ rb sw) a0 0.0 10)
                (list (list (+ xb rb sw) yh) (list (+ xb rb hw) yh) (list (+ xb rb) (+ yh hl))
                      (list (- (+ xb rb) hw) yh) (list (- (+ xb rb) sw) yh) (list (- (+ xb rb) sw) rb))
                (cdr (rds:arc xb rb (- rb sw) 0.0 (/ pi -2.0) 10))))))
  (append p (list (list 0.0 sw))))

;; 유턴: 줄기 → 반원(좌측으로 180도) → 되돌아오는 머리. 전체 길이 la, 차로 중심 기준
(defun rds:uturn (u la / sw hw hl r xa xh p)
  (setq sw (* 0.05 u) hw (* 0.15 u) hl (* 0.22 u) r (* 0.17 u)
        xa (- la r sw) xh (* 0.45 la))
  (setq p (append
            (list (list 0.0 (- sw)) (list xa (- sw)))
            (cdr (rds:arc xa r (+ r sw) (/ pi -2.0) (/ pi 2.0) 16))
            (list (list xh (+ r r sw)) (list xh (+ r r hw)) (list (- xh hl) (+ r r))
                  (list xh (- (+ r r) hw)) (list xh (- (+ r r) sw)) (list xa (- (+ r r) sw)))
            (cdr (rds:arc xa r (- r sw) (/ pi 2.0) (/ pi -2.0) 16))
            (list (list 0.0 sw))))
  (mapcar '(lambda (q) (list (car q) (- (cadr q) r))) p))

;; 횡단보도 예고 마름모: 바깥 + 안쪽 (두 닫힌 선 = 테두리 마름모)
(defun rds:diamond (u / l w th k o)
  (setq l (* 0.9 u) w (* 0.35 u) th (* 0.05 u) k (- 1.0 (/ (* 2.0 th) w))
        o (list (list 0.0 0.0) (list (/ l 2.0) (/ w -2.0)) (list l 0.0) (list (/ l 2.0) (/ w 2.0))))
  (list o (mapcar '(lambda (q) (list (+ (/ l 2.0) (* (- (car q) (/ l 2.0)) k)) (* (cadr q) k))) o)))

;; 횡단보도 줄무늬: 폭 width를 가로질러 가운데 맞춤
(defun rds:crosswalk (width / n used y0 i y out d)
  (setq d (/ *rds-cwd* 2.0)
        n (fix (/ (- width *rds-bg*) (+ *rds-bw* *rds-bg*)))
        used (- (* n (+ *rds-bw* *rds-bg*)) *rds-bg*)
        y0 (+ (/ width -2.0) (/ (- width used) 2.0)) i 0)
  (repeat (max n 0)
    (setq y (+ y0 (* i (+ *rds-bw* *rds-bg*)))
          out (cons (list (list (- d) y) (list d y) (list d (+ y *rds-bw*)) (list (- d) (+ y *rds-bw*))) out)
          i (1+ i)))
  out)

;;; ---------- 생성 / 배치 ----------
;; 로컬 도형들 → 닫힌 폴리선 (o: WCS 원점, f: 진행 방향, n: 왼쪽)
(defun rds:make (polys o f n / lay out)
  (setq lay (rds:layer))
  (foreach pl polys
    (entmake
      (append
        (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay) '(100 . "AcDbPolyline")
              (cons 90 (length pl)) '(70 . 1) (cons 38 (caddr o)))
        (mapcar '(lambda (q) (cons 10 (list (+ (car o) (* (car f) (car q)) (* (car n) (cadr q)))
                                            (+ (cadr o) (* (cadr f) (car q)) (* (cadr n) (cadr q))))))
                pl)))
    (setq out (cons (entlast) out)))
  out)

(defun rds:ss (ents / ss)
  (setq ss (ssadd))
  (foreach e ents (ssadd e ss))
  ss)

;; 화면 중앙에 위쪽 방향으로 만든 뒤 → 이동 미리보기 → 방향 지정
(defun rds:place (polys / o f n ss dest)
  (setq o (trans (getvar "VIEWCTR") 1 0)
        f (rds:unit (trans '(0.0 1.0 0.0) 1 0 t))
        n (list (- (cadr f)) (car f) 0.0)
        *rds-cur* (rds:make polys o f n)
        ss (rds:ss *rds-cur*))
  (princ "\n놓을 위치를 지정하세요 (화살표 꼬리 가운데): ")
  (command "_.MOVE" ss "" "_non" (trans o 0 1) pause)
  (setq dest (getvar "LASTPOINT"))
  (princ "\n진행 방향을 지정하세요 (점 또는 각도): ")
  (command "_.ROTATE" ss "" "_non" dest "_R" "_non" dest "_non" (polar dest (/ pi 2.0) 1.0) pause)
  (setq *rds-cur* nil))

(defun rds:place-crosswalk (/ p1 p2 w o n f)
  (if (and (setq p1 (getpoint "\n횡단보도 시작 (도로 한쪽 경계): "))
           (setq p2 (getpoint p1 "\n횡단보도 끝 (반대쪽 경계): ")))
    (progn
      (setq p1 (trans p1 1 0) p2 (trans p2 1 0)
            w  (distance p1 p2)
            o  (mapcar '(lambda (a b) (/ (+ a b) 2.0)) p1 p2)
            n  (rds:unit (mapcar '- p2 p1))
            f  (list (cadr n) (- (car n)) 0.0))
      (if (> w (+ *rds-bw* *rds-bg*))
        (rds:make (rds:crosswalk w) o f n)
        (princ "\n[주의] 폭이 너무 좁아 줄무늬를 그릴 수 없습니다.")))))

(defun rds:settings ()
  (defun rds:num (msg cur / v)
    (initget 6)
    (if (setq v (getdist (strcat msg " <" (rtos cur 2 0) ">: "))) v cur))
  (setq *rd-su*   (rds:num "\n심볼 기준 크기 (기준 차로폭)" *rd-su*)
        *rd-al*   (rds:num "\n화살표 길이" *rd-al*)
        *rds-cwd* (rds:num "\n횡단보도 폭 (진행 방향 길이)" *rds-cwd*)
        *rds-bw*  (rds:num "\n횡단보도 줄무늬 폭" *rds-bw*)
        *rds-bg*  (rds:num "\n횡단보도 줄무늬 간격" *rds-bg*)))

(defun rds:name (k)
  (cdr (assoc k '(("F" . "직진") ("L" . "좌") ("R" . "우") ("LF" . "좌직") ("FR" . "직우")
                  ("LR" . "좌우") ("LFR" . "전방향") ("Uturn" . "유턴")
                  ("Crosswalk" . "횡단보도") ("Diamond" . "예고")))))

(defun c:RDS (/ *error* doc k go ce undo_open)
  (setq doc (rds:doc) ce (getvar "CMDECHO"))
  (defun *error* (msg)
    (foreach e *rds-cur* (if (entget e) (entdel e)))   ; 놓다 만 심볼 정리
    (setq *rds-cur* nil)
    (setvar "CMDECHO" ce)
    (if (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*BREAK*"))
      (princ (strcat "\n[오류] " msg)))
    (if undo_open (vla-EndUndoMark doc))
    (princ))
  (setvar "CMDECHO" 0)
  (setq go t)
  (while go
    (initget "F L R LF FR LR LFR Uturn Crosswalk Diamond Settings")
    (setq k (getkword (strcat "\n심볼 [직진(F)/좌(L)/우(R)/좌직(LF)/직우(FR)/좌우(LR)/전방향(LFR)/유턴(U)/횡단보도(C)/예고(D)/설정(S)] <"
                              (rds:name *rds-last*) ">: ")))
    (if (null k) (setq k *rds-last*))
    (if (= k "Settings")
      (rds:settings)
      (progn
        (setq *rds-last* k)
        (vla-StartUndoMark doc)
        (setq undo_open t)
        (cond
          ((= k "Crosswalk") (rds:place-crosswalk))
          ((= k "Diamond")   (rds:place (rds:diamond *rd-su*)))
          ((= k "Uturn")     (rds:place (list (rds:uturn *rd-su* *rd-al*))))
          (t (rds:place (list (rds:arrow (wcmatch k "L*") (wcmatch k "*F*") (wcmatch k "*R")
                                         *rd-su* *rd-al*)))))
        (vla-EndUndoMark doc)
        (setq undo_open nil))))
  (princ))

(princ)
