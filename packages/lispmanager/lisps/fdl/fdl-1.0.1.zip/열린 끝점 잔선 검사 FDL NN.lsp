;;; ==============================================================================
;;; 명령어 1: FDL (도면 검사) - 선·호, 2D 기준 검사
;;; 명령어 2: NN (다음 위치) - 짧은 잔선은 주변이 닫혀 있어도 건너뛰지 않음
;;; 키: [Space]결합 | [D]오류 선만 삭제 | [M]수동 | [N]건너뛰기 | [X]종료
;;; ==============================================================================

(setq *fdl_error_list* nil)
(setq *fdl_current_index* 0)
(setq *fdl_all_lines* nil) 
(setq *fdl_max_gap* 50.0)  
(setq *fdl_max_short* 5.0) ; 짧은 잔선 기준 길이 (전역)

(defun dist2d (p1 p2)
  (distance (list (car p1) (cadr p1) 0.0) (list (car p2) (cadr p2) 0.0))
)
(defun flat (pt) (list (car pt) (cadr pt) 0.0))

;;; ------------------------------------------------------------------------------
;;; [명령어 1] 통합 오류 탐색
;;; ------------------------------------------------------------------------------
(defun c:FDL (/ ss i ent p1 p2 max_gap max_short lines_count item d1 d2 len)
  (vl-load-com)
  
  (setq max_gap (getreal "\n[열린 끝점] 찾을 최대 틈 거리를 입력하세요 <50.0>: "))
  (if (not max_gap) (setq max_gap 50.0))
  (setq *fdl_max_gap* max_gap)
  
  (setq max_short (getreal "\n[짧은 잔선] 짧은 잔선으로 볼 최대 길이를 입력하세요 <5.0>: "))
  (if (not max_short) (setq max_short 5.0))
  (setq *fdl_max_short* max_short) ; 전역 변수에 저장
  
  (prompt "\n스캔할 객체 선택 (LINE, ARC) (도면 전체는 Enter): ")
  (if (not (setq ss (ssget '((0 . "LINE,ARC")))))
    (setq ss (ssget "X" '((0 . "LINE,ARC"))))
  )
  
  (setq *fdl_error_list* nil)
  (setq *fdl_current_index* 0)
  
  (if ss
    (progn
      (setq i 0 lines_count (sslength ss) *fdl_all_lines* nil)
      (princ "\n2D 평면 기준으로 검사하는 중...")
      
      (while (< i lines_count)
        (setq ent (ssname ss i))
        (setq *fdl_all_lines* (cons ent *fdl_all_lines*))
        (setq i (1+ i))
      )
      
      (defun get_min_dist (pt curr_ent all_ents / min_d d near_pt)
        (setq min_d 999999.0)
        (foreach item all_ents
          (if (not (eq curr_ent item))
            (progn
              (setq near_pt (vlax-curve-getClosestPointTo item pt nil))
              (if near_pt
                (progn
                  (setq d (dist2d pt near_pt))
                  (if (< d min_d) (setq min_d d))
                )
              )
            )
          )
        )
        min_d
      )

      (foreach ent *fdl_all_lines*
        (setq p1 (vlax-curve-getStartPoint ent))
        (setq p2 (vlax-curve-getEndPoint ent))
        (setq len (vlax-curve-getDistAtParam ent (vlax-curve-getEndParam ent)))
        
        (if (<= len max_short)
          (setq *fdl_error_list* (append *fdl_error_list* (list (list ent p1 "짧은 잔선"))))
          (progn
            (setq d1 (get_min_dist p1 ent *fdl_all_lines*))
            (setq d2 (get_min_dist p2 ent *fdl_all_lines*))
            
            (if (and (> d1 0.001) (<= d1 max_gap))
              (setq *fdl_error_list* (append *fdl_error_list* (list (list ent p1 "시작점 열림"))))
            )
            (if (and (> d2 0.001) (<= d2 max_gap))
              (setq *fdl_error_list* (append *fdl_error_list* (list (list ent p2 "끝점 열림"))))
            )
          )
        )
      )
      
      (if *fdl_error_list*
        (progn
          (princ (strcat "\n[진단 완료] 총 " (itoa (length *fdl_error_list*)) "개의 문제(잔선·열린 끝점)를 찾았습니다."))
          (c:NN)
        )
        (princ "\n[완료] 도면에 잔선이나 열린 끝점이 없습니다.")
      )
    )
    (princ "\n검사할 객체가 없습니다.")
  )
  (princ)
)

;;; ------------------------------------------------------------------------------
;;; [내부 함수] LINE / ARC 좌표 업데이트 로직
;;; ------------------------------------------------------------------------------
(defun update_endpoint (ent old_pt new_pt / obj obj_type p1 p2 is_horiz is_vert cen ang_new pt_3d)
  (setq obj (vlax-ename->vla-object ent))
  (setq obj_type (cdr (assoc 0 (entget ent))))
  (setq p1 (vlax-curve-getStartPoint obj))
  (setq p2 (vlax-curve-getEndPoint obj))
  
  (if (= obj_type "LINE")
    (progn
      (setq is_horiz (equal (cadr p1) (cadr p2) 1e-8))
      (setq is_vert  (equal (car p1) (car p2) 1e-8))
      (if is_horiz (setq new_pt (list (car new_pt) (cadr p1) (caddr new_pt))))
      (if is_vert  (setq new_pt (list (car p1) (cadr new_pt) (caddr new_pt))))

      (if (< (dist2d p1 old_pt) (dist2d p2 old_pt))
        (setq pt_3d (list (car new_pt) (cadr new_pt) (caddr p1)))
        (setq pt_3d (list (car new_pt) (cadr new_pt) (caddr p2)))
      )

      (if (< (dist2d p1 old_pt) (dist2d p2 old_pt))
        (vlax-put obj 'StartPoint pt_3d)
        (vlax-put obj 'EndPoint pt_3d)
      )
    )
    (progn
      (setq cen (vlax-get obj 'Center))
      (setq ang_new (angle (flat cen) (flat new_pt)))
      (if (< (dist2d p1 old_pt) (dist2d p2 old_pt))
        (vlax-put obj 'StartAngle ang_new)
        (vlax-put obj 'EndAngle ang_new)
      )
    )
  )
)

(defun force_line_to_pt (ent old_pt new_pt / obj p1 p2 pt_3d)
  (setq obj (vlax-ename->vla-object ent))
  (setq p1 (vlax-curve-getStartPoint obj) p2 (vlax-curve-getEndPoint obj))
  (if (< (dist2d p1 old_pt) (dist2d p2 old_pt))
    (progn
      (setq pt_3d (list (car new_pt) (cadr new_pt) (caddr p1)))
      (vlax-put obj 'StartPoint pt_3d)
    )
    (progn
      (setq pt_3d (list (car new_pt) (cadr new_pt) (caddr p2)))
      (vlax-put obj 'EndPoint pt_3d)
    )
  )
)

;;; ------------------------------------------------------------------------------
;;; [내부 함수] 교차점 기준으로 대상 찾기
;;; ------------------------------------------------------------------------------
(defun get_target_type (int_pt target_ent max_gap / p3 p4 d3 d4)
  (setq p3 (vlax-curve-getStartPoint target_ent))
  (setq p4 (vlax-curve-getEndPoint target_ent))
  (setq d3 (dist2d int_pt p3))
  (setq d4 (dist2d int_pt p4))
  (if (or (<= d3 max_gap) (<= d4 max_gap)) "CORNER" "T_JUNC")
)

(defun get_smart_target (pt curr_ent max_gap / min_d target_ent target_type int_pt obj1 obj2 pts i temp_pt d p3 p4)
  (setq min_d max_gap target_ent nil target_type nil int_pt nil)
  (setq obj1 (vlax-ename->vla-object curr_ent))
  
  (foreach item *fdl_all_lines*
    (if (and (entget item) (not (eq curr_ent item)))
      (progn
        (setq obj2 (vlax-ename->vla-object item))
        (setq p3 (vlax-curve-getStartPoint obj2))
        (setq p4 (vlax-curve-getEndPoint obj2))
        
        (setq d (dist2d pt p3))
        (if (<= d min_d) (setq min_d d target_ent item int_pt p3 target_type "CORNER"))
        
        (setq d (dist2d pt p4))
        (if (<= d min_d) (setq min_d d target_ent item int_pt p4 target_type "CORNER"))

        (setq pts (vlax-invoke obj1 'IntersectWith obj2 3))
        (if pts
          (progn
            (setq i 0)
            (while (< i (length pts))
              (setq temp_pt (list (nth i pts) (nth (+ i 1) pts) (nth (+ i 2) pts)))
              (setq d (dist2d pt temp_pt))
              (if (<= d min_d)
                (progn
                  (setq min_d d target_ent item int_pt temp_pt)
                  (setq target_type (get_target_type int_pt item max_gap))
                )
              )
              (setq i (+ i 3))
            )
          )
        )
      )
    )
  )
  (if target_ent (list target_ent int_pt target_type) nil)
)

;;; ------------------------------------------------------------------------------
;;; [내부 함수] 짧은 잔선은 교차점이 닫혀 있어도 건너뛰지 않음
;;; ------------------------------------------------------------------------------
(defun check_resolved_live (ent old_pt msg / p1 p2 cur_pt is_closed p_min p_max ss_test k test_ent near_pt obj len)
  (if (not (entget ent))
    T ; 선이 지워졌으면 해결됨 (통과)
    (if (= msg "짧은 잔선")
      ;; 짧은 잔선인 경우:
      ;; 사용자가 늘려서 일반 선 길이로 만들지 않는 한 항상 화면에 보여 줌.
      (progn
        (setq obj (vlax-ename->vla-object ent))
        (setq len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
        (if (> len *fdl_max_short*) T nil)
      )
      ;; 일반 열린 끝점(FDL)인 경우: 주변이 닫혔는지 다시 검사
      (progn
        (setq p1 (vlax-curve-getStartPoint ent) p2 (vlax-curve-getEndPoint ent))
        (setq cur_pt (if (< (dist2d p1 old_pt) (dist2d p2 old_pt)) p1 p2))
        
        (if (> (dist2d cur_pt old_pt) 0.001) 
          T 
          (progn
            (setq is_closed nil)
            (setq p_min (list (- (car cur_pt) 0.1) (- (cadr cur_pt) 0.1) 0.0))
            (setq p_max (list (+ (car cur_pt) 0.1) (+ (cadr cur_pt) 0.1) 0.0))
            
            (if (setq ss_test (ssget "C" p_min p_max '((0 . "LINE,ARC"))))
              (progn
                (setq k 0)
                (while (< k (sslength ss_test))
                  (setq test_ent (ssname ss_test k))
                  (if (not (eq test_ent ent))
                    (progn
                      (setq near_pt (vlax-curve-getClosestPointTo test_ent cur_pt nil))
                      (if (and near_pt (< (dist2d cur_pt near_pt) 0.001))
                        (setq is_closed T)
                      )
                    )
                  )
                  (setq k (1+ k))
                )
              )
            )
            is_closed
          )
        )
      )
    )
  )
)

;;; ------------------------------------------------------------------------------
;;; [명령어 2] NN 루프 
;;; ------------------------------------------------------------------------------
(defun c:NN (/ data ent pt msg view_h ans loop target_info t_ent t_pt t_type p3 p4 pt2 type1 type2 arc_p1 arc_p2 line_p1 line_p2 line_old)
  (if (not *fdl_error_list*)
    (princ "\n탐색된 오류 리스트가 없습니다. 'FDL'을 먼저 실행하세요.")
    (progn
      (setq loop T)
      
      (while (and loop (< *fdl_current_index* (length *fdl_error_list*)))
        (setq data (nth *fdl_current_index* *fdl_error_list*))
        (setq ent (car data) pt (cadr data) msg (caddr data))
        
        (setq view_h 250.0) 
        (command "_.ZOOM" "_C" pt view_h)
        
        ;; msg를 넘겨 짧은 잔선은 항상 잡아냄
        (if (check_resolved_live ent pt msg)
          (progn
            (princ (strcat "\n[" (itoa (1+ *fdl_current_index*)) "/" (itoa (length *fdl_error_list*)) "] 이미 닫힌 곳입니다. (자동으로 건너뜀)"))
            (setq *fdl_current_index* (1+ *fdl_current_index*)) 
          )
          (progn
            (setq target_info (get_smart_target pt ent *fdl_max_gap*))
            
            (if (entget ent)
              (sssetfirst nil (ssadd ent (ssadd)))
            )
            
            (if target_info (redraw (car target_info) 3))
            
            (initget "Fix Delete Manual Next eXit")
            (setq ans (getkword (strcat "\n[" (itoa (1+ *fdl_current_index*)) "/" (itoa (length *fdl_error_list*)) "] " msg " | [Space] 결합 | [D] 오류 선만 삭제 | [M] 수동 | [N] 건너뛰기 | [X] 종료: ")))
            
            (if target_info (redraw (car target_info) 4))
            
            (cond
              ((or (null ans) (= ans "Fix"))
               (if target_info
                 (progn
                   (setq t_ent (car target_info) t_pt (cadr target_info) t_type (caddr target_info))
                   (setq type1 (cdr (assoc 0 (entget ent))))
                   (setq type2 (cdr (assoc 0 (entget t_ent))))
                   
                   (cond
                     ((and (= type1 "LINE") (= type2 "ARC"))
                      (princ "\n[선-호 결합] 직선 끝을 호의 끝점에 붙였습니다.")
                      (setq arc_p1 (vlax-curve-getStartPoint t_ent) arc_p2 (vlax-curve-getEndPoint t_ent))
                      (setq pt2 (if (< (dist2d pt arc_p1) (dist2d pt arc_p2)) arc_p1 arc_p2))
                      (force_line_to_pt ent pt pt2)
                     )
                     
                     ((and (= type1 "ARC") (= type2 "LINE"))
                      (princ "\n[선-호 결합] 직선 끝을 호의 끝점에 붙였습니다.")
                      (setq arc_p1 (vlax-curve-getStartPoint ent) arc_p2 (vlax-curve-getEndPoint ent))
                      (setq pt2 (if (< (dist2d pt arc_p1) (dist2d pt arc_p2)) arc_p1 arc_p2))
                      (setq line_p1 (vlax-curve-getStartPoint t_ent) line_p2 (vlax-curve-getEndPoint t_ent))
                      (setq line_old (if (< (dist2d pt line_p1) (dist2d pt line_p2)) line_p1 line_p2))
                      (force_line_to_pt t_ent line_old pt2)
                     )
                     
                     (T
                      (if (= t_type "T_JUNC")
                        (progn
                          (princ "\n[T자 접합] 맞닿는 벽은 그대로 두고 선을 연장했습니다.")
                          (update_endpoint ent pt t_pt)
                        )
                        (progn
                          (princ "\n[L자 모서리] 모서리를 결합했습니다.")
                          (update_endpoint ent pt t_pt)
                          (setq p3 (vlax-curve-getStartPoint t_ent) p4 (vlax-curve-getEndPoint t_ent))
                          (setq pt2 (if (< (dist2d p3 t_pt) (dist2d p4 t_pt)) p3 p4))
                          (update_endpoint t_ent pt2 t_pt)
                        )
                      )
                     )
                   )
                 )
                 (princ "\n주변에서 결합할 선을 찾지 못했습니다. 직접 고쳐 주세요.")
               )
               (setq *fdl_current_index* (1+ *fdl_current_index*))
              )
              
              ((= ans "Delete")
               (if (entget ent) (entdel ent))
               (princ "\n잔선을 삭제했습니다.")
               (setq *fdl_current_index* (1+ *fdl_current_index*))
              )
              
              ((= ans "Manual")
               (setq *fdl_current_index* (1+ *fdl_current_index*))
               (setq loop nil)
               (princ "\n수동 모드입니다. (고친 뒤 Space로 이어서 진행)")
              )
              ((= ans "Next")
               (setq *fdl_current_index* (1+ *fdl_current_index*))
              )
              ((= ans "eXit")
               (setq loop nil)
               (sssetfirst nil nil)
               (princ "\n검사를 멈췄습니다.")
              )
            )
          )
        )
      )
      
      (if (>= *fdl_current_index* (length *fdl_error_list*))
        (progn
          (princ "\n[완료] 모든 오류를 검사하고 고쳤습니다.")
          (setq *fdl_error_list* nil)
          (sssetfirst nil nil)
        )
      )
    )
  )
  (princ)
)