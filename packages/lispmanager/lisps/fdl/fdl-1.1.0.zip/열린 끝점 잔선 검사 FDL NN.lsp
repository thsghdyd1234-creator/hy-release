;;; ==============================================================================
;;;  FDL — 열린 끝점 · 짧은 잔선 찾기  /  NN — 찾은 곳을 하나씩 고치기
;;;
;;;  FDL: 틈(기본 50)과 잔선 길이(기본 5)를 넣고 검사할 객체를 고른다 (Enter = 지금 공간 전체).
;;;   · 검사 대상: 선(LINE)·호(ARC) — 꺼진·동결·잠긴 레이어는 빼고
;;;   · 닿았는지 볼 상대: 선·호·폴리선·원·타원·스플라인 모두 (고르지 않은 것도, 꺼진·동결 레이어는 빼고)
;;;   · 열린 끝점 = 끝점에서 가장 가까운 상대까지 평면 거리가 0.001 넘고 틈 이하 / 짧은 잔선 = 길이가 잔선 길이 이하
;;;   칸(격자)으로 나눠 가까운 것만 재므로 큰 도면도 빠르다.
;;;  NN: 찾은 곳마다 확대해서 [결합(F)/삭제(D)/수동(M)/다음(N)/이전(B)/종료(X)]
;;;   · 기본(Enter·Space): 열린 끝점이면 결합, 잔선이면 삭제
;;;   · 결합: T자(상대의 가운데)면 이 선만 늘이거나 줄이고, 모서리면 두 끝을 만나는 점으로. 호는 호 위에서만 움직인다.
;;;   · 이미 고쳐진 곳은 확대하지 않고 건너뛴다. 고칠 때마다 실행 취소 한 번(U). 다 보면 처음 화면으로.
;;;   · 수동(M): 그 자리에서 직접 고친 뒤 NN 을 입력하면 이어서 한다.
;;; ==============================================================================

(defun fdl:d2 (a b) (distance (list (car a) (cadr a)) (list (car b) (cadr b))))
(defun fdl:floor (x / n) (setq n (fix x)) (if (and (< x 0) (/= x n)) (1- n) n))
(defun fdl:istr (i) (if (< i 0) (strcat "M" (itoa (- i))) (itoa i)))
(defun fdl:key (ix iy) (read (strcat "FDL_G" (fdl:istr ix) "_" (fdl:istr iy))))
(defun fdl:clear (syms) (foreach s syms (set s nil)))

;; 점 p 에서 선분 a-b 까지 평면 거리
(defun fdl:segd (p a b / dx dy l2 u)
  (setq dx (- (car b) (car a)) dy (- (cadr b) (cadr a)) l2 (+ (* dx dx) (* dy dy)))
  (setq u (if (> l2 1e-24) (/ (+ (* (- (car p) (car a)) dx) (* (- (cadr p) (cadr a)) dy)) l2) 0.0))
  (setq u (max 0.0 (min 1.0 u)))
  (fdl:d2 p (list (+ (car a) (* u dx)) (+ (cadr a) (* u dy)))))

;; 곡선 → 평면 선분들 (선은 그대로, 나머지는 잘게)
(defun fdl:segs (e gap / o typ pts n i j k len step b out)
  (setq o (vlax-ename->vla-object e) typ (cdr (assoc 0 (entget e))))
  (cond
    ((= typ "LINE") (setq pts (list (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o))))
    ((= typ "LWPOLYLINE")
     (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
     (while (< i n)
       (setq b (vla-GetBulge o i)
             k (if (equal b 0.0 1e-12) 1
                 (min 64 (max 2 (fix (+ 1 (/ (- (vlax-curve-getDistAtParam o (1+ i)) (vlax-curve-getDistAtParam o i)) gap)))))))
       (setq j 0)
       (while (< j k)
         (setq pts (cons (vlax-curve-getPointAtParam o (+ i (/ (float j) k))) pts) j (1+ j)))
       (setq i (1+ i)))
     (setq pts (reverse (cons (vlax-curve-getEndPoint o) pts))))
    (T
     (setq len (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o))
           step (max gap (/ len 512.0) 1e-6)
           k (max 2 (fix (+ 1 (/ len step)))) i 0)
     (repeat (1+ k)
       (setq pts (cons (vlax-curve-getPointAtDist o (min len (* len (/ (float i) k)))) pts) i (1+ i)))
     (setq pts (reverse pts))))
  (setq out nil)
  (while (cdr pts)
    (if (and (car pts) (cadr pts)) (setq out (cons (list (car pts) (cadr pts)) out)))
    (setq pts (cdr pts)))
  out)

;; 선분 a-b 가 지나는 칸마다 항목을 넣는다 (격자 걷기)
(defun fdl:reg (a b c item / ix iy ex ey dx dy sx sy tdx tdy tmx tmy guard)
  (setq ix (fdl:floor (/ (car a) c)) iy (fdl:floor (/ (cadr a) c))
        ex (fdl:floor (/ (car b) c)) ey (fdl:floor (/ (cadr b) c))
        dx (- (car b) (car a)) dy (- (cadr b) (cadr a))
        sx (if (> dx 0) 1 -1) sy (if (> dy 0) 1 -1)
        tdx (if (/= dx 0) (abs (/ c dx)) 1e300) tdy (if (/= dy 0) (abs (/ c dy)) 1e300)
        tmx (if (/= dx 0) (/ (- (* (+ ix (if (> dx 0) 1 0)) c) (car a)) dx) 1e300)
        tmy (if (/= dy 0) (/ (- (* (+ iy (if (> dy 0) 1 0)) c) (cadr a)) dy) 1e300)
        guard (+ 3 (abs (- ex ix)) (abs (- ey iy))))
  (fdl:put ix iy item)
  (while (and (> (setq guard (1- guard)) 0) (not (and (= ix ex) (= iy ey))))
    (if (< tmx tmy)
      (setq ix (+ ix sx) tmx (+ tmx tdx))
      (setq iy (+ iy sy) tmy (+ tmy tdy)))
    (fdl:put ix iy item)))

(defun fdl:put (ix iy item / s v)
  (setq s (fdl:key ix iy) v (vl-symbol-value s))
  (if (not (eq (car v) item))
    (progn (if (null v) (setq syms (cons s syms))) (set s (cons item v)))))

;; 격자로 끝점 p 에서 가장 가까운 상대까지 거리 (자기 자신 빼고)
(defun fdl:near (p self c / ix iy best seen d dx dy q)
  (setq ix (fdl:floor (/ (car p) c)) iy (fdl:floor (/ (cadr p) c)) best 1e300)
  (foreach dx '(-1 0 1)
    (foreach dy '(-1 0 1)
      (foreach it (vl-symbol-value (fdl:key (+ ix dx) (+ iy dy)))
        (if (and (not (eq (car it) self)) (not (member it seen)))
          (progn
            (setq seen (cons it seen))
            (if (cdr it)
              (setq d (fdl:segd p (cadr it) (caddr it)))
              (setq q (vlax-curve-getClosestPointToProjection (car it) p '(0.0 0.0 1.0))
                    d (if q (fdl:d2 p q) 1e300)))
            (if (< d best) (setq best d)))))))
  best)

;; NN 용: 지금 도면 기준으로 가까운 상대까지 거리 (FDL 때 적어 둔 범위로 먼저 거름)
(defun fdl:live-near (p self / gap best q d)
  (setq gap (* 2.0 *fdl_gap*) best 1e300)
  (foreach t5 *fdl_targets*
    (if (and (not (eq (car t5) self))
             (<= (- (nth 1 t5) gap) (car p) (+ (nth 3 t5) gap))
             (<= (- (nth 2 t5) gap) (cadr p) (+ (nth 4 t5) gap))
             (entget (car t5)))
      (progn
        (setq q (vlax-curve-getClosestPointToProjection (car t5) p '(0.0 0.0 1.0))
              d (if q (fdl:d2 p q) 1e300))
        (if (< d best) (setq best d)))))
  best)

(defun fdl:len (e / o) (setq o (vlax-ename->vla-object e)) (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o)))
(defun fdl:near-end (e p / a b)
  (setq a (vlax-curve-getStartPoint e) b (vlax-curve-getEndPoint e))
  (if (< (fdl:d2 a p) (fdl:d2 b p)) a b))

;; 이미 고쳐졌는지 (지워짐 · 끝이 옮겨짐 · 닿음 · 잔선이 길어짐)
(defun fdl:resolved (e p kind / cur)
  (cond
    ((not (entget e)) T)
    ((= kind "short") (> (fdl:len e) *fdl_short*))
    ((> (fdl:d2 (setq cur (fdl:near-end e p)) p) 0.001) T)
    ((<= (fdl:live-near cur e) 0.001) T)))

;; 확대한 뒤 화면에서 새로 그린 선까지 한 번 더 (걸침 선택은 보이는 곳만 잡음)
(defun fdl:closed-on-screen (e p / u ss i x q ok)
  (setq u (trans p 0 1))
  (if (setq ss (ssget "_C" (list (- (car u) 0.01) (- (cadr u) 0.01)) (list (+ (car u) 0.01) (+ (cadr u) 0.01))
                      '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,CIRCLE,ELLIPSE,SPLINE"))))
    (progn
      (setq i 0)
      (while (and (not ok) (< i (sslength ss)))
        (setq x (ssname ss i))
        (if (not (eq x e))
          (progn
            (setq q (vlax-curve-getClosestPointToProjection x p '(0.0 0.0 1.0)))
            (if (and q (<= (fdl:d2 p q) 0.001)) (setq ok T))))
        (setq i (1+ i)))))
  ok)

;; 붙일 곳: 상대의 끝점(모서리) 또는 늘인 교점(상대 끝 근처면 모서리, 가운데면 T자) 중 가장 가까운 것
(defun fdl:target (p self / gap best bd o1 o2 a b pts i q d typ)
  (setq gap *fdl_gap* bd (* gap 1.000001) o1 (vlax-ename->vla-object self))
  (foreach t5 *fdl_targets*
    (if (and (not (eq (car t5) self))
             (<= (- (nth 1 t5) gap) (car p) (+ (nth 3 t5) gap))
             (<= (- (nth 2 t5) gap) (cadr p) (+ (nth 4 t5) gap))
             (entget (car t5)))
      (progn
        (setq o2 (vlax-ename->vla-object (car t5)))
        (if (not (vlax-curve-isClosed o2))
          (foreach q (list (vlax-curve-getStartPoint o2) (vlax-curve-getEndPoint o2))
            (if (<= (setq d (fdl:d2 p q)) bd) (setq bd d best (list (car t5) q "CORNER")))))
        (setq pts (vl-catch-all-apply 'vlax-invoke (list o1 'IntersectWith o2 3)))
        (if (and pts (not (vl-catch-all-error-p pts)))
          (progn
            (setq i 0)
            (while (< i (length pts))
              (setq q (list (nth i pts) (nth (1+ i) pts) (nth (+ i 2) pts)))
              (if (<= (setq d (fdl:d2 p q)) bd)
                (setq bd d
                      typ (if (and (not (vlax-curve-isClosed o2))
                                   (or (<= (fdl:d2 q (vlax-curve-getStartPoint o2)) gap)
                                       (<= (fdl:d2 q (vlax-curve-getEndPoint o2)) gap)))
                            "CORNER" "T_JUNC")
                      best (list (car t5) q typ)))
              (setq i (+ i 3))))))))
  best)

;; 선·호의 끝(old 에 가까운 쪽)을 new 로 — 수평·수직선은 그 방향 그대로, 호는 호 위에서(호의 좌표계 각도)
(defun fdl:move-end (e old new / o typ p1 p2 st c q)
  (setq o (vlax-ename->vla-object e) typ (cdr (assoc 0 (entget e)))
        p1 (vlax-curve-getStartPoint o) p2 (vlax-curve-getEndPoint o)
        st (< (fdl:d2 p1 old) (fdl:d2 p2 old)))
  (if (= typ "LINE")
    (progn
      (if (equal (cadr p1) (cadr p2) 1e-8) (setq new (list (car new) (cadr p1))))
      (if (equal (car p1) (car p2) 1e-8) (setq new (list (car p1) (cadr new))))
      (vlax-put o (if st 'StartPoint 'EndPoint) (list (car new) (cadr new) (caddr (if st p1 p2)))))
    (progn
      (setq c (vlax-get o 'Center)
            q (trans (list (car new) (cadr new) (caddr c)) 0 e)
            c (trans c 0 e))
      (vlax-put o (if st 'StartAngle 'EndAngle) (angle c q)))))

(defun fdl:fix (e p tg / te tp tt t1 t2 r)
  (if (null tg)
    (princ "\n붙일 곳을 찾지 못했습니다. 직접 고치세요.")
    (progn
      (setq te (car tg) tp (cadr tg) tt (caddr tg)
            t1 (cdr (assoc 0 (entget e))) t2 (cdr (assoc 0 (entget te))))
      (setq r (vl-catch-all-apply
                (function
                  (lambda ()
                    (cond
                      ((= tt "T_JUNC") (fdl:move-end e p tp))
                      ((and (= t1 "LINE") (= t2 "ARC")) (fdl:move-end e p (fdl:near-end te p)))
                      ((and (= t1 "ARC") (= t2 "LINE")) (fdl:move-end te (fdl:near-end te p) (fdl:near-end e p)))
                      ((member t2 '("LINE" "ARC")) (fdl:move-end e p tp) (fdl:move-end te (fdl:near-end te tp) tp))
                      (T (fdl:move-end e p tp)))))))
      (if (vl-catch-all-error-p r)
        (princ (strcat "\n[주의] 고치지 못했습니다 — " (vl-catch-all-error-message r)))
        (princ (if (= tt "T_JUNC") "\n[T자] 맞닿는 선은 그대로 두고 이 선만 늘이거나 줄였습니다."
                 "\n[모서리] 두 끝을 만나는 점으로 옮겼습니다."))))))

(defun fdl:space () (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1)) (getvar "CTAB") "Model"))

;;; ------------------------------------------------------------------------------
(defun c:FDL ( / *error* gap short ss all cands syms lays e ed L o len c i mn mx bb lo hi area d items rowh cand)
  (defun *error* (msg)
    (fdl:clear syms)
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (if (null *fdl_gap*) (setq *fdl_gap* 50.0))
  (if (null *fdl_short*) (setq *fdl_short* 5.0))
  (initget 6)
  (if (setq gap (getdist (strcat "\n[열린 끝점] 찾을 최대 틈 <" (rtos *fdl_gap* 2 2) ">: "))) (setq *fdl_gap* gap))
  (initget 4)
  (if (setq short (getdist (strcat "\n[짧은 잔선] 잔선으로 볼 최대 길이 (0 = 안 찾음) <" (rtos *fdl_short* 2 2) ">: ")))
    (setq *fdl_short* short))
  (setq gap *fdl_gap* short *fdl_short*)
  (prompt "\n검사할 객체를 고르세요 (Enter = 지금 공간 전체): ")
  (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,CIRCLE,ELLIPSE,SPLINE"))))
  ;; 레이어 상태: (이름 보임 잠김)
  (setq L (tblnext "LAYER" T))
  (while L
    (setq lays (cons (list (strcase (cdr (assoc 2 L))) (and (> (cdr (assoc 62 L)) 0) (= 0 (logand 1 (cdr (assoc 70 L)))))
                           (= 4 (logand 4 (cdr (assoc 70 L))))) lays)
          L (tblnext "LAYER")))
  ;; 상대 = 지금 공간의 보이는 곡선 전부, 검사 대상 = 고른 것(없으면 전부) 중 선·호 (잠긴 레이어 빼고)
  (setq all (ssget "_X" (list '(0 . "LINE,ARC,LWPOLYLINE,POLYLINE,CIRCLE,ELLIPSE,SPLINE") (cons 410 (fdl:space))))
        i 0 *fdl_items* nil *fdl_index* 0 *fdl_targets* nil)
  (while (and all (< i (sslength all)))
    (setq e (ssname all i) ed (entget e) L (cdr (assoc (strcase (cdr (assoc 8 ed))) lays)))
    (if (and (car L) (/= 1 (cdr (assoc 60 ed)))
             (not (vl-catch-all-error-p (setq bb (vl-catch-all-apply 'vla-GetBoundingBox
                                                                  (list (vlax-ename->vla-object e) 'mn 'mx))))))
      (progn
        (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx)
              *fdl_targets* (cons (list e (car mn) (cadr mn) (car mx) (cadr mx)) *fdl_targets*))
        (if (and (not (cadr L)) (member (cdr (assoc 0 ed)) '("LINE" "ARC")) (or (null ss) (ssmemb e ss)))
          (setq cands (cons e cands)
                lo (if lo (list (min (car lo) (car mn)) (min (cadr lo) (cadr mn))) (list (car mn) (cadr mn)))
                hi (if hi (list (max (car hi) (car mx)) (max (cadr hi) (cadr mx))) (list (car mx) (cadr mx)))))))
    (setq i (1+ i)))
  (cond
    ((null cands) (setq *fdl_targets* nil) (princ "\n검사할 선·호가 없습니다 (꺼진·동결·잠긴 레이어는 뺍니다)."))
    (T
     (princ (strcat "\n선·호 " (itoa (length cands)) "개를 검사하는 중..."))
     ;; 범위 (검사 대상 전체 + 틈) 안의 상대만
     (setq lo (list (- (car lo) gap) (- (cadr lo) gap)) hi (list (+ (car hi) gap) (+ (cadr hi) gap))
           *fdl_targets* (vl-remove-if-not
                           '(lambda (t5) (and (<= (nth 1 t5) (car hi)) (>= (nth 3 t5) (car lo))
                                              (<= (nth 2 t5) (cadr hi)) (>= (nth 4 t5) (cadr lo))))
                           *fdl_targets*)
           area (* (- (car hi) (car lo)) (- (cadr hi) (cadr lo)))
           c (max (* 2.0 gap) (/ (sqrt (/ area (max 1 (length *fdl_targets*)))) 4.0)
                  (/ (max (- (car hi) (car lo)) (- (cadr hi) (cadr lo))) 200000.0)))
     ;; 격자에 넣기 (선은 끝점까지 적어 두고 직접 잼)
     (foreach t5 *fdl_targets*
       (setq e (car t5))
       (foreach s (fdl:segs e gap)
         (fdl:reg (car s) (cadr s) c
                  (if (= (cdr (assoc 0 (entget e))) "LINE") (list e (car s) (cadr s)) (list e)))))
     ;; 검사
     (foreach e cands
       (setq o (vlax-ename->vla-object e) len (fdl:len e))
       (if (and (> short 0) (<= len short))
         (setq items (cons (list e (vlax-curve-getStartPoint o) "short") items))
         (foreach p (list (vlax-curve-getStartPoint o) (vlax-curve-getEndPoint o))
           (setq d (fdl:near p e c))
           (if (and (> d 0.001) (<= d gap)) (setq items (cons (list e p "open") items))))))
     (fdl:clear syms)
     (setq syms nil)
     ;; 위 줄부터 왼쪽에서 오른쪽으로
     (setq rowh (* 40.0 gap)
           *fdl_items* (vl-sort items
                                (function (lambda (a b / ra rb)
                                            (setq ra (fdl:floor (/ (cadr (cadr a)) rowh)) rb (fdl:floor (/ (cadr (cadr b)) rowh)))
                                            (if (= ra rb) (< (car (cadr a)) (car (cadr b))) (> ra rb)))))
           *fdl_view* (list (trans (getvar "VIEWCTR") 1 0) (getvar "VIEWSIZE")))
     (if *fdl_items*
       (progn
         (princ (strcat "\n[알림] 열린 끝점 " (itoa (length (vl-remove-if-not '(lambda (x) (= (caddr x) "open")) *fdl_items*)))
                        "곳 · 짧은 잔선 " (itoa (length (vl-remove-if-not '(lambda (x) (= (caddr x) "short")) *fdl_items*)))
                        "개를 찾았습니다."))
         (c:NN))
       (princ "\n[완료] 열린 끝점이나 짧은 잔선이 없습니다."))))
  (princ))

;;; ------------------------------------------------------------------------------
(defun c:NN ( / *error* doc sv tot loop item e p kind tg hl ans j)
  (defun *error* (msg)
    (if (and hl (entget hl)) (redraw hl 4))
    (sssetfirst nil nil)
    (foreach v sv (setvar (car v) (cdr v)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sv (mapcar '(lambda (v) (cons v (getvar v))) '("CMDECHO")))
  (setvar "CMDECHO" 0)
  (if (null *fdl_index*) (setq *fdl_index* 0))
  (if (not *fdl_items*)
    (princ "\n찾은 곳이 없습니다. FDL 을 먼저 실행하세요.")
    (progn
      (setq tot (length *fdl_items*) loop T)
      (while (and loop (< *fdl_index* tot))
        (setq item (nth *fdl_index* *fdl_items*) e (car item) p (cadr item) kind (caddr item))
        (cond
          ((fdl:resolved e p kind) (setq *fdl_index* (1+ *fdl_index*)))
          ((progn
             (command "_.ZOOM" "_C" "_non" (trans p 0 1) (max 250.0 (* 6.0 *fdl_gap*)))
             (and (= kind "open") (fdl:closed-on-screen e p)))
           (setq *fdl_index* (1+ *fdl_index*)))
          (T
           (setq tg (fdl:target p e))
           (sssetfirst nil (ssadd e))
           (if tg (redraw (setq hl (car tg)) 3))
           (initget "Fix Delete Manual Next Back eXit")
           (setq ans (getkword (strcat "\n[" (itoa (1+ *fdl_index*)) "/" (itoa tot) "] "
                                       (if (= kind "short") "짧은 잔선" "열린 끝점")
                                       (cond ((null tg) " (붙일 곳 없음)") ((= (caddr tg) "T_JUNC") " (T자)") (" (모서리)"))
                                       " [결합(F)/삭제(D)/수동(M)/다음(N)/이전(B)/종료(X)] <"
                                       (if (= kind "short") "삭제" "결합") ">: ")))
           (if hl (progn (redraw hl 4) (setq hl nil)))
           (sssetfirst nil nil)
           (if (null ans) (setq ans (if (= kind "short") "Delete" "Fix")))
           (cond
             ((= ans "Fix")
              (vla-StartUndoMark doc)
              (fdl:fix e p tg)
              (vla-EndUndoMark doc)
              (setq *fdl_index* (1+ *fdl_index*)))
             ((= ans "Delete")
              (if (entget e) (entdel e))
              (princ "\n이 선을 지웠습니다.")
              (setq *fdl_index* (1+ *fdl_index*)))
             ((= ans "Manual")
              (setq *fdl_index* (1+ *fdl_index*) loop nil)
              (princ "\n직접 고친 뒤 NN 을 입력하면 이어서 합니다."))
             ((= ans "Next") (setq *fdl_index* (1+ *fdl_index*)))
             ((= ans "Back")
              (setq j (1- *fdl_index*))
              (while (and (>= j 0) (apply 'fdl:resolved (nth j *fdl_items*))) (setq j (1- j)))
              (if (>= j 0) (setq *fdl_index* j) (princ "\n앞에 남은 곳이 없습니다.")))
             (T (setq loop nil) (princ "\n검사를 멈췄습니다. NN 을 입력하면 이어서 합니다."))))))
      (if (>= *fdl_index* tot)
        (progn
          (princ (strcat "\n[완료] " (itoa tot) "곳을 모두 살폈습니다."))
          (setq *fdl_items* nil *fdl_index* 0)
          (if *fdl_view* (command "_.ZOOM" "_C" "_non" (trans (car *fdl_view*) 0 1) (cadr *fdl_view*)))))))
  (foreach v sv (setvar (car v) (cdr v)))
  (princ))

(princ)
