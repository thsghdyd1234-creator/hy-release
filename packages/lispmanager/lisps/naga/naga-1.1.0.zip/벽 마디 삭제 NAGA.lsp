;;; ==============================================================================
;;;  NAGA — 벽 마디(짧은 칸막이 선) 한꺼번에 지우기
;;;
;;;  모드 [단면(1)/평면(2)], 지울 마디의 최대 길이, (단면) 짝 거리를 정하고(모두 기억) 영역의 선을 고르면,
;;;  짧은 수직·수평선 중 양 끝이 벽 사이에 걸린 '마디'를 찾아 지운다. 같은 방향의 짝 선이 짝 거리 안에 겹쳐 있어야 지운다
;;;  (짝 거리를 키울수록 더 많이 지움). 마디는 따로 끊겨 있어야 한다 (BXI 를 먼저).
;;;   · 수평·수직은 ±3° 안만 (예전: 세로는 ±18° 까지 수직으로 봄). 평면 모드는 가로·세로에 같은 규칙.
;;;   · 이웃 선은 지금 공간 전체에서 범위로 찾는다 (화면·UCS 와 상관없음). 잠긴 레이어는 지우지 않는다.
;;;   · 한 번 실행 = 실행 취소 한 번(U).
;;; ==============================================================================

;; 선 → (ename 시작 끝 minX maxX minY maxY)
(defun naga:item (e / d s t2)
  (setq d (entget e) s (cdr (assoc 10 d)) t2 (cdr (assoc 11 d)))
  (list e s t2 (min (car s) (car t2)) (max (car s) (car t2)) (min (cadr s) (cadr t2)) (max (cadr s) (cadr t2))))

(defun naga:horiz-p (it) (equal (abs (sin (angle (cadr it) (caddr it)))) 0.0 0.05))
(defun naga:vert-p (it) (equal (abs (cos (angle (cadr it) (caddr it)))) 0.0 0.05))

;; 점 pt 에 닿거나 지나가는 가로·세로 선 수 (끝에 닿으면 1, 몸통을 지나가면 2) → (가로 세로)
(defun naga:paths (pt ex cx cy / xc yc px py)
  (setq xc 0 yc 0 px (car pt) py (cadr pt))
  (foreach it cx
    (if (and (not (eq (car it) ex)) (>= py (- (nth 5 it) 0.1)) (<= py (+ (nth 6 it) 0.1))
             (>= px (- (nth 3 it) 0.1)) (<= px (+ (nth 4 it) 0.1)))
      (setq xc (+ xc (if (and (> (distance pt (cadr it)) 0.1) (> (distance pt (caddr it)) 0.1)) 2 1)))))
  (foreach it cy
    (if (and (not (eq (car it) ex)) (>= px (- (nth 3 it) 0.1)) (<= px (+ (nth 4 it) 0.1))
             (>= py (- (nth 5 it) 0.1)) (<= py (+ (nth 6 it) 0.1)))
      (setq yc (+ yc (if (and (> (distance pt (cadr it)) 0.1) (> (distance pt (caddr it)) 0.1)) 2 1)))))
  (list xc yc))

;; 같은 방향 짝 선이 거리 lim 안에서 겹치는지 (mode "Y" = 세로선)
(defun naga:partner (pa pb lim ex mode cache / v1 v2 v3 found d)
  (if (= mode "Y")
    (setq v1 (car pa) v2 (min (cadr pa) (cadr pb)) v3 (max (cadr pa) (cadr pb)))
    (setq v1 (cadr pa) v2 (min (car pa) (car pb)) v3 (max (car pa) (car pb))))
  (foreach it cache
    (if (and (not found) (not (eq (car it) ex)))
      (progn
        (setq d (if (= mode "Y") (abs (- v1 (nth 3 it))) (abs (- v1 (nth 5 it)))))
        (if (and (> d 0.1) (<= d lim)
                 (> v3 (if (= mode "Y") (nth 5 it) (nth 3 it))) (< v2 (if (= mode "Y") (nth 6 it) (nth 4 it))))
          (setq found T)))))
  found)

;; 지울 마디인지 — 자기 축(a)과 다른 축(b)의 길 수로 (단면 모드는 예전 규칙 그대로, 평면 모드는 가로·세로 같은 규칙)
(defun naga:trash-p (aa ba ab bb plan)
  (cond ((or (= (+ aa ba) 0) (= (+ ab bb) 0)) T)
        ((and (>= ba 2) (>= bb 2)) T)
        ((or (and (>= ba 1) (>= aa 1) (>= bb 2)) (and (>= bb 1) (>= ab 1) (>= ba 2))) T)
        ((and plan (>= aa 1) (>= ba 1) (>= ab 1) (>= bb 1)) T)))

(defun naga:space ()
  (if (or (= (getvar "TILEMODE") 1) (/= (getvar "CVPORT") 1)) "Model" (getvar "CTAB")))

(defun c:NAGA ( / *error* doc undo_open tmp lim ss all i it lo hi cx cy del dy dx na nb lk)
  (defun *error* (msg)
    (if undo_open (progn (vla-EndUndoMark doc) (setq undo_open nil)))
    (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
      (princ (strcat "\n[오류] " msg)))
    (princ))
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (null *cba_mode*) (setq *cba_mode* "1"))
  (if (null *cba_threshold*) (setq *cba_threshold* 201.0))
  (if (null *cba_max_thick*) (setq *cba_max_thick* 600.0))
  (initget "1 2")
  (if (setq tmp (getkword (strcat "\n모드 [단면(1)/평면(2)] <" *cba_mode* ">: "))) (setq *cba_mode* tmp))
  (initget 6)
  (if (setq tmp (getdist (strcat "\n지울 마디의 최대 길이 <" (rtos *cba_threshold* 2 2) ">: "))) (setq *cba_threshold* tmp))
  (if (= *cba_mode* "1")
    (progn
      (initget 6)
      (if (setq tmp (getdist (strcat "\n짝 거리 — 이 안에 평행한 짝 선이 있어야 지움 (키울수록 더 많이) <" (rtos *cba_max_thick* 2 2) ">: ")))
        (setq *cba_max_thick* tmp))
      (setq lim *cba_max_thick*))
    (setq lim *cba_threshold*))
  (prompt "\n정리할 영역의 선을 고르세요: ")
  (if (null (setq ss (ssget '((0 . "LINE")))))
    (princ "\n고른 선이 없습니다.")
    (progn
      ;; 고른 범위 + 짝 거리만큼 넓힌 상자 안의 선 (지금 공간 전체에서)
      (setq i 0)
      (while (< i (sslength ss))
        (setq it (naga:item (ssname ss i))
              lo (if lo (list (min (car lo) (nth 3 it)) (min (cadr lo) (nth 5 it))) (list (nth 3 it) (nth 5 it)))
              hi (if hi (list (max (car hi) (nth 4 it)) (max (cadr hi) (nth 6 it))) (list (nth 4 it) (nth 6 it)))
              i (1+ i)))
      (setq lo (mapcar '(lambda (v) (- v lim 10.0)) lo) hi (mapcar '(lambda (v) (+ v lim 10.0)) hi))
      (if (setq all (ssget "_X" (list '(0 . "LINE") (cons 410 (naga:space)))))
        (progn
          (setq i 0)
          (while (< i (sslength all))
            (setq it (naga:item (ssname all i)))
            (if (and (<= (nth 3 it) (car hi)) (>= (nth 4 it) (car lo)) (<= (nth 5 it) (cadr hi)) (>= (nth 6 it) (cadr lo)))
              (cond ((naga:horiz-p it) (setq cx (cons it cx)))
                    ((naga:vert-p it) (setq cy (cons it cy)))))
            (setq i (1+ i)))))
      ;; 1단계: 세로 마디
      (setq i 0)
      (while (< i (sslength ss))
        (setq it (naga:item (ssname ss i)))
        (if (and (naga:vert-p it) (<= (distance (cadr it) (caddr it)) *cba_threshold*))
          (progn
            (setq na (naga:paths (cadr it) (car it) cx cy) nb (naga:paths (caddr it) (car it) cx cy))
            ;; 자기 축 = 세로(y), 다른 축 = 가로(x)
            (if (and (naga:trash-p (cadr na) (car na) (cadr nb) (car nb) (= *cba_mode* "2"))
                     (naga:partner (cadr it) (caddr it) lim (car it) "Y" cy))
              (setq dy (cons (car it) dy)))))
        (setq i (1+ i)))
      (setq cy (vl-remove-if '(lambda (x) (member (car x) dy)) cy))
      ;; 2단계: 가로 마디
      (setq i 0)
      (while (< i (sslength ss))
        (setq it (naga:item (ssname ss i)))
        (if (and (not (member (car it) dy)) (naga:horiz-p it) (<= (distance (cadr it) (caddr it)) *cba_threshold*))
          (progn
            (setq na (naga:paths (cadr it) (car it) cx cy) nb (naga:paths (caddr it) (car it) cx cy))
            (if (and (naga:trash-p (car na) (cadr na) (car nb) (cadr nb) T)
                     (naga:partner (cadr it) (caddr it) lim (car it) "X" cx))
              (setq dx (cons (car it) dx)))))
        (setq i (1+ i)))
      (vla-StartUndoMark doc)
      (setq undo_open T lk 0)
      (foreach e (append dy dx) (if (not (entdel e)) (setq lk (1+ lk))))
      (vla-EndUndoMark doc)
      (setq undo_open nil)
      (princ (strcat "\n[완료] " (if (= *cba_mode* "1") "단면" "평면") " 모드: 세로 마디 " (itoa (length dy)) "개, 가로 마디 " (itoa (length dx))
                     "개를 지웠습니다" (if (> lk 0) (strcat " (잠긴 레이어 " (itoa lk) "개는 그대로)") "") "."))))
  (princ))

(princ)
