(defun c:NAGA ( / doc tmp active_thick ssUser ssAll j e d pS pE ang is_X is_Y 
                 cache_X cache_Y del_Y del_X count_Y count_X i ent nA nB xa xb ya yb is_trash
                 min_x min_y max_x max_y pt1 pt2 item )
  (vl-load-com)
  (prompt "\n[NAGA 벽 마디 삭제]")

  ;; 전역 변수 초기화
  (if (null *cba_mode*) (setq *cba_mode* "1"))
  (if (null *cba_threshold*) (setq *cba_threshold* 201.0))
  (if (null *cba_max_thick*) (setq *cba_max_thick* 600.0))

  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (vl-catch-all-apply 'vla-EndUndoMark (list doc))
  (vla-StartUndoMark doc)

  (initget "1 2")
  (setq tmp (getkword (strcat "\n모드 선택 [1: 단면(기둥·두꺼운 벽 보호) / 2: 평면(내부 잔선만)] <" *cba_mode* ">: ")))
  (if tmp (setq *cba_mode* tmp))

  (setq tmp (getreal (strcat "\n삭제할 마디의 최대 길이 (뚫을 폭) <" (vl-princ-to-string *cba_threshold*) ">: ")))
  (if tmp (setq *cba_threshold* tmp))

  (if (= *cba_mode* "1")
    (progn
      (setq tmp (getreal (strcat "\n보호할 최대 벽체 두께 (기둥 등) <" (vl-princ-to-string *cba_max_thick*) ">: ")))
      (if tmp (setq *cba_max_thick* tmp))
      (setq active_thick *cba_max_thick*)
    )
    (progn
      (setq active_thick *cba_threshold*)
      (princ (strcat "\n[평면 모드] 기둥 보호를 끕니다. (보호 한계값 " (vl-princ-to-string active_thick) " 자동 적용)"))
    )
  )

  (prompt "\n정리할 영역을 선택하세요: ")
  (if (setq ssUser (ssget '((0 . "LINE"))))
    (progn
      (princ "\n선택 영역의 선을 읽는 중...")
      
      ;; 선택 영역의 경계 상자(최소/최대 좌표) 계산
      (setq min_x 1e99 min_y 1e99 max_x -1e99 max_y -1e99 i 0)
      (while (< i (sslength ssUser))
        (setq d (entget (ssname ssUser i)) p1 (cdr (assoc 10 d)) p2 (cdr (assoc 11 d)))
        (setq min_x (min min_x (car p1) (car p2)) min_y (min min_y (cadr p1) (cadr p2))
              max_x (max max_x (car p1) (car p2)) max_y (max max_y (cadr p1) (cadr p2)))
        (setq i (1+ i))
      )
      
      ;; 경계 상자를 보호 두께(active_thick) + 여유(10.0)만큼 넓혀 주변 선만 걸치기 선택
      (setq pt1 (list (- min_x active_thick 10.0) (- min_y active_thick 10.0))
            pt2 (list (+ max_x active_thick 10.0) (+ max_y active_thick 10.0)))
      (setq ssAll (ssget "C" pt1 pt2 '((0 . "LINE"))))
      
      ;; 선 목록을 X축·Y축으로 나눠 저장
      (setq cache_X nil cache_Y nil j 0)
      (if ssAll
        (while (< j (sslength ssAll))
          (setq e (ssname ssAll j) d (entget e))
          (setq pS (cdr (assoc 10 d)) pE (cdr (assoc 11 d)) ang (angle pS pE))
          (setq is_X (if (equal (abs (sin ang)) 0.0 0.05) T nil))
          (setq is_Y (if (equal (abs (sin ang)) 1.0 0.05) T nil))
          
          (setq item (list e pS pE 
                           (min (car pS) (car pE)) (max (car pS) (car pE))
                           (min (cadr pS) (cadr pE)) (max (cadr pS) (cadr pE))))
          (if is_X (setq cache_X (cons item cache_X)))
          (if is_Y (setq cache_Y (cons item cache_Y)))
          (setq j (1+ j))
        )
      )

      (setq del_Y (list) del_X (list) count_Y 0 count_X 0)

      ;; 축별로 나눈 목록으로 검사
      (defun Get-Paths-Fast (pt exclude_ent c_X c_Y / x_cnt y_cnt px py item e pS pE minX maxX minY maxY dS dE)
        (setq x_cnt 0 y_cnt 0 px (car pt) py (cadr pt))
        
        ;; X축 리스트 검사
        (foreach item c_X
          (setq e (car item))
          (if (not (equal e exclude_ent))
            (progn
              (setq pS (cadr item) pE (caddr item) minX (nth 3 item) maxX (nth 4 item) minY (nth 5 item) maxY (nth 6 item))
              (if (and (>= py (- minY 0.1)) (<= py (+ maxY 0.1)) (>= px (- minX 0.1)) (<= px (+ maxX 0.1)))
                (progn
                  (setq dS (distance pt pS) dE (distance pt pE))
                  (if (and (> dS 0.1) (> dE 0.1)) (setq x_cnt (+ x_cnt 2)) (setq x_cnt (+ x_cnt 1)))
                )
              )
            )
          )
        )
        ;; Y축 리스트 검사
        (foreach item c_Y
          (setq e (car item))
          (if (not (equal e exclude_ent))
            (progn
              (setq pS (cadr item) pE (caddr item) minX (nth 3 item) maxX (nth 4 item) minY (nth 5 item) maxY (nth 6 item))
              (if (and (>= px (- minX 0.1)) (<= px (+ maxX 0.1)) (>= py (- minY 0.1)) (<= py (+ maxY 0.1)))
                (progn
                  (setq dS (distance pt pS) dE (distance pt pE))
                  (if (and (> dS 0.1) (> dE 0.1)) (setq y_cnt (+ y_cnt 2)) (setq y_cnt (+ y_cnt 1)))
                )
              )
            )
          )
        )
        (list x_cnt y_cnt)
      )

      ;; 자기 축(mode)의 목록만 검색
      (defun Has-Partner-Fast (pA pB thick_limit exclude_ent mode target_cache / v1 v2 v3 found item e minX maxX minY maxY d vS vE)
        (setq found nil)
        (if (= mode "Y")
          (setq v1 (car pA) v2 (min (cadr pA) (cadr pB)) v3 (max (cadr pA) (cadr pB)))
          (setq v1 (cadr pA) v2 (min (car pA) (car pB)) v3 (max (car pA) (car pB)))
        )
        (foreach item target_cache
          (if (not found)
            (progn
              (setq e (car item))
              (if (not (equal e exclude_ent))
                (progn
                  (setq minX (nth 3 item) maxX (nth 4 item) minY (nth 5 item) maxY (nth 6 item))
                  (setq d (if (= mode "Y") (abs (- v1 minX)) (abs (- v1 minY))))
                  (if (and (> d 0.1) (<= d thick_limit))
                    (progn
                      (setq vS (if (= mode "Y") minY minX) vE (if (= mode "Y") maxY maxX))
                      (if (and (> v3 vS) (< v2 vE)) (setq found T))
                    )
                  )
                )
              )
            )
          )
        )
        found
      )

      ;; ===========================================================
      ;; 1단계: Y축(수직선) 대상 찾기
      ;; ===========================================================
      (princ "\n1단계: Y축 계산 중...")
      (setq i 0)
      (while (< i (sslength ssUser))
        (setq ent (ssname ssUser i) d (entget ent))
        (setq p1 (cdr (assoc 10 d)) p2 (cdr (assoc 11 d)) ang (angle p1 p2) len (distance p1 p2))
        (if (and (equal (abs (sin ang)) 1.0 0.05) (<= len *cba_threshold*))
          (progn
            (setq nA (Get-Paths-Fast p1 ent cache_X cache_Y) nB (Get-Paths-Fast p2 ent cache_X cache_Y))
            (setq xa (car nA) ya (cadr nA) xb (car nB) yb (cadr nB) is_trash nil)
            (cond
              ((or (= (+ xa ya) 0) (= (+ xb yb) 0)) (setq is_trash T))
              ((and (>= xa 2) (>= xb 2)) (setq is_trash T))
              ((or (and (>= xa 1) (>= ya 1) (>= xb 2)) (and (>= xb 1) (>= yb 1) (>= xa 2))) (setq is_trash T))
              (t (setq is_trash nil))
            )
            ;; 보호할 짝을 찾을 때 Y축 목록(cache_Y)만 씀
            (if (and is_trash (not (Has-Partner-Fast p1 p2 active_thick ent "Y" cache_Y))) (setq is_trash nil))
            (if is_trash (setq del_Y (cons ent del_Y))) 
          )
        )
        (setq i (1+ i))
      )

      (setq count_Y (length del_Y))
      (setq cache_Y (vl-remove-if '(lambda (x) (member (car x) del_Y)) cache_Y))

      ;; ===========================================================
      ;; 2단계: X축(수평선) 대상 찾기
      ;; ===========================================================
      (princ "\n2단계: X축 계산 중...")
      (setq i 0)
      (while (< i (sslength ssUser))
        (setq ent (ssname ssUser i))
        (if (not (member ent del_Y))
          (progn
            (setq d (entget ent) p1 (cdr (assoc 10 d)) p2 (cdr (assoc 11 d)) ang (angle p1 p2) len (distance p1 p2))
            (if (and (equal (abs (sin ang)) 0.0 0.05) (<= len *cba_threshold*))
              (progn
                (setq nA (Get-Paths-Fast p1 ent cache_X cache_Y) nB (Get-Paths-Fast p2 ent cache_X cache_Y))
                (setq xa (car nA) ya (cadr nA) xb (car nB) yb (cadr nB) is_trash nil)
                (cond
                  ((or (= (+ xa ya) 0) (= (+ xb yb) 0)) (setq is_trash T))
                  ((and (>= ya 2) (>= yb 2)) (setq is_trash T))
                  ((or (and (>= ya 1) (>= xa 1) (>= yb 2)) (and (>= yb 1) (>= xb 1) (>= ya 2))) (setq is_trash T))
                  ((and (>= xa 1) (>= ya 1) (>= xb 1) (>= yb 1)) (setq is_trash T))
                  (t (setq is_trash nil))
                )
                ;; 보호할 짝을 찾을 때 X축 목록(cache_X)만 씀
                (if (and is_trash (not (Has-Partner-Fast p1 p2 active_thick ent "X" cache_X))) (setq is_trash nil))
                (if is_trash (setq del_X (cons ent del_X)))
              )
            )
          )
        )
        (setq i (1+ i))
      )
      
      (setq count_X (length del_X))

      ;; ===========================================================
      ;; 삭제
      ;; ===========================================================
      (foreach e del_Y (entdel e))
      (foreach e del_X (entdel e))

      (princ (strcat "\n[완료] 모드(" *cba_mode* ") Y축 " (itoa count_Y) "개, X축 " (itoa count_X) "개를 삭제했습니다."))
    )
    (princ "\n[취소] 선택된 객체가 없습니다.")
  )
  (vla-EndUndoMark doc)
  (princ)
)