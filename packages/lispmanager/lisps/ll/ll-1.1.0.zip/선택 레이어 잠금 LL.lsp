;;; ==============================================================================
;;;  LL — 고른 객체의 레이어 잠그기
;;;
;;;  객체를 고르면 그 레이어들을 잠근다. 이름 그대로 잠그므로 '.' '#' 같은 글자가 든 이름도 그 레이어만.
;;;  잠긴 레이어는 흐리게 보인다 (LAYLOCKFADECTL). 모두 풀기는 ULALL.
;;; ==============================================================================

(defun c:LL ( / ss i lay lays doc L n)
  (vl-load-com)
  (prompt "\n잠글 레이어의 객체를 고르세요: ")
  (if (null (setq ss (ssget)))
    (princ "\n고른 객체가 없습니다.")
    (progn
      (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)) i 0 n 0)
      (while (< i (sslength ss))
        (setq lay (cdr (assoc 8 (entget (ssname ss i)))))
        (if (not (member lay lays)) (setq lays (cons lay lays)))
        (setq i (1+ i)))
      (foreach lay lays
        (setq L (vla-Item (vla-get-Layers doc) lay))
        (if (= (vla-get-Lock L) :vlax-false) (progn (vla-put-Lock L :vlax-true) (setq n (1+ n)))))
      (princ (strcat "\n[완료] 레이어 " (itoa n) "개를 잠갔습니다"
                     (if (< n (length lays)) (strcat " (" (itoa (- (length lays) n)) "개는 이미 잠김)") "")
                     ": " (substr (apply 'strcat (mapcar '(lambda (x) (strcat ", " x)) (reverse lays))) 3)))))
  (princ))

(princ)
