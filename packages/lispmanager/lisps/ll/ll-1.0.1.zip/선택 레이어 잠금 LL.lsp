(defun c:ll ( / ss i ent layname laylist layStr)
  (prompt "\n잠글 도면층에 속한 객체들을 선택하세요: ")
  (if (setq ss (ssget)) ; 객체를 선택받음
    (progn
      (setq i 0)
      (setq laylist nil)
      (setq layStr "")

      ;; 1. 선택한 객체들을 하나씩 확인하며 레이어 이름 수집 (중복 제거)
      (repeat (sslength ss)
        (setq ent (entget (ssname ss i)))
        (setq layname (cdr (assoc 8 ent))) ; 레이어 이름 추출
        
        (if (not (member layname laylist)) ; 리스트에 없는 레이어면 추가
          (progn
            (setq laylist (cons layname laylist))
            (if (= layStr "")
              (setq layStr layname)
              (setq layStr (strcat layStr "," layname))
            )
          )
        )
        (setq i (1+ i))
      )

      ;; 2. 수집된 레이어들 잠금 실행
      (setvar "cmdecho" 0)
      (command "-layer" "lock" layStr "")
      (setvar "cmdecho" 1)

      (princ (strcat "\n총 " (itoa (length laylist)) "개의 도면층이 잠겼습니다. [" layStr "]"))
    )
    (princ "\n선택된 객체가 없습니다.")
  )
  (princ)
)+-