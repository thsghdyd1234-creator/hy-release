;;; ==============================================================================
;;;  WASD — 고른 객체를 W·A·S·D 키로 한 칸씩 옮기기
;;;
;;;  간격을 넣고(기억) 객체를 고른 뒤 W 위 · S 아래 · A 왼쪽 · D 오른쪽 (한글 자판 ㅈ·ㄴ·ㅁ·ㅇ 도 됨).
;;;  Q = 방금 옮긴 것 되돌리기.  Enter · Space · 클릭 · 오른쪽 클릭 = 끝.  화면(UCS) 방향으로 옮긴다.
;;;  한 번 누를 때마다 실행 취소 한 칸 (U 로 한 칸씩 되돌아감). 잠긴 레이어의 객체는 옮기지 않는다.
;;; ==============================================================================

(defun wasd:err (msg)
  (if wasd_sv (setvar "CMDECHO" wasd_sv))
  (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*,*QUIT*,*취소*")))
    (princ (strcat "\n[오류] " msg)))
  (princ))

(defun wasd:move (ss v)
  (command "_.MOVE" ss "" "_non" '(0.0 0.0 0.0) "_non" (list (car v) (cadr v) 0.0)))

(defun c:WASD ( / *error* wasd_sv d ss key c v hist sx sy go)
  (setq *error* wasd:err wasd_sv (getvar "CMDECHO"))
  (setq d (if (getenv "HyWasdDist") (atof (getenv "HyWasdDist")) 10.0))
  (if (<= d 0) (setq d 10.0))
  (initget 6)
  (setq d (cond ((getdist (strcat "\n한 칸 간격 <" (rtos d 2 2) ">: "))) (d)))
  (setenv "HyWasdDist" (rtos d 2 8))
  (prompt "\n옮길 객체를 고르세요 (잠긴 레이어는 빠짐): ")
  (if (null (setq ss (ssget "_:L")))
    (princ "\n고른 객체가 없습니다.")
    (progn
      (setvar "CMDECHO" 0)
      (setq sx 0.0 sy 0.0 go T)
      (prompt "\nW 위 · S 아래 · A 왼쪽 · D 오른쪽 · Q 되돌리기 · Enter/Space/클릭 = 끝")
      (while go
        (setq key (grread nil 6 0) c (cadr key) v nil)
        (cond
          ((member (car key) '(3 11 25)) (setq go nil))                        ; 클릭 · 오른쪽 클릭
          ((/= (car key) 2))                                                  ; 키보드가 아니면 무시
          ((member c '(13 32)) (setq go nil))
          ((member c '(87 119 12616)) (setq v (list 0.0 d)))                  ; W w ㅈ
          ((member c '(83 115 12596)) (setq v (list 0.0 (- d))))              ; S s ㄴ
          ((member c '(65 97 12609)) (setq v (list (- d) 0.0)))               ; A a ㅁ
          ((member c '(68 100 12615)) (setq v (list d 0.0)))                  ; D d ㅇ
          ((member c '(81 113 12610))                                          ; Q q ㅂ = 되돌리기
           (if hist
             (progn (wasd:move ss (mapcar '- (car hist))) (setq sx (- sx (car (car hist))) sy (- sy (cadr (car hist))) hist (cdr hist))
                    (prompt (strcat "\r지금까지 X " (rtos sx 2 2) " · Y " (rtos sy 2 2) "        ")))))
          (T (prompt "\rW·A·S·D 로 옮기고 Enter 로 끝내세요.        ")))
        (if v
          (progn (wasd:move ss v) (setq hist (cons v hist) sx (+ sx (car v)) sy (+ sy (cadr v)))
                 (prompt (strcat "\r지금까지 X " (rtos sx 2 2) " · Y " (rtos sy 2 2) "        ")))))
      (setvar "CMDECHO" wasd_sv)
      (princ (strcat "\n[완료] X " (rtos sx 2 2) " · Y " (rtos sy 2 2) " 만큼 옮겼습니다."))))
  (princ))

(princ)
