(defun c:WASD ( / old_cmdecho ss dist key code loop )
  (vl-load-com)
  ;; 명령어 에코 끄기
  (setq old_cmdecho (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  
  ;; 1. 이전 입력값(간격) 기억하기 (*wasd_dist* 전역 변수 사용)
  ;; 전역 변수가 비어있다면(최초 실행) 10.0으로 초기화
  (if (null *wasd_dist*) (setq *wasd_dist* 10.0)) 
  
  ;; 사용자에게 간격을 묻고, 괄호 안에 이전 입력값을 띄워줌
  (setq dist (getdist (strcat "\n이동할 간격(거리)을 입력하세요 <" (vl-princ-to-string *wasd_dist*) ">: ")))
  
  ;; 사용자가 새로운 값을 입력했으면 전역 변수 갱신, 엔터만 쳤으면 이전 값 그대로 사용
  (if dist
    (setq *wasd_dist* dist)
    (setq dist *wasd_dist*)
  )
  
  ;; 2. 객체 선택
  (prompt "\n이동할 객체를 선택하세요: ")
  (if (setq ss (ssget))
    (progn
      (prompt "\n[W:위 | S:아래 | A:왼쪽 | D:오른쪽] 키로 이동 / [Enter, Space] 종료")
      (setq loop T)
      
      ;; 3. 키보드 입력 실시간 감지 (Loop)
      (while loop
        (setq key (grread t 15 0))
        (setq code (cadr key))
        
        (cond
          ;; W 또는 w (위로 이동)
          ((or (= code 87) (= code 119))
           (command "_.MOVE" ss "" "_NON" '(0 0) "_NON" (list 0 dist))
          )
          ;; S 또는 s (아래로 이동)
          ((or (= code 83) (= code 115))
           (command "_.MOVE" ss "" "_NON" '(0 0) "_NON" (list 0 (- dist)))
          )
          ;; A 또는 a (왼쪽으로 이동)
          ((or (= code 65) (= code 97))
           (command "_.MOVE" ss "" "_NON" '(0 0) "_NON" (list (- dist) 0))
          )
          ;; D 또는 d (오른쪽으로 이동)
          ((or (= code 68) (= code 100))
           (command "_.MOVE" ss "" "_NON" '(0 0) "_NON" (list dist 0))
          )
          ;; Enter(13) 또는 Space(32) (종료)
          ((or (= code 13) (= code 32))
           (setq loop nil)
           (prompt "\nWASD 이동을 종료합니다.")
          )
        )
      )
    )
    (prompt "\n선택된 객체가 없습니다.")
  )
  
  ;; 초기 설정 복구
  (setvar "CMDECHO" old_cmdecho)
  (princ)
)