// hy Icon — Illustrator host (ExtendScript)
// Panel sends already-resolved shapes (fill/stroke hex). This file only draws.

var HYICON_NOTE = 'hyIcon:';

function hyIcon_parse(s) { return eval('(' + s + ')'); }

function hyIcon_ok(doc) {
  if (!app.documents.length) throw '문서가 열려 있지 않습니다';
}

function hyIcon_rgb(hex) {
  hex = hex.replace('#', '');
  if (hex.length === 3) hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
  var c = new RGBColor();
  c.red = parseInt(hex.substr(0, 2), 16);
  c.green = parseInt(hex.substr(2, 2), 16);
  c.blue = parseInt(hex.substr(4, 2), 16);
  return c;
}

// ---------- geometry: SVG subset → subpaths of {a,l,r} points ----------
var HY_K = 0.5522847498;

function hyIcon_tokens(d) {
  var re = /([MLHVCSQTAZmlhvcsqtaz])|(-?\d*\.?\d+(?:[eE][-+]?\d+)?)/g;
  var out = [], m;
  while ((m = re.exec(d)) !== null) out.push(m[1] ? m[1] : parseFloat(m[2]));
  return out;
}

function hyIcon_arcToCubics(x1, y1, rx, ry, phi, fa, fs, x2, y2) {
  // SVG arc → list of cubic segments [c1x,c1y,c2x,c2y,x,y]
  var segs = [];
  if (rx === 0 || ry === 0) { segs.push([x1, y1, x2, y2, x2, y2]); return segs; }
  rx = Math.abs(rx); ry = Math.abs(ry);
  var rad = phi * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
  var dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
  var x1p = cos * dx + sin * dy, y1p = -sin * dx + cos * dy;
  var lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
  if (lam > 1) { rx *= Math.sqrt(lam); ry *= Math.sqrt(lam); }
  var num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
  var den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
  var coef = (num <= 0 || den === 0) ? 0 : Math.sqrt(num / den);
  if (fa === fs) coef = -coef;
  var cxp = coef * (rx * y1p / ry), cyp = coef * (-ry * x1p / rx);
  var cx = cos * cxp - sin * cyp + (x1 + x2) / 2, cy = sin * cxp + cos * cyp + (y1 + y2) / 2;
  function ang(ux, uy, vx, vy) {
    var d = ux * vx + uy * vy, l = Math.sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy));
    var a = Math.acos(Math.max(-1, Math.min(1, d / l)));
    return (ux * vy - uy * vx < 0) ? -a : a;
  }
  var t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
  var dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
  if (!fs && dt > 0) dt -= 2 * Math.PI;
  if (fs && dt < 0) dt += 2 * Math.PI;
  var n = Math.ceil(Math.abs(dt) / (Math.PI / 2)), step = dt / n;
  var t = t1;
  for (var i = 0; i < n; i++) {
    var a1 = t, a2 = t + step, k = 4 / 3 * Math.tan((a2 - a1) / 4);
    var p1x = Math.cos(a1), p1y = Math.sin(a1), p2x = Math.cos(a2), p2y = Math.sin(a2);
    var c1x = p1x - k * p1y, c1y = p1y + k * p1x, c2x = p2x + k * p2y, c2y = p2y - k * p2x;
    function map(px, py) { px *= rx; py *= ry; return [cos * px - sin * py + cx, sin * px + cos * py + cy]; }
    var C1 = map(c1x, c1y), C2 = map(c2x, c2y), P = map(p2x, p2y);
    segs.push([C1[0], C1[1], C2[0], C2[1], P[0], P[1]]);
    t = a2;
  }
  return segs;
}

function hyIcon_pathToSubs(d) {
  var tk = hyIcon_tokens(d), i = 0, subs = [], cur = null;
  var cx = 0, cy = 0, sx = 0, sy = 0, lcx = null, lcy = null, lqx = null, lqy = null, cmd = null, prev = null;
  function newSub(x, y) { cur = { closed: false, pts: [{ a: [x, y], l: [x, y], r: [x, y] }] }; subs.push(cur); }
  function lineTo(x, y) { if (!cur) newSub(cx, cy); cur.pts.push({ a: [x, y], l: [x, y], r: [x, y] }); }
  function cubicTo(c1x, c1y, c2x, c2y, x, y) {
    if (!cur) newSub(cx, cy);
    var last = cur.pts[cur.pts.length - 1]; last.r = [c1x, c1y];
    cur.pts.push({ a: [x, y], l: [c2x, c2y], r: [x, y] });
  }
  function num() { return tk[i++]; }
  while (i < tk.length) {
    var t = tk[i];
    if (typeof t === 'string') { cmd = t; i++; } // else: implicit repeat of previous cmd
    var rel = (cmd === cmd.toLowerCase()), C = cmd.toUpperCase();
    var x, y, c1x, c1y, c2x, c2y, qx, qy;
    switch (C) {
      case 'M':
        x = num(); y = num(); if (rel) { x += cx; y += cy; }
        newSub(x, y); cx = sx = x; cy = sy = y; lcx = lcy = lqx = lqy = null;
        cmd = rel ? 'l' : 'L'; break;
      case 'L': x = num(); y = num(); if (rel) { x += cx; y += cy; } lineTo(x, y); cx = x; cy = y; lcx = lqx = null; break;
      case 'H': x = num(); if (rel) x += cx; lineTo(x, cy); cx = x; lcx = lqx = null; break;
      case 'V': y = num(); if (rel) y += cy; lineTo(cx, y); cy = y; lcx = lqx = null; break;
      case 'C':
        c1x = num(); c1y = num(); c2x = num(); c2y = num(); x = num(); y = num();
        if (rel) { c1x += cx; c1y += cy; c2x += cx; c2y += cy; x += cx; y += cy; }
        cubicTo(c1x, c1y, c2x, c2y, x, y); lcx = c2x; lcy = c2y; cx = x; cy = y; lqx = null; break;
      case 'S':
        c2x = num(); c2y = num(); x = num(); y = num();
        if (rel) { c2x += cx; c2y += cy; x += cx; y += cy; }
        c1x = (lcx === null) ? cx : 2 * cx - lcx; c1y = (lcx === null) ? cy : 2 * cy - lcy;
        cubicTo(c1x, c1y, c2x, c2y, x, y); lcx = c2x; lcy = c2y; cx = x; cy = y; lqx = null; break;
      case 'Q':
        qx = num(); qy = num(); x = num(); y = num();
        if (rel) { qx += cx; qy += cy; x += cx; y += cy; }
        cubicTo(cx + 2 / 3 * (qx - cx), cy + 2 / 3 * (qy - cy), x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), x, y);
        lqx = qx; lqy = qy; cx = x; cy = y; lcx = null; break;
      case 'T':
        x = num(); y = num(); if (rel) { x += cx; y += cy; }
        qx = (lqx === null) ? cx : 2 * cx - lqx; qy = (lqx === null) ? cy : 2 * cy - lqy;
        cubicTo(cx + 2 / 3 * (qx - cx), cy + 2 / 3 * (qy - cy), x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), x, y);
        lqx = qx; lqy = qy; cx = x; cy = y; lcx = null; break;
      case 'A':
        var rx = num(), ry = num(), phi = num(), fa = num(), fs = num(); x = num(); y = num();
        if (rel) { x += cx; y += cy; }
        var segs = hyIcon_arcToCubics(cx, cy, rx, ry, phi, fa ? 1 : 0, fs ? 1 : 0, x, y);
        for (var k = 0; k < segs.length; k++) { var s = segs[k]; cubicTo(s[0], s[1], s[2], s[3], s[4], s[5]); }
        cx = x; cy = y; lcx = lqx = null; break;
      case 'Z':
        if (cur) {
          cur.closed = true;
          var f = cur.pts[0], l = cur.pts[cur.pts.length - 1];
          if (cur.pts.length > 1 && Math.abs(f.a[0] - l.a[0]) < 1e-6 && Math.abs(f.a[1] - l.a[1]) < 1e-6) { f.l = l.l; cur.pts.pop(); }
        }
        cx = sx; cy = sy; cur = null; lcx = lqx = null; break;
      default: i++;
    }
  }
  return subs;
}

function hyIcon_ellipseSubs(cx, cy, rx, ry) {
  var kx = rx * HY_K, ky = ry * HY_K;
  return [{ closed: true, pts: [
    { a: [cx + rx, cy], l: [cx + rx, cy - ky], r: [cx + rx, cy + ky] },
    { a: [cx, cy + ry], l: [cx + kx, cy + ry], r: [cx - kx, cy + ry] },
    { a: [cx - rx, cy], l: [cx - rx, cy + ky], r: [cx - rx, cy - ky] },
    { a: [cx, cy - ry], l: [cx - kx, cy - ry], r: [cx + kx, cy - ry] } ] }];
}

function hyIcon_rectSubs(x, y, w, h, rx) {
  if (!rx) return [{ closed: true, pts: [
    { a: [x, y], l: [x, y], r: [x, y] }, { a: [x + w, y], l: [x + w, y], r: [x + w, y] },
    { a: [x + w, y + h], l: [x + w, y + h], r: [x + w, y + h] }, { a: [x, y + h], l: [x, y + h], r: [x, y + h] } ] }];
  rx = Math.min(rx, w / 2, h / 2);
  var d = 'M' + (x + rx) + ' ' + y + ' H' + (x + w - rx) + ' A' + rx + ' ' + rx + ' 0 0 1 ' + (x + w) + ' ' + (y + rx) +
    ' V' + (y + h - rx) + ' A' + rx + ' ' + rx + ' 0 0 1 ' + (x + w - rx) + ' ' + (y + h) +
    ' H' + (x + rx) + ' A' + rx + ' ' + rx + ' 0 0 1 ' + x + ' ' + (y + h - rx) +
    ' V' + (y + rx) + ' A' + rx + ' ' + rx + ' 0 0 1 ' + (x + rx) + ' ' + y + ' Z';
  return hyIcon_pathToSubs(d);
}

function hyIcon_shapeSubs(sh) {
  switch (sh.t) {
    case 'path': return hyIcon_pathToSubs(sh.d);
    case 'circle': return hyIcon_ellipseSubs(sh.cx, sh.cy, sh.r, sh.r);
    case 'ellipse': return hyIcon_ellipseSubs(sh.cx, sh.cy, sh.rx, sh.ry);
    case 'rect': return hyIcon_rectSubs(sh.x, sh.y, sh.w, sh.h, sh.rx || 0);
  }
  return [];
}

// ---------- drawing ----------
function hyIcon_style(item, fill, stroke, sw) {
  // compound paths take their appearance from their member paths
  if (item.typename === 'CompoundPathItem') {
    for (var i = 0; i < item.pathItems.length; i++) hyIcon_style(item.pathItems[i], fill, stroke, sw);
    return;
  }
  if (fill) { item.filled = true; item.fillColor = hyIcon_rgb(fill); } else item.filled = false;
  if (stroke) {
    item.stroked = true; item.strokeColor = hyIcon_rgb(stroke); item.strokeWidth = sw;
    item.strokeCap = StrokeCap.ROUNDENDCAP; item.strokeJoin = StrokeJoin.ROUNDENDJOIN;
  } else item.stroked = false;
}

function hyIcon_fillPath(target, sp, tx, ty) {
  var p = target.pathItems.add();
  for (var j = 0; j < sp.pts.length; j++) {
    var pt = sp.pts[j], pp = p.pathPoints.add();
    pp.anchor = [tx(pt.a[0]), ty(pt.a[1])];
    pp.leftDirection = [tx(pt.l[0]), ty(pt.l[1])];
    pp.rightDirection = [tx(pt.r[0]), ty(pt.r[1])];
    pp.pointType = PointType.CORNER;
  }
  p.closed = sp.closed;
  return p;
}

// returns the created item (PathItem or CompoundPathItem)
function hyIcon_addShape(g, subs, tx, ty, fill, stroke, sw) {
  var item;
  if (subs.length > 1 && fill) {
    item = g.compoundPathItems.add();
    for (var i = 0; i < subs.length; i++) hyIcon_fillPath(item, subs[i], tx, ty);
  } else if (subs.length > 1) {
    item = g.groupItems.add();              // open strokes with several parts
    for (var k = 0; k < subs.length; k++) hyIcon_style(hyIcon_fillPath(item, subs[k], tx, ty), fill, stroke, sw);
    item.move(g, ElementPlacement.PLACEATBEGINNING);
    return item;
  } else {
    item = hyIcon_fillPath(g, subs[0], tx, ty);
  }
  hyIcon_style(item, fill, stroke, sw);
  item.move(g, ElementPlacement.PLACEATBEGINNING);   // later shapes stack in front
  return item;
}

function hyIcon_bbox(subs) {
  var L = 1e9, T = 1e9, R = -1e9, B = -1e9;
  for (var i = 0; i < subs.length; i++) for (var j = 0; j < subs[i].pts.length; j++) {
    var a = subs[i].pts[j].a;
    L = Math.min(L, a[0]); R = Math.max(R, a[0]); T = Math.min(T, a[1]); B = Math.max(B, a[1]);
  }
  return [L, T, R, B];
}
function hyIcon_inside(inner, outer) {
  return inner[0] >= outer[0] - 0.01 && inner[2] <= outer[2] + 0.01 && inner[1] >= outer[1] - 0.01 && inner[3] <= outer[3] + 0.01;
}

// punch 'subs' out of 'host' (a filled PathItem or CompoundPathItem); returns the compound
function hyIcon_punch(g, host, subs, tx, ty, fill) {
  var cp = host;
  if (host.typename !== 'CompoundPathItem') {
    cp = g.compoundPathItems.add();
    cp.move(host, ElementPlacement.PLACEBEFORE);
    host.move(cp, ElementPlacement.PLACEATEND);
  }
  for (var i = 0; i < subs.length; i++) {
    var h = hyIcon_fillPath(cp, subs[i], tx, ty);
    h.polarity = PolarityValues.NEGATIVE;
  }
  hyIcon_style(cp, fill, null, 0);
  return cp;
}

// render: {grid, badge, paper, shapes:[{t,.., fill, stroke, sw}]}  fill/stroke may be 'HOLE'
function hyIcon_draw(layer, render, cx, cy, sizePt, name, note) {
  var g = layer.groupItems.add();
  g.name = 'hyIcon ' + name;
  var s = sizePt / render.grid, ox = cx - sizePt / 2, oy = cy + sizePt / 2;
  function tx(x) { return ox + x * s; }
  function ty(y) { return oy - y * s; }

  if (render.badge) {
    var b = render.badge, r = b.fill ? 24 : 24 - (b.w || 3) / 2;
    hyIcon_addShape(g, hyIcon_ellipseSubs(24, 24, r, r), tx, ty, b.fill || null, b.stroke || null, b.fill ? 0 : (b.w || 3) * s);
  }

  var solids = []; // filled shapes that holes may cut into: {item, box, fill}
  for (var i = 0; i < render.shapes.length; i++) {
    var sh = render.shapes[i], subs = hyIcon_shapeSubs(sh);
    if (!subs.length) continue;
    var sw = (sh.sw || 3) * s, box = hyIcon_bbox(subs);

    if (sh.fill === 'HOLE') {
      // cut into the front-most solid that fully contains it
      var host = null;
      for (var k = solids.length - 1; k >= 0; k--) if (hyIcon_inside(box, solids[k].box)) { host = solids[k]; break; }
      if (host) { host.item = hyIcon_punch(g, host.item, subs, tx, ty, host.fill); continue; }
      // nothing to cut into: leave it out (it would be invisible on the page anyway)
      continue;
    }
    var stroke = sh.stroke === 'HOLE' ? render.paper : sh.stroke; // a stroked line can't be a hole
    var item = hyIcon_addShape(g, subs, tx, ty, sh.fill, stroke, sw);
    if (sh.fill && !sh.stroke && item.typename !== 'GroupItem') solids.push({ item: item, box: box, fill: sh.fill });
  }

  // remember where the icon's centre sits relative to its visible bounds, so restyle keeps the spot
  var gb = g.geometricBounds, bcx = (gb[0] + gb[2]) / 2, bcy = (gb[1] + gb[3]) / 2;
  var meta = hyIcon_parse(note);
  meta.off = [(bcx - cx) / sizePt, (bcy - cy) / sizePt];
  g.note = HYICON_NOTE + hyIcon_json(meta);
  return g;
}

function hyIcon_json(o) {
  var out = [];
  for (var k in o) if (o.hasOwnProperty(k)) {
    var v = o[k], t = typeof v;
    if (v instanceof Array) v = '[' + v.join(',') + ']';
    else if (t === 'string') v = '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
    else v = String(v);
    out.push('"' + k + '":' + v);
  }
  return '{' + out.join(',') + '}';
}

function hyIcon_boundsCenter(item, geometric) {
  var b = geometric ? item.geometricBounds : item.visibleBounds; // [left, top, right, bottom]
  return [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2];
}

// the icon's own centre (not its bounds centre), using the stored offset
function hyIcon_iconCenter(g) {
  var c = hyIcon_boundsCenter(g, true);
  try {
    var m = hyIcon_parse(g.note.substr(HYICON_NOTE.length));
    if (m.off && m.sizePt) { c[0] -= m.off[0] * m.sizePt; c[1] -= m.off[1] * m.sizePt; }
  } catch (e) {}
  return c;
}

function hyIcon_artboardCenter(doc) {
  var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
  return [(ab[0] + ab[2]) / 2, (ab[1] + ab[3]) / 2];
}

function hyIcon_targetLayer(doc) {
  var L = doc.activeLayer;
  if (L.locked || !L.visible) {
    for (var i = 0; i < doc.layers.length; i++) if (!doc.layers[i].locked && doc.layers[i].visible) return doc.layers[i];
  }
  return L;
}

// ---------- panel entry points ----------
// count of page items — taken before a drag so we can tell whether a drop happened
function hyIcon_snap() {
  try {
    hyIcon_ok();
    var d = app.activeDocument;
    return '{"n":' + d.pageItems.length + ',"doc":"' + String(d.name).replace(/"/g, '\\"') + '","docs":' + app.documents.length + '}';
  } catch (e) { return 'ERR:' + e; }
}

// p: {mode:'drop'|'select'|'center', snap:n, render, sizePt, name, note}
function hyIcon_place(str) {
  try {
    hyIcon_ok();
    var p = hyIcon_parse(str), doc = app.activeDocument, sel = doc.selection, center, layer = hyIcon_targetLayer(doc);
    if (p.mode === 'drop') {
      // why a drop was not found is reported back so the panel can say it plainly
      var sn = p.snap || {};
      if (sn.docs !== undefined && app.documents.length > sn.docs) return 'NODROP:newdoc';
      if (sn.doc !== undefined && String(doc.name) !== sn.doc) return 'NODROP:otherdoc';
      if (sn.n !== undefined && doc.pageItems.length <= sn.n) return 'NODROP:nothing';
      if (!sel || !sel.length) return 'NODROP:nosel';
      // the import may arrive as one group or as several loose items: use all of the selection
      var L = 1e9, T = -1e9, R = -1e9, B = 1e9, list = [];
      for (var q = 0; q < sel.length; q++) {
        var gbq = sel[q].geometricBounds; list.push(sel[q]);
        L = Math.min(L, gbq[0]); T = Math.max(T, gbq[1]); R = Math.max(R, gbq[2]); B = Math.min(B, gbq[3]);
      }
      center = [(L + R) / 2, (T + B) / 2];
      try { layer = list[0].layer; } catch (e) {}
      for (var z = 0; z < list.length; z++) { try { list[z].remove(); } catch (e) {} }
    } else if (p.mode === 'select' && sel && sel.length) {
      var L = 1e9, T = -1e9, R = -1e9, B = 1e9;
      for (var i = 0; i < sel.length; i++) {
        var b = sel[i].visibleBounds;
        L = Math.min(L, b[0]); T = Math.max(T, b[1]); R = Math.max(R, b[2]); B = Math.min(B, b[3]);
      }
      center = [(L + R) / 2, (T + B) / 2];
    } else {
      center = hyIcon_artboardCenter(doc);
    }
    var g = hyIcon_draw(layer, p.render, center[0], center[1], p.sizePt, p.name, p.note);
    doc.selection = null; g.selected = true;
    app.redraw();
    return 'OK';
  } catch (e) { return 'ERR:' + e; }
}

// selected hyIcon groups → [{i, id}] (index into current selection)
function hyIcon_selected() {
  try {
    hyIcon_ok();
    var sel = app.activeDocument.selection, out = [];
    if (!sel) return '[]';
    for (var i = 0; i < sel.length; i++) {
      var it = sel[i];
      if (it.typename === 'GroupItem' && it.note && it.note.indexOf(HYICON_NOTE) === 0) {
        var meta = hyIcon_parse(it.note.substr(HYICON_NOTE.length));
        out.push('{"i":' + i + ',"id":"' + meta.id + '","sizePt":' + (meta.sizePt || 0) + '}');
      }
    }
    return '[' + out.join(',') + ']';
  } catch (e) { return 'ERR:' + e; }
}

// p: {items:[{i, render, sizePt, name, note}]}
function hyIcon_restyle(str) {
  try {
    hyIcon_ok();
    var p = hyIcon_parse(str), doc = app.activeDocument, sel = doc.selection, made = [];
    var old = [];
    for (var i = 0; i < sel.length; i++) old.push(sel[i]);
    for (var k = 0; k < p.items.length; k++) {
      var it = p.items[k], g = old[it.i];
      var c = hyIcon_iconCenter(g), layer = g.layer;
      g.remove();
      made.push(hyIcon_draw(layer, it.render, c[0], c[1], it.sizePt, it.name, it.note));
    }
    doc.selection = null;
    for (var m = 0; m < made.length; m++) made[m].selected = true;
    app.redraw();
    return 'OK:' + made.length;
  } catch (e) { return 'ERR:' + e; }
}
