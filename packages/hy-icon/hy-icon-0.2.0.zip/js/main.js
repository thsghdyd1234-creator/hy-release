/* hy Icon — panel logic */
(function () {
  var VERSION = '0.2.0';
  var cs = new CSInterface();
  var $ = function (id) { return document.getElementById(id); };
  var DATA = null, CATMAP = {}, ICONMAP = {};
  var st = {
    style: 'flat', badge: true, holes: true, size: 10, lineScale: 1,
    colorMode: 'cat', color: '#333333', paper: '#ffffff',
    cat: 'all', q: '', sel: null
  };
  var snap = null, dragging = null, tmpDir = null; // tmpDir: null = not checked yet, '' = unavailable

  // ---------- persistence ----------
  try { var saved = JSON.parse(localStorage.getItem('hyIcon.state') || 'null'); if (saved) for (var k in saved) st[k] = saved[k]; } catch (e) {}
  function save() { try { localStorage.setItem('hyIcon.state', JSON.stringify(st)); } catch (e) {} }

  // ---------- helpers ----------
  function status(msg, err) { var s = $('status'); s.textContent = msg; s.className = 'status' + (err ? ' err' : ''); }
  function mm2pt(mm) { return mm * 72 / 25.4; }
  function opts() { return { style: st.style, badge: st.badge, holes: st.holes, colorMode: st.colorMode, color: st.color, paper: st.paper, lineScale: st.lineScale }; }
  function renderOf(icon) { return HyRender.resolve(icon, CATMAP[icon.cat], opts()); }
  function metaOf(icon) { return { id: icon.id, style: st.style, badge: st.badge, holes: st.holes, colorMode: st.colorMode, color: st.color, paper: st.paper, lineScale: st.lineScale, sizePt: mm2pt(st.size) }; }
  function payloadOf(icon, mode, extra) {
    var p = { mode: mode, render: renderOf(icon), sizePt: mm2pt(st.size), name: icon.name, note: JSON.stringify(metaOf(icon)) };
    if (extra) for (var k in extra) p[k] = extra[k];
    return p;
  }
  function callJsx(fn, payload, cb) {
    var arg = payload === undefined ? '' : JSON.stringify(JSON.stringify(payload));
    cs.evalScript(fn + '(' + arg + ')', function (r) { cb && cb(r || ''); });
  }
  function syncControls() {
    setSeg('styleSeg', st.style); setSeg('colorSeg', st.colorMode);
    setSeg('badgeSeg', st.badge ? '1' : '0'); setSeg('holeSeg', st.holes ? '1' : '0'); syncHoleRow();
    $('size').value = st.size; $('lineScale').value = st.lineScale;
    $('color').value = st.color; $('paper').value = st.paper; $('search').value = st.q;
  }
  // 'inside' option only matters for flat/silhouette without an outline circle
  function syncHoleRow() {
    var show = !st.badge && st.style !== 'line';
    $('holeRow').style.display = show ? '' : 'none';
    $('paper').style.display = (show && !st.holes) ? '' : 'none';
  }
  function setSeg(id, v) {
    var bs = $(id).querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) bs[i].className = bs[i].getAttribute('data-v') === v ? 'on' : '';
  }

  // ---------- rendering ----------
  function renderCats() {
    var html = '<button data-c="all"' + (st.cat === 'all' ? ' class="on" style="background:#666"' : '') + '>전체</button>';
    DATA.categories.forEach(function (c) {
      var on = st.cat === c.id;
      html += '<button data-c="' + c.id + '"' + (on ? ' class="on"' : '') + ' style="' + (on ? 'background:' + c.color : 'border-color:' + c.color) + '">' + c.name + '</button>';
    });
    $('cats').innerHTML = html;
  }
  function visibleIcons() {
    var q = st.q.trim().toLowerCase();
    return DATA.icons.filter(function (ic) {
      if (st.cat !== 'all' && ic.cat !== st.cat) return false;
      if (!q) return true;
      return (ic.name + ' ' + ic.id + ' ' + (ic.tags || '')).toLowerCase().indexOf(q) >= 0;
    });
  }
  // Thumbnails are real .svg files shown with <img>. Dragging an <img> makes Chromium hand the
  // image file itself to Windows, which is what Illustrator accepts as a drop (it ignores custom data).
  function styleKey() {
    var str = JSON.stringify(opts()), h = 0;
    for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }
  function thumbFile(ic, key) {
    var dir = ensureTmp(); if (!dir) return null;
    var path = dir + '/' + ic.id + '_' + key + '.svg';
    // empty 48x48 box: the dropped import's bounds equal the icon cell, so its centre = drop point
    var svg = '<?xml version="1.0" encoding="UTF-8"?>' + HyRender.toSvg(renderOf(ic), 36, '#3b3b3b')
      .replace(/(<svg[^>]*>)/, '$1<rect x="0" y="0" width="48" height="48" fill="none" stroke="none"/>');
    var res = window.cep.fs.writeFile(path, svg);
    return res.err === 0 ? path : null;
  }
  function renderGrid() {
    var list = visibleIcons(), html = '', key = styleKey();
    if (!list.length) html = '<div class="empty">검색 결과 없음</div>';
    list.forEach(function (ic) {
      var f = thumbFile(ic, key);
      var pic = f ? '<img src="file:///' + f.replace(/^\/+/, '') + '" data-path="' + f + '" alt="">' : HyRender.toSvg(renderOf(ic), 36, '#3b3b3b');
      html += '<div class="cell' + (st.sel === ic.id ? ' sel' : '') + '" data-id="' + ic.id + '" title="' + ic.name + ' — 그림을 끌어서 배치, 더블클릭: 선택/중앙 배치">' +
        pic + '<div class="nm">' + ic.name + '</div></div>';
    });
    $('grid').innerHTML = html;
  }
  function refresh() { renderCats(); renderGrid(); save(); }

  // ---------- placement ----------
  function place(icon, mode) {
    if (!icon) { status('아이콘을 먼저 선택하세요', true); return; }
    callJsx('hyIcon_place', payloadOf(icon, mode), function (r) {
      if (r === 'OK') status(icon.name + ' 배치됨');
      else status('실패: ' + r, true);
    });
  }
  function restyle() {
    callJsx('hyIcon_selected', undefined, function (r) {
      if (r.indexOf('ERR') === 0) { status('실패: ' + r, true); return; }
      var list; try { list = JSON.parse(r); } catch (e) { list = []; }
      if (!list.length) { status('선택된 hy Icon 그룹이 없습니다', true); return; }
      var items = [];
      list.forEach(function (it) {
        var icon = ICONMAP[it.id]; if (!icon) return;
        items.push({ i: it.i, render: renderOf(icon), sizePt: mm2pt(st.size), name: icon.name, note: JSON.stringify(metaOf(icon)) });
      });
      callJsx('hyIcon_restyle', { items: items }, function (r2) {
        if (r2.indexOf('OK') === 0) status(items.length + '개 재스타일됨'); else status('실패: ' + r2, true);
      });
    });
  }

  // ---------- drag to document ----------
  // Illustrator places the dropped SVG where the mouse was released; we then read that spot,
  // remove the import and redraw the icon natively at the same centre.
  function ensureTmp() {
    if (tmpDir !== null) return tmpDir;
    tmpDir = '';
    try {
      if (!window.cep || !window.cep.fs) return tmpDir;
      var base = cs.getSystemPath(SystemPath.USER_DATA).replace(/^file:\/+/, '').replace(/\\/g, '/') + '/hy_icon_tmp';
      window.cep.fs.makedir(base);
      // clear thumbnails left from earlier sessions
      var ls = window.cep.fs.readdir(base);
      if (ls && ls.err === 0) for (var i = 0; i < ls.data.length; i++) window.cep.fs.deleteFile(base + '/' + ls.data[i]);
      tmpDir = base;
    } catch (e) { tmpDir = ''; }
    return tmpDir;
  }
  function onDragStart(e) {
    var cell = e.target.closest ? e.target.closest('.cell') : null;
    if (!cell) return;
    var icon = ICONMAP[cell.getAttribute('data-id')];
    st.sel = icon.id; save();
    var cells = $('grid').querySelectorAll('.cell');
    for (var i = 0; i < cells.length; i++) cells[i].classList.toggle('sel', cells[i] === cell);
    var img = cell.querySelector('img'), path = img && img.getAttribute('data-path');
    if (!path) { status('이 환경에서는 드래그 배치를 쓸 수 없습니다 — 더블클릭하세요', true); return; }
    // keep Chromium's own image data; only add the file hints
    try {
      var nativePath = /^win/i.test(navigator.platform) ? path.replace(/\//g, '\\') : path;
      e.dataTransfer.effectAllowed = 'copy';
      e.dataTransfer.setData('DownloadURL', 'image/svg+xml:' + icon.id + '.svg:file:///' + path.replace(/^\/+/, ''));
      e.dataTransfer.setData('com.adobe.cep.dnd.file.0', nativePath);
    } catch (x) {}
    dragging = icon; snap = null;
    callJsx('hyIcon_snap', undefined, function (r) { try { snap = JSON.parse(r); } catch (x) { snap = null; } });
    status(icon.name + ' — 문서 위에 놓으세요');
  }
  var DROP_MSG = {
    'NODROP:nothing':  '문서에 아무것도 들어오지 않음 (NODROP:nothing) — 더블클릭으로 배치하세요',
    'NODROP:newdoc':   '새 문서로 열림 — 탭 영역이 아니라 캔버스 안에 놓으세요 (NODROP:newdoc)',
    'NODROP:otherdoc': '다른 문서가 활성화됨 (NODROP:otherdoc)',
    'NODROP:nosel':    '들어온 객체가 선택되지 않음 (NODROP:nosel)'
  };
  function onDragEnd() {
    if (!dragging) return;
    var icon = dragging, tries = 0; dragging = null;
    // the import can take a moment; poll a few times before giving up
    (function attempt() {
      tries++;
      callJsx('hyIcon_place', payloadOf(icon, 'drop', { snap: snap || {} }), function (r) {
        if (r === 'OK') status(icon.name + ' 배치됨');
        else if (r.indexOf('NODROP') === 0 && r !== 'NODROP:newdoc' && tries < 6) setTimeout(attempt, 350);
        else if (r.indexOf('NODROP') === 0) status(DROP_MSG[r] || ('놓은 위치를 찾지 못함 (' + r + ')'), true);
        else status('실패: ' + r, true);
      });
    })();
  }

  // ---------- events ----------
  function bind() {
    $('styleSeg').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; st.style = b.getAttribute('data-v'); setSeg('styleSeg', st.style); syncHoleRow(); refresh(); });
    $('colorSeg').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; st.colorMode = b.getAttribute('data-v'); setSeg('colorSeg', st.colorMode); refresh(); });
    $('badgeSeg').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; st.badge = b.getAttribute('data-v') === '1'; setSeg('badgeSeg', b.getAttribute('data-v')); syncHoleRow(); refresh(); });
    $('holeSeg').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; st.holes = b.getAttribute('data-v') === '1'; setSeg('holeSeg', b.getAttribute('data-v')); syncHoleRow(); refresh(); });
    $('size').addEventListener('change', function () { st.size = parseFloat(this.value) || 10; save(); });
    $('lineScale').addEventListener('change', function () { st.lineScale = parseFloat(this.value) || 1; refresh(); });
    $('color').addEventListener('input', function () { st.color = this.value; if (st.colorMode === 'custom') refresh(); else save(); });
    $('paper').addEventListener('input', function () { st.paper = this.value; refresh(); });
    $('search').addEventListener('input', function () { st.q = this.value; renderGrid(); save(); });
    $('cats').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; st.cat = b.getAttribute('data-c'); refresh(); });

    var grid = $('grid');
    grid.addEventListener('click', function (e) {
      var c = e.target.closest('.cell'); if (!c) return;
      st.sel = c.getAttribute('data-id'); save();
      var cells = grid.querySelectorAll('.cell');
      for (var i = 0; i < cells.length; i++) cells[i].classList.toggle('sel', cells[i] === c);
    });
    grid.addEventListener('dblclick', function (e) { var c = e.target.closest('.cell'); if (!c) return; place(ICONMAP[c.getAttribute('data-id')], 'select'); });
    grid.addEventListener('dragstart', onDragStart);
    grid.addEventListener('dragend', onDragEnd);

    $('placeBtn').addEventListener('click', function () { place(ICONMAP[st.sel], 'select'); });
    $('restyleBtn').addEventListener('click', restyle);
  }

  // ---------- boot ----------
  function load() {
    var x = new XMLHttpRequest();
    x.open('GET', 'data/icons.json', true);
    x.onload = function () {
      try { DATA = JSON.parse(x.responseText); } catch (e) { status('icons.json 파싱 실패', true); return; }
      DATA.categories.forEach(function (c) { CATMAP[c.id] = c; });
      DATA.icons.forEach(function (ic) { ICONMAP[ic.id] = ic; });
      syncControls(); bind(); refresh();
      status('v' + VERSION + ' · ' + DATA.icons.length + '개 아이콘 — 드래그하거나 더블클릭해서 배치');
    };
    x.onerror = function () { status('icons.json 로드 실패', true); };
    x.send();
  }
  load();
})();
