/* hy Icon — role → color resolver + SVG builder
 * icon.shapes[i]: {t:'path'|'circle'|'rect'|'ellipse', ...geom, f:'main'|'accent'|'bg'|'none', s:'main'|'bg'|'none', w}
 * opt: {style:'flat'|'silhouette'|'line', badge:bool, holes:bool, colorMode:'cat'|'custom', color:'#hex', paper:'#hex', lineScale:number}
 * holes: with no badge, 'bg' parts become real cut-outs (fill 'HOLE') instead of paper-coloured shapes
 */
var HyRender = (function () {

  function clamp(v) { return Math.max(0, Math.min(255, Math.round(v))); }
  function hexToRgb(h) {
    h = (h || '#000000').replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbToHex(r) {
    return '#' + r.map(function (v) { return ('0' + clamp(v).toString(16)).slice(-2); }).join('');
  }
  function mix(a, b, t) { // t: 0 → a, 1 → b
    var A = hexToRgb(a), B = hexToRgb(b);
    return rgbToHex([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]);
  }

  // Returns {grid, badge:{fill, stroke, w}|null, shapes:[{geom..., fill:hex|null, stroke:hex|null, w}]}
  function resolve(icon, cat, opt) {
    var paper = opt.paper || '#FFFFFF';
    var base = (opt.colorMode === 'custom' && opt.color) ? opt.color : cat.color;
    var accent = (opt.colorMode === 'custom' && opt.color) ? mix(base, '#FFFFFF', 0.5) : cat.accent;
    var lineScale = opt.lineScale || 1;
    var roles, badge = null, lineMode = false;

    var cut = opt.holes ? 'HOLE' : paper;
    if (opt.style === 'flat') {
      if (opt.badge) { badge = { fill: base }; roles = { main: '#FFFFFF', accent: accent, bg: base }; }
      else           { roles = { main: base, accent: accent, bg: cut }; }
    } else if (opt.style === 'silhouette') {
      if (opt.badge) { badge = { fill: base }; roles = { main: paper, accent: paper, bg: base }; }
      else           { roles = { main: base, accent: base, bg: cut }; }
    } else { // line
      lineMode = true;
      roles = { main: base, accent: base, bg: base };
      if (opt.badge) badge = { stroke: base, w: 3 * lineScale };
    }

    var out = [];
    for (var i = 0; i < icon.shapes.length; i++) {
      var sh = icon.shapes[i], o = {};
      for (var k in sh) if (sh.hasOwnProperty(k)) o[k] = sh[k];
      // stroke width: paths carry it as 'w'; for rect 'w' is the width, so use default
      var dataW = (sh.t === 'rect') ? 3 : (sh.w || 3);
      var fill = null, stroke = null, sw = dataW * lineScale;
      if (lineMode) {
        stroke = base;
        if (sh.f === 'bg') sw = 1.5 * lineScale; // cutouts (windows, hubs) stay light in line mode
      } else {
        if (sh.f && sh.f !== 'none') fill = roles[sh.f] || sh.f;
        if (sh.s && sh.s !== 'none') stroke = roles[sh.s] || sh.s;
      }
      o.fill = fill; o.stroke = stroke; o.sw = sw;
      if (sh.t !== 'rect') delete o.w;
      delete o.f; delete o.s;
      out.push(o);
    }
    return { grid: 48, badge: badge, paper: paper, shapes: out };
  }

  var HOLE_VIEW = '#3b3b3b'; // how cut-outs look in a preview (set per call)
  function col(c) { return c === 'HOLE' ? HOLE_VIEW : c; }
  function attr(sh) {
    var a = ' fill="' + (sh.fill ? col(sh.fill) : 'none') + '"';
    if (sh.stroke) a += ' stroke="' + col(sh.stroke) + '" stroke-width="' + sh.sw + '" stroke-linecap="round" stroke-linejoin="round"';
    return a;
  }

  function shapeSvg(sh) {
    switch (sh.t) {
      case 'path':    return '<path d="' + sh.d + '"' + attr(sh) + '/>';
      case 'circle':  return '<circle cx="' + sh.cx + '" cy="' + sh.cy + '" r="' + sh.r + '"' + attr(sh) + '/>';
      case 'ellipse': return '<ellipse cx="' + sh.cx + '" cy="' + sh.cy + '" rx="' + sh.rx + '" ry="' + sh.ry + '"' + attr(sh) + '/>';
      case 'rect':    return '<rect x="' + sh.x + '" y="' + sh.y + '" width="' + sh.w + '" height="' + sh.h + '"' + (sh.rx ? ' rx="' + sh.rx + '"' : '') + attr(sh) + '/>';
    }
    return '';
  }

  // sizePx: rendered size; holeView: colour that stands in for cut-outs in this preview
  function toSvg(res, sizePx, holeView) {
    HOLE_VIEW = holeView || res.paper || '#ffffff';
    var g = res.grid, s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + g + ' ' + g + '"' +
      (sizePx ? ' width="' + sizePx + '" height="' + sizePx + '"' : '') + '>';
    if (res.badge) {
      if (res.badge.fill) s += '<circle cx="24" cy="24" r="24" fill="' + res.badge.fill + '"/>';
      else s += '<circle cx="24" cy="24" r="' + (24 - res.badge.w / 2) + '" fill="none" stroke="' + res.badge.stroke + '" stroke-width="' + res.badge.w + '"/>';
    }
    for (var i = 0; i < res.shapes.length; i++) {
      s += shapeSvg(res.shapes[i]);
    }
    return s + '</svg>';
  }

  return { resolve: resolve, toSvg: toSvg, mix: mix };
})();
