(() => {
  const cep = window.__adobe_cep__;
  const $ = id => document.getElementById(id);
  const statusEl = $("status");
  let groups = [];          // [{name, presets:[...], user?}]
  let cur = null;           // 현재 편집 중인 설정 (프리셋은 출발점일 뿐)
  let activeId = null;
  let closed = {};          // 접어둔 그룹
  let dirty = false;        // 패널에서 값을 고친 뒤 아직 적용하지 않은 상태
  let actionSeq = 0;        // 사용자 조작 순번 (늦게 도착한 응답 무시용)
  let lastSync = 0;
  let tileEls = [];         // 썸네일 요소 (활성 표시만 바꿀 때 재생성하지 않으려고)
  let native = false;       // hyArrow.aip 플러그인이 있으면 라이브 효과 방식으로 동작

  /* ---------- 호스트 ---------- */
  function evalHost(code) {
    return new Promise(resolve => {
      if (!cep) { resolve('{"ok":false,"msg":"일러스트레이터 밖에서 열렸습니다."}'); return; }
      cep.evalScript(code, r => resolve(r));
    });
  }
  let queue = Promise.resolve();   // 호스트 호출을 한 줄로 세워 겹치지 않게 함
  let busy = 0;
  function call(code) {
    const run = () => rawCall(code);
    queue = queue.then(run, run);
    return queue;
  }
  async function rawCall(code) {
    busy++;
    try { return await hostCall(code); } finally { busy--; }
  }
  async function hostCall(code) {
    let r = await evalHost(code);
    if (!r || r.indexOf("EvalScript error") === 0) {
      await evalHost(`$.evalFile(${JSON.stringify(extPath() + "/jsx/hyArrow.jsx")})`);
      r = await evalHost(code);
    }
    try { return JSON.parse(r); } catch (e) { return { ok: false, msg: "스크립트 오류: " + r }; }
  }
  function say(msg, err) { statusEl.textContent = msg; statusEl.classList.toggle("err", !!err); }

  /* ---------- 파일 ---------- */
  function toPath(uri) {
    let p = decodeURIComponent(uri).replace(/^file:\/\//, "");
    if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
    return p.replace(/\\/g, "/");
  }
  function extPath() { return cep ? toPath(cep.getSystemPath("extension")) : "."; }
  function userDir() { return cep ? toPath(cep.getSystemPath("userData")) + "/hyArrow" : "."; }
  const userFile = () => userDir() + "/presets_user.json";
  function readText(path) {
    const fs = window.cep && window.cep.fs; if (!fs) return null;
    const r = fs.readFile(path); return r.err === 0 ? r.data : null;
  }
  function writeText(path, text) {
    const fs = window.cep && window.cep.fs; if (!fs) return false;
    fs.makedir(userDir()); return fs.writeFile(path, text).err === 0;
  }
  function loadPresets() {
    groups = [];
    const user = readText(userFile());
    if (user) {
      try {
        const u = JSON.parse(user);
        if (u.presets && u.presets.length) groups.push({ name: "내 스타일", presets: u.presets, user: true });
      } catch (e) { say("내 스타일 파일을 읽지 못했습니다.", true); }
    }
    const base = readText(extPath() + "/presets.json");
    if (!base) { say("presets.json을 찾을 수 없습니다.", true); return; }
    try { groups = groups.concat(JSON.parse(base).groups); }
    catch (e) { say("presets.json 형식 오류: " + e.message, true); }
  }
  const userPresets = () => (groups.find(g => g.user) || { presets: [] }).presets;
  const saveUserPresets = list => writeText(userFile(), JSON.stringify({ version: 2, presets: list }, null, 2));

  /* ---------- 현재 설정 ---------- */
  function defaults() {
    return { id: "custom", name: "직접 설정", start: { shape: "none" }, end: { shape: "triangle" },
      shaft: "solid", cap: "butt", profile: "uniform" };
  }
  function fromPreset(p) {
    const c = JSON.parse(JSON.stringify(p));
    c.profile = hyGeom.resolveProfile(c, null);
    c.shaft = c.shaft === "taper" ? "solid" : (c.shaft || "solid");
    delete c.taper;
    return c;
  }
  const SH = hyGeom.SHAPES, SN = hyGeom.SHAPE_NAMES;
  function headVal(end, key) {
    const spec = cur[end] || { shape: "none" }, d = SH[spec.shape] || SH.none;
    return spec[key] !== undefined && spec[key] !== null ? spec[key] : d[key];
  }
  // 슬라이더 기준값: 끝 화살촉이 있으면 그쪽, 없으면 시작 쪽
  const mainEnd = () => (cur.end && cur.end.shape !== "none" ? "end" : "start");
  function setHead(key, v) {
    ["start", "end"].forEach(e => {
      if (!cur[e] || cur[e].shape === "none") return;
      cur[e][key] = v;
    });
  }
  function overrides() {
    const num = id => { const v = parseFloat($(id).value); return v > 0 ? v : 0; };
    return { sw: num("sw"), headScale: 1, headPt: num("headPt"), dashPt: [num("dashLen"), num("dashGap")] };
  }

  /* ---------- UI 그리기 ---------- */
  function fillSelects() {
    const opts = Object.keys(SN).map(k => `<option value="${k}">${SN[k]}</option>`).join("");
    $("shStart").innerHTML = opts; $("shEnd").innerHTML = opts;
  }
  // 폭 슬라이더: 시작·가운데·끝 세 점으로 프로파일을 만든다
  function widthsFromProfile() {
    const prof = cur.profile || "uniform";
    return [0, 0.5, 1].map(t => Math.round(hyGeom.widthAt(prof, t) * 20) / 20);
  }
  function profileFromWidths() {
    const v = ["w0", "w1", "w2"].map(id => parseFloat($(id).value));
    cur.profile = [[0, v[0]], [0.5, v[1]], [1, v[2]]];
  }

  function renderChips() {
    const box = $("chips"); box.innerHTML = "";
    Object.keys(hyGeom.PROFILES).forEach(k => {
      const b = document.createElement("button");
      b.className = "chip" + (cur.profile === k ? " active" : "");
      b.title = hyGeom.PROFILES[k].name;
      b.innerHTML = hyGeom.profileSVG(k);
      b.addEventListener("click", () => { cur.profile = k; activeId = null; touched(); syncUI(); updateActive(); maybeApply(); });
      box.appendChild(b);
    });
  }
  function syncUI() {
    $("shStart").value = (cur.start || {}).shape || "none";
    $("shEnd").value = (cur.end || {}).shape || "none";
    const e = mainEnd(), shape = (cur[e] || {}).shape || "none";
    const set = (id, v, fmt) => { $(id).value = v; $(id + "Out").textContent = fmt(v); };
    set("len", headVal(e, "len") || 5, v => "×" + Number(v).toFixed(1));
    set("asp", headVal(e, "asp") || 0.8, v => Number(v).toFixed(2));
    set("notch", headVal(e, "notch") || 0, v => Number(v).toFixed(2));
    const tri = shape === "triangle" || shape === "stealth";
    $("notch").disabled = !tri;
    $("notch").parentElement.classList.toggle("off", !tri);
    const solid = shape === "none";
    ["len", "asp"].forEach(id => { $(id).disabled = solid; $(id).parentElement.classList.toggle("off", solid); });
    $("shaft").value = cur.shaft || "solid";
    $("gstyle").value = cur.gstyle || "";
    const dashed = cur.shaft === "dashed", dotted = cur.shaft === "dotted";
    $("dashRow").classList.toggle("off", !dashed && !dotted);
    $("dashLen").disabled = !dashed; $("dashGap").disabled = !dashed && !dotted;
    const sw = parseFloat($("sw").value) > 0 ? parseFloat($("sw").value) : 1, dd = cur.dash || [];
    const fmt = n => String(Math.round(n * 100) / 100);
    const act = cur.dash ? null : cur._dashActual;
    $("dashLen").placeholder = dashed ? fmt(act ? act[0] : (dd[0] || 4) * sw) : "길이";
    $("dashGap").placeholder = dashed ? fmt(act ? act[1] : (dd[1] || 3) * sw)
      : dotted ? fmt(act ? act[1] : (dd[1] || 2.5) * sw) : "간격";
    const w = widthsFromProfile();
    ["w0", "w1", "w2"].forEach((id, i) => { $(id).value = w[i]; });
    $("gsTarget").value = cur.gsTarget || "all";
    const locked = parseFloat($("headPt").value) > 0;
    $("btnLock").classList.toggle("active", locked);
    $("gsRow").classList.toggle("off", !cur.gstyle);
    $("gsTarget").disabled = !cur.gstyle;
    renderChips();
    $("bigPreview").innerHTML = hyGeom.previewSVG(preview(), 1);
  }
  // 미리보기에는 패널의 두께 값도 함께 넣어 화살촉 비율을 보여준다
  function preview() {
    const o = overrides(), c = JSON.parse(JSON.stringify(cur));
    c.sw = o.sw > 0 ? o.sw : 1;
    c.headPt = o.headPt;
    return c;
  }

  function updateActive() {
    tileEls.forEach(t => t.el.classList.toggle("active", t.id === activeId));
  }

  function renderGrid() {
    const grid = $("grid"), q = $("filter").value.trim().toLowerCase();
    grid.innerHTML = "";
    tileEls = [];
    let shown = 0;
    groups.forEach(g => {
      const list = q ? g.presets.filter(p => p.name.toLowerCase().includes(q)) : g.presets;
      if (!list.length) return;
      shown += list.length;
      const head = document.createElement("button");
      const isClosed = !q && closed[g.name];
      head.className = "group-head" + (isClosed ? " closed" : "");
      head.innerHTML = `<span class="caret">▾</span><span></span>`;
      head.lastChild.textContent = `${g.name} (${list.length})`;
      const wrap = document.createElement("div");
      wrap.className = "tiles" + (isClosed ? " hidden" : "");
      head.addEventListener("click", () => {
        closed[g.name] = !closed[g.name];
        try { localStorage.setItem("hyArrowClosed", JSON.stringify(closed)); } catch (e) {}
        renderGrid();
      });
      list.forEach(p => {
        const t = document.createElement("div");
        t.className = "tile" + (p.id === activeId ? " active" : "");
        t.tabIndex = 0; t.title = p.name;
        t.innerHTML = hyGeom.previewSVG(p, 1) + `<span class="nm"></span>`;
        t.querySelector(".nm").textContent = p.name;
        const pick = () => {
          const cfg = fromPreset(p);
          cur = cfg; activeId = p.id; dirty = false;
          syncUI(); updateActive();
          apply(cfg);                   // 클릭한 순간의 설정으로 적용
        };
        t.addEventListener("click", pick);
        t.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); pick(); } });
        if (g.user) {
          const del = document.createElement("button");
          del.className = "del"; del.textContent = "×"; del.title = "이 스타일 삭제";
          del.addEventListener("click", ev => { ev.stopPropagation(); deleteUser(p.id); });
          t.appendChild(del);
        }
        tileEls.push({ el: t, id: p.id });
        wrap.appendChild(t);
      });
      grid.appendChild(head); grid.appendChild(wrap);
    });
    if (!shown) grid.innerHTML = `<p class="empty">검색 결과가 없습니다.</p>`;
  }

  /* ---------- 동작 ---------- */
  // 빠르게 연달아 누르면 중간 것은 건너뛰고 마지막 설정만 적용한다
  let inFlight = false, pendingJob = null;
  function apply(cfg) {
    actionSeq++;
    const job = { cfg: JSON.stringify(cfg || cur), over: overrides() };
    if (inFlight) { pendingJob = job; return Promise.resolve({ ok: true, msg: "" }); }
    return runJobs(job);
  }
  async function runJobs(job) {
    inFlight = true;
    let last = null;
    try {
      while (job) {
        let code;
        if (native) {
          const payload = Object.assign(JSON.parse(job.cfg), job.over);
          delete payload._dashActual;
          code = `hyArrowNative.apply(${JSON.stringify(JSON.stringify(payload))})`;
        } else {
          const over = Object.assign({}, job.over, { quiet: true });
          code = `hyArrow.applyPreset(${job.cfg}, ${JSON.stringify(over)})`;
        }
        last = await call(code);
        say(last.msg || "", !last.ok);
        if (last.ok) dirty = false;
        job = pendingJob; pendingJob = null;
      }
      if (!native) await call("hyArrow.redraw()");   // 마지막에 한 번만 화면 갱신
    } finally { inFlight = false; }
    return last || { ok: false, msg: "" };
  }
  function touched() { dirty = true; actionSeq++; }
  function maybeApply() { if ($("live").checked) apply(); }
  async function loadStyles() {
    const r = await call("hyArrow.styles()");
    const sel = $("gstyle"), keep = (cur && cur.gstyle) || "";
    sel.innerHTML = "";
    const none = new Option("그래픽 스타일 없음", "");
    sel.appendChild(none);
    (r.data || []).forEach(n => sel.appendChild(new Option(n, n)));
    sel.value = keep;
  }
  async function syncFromSelection() {
    if (dirty || busy || inFlight || pendingJob) return;   // 작업 중에는 건드리지 않음
    const my = ++actionSeq;
    const r = await call(native ? "hyArrowNative.info()" : "hyArrow.info()");
    if (my !== actionSeq) return;       // 그 사이 사용자가 뭔가 했으면 결과를 버림
    if (!r.ok || !r.data) return;
    const d = r.data;
    cur = fromPreset(d);
    activeId = d.id || null;
    if (d.sw > 0) $("sw").value = Math.round(d.sw * 100) / 100;
    $("headPt").value = d.headPt > 0 ? Math.round(d.headPt * 100) / 100 : "";
    const dp = d.dashPt || [];
    if (native) {
      // 실제 점선 값은 칸 안내로만 보여준다 (칸에 넣으면 다음 프리셋 적용 때 덮어써짐)
      cur._dashActual = cur.shaft === "solid" ? null : dp;
      $("dashLen").value = ""; $("dashGap").value = "";
      // 플러그인은 점선 배수를 기억하지 않으므로 실제 점선 값을 두께로 나눠 되살린다.
      // (없으면 두께 등 다른 값을 바꿀 때 점선 길이·간격이 기본값으로 돌아감)
      const swNow = d.sw > 0 ? d.sw : 1, r3 = n => Math.round(n / swNow * 1000) / 1000;
      if (cur.shaft !== "solid" && dp.length >= 2) cur.dash = [r3(dp[0] || 0), r3(dp[1] || 0)];
    } else {
      $("dashLen").value = dp[0] > 0 ? dp[0] : "";
      $("dashGap").value = dp[1] > 0 ? dp[1] : "";
    }
    syncUI(); updateActive();
  }
  async function saveCurrent() {
    let nm = $("filter").value.trim();
    if (!nm) {
      try { nm = window.prompt("스타일 이름", cur.name || "내 화살표") || ""; } catch (e) { nm = ""; }
      nm = nm.trim();
    }
    if (!nm) { say("검색칸에 이름을 적고 저장을 누르면 그 이름으로 저장됩니다.", true); return; }
    const p = JSON.parse(JSON.stringify(cur));
    p.id = "u_" + Date.now().toString(36);
    p.name = nm;
    const swNow = parseFloat($("sw").value) > 0 ? parseFloat($("sw").value) : (cur.sw > 0 ? cur.sw : 1);
    if (p._dashActual && p.shaft !== "solid") {
      p.dash = [Math.round(p._dashActual[0] / swNow * 100) / 100, Math.round(p._dashActual[1] / swNow * 100) / 100];
    }
    delete p._dashActual; delete p.native; delete p.gsTarget;
    delete p.s0; delete p.s1; delete p.sw; delete p.dashPt; delete p.fixedMM; delete p.headScale;
    if (!saveUserPresets(userPresets().concat([p]))) { say("저장 실패: " + userFile(), true); return; }
    $("filter").value = "";
    loadPresets(); activeId = p.id; renderGrid();
    say(`'${nm}' 저장됨`);
  }
  function deleteUser(id) {
    if (!saveUserPresets(userPresets().filter(p => p.id !== id))) { say("삭제 실패", true); return; }
    loadPresets(); renderGrid(); say("삭제됨");
  }

  /* ---------- 테마 ---------- */
  function applyTheme() {
    if (!cep) return;
    try {
      const c = JSON.parse(cep.getHostEnvironment()).appSkinInfo.panelBackgroundColor.color;
      document.documentElement.style.setProperty("--bg", `rgb(${Math.round(c.red)},${Math.round(c.green)},${Math.round(c.blue)})`);
      document.body.classList.toggle("light", (c.red + c.green + c.blue) / 3 > 140);
    } catch (e) {}
  }

  /* ---------- 이벤트 ---------- */
  function bindHeadSelect(id, which) {
    $(id).addEventListener("change", () => {
      const shape = $(id).value;
      cur[which] = shape === "none" ? { shape: "none" } : { shape };
      activeId = null; touched(); syncUI(); updateActive(); maybeApply();
    });
  }
  bindHeadSelect("shStart", "start");
  bindHeadSelect("shEnd", "end");
  [["len", "len"], ["asp", "asp"], ["notch", "notch"]].forEach(([id, key]) => {
    $(id).addEventListener("input", () => {
      setHead(key, parseFloat($(id).value));
      activeId = null; touched(); updateActive();
      $(id + "Out").textContent = key === "len" ? "×" + Number($(id).value).toFixed(1) : Number($(id).value).toFixed(2);
      $("bigPreview").innerHTML = hyGeom.previewSVG(preview(), 1);
    });
    $(id).addEventListener("change", maybeApply);
  });
  $("shaft").addEventListener("change", () => { cur.shaft = $("shaft").value; activeId = null; touched(); syncUI(); maybeApply(); });
  $("gstyle").addEventListener("change", () => {
    cur.gstyle = $("gstyle").value || undefined;
    if (cur.gstyle && !cur.gsTarget) cur.gsTarget = "all";
    touched(); syncUI();
    if (cur.gstyle) say(native ? "그래픽 스타일 위에 화살표를 얹습니다."
      : (cur.gsTarget === "stroke" ? "몸통 획에 적용 — 가변 폭 프로파일용" : "도형 전체에 적용 — 그림자 같은 효과용"));
    maybeApply();
  });
  ["w0", "w1", "w2"].forEach(id => {
    $(id).addEventListener("input", () => {
      profileFromWidths(); activeId = null; touched(); updateActive();
      renderChips();
      $("bigPreview").innerHTML = hyGeom.previewSVG(preview(), 1);
    });
    $(id).addEventListener("change", maybeApply);
  });
  $("btnLock").addEventListener("click", () => {
    const on = !$("btnLock").classList.contains("active");
    if (on) {
      // 지금 화살촉 크기를 그대로 묶어둔다
      const sw = parseFloat($("sw").value);
      $("headPt").value = cur.headPt > 0 ? cur.headPt : (sw > 0 ? sw : 1);
    } else {
      $("headPt").value = "";
    }
    touched(); syncUI(); maybeApply();
  });
  $("gsTarget").addEventListener("change", () => { cur.gsTarget = $("gsTarget").value; touched(); maybeApply(); });
  ["sw", "headPt", "dashLen", "dashGap"].forEach(id => $(id).addEventListener("change", () => { touched(); syncUI(); maybeApply(); }));
  $("btnApply").addEventListener("click", () => apply());
  $("btnFlip").addEventListener("click", async () => {
    const r = await call(native ? "hyArrowNative.flip()" : "hyArrow.flip()");
    say(r.msg, !r.ok); syncFromSelection();
  });
  $("btnSame").addEventListener("click", async () => {
    const r = await call(native ? "hyArrowNative.selectSame()" : "hyArrow.selectSame()");
    say(r.msg, !r.ok);
  });
  $("btnRefreshAll").addEventListener("click", async () => {
    const r = await call("hyArrow.refreshAll(false)");
    say(r.msg, !r.ok);
  });
  $("btnRelease").addEventListener("click", async () => {
    const r = await call(native ? "hyArrowNative.remove()" : "hyArrow.release()");
    say(r.msg, !r.ok);
  });
  $("btnFinalize").addEventListener("click", async () => {
    const keep = $("keepOrig").checked;
    const r = await call(`hyArrow.finalize(${keep ? "true" : "false"})`);
    say(r.msg, !r.ok);
  });
  $("btnReopen").addEventListener("click", async () => {
    const r = await call("hyArrow.reopen()");
    say(r.msg, !r.ok);
    if (r.ok) { lastSync = 0; syncFromSelection(); }
  });
  try {
    const k = localStorage.getItem("hyArrowKeep");
    if (k !== null) $("keepOrig").checked = k === "1";
  } catch (e) {}
  $("keepOrig").addEventListener("change", () => {
    try { localStorage.setItem("hyArrowKeep", $("keepOrig").checked ? "1" : "0"); } catch (e) {}
  });
  $("btnSave").addEventListener("click", saveCurrent);
  $("filter").addEventListener("input", renderGrid);
  document.body.addEventListener("mouseenter", async () => {
    const now = Date.now();
    if (now - lastSync < 800) return;
    lastSync = now;
    // 선을 고쳤으면 선택한 화살표를 먼저 다시 그린다
    if (!native && $("follow").checked && !dirty && !inFlight) {
      const r = await call("hyArrow.refresh(false)");
      if (r && r.n > 0) { await call("hyArrow.redraw()"); say(r.msg); }
    }
    syncFromSelection(); loadStyles();
  });

  try { closed = JSON.parse(localStorage.getItem("hyArrowClosed") || "{}"); } catch (e) { closed = {}; }
  applyTheme();
  fillSelects();
  loadPresets();
  cur = defaults();
  syncUI();
  renderGrid();
  loadStyles();
  call("hyArrowNative.ping()").then(r => {
    native = !!(r && r.ok);
    document.body.classList.toggle("native", native);
    if (native) say("hy Arrow 플러그인 연결됨 — 선을 고치면 화살표가 바로 따라옵니다.");
  });
})();
