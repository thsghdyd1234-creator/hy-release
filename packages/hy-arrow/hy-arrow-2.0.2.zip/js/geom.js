/* 썸네일용 형상 — jsx/hyArrow.jsx 의 headGeom / 몸통 생성 규칙과 동일 */
(function (root) {
  const SHAPES = {
    none: { len: 0, asp: 0 }, triangle: { len: 5, asp: 0.8, notch: 0 }, stealth: { len: 6, asp: 0.8, notch: 0.35 },
    open: { len: 4, asp: 1.2 }, chevron: { len: 4, asp: 1.4 }, harpoon: { len: 5, asp: 0.8 },
    dot: { len: 3, asp: 1 }, ring: { len: 3.5, asp: 1 }, square: { len: 3, asp: 1 },
    diamond: { len: 5, asp: 0.6 }, bar: { len: 4, asp: 1 }, slash: { len: 4, asp: 1 }
  };

  // 폭 프로파일: [위치 0~1, 두께 배수 0~1]
  const PROFILES = {
    uniform:    { name: "균일",     pts: [[0,1],[1,1]] },
    leaf:       { name: "잎",       pts: [[0,0],[0.5,1],[1,0]] },
    bowtie:     { name: "물결",     pts: [[0,0],[0.25,1],[0.5,0.25],[0.75,1],[1,0]] },
    block:      { name: "각진",     pts: [[0,0.4],[0.18,1],[0.82,1],[1,0.4]] },
    taperEnd:   { name: "끝 가늘게", pts: [[0,1],[1,0]] },
    taperStart: { name: "시작 가늘게", pts: [[0,0],[1,1]] },
    spear:      { name: "창",       pts: [[0,0],[0.7,1],[1,0.45]] }
  };

  function profilePts(p) {
    if (p instanceof Array) return p;
    return (PROFILES[p] || PROFILES.uniform).pts;
  }
  function isUniform(p) {
    const a = profilePts(p);
    for (let i = 0; i < a.length; i++) if (Math.abs(a[i][1] - 1) > 0.001) return false;
    return true;
  }
  function widthAt(prof, t) {
    const a = profilePts(prof);
    if (t <= a[0][0]) return a[0][1];
    for (let i = 1; i < a.length; i++) {
      if (t <= a[i][0]) {
        const span = a[i][0] - a[i-1][0];
        const u = span <= 0 ? 1 : (t - a[i-1][0]) / span;
        const s = u * u * (3 - 2 * u);               // 부드럽게 연결
        return a[i-1][1] + (a[i][1] - a[i-1][1]) * s;
      }
    }
    return a[a.length-1][1];
  }

  /* ---- 경로 샘플러: {pts, cum, total} ---- */
  function sampler(pts) {
    const cum = [0];
    for (let i = 1; i < pts.length; i++) cum.push(cum[i-1] + Math.hypot(pts[i][0]-pts[i-1][0], pts[i][1]-pts[i-1][1]));
    return { pts, cum, total: cum[cum.length-1] };
  }
  function at(S, s) {
    const { pts, cum } = S;
    let i = 1;
    while (i < cum.length - 1 && cum[i] < s) i++;
    const seg = cum[i] - cum[i-1] || 1;
    const u = Math.min(Math.max((s - cum[i-1]) / seg, 0), 1);
    const a = pts[i-1], b = pts[i];
    const p = [a[0] + (b[0]-a[0])*u, a[1] + (b[1]-a[1])*u];
    const L = Math.hypot(b[0]-a[0], b[1]-a[1]) || 1;
    return { p, t: [(b[0]-a[0])/L, (b[1]-a[1])/L] };
  }
  // 점선 구간 나누기 (pt 단위). on<=0 이면 전체 한 덩어리
  function chunks(total, on, gap) {
    if (!(on > 0) || !(gap > 0)) return [[0, total]];
    const out = [];
    for (let s = 0; s < total - 0.01; s += on + gap) out.push([s, Math.min(s + on, total)]);
    return out;
  }
  // 한 구간의 윤곽 폴리곤
  function outline(S, s0, s1, prof, sw, step) {
    const stops = [s0];
    for (let i = 0; i < S.cum.length; i++) if (S.cum[i] > s0 + 0.01 && S.cum[i] < s1 - 0.01) stops.push(S.cum[i]);
    const n = Math.max(2, Math.ceil((s1 - s0) / (step || 2)));
    for (let i = 1; i < n; i++) stops.push(s0 + (s1 - s0) * i / n);
    stops.push(s1);
    stops.sort((a, b) => a - b);
    const top = [], bot = [];
    for (const s of stops) {
      const q = at(S, s), w = widthAt(prof, S.total ? s / S.total : 0) * sw / 2;
      const nv = [-q.t[1], q.t[0]];
      top.push([q.p[0] + nv[0]*w, q.p[1] + nv[1]*w]);
      bot.push([q.p[0] - nv[0]*w, q.p[1] - nv[1]*w]);
    }
    return top.concat(bot.reverse());
  }
  // 점 모양 점선 + 프로파일 → 원 배열
  function dots(S, gap, prof, sw) {
    const out = [];
    for (let s = 0; s <= S.total + 0.01; s += Math.max(gap, 0.2)) {
      const q = at(S, s), r = widthAt(prof, S.total ? s / S.total : 0) * sw / 2;
      if (r > 0.01) out.push({ c: q.p, r });
    }
    return out;
  }

  function headGeom(shape, L, W, sw, notch) {
    const h = W / 2, g = { items: [], setback: 0 };
    if (!(notch > 0)) notch = 0;
    switch (shape) {
      case "triangle": case "stealth":
        if (notch > 0) {
          g.items.push({ k: "poly", pts: [[0,0],[-L,h],[-L*(1-notch),0],[-L,-h]], closed: true, fill: true });
          g.setback = L * (1 - notch) * 0.95;
        } else {
          g.items.push({ k: "poly", pts: [[0,0],[-L,h],[-L,-h]], closed: true, fill: true });
          g.setback = L * 0.9;
        }
        break;
      case "open": {
        const bx = 0.8 * L, m = (sw / 2) / Math.max(h / Math.hypot(h, bx), 0.05);
        g.items.push({ k: "poly", pts: [[-bx-m,h],[-m,0],[-bx-m,-h]], stroke: true, join: "miter", cap: "butt" }); g.setback = m; break;
      }
      case "chevron": {
        const m = sw / 2;
        g.items.push({ k: "poly", pts: [[-L-m,h],[-m,0],[-L-m,-h]], stroke: true, join: "round", cap: "round" }); g.setback = m; break;
      }
      case "harpoon": g.items.push({ k: "poly", pts: [[-L,h],[0,0]], stroke: true, join: "round", cap: "round" }); break;
      case "dot": g.items.push({ k: "circle", c: [0,0], r: h, fill: true }); break;
      case "ring": g.items.push({ k: "circle", c: [-h - sw/2, 0], r: h, stroke: true }); g.setback = 2*h + sw/2; break;
      case "square": g.items.push({ k: "poly", pts: [[h,h],[-h,h],[-h,-h],[h,-h]], closed: true, fill: true }); break;
      case "diamond": g.items.push({ k: "poly", pts: [[0,0],[-L/2,h],[-L,0],[-L/2,-h]], closed: true, fill: true }); g.setback = L * 0.75; break;
      case "bar": g.items.push({ k: "poly", pts: [[0,h],[0,-h]], stroke: true, cap: "butt" }); break;
      case "slash": { const a = h * 0.7071; g.items.push({ k: "poly", pts: [[-a,-a],[a,a]], stroke: true, cap: "butt" }); break; }
    }
    return g;
  }

  // 옛 preset(shaft:"taper")도 프로파일로 환산
  function resolveProfile(p, over) {
    if (over) return over;
    if (p.profile) return p.profile;
    if (p.shaft === "taper") return [[0, p.taper >= 0 ? p.taper : 0.15], [1, 1]];
    return "uniform";
  }

  const f = n => Math.round(n * 100) / 100;

  function previewSVG(p, headScale, profOver) {
    const W = 120, H = 32, y = H / 2, x0 = 12, x1 = W - 12;
    const clamp = n => Math.min(Math.max(n, 0.4), 9);
    const scale = Math.min(Math.max(headScale || 1, 0.4), 1.8);
    const prof = resolveProfile(p, profOver);
    const uni = isUniform(prof);
    // 몸통 두께를 그대로 반영하고, 화살촉 기준 두께가 따로 있으면 화살촉만 그 값으로
    const swLine = p.sw > 0 ? clamp(p.sw) : (uni ? 1.5 : 2.2);
    const hw = p.headPt > 0 ? clamp(p.headPt) : swLine;
    const sw = swLine;
    const ends = [{ nm: "start", tip: [x0, y], d: [-1, 0] }, { nm: "end", tip: [x1, y], d: [1, 0] }];
    let heads = "", sb = [0, 0];
    ends.forEach((e, i) => {
      const spec = p[e.nm];
      if (!spec || !SHAPES[spec.shape] || spec.shape === "none") return;
      const d = SHAPES[spec.shape];
      const L = (spec.len || d.len) * hw * scale, Wd = L * (spec.asp || d.asp);
      const nt = (spec.notch >= 0 && spec.notch !== null) ? spec.notch : d.notch;
      const g = headGeom(spec.shape, L, Wd, hw, nt);
      const T = (x, yy) => [e.tip[0] + e.d[0]*x - e.d[1]*yy, e.tip[1] + e.d[1]*x + e.d[0]*yy];
      g.items.forEach(it => {
        const paint = it.fill ? `fill="currentColor"`
          : `fill="none" stroke="currentColor" stroke-width="${hw}" stroke-linecap="${it.cap || "butt"}" stroke-linejoin="${it.join === "round" ? "round" : it.join === "miter" ? "miter" : "bevel"}" stroke-miterlimit="20"`;
        if (it.k === "circle") { const c = T(it.c[0], it.c[1]); heads += `<circle cx="${f(c[0])}" cy="${f(c[1])}" r="${f(it.r)}" ${paint}/>`; }
        else {
          const pts = it.pts.map(q => T(q[0], q[1]).map(f).join(",")).join(" ");
          heads += it.closed ? `<polygon points="${pts}" ${paint}/>` : `<polyline points="${pts}" ${paint}/>`;
        }
      });
      sb[i] = g.setback;
    });
    const a = x0 + sb[0], b = x1 - sb[1];
    const dd = p.dash || [];
    let body = "";
    if (uni) {
      let dash = "", cap = p.cap === "round" ? "round" : "butt";
      if (p.shaft === "dashed") dash = `stroke-dasharray="${(dd[0] || 4) * swLine} ${(dd[1] || 3) * swLine}"`;
      if (p.shaft === "dotted") { dash = `stroke-dasharray="0 ${(dd[1] || 2.5) * swLine}"`; cap = "round"; }
      body = `<line x1="${f(a)}" y1="${y}" x2="${f(b)}" y2="${y}" stroke="currentColor" stroke-width="${swLine}" stroke-linecap="${cap}" ${dash}/>`;
    } else {
      const S = sampler([[a, y], [b, y]]);
      if (p.shaft === "dotted") {
        body = dots(S, (dd[1] || 2.5) * sw, prof, sw).map(c => `<circle cx="${f(c.c[0])}" cy="${f(c.c[1])}" r="${f(c.r)}" fill="currentColor"/>`).join("");
      } else {
        const on = p.shaft === "dashed" ? (dd[0] || 4) * sw : 0, gap = p.shaft === "dashed" ? (dd[1] || 3) * sw : 0;
        body = chunks(S.total, on, gap).map(c =>
          `<polygon points="${outline(S, c[0], c[1], prof, sw, 1.5).map(q => q.map(f).join(",")).join(" ")}" fill="currentColor"/>`).join("");
      }
    }
    return `<svg viewBox="0 0 ${W} ${H}" aria-hidden="true">${body}${heads}</svg>`;
  }

  // 폭 프로파일 칩용 미니 썸네일
  function profileSVG(key) {
    const W = 40, H = 14, S = sampler([[2, H/2], [W-2, H/2]]);
    const pts = outline(S, 0, S.total, key, 9, 1.2).map(q => q.map(f).join(",")).join(" ");
    return `<svg viewBox="0 0 ${W} ${H}" aria-hidden="true"><polygon points="${pts}" fill="currentColor"/></svg>`;
  }

  const SHAPE_NAMES = {
    none: "없음", triangle: "삼각", stealth: "오목 삼각", open: "열린 V", chevron: "둥근 V",
    harpoon: "반쪽", dot: "점", ring: "원", square: "사각", diamond: "마름모", bar: "바", slash: "사선"
  };
  root.hyGeom = { previewSVG, profileSVG, PROFILES, SHAPES, SHAPE_NAMES, resolveProfile, isUniform, widthAt };
})(window);
