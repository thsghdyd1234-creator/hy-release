/*  hy Arrow — Illustrator host script (ExtendScript, ES3)
    화살표 = 그룹 { hyArrow_shaft(원본 선), 화살촉 도형들 } + group.note 에 설정 JSON
*/
var hyArrow = (function () {
    var TAG = "hyArrow:";
    var SHAFT = "hyArrow_shaft";
    var PT_PER_MM = 2.834645669;

    // 모양별 기본값: len = 선 두께 배수, asp = 폭/길이
    var SHAPES = {
        none:     { len: 0,   asp: 0 },
        triangle: { len: 5,   asp: 0.8, notch: 0 },
        stealth:  { len: 6,   asp: 0.8, notch: 0.35 },
        open:     { len: 4,   asp: 1.2 },
        chevron:  { len: 4,   asp: 1.4 },
        harpoon:  { len: 5,   asp: 0.8 },
        dot:      { len: 3,   asp: 1 },
        ring:     { len: 3.5, asp: 1 },
        square:   { len: 3,   asp: 1 },
        diamond:  { len: 5,   asp: 0.6 },
        bar:      { len: 4,   asp: 1 },
        slash:    { len: 4,   asp: 1 }
    };

    // 폭 프로파일: [위치 0~1, 두께 배수 0~1] — js/geom.js 의 PROFILES 와 동일
    var PROFILES = {
        uniform:    [[0,1],[1,1]],
        leaf:       [[0,0],[0.5,1],[1,0]],
        bowtie:     [[0,0],[0.25,1],[0.5,0.25],[0.75,1],[1,0]],
        block:      [[0,0.4],[0.18,1],[0.82,1],[1,0.4]],
        taperEnd:   [[0,1],[1,0]],
        taperStart: [[0,0],[1,1]],
        spear:      [[0,0],[0.7,1],[1,0.45]]
    };

    /* ---------- JSON (ExtendScript에는 JSON 객체가 없음) ---------- */
    function toJSON(v) {
        if (v === null || v === undefined) return "null";
        var t = typeof v, i, a;
        if (t === "number") return isFinite(v) ? String(Math.round(v * 10000) / 10000) : "null";
        if (t === "boolean") return v ? "true" : "false";
        if (t === "string") return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
        if (v instanceof Array) { a = []; for (i = 0; i < v.length; i++) a.push(toJSON(v[i])); return "[" + a.join(",") + "]"; }
        a = [];
        for (var k in v) { if (v.hasOwnProperty(k) && k.charAt(0) !== "_") a.push(toJSON(k) + ":" + toJSON(v[k])); }
        return "{" + a.join(",") + "}";
    }
    function fromJSON(s) { try { return eval("(" + s + ")"); } catch (e) { return null; } }
    function clone(o) { return fromJSON(toJSON(o)); }
    function res(ok, n, msg, extra) {
        var r = { ok: ok, n: n || 0, msg: msg || "" };
        if (extra) r.data = extra;
        return toJSON(r);
    }

    /* ---------- 벡터 ---------- */
    function sub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }
    function vlen(v) { return Math.sqrt(v[0] * v[0] + v[1] * v[1]); }
    function same(a, b) { return Math.abs(a[0] - b[0]) < 0.001 && Math.abs(a[1] - b[1]) < 0.001; }
    function norm(v) { var l = vlen(v); return l < 1e-9 ? [1, 0] : [v[0] / l, v[1] / l]; }
    // 로컬 좌표(팁=원점, +x=진행방향) → 문서 좌표
    function T(tip, d, x, y) { return [tip[0] + d[0] * x - d[1] * y, tip[1] + d[1] * x + d[0] * y]; }

    function endInfo(path, atEnd) {
        var pts = path.pathPoints, n = pts.length;
        var p = atEnd ? pts[n - 1] : pts[0];
        var q = atEnd ? pts[n - 2] : pts[1];
        var a = p.anchor, ref;
        var h = atEnd ? p.leftDirection : p.rightDirection;
        if (!same(h, a)) ref = h;
        else {
            var qh = atEnd ? q.rightDirection : q.leftDirection;
            ref = same(qh, a) ? q.anchor : qh;
        }
        return { pt: p, tip: [a[0], a[1]], dir: norm(sub(a, ref)) };
    }
    function shiftPoint(p, dx, dy) {
        var a = p.anchor, l = p.leftDirection, r = p.rightDirection;
        p.anchor = [a[0] + dx, a[1] + dy];
        p.leftDirection = [l[0] + dx, l[1] + dy];
        p.rightDirection = [r[0] + dx, r[1] + dy];
    }
    function isStraight(path) {
        var pts = path.pathPoints;
        if (pts.length !== 2) return false;
        for (var i = 0; i < 2; i++) {
            if (!same(pts[i].anchor, pts[i].leftDirection) || !same(pts[i].anchor, pts[i].rightDirection)) return false;
        }
        return true;
    }

    /* ---------- 몸통(폭 프로파일 + 점선) ---------- */
    function profilePts(p) {
        if (p instanceof Array) return p;
        return PROFILES[p] || PROFILES.uniform;
    }
    function isUniform(p) {
        var a = profilePts(p);
        for (var i = 0; i < a.length; i++) if (Math.abs(a[i][1] - 1) > 0.001) return false;
        return true;
    }
    function widthAt(prof, t) {
        var a = profilePts(prof);
        if (t <= a[0][0]) return a[0][1];
        for (var i = 1; i < a.length; i++) {
            if (t <= a[i][0]) {
                var span = a[i][0] - a[i - 1][0];
                var u = span <= 0 ? 1 : (t - a[i - 1][0]) / span;
                var sm = u * u * (3 - 2 * u);
                return a[i - 1][1] + (a[i][1] - a[i - 1][1]) * sm;
            }
        }
        return a[a.length - 1][1];
    }
    function resolveProfile(P) {
        if (P.profile) return P.profile;
        if (P.shaft === "taper") return [[0, P.taper >= 0 ? P.taper : 0.15], [1, 1]];
        return "uniform";
    }
    function bez(a, c1, c2, b, t) {
        var u = 1 - t, w0 = u * u * u, w1 = 3 * u * u * t, w2 = 3 * u * t * t, w3 = t * t * t;
        return [a[0] * w0 + c1[0] * w1 + c2[0] * w2 + b[0] * w3,
                a[1] * w0 + c1[1] * w1 + c2[1] * w2 + b[1] * w3];
    }
    function samplePath(path) {
        var P = path.pathPoints, pts = [], i, j;
        for (i = 0; i < P.length - 1; i++) {
            var a = P[i].anchor, c1 = P[i].rightDirection, c2 = P[i + 1].leftDirection, b = P[i + 1].anchor;
            var approx = vlen(sub(a, c1)) + vlen(sub(c1, c2)) + vlen(sub(c2, b));
            var steps = Math.max(8, Math.min(200, Math.ceil(approx / 2)));
            for (j = (i === 0 ? 0 : 1); j <= steps; j++) pts.push(bez(a, c1, c2, b, j / steps));
        }
        return pts;
    }
    function sampler(pts) {
        var cum = [0];
        for (var i = 1; i < pts.length; i++) cum.push(cum[i - 1] + vlen(sub(pts[i], pts[i - 1])));
        return { pts: pts, cum: cum, total: cum[cum.length - 1] };
    }
    function at(S, s) {
        var cum = S.cum, i = 1;
        while (i < cum.length - 1 && cum[i] < s) i++;
        var seg = cum[i] - cum[i - 1] || 1;
        var u = Math.min(Math.max((s - cum[i - 1]) / seg, 0), 1);
        var a = S.pts[i - 1], b = S.pts[i];
        var L = vlen(sub(b, a)) || 1;
        return { p: [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u],
                 t: [(b[0] - a[0]) / L, (b[1] - a[1]) / L] };
    }
    function chunks(total, on, gap) {
        if (!(on > 0) || !(gap > 0)) return [[0, total]];
        var out = [];
        for (var s = 0; s < total - 0.01; s += on + gap) out.push([s, Math.min(s + on, total)]);
        return out;
    }
    function outline(S, s0, s1, prof, sw, step) {
        var stops = [s0], i;
        for (i = 0; i < S.cum.length; i++) if (S.cum[i] > s0 + 0.01 && S.cum[i] < s1 - 0.01) stops.push(S.cum[i]);
        var n = Math.max(2, Math.ceil((s1 - s0) / (step || 2)));
        for (i = 1; i < n; i++) stops.push(s0 + (s1 - s0) * i / n);
        stops.push(s1);
        stops.sort(function (a, b) { return a - b; });
        var top = [], bot = [];
        for (i = 0; i < stops.length; i++) {
            var q = at(S, stops[i]), w = widthAt(prof, S.total ? stops[i] / S.total : 0) * sw / 2;
            var nv = [-q.t[1], q.t[0]];
            top.push([q.p[0] + nv[0] * w, q.p[1] + nv[1] * w]);
            bot.push([q.p[0] - nv[0] * w, q.p[1] - nv[1] * w]);
        }
        bot.reverse();
        return top.concat(bot);
    }

    /* ---------- 화살촉 형상 (panel/js/geom.js 와 동일 규칙) ---------- */
    function headGeom(shape, L, W, sw, notch) {
        var h = W / 2, g = { items: [], setback: 0 }, m, bx, a;
        if (!(notch > 0)) notch = 0;
        switch (shape) {
            case "triangle":
            case "stealth":
                if (notch > 0) {
                    g.items.push({ k: "poly", pts: [[0, 0], [-L, h], [-L * (1 - notch), 0], [-L, -h]], closed: true, fill: true });
                    g.setback = L * (1 - notch) * 0.95;
                } else {
                    g.items.push({ k: "poly", pts: [[0, 0], [-L, h], [-L, -h]], closed: true, fill: true });
                    g.setback = L * 0.9;
                }
                break;
            case "open":
                bx = 0.8 * L;
                m = (sw / 2) / Math.max(h / Math.sqrt(h * h + bx * bx), 0.05);
                g.items.push({ k: "poly", pts: [[-bx - m, h], [-m, 0], [-bx - m, -h]], closed: false, stroke: true, join: "miter", cap: "butt" });
                g.setback = m; break;
            case "chevron":
                m = sw / 2;
                g.items.push({ k: "poly", pts: [[-L - m, h], [-m, 0], [-L - m, -h]], closed: false, stroke: true, join: "round", cap: "round" });
                g.setback = m; break;
            case "harpoon":
                g.items.push({ k: "poly", pts: [[-L, h], [0, 0]], closed: false, stroke: true, join: "round", cap: "round" });
                break;
            case "dot":
                g.items.push({ k: "circle", c: [0, 0], r: h, fill: true }); break;
            case "ring":
                g.items.push({ k: "circle", c: [-h - sw / 2, 0], r: h, stroke: true });
                g.setback = 2 * h + sw / 2; break;
            case "square":
                g.items.push({ k: "poly", pts: [[h, h], [-h, h], [-h, -h], [h, -h]], closed: true, fill: true }); break;
            case "diamond":
                g.items.push({ k: "poly", pts: [[0, 0], [-L / 2, h], [-L, 0], [-L / 2, -h]], closed: true, fill: true });
                g.setback = L * 0.75; break;
            case "bar":
                g.items.push({ k: "poly", pts: [[0, h], [0, -h]], closed: false, stroke: true, cap: "butt" }); break;
            case "slash":
                a = h * 0.7071;
                g.items.push({ k: "poly", pts: [[-a, -a], [a, a]], closed: false, stroke: true, cap: "butt" }); break;
        }
        return g;
    }

    function styleItem(item, it, sw, color) {
        if (it.fill) {
            item.filled = true; item.fillColor = color; item.stroked = false;
        } else {
            item.filled = false; item.stroked = true;
            item.strokeColor = color; item.strokeWidth = sw; item.strokeDashes = [];
            item.strokeCap = it.cap === "round" ? StrokeCap.ROUNDENDCAP : StrokeCap.BUTTENDCAP;
            item.strokeJoin = it.join === "round" ? StrokeJoin.ROUNDENDJOIN :
                (it.join === "miter" ? StrokeJoin.MITERENDJOIN : StrokeJoin.BEVELENDJOIN);
            item.strokeMiterLimit = 20;
        }
    }

    function drawHead(grp, g, tip, dir, sw, color) {
        for (var i = 0; i < g.items.length; i++) {
            var it = g.items[i], item;
            if (it.k === "circle") {
                var c = T(tip, dir, it.c[0], it.c[1]);
                item = grp.pathItems.ellipse(c[1] + it.r, c[0] - it.r, it.r * 2, it.r * 2);
            } else {
                var w = [];
                for (var j = 0; j < it.pts.length; j++) w.push(T(tip, dir, it.pts[j][0], it.pts[j][1]));
                item = grp.pathItems.add();
                item.setEntirePath(w);
                item.closed = !!it.closed;
            }
            styleItem(item, it, sw, color);
            item.name = "hyArrow_head";
        }
    }

    function defaultColor() { var c = new GrayColor(); c.gray = 100; return c; }
    function usable(c) { return c && c.typename !== "NoColor"; }

    /* ---------- 빌드 ---------- */
    function build(grp, shaft, P, color) {
        var sw = P.sw > 0 ? P.sw : 1;
        P.sw = sw;
        shaft.filled = false;
        shaft.stroked = true;
        shaft.strokeWidth = sw;
        shaft.strokeColor = color;
        shaft.strokeJoin = StrokeJoin.ROUNDENDJOIN;

        var hw = P.headPt > 0 ? P.headPt : sw;   // 화살촉 크기 기준 (몸통 두께와 분리 가능)
        var total = 0;
        try { total = shaft.length; } catch (e) { total = 1e9; }
        var info = { start: endInfo(shaft, false), end: endInfo(shaft, true) };
        var names = ["start", "end"];
        P.s0 = 0; P.s1 = 0;
        var scale = P.headScale > 0 ? P.headScale : 1;

        for (var i = 0; i < 2; i++) {
            var nm = names[i], spec = P[nm];
            if (!spec || !spec.shape || spec.shape === "none" || !SHAPES[spec.shape]) continue;
            var d = SHAPES[spec.shape];
            var L = (P.fixedMM > 0 ? P.fixedMM * PT_PER_MM : (spec.len || d.len) * hw) * scale;
            var W = L * (spec.asp || d.asp);
            var nt = (spec.notch >= 0 && spec.notch !== null) ? spec.notch : d.notch;
            var g = headGeom(spec.shape, L, W, hw, nt);
            drawHead(grp, g, info[nm].tip, info[nm].dir, hw, color);
            var sb = Math.min(g.setback, total * 0.4);
            if (sb > 0.0001) shiftPoint(info[nm].pt, -info[nm].dir[0] * sb, -info[nm].dir[1] * sb);
            if (i === 0) P.s0 = sb; else P.s1 = sb;
        }

        // 몸통 — 균일 폭이면 일러스트레이터 선 그대로, 아니면 윤곽을 직접 그림
        var dash = P.dash || [];
        var dp = P.dashPt || [];   // 패널에서 지정한 pt 값 (0 = 프리셋 기본)
        var prof = resolveProfile(P);
        P.profile = prof;
        var dashed = P.shaft === "dashed", dotted = P.shaft === "dotted";
        var on = dashed ? (dp[0] > 0 ? dp[0] : (dash[0] || 4) * sw) : 0;
        var gap = (dashed || dotted) ? (dp[1] > 0 ? dp[1] : (dash[1] || (dotted ? 2.5 : 3)) * sw) : 0;

        var gsOK = false;
        if (P.gstyle && P.gsTarget !== "all") {
            try {
                app.activeDocument.graphicStyles.getByName(P.gstyle).applyTo(shaft);
                // 스타일이 색·두께까지 덮으므로 되돌림 (가변 폭 프로파일은 유지됨)
                shaft.filled = false;
                shaft.stroked = true; shaft.strokeWidth = sw; shaft.strokeColor = color;
                gsOK = true;
            } catch (eGS) { P._gsError = P.gstyle; }
        }
        if (gsOK) {
            shaft.strokeCap = P.cap === "round" ? StrokeCap.ROUNDENDCAP : StrokeCap.BUTTENDCAP;
            shaft.strokeDashes = dashed ? [on, gap] : (dotted ? [0, gap] : []);
        } else if (isUniform(prof)) {
            shaft.strokeCap = (P.cap === "round" || dotted) ? StrokeCap.ROUNDENDCAP : StrokeCap.BUTTENDCAP;
            if (dashed) shaft.strokeDashes = [on, gap];
            else if (dotted) shaft.strokeDashes = [0, gap];
            else shaft.strokeDashes = [];
        } else {
            shaft.stroked = false;
            var S = sampler(samplePath(shaft)), body = [], k, item;
            if (dotted) {
                for (var sPos = 0; sPos <= S.total + 0.01; sPos += Math.max(gap, 0.2)) {
                    var q = at(S, sPos), r = widthAt(prof, S.total ? sPos / S.total : 0) * sw / 2;
                    if (r <= 0.01) continue;
                    item = grp.pathItems.ellipse(q.p[1] + r, q.p[0] - r, r * 2, r * 2);
                    body.push(item);
                }
            } else {
                var cs = chunks(S.total, on, gap);
                for (k = 0; k < cs.length; k++) {
                    if (cs[k][1] - cs[k][0] < 0.05) continue;
                    item = grp.pathItems.add();
                    item.setEntirePath(outline(S, cs[k][0], cs[k][1], prof, sw, 2));
                    item.closed = true;
                    body.push(item);
                }
            }
            for (k = 0; k < body.length; k++) {
                body[k].filled = true; body[k].fillColor = color; body[k].stroked = false;
                body[k].name = "hyArrow_body";
                body[k].move(grp, ElementPlacement.PLACEATEND);   // 화살촉이 위로 오도록
            }
        }

        // 그림자 같은 효과 스타일은 그려진 도형 전체에 입힘 (칠·획은 원래 값으로 되돌림)
        if (P.gstyle && P.gsTarget === "all") {
            var gs = null;
            try { gs = app.activeDocument.graphicStyles.getByName(P.gstyle); } catch (eG) { P._gsMissing = true; }
            if (gs) {
                for (var gi = 0; gi < grp.pageItems.length; gi++) {
                    var it2 = grp.pageItems[gi];
                    if (it2.typename !== "PathItem") continue;
                    var keep = { f: it2.filled, fc: it2.filled ? it2.fillColor : null,
                                 st: it2.stroked, sc: it2.stroked ? it2.strokeColor : null,
                                 swd: it2.strokeWidth, dash: it2.strokeDashes,
                                 cap: it2.strokeCap, join: it2.strokeJoin };
                    try {
                        gs.applyTo(it2);
                        it2.filled = keep.f; if (keep.f && keep.fc) it2.fillColor = keep.fc;
                        it2.stroked = keep.st;
                        if (keep.st) {
                            it2.strokeColor = keep.sc; it2.strokeWidth = keep.swd;
                            it2.strokeDashes = keep.dash; it2.strokeCap = keep.cap; it2.strokeJoin = keep.join;
                        }
                    } catch (eA) {}
                }
            }
        }

        P.sig = sigOf(shaft);
        grp.name = "hyArrow" + (P.name ? " · " + P.name : "");
        grp.note = TAG + toJSON(P);
    }

    /* ---------- 대상 수집 ---------- */
    function arrowGroupOf(it) {
        var p = it;
        for (var d = 0; d < 4 && p; d++) {
            if (p.typename === "GroupItem") {
                var nt = "";
                try { nt = String(p.note); } catch (e) {}
                if (nt.indexOf(TAG) === 0) return p;
            }
            if (p.typename === "Layer" || p.typename === "Document") break;
            p = p.parent;
        }
        return null;
    }
    function keyOf(it) {
        try { return "u" + it.uuid; } catch (e) {}
        var b = it.geometricBounds; return "b" + b.join(",");
    }
    var LAST = [];   // 방금 만든 화살표 (선택이 풀렸을 때 되살리기용)
    function recallLast() {
        var doc = app.activeDocument, out = [], i, j;
        for (i = 0; i < doc.groupItems.length; i++) {
            var g = doc.groupItems[i], u = "";
            try { u = "u" + g.uuid; } catch (e) { continue; }
            for (j = 0; j < LAST.length; j++) if (LAST[j] === u) { out.push({ group: g }); break; }
        }
        return out;
    }

    function collect(recall) {
        if (app.documents.length === 0) return null;
        var sel = app.activeDocument.selection, out = [], seen = {};
        if (!sel || !sel.length) return recall ? recallLast() : [];
        function visit(it) {
            var g = arrowGroupOf(it);
            if (g) {
                var k = keyOf(g);
                if (!seen[k]) { seen[k] = 1; out.push({ group: g }); }
                return;
            }
            if (it.typename === "PathItem") {
                if (!it.closed && it.pathPoints.length >= 2 && !it.guides && !it.clipping &&
                    it.parent.typename !== "CompoundPathItem") {
                    var k2 = keyOf(it);
                    if (!seen[k2]) { seen[k2] = 1; out.push({ path: it }); }
                }
            } else if (it.typename === "GroupItem") {
                for (var i = 0; i < it.pageItems.length; i++) visit(it.pageItems[i]);
            }
        }
        for (var i = 0; i < sel.length; i++) visit(sel[i]);
        if (!out.length && recall) out = recallLast();
        return out;
    }

    function sigOf(path) {
        var pts = path.pathPoints, a = [], i;
        for (i = 0; i < pts.length; i++) {
            var an = pts[i].anchor;
            a.push(Math.round(an[0] * 100) / 100 + "," + Math.round(an[1] * 100) / 100);
        }
        return a.join(";");
    }

    function readParams(g) { return fromJSON(String(g.note).substr(TAG.length)) || {}; }
    function findShaft(g) {
        for (var i = 0; i < g.pathItems.length; i++) if (g.pathItems[i].name === SHAFT) return g.pathItems[i];
        return null;
    }

    // 화살촉 제거 + 몸통 원복 → {shaft, color}
    function strip(g, old) {
        var shaft = findShaft(g);
        if (!shaft) return null;
        var color = null;
        if (shaft.stroked && usable(shaft.strokeColor)) color = shaft.strokeColor;
        for (var i = g.pageItems.length - 1; i >= 0; i--) {
            var it = g.pageItems[i];
            if (it === shaft || it.name === SHAFT) continue;
            if (!color && it.typename === "PathItem") {
                if (it.filled && usable(it.fillColor)) color = it.fillColor;
                else if (it.stroked && usable(it.strokeColor)) color = it.strokeColor;
            }
            it.remove();
        }
        var a = endInfo(shaft, false), b = endInfo(shaft, true);
        if (old.s0 > 0) shiftPoint(a.pt, a.dir[0] * old.s0, a.dir[1] * old.s0);
        if (old.s1 > 0) shiftPoint(b.pt, b.dir[0] * old.s1, b.dir[1] * old.s1);
        return { shaft: shaft, color: color || defaultColor() };
    }

    // 열린 선에 칠이 있으면 일러스트가 시작점과 끝점을 이어 면을 칠한다.
    // 확정(윤곽선+합치기) 때 그 면이 같이 합쳐져 화살촉 끝끼리 이어진 덩어리가 생기므로 칠을 끈다.
    function unfillOpen(it) {
        var n = 0, i;
        try {
            if (it.typename === "PathItem") {
                if (!it.closed && it.filled) { it.filled = false; n++; }
            } else if (it.typename === "GroupItem") {
                for (i = 0; i < it.pageItems.length; i++) n += unfillOpen(it.pageItems[i]);
            }
        } catch (e) {}
        return n;
    }

    function wrap(path) {
        unfillOpen(path);
        var grp = path.parent.groupItems.add();
        grp.move(path, ElementPlacement.PLACEBEFORE);
        path.move(grp, ElementPlacement.PLACEATBEGINNING);
        path.name = SHAFT;
        return grp;
    }

    function applyOver(P, over, oldSw) {
        over = over || {};
        if (over.sw > 0) P.sw = over.sw; else if (!(P.sw > 0)) P.sw = oldSw;
        if (over.headScale > 0) P.headScale = over.headScale;
        if (over.fixedMM !== undefined && over.fixedMM !== null) P.fixedMM = over.fixedMM;
        if (over.profile) P.profile = over.profile;
        if (over.headPt !== undefined && over.headPt !== null) P.headPt = over.headPt;
        if (over.dashPt) P.dashPt = [over.dashPt[0] > 0 ? over.dashPt[0] : 0, over.dashPt[1] > 0 ? over.dashPt[1] : 0];
        return P;
    }

    /* ---------- 공개 함수 ---------- */
    // mode: "preset"(프리셋 적용) | "update"(크기·두께만) | "flip"
    function run(mode, preset, over) {
        // 되살리기는 갱신·수치 조정에서만 (프리셋 적용은 반드시 실제 선택을 따른다)
        var t = collect(mode === "refresh" || mode === "update");
        if (t === null) return res(false, 0, "열린 문서가 없습니다.");
        if (!t.length) return res(false, 0, "열린 패스나 화살표를 선택하세요.");
        var made = [], fail = 0, firstErr = "", skipped = 0;
        for (var i = 0; i < t.length; i++) {
            try {
                var P, st, grp, oldSw;
                if (t[i].group) {
                    grp = t[i].group;
                    var old = readParams(grp);
                    if (mode === "refresh" && !(preset && preset.force)) {
                        // 선이 그대로면 손대지 않는다 (지문은 화살촉을 지우기 전에 비교)
                        var sh0 = findShaft(grp);
                        if (sh0 && old.sig && old.sig === sigOf(sh0)) { skipped++; continue; }
                    }
                    st = strip(grp, old);
                    if (!st) { fail++; continue; }
                    oldSw = old.sw > 0 ? old.sw : 1;
                    if (mode === "preset") {
                        P = clone(preset);
                        P.headScale = old.headScale; P.fixedMM = old.fixedMM; P.sw = 0;
                    } else {
                        P = old;
                        if (mode === "flip") { var tmp = P.start; P.start = P.end; P.end = tmp; }
                    }
                } else {
                    if (mode !== "preset") continue;
                    var path = t[i].path;
                    var col = path.stroked && usable(path.strokeColor) ? path.strokeColor :
                        (path.filled && usable(path.fillColor) ? path.fillColor : defaultColor());
                    oldSw = path.stroked && path.strokeWidth > 0 ? path.strokeWidth : 1;
                    grp = wrap(path);
                    st = { shaft: path, color: col };
                    P = clone(preset); P.sw = 0;
                }
                applyOver(P, over, oldSw);
                build(grp, st.shaft, P, st.color);
                made.push(grp);
            } catch (e) { fail++; if (!firstErr) firstErr = e.message ? String(e.message) : String(e); }
        }
        LAST = [];
        for (var m = 0; m < made.length; m++) { try { LAST.push("u" + made[m].uuid); } catch (e4) {} }
        if (made.length && !(over && over.quiet)) { try { app.redraw(); } catch (e3) {} }
        var msg = made.length + "개 처리" + (skipped ? ", " + skipped + "개 그대로" : "") + (fail ? ", " + fail + "개 실패: " + firstErr : "");
        if (made.length && preset && preset._gsMissing) msg += " (그래픽 스타일 없음)";
        return res(made.length > 0, made.length, msg);
    }

    function applyPreset(preset, over) { return run("preset", preset, over); }
    function refresh(force) { return run("refresh", { force: !!force }, { quiet: true }); }

    // 문서 전체에서 선이 수정된 화살표를 찾아 다시 그림
    function refreshAll(force) {
        if (app.documents.length === 0) return res(false, 0, "열린 문서가 없습니다.");
        var doc = app.activeDocument, n = 0, i;
        for (i = 0; i < doc.groupItems.length; i++) {
            var g = doc.groupItems[i], nt = "";
            try { nt = String(g.note); } catch (e) {}
            if (nt.indexOf(TAG) !== 0) continue;
            if (g.locked || g.hidden || g.layer.locked || !g.layer.visible) continue;
            try {
                var old = readParams(g), sh = findShaft(g);
                if (!sh) continue;
                if (!force && old.sig && old.sig === sigOf(sh)) continue;
                var st = strip(g, old);
                if (!st) continue;
                build(g, st.shaft, old, st.color);
                n++;
            } catch (e2) {}
        }
        try { app.redraw(); } catch (e3) {}
        return res(true, n, n ? n + "개 갱신됨" : "갱신할 화살표가 없습니다.");
    }
    function update(over) { return run("update", null, over); }
    function flip() { return run("flip", null, null); }

    function release() {
        var t = collect(false);
        if (t === null) return res(false, 0, "열린 문서가 없습니다.");
        var n = 0, out = [];
        for (var i = 0; i < t.length; i++) {
            if (!t[i].group) continue;
            try {
                var g = t[i].group, st = strip(g, readParams(g));
                if (!st) continue;
                var s = st.shaft;
                s.move(g, ElementPlacement.PLACEBEFORE);
                s.name = ""; s.stroked = true; s.strokeColor = st.color; s.strokeDashes = [];
                g.remove(); out.push(s); n++;
            } catch (e) {}
        }
        if (out.length) { try { app.activeDocument.selection = out; } catch (e2) {} }
        return res(n > 0, n, n ? n + "개를 일반 선으로 되돌림" : "선택에 화살표가 없습니다.");
    }

    function info() {
        var t = collect(false);
        if (!t) return res(false, 0, "");
        for (var i = 0; i < t.length; i++) if (t[i].group) return res(true, t.length, "", readParams(t[i].group));
        return res(true, t.length, "");
    }

    function selectSame() {
        var t = collect(false);
        if (!t) return res(false, 0, "열린 문서가 없습니다.");
        var id = null;
        for (var i = 0; i < t.length; i++) if (t[i].group) { id = readParams(t[i].group).id; break; }
        if (!id) return res(false, 0, "기준이 될 화살표를 하나 선택하세요.");
        var doc = app.activeDocument, arr = [];
        for (var j = 0; j < doc.groupItems.length; j++) {
            var g = doc.groupItems[j], nt = "";
            try { nt = String(g.note); } catch (e) {}
            if (nt.indexOf(TAG) !== 0) continue;
            if (g.locked || g.hidden || g.layer.locked || !g.layer.visible) continue;
            if (readParams(g).id === id) arr.push(g);
        }
        try { doc.selection = arr; } catch (e3) {}
        return res(true, arr.length, arr.length + "개 선택됨");
    }

    /* ---------- 확정: 하나의 패스로 합치기 ---------- */
    var ARCHIVE = "hyArrow 원본";
    var DONE = "hyArrowDone:";

    function archiveLayer(doc, create) {
        var L = null;
        try { L = doc.layers.getByName(ARCHIVE); } catch (e) { L = null; }
        if (!L && create) {
            L = doc.layers.add();
            L.name = ARCHIVE;
            L.printable = false;
            try { L.zOrder(ZOrderMethod.SENDTOBACK); } catch (e2) {}
        }
        return L;
    }
    function openLayer(L) { var st = { lk: L.locked, vis: L.visible }; L.locked = false; L.visible = true; return st; }
    function closeLayer(L, st) { L.visible = false; L.locked = true; }

    function fillOf(item) {
        if (item.typename === "CompoundPathItem") return item.pathItems.length ? item.pathItems[0] : null;
        return item.typename === "PathItem" ? item : null;
    }

    // 그룹 안의 획을 윤곽선으로 바꾸고 전부 합쳐 패스 하나(점선이면 컴파운드 패스 하나)로 만든다
    function mergeGroup(doc, g) {
        unfillOpen(g);
        doc.selection = null;
        g.selected = true;
        app.executeMenuCommand("OffsetPath v22");       // 획 윤곽선 (점선은 조각 그대로)
        app.executeMenuCommand("Live Pathfinder Add");  // 합치기
        app.executeMenuCommand("expandStyle");          // 확장
        var sel = doc.selection;
        if (!sel || !sel.length) throw new Error("합치기 결과를 찾지 못했습니다");
        var r = sel[0];
        while (r.typename === "GroupItem" && r.pageItems.length === 1) {
            var c = r.pageItems[0];
            c.move(r, ElementPlacement.PLACEBEFORE);
            r.remove();
            r = c;
        }
        return r;
    }

    function finalize(keep) {
        if (app.documents.length === 0) return res(false, 0, "열린 문서가 없습니다.");
        var doc = app.activeDocument, sel = doc.selection, items = [], seen = {}, i;
        if (!sel || !sel.length) return res(false, 0, "확정할 화살표를 선택하세요.");
        // 예전 방식 화살표는 그룹, 플러그인 방식은 효과가 붙은 선 자체
        for (i = 0; i < sel.length; i++) {
            var lg = arrowGroupOf(sel[i]), it = lg || sel[i], k = keyOf(it);
            if (seen[k]) continue;
            seen[k] = 1;
            items.push({ item: it, legacy: !!lg });
        }

        var arch = keep ? archiveLayer(doc, true) : null;
        var out = [], fail = 0, firstErr = "";
        for (i = 0; i < items.length; i++) {
            var g = items[i].item;
            try {
                var id = "a" + new Date().getTime() + "_" + i;
                var P = items[i].legacy ? readParams(g) : {};

                // 편집 가능한 원본은 숨김 레이어에 보관
                if (arch) {
                    var ls = openLayer(arch);
                    var dup = g.duplicate(arch, ElementPlacement.PLACEATEND);
                    if (items[i].legacy) { var PP = clone(P); PP.archId = id; dup.note = TAG + toJSON(PP); }
                    dup.name = "hyArrow 원본 " + id;
                    closeLayer(arch, ls);
                }

                var shape, styleAfter = null, color = null;
                if (items[i].legacy) {
                    // 도형 전체용 그래픽 스타일은 합친 뒤 다시 입힌다 (먼저 확장되면 그림자가 이미지가 됨)
                    var st = strip(g, P);
                    if (!st) { fail++; continue; }
                    var P2 = clone(P);
                    if (P2.gstyle && P2.gsTarget !== "stroke") { styleAfter = P2.gstyle; delete P2.gstyle; }
                    build(g, st.shaft, P2, st.color);
                    var sh = findShaft(g);
                    if (sh && !sh.stroked) sh.remove();       // 윤곽을 직접 그린 경우 중심선은 버림
                    color = st.color;
                    shape = mergeGroup(doc, g);
                } else {
                    // 플러그인 방식: 모양 확장으로 실제 도형을 만든 뒤 합친다
                    unfillOpen(g);
                    doc.selection = null;
                    g.selected = true;
                    app.executeMenuCommand("expandStyle");
                    var ex = doc.selection;
                    if (!ex || !ex.length) throw new Error("모양 확장 결과를 찾지 못했습니다");
                    shape = mergeGroup(doc, ex[0]);
                }
                if (styleAfter) {
                    try {
                        doc.graphicStyles.getByName(styleAfter).applyTo(shape);
                        var f = fillOf(shape);
                        if (f) { f.filled = true; f.fillColor = color; f.stroked = false; }
                    } catch (eS) {}
                }
                shape.name = "hyArrow" + (P.name ? " · " + P.name : "") + " (확정)";
                shape.note = DONE + toJSON({ archId: arch ? id : null, b: shape.geometricBounds });
                out.push(shape);
            } catch (e) { fail++; if (!firstErr) firstErr = e.message ? String(e.message) : String(e); }
        }
        try { doc.selection = out; } catch (e2) {}
        try { app.redraw(); } catch (e3) {}
        var msg = out.length + "개를 패스 하나로 확정" + (arch ? " (원본 보관됨)" : "") +
            (fail ? ", " + fail + "개 실패: " + firstErr : "");
        return res(out.length > 0, out.length, msg);
    }

    // 확정한 패스를 보관해 둔 원본 화살표로 되돌림 (확정 뒤 옮긴 만큼 같이 옮김)
    function reopen() {
        if (app.documents.length === 0) return res(false, 0, "열린 문서가 없습니다.");
        var doc = app.activeDocument, sel = doc.selection, items = [], i, j;
        if (sel && sel.length) {
            for (i = 0; i < sel.length; i++) {
                var nt = "";
                try { nt = String(sel[i].note); } catch (e) {}
                if (nt.indexOf(DONE) === 0) items.push(sel[i]);
            }
        }
        if (!items.length) return res(false, 0, "확정한 화살표를 선택하세요.");
        var arch = archiveLayer(doc, false);
        if (!arch) return res(false, 0, "보관된 원본이 없습니다. 원본 보관을 끄고 확정한 것은 되돌릴 수 없습니다.");

        var ls = openLayer(arch), back = [], miss = 0;
        try {
            for (i = 0; i < items.length; i++) {
                var s = items[i], d = fromJSON(String(s.note).substr(DONE.length)) || {};
                var orig = null;
                if (d.archId) {
                    for (j = 0; j < arch.pageItems.length; j++) {
                        if (arch.pageItems[j].name === "hyArrow 원본 " + d.archId) { orig = arch.pageItems[j]; break; }
                    }
                }
                if (!orig) { miss++; continue; }
                orig.move(s, ElementPlacement.PLACEBEFORE);
                var b0 = d.b, b1 = s.geometricBounds;
                if (b0 && b1) orig.translate(b1[0] - b0[0], b1[1] - b0[1]);
                var nt0 = "";
                try { nt0 = String(orig.note); } catch (eN) {}
                if (orig.typename === "GroupItem" && nt0.indexOf(TAG) === 0) {
                    var P = readParams(orig);
                    delete P.archId;
                    orig.note = TAG + toJSON(P);
                    orig.name = "hyArrow" + (P.name ? " \u00b7 " + P.name : "");
                } else {
                    orig.name = "";
                }
                s.remove();
                back.push(orig);
            }
        } finally {
            if (arch.pageItems.length === 0) { arch.locked = false; arch.visible = true; arch.remove(); }
            else closeLayer(arch, ls);
        }
        try { doc.selection = back; } catch (e2) {}
        try { app.redraw(); } catch (e3) {}
        var msg = back.length + "개를 다시 편집할 수 있게 되돌림" + (miss ? ", " + miss + "개는 원본이 없음" : "");
        return res(back.length > 0, back.length, msg);
    }

    /* ---------- 플러그인(hyArrow.aip) 방식으로 넘어가기 전 준비 ---------- */
    // 선택에 예전 방식 화살표(그룹)가 있으면 원래 선으로 돌려놓고, 선택을 그 선들로 바꾼다
    function legacyToLines() {
        var t = collect(false);
        if (!t || !t.length) return 0;
        var has = false, i;
        for (i = 0; i < t.length; i++) if (t[i].group) { has = true; break; }
        if (!has) return 0;
        var sel = [], n = 0;
        for (i = 0; i < t.length; i++) {
            if (t[i].group) {
                try {
                    var g = t[i].group, st = strip(g, readParams(g));
                    if (!st) continue;
                    var s = st.shaft;
                    s.move(g, ElementPlacement.PLACEBEFORE);
                    s.name = ""; s.stroked = true; s.strokeColor = st.color; s.strokeDashes = [];
                    g.remove(); sel.push(s); n++;
                } catch (e) {}
            } else if (t[i].path) sel.push(t[i].path);
        }
        try { app.activeDocument.selection = sel; } catch (e2) {}
        return n;
    }
    // 획이 없는 열린 선은 화살표가 그려지지 않으므로 획을 켠다 (칠 색을 획 색으로)
    function ensureStroke() {
        var t = collect(false), n = 0;
        if (!t) return 0;
        for (var i = 0; i < t.length; i++) {
            var p = t[i].path;
            if (!p) continue;
            if (p.stroked) { n += unfillOpen(p); continue; }
            try {
                var col = p.filled && usable(p.fillColor) ? p.fillColor : defaultColor();
                p.stroked = true;
                p.strokeColor = col;
                if (!(p.strokeWidth > 0)) p.strokeWidth = 1;
                p.filled = false;
                n++;
            } catch (e) {}
        }
        return n;
    }

    function redraw() {
        try { app.redraw(); } catch (e) {}
        return res(true, 0, "");
    }

    function styles() {
        if (app.documents.length === 0) return res(false, 0, "열린 문서가 없습니다.");
        var doc = app.activeDocument, out = [];
        for (var i = 0; i < doc.graphicStyles.length; i++) {
            var nm = doc.graphicStyles[i].name;
            if (nm && nm !== "[Default]" && nm !== "기본") out.push(nm);
        }
        return res(true, out.length, "", out);
    }

    return {
        legacyToLines: legacyToLines,
        ensureStroke: ensureStroke,
        finalize: finalize,
        reopen: reopen,
        refresh: refresh,
        refreshAll: refreshAll,
        redraw: redraw,
        styles: styles,
        applyPreset: applyPreset, update: update, flip: flip,
        release: release, info: info, selectSame: selectSame
    };
})();


/*  hyArrowNative — 일러스트레이터 플러그인(hyArrow.aip)에 메시지를 보낸다.
    플러그인이 설치되어 있으면 화살표는 선에 붙은 라이브 효과가 되고, 선을 고치면 바로 따라온다. */
var hyArrowNative = (function () {
    var PLUGIN = "hyArrow";
    function fail(msg) { return '{"ok":false,"n":0,"msg":"' + String(msg).replace(/"/g, "'") + '"}'; }
    function send(selector, input) {
        try {
            var r = app.sendScriptMessage(PLUGIN, selector, input || "");
            return (r && String(r).length) ? String(r) : fail("플러그인 응답이 없습니다.");
        } catch (e) {
            return fail("hy Arrow 플러그인을 찾지 못했습니다.");
        }
    }
    function hasDoc() { return app.documents.length > 0; }
    return {
        ping: function () { return send("ping", ""); },
        apply: function (json) {
            if (!hasDoc()) return fail("열린 문서가 없습니다.");
            try { hyArrow.legacyToLines(); hyArrow.ensureStroke(); } catch (e) {}
            var r = send("apply", json);
            try { app.redraw(); } catch (e2) {}
            return r;
        },
        info: function () { return hasDoc() ? send("info", "") : fail(""); },
        remove: function () { return hasDoc() ? send("remove", "") : fail("열린 문서가 없습니다."); },
        flip: function () { return hasDoc() ? send("flip", "") : fail("열린 문서가 없습니다."); },
        selectSame: function () { return hasDoc() ? send("selectSame", "") : fail("열린 문서가 없습니다."); }
    };
})();
