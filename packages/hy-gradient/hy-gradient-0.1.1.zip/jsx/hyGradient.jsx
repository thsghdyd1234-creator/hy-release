/* hy Gradient — Illustrator 호스트 (ExtendScript). 전역 함수 접두: hyGrad_ */

function hyGrad_parse(s) { return eval('(' + decodeURIComponent(s) + ')'); }
function hyGrad_q(s) {
  return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n') + '"';
}
function hyGrad_ok(extra) { return '{"ok":true' + (extra ? ',' + extra : '') + '}'; }
function hyGrad_err(m) { return '{"ok":false,"msg":' + hyGrad_q(m) + '}'; }

/* ---------- 색 변환 ---------- */
function hyGrad_isCMYK(doc) { return doc.documentColorSpace == DocumentColorSpace.CMYK; }

function hyGrad_makeColor(doc, rgb) {
  if (hyGrad_isCMYK(doc)) {
    var v = null;
    try { v = app.convertSampleColor(ImageColorSpace.RGB, [rgb[0], rgb[1], rgb[2]], ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose); } catch (e) {}
    if (!v || v.length < 4) {
      var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, k = 1 - Math.max(r, g, b);
      v = k >= 1 ? [0, 0, 0, 100] : [(1 - r - k) / (1 - k) * 100, (1 - g - k) / (1 - k) * 100, (1 - b - k) / (1 - k) * 100, k * 100];
    }
    var c = new CMYKColor(); c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
    return c;
  }
  var o = new RGBColor(); o.red = rgb[0]; o.green = rgb[1]; o.blue = rgb[2];
  return o;
}

function hyGrad_toRGB(col) {
  if (!col) return null;
  var t = col.typename, v;
  if (t == 'RGBColor') return [Math.round(col.red), Math.round(col.green), Math.round(col.blue)];
  if (t == 'CMYKColor') {
    try { v = app.convertSampleColor(ImageColorSpace.CMYK, [col.cyan, col.magenta, col.yellow, col.black], ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose); } catch (e) { v = null; }
    if (!v) { var k = col.black / 100; v = [255 * (1 - col.cyan / 100) * (1 - k), 255 * (1 - col.magenta / 100) * (1 - k), 255 * (1 - col.yellow / 100) * (1 - k)]; }
    return [Math.round(v[0]), Math.round(v[1]), Math.round(v[2])];
  }
  if (t == 'GrayColor') { var g = Math.round(255 * (1 - col.gray / 100)); return [g, g, g]; }
  if (t == 'SpotColor') {
    var base = hyGrad_toRGB(col.spot.color), tint = (col.tint == undefined ? 100 : col.tint) / 100;
    if (!base) return null;
    return [Math.round(255 - (255 - base[0]) * tint), Math.round(255 - (255 - base[1]) * tint), Math.round(255 - (255 - base[2]) * tint)];
  }
  return null;
}

/* ---------- 그라디언트 생성·갱신 ---------- */
var HYGRAD_TMP = 'hy 임시 ';

function hyGrad_fillStops(doc, g, st) {
  g.type = st.type == 'radial' ? GradientType.RADIAL : GradientType.LINEAR;
  var out = st.out, i;
  while (g.gradientStops.length < out.length) g.gradientStops.add();
  while (g.gradientStops.length > out.length) g.gradientStops[g.gradientStops.length - 1].remove();
  // 1차: 위치만 (컬렉션이 위치순으로 재정렬될 수 있어 색은 2차에서)
  for (i = 0; i < out.length; i++) g.gradientStops[i].rampPoint = out[i].p;
  var arr = [];
  for (i = 0; i < g.gradientStops.length; i++) arr.push({ s: g.gradientStops[i], i: i });
  arr.sort(function (a, b) { return a.s.rampPoint - b.s.rampPoint || a.i - b.i; });
  for (i = 0; i < out.length; i++) {
    if (Math.abs(arr[i].s.rampPoint - out[i].p) > 0.05) return false;   // 위치가 어긋나면 실패로 보고
    var gs = arr[i].s;
    gs.midPoint = 50;
    gs.color = hyGrad_makeColor(doc, out[i].c);
    try { gs.opacity = out[i].a; } catch (e2) {}
  }
  return true;
}

function hyGrad_build(doc, st, name) {
  var g = doc.gradients.add();
  try { g.name = name; } catch (e) {}
  hyGrad_fillStops(doc, g, st);
  return g;
}

/* 선택 객체들이 모두 같은 임시 그라디언트를 쓰고 있으면 그 그라디언트를 돌려줌 */
function hyGrad_leaves(it, acc) {
  var t = it.typename, i;
  if (t == 'GroupItem') { for (i = 0; i < it.pageItems.length; i++) hyGrad_leaves(it.pageItems[i], acc); }
  else if (t == 'CompoundPathItem') { if (it.pathItems.length) acc.push(it.pathItems[0]); }
  else if (t == 'PathItem') acc.push(it);
  else if (t == 'TextFrame') { var ca = it.textRange.characterAttributes; acc.push({ fillColor: ca.fillColor, strokeColor: ca.strokeColor, filled: true, stroked: true }); }
}
function hyGrad_sharedGrad(sel, target) {
  var acc = [], i, g = null;
  for (i = 0; i < sel.length; i++) hyGrad_leaves(sel[i], acc);
  if (!acc.length) return null;
  for (i = 0; i < acc.length; i++) {
    var col = null;
    try { col = target == 'stroke' ? (acc[i].stroked ? acc[i].strokeColor : null) : (acc[i].filled ? acc[i].fillColor : null); } catch (e) {}
    if (!col || col.typename != 'GradientColor') return null;
    var gi = col.gradient;
    if (!g) g = gi; else if (gi.name != g.name) return null;
  }
  return g;
}
function hyGrad_isTmp(g) { return g && String(g.name).indexOf(HYGRAD_TMP) === 0; }

function hyGrad_newName(doc, prefix) {
  prefix = prefix || 'hy Gradient ';
  for (var n = 1; n < 1000; n++) {
    var nm = prefix + n, hit = false;
    try { doc.gradients.getByName(nm); hit = true; } catch (e) {}
    if (!hit) return nm;
  }
  return 'hy Gradient';
}

function hyGrad_gc(g) { var gc = new GradientColor(); gc.gradient = g; return gc; }

function hyGrad_paint(p, g, st) {
  if (st.target == 'stroke') { p.stroked = true; p.strokeColor = hyGrad_gc(g); }
  else { p.filled = true; p.fillColor = hyGrad_gc(g); }
}

function hyGrad_rotate(it, st) {
  if (st.type != 'linear' || st.target != 'fill' || !st.angle) return;
  try { it.rotate(st.angle, false, false, true, false, Transformation.CENTER); } catch (e) {}
}

function hyGrad_tag(it, st) {
  try {
    var n = it.note || '';
    if (n === '' || n.indexOf('hyGrad:') === 0) it.note = 'hyGrad:' + st.outN + ':' + st.note;
  } catch (e) {}
}

function hyGrad_applyItem(it, g, st, cnt) {
  var t = it.typename, i;
  if (t == 'GroupItem') { for (i = 0; i < it.pageItems.length; i++) hyGrad_applyItem(it.pageItems[i], g, st, cnt); return; }
  if (t == 'CompoundPathItem') {
    if (!it.pathItems.length) return;
    for (i = 0; i < it.pathItems.length; i++) hyGrad_paint(it.pathItems[i], g, st);
    hyGrad_rotate(it, st); hyGrad_tag(it, st); cnt.n++; return;
  }
  if (t == 'PathItem') { hyGrad_paint(it, g, st); hyGrad_rotate(it, st); hyGrad_tag(it, st); cnt.n++; return; }
  if (t == 'TextFrame') {
    var ca = it.textRange.characterAttributes;
    if (st.target == 'stroke') ca.strokeColor = hyGrad_gc(g); else ca.fillColor = hyGrad_gc(g);
    hyGrad_tag(it, st); cnt.n++;
  }
}

function hyGrad_apply(s) {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, st = hyGrad_parse(s), sel = doc.selection;
    var hasSel = sel && sel.length;
    if (!hasSel && !st.keep) return hyGrad_err('적용할 객체를 선택하세요');

    var g = null, reused = false;
    if (hasSel) {
      var sh = hyGrad_sharedGrad(sel, st.target);
      // 같은 임시 그라디언트를 쓰는 객체를 다시 편집 → 그 스와치를 고쳐 씀 (스와치가 늘지 않음)
      if (sh && hyGrad_isTmp(sh) && hyGrad_fillStops(doc, sh, st)) { g = sh; reused = true; }
    }
    if (!g) g = hyGrad_build(doc, st, hyGrad_newName(doc, HYGRAD_TMP));

    var name = '';
    if (st.keep) { name = hyGrad_newName(doc); try { g.name = name; } catch (e1) {} }

    var cnt = { n: 0 };
    if (hasSel) for (var i = 0; i < sel.length; i++) hyGrad_applyItem(sel[i], g, st, cnt);
    if (hasSel && !cnt.n && !st.keep) return hyGrad_err('패스·복합 패스·텍스트만 적용됩니다');
    return hyGrad_ok('"count":' + cnt.n + ',"name":' + hyGrad_q(name) + ',"reused":' + reused);
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 쓰지 않는 임시 스와치 정리 ---------- */
function hyGrad_markUsed(col, used) {
  try { if (col && col.typename == 'GradientColor') used[col.gradient.name] = 1; } catch (e) {}
}
function hyGrad_cleanup() {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, used = {}, i, p;
    for (i = 0; i < doc.pathItems.length; i++) {
      p = doc.pathItems[i];
      if (p.filled) hyGrad_markUsed(p.fillColor, used);
      if (p.stroked) hyGrad_markUsed(p.strokeColor, used);
    }
    for (i = 0; i < doc.textFrames.length; i++) {
      var tr = doc.textFrames[i].textRange;
      for (var k = 0; k < tr.characters.length; k++) {
        var ca = tr.characters[k].characterAttributes;
        hyGrad_markUsed(ca.fillColor, used); hyGrad_markUsed(ca.strokeColor, used);
      }
    }
    var n = 0;
    for (i = doc.gradients.length - 1; i >= 0; i--) {
      var g = doc.gradients[i];
      if (hyGrad_isTmp(g) && !used[g.name]) { try { g.remove(); n++; } catch (e2) {} }
    }
    return hyGrad_ok('"removed":' + n);
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 선택 객체에서 불러오기 ---------- */
function hyGrad_first(it) {
  var t = it.typename;
  if (t == 'GroupItem') { for (var i = 0; i < it.pageItems.length; i++) { var r = hyGrad_first(it.pageItems[i]); if (r) return r; } return null; }
  if (t == 'CompoundPathItem') return it.pathItems.length ? { tag: it, p: it.pathItems[0] } : null;
  if (t == 'PathItem') return { tag: it, p: it };
  if (t == 'TextFrame') { var ca = it.textRange.characterAttributes; return { tag: it, p: { fillColor: ca.fillColor, strokeColor: ca.strokeColor, filled: true, stroked: true } }; }
  return null;
}

function hyGrad_read() {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var sel = app.activeDocument.selection;
    if (!sel || !sel.length) return hyGrad_err('그라디언트를 불러올 객체를 선택하세요');
    var f = hyGrad_first(sel[0]);
    if (!f) return hyGrad_err('패스·복합 패스·텍스트를 선택하세요');
    var col = null, target = 'fill';
    try { if (f.p.filled && f.p.fillColor.typename == 'GradientColor') col = f.p.fillColor; } catch (e) {}
    if (!col) { try { if (f.p.stroked && f.p.strokeColor.typename == 'GradientColor') { col = f.p.strokeColor; target = 'stroke'; } } catch (e2) {} }
    if (!col) return hyGrad_err('선택한 객체에 그라디언트가 없습니다');
    var gst = col.gradient.gradientStops, i;
    // 이 패널로 만든 그라디언트면 편집 상태(보간·곡선 포함) 그대로 복원
    var note = '';
    try { note = f.tag.note || ''; } catch (e3) {}
    if (note.indexOf('hyGrad:') === 0) {
      var rest = note.substring(7), c = rest.indexOf(':');
      if (c > 0 && parseInt(rest.substring(0, c), 10) == gst.length) return hyGrad_ok('"state":' + rest.substring(c + 1) + ',"target":"' + target + '"');
    }
    var parts = [];
    for (i = 0; i < gst.length; i++) {
      var rgb = hyGrad_toRGB(gst[i].color) || [0, 0, 0], op = 100;
      try { op = Math.round(gst[i].opacity); } catch (e4) {}
      parts.push('{"p":' + Math.round(gst[i].rampPoint * 100) / 100 + ',"c":[' + rgb.join(',') + '],"a":' + op + '}');
    }
    var ang = 0; try { ang = Math.round(col.angle); } catch (e5) {}
    var type = col.gradient.type == GradientType.RADIAL ? 'radial' : 'linear';
    return hyGrad_ok('"raw":{"type":"' + type + '","angle":' + ang + ',"stops":[' + parts.join(',') + ']},"target":"' + target + '"');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 현재 칠 색 (hy Color 등에서 고른 색을 정지점으로) ---------- */
function hyGrad_fill() {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var col = app.activeDocument.defaultFillColor;
    if (col.typename == 'GradientColor') return hyGrad_err('현재 칠이 그라디언트입니다. 단색을 고르세요');
    var rgb = hyGrad_toRGB(col);
    if (!rgb) return hyGrad_err('현재 칠 색이 없습니다');
    return hyGrad_ok('"c":[' + rgb.join(',') + ']');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}
