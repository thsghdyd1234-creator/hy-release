/* hy Gradient — 색 계산 (호스트 무의존, 순수 JS) */
(function (root) {
  'use strict';
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  // sRGB <-> OKLab
  function toLin(c) { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function toSrgb(c) {
    c = c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(Math.max(c, 0), 1 / 2.4) - 0.055;
    return clamp(Math.round(c * 255), 0, 255);
  }
  function rgbToOklab(c) {
    var R = toLin(c[0]), G = toLin(c[1]), B = toLin(c[2]);
    var l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B);
    var m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B);
    var s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B);
    return [0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
            1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
            0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s];
  }
  function oklabToRgb(o) {
    var l = o[0] + 0.3963377774 * o[1] + 0.2158037573 * o[2];
    var m = o[0] - 0.1055613458 * o[1] - 0.0638541728 * o[2];
    var s = o[0] - 0.0894841775 * o[1] - 1.2914855480 * o[2];
    l = l * l * l; m = m * m * m; s = s * s * s;
    return [toSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
            toSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
            toSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)];
  }

  // HSB (포토샵·일러스트 색상 피커와 같은 숫자)
  function rgbToHsb(c) {
    var r = c[0] / 255, g = c[1] / 255, b = c[2] / 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d) {
      if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return [Math.round(h), Math.round(mx ? d / mx * 100 : 0), Math.round(mx * 100)];
  }
  function hsbToRgb(h, s, v) {
    s /= 100; v /= 100;
    var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
  }
  function toHex(c) { return '#' + c.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join('').toUpperCase(); }
  function fromHex(s) {
    s = String(s).trim().replace(/^#/, '');
    if (/^[0-9a-f]{3}$/i.test(s)) s = s.replace(/(.)/g, '$1$1');
    if (!/^[0-9a-f]{6}$/i.test(s)) return null;
    return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
  }

  // 이징: cubic-bezier(x1,y1,x2,y2)
  function isLinear(e) { return Math.abs(e[0] - e[1]) < 1e-3 && Math.abs(e[2] - e[3]) < 1e-3; }
  function bezier(e) {
    if (isLinear(e)) return function (t) { return t; };
    var x1 = e[0], y1 = e[1], x2 = e[2], y2 = e[3];
    function bx(s) { var u = 1 - s; return 3 * x1 * s * u * u + 3 * x2 * s * s * u + s * s * s; }
    function by(s) { var u = 1 - s; return 3 * y1 * s * u * u + 3 * y2 * s * s * u + s * s * s; }
    return function (t) {
      if (t <= 0) return 0; if (t >= 1) return 1;
      var lo = 0, hi = 1, s = t;
      for (var i = 0; i < 40; i++) {
        var x = bx(s);
        if (Math.abs(x - t) < 1e-6) break;
        if (x < t) lo = s; else hi = s;
        s = (lo + hi) / 2;
      }
      return clamp(by(s), 0, 1);
    };
  }

  function sorted(stops) {
    return stops.map(function (s, i) { return { s: s, i: i }; })
      .sort(function (a, b) { return a.s.p - b.s.p || a.i - b.i; })
      .map(function (o) { return o.s; });
  }

  function mix(a, b, u, interp) {
    var c;
    if (interp === 'oklab') {
      var A = rgbToOklab(a.c), B = rgbToOklab(b.c);
      c = oklabToRgb([A[0] + (B[0] - A[0]) * u, A[1] + (B[1] - A[1]) * u, A[2] + (B[2] - A[2]) * u]);
    } else {
      c = [0, 1, 2].map(function (k) { return Math.round(a.c[k] + (b.c[k] - a.c[k]) * u); });
    }
    return { c: c, a: a.a + (b.a - a.a) * u };
  }

  // 위치 t(0~1)의 색 — 이징은 정지점 사이 구간마다 적용
  function sample(state, t, _st, _e) {
    var st = _st || sorted(state.stops), e = _e || bezier(state.ease);
    var p = clamp(t, 0, 1) * 100, n = st.length;
    if (p <= st[0].p) return { c: st[0].c.slice(), a: st[0].a };
    if (p >= st[n - 1].p) return { c: st[n - 1].c.slice(), a: st[n - 1].a };
    for (var i = 0; i < n - 1; i++) {
      var a = st[i], b = st[i + 1];
      if (p >= a.p && p <= b.p) {
        var span = b.p - a.p, u = span > 0 ? (p - a.p) / span : 1;
        return mix(a, b, e(u), state.interp);
      }
    }
    return { c: st[n - 1].c.slice(), a: st[n - 1].a };
  }

  function needsResample(state) {
    return state.interp === 'oklab' || !isLinear(state.ease);
  }

  // 일러스트로 보낼 정지점: 원본 정지점 + 균등 샘플 (겹치는 위치는 원본 우선, 하드 스톱 보존)
  function outputStops(state) {
    var st = sorted(state.stops);
    var raw = st.map(function (s) { return { p: +s.p.toFixed(2), c: s.c.slice(), a: Math.round(s.a) }; });
    if (!needsResample(state)) return raw;
    var e = bezier(state.ease), n = Math.max(2, state.res | 0), out = raw.slice();
    for (var k = 0; k <= n; k++) {
      var p = k / n * 100, near = false;
      for (var j = 0; j < raw.length; j++) if (Math.abs(raw[j].p - p) < 0.6) { near = true; break; }
      if (near || p < raw[0].p || p > raw[raw.length - 1].p) continue;
      var s = sample(state, p / 100, st, e);
      out.push({ p: +p.toFixed(2), c: s.c, a: Math.round(s.a), _g: 1 });
    }
    out.sort(function (a, b) { return a.p - b.p || (a._g ? 1 : 0) - (b._g ? 1 : 0); });
    // 같은 색이 이어지는 중복 샘플 제거
    var res = [];
    for (var q = 0; q < out.length; q++) {
      var o = out[q];
      if (o._g && res.length && q < out.length - 1) {
        var pv = res[res.length - 1], nx = out[q + 1];
        if (same(pv, o) && same(o, nx)) continue;
      }
      res.push({ p: o.p, c: o.c, a: o.a });
    }
    return res;
  }
  function same(a, b) { return a.a === b.a && a.c[0] === b.c[0] && a.c[1] === b.c[1] && a.c[2] === b.c[2]; }

  function cssGradient(state) {
    return 'linear-gradient(to right,' + outputStops(state).map(function (s) {
      return 'rgba(' + s.c.join(',') + ',' + (s.a / 100) + ') ' + s.p + '%';
    }).join(',') + ')';
  }

  var GM = { clamp: clamp, rgbToOklab: rgbToOklab, oklabToRgb: oklabToRgb, rgbToHsb: rgbToHsb, hsbToRgb: hsbToRgb,
    toHex: toHex, fromHex: fromHex, bezier: bezier, isLinear: isLinear, sorted: sorted, sample: sample,
    needsResample: needsResample, outputStops: outputStops, cssGradient: cssGradient };
  if (typeof module !== 'undefined' && module.exports) module.exports = GM; else root.GM = GM;
})(this);
