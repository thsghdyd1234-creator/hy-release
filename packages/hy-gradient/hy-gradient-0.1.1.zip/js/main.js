/* hy Gradient — 패널 로직 */
(function () {
  'use strict';
  const GM = window.GM;
  const $ = id => document.getElementById(id);
  const LS_STATE = 'hyGrad.state', LS_USER = 'hyGrad.presets', LS_LIVE = 'hyGrad.live';
  const LINEAR = [0.33, 0.33, 0.67, 0.67];

  const DEF = {
    stops: [{ p: 0, c: [29, 53, 87], a: 100 }, { p: 100, c: [244, 162, 97], a: 100 }],
    interp: 'oklab', ease: LINEAR.slice(), res: 24, type: 'linear', angle: 0, target: 'fill'
  };

  const EASES = [
    ['직선', LINEAR], ['가속', [0.55, 0, 1, 0.45]], ['감속', [0, 0.55, 0.45, 1]],
    ['S자', [0.65, 0, 0.35, 1]], ['역S', [0.2, 0.8, 0.8, 0.2]]
  ];

  const h = hex => GM.fromHex(hex);
  const P = (name, cols, extra) => Object.assign({
    name, interp: 'oklab', ease: LINEAR.slice(),
    stops: cols.map((c, i) => Array.isArray(c)
      ? { p: c[1], c: h(c[0]), a: c[2] == null ? 100 : c[2] }
      : { p: Math.round(i / (cols.length - 1) * 100), c: h(c), a: 100 })
  }, extra || {});

  const PRESETS = [
    P('열 분포', ['#2B3A8F', '#2E9CC9', '#F2E35B', '#E8532E', '#8E1B2A']),
    P('고도', [['#2F5D3A', 0], ['#9BB567', 35], ['#E9DCA0', 60], ['#B98C5A', 82], ['#F5F2EA', 100]]),
    P('수심', ['#0B2545', '#13315C', '#8DA9C4', '#EEF4ED']),
    P('일조', ['#2D1E4F', '#8A2F6B', '#E0643C', '#F7C948', '#FFF3C4']),
    P('녹지', ['#1F4D2B', '#6A9F58', '#D8E8B0']),
    P('블루프린트', ['#0F2A4A', '#3F6FA8', '#D6E4F5']),
    P('콘크리트', ['#6F6F6C', '#B9B7B0', '#E9E7E1'], { interp: 'rgb' }),
    P('대기 원근', ['#6F8FB3', '#C9D6E3', '#F4EFE6']),
    P('모노 잉크', ['#000000', '#FFFFFF'], { interp: 'rgb' }),
    P('리소 핑크 블루', ['#FF48B0', '#0078BF']),
    P('그림자 페이드', [['#000000', 0, 60], ['#000000', 100, 0]], { interp: 'rgb', ease: [0, 0.55, 0.45, 1] }),
    P('빛 페이드', [['#FFFFFF', 0, 85], ['#FFFFFF', 100, 0]], { interp: 'rgb', ease: [0, 0.55, 0.45, 1] })
  ];

  const clone = o => JSON.parse(JSON.stringify(o));
  const r1 = v => Math.round(v * 10) / 10;
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a / 100})`;

  let S = loadState();
  let sel = 0;
  let hsb = null;           // 선택 정지점의 HSB 캐시 (채도 0일 때 색조 유지)
  let live = localStorage.getItem(LS_LIVE) !== '0';

  function loadState() {
    try {
      const s = JSON.parse(localStorage.getItem(LS_STATE));
      if (s && s.stops && s.stops.length >= 2) return Object.assign(clone(DEF), s);
    } catch (e) {}
    return clone(DEF);
  }
  function saveState() { try { localStorage.setItem(LS_STATE, JSON.stringify(S)); } catch (e) {} }

  function status(msg, kind) { const el = $('status'); el.textContent = msg; el.className = kind || ''; }

  /* ---------- 호스트 ---------- */
  function host(fn, arg) {
    return new Promise(res => {
      if (!window.__adobe_cep__) { res({ ok: false, msg: '일러스트레이터 안에서 실행하세요' }); return; }
      const src = arg === undefined ? fn + '()' : fn + '("' + encodeURIComponent(arg) + '")';
      window.__adobe_cep__.evalScript(src, r => {
        try { res(JSON.parse(r)); } catch (e) { res({ ok: false, msg: String(r) }); }
      });
    });
  }

  let busy = false, again = false, liveT = null;
  function scheduleLive() {
    if (!live) return;
    clearTimeout(liveT);
    liveT = setTimeout(() => apply(false, true), 120);
  }
  async function apply(keep, quiet) {
    if (busy) { again = true; return; }
    busy = true;
    const out = GM.outputStops(S);
    const payload = { type: S.type, angle: S.angle, target: S.target, keep: !!keep, out, outN: out.length, note: JSON.stringify(S) };
    const r = await host('hyGrad_apply', JSON.stringify(payload));
    busy = false;
    if (r.ok) {
      if (keep) status(r.count ? `스와치 "${r.name}"을 등록하고 ${r.count}개 객체에 적용했습니다` : `스와치 "${r.name}"을 등록했습니다`, 'good');
      else status(`${r.count}개 객체에 적용했습니다`, 'good');
    } else status(r.msg, quiet ? '' : 'err');
    if (again) { again = false; apply(false, true); }
  }

  /* ---------- 테마 ---------- */
  function theme() {
    try {
      const env = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      const c = env.appSkinInfo.panelBackgroundColor.color;
      const bg = [c.red, c.green, c.blue].map(Math.round);
      const lum = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) / 255;
      const dark = lum < 0.5;
      const sh = d => `rgb(${bg.map(v => Math.max(0, Math.min(255, v + d))).join(',')})`;
      const st = document.documentElement.style;
      st.setProperty('--bg', `rgb(${bg.join(',')})`);
      st.setProperty('--fg', dark ? '#e8e8e8' : '#1f1f1f');
      st.setProperty('--dim', dark ? '#9c9c9c' : '#6a6a6a');
      st.setProperty('--field', dark ? sh(-14) : sh(-22));
      st.setProperty('--field2', dark ? sh(16) : sh(-40));
      st.setProperty('--line', dark ? sh(28) : sh(-60));
    } catch (e) {}
  }

  /* ---------- 그라디언트 바 ---------- */
  function drawBar() {
    const cv = $('bar'), d = window.devicePixelRatio || 1;
    const W = Math.round(cv.clientWidth * d), H = Math.round(cv.clientHeight * d);
    if (!W) return;
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const ctx = cv.getContext('2d'), cs = Math.round(6 * d);
    for (let y = 0; y < H; y += cs) for (let x = 0; x < W; x += cs) {
      ctx.fillStyle = ((x / cs + y / cs) & 1) ? '#cfcfcf' : '#f4f4f4'; ctx.fillRect(x, y, cs, cs);
    }
    // 바 좌우 여백(정지점 트랙과 맞춤)
    const pad = Math.round(6 * d), inner = W - pad * 2;
    const st = GM.sorted(S.stops), e = GM.bezier(S.ease);
    for (let x = 0; x < W; x++) {
      const s = GM.sample(S, (x - pad + 0.5) / inner, st, e);
      ctx.fillStyle = rgba(s.c, s.a); ctx.fillRect(x, 0, 1, H);
    }
  }

  function renderPins() {
    const tr = $('track'); tr.innerHTML = '';
    S.stops.forEach((s, i) => {
      const el = document.createElement('div');
      el.className = 'pin' + (i === sel ? ' on' : '');
      el.style.left = s.p + '%'; el.dataset.i = i;
      const sw = document.createElement('i');
      sw.style.background = `linear-gradient(${rgba(s.c, s.a)},${rgba(s.c, s.a)}),var(--checker)`;
      el.appendChild(sw); tr.appendChild(el);
    });
  }

  function addStopAt(p) {
    const s = GM.sample(S, p / 100);
    S.stops.push({ p: r1(p), c: s.c, a: Math.round(s.a) });
    return S.stops.length - 1;
  }
  function removeStop(i) {
    if (S.stops.length <= 2) { status('정지점은 최소 두 개가 필요합니다', 'err'); return; }
    S.stops.splice(i, 1);
    sel = Math.min(i, S.stops.length - 1);
    hsb = null;
  }

  function bindStrip() {
    const strip = $('strip'), tr = $('track');
    strip.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      const r = tr.getBoundingClientRect();
      const pAt = x => GM.clamp((x - r.left) / r.width * 100, 0, 100);
      const pin = e.target.closest('.pin');
      let i, off = 0;
      if (!pin) { i = addStopAt(pAt(e.clientX)); }
      else {
        i = +pin.dataset.i;
        if (e.altKey) { S.stops.push(clone(S.stops[i])); i = S.stops.length - 1; }
        off = S.stops[i].p - pAt(e.clientX);
      }
      if (sel !== i) hsb = null;
      sel = i; renderPins(); renderStop(); drawBar();
      const el = tr.querySelector(`.pin[data-i="${i}"]`);
      strip.setPointerCapture(e.pointerId);
      const x0 = e.clientX, y0 = e.clientY;
      let del = false, moved = !pin;
      const mv = ev => {
        if (!moved && Math.abs(ev.clientX - x0) < 2 && Math.abs(ev.clientY - y0) < 2) return;
        moved = true;
        let p = GM.clamp(pAt(ev.clientX) + off, 0, 100);
        p = ev.shiftKey ? Math.round(p / 5) * 5 : r1(p);
        S.stops[i].p = p; el.style.left = p + '%';
        del = (ev.clientY - y0) > 28 && S.stops.length > 2;
        el.style.opacity = del ? 0.25 : 1;
        $('pos').value = Math.round(p);
        drawBar();
      };
      const up = () => {
        strip.removeEventListener('pointermove', mv);
        strip.removeEventListener('pointerup', up);
        strip.removeEventListener('pointercancel', up);
        if (del) removeStop(i);
        if (moved || del) commit(); else renderAll();
      };
      strip.addEventListener('pointermove', mv);
      strip.addEventListener('pointerup', up);
      strip.addEventListener('pointercancel', up);
    });
  }

  /* ---------- 정지점 편집 ---------- */
  function cur() { return S.stops[sel]; }

  function renderStop() {
    const s = cur(); if (!s) return;
    if (!hsb) hsb = GM.rgbToHsb(s.c);
    $('sw').firstChild.style.background = rgba(s.c, s.a);
    if (document.activeElement !== $('hex')) $('hex').value = GM.toHex(s.c);
    if (document.activeElement !== $('pos')) $('pos').value = Math.round(s.p);
    if (document.activeElement !== $('alpha')) $('alpha').value = Math.round(s.a);
    $('hH').value = hsb[0]; $('hS').value = hsb[1]; $('hB').value = hsb[2];
    $('vH').textContent = hsb[0]; $('vS').textContent = hsb[1]; $('vB').textContent = hsb[2];
    const atB = GM.hsbToRgb(hsb[0], hsb[1], 100);
    const g0 = GM.hsbToRgb(0, 0, hsb[2]), g1 = GM.hsbToRgb(hsb[0], 100, hsb[2]);
    $('hH').style.background = 'linear-gradient(to right,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00)';
    $('hS').style.background = `linear-gradient(to right,rgb(${g0}),rgb(${g1}))`;
    $('hB').style.background = `linear-gradient(to right,#000,rgb(${atB}))`;
    $('bDel').className = 'btn' + (S.stops.length <= 2 ? ' off' : '');
  }

  function liveEdit() { drawBar(); renderPins(); renderStop(); renderOut(); }

  function bindStop() {
    ['hH', 'hS', 'hB'].forEach((id, k) => {
      $(id).addEventListener('input', () => {
        hsb[k] = +$(id).value;
        cur().c = GM.hsbToRgb(hsb[0], hsb[1], hsb[2]);
        liveEdit();
      });
      $(id).addEventListener('change', commit);
    });
    $('hex').addEventListener('change', () => {
      const c = GM.fromHex($('hex').value);
      if (!c) { status('색 코드는 #RRGGBB 형식으로 넣어 주세요', 'err'); $('hex').value = GM.toHex(cur().c); return; }
      cur().c = c; hsb = null; commit();
    });
    $('pos').addEventListener('change', () => { cur().p = GM.clamp(+$('pos').value || 0, 0, 100); commit(); });
    $('alpha').addEventListener('change', () => { cur().a = GM.clamp(+$('alpha').value || 0, 0, 100); commit(); });
    [$('hex'), $('pos'), $('alpha'), $('ang'), $('pName')].forEach(el =>
      el.addEventListener('keydown', e => { if (e.key === 'Enter') el.blur(); }));

    $('bFill').addEventListener('click', async () => {
      const r = await host('hyGrad_fill');
      if (!r.ok) { status(r.msg, 'err'); return; }
      cur().c = r.c; hsb = null; commit();
      status('현재 칠 색을 정지점에 넣었습니다');
    });
    $('bRev').addEventListener('click', () => { S.stops.forEach(s => { s.p = r1(100 - s.p); }); commit(); });
    $('bEven').addEventListener('click', () => {
      const keep = cur();
      S.stops = GM.sorted(S.stops);
      const n = S.stops.length;
      S.stops.forEach((s, i) => { s.p = r1(i / (n - 1) * 100); });
      sel = S.stops.indexOf(keep); commit();
    });
    $('bDel').addEventListener('click', () => { removeStop(sel); commit(); });

    document.addEventListener('keydown', e => {
      const t = e.target.tagName;
      if (t === 'INPUT') return;
      if (e.key === 'Delete' || e.key === 'Backspace') { removeStop(sel); commit(); e.preventDefault(); }
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        const d = (e.key === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 10 : 1);
        cur().p = GM.clamp(r1(cur().p + d), 0, 100); commit(); e.preventDefault();
      }
    });
  }

  /* ---------- 곡선 ---------- */
  function renderCurve() {
    const [x1, y1, x2, y2] = S.ease;
    const X = v => v * 100, Y = v => (1 - v) * 100;
    $('cv').setAttribute('d', `M0 100 C${X(x1)} ${Y(y1)} ${X(x2)} ${Y(y2)} 100 0`);
    const a1 = $('a1'), a2 = $('a2');
    a1.setAttribute('x1', 0); a1.setAttribute('y1', 100); a1.setAttribute('x2', X(x1)); a1.setAttribute('y2', Y(y1));
    a2.setAttribute('x1', 100); a2.setAttribute('y1', 0); a2.setAttribute('x2', X(x2)); a2.setAttribute('y2', Y(y2));
    $('h1').setAttribute('cx', X(x1)); $('h1').setAttribute('cy', Y(y1));
    $('h2').setAttribute('cx', X(x2)); $('h2').setAttribute('cy', Y(y2));
    [...$('easeChips').children].forEach((b, k) => {
      b.className = 'btn' + (EASES[k][1].every((v, j) => Math.abs(v - S.ease[j]) < 0.01) ? ' primary' : '');
    });
  }

  function bindCurve() {
    EASES.forEach(([name, e]) => {
      const b = document.createElement('div'); b.className = 'btn'; b.textContent = name;
      b.addEventListener('click', () => { S.ease = e.slice(); commit(); });
      $('easeChips').appendChild(b);
    });
    const svg = $('curve');
    ['h1', 'h2'].forEach((id, k) => {
      $(id).addEventListener('pointerdown', e => {
        e.preventDefault();
        svg.setPointerCapture(e.pointerId);
        const r = svg.getBoundingClientRect();
        const mv = ev => {
          const x = GM.clamp(((ev.clientX - r.left) / r.width * 116 - 8) / 100, 0, 1);
          const y = GM.clamp(1 - ((ev.clientY - r.top) / r.height * 116 - 8) / 100, 0, 1);
          S.ease[k * 2] = Math.round(x * 100) / 100; S.ease[k * 2 + 1] = Math.round(y * 100) / 100;
          renderCurve(); drawBar(); renderOut();
        };
        const up = () => {
          svg.removeEventListener('pointermove', mv); svg.removeEventListener('pointerup', up); svg.removeEventListener('pointercancel', up);
          commit();
        };
        svg.addEventListener('pointermove', mv); svg.addEventListener('pointerup', up); svg.addEventListener('pointercancel', up);
      });
    });
    // 곡선 영역 더블클릭 = 직선으로
    svg.addEventListener('dblclick', () => { S.ease = LINEAR.slice(); commit(); });

    seg('segInterp', v => { S.interp = v; commit(); });
    $('res').addEventListener('input', () => { S.res = +$('res').value; renderOut(); });
    $('res').addEventListener('change', commit);
  }

  function renderOut() {
    $('res').value = S.res; $('vRes').textContent = S.res;
    const n = GM.outputStops(S).length;
    $('outInfo').textContent = GM.needsResample(S) ? `일러스트 정지점 ${n}개로 변환` : '정지점을 그대로 사용';
    $('res').parentNode.style.opacity = GM.needsResample(S) ? 1 : 0.4;
  }

  /* ---------- 적용 옵션 ---------- */
  function seg(id, fn) {
    [...$(id).children].forEach(b => b.addEventListener('click', () => fn(b.dataset.v)));
  }
  function setSeg(id, v) { [...$(id).children].forEach(b => { b.className = 'btn' + (b.dataset.v === v ? ' on' : '') + (b.className.indexOf('grow') >= 0 ? ' grow' : ''); }); }

  function renderApply() {
    setSeg('segInterp', S.interp); setSeg('segTarget', S.target); setSeg('segType', S.type);
    $('dial').firstChild.style.transform = `rotate(${-S.angle}deg)`;
    if (document.activeElement !== $('ang')) $('ang').value = S.angle;
    const angOn = S.type === 'linear' && S.target === 'fill';
    $('angWrap').className = 'row' + (angOn ? '' : ' off-ang');
    $('angWrap').title = angOn ? '' : (S.type === 'radial' ? '원형에는 각도가 없습니다' : '획 그라디언트 각도는 v0.1에서 지원하지 않습니다');
    $('swLive').className = 'switch' + (live ? ' on' : '');
  }

  function bindApply() {
    seg('segTarget', v => { S.target = v; commit(); });
    seg('segType', v => { S.type = v; commit(); });
    $('ang').addEventListener('change', () => {
      let a = Math.round(+$('ang').value || 0);
      a = ((a + 180) % 360 + 360) % 360 - 180;
      S.angle = a; commit();
    });
    const dial = $('dial');
    dial.addEventListener('pointerdown', e => {
      dial.setPointerCapture(e.pointerId);
      const r = dial.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const mv = ev => {
        let a = Math.atan2(-(ev.clientY - cy), ev.clientX - cx) * 180 / Math.PI;
        a = ev.shiftKey ? Math.round(a / 15) * 15 : Math.round(a);
        if (a === 180) a = -180;
        S.angle = a; renderApply();
      };
      const up = () => { dial.removeEventListener('pointermove', mv); dial.removeEventListener('pointerup', up); commit(); };
      mv(e);
      dial.addEventListener('pointermove', mv); dial.addEventListener('pointerup', up);
    });
    $('swLive').addEventListener('click', () => {
      live = !live; localStorage.setItem(LS_LIVE, live ? '1' : '0'); renderApply();
      status(live ? '편집할 때마다 선택 객체에 바로 적용합니다' : '적용 버튼을 눌러야 반영됩니다');
    });
    $('bApply').addEventListener('click', () => apply(false, false));
    $('bSwatch').addEventListener('click', () => apply(true, false));
    $('bClean').addEventListener('click', async () => {
      const r = await host('hyGrad_cleanup');
      if (!r.ok) { status(r.msg, 'err'); return; }
      status(r.removed ? `쓰지 않는 임시 스와치 ${r.removed}개를 지웠습니다` : '지울 임시 스와치가 없습니다', r.removed ? 'good' : '');
    });
    $('bRead').addEventListener('click', async () => {
      const r = await host('hyGrad_read');
      if (!r.ok) { status(r.msg, 'err'); return; }
      if (r.state) S = Object.assign(clone(DEF), r.state);
      else {
        S.stops = r.raw.stops; S.type = r.raw.type; S.angle = r.raw.angle;
        S.interp = 'rgb'; S.ease = LINEAR.slice();
      }
      S.target = r.target || S.target;
      sel = 0; hsb = null; saveState(); renderAll();
      status(r.state ? '이 패널로 만든 그라디언트를 편집 상태 그대로 불러왔습니다' : '선택 객체의 그라디언트를 불러왔습니다', 'good');
    });
  }

  /* ---------- 프리셋 ---------- */
  function userPresets() { try { return JSON.parse(localStorage.getItem(LS_USER)) || []; } catch (e) { return []; } }
  function setUserPresets(a) { try { localStorage.setItem(LS_USER, JSON.stringify(a)); } catch (e) {} }

  function presetEl(p, onDel) {
    const el = document.createElement('div'); el.className = 'pre'; el.title = p.name;
    const pb = document.createElement('div'); pb.className = 'pb';
    const i = document.createElement('i'); i.style.background = GM.cssGradient(Object.assign({ res: 24 }, p));
    pb.appendChild(i); el.appendChild(pb);
    const sp = document.createElement('span'); sp.textContent = p.name; el.appendChild(sp);
    el.addEventListener('click', () => {
      S.stops = clone(p.stops); S.interp = p.interp || 'oklab'; S.ease = (p.ease || LINEAR).slice();
      if (p.res) S.res = p.res;
      sel = 0; hsb = null; commit();
      status(`프리셋 "${p.name}"을 불러왔습니다`);
    });
    if (onDel) {
      const x = document.createElement('div'); x.className = 'x'; x.textContent = '×'; x.title = '삭제';
      x.addEventListener('click', ev => { ev.stopPropagation(); onDel(); });
      pb.appendChild(x);
    }
    return el;
  }

  function renderPresets() {
    const box = $('presets'); box.innerHTML = '';
    PRESETS.forEach(p => box.appendChild(presetEl(p)));
    const ub = $('userPresets'); ub.innerHTML = '';
    const list = userPresets();
    $('userHead').style.display = list.length ? '' : 'none';
    list.forEach((p, k) => ub.appendChild(presetEl(p, () => {
      const a = userPresets(); a.splice(k, 1); setUserPresets(a); renderPresets();
      status(`프리셋 "${p.name}"을 지웠습니다`);
    })));
  }

  function bindPresets() {
    $('bSave').addEventListener('click', () => {
      const name = $('pName').value.trim();
      if (!name) { status('저장할 이름을 넣어 주세요', 'err'); $('pName').focus(); return; }
      const a = userPresets().filter(p => p.name !== name);
      a.push({ name, stops: clone(S.stops), interp: S.interp, ease: S.ease.slice(), res: S.res });
      setUserPresets(a); $('pName').value = ''; renderPresets();
      status(`프리셋 "${name}"을 저장했습니다`, 'good');
    });
  }

  /* ---------- 공통 ---------- */
  function renderAll() { drawBar(); renderPins(); renderStop(); renderCurve(); renderOut(); renderApply(); }
  function commit() { saveState(); renderAll(); scheduleLive(); }

  function init() {
    theme();
    if (window.__adobe_cep__) window.__adobe_cep__.addEventListener('com.adobe.csxs.events.ThemeColorChanged', theme);
    bindStrip(); bindStop(); bindCurve(); bindApply(); bindPresets();
    renderPresets(); renderAll();
    window.addEventListener('resize', drawBar);
  }
  init();
})();
