/* hy Gradient — 패널 로직 */
(function () {
  'use strict';
  const GM = window.GM;
  const $ = id => document.getElementById(id);
  const LS_STATE = 'hyGrad.state', LS_USER = 'hyGrad.presets', LS_LIVE = 'hyGrad.live', LS_UI = 'hyGrad.ui';
  const LINEAR = [0.33, 0.33, 0.67, 0.67];

  const DEF = {
    stops: [{ p: 0, c: [29, 53, 87], a: 100 }, { p: 100, c: [244, 162, 97], a: 100 }],
    interp: 'oklab', ease: LINEAR.slice(), easeMode: 'seg', res: 24,
    type: 'linear', angle: 0, target: 'fill', span: false
  };
  const UI_DEF = { fold: { secPresets: false, secCurve: false, secSteps: true }, steps: 5, order: 'x', spacing: 'even' };

  const EASES = [
    ['직선', LINEAR], ['가속', [0.55, 0, 1, 0.45]], ['감속', [0, 0.55, 0.45, 1]],
    ['S자', [0.65, 0, 0.35, 1]], ['역S', [0.2, 0.8, 0.8, 0.2]]
  ];

  const h = hex => GM.fromHex(hex);
  const P = (name, cols, extra) => Object.assign({
    name, interp: 'oklab', ease: LINEAR.slice(),
    stops: cols.map((c, i) => Array.isArray(c)
      ? { p: c[1], c: h(c[0]), a: c[2] == null ? 100 : c[2] }
      : { p: Math.round(i / (cols.length - 1) * 100), c: h(c), a: 100 })
  }, extra || {});

  const PRESETS = [
    P('열 분포', ['#2B3A8F', '#2E9CC9', '#F2E35B', '#E8532E', '#8E1B2A']),
    P('고도', [['#2F5D3A', 0], ['#9BB567', 35], ['#E9DCA0', 60], ['#B98C5A', 82], ['#F5F2EA', 100]]),
    P('수심', ['#0B2545', '#13315C', '#8DA9C4', '#EEF4ED']),
    P('일조', ['#2D1E4F', '#8A2F6B', '#E0643C', '#F7C948', '#FFF3C4']),
    P('녹지', ['#1F4D2B', '#6A9F58', '#D8E8B0']),
    P('블루프린트', ['#0F2A4A', '#3F6FA8', '#D6E4F5']),
    P('콘크리트', ['#6F6F6C', '#B9B7B0', '#E9E7E1'], { interp: 'rgb' }),
    P('대기 원근', ['#6F8FB3', '#C9D6E3', '#F4EFE6']),
    P('모노 잉크', ['#000000', '#FFFFFF'], { interp: 'rgb' }),
    P('리소 핑크 블루', ['#FF48B0', '#0078BF']),
    P('그림자 페이드', [['#000000', 0, 60], ['#000000', 100, 0]], { interp: 'rgb', ease: [0, 0.55, 0.45, 1] }),
    P('빛 페이드', [['#FFFFFF', 0, 85], ['#FFFFFF', 100, 0]], { interp: 'rgb', ease: [0, 0.55, 0.45, 1] })
  ];

  const clone = o => JSON.parse(JSON.stringify(o));
  const r1 = v => Math.round(v * 10) / 10;
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a / 100})`;
  const lsGet = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

  let S = loadState();
  let sel = 0;
  let hsb = null;           // 선택 정지점의 HSB 캐시 (채도 0일 때 색조 유지)
  let live = lsGet(LS_LIVE, 1) !== 0;
  const UI = Object.assign(clone(UI_DEF), lsGet(LS_UI, {}));
  UI.fold = Object.assign(clone(UI_DEF.fold), UI.fold || {});

  function loadState() {
    const s = lsGet(LS_STATE, null);
    if (s && s.stops && s.stops.length >= 2) return Object.assign(clone(DEF), s);
    return clone(DEF);
  }
  function saveState() { lsSet(LS_STATE, S); }
  function saveUI() { lsSet(LS_UI, UI); }

  function status(msg, kind) { const el = $('status'); el.textContent = msg; el.className = kind || ''; }

  /* ---------- 패널 되돌리기 (일러스트 실행 취소와 별개로 편집기 상태만) ---------- */
  const hist = { past: [], future: [], cur: JSON.stringify(S) };
  function record() {
    const now = JSON.stringify(S);
    if (now === hist.cur) return;
    hist.past.push(hist.cur); if (hist.past.length > 80) hist.past.shift();
    hist.future.length = 0; hist.cur = now;
  }
  function travel(back) {
    const from = back ? hist.past : hist.future, to = back ? hist.future : hist.past;
    if (!from.length) return;
    to.push(hist.cur); hist.cur = from.pop();
    S = Object.assign(clone(DEF), JSON.parse(hist.cur));
    sel = Math.min(sel, S.stops.length - 1); hsb = null;
    saveState(); renderAll(); want(true);
    status(back ? '편집기를 한 단계 되돌렸습니다' : '편집기를 한 단계 다시 했습니다');
  }

  /* ---------- 호스트 ---------- */
  function host(fn, arg) {
    return new Promise(res => {
      if (!window.__adobe_cep__) { res({ ok: false, msg: '일러스트레이터 안에서 실행하세요' }); return; }
      const src = arg === undefined ? fn + '()' : fn + '("' + encodeURIComponent(typeof arg === 'string' ? arg : JSON.stringify(arg)) + '")';
      window.__adobe_cep__.evalScript(src, r => {
        try { res(JSON.parse(r)); } catch (e) { res({ ok: false, msg: String(r) }); }
      });
    });
  }

  /* ---------- 실시간 반영 큐 ----------
     드래그 중에는 간격을 두고(throttle) 반영하고, 손을 떼면 바로 마지막 상태를 확정한다.
     적용 방식(종류·대상·각도·걸치기)이 그대로면 공유 임시 스와치의 바뀐 정지점만 고친다(실행 취소 단계가 적음). */
  const skey = () => [S.type, S.target, S.angle, S.span ? 1 : 0].join('|');
  let lastKey = null;
  const Q = { busy: false, job: null, last: 0, timer: null };

  function want(final, force) {
    if (!live && !force) return;
    const kind = skey() !== lastKey || force ? 'full' : 'stops';
    const j = Q.job;
    Q.job = { kind: j && j.kind === 'full' ? 'full' : kind, final: !!(final || (j && j.final)), force: !!(force || (j && j.force)) };
    pump();
  }
  function pump() {
    if (Q.busy || !Q.job) return;
    const gap = Q.job.final ? 0 : (Q.job.kind === 'full' ? 160 : 90);
    const wait = gap - (Date.now() - Q.last);
    if (wait > 0) { if (!Q.timer) Q.timer = setTimeout(() => { Q.timer = null; pump(); }, wait); return; }
    const job = Q.job; Q.job = null; Q.busy = true; Q.last = Date.now();
    run(job).then(() => { Q.busy = false; pump(); });
  }
  function payload(extra) {
    const out = GM.outputStops(S);
    return Object.assign({ type: S.type, angle: S.angle, target: S.target, span: !!S.span, out, outN: out.length, note: JSON.stringify(S) }, extra || {});
  }
  async function run(job) {
    const key = skey();
    const r = await host(job.kind === 'full' ? 'hyGrad_apply' : 'hyGrad_update', payload({ final: job.final }));
    if (r.ok) {
      lastKey = key;
      if (job.final) status(`${r.count}개 객체에 반영했습니다`, 'good');
    } else if (job.final) {
      if (/선택하세요/.test(r.msg) && !job.force) status('선택한 객체가 없어 편집기만 바뀌었습니다');
      else status(r.msg, 'err');
    }
  }

  /* ---------- 테마 ---------- */
  function theme() {
    try {
      const env = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      const c = env.appSkinInfo.panelBackgroundColor.color;
      const bg = [c.red, c.green, c.blue].map(Math.round);
      const lum = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) / 255;
      const dark = lum < 0.5;
      const sh = d => `rgb(${bg.map(v => Math.max(0, Math.min(255, v + d))).join(',')})`;
      const st = document.documentElement.style;
      st.setProperty('--bg', `rgb(${bg.join(',')})`);
      st.setProperty('--fg', dark ? '#e8e8e8' : '#1f1f1f');
      st.setProperty('--dim', dark ? '#9c9c9c' : '#6a6a6a');
      st.setProperty('--field', dark ? sh(-14) : sh(-22));
      st.setProperty('--field2', dark ? sh(16) : sh(-40));
      st.setProperty('--line', dark ? sh(28) : sh(-60));
    } catch (e) {}
  }

  /* ---------- 그라디언트 바 ---------- */
  function drawBar() {
    const cv = $('bar'), d = window.devicePixelRatio || 1;
    const W = Math.round(cv.clientWidth * d), H = Math.round(cv.clientHeight * d);
    if (!W) return;
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const ctx = cv.getContext('2d'), cs = Math.round(6 * d);
    for (let y = 0; y < H; y += cs) for (let x = 0; x < W; x += cs) {
      ctx.fillStyle = ((x / cs + y / cs) & 1) ? '#cfcfcf' : '#f4f4f4'; ctx.fillRect(x, y, cs, cs);
    }
    const pad = Math.round(7 * d), inner = W - pad * 2;
    const st = GM.sorted(S.stops), e = GM.bezier(S.ease);
    for (let x = 0; x < W; x++) {
      const s = GM.sample(S, (x - pad + 0.5) / inner, st, e);
      ctx.fillStyle = rgba(s.c, s.a); ctx.fillRect(x, 0, 1, H);
    }
  }

  // 전체 곡선 모드에서는 정지점이 바 위에서 곡선만큼 밀려 보이므로 표시 위치를 따로 계산
  function shownPos(p) {
    if (S.easeMode !== 'all' || GM.isLinear(S.ease)) return p;
    return GM.invEase(GM.bezier(S.ease), p / 100) * 100;
  }
  function stopPosFromShown(x) {
    if (S.easeMode !== 'all' || GM.isLinear(S.ease)) return x;
    return GM.bezier(S.ease)(x / 100) * 100;
  }

  function renderPins() {
    const tr = $('track'); tr.innerHTML = '';
    S.stops.forEach((s, i) => {
      const el = document.createElement('div');
      el.className = 'pin' + (i === sel ? ' on' : '');
      el.style.left = shownPos(s.p) + '%'; el.dataset.i = i;
      const sw = document.createElement('i');
      sw.style.background = `linear-gradient(${rgba(s.c, s.a)},${rgba(s.c, s.a)}),var(--checker)`;
      el.appendChild(sw); tr.appendChild(el);
    });
  }

  function addStopAt(p) {
    const s = GM.sample(S, shownPos(p) / 100);
    S.stops.push({ p: r1(p), c: s.c, a: Math.round(s.a) });
    return S.stops.length - 1;
  }
  function removeStop(i) {
    if (S.stops.length <= 2) { status('정지점은 최소 두 개가 필요합니다', 'err'); return false; }
    S.stops.splice(i, 1);
    sel = Math.min(i, S.stops.length - 1);
    hsb = null;
    return true;
  }

  function bindStrip() {
    const strip = $('strip'), tr = $('track');
    strip.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      const r = tr.getBoundingClientRect();
      const pAt = x => stopPosFromShown(GM.clamp((x - r.left) / r.width * 100, 0, 100));
      const pin = e.target.closest('.pin');
      let i, off = 0;
      if (!pin) { i = addStopAt(pAt(e.clientX)); }
      else {
        i = +pin.dataset.i;
        if (e.altKey) { S.stops.push(clone(S.stops[i])); i = S.stops.length - 1; }
        off = S.stops[i].p - pAt(e.clientX);
      }
      if (sel !== i) hsb = null;
      sel = i; renderPins(); renderStop(); drawBar();
      const el = tr.querySelector(`.pin[data-i="${i}"]`);
      strip.setPointerCapture(e.pointerId);
      const x0 = e.clientX, y0 = e.clientY;
      let del = false, moved = !pin;
      if (!pin) want(false);
      const mv = ev => {
        if (!moved && Math.abs(ev.clientX - x0) < 2 && Math.abs(ev.clientY - y0) < 2) return;
        moved = true;
        let p = GM.clamp(pAt(ev.clientX) + off, 0, 100);
        p = ev.shiftKey ? Math.round(p / 5) * 5 : r1(p);
        S.stops[i].p = p; el.style.left = shownPos(p) + '%';
        del = (ev.clientY - y0) > 28 && S.stops.length > 2;
        el.className = 'pin on' + (del ? ' del' : '');
        $('pos').value = Math.round(shownPos(p));
        drawBar(); renderInfo();
        if (!del) want(false);
      };
      const up = () => {
        strip.removeEventListener('pointermove', mv);
        strip.removeEventListener('pointerup', up);
        strip.removeEventListener('pointercancel', up);
        if (del) removeStop(i);
        if (moved || del) commit(); else renderAll();
      };
      strip.addEventListener('pointermove', mv);
      strip.addEventListener('pointerup', up);
      strip.addEventListener('pointercancel', up);
    });
    strip.addEventListener('dblclick', e => { if (e.target.closest('.pin')) pick(); });
  }

  /* ---------- 정지점 편집 ---------- */
  function cur() { return S.stops[sel]; }

  function renderInfo() {
    const order = GM.sorted(S.stops), k = order.indexOf(cur()) + 1;
    $('stopInfo').textContent = `정지점 ${k} / ${S.stops.length}`;
    $('bUndo').className = 'ib' + (hist.past.length ? '' : ' off');
    $('bRedo').className = 'ib' + (hist.future.length ? '' : ' off');
  }

  function renderStop() {
    const s = cur(); if (!s) return;
    if (!hsb) hsb = GM.rgbToHsb(s.c);
    $('sw').firstChild.style.background = rgba(s.c, s.a);
    if (document.activeElement !== $('hex')) $('hex').value = GM.toHex(s.c);
    if (document.activeElement !== $('pos')) $('pos').value = Math.round(shownPos(s.p));
    if (document.activeElement !== $('alpha')) $('alpha').value = Math.round(s.a);
    $('hH').value = hsb[0]; $('hS').value = hsb[1]; $('hB').value = hsb[2];
    $('vH').textContent = hsb[0]; $('vS').textContent = hsb[1]; $('vB').textContent = hsb[2];
    const atB = GM.hsbToRgb(hsb[0], hsb[1], 100);
    const g0 = GM.hsbToRgb(0, 0, hsb[2]), g1 = GM.hsbToRgb(hsb[0], 100, hsb[2]);
    $('hH').style.background = 'linear-gradient(to right,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00)';
    $('hS').style.background = `linear-gradient(to right,rgb(${g0}),rgb(${g1}))`;
    $('hB').style.background = `linear-gradient(to right,#000,rgb(${atB}))`;
    $('bDel').className = 'btn' + (S.stops.length <= 2 ? ' off' : '');
    renderInfo();
  }

  // 드래그 중 화면 갱신 + 간격 둔 반영
  function liveEdit() { drawBar(); renderPins(); renderStop(); renderOut(); renderSteps(); want(false); }

  async function pick() {
    const r = await host('hyGrad_pick', { c: cur().c });
    if (!r.ok) { status(r.msg, 'err'); return; }
    cur().c = r.c; hsb = null; commit();
  }

  // 라벨을 좌우로 끌어 숫자 조절 (일러스트 패널처럼)
  function scrub(label, get, set, min, max, step) {
    label.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      e.preventDefault();
      label.setPointerCapture(e.pointerId);
      const x0 = e.clientX, v0 = get();
      let moved = false;
      const mv = ev => {
        const dx = ev.clientX - x0;
        if (!moved && Math.abs(dx) < 2) return;
        moved = true;
        const k = ev.shiftKey ? step * 10 : step;
        set(GM.clamp(Math.round((v0 + dx * k) / step) * step, min, max));
      };
      const up = () => {
        label.removeEventListener('pointermove', mv); label.removeEventListener('pointerup', up); label.removeEventListener('pointercancel', up);
        if (moved) commit();
      };
      label.addEventListener('pointermove', mv); label.addEventListener('pointerup', up); label.addEventListener('pointercancel', up);
    });
  }

  function bindStop() {
    ['hH', 'hS', 'hB'].forEach((id, k) => {
      $(id).addEventListener('input', () => {
        hsb[k] = +$(id).value;
        cur().c = GM.hsbToRgb(hsb[0], hsb[1], hsb[2]);
        liveEdit();
      });
      $(id).addEventListener('change', commit);
    });
    $('hex').addEventListener('change', () => {
      const c = GM.fromHex($('hex').value);
      if (!c) { status('색 코드는 #RRGGBB 형식으로 넣어 주세요', 'err'); $('hex').value = GM.toHex(cur().c); return; }
      cur().c = c; hsb = null; commit();
    });
    $('pos').addEventListener('change', () => { cur().p = r1(stopPosFromShown(GM.clamp(+$('pos').value || 0, 0, 100))); commit(); });
    $('alpha').addEventListener('change', () => { cur().a = GM.clamp(+$('alpha').value || 0, 0, 100); commit(); });
    [$('hex'), $('pos'), $('alpha'), $('ang'), $('pName'), $('nSteps')].forEach(el =>
      el.addEventListener('keydown', e => { if (e.key === 'Enter') el.blur(); }));
    scrub($('sPos'), () => shownPos(cur().p), v => { cur().p = r1(stopPosFromShown(v)); liveEdit(); }, 0, 100, 0.5);
    scrub($('sAlpha'), () => cur().a, v => { cur().a = v; liveEdit(); }, 0, 100, 1);

    $('sw').addEventListener('click', pick);
    $('bFill').addEventListener('click', async () => {
      const r = await host('hyGrad_fill');
      if (!r.ok) { status(r.msg, 'err'); return; }
      cur().c = r.c; hsb = null; commit();
    });
    $('bRev').addEventListener('click', () => { S.stops.forEach(s => { s.p = r1(100 - s.p); }); commit(); });
    $('bEven').addEventListener('click', () => {
      const keep = cur();
      S.stops = GM.sorted(S.stops);
      const n = S.stops.length;
      S.stops.forEach((s, i) => { s.p = r1(i / (n - 1) * 100); });
      sel = S.stops.indexOf(keep); commit();
    });
    $('bDel').addEventListener('click', () => { if (removeStop(sel)) commit(); });
    $('bUndo').addEventListener('click', () => travel(true));
    $('bRedo').addEventListener('click', () => travel(false));

    document.addEventListener('keydown', e => {
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && (k === 'z' || k === 'y')) {
        if (e.target.tagName === 'INPUT') return;
        travel(k === 'z' && !e.shiftKey); e.preventDefault(); return;
      }
      if (e.target.tagName === 'INPUT') return;
      if (e.key === 'Delete' || e.key === 'Backspace') { if (removeStop(sel)) commit(); e.preventDefault(); }
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        const d = (e.key === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 10 : 1);
        cur().p = r1(stopPosFromShown(GM.clamp(shownPos(cur().p) + d, 0, 100))); commit(); e.preventDefault();
      } else if (e.key === 'Tab') {
        // 위치 순서로 다음·이전 정지점
        const order = GM.sorted(S.stops), k2 = order.indexOf(cur());
        const nx = order[(k2 + (e.shiftKey ? -1 : 1) + order.length) % order.length];
        sel = S.stops.indexOf(nx); hsb = null; renderAll(); e.preventDefault();
      }
    });
  }

  /* ---------- 곡선 ---------- */
  function renderCurve() {
    const [x1, y1, x2, y2] = S.ease;
    const X = v => v * 100, Y = v => (1 - v) * 100;
    $('cv').setAttribute('d', `M0 100 C${X(x1)} ${Y(y1)} ${X(x2)} ${Y(y2)} 100 0`);
    const a1 = $('a1'), a2 = $('a2');
    a1.setAttribute('x1', 0); a1.setAttribute('y1', 100); a1.setAttribute('x2', X(x1)); a1.setAttribute('y2', Y(y1));
    a2.setAttribute('x1', 100); a2.setAttribute('y1', 0); a2.setAttribute('x2', X(x2)); a2.setAttribute('y2', Y(y2));
    $('h1').setAttribute('cx', X(x1)); $('h1').setAttribute('cy', Y(y1));
    $('h2').setAttribute('cx', X(x2)); $('h2').setAttribute('cy', Y(y2));
    [...$('easeChips').children].forEach((b, k) => {
      b.className = 'btn' + (EASES[k][1].every((v, j) => Math.abs(v - S.ease[j]) < 0.01) ? ' primary' : '');
    });
    setSeg('segEaseMode', S.easeMode || 'seg');
    $('segEaseMode').className = 'seg' + (GM.isLinear(S.ease) ? ' off' : '');
  }

  function bindCurve() {
    EASES.forEach(([name, e]) => {
      const b = document.createElement('div'); b.className = 'btn'; b.textContent = name;
      b.addEventListener('click', () => { S.ease = e.slice(); commit(); });
      $('easeChips').appendChild(b);
    });
    const svg = $('curve');
    ['h1', 'h2'].forEach((id, k) => {
      $(id).addEventListener('pointerdown', e => {
        e.preventDefault();
        svg.setPointerCapture(e.pointerId);
        const r = svg.getBoundingClientRect();
        const mv = ev => {
          const x = GM.clamp(((ev.clientX - r.left) / r.width * 116 - 8) / 100, 0, 1);
          const y = GM.clamp(1 - ((ev.clientY - r.top) / r.height * 116 - 8) / 100, 0, 1);
          S.ease[k * 2] = Math.round(x * 100) / 100; S.ease[k * 2 + 1] = Math.round(y * 100) / 100;
          renderCurve(); renderPins(); drawBar(); renderOut(); renderSteps(); want(false);
        };
        const up = () => {
          svg.removeEventListener('pointermove', mv); svg.removeEventListener('pointerup', up); svg.removeEventListener('pointercancel', up);
          commit();
        };
        svg.addEventListener('pointermove', mv); svg.addEventListener('pointerup', up); svg.addEventListener('pointercancel', up);
      });
    });
    svg.addEventListener('dblclick', () => { S.ease = LINEAR.slice(); commit(); });

    seg('segEaseMode', v => { S.easeMode = v; commit(); });
    seg('segInterp', v => { S.interp = v; commit(); });
    $('res').addEventListener('input', () => { S.res = +$('res').value; renderOut(); want(false); });
    $('res').addEventListener('change', commit);
  }

  function renderOut() {
    $('res').value = S.res; $('vRes').textContent = S.res;
    const need = GM.needsResample(S), n = GM.outputStops(S).length;
    $('outInfo').textContent = need ? `일러스트에는 정지점 ${n}개로 풀어 넣습니다` : '정지점을 그대로 씁니다';
    $('res').style.opacity = need ? 1 : 0.35; $('vRes').style.opacity = need ? 1 : 0.35;
  }

  /* ---------- 적용 옵션 ---------- */
  function seg(id, fn) {
    [...$(id).children].forEach(b => b.addEventListener('click', () => fn(b.dataset.v)));
  }
  function setSeg(id, v) { [...$(id).children].forEach(b => { b.className = 'btn' + (b.dataset.v === v ? ' on' : '') + (b.className.indexOf('grow') >= 0 ? ' grow' : ''); }); }

  function renderApply() {
    setSeg('segInterp', S.interp); setSeg('segTarget', S.target); setSeg('segType', S.type);
    setSeg('segSpan', S.span ? 'span' : 'each');
    $('dial').firstChild.style.transform = `rotate(${-S.angle}deg)`;
    if (document.activeElement !== $('ang')) $('ang').value = S.angle;
    const fill = S.target === 'fill', angOn = S.type === 'linear' && fill;
    $('angWrap').className = 'row' + (angOn ? '' : ' off-ang');
    $('angWrap').title = angOn ? '' : (S.type === 'radial' ? '원형에는 각도가 없습니다' : '획 그라디언트는 각도를 바꿀 수 없습니다');
    $('segSpan').className = 'seg' + (fill ? '' : ' off');
    $('segSpan').title = fill ? '여러 객체를 골랐을 때' : '획 그라디언트는 객체마다만 됩니다';
    $('swLive').className = 'switch' + (live ? ' on' : '');
  }

  function setAngle(a) {
    a = Math.round(a);
    S.angle = ((a + 180) % 360 + 360) % 360 - 180;
    renderApply();
  }

  function bindApply() {
    seg('segTarget', v => { S.target = v; commit(); });
    seg('segType', v => { S.type = v; commit(); });
    seg('segSpan', v => { S.span = v === 'span'; commit(); });
    $('ang').addEventListener('change', () => { setAngle(+$('ang').value || 0); commit(); });
    scrub($('sAng'), () => S.angle, v => { setAngle(v); want(false); }, -180, 180, 1);
    const dial = $('dial');
    dial.addEventListener('pointerdown', e => {
      dial.setPointerCapture(e.pointerId);
      const r = dial.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const mv = ev => {
        let a = Math.atan2(-(ev.clientY - cy), ev.clientX - cx) * 180 / Math.PI;
        a = ev.shiftKey ? Math.round(a / 15) * 15 : Math.round(a);
        if (a === S.angle) return;
        setAngle(a); want(false);
      };
      const up = () => { dial.removeEventListener('pointermove', mv); dial.removeEventListener('pointerup', up); commit(); };
      mv(e);
      dial.addEventListener('pointermove', mv); dial.addEventListener('pointerup', up);
    });
    dial.addEventListener('dblclick', () => { setAngle(0); commit(); });
    $('swLive').addEventListener('click', () => {
      live = !live; lsSet(LS_LIVE, live ? 1 : 0); renderApply();
      status(live ? '편집하는 동안 선택 객체에 바로 반영합니다' : '[적용]을 눌러야 반영됩니다');
      if (live) want(true);
    });
    $('bApply').addEventListener('click', () => want(true, true));
    $('bSwatch').addEventListener('click', async () => {
      const r = await host('hyGrad_apply', payload({ keep: true, final: true }));
      if (!r.ok) { status(r.msg, 'err'); return; }
      lastKey = null;   // 정식 스와치로 떨어져 나갔으니 다음 편집은 새 임시 스와치로
      status(r.count ? `스와치 "${r.name}"을 등록하고 ${r.count}개 객체에 적용했습니다` : `스와치 "${r.name}"을 등록했습니다`, 'good');
    });
    $('bClean').addEventListener('click', async () => {
      const r = await host('hyGrad_cleanup');
      if (!r.ok) { status(r.msg, 'err'); return; }
      status(r.removed ? `쓰지 않는 임시 스와치 ${r.removed}개를 지웠습니다` : '지울 임시 스와치가 없습니다', r.removed ? 'good' : '');
    });
    $('bRead').addEventListener('click', async () => {
      const r = await host('hyGrad_read');
      if (!r.ok) { status(r.msg, 'err'); return; }
      let msg;
      if (r.state) {
        S = Object.assign(clone(DEF), r.state);
        msg = '이 패널로 만든 그라디언트를 편집 상태 그대로 불러왔습니다';
      } else {
        const ex = GM.expandMidpoints(r.raw.stops);
        S.stops = ex.stops; S.type = r.raw.type; S.angle = r.raw.angle;
        S.interp = 'rgb'; S.ease = LINEAR.slice(); S.easeMode = 'seg'; S.span = false;
        msg = '선택 객체의 그라디언트를 불러왔습니다' + (ex.added ? ` · 중간점 ${ex.added}개를 정지점으로 바꿨습니다` : '');
      }
      S.target = r.target || S.target;
      sel = 0; hsb = null; lastKey = skey();
      saveState(); record(); renderAll();
      status(msg, 'good');
    });
  }

  /* ---------- 단계 색·객체별 분배 ---------- */
  function stepColors() { return GM.lut(S, UI.steps).map(x => x.c); }

  function renderSteps() {
    $('nSteps').value = UI.steps;
    const box = $('stepChips');
    const cols = stepColors();
    if (box.children.length !== cols.length) {
      box.innerHTML = '';
      cols.forEach((c, i) => {
        const d = document.createElement('div'); d.dataset.i = i; box.appendChild(d);
      });
    }
    cols.forEach((c, i) => { box.children[i].style.background = `rgb(${c})`; box.children[i].title = GM.toHex(c); });
    setSeg('segOrder', UI.order); setSeg('segSpacing', UI.spacing);
  }

  function bindSteps() {
    const setN = n => { UI.steps = GM.clamp(Math.round(n) || 2, 2, 24); saveUI(); renderSteps(); };
    $('nDec').addEventListener('click', () => setN(UI.steps - 1));
    $('nInc').addEventListener('click', () => setN(UI.steps + 1));
    $('nSteps').addEventListener('change', () => setN(+$('nSteps').value));
    $('stepChips').addEventListener('click', async e => {
      const d = e.target.closest('[data-i]'); if (!d) return;
      const c = stepColors()[+d.dataset.i];
      const r = await host('hyGrad_solid', { c, target: S.target });
      status(r.ok ? `${GM.toHex(c)}로 칠했습니다` : r.msg, r.ok ? 'good' : 'err');
    });
    $('bSteps').addEventListener('click', async () => {
      const r = await host('hyGrad_steps', { colors: stepColors() });
      status(r.ok ? `스와치 그룹 "${r.name}"을 만들었습니다` : r.msg, r.ok ? 'good' : 'err');
    });
    seg('segOrder', v => { UI.order = v; saveUI(); renderSteps(); });
    seg('segSpacing', v => { UI.spacing = v; saveUI(); renderSteps(); });
    $('bDist').addEventListener('click', async () => {
      const lut = GM.lut(S, 101).map(x => x.c);
      const r = await host('hyGrad_distribute', { lut, order: UI.order, spacing: UI.spacing, target: S.target });
      status(!r.ok ? r.msg : r.offset ? `hy Offset 링 ${r.count}개에 나눠 칠했습니다 · 링을 다시 만들어도 유지돼요` : `${r.count}개 객체에 색을 나눠 칠했습니다`, r.ok ? 'good' : 'err');
    });
  }

  /* ---------- 접는 구역 ---------- */
  function bindFolds() {
    document.querySelectorAll('h2.fold').forEach(h2 => {
      const sec = h2.parentNode;
      const paint = () => { sec.className = UI.fold[sec.id] ? 'closed' : ''; };
      h2.addEventListener('click', () => { UI.fold[sec.id] = !UI.fold[sec.id]; saveUI(); paint(); if (!UI.fold[sec.id]) drawBar(); });
      paint();
    });
  }

  /* ---------- 프리셋 ---------- */
  function userPresets() { return lsGet(LS_USER, []); }
  function setUserPresets(a) { lsSet(LS_USER, a); }

  function presetEl(p, onDel) {
    const el = document.createElement('div'); el.className = 'pre'; el.title = p.name;
    const pb = document.createElement('div'); pb.className = 'pb';
    const i = document.createElement('i'); i.style.background = GM.cssGradient(Object.assign({ res: 24, easeMode: 'seg' }, p));
    pb.appendChild(i); el.appendChild(pb);
    const sp = document.createElement('span'); sp.textContent = p.name; el.appendChild(sp);
    el.addEventListener('click', () => {
      S.stops = clone(p.stops); S.interp = p.interp || 'oklab'; S.ease = (p.ease || LINEAR).slice();
      S.easeMode = p.easeMode || 'seg';
      if (p.res) S.res = p.res;
      sel = 0; hsb = null; commit();
      status(`프리셋 "${p.name}"을 불러왔습니다 · 되돌리기는 Ctrl+Z`);
    });
    if (onDel) {
      const x = document.createElement('div'); x.className = 'x'; x.textContent = '×'; x.title = '삭제';
      x.addEventListener('click', ev => { ev.stopPropagation(); onDel(); });
      pb.appendChild(x);
    }
    return el;
  }

  function renderPresets() {
    const box = $('presets'); box.innerHTML = '';
    PRESETS.forEach(p => box.appendChild(presetEl(p)));
    const ub = $('userPresets'); ub.innerHTML = '';
    const list = userPresets();
    $('userHead').style.display = list.length ? '' : 'none';
    list.forEach((p, k) => ub.appendChild(presetEl(p, () => {
      const a = userPresets(); a.splice(k, 1); setUserPresets(a); renderPresets();
      status(`프리셋 "${p.name}"을 지웠습니다`);
    })));
  }

  function bindPresets() {
    $('bSave').addEventListener('click', () => {
      const name = $('pName').value.trim();
      if (!name) { status('저장할 이름을 넣어 주세요', 'err'); $('pName').focus(); return; }
      const a = userPresets().filter(p => p.name !== name);
      a.push({ name, stops: clone(S.stops), interp: S.interp, ease: S.ease.slice(), easeMode: S.easeMode, res: S.res });
      setUserPresets(a); $('pName').value = ''; renderPresets();
      status(`프리셋 "${name}"을 저장했습니다`, 'good');
    });
  }

  /* ---------- 공통 ---------- */
  function renderAll() { drawBar(); renderPins(); renderStop(); renderCurve(); renderOut(); renderApply(); renderSteps(); }
  // 편집 확정: 저장 → 되돌리기 기록 → 화면 → 마지막 상태 반영
  function commit() { saveState(); record(); renderAll(); want(true); }

  function init() {
    theme();
    if (window.__adobe_cep__) window.__adobe_cep__.addEventListener('com.adobe.csxs.events.ThemeColorChanged', theme);
    bindFolds(); bindStrip(); bindStop(); bindCurve(); bindApply(); bindSteps(); bindPresets();
    renderPresets(); renderAll();
    window.addEventListener('resize', drawBar);
  }
  init();
})();
