/* hy Gradient — Illustrator 호스트 (ExtendScript, ES3). 전역 함수 접두: hyGrad_ */

function hyGrad_parse(s) { return eval('(' + decodeURIComponent(s) + ')'); }
function hyGrad_q(s) {
  return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n') + '"';
}
function hyGrad_ok(extra) { return '{"ok":true' + (extra ? ',' + extra : '') + '}'; }
function hyGrad_err(m) { return '{"ok":false,"msg":' + hyGrad_q(m) + '}'; }
function hyGrad_hex(c) {
  var s = '#', i, h;
  for (i = 0; i < 3; i++) { h = Math.round(c[i]).toString(16).toUpperCase(); s += h.length < 2 ? '0' + h : h; }
  return s;
}

/* ---------- 색 변환 ---------- */
function hyGrad_isCMYK(doc) { return doc && doc.documentColorSpace == DocumentColorSpace.CMYK; }

function hyGrad_makeColor(doc, rgb) {
  if (hyGrad_isCMYK(doc)) {
    var v = null;
    try { v = app.convertSampleColor(ImageColorSpace.RGB, [rgb[0], rgb[1], rgb[2]], ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose); } catch (e) {}
    if (!v || v.length < 4) {
      var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, k = 1 - Math.max(r, g, b);
      v = k >= 1 ? [0, 0, 0, 100] : [(1 - r - k) / (1 - k) * 100, (1 - g - k) / (1 - k) * 100, (1 - b - k) / (1 - k) * 100, k * 100];
    }
    var c = new CMYKColor(); c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
    return c;
  }
  var o = new RGBColor(); o.red = rgb[0]; o.green = rgb[1]; o.blue = rgb[2];
  return o;
}

function hyGrad_toRGB(col) {
  if (!col) return null;
  var t = col.typename, v;
  if (t == 'RGBColor') return [Math.round(col.red), Math.round(col.green), Math.round(col.blue)];
  if (t == 'CMYKColor') {
    try { v = app.convertSampleColor(ImageColorSpace.CMYK, [col.cyan, col.magenta, col.yellow, col.black], ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose); } catch (e) { v = null; }
    if (!v) { var k = col.black / 100; v = [255 * (1 - col.cyan / 100) * (1 - k), 255 * (1 - col.magenta / 100) * (1 - k), 255 * (1 - col.yellow / 100) * (1 - k)]; }
    return [Math.round(v[0]), Math.round(v[1]), Math.round(v[2])];
  }
  if (t == 'GrayColor') { var g = Math.round(255 * (1 - col.gray / 100)); return [g, g, g]; }
  if (t == 'SpotColor') {
    var base = hyGrad_toRGB(col.spot.color), tint = (col.tint == undefined ? 100 : col.tint) / 100;
    if (!base) return null;
    return [Math.round(255 - (255 - base[0]) * tint), Math.round(255 - (255 - base[1]) * tint), Math.round(255 - (255 - base[2]) * tint)];
  }
  return null;
}

/* 이미 같은 색이면 다시 쓰지 않음 (쓸 때마다 실행 취소 단계가 생기므로) */
function hyGrad_sameColor(a, b) {
  try {
    if (!a || a.typename != b.typename) return false;
    if (a.typename == 'RGBColor') return Math.abs(a.red - b.red) < 0.6 && Math.abs(a.green - b.green) < 0.6 && Math.abs(a.blue - b.blue) < 0.6;
    if (a.typename == 'CMYKColor') return Math.abs(a.cyan - b.cyan) < 0.3 && Math.abs(a.magenta - b.magenta) < 0.3 &&
      Math.abs(a.yellow - b.yellow) < 0.3 && Math.abs(a.black - b.black) < 0.3;
  } catch (e) {}
  return false;
}

/* ---------- 정지점 맞추기 (바뀐 값만 씀) ---------- */
var HYGRAD_TMP = 'hy 임시 ';

function hyGrad_sortedStops(g) {
  var arr = [], gs = g.gradientStops, i;
  for (i = 0; i < gs.length; i++) arr.push({ s: gs[i], p: gs[i].rampPoint, i: i });
  arr.sort(function (a, b) { return a.p - b.p || a.i - b.i; });
  return arr;
}

function hyGrad_sync(doc, g, st) {
  var want = st.type == 'radial' ? GradientType.RADIAL : GradientType.LINEAR;
  if (g.type != want) g.type = want;
  var out = st.out, gs = g.gradientStops, i, pass, arr, ch;
  while (gs.length < out.length) gs.add();
  while (gs.length > out.length) gs[gs.length - 1].remove();
  // 위치: 정렬 순서대로 맞추고, 컬렉션이 다시 정렬돼 어긋나면 한 번 더
  for (pass = 0; pass < 4; pass++) {
    arr = hyGrad_sortedStops(g); ch = false;
    for (i = 0; i < out.length; i++) if (Math.abs(arr[i].p - out[i].p) > 0.01) { arr[i].s.rampPoint = out[i].p; ch = true; }
    if (!ch) break;
  }
  arr = hyGrad_sortedStops(g);
  for (i = 0; i < out.length; i++) if (Math.abs(arr[i].p - out[i].p) > 0.05) return false;
  for (i = 0; i < out.length; i++) {
    var s = arr[i].s, tc = hyGrad_makeColor(doc, out[i].c);
    if (!hyGrad_sameColor(s.color, tc)) s.color = tc;
    try { if (Math.abs(s.opacity - out[i].a) > 0.5) s.opacity = out[i].a; } catch (e) {}
    try { if (Math.abs(s.midPoint - 50) > 0.01) s.midPoint = 50; } catch (e2) {}
  }
  return true;
}

function hyGrad_build(doc, st, name) {
  var g = doc.gradients.add();
  try { g.name = name; } catch (e) {}
  hyGrad_sync(doc, g, st);
  return g;
}

/* ---------- hy Offset 연동 ----------
   hy Offset 그룹(태그 hyOffsetParams, 이름 'hy Offset') 구조: ['링'(링들 + 원본) · '중심선' · '라벨'].
   칠할 단위는 '링' 묶음 안의 보이는 객체만 — 라벨·중심선·숨긴 원본은 건드리지 않는다.
   칠한 방식은 그룹 태그 hyGradPaint(JSON)에 남기고, hy Offset이 링을 다시 만들 때 그대로 다시 칠한다.
     {"v":1,"mode":"grad","target":"fill","grad":"<스와치 이름>","type":"radial","angle":0,"span":true}
     {"v":1,"mode":"dist","target":"fill","order":"size","spacing":"pos","lut":"RRGGBB…(101색)"}
     {"v":1,"mode":"solid","target":"fill","c":"RRGGBB"}
   이 형식을 바꾸면 hy-offset-ai jsx/host.jsx 의 gradRepaint 도 같이 바꿀 것. */
var HYGRAD_OFS_P = 'hyOffsetParams', HYGRAD_PAINT = 'hyGradPaint';

function hyGrad_getTag(it, name) {
  try { var t = it.tags; for (var i = 0; i < t.length; i++) if (t[i].name == name) return t[i].value; } catch (e) {}
  return null;
}
function hyGrad_setTag(it, name, v) {
  var t = it.tags, i;
  for (i = 0; i < t.length; i++) if (t[i].name == name) { if (t[i].value != v) t[i].value = v; return; }
  var n = t.add(); n.name = name; n.value = v;
}
function hyGrad_isOffset(it) {
  try { return it.typename == 'GroupItem' && hyGrad_getTag(it, HYGRAD_OFS_P) !== null; } catch (e) { return false; }
}
function hyGrad_rings(g) {
  var out = [], i, k;
  for (i = 0; i < g.pageItems.length; i++) {
    var rg = g.pageItems[i];
    if (rg.typename != 'GroupItem' || rg.name != '링') continue;
    for (k = 0; k < rg.pageItems.length; k++) { var r = rg.pageItems[k]; if (!hyGrad_hidden(r)) out.push(r); }
    break;
  }
  return out;
}
// 선택한 것이 hy Offset 그룹 자체이거나 그 '링' 묶음이면 그 그룹 (링 일부만 고른 경우는 연동하지 않음)
function hyGrad_offsetOwner(it) {
  try {
    if (hyGrad_isOffset(it)) return it;
    if (it.typename == 'GroupItem' && it.name == '링' && hyGrad_isOffset(it.parent)) return it.parent;
  } catch (e) {}
  return null;
}
function hyGrad_markOffsets(sel, value) {
  var seen = [], n = 0, i, j;
  for (i = 0; i < sel.length; i++) {
    var g = hyGrad_offsetOwner(sel[i]), dup = false;
    if (!g) continue;
    for (j = 0; j < seen.length; j++) if (seen[j] === g) dup = true;
    if (dup) continue;
    seen.push(g);
    try { hyGrad_setTag(g, HYGRAD_PAINT, value); n++; } catch (e) {}
  }
  return n;
}
function hyGrad_hex6(c) { return hyGrad_hex(c).substring(1); }
function hyGrad_hidden(it) { try { return !!it.hidden; } catch (e) { return false; } }

/* ---------- 선택 훑기 ---------- */
// 칠할 단위(패스·복합 패스·텍스트)마다 fn(item). 숨긴 객체는 건너뜀, hy Offset 그룹은 링만
function hyGrad_walk(it, fn) {
  var t = it.typename, i;
  if (hyGrad_hidden(it)) return;
  if (t == 'GroupItem') {
    if (hyGrad_isOffset(it)) { var rs = hyGrad_rings(it); for (i = 0; i < rs.length; i++) hyGrad_walk(rs[i], fn); return; }
    for (i = 0; i < it.pageItems.length; i++) hyGrad_walk(it.pageItems[i], fn);
    return;
  }
  if (t == 'CompoundPathItem') { if (it.pathItems.length) fn(it); return; }
  if (t == 'PathItem' || t == 'TextFrame') fn(it);
}
function hyGrad_walkSel(sel, fn) { for (var i = 0; i < sel.length; i++) hyGrad_walk(sel[i], fn); }

// 단위의 칠·획을 들고 있는 대표(복합 패스는 첫 패스, 텍스트는 글자 속성)
function hyGrad_paintRef(it) {
  if (it.typename == 'CompoundPathItem') return it.pathItems[0];
  if (it.typename == 'TextFrame') { var ca = it.textRange.characterAttributes; return { fillColor: ca.fillColor, strokeColor: ca.strokeColor, filled: true, stroked: true }; }
  return it;
}

/* 선택 객체들이 모두 같은 그라디언트를 쓰고 있으면 그 그라디언트를 돌려줌 */
function hyGrad_sharedGrad(sel, target) {
  var g = null, bad = false, any = false;
  hyGrad_walkSel(sel, function (it) {
    if (bad) return;
    var p = hyGrad_paintRef(it), col = null;
    try { col = target == 'stroke' ? (p.stroked ? p.strokeColor : null) : (p.filled ? p.fillColor : null); } catch (e) {}
    if (!col || col.typename != 'GradientColor') { bad = true; return; }
    any = true;
    if (!g) g = col.gradient; else if (col.gradient.name != g.name) bad = true;
  });
  return bad || !any ? null : g;
}
function hyGrad_isTmp(g) { return g && String(g.name).indexOf(HYGRAD_TMP) === 0; }

/* ---------- 공유 임시 스와치 보호 ----------
   임시 스와치의 정지점을 고치면 그 스와치를 쓰는 객체가 모두 같이 바뀐다. 고르지 않은 객체도 같은 스와치를 쓰고
   있으면(예전에 여러 개를 같이 적용했거나, 칠한 선을 복제한 경우) 그 스와치는 건드리지 않고 고른 것만 새 임시
   스와치로 떼어 낸다. 문서 전체를 훑는 건 선택·스와치·객체 수가 바뀔 때만 하고, 같으면 지난 결과를 쓴다. */
var HYGRAD_EXCL = { key: '', ok: false };
function hyGrad_uid(it) { try { var u = it.uuid; return u === undefined || u === null ? null : String(u); } catch (e) { return null; } }
function hyGrad_selPaths(sel) {
  var out = [];
  hyGrad_walkSel(sel, function (u) {
    if (u.typename == 'CompoundPathItem') { for (var i = 0; i < u.pathItems.length; i++) out.push(u.pathItems[i]); }
    else if (u.typename == 'PathItem') out.push(u);
  });
  return out;
}
function hyGrad_usesGrad(p, name) {
  try { if (p.filled && p.fillColor.typename == 'GradientColor' && p.fillColor.gradient.name == name) return true; } catch (e) {}
  try { if (p.stroked && p.strokeColor.typename == 'GradientColor' && p.strokeColor.gradient.name == name) return true; } catch (e2) {}
  return false;
}
function hyGrad_exclKey(doc, sel, g) {
  var ps = hyGrad_selPaths(sel), ids = [], total = 0, i, id;
  try { total = doc.pathItems.length; } catch (e) {}
  for (i = 0; i < ps.length; i++) { id = hyGrad_uid(ps[i]); ids.push(id === null ? '?' : id); }
  return { key: g.name + '|' + total + '|' + ids.join(','), paths: ps, ids: ids };
}
// 고른 객체만 이 스와치를 쓰면 true
function hyGrad_exclusive(doc, sel, g) {
  var k = hyGrad_exclKey(doc, sel, g), i;
  if (HYGRAD_EXCL.key === k.key) return HYGRAD_EXCL.ok;
  var mine = {}, byCount = false, users = 0, ok = true, all = doc.pathItems;
  for (i = 0; i < k.ids.length; i++) { if (k.ids[i] == '?') byCount = true; else mine[k.ids[i]] = 1; }
  for (i = 0; i < all.length; i++) {
    var p = all[i];
    if (!hyGrad_usesGrad(p, g.name)) continue;
    users++;
    if (!byCount) { var id = hyGrad_uid(p); if (id === null) byCount = true; else if (!mine[id]) { ok = false; break; } }
  }
  if (byCount) ok = users <= k.paths.length;
  HYGRAD_EXCL = { key: k.key, ok: ok };
  return ok;
}
function hyGrad_setExclusive(doc, sel, g) { HYGRAD_EXCL = { key: hyGrad_exclKey(doc, sel, g).key, ok: true }; }

function hyGrad_newName(doc, prefix) {
  prefix = prefix || 'hy Gradient ';
  for (var n = 1; n < 1000; n++) {
    var nm = prefix + n, hit = false;
    try { doc.gradients.getByName(nm); hit = true; } catch (e) {}
    if (!hit) return nm;
  }
  return 'hy Gradient';
}

function hyGrad_gc(g) { var gc = new GradientColor(); gc.gradient = g; return gc; }

/* ---------- 그라디언트 방향 맞추기 ----------
   새 그라디언트를 입히면 일러스트는 선형을 경계 상자 왼쪽 가운데 → 오른쪽 가운데(길이 = 너비)로,
   원형을 가운데 → 반지름 너비/2로 놓는다. 거기서 회전·크기·이동(그라디언트만)으로 원하는 선에 맞춘다.
   U가 있으면(하나로 걸치기) 선택 전체 경계 상자 기준, 없으면 객체마다 자기 경계 상자 기준. */
function hyGrad_union(sel) {
  var u = null;
  for (var i = 0; i < sel.length; i++) {
    var b = sel[i].geometricBounds;
    if (!u) u = [b[0], b[1], b[2], b[3]];
    else { u[0] = Math.min(u[0], b[0]); u[1] = Math.max(u[1], b[1]); u[2] = Math.max(u[2], b[2]); u[3] = Math.min(u[3], b[3]); }
  }
  return u;
}

function hyGrad_fit(it, st, U) {
  if (st.target != 'fill' || it.typename == 'TextFrame') return;
  var lin = st.type != 'radial';
  if (!lin && !U) return;
  var b = it.geometricBounds;
  var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, w = Math.max(b[2] - b[0], 0.01);
  var p0x = lin ? b[0] : cx, p0y = cy, len0 = lin ? w : w / 2;
  var r = U || b, rcx = (r[0] + r[2]) / 2, rcy = (r[1] + r[3]) / 2;
  var rw = Math.max(r[2] - r[0], 0.01), rh = Math.max(r[1] - r[3], 0.01);
  var ang = lin ? (st.angle || 0) : 0, th = ang * Math.PI / 180, ux = Math.cos(th), uy = Math.sin(th);
  var lenD, sx, sy;
  if (lin) { lenD = Math.abs(rw * ux) + Math.abs(rh * uy); sx = rcx - ux * lenD / 2; sy = rcy - uy * lenD / 2; }
  else { lenD = Math.max(rw, rh) / 2; sx = rcx; sy = rcy; }
  if (Math.abs(ang) > 0.01) {
    it.rotate(ang, false, false, true, false, Transformation.CENTER);
    var dx = p0x - cx, dy = p0y - cy;
    p0x = cx + dx * ux - dy * uy; p0y = cy + dx * uy + dy * ux;
  }
  var k = lenD / len0;
  if (Math.abs(k - 1) > 1e-4) {
    it.resize(k * 100, k * 100, false, false, true, false, 100, Transformation.CENTER);
    p0x = cx + (p0x - cx) * k; p0y = cy + (p0y - cy) * k;
  }
  var tx = sx - p0x, ty = sy - p0y;
  if (Math.abs(tx) > 0.01 || Math.abs(ty) > 0.01) it.translate(tx, ty, false, false, true, false);
}

function hyGrad_tag(it, st) {
  try {
    var n = it.note || '';
    if (n === '' || n.indexOf('hyGrad:') === 0) it.note = 'hyGrad:' + st.outN + ':' + st.note;
  } catch (e) {}
}

function hyGrad_paintUnit(it, g, st, U) {
  var i;
  if (it.typename == 'TextFrame') {
    var ca = it.textRange.characterAttributes;
    if (st.target == 'stroke') ca.strokeColor = hyGrad_gc(g); else ca.fillColor = hyGrad_gc(g);
  } else {
    var ps = it.typename == 'CompoundPathItem' ? it.pathItems : [it];
    for (i = 0; i < ps.length; i++) {
      if (st.target == 'stroke') { ps[i].stroked = true; ps[i].strokeColor = hyGrad_gc(g); }
      else { ps[i].filled = true; ps[i].fillColor = hyGrad_gc(g); }
    }
    try { hyGrad_fit(it, st, U); } catch (e) {}
  }
  hyGrad_tag(it, st);
}

/* ---------- 적용 (전체: 새로 입히고 방향까지) ---------- */
function hyGrad_apply(s) {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, st = hyGrad_parse(s), sel = doc.selection;
    var hasSel = sel && sel.length;
    if (!hasSel && !st.keep) return hyGrad_err('적용할 객체를 선택하세요');

    var g = null, reused = false, split = false;
    if (hasSel) {
      var sh = hyGrad_sharedGrad(sel, st.target);
      split = !!(sh && hyGrad_isTmp(sh) && !hyGrad_exclusive(doc, sel, sh));
      // 같은 임시 그라디언트를 쓰는 객체를 다시 편집 → 그 스와치를 고쳐 씀 (스와치가 늘지 않음)
      if (sh && hyGrad_isTmp(sh) && hyGrad_exclusive(doc, sel, sh) && hyGrad_sync(doc, sh, st)) { g = sh; reused = true; }
    }
    if (!g) g = hyGrad_build(doc, st, hyGrad_newName(doc, HYGRAD_TMP));

    var name = '';
    if (st.keep) { name = hyGrad_newName(doc); try { g.name = name; } catch (e1) {} }

    var n = 0, units = [], i2;
    if (hasSel) {
      hyGrad_walkSel(sel, function (it) { units.push(it); });
      var U = st.span && st.target == 'fill' && units.length ? hyGrad_union(units) : null;
      for (i2 = 0; i2 < units.length; i2++) { hyGrad_paintUnit(units[i2], g, st, U); n++; }
      if (n && hyGrad_isTmp(g)) hyGrad_setExclusive(doc, sel, g);
      if (n) hyGrad_markOffsets(sel, '{"v":1,"mode":"grad","target":"' + st.target + '","grad":' + hyGrad_q(g.name) +
        ',"type":"' + (st.type == 'radial' ? 'radial' : 'linear') + '","angle":' + (st.angle || 0) + ',"span":' + !!st.span + '}');
    }
    if (hasSel && !n && !st.keep) return hyGrad_err('패스·복합 패스·텍스트만 적용됩니다');
    return hyGrad_ok('"count":' + n + ',"name":' + hyGrad_q(name) + ',"reused":' + reused + ',"split":' + split + ',"mode":"full"');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* 첫 객체 메모에 남은 적용 방식(종류·대상·각도·걸치기)이 지금과 같은지 */
function hyGrad_keyMatch(sel, st) {
  var n = '';
  hyGrad_walkSel(sel, function (it) { if (n === '') { try { n = it.note || ''; } catch (e) {} if (n === '') n = ' '; } });
  if (n.indexOf('hyGrad:') !== 0) return true;
  function pick(re) { var m = n.match(re); return m ? m[1] : null; }
  var ty = pick(/"type":"(\w+)"/), tg = pick(/"target":"(\w+)"/), an = pick(/"angle":(-?[\d.]+)/), sp = pick(/"span":(true|false)/);
  if (ty && ty != st.type) return false;
  if (tg && tg != st.target) return false;
  if (an !== null && Math.abs(parseFloat(an) - (st.angle || 0)) > 0.01) return false;
  if ((sp == 'true') != !!st.span) return false;
  return true;
}

/* ---------- 갱신 (드래그 중: 공유 임시 스와치의 바뀐 정지점만) ---------- */
function hyGrad_update(s) {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, st = hyGrad_parse(s), sel = doc.selection;
    if (!sel || !sel.length) return hyGrad_err('적용할 객체를 선택하세요');
    var sh = hyGrad_sharedGrad(sel, st.target);
    if (!sh || !hyGrad_isTmp(sh) || !hyGrad_keyMatch(sel, st) || !hyGrad_exclusive(doc, sel, sh)) return hyGrad_apply(s);
    if (!hyGrad_sync(doc, sh, st)) return hyGrad_apply(s);
    var n = 0;
    hyGrad_walkSel(sel, function (it) { n++; if (st.final) hyGrad_tag(it, st); });
    return hyGrad_ok('"count":' + n + ',"mode":"stops"');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 쓰지 않는 임시 스와치 정리 ---------- */
function hyGrad_markUsed(col, used) {
  try { if (col && col.typename == 'GradientColor') used[col.gradient.name] = 1; } catch (e) {}
}
function hyGrad_cleanup() {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, used = {}, i, p;
    for (i = 0; i < doc.pathItems.length; i++) {
      p = doc.pathItems[i];
      if (p.filled) hyGrad_markUsed(p.fillColor, used);
      if (p.stroked) hyGrad_markUsed(p.strokeColor, used);
    }
    for (i = 0; i < doc.textFrames.length; i++) {
      var tr = doc.textFrames[i].textRange;
      for (var k = 0; k < tr.characters.length; k++) {
        var ca = tr.characters[k].characterAttributes;
        hyGrad_markUsed(ca.fillColor, used); hyGrad_markUsed(ca.strokeColor, used);
      }
    }
    var n = 0;
    for (i = doc.gradients.length - 1; i >= 0; i--) {
      var g = doc.gradients[i];
      if (hyGrad_isTmp(g) && !used[g.name]) { try { g.remove(); n++; } catch (e2) {} }
    }
    return hyGrad_ok('"removed":' + n);
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 선택 객체에서 불러오기 ---------- */
function hyGrad_read() {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var sel = app.activeDocument.selection;
    if (!sel || !sel.length) return hyGrad_err('그라디언트를 불러올 객체를 선택하세요');
    var f = null;
    hyGrad_walkSel(sel, function (it) { if (!f) f = it; });
    if (!f) return hyGrad_err('패스·복합 패스·텍스트를 선택하세요');
    var p = hyGrad_paintRef(f), col = null, target = 'fill';
    try { if (p.filled && p.fillColor.typename == 'GradientColor') col = p.fillColor; } catch (e) {}
    if (!col) { try { if (p.stroked && p.strokeColor.typename == 'GradientColor') { col = p.strokeColor; target = 'stroke'; } } catch (e2) {} }
    if (!col) return hyGrad_err('선택한 객체에 그라디언트가 없습니다');
    var gst = col.gradient.gradientStops, i;
    // 이 패널로 만든 그라디언트면 편집 상태(보간·곡선·방향 포함) 그대로 복원
    var note = '';
    try { note = f.note || ''; } catch (e3) {}
    if (note.indexOf('hyGrad:') === 0) {
      var rest = note.substring(7), c = rest.indexOf(':');
      if (c > 0 && parseInt(rest.substring(0, c), 10) == gst.length) return hyGrad_ok('"state":' + rest.substring(c + 1) + ',"target":"' + target + '"');
    }
    var parts = [];
    for (i = 0; i < gst.length; i++) {
      var rgb = hyGrad_toRGB(gst[i].color) || [0, 0, 0], op = 100, mp = 50;
      try { op = Math.round(gst[i].opacity); } catch (e4) {}
      try { mp = Math.round(gst[i].midPoint * 10) / 10; } catch (e6) {}
      parts.push('{"p":' + Math.round(gst[i].rampPoint * 100) / 100 + ',"c":[' + rgb.join(',') + '],"a":' + op + ',"m":' + mp + '}');
    }
    var ang = 0; try { ang = Math.round(col.angle); } catch (e5) {}
    var type = col.gradient.type == GradientType.RADIAL ? 'radial' : 'linear';
    return hyGrad_ok('"raw":{"type":"' + type + '","angle":' + ang + ',"stops":[' + parts.join(',') + ']},"target":"' + target + '"');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 현재 칠 색 (hy Color 등에서 고른 색을 정지점으로) ---------- */
function hyGrad_fill() {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var col = app.activeDocument.defaultFillColor;
    if (col.typename == 'GradientColor') return hyGrad_err('현재 칠이 그라디언트입니다. 단색을 고르세요');
    var rgb = hyGrad_toRGB(col);
    if (!rgb) return hyGrad_err('현재 칠 색이 없습니다');
    return hyGrad_ok('"c":[' + rgb.join(',') + ']');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 일러스트 색상 피커 ---------- */
function hyGrad_pick(s) {
  try {
    var a = hyGrad_parse(s), doc = app.documents.length ? app.activeDocument : null;
    var picked = app.showColorPicker(hyGrad_makeColor(doc, a.c));
    var rgb = hyGrad_toRGB(picked);
    if (!rgb) return hyGrad_err('색을 읽지 못했습니다');
    return hyGrad_ok('"c":[' + rgb.join(',') + ']');
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 단색 칠하기 (단계 색 칩, 객체별 분배) ---------- */
function hyGrad_paintSolid(it, doc, rgb, target) {
  hyGrad_walk(it, function (u) {
    if (u.typename == 'TextFrame') {
      var ca = u.textRange.characterAttributes;
      if (target == 'stroke') ca.strokeColor = hyGrad_makeColor(doc, rgb); else ca.fillColor = hyGrad_makeColor(doc, rgb);
      return;
    }
    var ps = u.typename == 'CompoundPathItem' ? u.pathItems : [u];
    for (var i = 0; i < ps.length; i++) {
      if (target == 'stroke') { ps[i].stroked = true; ps[i].strokeColor = hyGrad_makeColor(doc, rgb); }
      else { ps[i].filled = true; ps[i].fillColor = hyGrad_makeColor(doc, rgb); }
    }
  });
}

function hyGrad_solid(s) {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, a = hyGrad_parse(s), sel = doc.selection;
    if (!sel || !sel.length) return hyGrad_err('칠할 객체를 선택하세요');
    for (var i = 0; i < sel.length; i++) hyGrad_paintSolid(sel[i], doc, a.c, a.target);
    hyGrad_markOffsets(sel, '{"v":1,"mode":"solid","target":"' + a.target + '","c":"' + hyGrad_hex6(a.c) + '"}');
    return hyGrad_ok('"count":' + sel.length);
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* 선택 객체마다 그라디언트에서 색 하나씩. 그룹 하나만 골랐으면 그 안의 객체들끼리 (hy Offset 그룹이면 링끼리) */
function hyGrad_distKeys(units, order) {
  var U = hyGrad_union(units), ucx = (U[0] + U[2]) / 2, ucy = (U[1] + U[3]) / 2, keys = [], i;
  for (i = 0; i < units.length; i++) {
    var b = units[i].geometricBounds, cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, key;
    if (order == 'y') key = -cy;
    else if (order == 'size') key = Math.sqrt(Math.max(0, (b[2] - b[0]) * (b[1] - b[3])));   // 길이 기준 — 동심원이면 반경에 비례
    else if (order == 'radial') key = Math.sqrt((cx - ucx) * (cx - ucx) + (cy - ucy) * (cy - ucy));
    else key = cx;
    keys.push(key);
  }
  if (order == 'radial') {   // 중심이 모두 같으면(동심원) 거리로는 순서가 안 나오므로 크기로
    var mn = keys[0], mx = keys[0];
    for (i = 1; i < keys.length; i++) { mn = Math.min(mn, keys[i]); mx = Math.max(mx, keys[i]); }
    if (mx - mn < 0.5) return hyGrad_distKeys(units, 'size');
  }
  return keys;
}

function hyGrad_distribute(s) {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, a = hyGrad_parse(s), sel = doc.selection, units = [], i;
    if (!sel || !sel.length) return hyGrad_err('색을 나눌 객체를 선택하세요');
    var owner = sel.length == 1 ? hyGrad_offsetOwner(sel[0]) : null;
    if (owner) units = hyGrad_rings(owner);
    else if (sel.length == 1 && sel[0].typename == 'GroupItem') {
      for (i = 0; i < sel[0].pageItems.length; i++) if (!hyGrad_hidden(sel[0].pageItems[i])) units.push(sel[0].pageItems[i]);
    } else for (i = 0; i < sel.length; i++) if (!hyGrad_hidden(sel[i])) units.push(sel[i]);
    if (units.length < 2) return hyGrad_err(owner ? 'hy Offset 링이 두 개 이상 있어야 합니다' : '객체를 두 개 이상 선택하세요 (그룹 하나도 됩니다)');
    var keys = hyGrad_distKeys(units, a.order), list = [];
    for (i = 0; i < units.length; i++) list.push({ it: units[i], k: keys[i], i: i });
    list.sort(function (p, q) { return p.k - q.k || p.i - q.i; });
    var n = list.length, kmin = list[0].k, kmax = list[n - 1].k, L = a.lut.length;
    for (i = 0; i < n; i++) {
      var t = a.spacing == 'pos' && kmax - kmin > 1e-6 ? (list[i].k - kmin) / (kmax - kmin) : i / (n - 1);
      hyGrad_paintSolid(list[i].it, doc, a.lut[Math.round(t * (L - 1))], a.target);
    }
    if (owner) {
      var hex = '';
      for (i = 0; i < L; i++) hex += hyGrad_hex6(a.lut[i]);
      hyGrad_markOffsets(sel, '{"v":1,"mode":"dist","target":"' + a.target + '","order":"' + (a.order || 'x') +
        '","spacing":"' + (a.spacing || 'even') + '","lut":"' + hex + '"}');
    }
    return hyGrad_ok('"count":' + n + ',"offset":' + !!owner);
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}

/* ---------- 단계 색을 스와치 그룹으로 ---------- */
function hyGrad_steps(s) {
  try {
    if (!app.documents.length) return hyGrad_err('열린 문서가 없습니다');
    var doc = app.activeDocument, a = hyGrad_parse(s), base = 'hy 단계 ' + a.colors.length, gname = base, i, k;
    for (k = 2; k < 100; k++) {
      var hit = false;
      for (i = 0; i < doc.swatchGroups.length; i++) if (doc.swatchGroups[i].name == gname) { hit = true; break; }
      if (!hit) break;
      gname = base + ' (' + k + ')';
    }
    var grp = doc.swatchGroups.add();
    grp.name = gname;
    for (i = 0; i < a.colors.length; i++) {
      var sw = doc.swatches.add();
      sw.name = gname + ' · ' + (i + 1) + ' ' + hyGrad_hex(a.colors[i]);
      sw.color = hyGrad_makeColor(doc, a.colors[i]);
      grp.addSwatch(sw);
    }
    return hyGrad_ok('"name":' + hyGrad_q(gname));
  } catch (e) { return hyGrad_err(e.message || String(e)); }
}
