/* hy_color — Illustrator host script (ExtendScript / ES3)
   패널(main.js)에서 evalScript로 호출. JSON 객체가 없으므로 직렬화는 직접 처리. */

function hyc_str(s) {
    return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"')
        .replace(/\r/g, '\\r').replace(/\n/g, '\\n') + '"';
}

function hyc_ser(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') return hyc_str(v);
    var i, out = [];
    if (v instanceof Array) {
        for (i = 0; i < v.length; i++) out.push(hyc_ser(v[i]));
        return '[' + out.join(',') + ']';
    }
    for (var k in v) {
        if (v.hasOwnProperty(k)) out.push(hyc_str(k) + ':' + hyc_ser(v[k]));
    }
    return '{' + out.join(',') + '}';
}

function hyc_r(n) { return Math.round(n * 100) / 100; }

function hyc_hex(rgb) {
    var s = '#';
    for (var i = 0; i < 3; i++) {
        var v = Math.max(0, Math.min(255, Math.round(rgb[i])));
        var h = v.toString(16).toUpperCase();
        if (h.length < 2) h = '0' + h;
        s += h;
    }
    return s;
}

function hyc_hexToRgb(hex) {
    return [parseInt(hex.substr(1, 2), 16), parseInt(hex.substr(3, 2), 16), parseInt(hex.substr(5, 2), 16)];
}

// 문서 색상 설정 기반 변환. 실패하거나 범위를 벗어나면 null
function hyc_toRGB(space, vals) {
    try {
        var o = app.convertSampleColor(space, vals, ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
        if (o && o.length >= 3) {
            for (var i = 0; i < 3; i++) { if (!(o[i] >= 0 && o[i] <= 255)) return null; }
            return [o[0], o[1], o[2]];
        }
    } catch (e) {}
    return null;
}

function hyc_colorObj(c) {
    if (!c) return { t: 'NONE' };
    var v, rgb;
    switch (c.typename) {
        case 'RGBColor':
            v = [hyc_r(c.red), hyc_r(c.green), hyc_r(c.blue)];
            return { t: 'RGB', v: v, hex: hyc_hex(v) };
        case 'CMYKColor':
            v = [hyc_r(c.cyan), hyc_r(c.magenta), hyc_r(c.yellow), hyc_r(c.black)];
            rgb = hyc_toRGB(ImageColorSpace.CMYK, v);
            if (!rgb) { // 단순 변환 폴백
                var k = 1 - v[3] / 100;
                rgb = [255 * (1 - v[0] / 100) * k, 255 * (1 - v[1] / 100) * k, 255 * (1 - v[2] / 100) * k];
            }
            return { t: 'CMYK', v: v, hex: hyc_hex(rgb) };
        case 'GrayColor':
            var g = 255 * (1 - c.gray / 100);
            return { t: 'GRAY', v: [hyc_r(c.gray)], hex: hyc_hex([g, g, g]) };
        case 'LabColor':
            v = [hyc_r(c.l), hyc_r(c.a), hyc_r(c.b)];
            rgb = hyc_toRGB(ImageColorSpace.LAB, v) || [128, 128, 128];
            return { t: 'LAB', v: v, hex: hyc_hex(rgb) };
        case 'SpotColor':
            var base = hyc_colorObj(c.spot.color);
            var tint = hyc_r(c.tint);
            var b = base.hex ? hyc_hexToRgb(base.hex) : [128, 128, 128];
            rgb = [255 - (255 - b[0]) * tint / 100, 255 - (255 - b[1]) * tint / 100, 255 - (255 - b[2]) * tint / 100];
            return { t: 'SPOT', name: c.spot.name, tint: tint, base: base, hex: hyc_hex(rgb) };
        case 'NoColor':
            return { t: 'NONE' };
        default:
            return { t: 'OTHER', kind: c.typename };
    }
}

// 선택 식별값: 같은 선택 상태에서 색이 바뀐 것만 '사용'으로 인정하기 위함
function hyc_selSig(doc) {
    var sel;
    try { sel = doc.selection; } catch (e) { return 'ERR'; }
    if (!sel) return '0';
    if (sel.typename === 'TextRange') {
        var off = 0;
        try { off = sel.characterOffset; } catch (e2) {}
        return 'T:' + off + ':' + sel.length;
    }
    if (!sel.length) return '0';
    var b = '';
    try {
        var gb = sel[0].geometricBounds;
        b = Math.round(gb[0]) + ',' + Math.round(gb[1]) + ',' + Math.round(gb[2]) + ',' + Math.round(gb[3]);
    } catch (e3) {}
    return 'S:' + sel.length + ':' + sel[0].typename + ':' + b;
}

function hyc_getState() {
    try {
        if (app.documents.length === 0) return '{"doc":false}';
        var doc = app.activeDocument;
        return hyc_ser({
            doc: true,
            name: doc.name,
            mode: doc.documentColorSpace == DocumentColorSpace.CMYK ? 'CMYK' : 'RGB',
            sig: hyc_selSig(doc),
            fill: doc.defaultFilled ? hyc_colorObj(doc.defaultFillColor) : { t: 'NONE' },
            stroke: doc.defaultStroked ? hyc_colorObj(doc.defaultStrokeColor) : { t: 'NONE' }
        });
    } catch (e) {
        return hyc_ser({ err: String(e) });
    }
}

function hyc_makeColor(o) {
    var c;
    switch (o.t) {
        case 'RGB':
            c = new RGBColor(); c.red = o.v[0]; c.green = o.v[1]; c.blue = o.v[2]; return c;
        case 'CMYK':
            c = new CMYKColor(); c.cyan = o.v[0]; c.magenta = o.v[1]; c.yellow = o.v[2]; c.black = o.v[3]; return c;
        case 'GRAY':
            c = new GrayColor(); c.gray = o.v[0]; return c;
        case 'LAB':
            c = new LabColor(); c.l = o.v[0]; c.a = o.v[1]; c.b = o.v[2]; return c;
        case 'SPOT':
            var doc = app.activeDocument, sp = null;
            try { sp = doc.spots.getByName(o.name); } catch (e) { sp = null; }
            if (!sp) { // 다른 문서에서 쓴 별색이면 새로 만든다
                sp = doc.spots.add();
                sp.name = o.name;
                sp.colorType = ColorModel.SPOT;
                sp.color = hyc_makeColor(o.base);
            }
            c = new SpotColor(); c.spot = sp; c.tint = o.tint; return c;
    }
    return null;
}

function hyc_paintText(tr, c, stroke) {
    if (stroke) tr.characterAttributes.strokeColor = c;
    else tr.characterAttributes.fillColor = c;
}

function hyc_paint(item, c, stroke) {
    var i, t = item.typename;
    if (t === 'PathItem') {
        if (item.clipping) return;
        if (stroke) { item.stroked = true; item.strokeColor = c; }
        else { item.filled = true; item.fillColor = c; }
    } else if (t === 'CompoundPathItem') {
        for (i = 0; i < item.pathItems.length; i++) hyc_paint(item.pathItems[i], c, stroke);
    } else if (t === 'GroupItem') {
        for (i = 0; i < item.pageItems.length; i++) hyc_paint(item.pageItems[i], c, stroke);
    } else if (t === 'TextFrame') {
        hyc_paintText(item.textRange, c, stroke);
    }
}

function hyc_apply(o, target) {
    try {
        if (app.documents.length === 0) return '{"ok":false,"msg":"열린 문서가 없습니다"}';
        var doc = app.activeDocument;
        var stroke = target === 'stroke';
        var c = hyc_makeColor(o);
        if (!c) return '{"ok":false,"msg":"지원하지 않는 색상 형식입니다"}';

        var sel = doc.selection;
        if (sel && sel.typename === 'TextRange') {
            hyc_paintText(sel, c, stroke);
        } else if (sel && sel.length) {
            for (var i = 0; i < sel.length; i++) hyc_paint(sel[i], c, stroke);
        } else if (stroke) {
            doc.defaultStroked = true; doc.defaultStrokeColor = c;
        } else {
            doc.defaultFilled = true; doc.defaultFillColor = c;
        }
        app.redraw();
        return '{"ok":true}';
    } catch (e) {
        return hyc_ser({ ok: false, msg: String(e) });
    }
}
