/* hy_color — Illustrator 색상 패널 (CEP)
   - 최근 색: 문서의 기본 칠/선을 폴링해서, 같은 선택 상태에서 바뀐 색만 기록
   - 고정 / 그룹 / 레퍼런스 팔레트
   - 데이터는 %APPDATA%\hy_color\*.json (포토샵 패널과 공유 예정) */
(function () {
  'use strict';

  var VERSION = '0.3.2';
  var POLL_MS = 600;       // 상태 확인 주기
  var STABLE_MS = 1200;    // 이 시간 이상 유지된 색만 기록 (피커 드래그 중간색 제외)
  var HISTORY_MAX = 48;
  var PALETTE_MAX = 30;
  var RECORDABLE = { RGB: 1, CMYK: 1, GRAY: 1, LAB: 1, SPOT: 1 };

  var cep = window.__adobe_cep__;
  var nreq = typeof require === 'function' ? require : (window.cep_node && window.cep_node.require);
  var proc = typeof process !== 'undefined' ? process : (window.cep_node && window.cep_node.process);
  var fs = nreq('fs'), path = nreq('path'), os = nreq('os');
  var $ = function (id) { return document.getElementById(id); };

  // =============== 저장소 ===============
  var root = (proc && proc.env && proc.env.APPDATA) || path.join(os.homedir(), 'Library', 'Application Support');
  var DIR = path.join(root, 'hy_color');
  var FILES = {
    history: path.join(DIR, 'history.json'),
    pins: path.join(DIR, 'pins.json'),
    groups: path.join(DIR, 'groups.json'),
    palettes: path.join(DIR, 'palettes.json')
  };
  try { if (!fs.existsSync(DIR)) fs.mkdirSync(DIR); } catch (e) {}

  function load(name) {
    try {
      var d = JSON.parse(fs.readFileSync(FILES[name], 'utf8'));
      if (d && Array.isArray(d.items)) return d.items;
    } catch (e) {}
    return [];
  }

  function save(name, items) {
    var tmp = FILES[name] + '.tmp';
    try {
      fs.writeFileSync(tmp, JSON.stringify({ version: 1, items: items }, null, 2), 'utf8');
      fs.renameSync(tmp, FILES[name]);
    } catch (e) { toast('저장하지 못했습니다: ' + e.message); }
  }

  Object.keys(FILES).forEach(function (n) {
    try { fs.watchFile(FILES[n], { interval: 1500 }, function () { render(); }); } catch (e) {}
  });

  function colorKey(c) {
    if (!c) return 'NONE';
    if (c.t === 'SPOT') return 'SPOT:' + c.name + '@' + c.tint;
    return c.t + ':' + (c.v || []).map(function (n) { return Math.round(n * 100) / 100; }).join(',');
  }

  function makeEntry(c) {
    return { key: colorKey(c), color: c, hex: c.hex, app: 'ILST', time: Date.now() };
  }

  function stripExt(name) { return String(name).replace(/\.[^.]+$/, '') || '그룹'; }

  // ---- 최근 / 고정 ----
  // 매번 디스크에서 새로 읽고 병합 → 다른 앱 패널이 같은 파일을 써도 안전
  function addHistory(c) {
    if (!c || !RECORDABLE[c.t]) return;
    var e = makeEntry(c);
    var items = load('history').filter(function (x) { return x.key !== e.key; });
    items.unshift(e);
    save('history', items.slice(0, HISTORY_MAX));
    render();
  }

  function removeHistory(key) {
    save('history', load('history').filter(function (x) { return x.key !== key; }));
    render();
  }

  function isPinned(key) {
    return load('pins').some(function (p) { return p.key === key; });
  }

  function togglePin(c) {
    if (!c || !RECORDABLE[c.t]) return;
    var key = colorKey(c), items = load('pins'), idx = -1;
    items.forEach(function (p, i) { if (p.key === key) idx = i; });
    if (idx >= 0) { items.splice(idx, 1); toast('고정 해제됨'); }
    else { items.push(makeEntry(c)); toast('고정됨'); }
    save('pins', items);
    render();
  }

  // ---- 그룹 ----
  function slim(e) { return { key: e.key, color: e.color, hex: e.hex }; }

  function nextGroupName(items) {
    var names = {};
    items.forEach(function (g) { names[g.name] = 1; });
    for (var n = items.length + 1; ; n++) if (!names['그룹 ' + n]) return '그룹 ' + n;
  }

  function newGroup(entries, name) {
    var items = load('groups'), seen = {}, colors = [];
    entries.forEach(function (e) { if (!seen[e.key]) { seen[e.key] = 1; colors.push(slim(e)); } });
    var g = { id: 'g' + Date.now(), name: name || nextGroupName(items), time: Date.now(), colors: colors };
    items.unshift(g);
    save('groups', items);
    render();
    return g;
  }

  function updateGroup(id, fn) {
    var items = load('groups');
    items.forEach(function (g) { if (g.id === id) fn(g); });
    save('groups', items);
    render();
  }

  function addToGroup(id, entries) {
    var added = 0;
    updateGroup(id, function (g) {
      var seen = {};
      g.colors.forEach(function (c) { seen[c.key] = 1; });
      entries.forEach(function (e) { if (!seen[e.key]) { seen[e.key] = 1; g.colors.push(slim(e)); added++; } });
    });
    return added;
  }

  function removeFromGroup(id, key) {
    updateGroup(id, function (g) { g.colors = g.colors.filter(function (c) { return c.key !== key; }); });
  }

  function renameGroup(id, name) { updateGroup(id, function (g) { g.name = name; }); }

  function deleteGroup(id) {
    save('groups', load('groups').filter(function (g) { return g.id !== id; }));
    render();
  }

  // =============== 호스트 통신 ===============
  function evalHost(script) {
    return new Promise(function (resolve) { cep.evalScript(script, resolve); });
  }

  function parse(r) {
    try { return JSON.parse(r); } catch (e) { return null; }
  }

  function applyColor(c, target) {
    evalHost('hyc_apply(' + JSON.stringify(c) + ',' + JSON.stringify(target) + ')').then(function (r) {
      var res = parse(r);
      if (res && res.ok) {
        addHistory(c);
        track.sig = null; // 다음 폴링에서 기준 재설정
      } else {
        toast((res && res.msg) || '적용하지 못했습니다');
      }
    });
  }

  function addSwatches(name, colors) {
    evalHost('hyc_addSwatchGroup(' + JSON.stringify(name) + ',' + JSON.stringify(colors) + ')').then(function (r) {
      var res = parse(r);
      if (res && res.ok) toast('견본 그룹 "' + res.name + '"에 추가됨');
      else toast((res && res.msg) || '견본에 추가하지 못했습니다');
    });
  }

  // =============== 사용 색 추적 ===============
  var track = { sig: null, base: { fill: null, stroke: null }, pending: {} };
  var current = null, busy = false, fails = 0;

  // hy Tone(일러스트)이 색을 조정하는 동안에는 '사용 색' 기록을 멈춤
  // → 슬라이더 중간색이 최근 목록(과 포토샵 패널)에 쌓이지 않게. 신호가 끊기고 5초 뒤 다시 기록
  var TONE_HOLD_MS = 5000, toneHoldUntil = 0;
  function toneHold() { return Date.now() < toneHoldUntil; }
  try { cep.addEventListener('com.hy.tone.session', function () { toneHoldUntil = Date.now() + TONE_HOLD_MS; }); } catch (e) {}

  function commitPending() {
    if (!toneHold()) Object.keys(track.pending).forEach(function (w) { addHistory(track.pending[w].color); });
    track.pending = {};
  }

  function handle(s) {
    if (!s || s.err) return;
    if (!s.doc) {
      commitPending();
      track.sig = null;
      current = null;
      renderCurrent();
      setStatus('열린 문서가 없습니다');
      return;
    }
    current = s;
    renderCurrent();
    setStatus(s.name + ' / ' + s.mode);

    var cur = { fill: s.fill, stroke: s.stroke };
    var sig = s.name + '|' + s.sig;

    if (sig !== track.sig) {
      // 선택이 바뀜: 직전까지 바꾸던 색은 확정, 새 선택의 색은 기준으로만 사용
      commitPending();
      track.sig = sig;
      track.base.fill = colorKey(cur.fill);
      track.base.stroke = colorKey(cur.stroke);
      return;
    }

    var now = Date.now();
    ['fill', 'stroke'].forEach(function (w) {
      var k = colorKey(cur[w]);
      if (k === track.base[w]) { delete track.pending[w]; return; }
      var p = track.pending[w];
      if (!p || p.key !== k) { track.pending[w] = { key: k, color: cur[w], since: now }; return; }
      if (now - p.since >= STABLE_MS) {
        if (!toneHold()) addHistory(p.color);
        track.base[w] = k;
        delete track.pending[w];
      }
    });
  }

  function tick() {
    if (busy) return;
    busy = true;
    evalHost('hyc_getState()').then(function (r) {
      busy = false;
      var s = parse(r);
      if (!s) {
        if (++fails > 8) setStatus('일러스트레이터 응답 없음 (대화상자가 열려 있나요?)');
        return;
      }
      fails = 0;
      try { handle(s); } catch (e) { console.error(e); }
    });
  }

  // =============== 선택 모드 ===============
  var selecting = false, selected = {}, selOrder = [];

  function setSelecting(on) {
    selecting = on;
    selected = {};
    selOrder = [];
    document.body.classList.toggle('selecting', on);
    $('selBtn').textContent = on ? '완료' : '선택';
    updateSelUI();
  }

  function toggleSelect(entry) {
    if (selected[entry.key]) {
      delete selected[entry.key];
      selOrder = selOrder.filter(function (k) { return k !== entry.key; });
    } else {
      selected[entry.key] = slim(entry);
      selOrder.push(entry.key);
    }
    updateSelUI();
  }

  function selectedEntries() {
    return selOrder.map(function (k) { return selected[k]; });
  }

  function updateSelUI() {
    Array.prototype.forEach.call(document.querySelectorAll('.chip'), function (el) {
      el.classList.toggle('sel', !!selected[el.dataset.key]);
    });
    var n = selOrder.length;
    $('selCount').textContent = n ? n + '개 선택' : '색을 눌러 고르세요';
    $('newGroupBtn').disabled = !n;
    var sel = $('addToSel');
    sel.disabled = !n;
    sel.innerHTML = '';
    var first = document.createElement('option');
    first.value = '';
    first.textContent = '그룹에 추가';
    sel.appendChild(first);
    load('groups').forEach(function (g) {
      var o = document.createElement('option');
      o.value = g.id;
      o.textContent = g.name;
      sel.appendChild(o);
    });
  }

  // =============== UI 공통 ===============
  function r0(n) { return Math.round(n); }

  function label(c) {
    if (!c) return '';
    var v = c.v || [];
    switch (c.t) {
      case 'RGB': return 'R' + r0(v[0]) + ' G' + r0(v[1]) + ' B' + r0(v[2]);
      case 'CMYK': return 'C' + r0(v[0]) + ' M' + r0(v[1]) + ' Y' + r0(v[2]) + ' K' + r0(v[3]);
      case 'GRAY': return 'K ' + r0(v[0]) + '%';
      case 'LAB': return 'L' + r0(v[0]) + ' a' + r0(v[1]) + ' b' + r0(v[2]);
      case 'SPOT': return c.name + ' ' + r0(c.tint) + '%';
      case 'NONE': return '없음';
    }
    return c.kind || c.t;
  }

  function mk(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  // where: pins | history | group | palette,  ctx: { groupId }
  function chip(entry, where, pinnedKeys, ctx) {
    var el = mk('div', 'chip');
    el.dataset.key = entry.key;
    if (entry.color.t === 'SPOT') el.classList.add('spot');
    if (where !== 'pins' && pinnedKeys[entry.key]) el.classList.add('pinned');
    el.style.background = entry.hex || '#888';
    el.title = label(entry.color) + '   ' + (entry.hex || '');
    el.appendChild(mk('i', 'chk'));
    el.addEventListener('click', function (ev) {
      if (selecting) { toggleSelect(entry); return; }
      if (ev.ctrlKey || ev.metaKey) { togglePin(entry.color); return; }
      applyColor(entry.color, ev.shiftKey ? 'stroke' : 'fill');
    });
    el.addEventListener('contextmenu', function (ev) {
      ev.preventDefault();
      if (!selecting) openChipMenu(ev, entry, where, ctx || {});
    });
    return el;
  }

  function fillGrid(el, items, where, pinnedKeys, emptyText) {
    el.innerHTML = '';
    if (!items.length) { el.appendChild(mk('div', 'empty', emptyText)); return; }
    items.forEach(function (it) { el.appendChild(chip(it, where, pinnedKeys)); });
  }

  // 그룹·팔레트 공통 카드
  function card(opts) {
    var c = mk('div', 'pal');
    if (opts.dataId) c.dataset.gid = opts.dataId;
    var head = mk('div', 'pal-head');
    if (opts.thumb) {
      var img = mk('img', 'pal-thumb');
      img.src = opts.thumb;
      head.appendChild(img);
    }
    var nm = mk('div', 'pal-name', opts.name);
    nm.title = opts.name + ' (' + opts.entries.length + '색)';
    if (opts.onRename) nm.addEventListener('dblclick', function () { startRename(opts.dataId, nm); });
    head.appendChild(nm);
    var more = mk('button', 'link more', '···');
    more.title = '메뉴';
    more.addEventListener('click', function (ev) { showMenu(ev, opts.menu()); });
    head.appendChild(more);
    c.appendChild(head);

    if (opts.ratios) {
      var bar = mk('div', 'pal-bar');
      opts.entries.forEach(function (e, i) {
        var seg = mk('span');
        seg.style.flex = String(Math.max(opts.ratios[i], 0.01));
        seg.style.background = e.hex;
        bar.appendChild(seg);
      });
      c.appendChild(bar);
    }

    var grid = mk('div', 'grid');
    if (!opts.entries.length) grid.appendChild(mk('div', 'empty', '비어 있음'));
    opts.entries.forEach(function (e, i) {
      var ch = chip(e, opts.where, opts.keys, { groupId: opts.dataId });
      if (opts.ratios) ch.title += '   ' + Math.round(opts.ratios[i] * 100) + '%';
      grid.appendChild(ch);
    });
    c.appendChild(grid);
    return c;
  }

  function renderGroups(keys) {
    var box = $('groups');
    box.innerHTML = '';
    var groups = load('groups');
    $('groupCount').textContent = groups.length ? groups.length : '';
    if (!groups.length) {
      box.appendChild(mk('div', 'empty', '위의 선택 버튼으로 색을 골라 그룹을 만드세요'));
      return;
    }
    groups.forEach(function (g) {
      box.appendChild(card({
        dataId: g.id,
        name: g.name,
        entries: g.colors,
        where: 'group',
        keys: keys,
        onRename: true,
        menu: function () {
          return [
            ['견본 그룹으로 추가', function () { addSwatches(g.name, g.colors.map(function (c) { return c.color; })); }],
            ['이름 바꾸기', function () { startRename(g.id); }],
            ['그룹 삭제', function () { deleteGroup(g.id); toast('"' + g.name + '" 삭제됨'); }]
          ];
        }
      }));
    });
  }

  function renderPalettes(keys) {
    var box = $('palettes');
    box.innerHTML = '';
    var pals = load('palettes');
    if (!pals.length) {
      box.appendChild(mk('div', 'empty', '레퍼런스 이미지를 패널에 끌어다 놓거나 위 버튼으로 불러오세요'));
      return;
    }
    pals.forEach(function (p) {
      var entries = p.colors.map(function (c) { return makeEntry(c.color); });
      box.appendChild(card({
        dataId: p.id,
        name: p.name,
        thumb: p.thumb,
        entries: entries,
        ratios: p.colors.map(function (c) { return c.ratio; }),
        where: 'palette',
        keys: keys,
        menu: function () {
          return [
            ['그룹으로 저장', function () {
              var g = newGroup(entries, stripExt(p.name));
              toast('"' + g.name + '" 그룹으로 저장됨');
            }],
            ['견본 그룹으로 추가', function () { addSwatches(p.name, entries.map(function (e) { return e.color; })); }],
            ['팔레트 삭제', function () { removePalette(p.id); }]
          ];
        }
      }));
    });
  }

  // 이름 바꾸는 중에는 다시 그리지 않음 (입력창 유지)
  var renaming = false, renderQueued = false;

  function render() {
    if (renaming) { renderQueued = true; return; }
    var pins = load('pins'), hist = load('history'), keys = {};
    pins.forEach(function (p) { keys[p.key] = 1; });
    fillGrid($('pins'), pins, 'pins', keys, 'Ctrl+클릭으로 자주 쓰는 색을 고정하세요');
    fillGrid($('history'), hist, 'history', keys, '색을 칠하면 여기에 쌓입니다');
    $('pinCount').textContent = pins.length ? pins.length : '';
    renderGroups(keys);
    renderPalettes(keys);
    lastHl = '';
    updateHighlight();
    updateSelUI();
  }

  function startRename(id, nameEl) {
    nameEl = nameEl || document.querySelector('[data-gid="' + id + '"] .pal-name');
    if (!nameEl) return;
    var g = load('groups').filter(function (x) { return x.id === id; })[0];
    if (!g) return;
    renaming = true;
    var inp = mk('input', 'rename');
    inp.value = g.name;
    nameEl.parentNode.replaceChild(inp, nameEl);
    inp.focus();
    inp.select();
    var done = false;
    function finish(ok) {
      if (done) return;
      done = true;
      renaming = false;
      var v = inp.value.trim();
      if (ok && v && v !== g.name) renameGroup(id, v);
      else render();
    }
    inp.addEventListener('keydown', function (e) {
      e.stopPropagation();
      if (e.key === 'Enter') finish(true);
      else if (e.key === 'Escape') finish(false);
    });
    inp.addEventListener('blur', function () { finish(true); });
  }

  // 현재 칠/선과 같은 색 칩에 테두리 표시 (칠: 실선 링, 선: 점선 링)
  var lastHl = '';
  function updateHighlight() {
    var fk = current && RECORDABLE[current.fill.t] ? colorKey(current.fill) : null;
    var sk = current && RECORDABLE[current.stroke.t] ? colorKey(current.stroke) : null;
    var first = null;
    Array.prototype.forEach.call(document.querySelectorAll('.chip'), function (el) {
      var f = el.dataset.key === fk, s = el.dataset.key === sk;
      el.classList.toggle('hl-fill', f);
      el.classList.toggle('hl-stroke', s);
      if ((f || s) && !first) first = el;
    });
    var hl = fk + '|' + sk;
    if (hl !== lastHl) {
      lastHl = hl;
      if (first && first.scrollIntoViewIfNeeded) first.scrollIntoViewIfNeeded(false);
    }
  }

  function paintCurrent(el, c) {
    var ok = c && RECORDABLE[c.t];
    el.classList.toggle('none', !ok);
    el.style.setProperty('--c', ok ? c.hex : 'transparent');
    el.title = c ? label(c) + (ok ? '   ' + c.hex + '\n클릭하면 고정' : '') : '';
  }

  function renderCurrent() {
    paintCurrent($('curFill'), current && current.fill);
    paintCurrent($('curStroke'), current && current.stroke);
    updateHighlight();
  }

  function setStatus(t) { $('status').textContent = t; }

  var toastTimer = null;
  function toast(t) {
    var el = $('toast');
    el.textContent = t;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 1600);
  }

  function copy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); toast(text + ' 복사됨'); } catch (e) { toast('복사하지 못했습니다'); }
    document.body.removeChild(ta);
  }

  // =============== 메뉴 ===============
  function closeMenu() { $('menu').hidden = true; }

  function showMenu(ev, items) {
    var m = $('menu');
    m.innerHTML = '';
    items.forEach(function (it) {
      if (!it) { m.appendChild(mk('hr')); return; }
      var b = mk('button', null, it[0]);
      b.addEventListener('click', function () { closeMenu(); it[1](); });
      m.appendChild(b);
    });
    m.hidden = false;
    var w = m.offsetWidth, h = m.offsetHeight;
    m.style.left = Math.max(4, Math.min(ev.clientX, window.innerWidth - w - 4)) + 'px';
    m.style.top = Math.max(4, Math.min(ev.clientY, window.innerHeight - h - 4)) + 'px';
  }

  function openChipMenu(ev, entry, where, ctx) {
    var items = [
      ['칠에 적용', function () { applyColor(entry.color, 'fill'); }],
      ['선에 적용', function () { applyColor(entry.color, 'stroke'); }],
      [isPinned(entry.key) ? '고정 해제' : '고정', function () { togglePin(entry.color); }],
      [entry.hex + ' 복사', function () { copy(entry.hex); }]
    ];
    var groups = load('groups').filter(function (g) { return g.id !== ctx.groupId; });
    if (groups.length) {
      items.push(null);
      groups.slice(0, 6).forEach(function (g) {
        items.push(['"' + g.name + '"에 추가', function () {
          if (addToGroup(g.id, [entry])) toast('"' + g.name + '"에 추가됨');
          else toast('이미 들어 있는 색입니다');
        }]);
      });
    }
    if (where === 'history' || where === 'group') items.push(null);
    if (where === 'history') items.push(['기록에서 삭제', function () { removeHistory(entry.key); }]);
    if (where === 'group') items.push(['그룹에서 빼기', function () { removeFromGroup(ctx.groupId, entry.key); }]);
    showMenu(ev, items);
  }

  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('mousedown', function (e) { if (!$('menu').contains(e.target)) closeMenu(); });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!$('menu').hidden) closeMenu();
    else if (selecting) setSelecting(false);
  });

  // =============== 팔레트 추출 ===============
  var MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp' };
  var lastSource = null; // 색 수를 바꾸면 마지막 이미지를 다시 추출

  function getK() {
    var k = NaN;
    try { k = parseInt(localStorage.getItem('hyc.k'), 10); } catch (e) {}
    return k >= 3 && k <= 12 ? k : 6;
  }

  function loadImage(src) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = function () { reject(new Error('이미지를 읽지 못했습니다')); };
      img.src = src;
    });
  }

  function toCanvas(img, maxSide, bg) {
    var s = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    var cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(img.naturalWidth * s));
    cv.height = Math.max(1, Math.round(img.naturalHeight * s));
    var ctx = cv.getContext('2d');
    if (bg) { ctx.fillStyle = bg; ctx.fillRect(0, 0, cv.width, cv.height); }
    ctx.drawImage(img, 0, 0, cv.width, cv.height);
    return cv;
  }

  function extractPalette(src, name, id) {
    if (!window.HyPalette) {
      toast('js 폴더에 palette.js가 없어 추출할 수 없습니다');
      return Promise.resolve();
    }
    toast('팔레트 추출 중…');
    return loadImage(src).then(function (img) {
      var cv = toCanvas(img, 200);
      var data = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
      var k = getK();
      var res = window.HyPalette.extract(data, k);
      if (!res.length) throw new Error('불투명한 픽셀이 없습니다');
      var pal = {
        id: id || 'p' + Date.now(),
        name: name,
        time: Date.now(),
        k: k,
        thumb: toCanvas(img, 96, '#ffffff').toDataURL('image/jpeg', 0.75),
        colors: res.map(function (c) {
          return { color: { t: 'RGB', v: c.rgb, hex: c.hex }, ratio: Math.round(c.ratio * 1000) / 1000 };
        })
      };
      var items = load('palettes').filter(function (x) { return x.id !== pal.id; });
      items.unshift(pal);
      save('palettes', items.slice(0, PALETTE_MAX));
      lastSource = { src: src, name: name, id: pal.id };
      render();
      toast(pal.colors.length + '색 추출됨');
    }).catch(function (e) { toast(e.message); });
  }

  function fromPath(p, name, cleanup) {
    var ext = path.extname(p).slice(1).toLowerCase();
    if (!MIME[ext]) { toast('jpg, png, gif, webp, bmp만 열 수 있습니다'); return; }
    var url;
    try { url = 'data:' + MIME[ext] + ';base64,' + fs.readFileSync(p).toString('base64'); }
    catch (e) { toast('파일을 읽지 못했습니다'); return; }
    if (cleanup) { try { fs.unlinkSync(p); } catch (e2) {} }
    extractPalette(url, name || path.basename(p));
  }

  function fromFile(file, fallbackName) {
    if (!file) return;
    if (file.type && file.type.indexOf('image/') !== 0) { toast('이미지 파일이 아닙니다'); return; }
    var r = new FileReader();
    r.onload = function () { extractPalette(r.result, file.name || fallbackName || '이미지'); };
    r.onerror = function () { toast('파일을 읽지 못했습니다'); };
    r.readAsDataURL(file);
  }

  function openImage() {
    var fsx = window.cep && window.cep.fs;
    if (fsx && (fsx.showOpenDialogEx || fsx.showOpenDialog)) {
      try {
        var args = [false, false, '레퍼런스 이미지 선택', '', Object.keys(MIME)];
        var r = fsx.showOpenDialogEx ? fsx.showOpenDialogEx.apply(fsx, args) : fsx.showOpenDialog.apply(fsx, args);
        if (r && r.data && r.data.length) fromPath(r.data[0]);
        return;
      } catch (e) {}
    }
    $('fileInput').click();
  }

  function fromSelection() {
    toast('선택 영역 캡처 중…');
    evalHost('hyc_captureSelection()').then(function (r) {
      var res = parse(r);
      if (!res || !res.ok) { toast((res && res.msg) || '캡처하지 못했습니다'); return; }
      fromPath(res.path, res.name, true);
    });
  }

  function removePalette(id) {
    save('palettes', load('palettes').filter(function (x) { return x.id !== id; }));
    if (lastSource && lastSource.id === id) lastSource = null;
    render();
  }

  // =============== 이벤트 연결 ===============
  ['curFill', 'curStroke'].forEach(function (id) {
    $(id).addEventListener('click', function () {
      if (!current) return;
      togglePin(id === 'curFill' ? current.fill : current.stroke);
    });
  });

  $('selBtn').addEventListener('click', function () { setSelecting(!selecting); });

  $('newGroupBtn').addEventListener('click', function () {
    var entries = selectedEntries();
    if (!entries.length) return;
    var g = newGroup(entries);
    setSelecting(false);
    startRename(g.id); // 바로 이름 입력
  });

  $('addToSel').addEventListener('change', function () {
    var id = this.value;
    if (!id) return;
    var g = load('groups').filter(function (x) { return x.id === id; })[0];
    var n = addToGroup(id, selectedEntries());
    toast(g ? '"' + g.name + '"에 ' + n + '색 추가됨' : '추가됨');
    setSelecting(false);
  });

  // 비우기: 두 번 눌러야 실행
  var clearArmed = null;
  $('clearBtn').addEventListener('click', function () {
    var b = $('clearBtn');
    if (clearArmed) {
      clearTimeout(clearArmed); clearArmed = null;
      b.textContent = '비우기'; b.classList.remove('danger');
      save('history', []); render();
      return;
    }
    b.textContent = '한 번 더 누르면 비움';
    b.classList.add('danger');
    clearArmed = setTimeout(function () {
      clearArmed = null; b.textContent = '비우기'; b.classList.remove('danger');
    }, 2500);
  });

  $('openBtn').addEventListener('click', openImage);
  $('capBtn').addEventListener('click', fromSelection);
  $('fileInput').addEventListener('change', function () {
    fromFile(this.files && this.files[0]);
    this.value = '';
  });

  $('kSel').value = String(getK());
  $('kSel').addEventListener('change', function () {
    try { localStorage.setItem('hyc.k', this.value); } catch (e) {}
    if (lastSource) extractPalette(lastSource.src, lastSource.name, lastSource.id);
  });

  // 드래그 앤 드롭
  var dragDepth = 0;
  document.addEventListener('dragenter', function (e) {
    e.preventDefault(); dragDepth++; document.body.classList.add('dropping');
  });
  document.addEventListener('dragleave', function () {
    if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove('dropping'); }
  });
  document.addEventListener('dragover', function (e) { e.preventDefault(); });
  document.addEventListener('drop', function (e) {
    e.preventDefault();
    dragDepth = 0;
    document.body.classList.remove('dropping');
    var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) fromFile(f);
  });

  // 붙여넣기 (클립보드 이미지)
  document.addEventListener('paste', function (e) {
    if (renaming) return;
    var items = e.clipboardData && e.clipboardData.items;
    if (!items) return;
    for (var i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image/') === 0) {
        e.preventDefault();
        fromFile(items[i].getAsFile(), '붙여넣은 이미지');
        return;
      }
    }
  });

  // =============== 테마 ===============
  function applyTheme() {
    try {
      var env = JSON.parse(cep.getHostEnvironment());
      var c = env.appSkinInfo.panelBackgroundColor.color;
      var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
      document.documentElement.style.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
      document.documentElement.dataset.theme = (0.299 * r + 0.587 * g + 0.114 * b) < 128 ? 'dark' : 'light';
    } catch (e) {}
  }
  try { cep.addEventListener('com.adobe.csxs.events.ThemeColorChanged', applyTheme); } catch (e) {}

  $('ver').textContent = 'v' + VERSION;
  applyTheme();
  render();
  tick();
  setInterval(tick, POLL_MS);
})();
