/* hy_color — 이미지 팔레트 추출 (LAB 색공간 k-means++)
   window.HyPalette.extract(rgbaData, k) → [{ rgb:[r,g,b], hex, ratio }] (비율 내림차순) */
(function (root) {
  'use strict';

  function lin(c) { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function f(t) { return t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116; }

  function rgbToLab(r, g, b) {
    var R = lin(r), G = lin(g), B = lin(b);
    var x = (R * 0.4124 + G * 0.3576 + B * 0.1805) / 0.95047;
    var y = (R * 0.2126 + G * 0.7152 + B * 0.0722);
    var z = (R * 0.0193 + G * 0.1192 + B * 0.9505) / 1.08883;
    var fx = f(x), fy = f(y), fz = f(z);
    return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
  }

  function hex(rgb) {
    return '#' + rgb.map(function (v) {
      var h = Math.max(0, Math.min(255, Math.round(v))).toString(16).toUpperCase();
      return h.length < 2 ? '0' + h : h;
    }).join('');
  }

  // 결과가 매번 같도록 고정 시드 난수
  function rng(seed) {
    var s = seed >>> 0;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  }

  var MERGE_DE = 7; // 이 거리(ΔE76) 안의 군집은 같은 색으로 합침

  function extract(data, k) {
    var L = [], A = [], B = [], R = [], G = [], Bl = [];
    for (var p = 0; p < data.length; p += 4) {
      if (data[p + 3] < 128) continue; // 투명 픽셀 제외
      var lab = rgbToLab(data[p], data[p + 1], data[p + 2]);
      L.push(lab[0]); A.push(lab[1]); B.push(lab[2]);
      R.push(data[p]); G.push(data[p + 1]); Bl.push(data[p + 2]);
    }
    var m = L.length;
    if (!m) return [];
    k = Math.max(1, Math.min(k, m));

    // k-means++ 초기화
    var rand = rng(20260922);
    var cL = [], cA = [], cB = [];
    var i0 = Math.floor(rand() * m);
    cL.push(L[i0]); cA.push(A[i0]); cB.push(B[i0]);
    var d = new Float64Array(m).fill(Infinity);
    var i, j;
    while (cL.length < k) {
      var last = cL.length - 1, sum = 0;
      for (i = 0; i < m; i++) {
        var dl = L[i] - cL[last], da = A[i] - cA[last], db = B[i] - cB[last];
        var dd = dl * dl + da * da + db * db;
        if (dd < d[i]) d[i] = dd;
        sum += d[i];
      }
      if (sum === 0) break; // 남은 색이 모두 동일
      var t = rand() * sum, pick = m - 1;
      for (i = 0; i < m; i++) { t -= d[i]; if (t <= 0) { pick = i; break; } }
      cL.push(L[pick]); cA.push(A[pick]); cB.push(B[pick]);
    }
    k = cL.length;

    // 반복
    var asg = new Int32Array(m).fill(-1);
    var cnt = new Float64Array(k), sL = new Float64Array(k), sA = new Float64Array(k), sB = new Float64Array(k);
    for (var iter = 0; iter < 24; iter++) {
      var changed = 0;
      for (i = 0; i < m; i++) {
        var best = 0, bd = Infinity;
        for (j = 0; j < k; j++) {
          var el = L[i] - cL[j], ea = A[i] - cA[j], eb = B[i] - cB[j];
          var e = el * el + ea * ea + eb * eb;
          if (e < bd) { bd = e; best = j; }
        }
        if (asg[i] !== best) { asg[i] = best; changed++; }
      }
      if (!changed) break;
      cnt.fill(0); sL.fill(0); sA.fill(0); sB.fill(0);
      for (i = 0; i < m; i++) { j = asg[i]; cnt[j]++; sL[j] += L[i]; sA[j] += A[i]; sB[j] += B[i]; }
      for (j = 0; j < k; j++) if (cnt[j]) { cL[j] = sL[j] / cnt[j]; cA[j] = sA[j] / cnt[j]; cB[j] = sB[j] / cnt[j]; }
    }

    // 군집별 대표색 = 구성 픽셀의 평균 RGB
    var cl = [];
    for (j = 0; j < k; j++) cl.push({ n: 0, r: 0, g: 0, b: 0, lab: [cL[j], cA[j], cB[j]] });
    for (i = 0; i < m; i++) { var c = cl[asg[i]]; c.n++; c.r += R[i]; c.g += G[i]; c.b += Bl[i]; }
    cl = cl.filter(function (c) { return c.n > 0; }).sort(function (a, b) { return b.n - a.n; });

    // 거의 같은 색 합치기
    var out = [];
    cl.forEach(function (c) {
      for (var q = 0; q < out.length; q++) {
        var o = out[q], x = o.lab[0] - c.lab[0], y = o.lab[1] - c.lab[1], z = o.lab[2] - c.lab[2];
        if (Math.sqrt(x * x + y * y + z * z) < MERGE_DE) {
          var n = o.n + c.n;
          o.lab = [(o.lab[0] * o.n + c.lab[0] * c.n) / n, (o.lab[1] * o.n + c.lab[1] * c.n) / n, (o.lab[2] * o.n + c.lab[2] * c.n) / n];
          o.r += c.r; o.g += c.g; o.b += c.b; o.n = n;
          return;
        }
      }
      out.push(c);
    });

    return out.sort(function (a, b) { return b.n - a.n; }).map(function (c) {
      var rgb = [Math.round(c.r / c.n), Math.round(c.g / c.n), Math.round(c.b / c.n)];
      return { rgb: rgb, hex: hex(rgb), ratio: c.n / m };
    });
  }

  root.HyPalette = { extract: extract, rgbToLab: rgbToLab };
})(typeof window !== 'undefined' ? window : globalThis);
