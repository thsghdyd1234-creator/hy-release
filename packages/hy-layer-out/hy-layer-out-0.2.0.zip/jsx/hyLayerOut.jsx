/*
 * hy Layer Out - host script (ExtendScript, ES3)
 * 레이어·클립 그룹 안의 항목(건물·도로·등고선 …)을 하나씩 최상위 레이어로 꺼낸다.
 * (예전 hy_clip_to_layers.jsx v5 를 다듬은 것)
 *
 *  - 대상: 선택한 오브젝트가 든 레이어·클립 그룹(가까운 곳부터) + 문서의 나머지 레이어·클립 그룹
 *  - 감싸기: 항목이 클립 그룹 하나·이름 없는 그룹 하나뿐이면 안으로 파고든다
 *      레이어 1 › <클립 그룹> › <그룹> › 건물, 축척 … → 건물, 축척 … 이 레이어가 된다
 *  - 클리핑: keep(레이어마다 마스크 복제) / prune(keep + 영역 밖 개체 삭제) / release(해제, 마스크 모양은 '클립 영역' 레이어에)
 *    대상을 감싼 클립 그룹이 여럿이면 모두 다시 씌운다
 *  - 꺼낸 그룹은 풀어서 레이어에 바로 넣는다 (레이어 '건물' › 건물 안의 것들). 그룹 자체에 불투명도·혼합 모드가 있으면 그룹째
 *  - 내용이 남은 레이어·그룹은 절대 지우지 않는다. 하위 레이어는 건드리지 않는다.
 *  - 실행 취소가 여러 번으로 쪼개지지 않게 app.redraw·메뉴 명령은 쓰지 않는다
 *    (클리핑이 스크립트 방식으로 안 될 때만 Ctrl+7 메뉴로 다시 시도)
 *
 * 패널과 주고받는 값은 JSON 문자열.
 */

var HYLO_T = [];            // 마지막으로 읽은 대상들 (실행할 때 다시 찾는 데 씀)
var HYLO_MAXDRILL = 8;      // 감싸기를 파고드는 깊이
var HYLO_MAXT = 60;         // 대상 목록 길이
var HYLO_MAXITEMS = 300;    // 패널에 이름을 보내는 항목 수
var HYLO_SCANKIDS = 400;    // 레이어마다 클립 그룹 후보를 찾을 때 보는 항목 수

/* ---------------- JSON (ES3 에는 JSON 이 없음) ---------------- */

function hyLO_str(s) {
  s = String(s);
  var out = '"';
  for (var i = 0; i < s.length; i++) {
    var c = s.charAt(i), code = s.charCodeAt(i);
    if (c === '"') out += '\\"';
    else if (c === '\\') out += '\\\\';
    else if (code < 32) out += '\\u' + ('0000' + code.toString(16)).slice(-4);
    else out += c;
  }
  return out + '"';
}

function hyLO_json(v) {
  if (v === null || v === undefined) return 'null';
  var t = typeof v;
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') return hyLO_str(v);
  var i, a = [];
  if (v instanceof Array) {
    for (i = 0; i < v.length; i++) a.push(hyLO_json(v[i]));
    return '[' + a.join(',') + ']';
  }
  for (var k in v) {
    if (v.hasOwnProperty(k)) a.push(hyLO_str(k) + ':' + hyLO_json(v[k]));
  }
  return '{' + a.join(',') + '}';
}

function hyLO_parse(s) {
  try {
    var o = eval('(' + s + ')');
    if (o && typeof o === 'object') return o;
  } catch (e) {}
  return null;
}

function hyLO_ok(o) { o.ok = true; return hyLO_json(o); }
function hyLO_fail(msg) { return hyLO_json({ ok: false, err: msg }); }

/* ---------------- 아트 트리 ---------------- */

function hyLO_type(o) { try { return o.typename; } catch (e) { return ''; } }
function hyLO_isLayer(o) { return hyLO_type(o) === 'Layer'; }
function hyLO_isGroup(o) { return hyLO_type(o) === 'GroupItem'; }
function hyLO_isClip(o) {
  try { return o.typename === 'GroupItem' && o.clipped === true; } catch (e) { return false; }
}
function hyLO_isPlain(o) { return hyLO_isGroup(o) && !hyLO_isClip(o); }

function hyLO_isMask(o) {
  try {
    if (o.typename === 'PathItem') return o.clipping === true;
    if (o.typename === 'CompoundPathItem') return o.pathItems.length > 0 && o.pathItems[0].clipping === true;
  } catch (e) {}
  return false;
}

function hyLO_setClipping(o, v) {
  try {
    if (o.typename === 'PathItem') o.clipping = v;
    else if (o.typename === 'CompoundPathItem' && o.pathItems.length) o.pathItems[0].clipping = v;
  } catch (e) {}
}

function hyLO_kids(c, max) {
  var a = [], n = 0;
  try { n = c.pageItems.length; } catch (e) { return a; }
  if (max && n > max) n = max;
  for (var i = 0; i < n; i++) a.push(c.pageItems[i]);
  return a;
}

function hyLO_masks(g) {
  var m = [], k = hyLO_kids(g);
  for (var i = 0; i < k.length; i++) if (hyLO_isMask(k[i])) m.push(k[i]);
  return m;
}

// 꺼낼 항목: 클리핑 마스크는 뺀다 (하위 레이어는 pageItems 에 없음)
function hyLO_items(c) {
  var clip = hyLO_isClip(c), a = [], k = hyLO_kids(c);
  for (var i = 0; i < k.length; i++) {
    if (clip && hyLO_isMask(k[i])) continue;
    a.push(k[i]);
  }
  return a;
}

function hyLO_isEmpty(c) {
  try {
    if (c.pageItems.length) return false;
    if (hyLO_isLayer(c) && c.layers.length) return false;
    return true;
  } catch (e) { return false; }
}

function hyLO_named(o) {
  var n = '';
  try { n = o.name; } catch (e) {}
  return n ? String(n) : '';
}

// o 에서 위로: o, 부모, …, 최상위 레이어
function hyLO_up(o) {
  var a = [], p = o;
  while (p && hyLO_type(p) !== 'Document' && hyLO_type(p) !== '' && a.length < 64) {
    a.push(p);
    try { p = p.parent; } catch (e) { break; }
  }
  return a;
}

function hyLO_nodeName(n) {
  if (hyLO_isLayer(n)) return hyLO_named(n) || '레이어';
  return hyLO_named(n) || (hyLO_isClip(n) ? '<클립 그룹>' : '<그룹>');
}

function hyLO_typeKo(o) {
  switch (hyLO_type(o)) {
    case 'GroupItem': return hyLO_isClip(o) ? '클립 그룹' : '그룹';
    case 'PathItem': return '패스';
    case 'CompoundPathItem': return '컴파운드 패스';
    case 'PlacedItem':
    case 'RasterItem': return '이미지';
    case 'TextFrame': return '텍스트';
    case 'SymbolItem': return '심볼';
    default: return '오브젝트';
  }
}

/* ---------------- 대상 찾기 ---------------- */

function hyLO_resolve(root) {
  var t = { root: root, inner: root, items: hyLO_items(root) };
  // 항목이 클립 그룹 하나 또는 이름 없는 그룹 하나뿐이면 안으로
  for (var d = 0; d < HYLO_MAXDRILL && t.items.length === 1; d++) {
    var only = t.items[0];
    if (!hyLO_isGroup(only)) break;
    if (!hyLO_isClip(only) && hyLO_named(only)) break;
    t.inner = only;
    t.items = hyLO_items(only);
  }
  // 레이어가 될 만한 것: 이름 있는 그룹 수 (기본 대상 고르기·문서 목록 거르기에 씀)
  t.namedGroups = 0;
  t.groups = 0;
  t.named = 0;
  for (var g = 0; g < t.items.length && g < HYLO_SCANKIDS; g++) {
    var isG = hyLO_isGroup(t.items[g]), nm = !!hyLO_named(t.items[g]);
    if (isG) t.groups++;
    if (nm) t.named++;
    if (isG && nm) t.namedGroups++;
  }
  var up = hyLO_up(t.inner);
  t.clip = 0;
  t.parts = [];
  for (var i = up.length - 1; i >= 0; i--) {
    if (hyLO_isClip(up[i])) t.clip++;
    t.parts.push(hyLO_nodeName(up[i]));
  }
  t.key = t.parts.join(' › ') + ' #' + t.items.length;
  return t;
}

function hyLO_selection(doc) {
  var out = [];
  try {
    var sel = doc.selection;
    if (sel && sel.length) {
      for (var i = 0; i < sel.length; i++) {
        var tn = hyLO_type(sel[i]);
        if (tn && tn !== 'TextRange' && tn !== 'InsertionPoint') out.push(sel[i]);
      }
    }
  } catch (e) {}
  return out;
}

// 선택한 것이 대상의 어느 항목 안에 있는지 표시
function hyLO_markSelected(t, sel) {
  var flags = [], i, j;
  for (i = 0; i < t.items.length; i++) flags.push(false);
  for (j = 0; j < sel.length && j < 5000; j++) {
    var p = sel[j], k = 0;
    while (p && k < 64) {
      var par = null;
      try { par = p.parent; } catch (e) { break; }
      if (!par || hyLO_type(par) === 'Document') break;
      if (par == t.inner) {
        for (i = 0; i < t.items.length; i++) if (t.items[i] == p) { flags[i] = true; break; }
        break;
      }
      p = par;
      k++;
    }
  }
  return flags;
}

function hyLO_collect(doc, sel) {
  var list = [];
  // min: 항목이 이보다 적은 곳은 뺀다. strict: 문서 목록에서는 패스만 잔뜩 든 곳(이미 꺼낸 레이어 등)도 뺀다
  function add(root, min, strict) {
    if (!root || list.length >= HYLO_MAXT) return;
    var t = hyLO_resolve(root);
    if (t.items.length < (min || 1)) return;
    if (strict && !t.groups && t.named < 2) return;
    for (var i = 0; i < list.length; i++) if (list[i].inner == t.inner) return;   // 같은 곳으로 파고드는 후보는 하나만
    list.push(t);
  }
  var fromSel = false;
  if (sel.length) {
    var up = [];
    try { up = hyLO_up(sel[0].parent); } catch (e) {}
    for (var i = 0; i < up.length; i++) if (hyLO_isLayer(up[i]) || hyLO_isClip(up[i])) add(up[i]);
    fromSel = list.length > 0;
  }
  var nSel = list.length;
  function walk(layers, min) {
    for (var i = 0; i < layers.length && list.length < HYLO_MAXT; i++) {
      var L = layers[i];
      add(L, min, min > 1);
      var k = hyLO_kids(L, HYLO_SCANKIDS);
      for (var j = 0; j < k.length; j++) if (hyLO_isClip(k[j])) add(k[j], min, min > 1);
      try { if (L.layers.length) walk(L.layers, min); } catch (e) {}
    }
  }
  walk(doc.layers, 2);
  if (!list.length) walk(doc.layers, 1);     // 한 항목짜리밖에 없으면 그것이라도

  // 경로·항목 수가 같은 후보가 또 있으면 순번을 붙여 실행할 때 헷갈리지 않게
  for (var u = 1; u < list.length; u++) {
    var same = 1;
    for (var v = 0; v < u; v++) if (list[v].key.split(' ~')[0] === list[u].key) same++;
    if (same > 1) list[u].key += ' ~' + same;
  }

  // 선택이 없으면: 이름 있는 그룹이 많은 곳 → 클립 그룹 안 → 항목 많은 곳
  // (꺼낸 뒤의 '건물' 레이어처럼 패스만 많은 곳이 먼저 잡혀 수백 개 레이어가 생기지 않게)
  var def = 0;
  if (!fromSel) {
    for (var b = 1; b < list.length; b++) {
      var x = list[b], y = list[def];
      if (x.namedGroups !== y.namedGroups) { if (x.namedGroups > y.namedGroups) def = b; continue; }
      if ((x.clip > 0) !== (y.clip > 0)) { if (x.clip > 0) def = b; continue; }
      if (x.items.length > y.items.length) def = b;
    }
  }
  return { list: list, def: def, fromSel: fromSel, nSel: nSel };
}

// 패널: 대상 목록
function hyLO_scan() {
  try {
    if (!app.documents.length) return hyLO_ok({ doc: '', targets: [] });
    var doc = app.activeDocument;
    var sel = hyLO_selection(doc);
    var c = hyLO_collect(doc, sel);
    HYLO_T = c.list;
    var out = [];
    for (var i = 0; i < c.list.length; i++) {
      var t = c.list[i];
      var flags = sel.length ? hyLO_markSelected(t, sel) : [];
      var nsel = 0, items = [];
      for (var j = 0; j < t.items.length; j++) {
        if (flags[j]) nsel++;
        if (j < HYLO_MAXITEMS) items.push({ n: hyLO_named(t.items[j]), t: hyLO_typeKo(t.items[j]), s: !!flags[j] });
      }
      out.push({ key: t.key, parts: t.parts, count: t.items.length, clip: t.clip, sel: nsel,
                 fromSel: i < c.nSel, items: items });
    }
    return hyLO_ok({ doc: doc.name, targets: out, def: c.def, fromSel: c.fromSel });
  } catch (e) {
    return hyLO_fail('읽기 실패: ' + e.message);
  }
}

// 패널: 선택·문서가 바뀌었는지 가볍게 보기 (바뀌면 패널이 hyLO_scan 을 다시 부름)
function hyLO_sig() {
  try {
    if (!app.documents.length) return '';
    var d = app.activeDocument, s = d.name + '|' + d.layers.length;
    var sel = d.selection;
    s += '|' + (sel ? sel.length : 0);
    if (sel && sel.length) {
      var p = sel[0], k = 0;
      while (p && k < 20 && hyLO_type(p) !== 'Document' && hyLO_type(p) !== '') {
        s += '|' + hyLO_type(p) + ':' + hyLO_named(p);
        try { p = p.parent; } catch (e) { break; }
        k++;
      }
    }
    return s;
  } catch (e) { return 'x'; }
}

/* ---------------- 실행 ---------------- */

function hyLO_box(o, geometric) {
  try {
    var b = geometric ? o.geometricBounds : o.visibleBounds;     // [왼, 위, 오른, 아래]
    return { x0: Math.min(b[0], b[2]), x1: Math.max(b[0], b[2]), y0: Math.min(b[1], b[3]), y1: Math.max(b[1], b[3]) };
  } catch (e) { return null; }
}

function hyLO_overlaps(a, b) {
  return !(a.x1 < b.x0 || a.x0 > b.x1 || a.y1 < b.y0 || a.y0 > b.y1);
}

function hyLO_Runner(doc, opt) {
  this.doc = doc;
  this.opt = opt;
  this.saved = [];
  this.warn = [];
  this.moved = 0;
  this.clipNeeded = 0;
  this.clipped = 0;
  this.menuClip = 0;
  this.pruned = 0;
  this.unnamed = 0;
  this.area = null;
  this.areaKept = false;
  this.levels = [];
  this.box = null;
  this.first = null;
}

hyLO_Runner.prototype.set = function (o, k, v) {
  try {
    if (o[k] === v) return;
    this.saved.push({ o: o, k: k, v: o[k] });
    o[k] = v;
  } catch (e) {}
};

hyLO_Runner.prototype.unlock = function (o) {
  if (hyLO_isLayer(o)) {
    this.set(o, 'locked', false);
    this.set(o, 'visible', true);
  } else {
    this.set(o, 'locked', false);
    this.set(o, 'hidden', false);
  }
};

hyLO_Runner.prototype.restore = function () {
  for (var i = this.saved.length - 1; i >= 0; i--) {
    try { this.saved[i].o[this.saved[i].k] = this.saved[i].v; } catch (e) {}   // 지운 것은 건너뜀
  }
};

hyLO_Runner.prototype.removeIfEmpty = function (lay) {
  try { if (hyLO_isEmpty(lay)) lay.remove(); } catch (e) {}
};

hyLO_Runner.prototype.dispose = function (o) {
  try { o.locked = false; } catch (e) {}
  try { o.remove(); return true; } catch (e) { return false; }
};

hyLO_Runner.prototype.computeBox = function () {
  var all = null;
  for (var l = 0; l < this.levels.length; l++) {
    var lv = null;
    for (var m = 0; m < this.levels[l].length; m++) {
      var b = hyLO_box(this.levels[l][m], true);
      if (!b) continue;
      if (!lv) lv = b;
      else lv = { x0: Math.min(lv.x0, b.x0), x1: Math.max(lv.x1, b.x1), y0: Math.min(lv.y0, b.y0), y1: Math.max(lv.y1, b.y1) };
    }
    if (!lv) continue;
    if (!all) all = lv;
    else all = { x0: Math.max(all.x0, lv.x0), x1: Math.min(all.x1, lv.x1), y0: Math.max(all.y0, lv.y0), y1: Math.min(all.y1, lv.y1) };
  }
  if (!all) { this.warn.push('마스크 크기를 읽지 못해 영역 밖 삭제를 건너뜀'); return; }
  if (all.x0 > all.x1 || all.y0 > all.y1) { this.warn.push('클립 영역끼리 겹치지 않아 영역 밖 삭제를 건너뜀'); return; }
  this.box = all;
};

hyLO_Runner.prototype.outside = function (o) {
  var b = hyLO_box(o, false);
  if (!b) return false;              // 크기를 못 읽으면 남긴다
  return !hyLO_overlaps(b, this.box);
};

// 그룹 안을 돌며 영역 밖 개체를 지운다. 빈 그룹도 지운다. 클립 그룹·컴파운드 패스는 한 덩어리
hyLO_Runner.prototype.prune = function (g, depth) {
  if (depth > 64 || !hyLO_isPlain(g)) return 0;
  var n = 0, k = hyLO_kids(g);
  for (var i = 0; i < k.length; i++) {
    if (this.outside(k[i])) {
      if (this.dispose(k[i])) n++;
    } else if (hyLO_isPlain(k[i])) {
      n += this.prune(k[i], depth + 1);
      if (hyLO_isEmpty(k[i])) this.dispose(k[i]);
    }
  }
  return n;
};

// contents(같은 부모, 위 → 아래)를 새 클립 그룹에 넣고 마스크 사본을 맨 위에 둔다 (스크립트 방식, 실행 취소 한 번에 묶임)
hyLO_Runner.prototype.clipOnce = function (contents, masks) {
  var g = null, moved = [], c;
  try {
    g = contents[0].parent.groupItems.add();
    g.move(contents[0], ElementPlacement.PLACEBEFORE);
    for (c = 0; c < contents.length; c++) {
      var r = contents[c].move(g, ElementPlacement.PLACEATEND);
      moved.push(r || contents[c]);
    }
    for (var i = masks.length - 1; i >= 0; i--) {
      var d = masks[i].duplicate(g, ElementPlacement.PLACEATBEGINNING);
      try { d.locked = false; d.hidden = false; } catch (e1) {}
      hyLO_setClipping(d, true);
    }
    g.clipped = true;
    if (hyLO_isClip(g) && g.pageItems.length > masks.length && hyLO_isMask(g.pageItems[0])) return g;
  } catch (e) {}
  // 안 됐으면 원래대로: 내용을 그룹 밖(원래 순서)으로 빼고 그룹(마스크 사본)을 지운다
  if (g) {
    try {
      var left = false;
      for (c = 0; c < moved.length; c++) {
        try { if (moved[c].parent == g) moved[c].move(g, ElementPlacement.PLACEBEFORE); } catch (e3) {}
        try { if (moved[c].parent == g) left = true; } catch (e4) {}
      }
      if (!left) g.remove();
      else g.clipped = false;     // 못 뺀 것이 있으면 그룹째 둔다 (내용은 지우지 않음)
    } catch (e2) {}
  }
  return null;
};

// 스크립트 방식이 안 될 때: 마스크 사본과 내용을 선택하고 Ctrl+7 (이 경우 실행 취소가 나뉠 수 있음)
hyLO_Runner.prototype.clipMenu = function (contents, masks) {
  var dup = null;
  try {
    dup = masks[0].duplicate(contents[0], ElementPlacement.PLACEBEFORE);   // Ctrl+7 은 맨 위 하나만 마스크로 쓴다
    try { dup.locked = false; dup.hidden = false; } catch (e1) {}
    hyLO_setClipping(dup, false);
    this.doc.selection = null;
    dup.selected = true;
    for (var c = 0; c < contents.length; c++) contents[c].selected = true;
    app.executeMenuCommand('makeMask');
    this.doc.selection = null;
    var p = contents[0].parent;
    if (hyLO_isClip(p)) { this.menuClip++; return p; }
  } catch (e) {}
  try { this.doc.selection = null; } catch (e3) {}
  if (dup) { try { if (!hyLO_isClip(dup.parent)) dup.remove(); } catch (e2) {} }
  return null;
};

// 클립 그룹에는 이름을 붙이지 않는다 — 레이어가 이미 그 이름이라 '건물 › 건물 › 건물'처럼 겹쳐 보인다
hyLO_Runner.prototype.clipAll = function (contents) {
  var cur = contents;
  for (var l = 0; l < this.levels.length; l++) {
    var g = this.clipOnce(cur, this.levels[l]) || this.clipMenu(cur, this.levels[l]);
    if (!g) return false;
    cur = [g];
  }
  return true;
};

// 꺼낸 그룹을 풀어서 안의 것들을 레이어에 바로 둔다. 풀린 것들(위 → 아래)을 돌려주고, 못 풀면 null.
// 안의 잠긴 것은 클리핑까지 끝낸 뒤 되돌리려고 relock 에 모아 둔다
hyLO_Runner.prototype.dissolve = function (g, name, relock) {
  var kids = hyLO_kids(g);
  if (!kids.length) return null;                      // 빈 그룹은 그대로
  try {
    if (g.opacity < 99.99 || (typeof BlendModes !== 'undefined' && g.blendingMode !== BlendModes.NORMAL)) {
      this.warn.push("'" + name + "' 그룹에 불투명도·혼합 모드가 있어서 그룹째 넣음");
      return null;
    }
  } catch (e) { return null; }
  var out = [];
  for (var i = 0; i < kids.length; i++) {
    var k = kids[i];
    try { if (k.locked) { k.locked = false; relock.push(k); } } catch (e1) {}
    try {
      var r = k.move(g, ElementPlacement.PLACEBEFORE);   // 그룹 바로 위로, 차례대로 → 순서 그대로
      out.push(r || k);
    } catch (e2) {}
  }
  if (hyLO_isEmpty(g)) this.dispose(g);
  else { out.push(g); this.warn.push("'" + name + "' 안의 일부를 그룹 밖으로 못 꺼냄 (그룹째 남김)"); }
  return out;
};

// 해제 모드: 마스크 모양을 '클립 영역' 레이어에 보통 패스로 남긴다
hyLO_Runner.prototype.keepArea = function (masks, anchor) {
  if (!masks.length) return;
  try {
    if (!this.area) {
      this.area = this.doc.layers.add();
      this.area.name = '클립 영역';
      this.area.move(anchor, ElementPlacement.PLACEBEFORE);
    }
    for (var i = masks.length - 1; i >= 0; i--) {
      var d = masks[i].duplicate(this.area, ElementPlacement.PLACEATBEGINNING);
      hyLO_setClipping(d, false);
      try { d.locked = false; d.hidden = false; } catch (e1) {}
      this.areaKept = true;
    }
  } catch (e) {
    this.warn.push("'클립 영역' 레이어를 만들지 못함");
  }
};

// 빈 껍데기 정리: 안쪽부터 위로, 빈 것만. 내용이 남은 곳에서 멈춘다
hyLO_Runner.prototype.cleanup = function (up) {
  for (var i = 0; i < up.length; i++) {
    var n = up[i], label = hyLO_nodeName(n);
    try {
      if (hyLO_isLayer(n)) {
        if (!this.opt.removeEmpty || !hyLO_isEmpty(n)) return;
        n.remove();
      } else if (hyLO_isClip(n)) {
        if (hyLO_items(n).length) return;
        if (this.opt.clip === 'release') this.keepArea(hyLO_masks(n), up[up.length - 1]);
        if (!this.dispose(n)) { this.warn.push('비워진 ' + label + ' 을(를) 지우지 못함'); return; }
      } else {
        if (!hyLO_isEmpty(n)) return;
        if (!this.dispose(n)) { this.warn.push('비워진 ' + label + ' 을(를) 지우지 못함'); return; }
      }
    } catch (e) {
      this.warn.push(label + ' 정리 오류: ' + e.message);
      return;
    }
  }
};

hyLO_Runner.prototype.go = function (t, skip) {
  var doc = this.doc, opt = this.opt, i;
  var items = [];
  for (i = 0; i < t.items.length; i++) if (!skip[i]) items.push(t.items[i]);
  if (!items.length) { this.warn.push('꺼낼 항목이 없음'); return; }

  var up = hyLO_up(t.inner);
  var anchor = up[up.length - 1];
  if (!hyLO_isLayer(anchor)) { this.warn.push('대상이 든 레이어를 찾지 못함'); return; }

  // 감싸고 있던 클립 그룹의 마스크 (안 → 바깥)
  for (i = 0; i < up.length; i++) {
    if (!hyLO_isClip(up[i])) continue;
    var m = hyLO_masks(up[i]);
    if (m.length) this.levels.push(m);
  }
  var hadClip = this.levels.length > 0;
  var keepClip = hadClip && opt.clip !== 'release';
  var prune = hadClip && opt.clip === 'prune';

  // 잠금·숨김 잠시 풀기 (끝나면 되돌림)
  for (i = 0; i < up.length; i++) this.unlock(up[i]);
  for (var l = 0; l < this.levels.length; l++)
    for (var k = 0; k < this.levels[l].length; k++) this.unlock(this.levels[l][k]);

  if (prune) this.computeBox();

  for (i = 0; i < items.length; i++) {
    var item = items[i];
    var name = hyLO_named(item), named = !!name;
    if (!named) { this.unnamed++; name = '<' + hyLO_typeKo(item) + ' ' + this.unnamed + '>'; }

    var lay;
    try {
      lay = doc.layers.add();
      lay.name = name;
      lay.move(anchor, ElementPlacement.PLACEBEFORE);    // 원래 레이어 바로 위, 위 → 아래 순서 유지
    } catch (e) {
      this.warn.push("'" + name + "' 레이어를 만들지 못함");
      continue;
    }

    var wasLocked = false, wasHidden = false;
    try { wasLocked = item.locked; wasHidden = item.hidden; item.locked = false; item.hidden = false; } catch (e1) {}
    try {
      var r = item.move(lay, ElementPlacement.PLACEATEND);
      if (r) item = r;
    } catch (e2) {
      try { item.locked = wasLocked; item.hidden = wasHidden; } catch (e3) {}
      this.removeIfEmpty(lay);
      this.warn.push("'" + name + "' 옮기기 실패: " + e2.message);
      continue;
    }

    if (prune && this.box) {
      var gone = false;
      if (this.outside(item)) {
        if (this.dispose(item)) { this.pruned++; gone = true; }
      } else {
        this.pruned += this.prune(item, 0);
        // 테두리끼리는 영역에 걸쳤어도 안의 것이 모두 밖이었으면 빈 그룹만 남는다
        if (hyLO_isPlain(item) && hyLO_isEmpty(item) && this.dispose(item)) gone = true;
      }
      if (gone) {
        this.removeIfEmpty(lay);
        this.warn.push("'" + name + "' 전체가 영역 밖이라 지움 (레이어 안 만듦)");
        continue;
      }
    }

    this.moved++;
    if (!this.first) this.first = lay;

    // 그룹은 풀어서 레이어에 바로 (레이어가 그 그룹이 된다)
    var contents = [item], relock = [], flat = null;
    if (opt.flatten && hyLO_isPlain(item)) flat = this.dissolve(item, name, relock);
    if (flat) contents = flat;

    if (keepClip) {
      this.clipNeeded++;
      if (this.clipAll(contents)) this.clipped++;
      else this.warn.push("'" + name + "' 클리핑 실패 (항목은 꺼냄)");
    }
    for (var q = 0; q < relock.length; q++) { try { relock[q].locked = true; } catch (e5) {} }
    if (flat) {
      // 그룹의 숨김·잠금은 레이어가 이어받는다
      try { if (wasHidden) lay.visible = false; if (wasLocked) lay.locked = true; } catch (e6) {}
      if (wasHidden && this.first === lay) this.first = null;
    } else {
      try { item.locked = wasLocked; item.hidden = wasHidden; } catch (e4) {}
    }
  }

  this.cleanup(up);
  this.restore();
  try { doc.selection = null; } catch (e5) {}
  try { if (this.first) doc.activeLayer = this.first; } catch (e6) {}
  this.hadClip = hadClip;
};

// 패널: 실행. a = { key, skip:[항목 번호…], clip:'keep'|'prune'|'release', removeEmpty:bool, flatten:bool }
function hyLO_run(argJson) {
  try {
    if (!app.documents.length) return hyLO_fail('열린 문서가 없습니다');
    var a = hyLO_parse(argJson);
    if (!a) return hyLO_fail('잘못된 요청');
    var doc = app.activeDocument;

    // 읽은 뒤 문서가 바뀌었을 수 있어서 다시 찾는다 (경로·항목 수가 같은 곳)
    var c = hyLO_collect(doc, hyLO_selection(doc));
    HYLO_T = c.list;
    var t = null;
    for (var i = 0; i < c.list.length; i++) if (c.list[i].key === a.key) { t = c.list[i]; break; }
    if (!t) return hyLO_fail('문서가 바뀌어서 대상을 다시 찾지 못했어요. 새로고침 후 다시 해 주세요');

    var skip = {};
    if (a.skip) for (var s = 0; s < a.skip.length; s++) skip[a.skip[s]] = true;

    var run = new hyLO_Runner(doc, { clip: a.clip || 'keep', removeEmpty: a.removeEmpty !== false, flatten: a.flatten !== false });
    run.go(t, skip);
    return hyLO_ok({
      moved: run.moved, clipNeeded: run.clipNeeded, clipped: run.clipped, menuClip: run.menuClip,
      pruned: run.pruned, hadClip: !!run.hadClip, areaKept: run.areaKept, warnings: run.warn
    });
  } catch (e) {
    return hyLO_fail('실행 중 오류: ' + e.message + (e.line ? ' (' + e.line + '줄)' : ''));
  }
}
