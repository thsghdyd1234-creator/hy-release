/* hy Layer Out - panel */
(function () {
  'use strict';

  var cs = new CSInterface();
  var SHOW_TARGETS = 6;        // 꺼낼 곳 목록을 이만큼 보여 주고 나머지는 '더 보기'
  var CONFIRM_OVER = 60;       // 이보다 많이 꺼내면 한 번 더 눌러 확인

  var CLIP_NOTE = {
    keep: '레이어마다 마스크를 복제해 씌워요. 보이던 그대로, 데이터는 다 남아요.',
    prune: '마스크와 전혀 안 겹치는 개체는 지우고, 걸친 것은 남겨서 가려요. 파일이 가벼워져요.',
    release: "클리핑을 풀어 모두 드러내요. 마스크 모양은 '클립 영역' 레이어에 남겨요."
  };

  var state = {
    data: null,          // hyLO_scan 결과
    key: null,           // 지금 고른 대상
    manual: false,       // 사용자가 목록에서 직접 골랐는지
    skip: {},            // 대상 key → { 항목 번호: true }
    showAll: false,
    clip: load('hyLayerOut.clip', 'keep'),
    removeEmpty: load('hyLayerOut.removeEmpty', '1') === '1',
    flatten: load('hyLayerOut.flatten', '1') === '1',
    sig: null,
    busy: false,
    confirmUntil: 0,
    lastRead: 0
  };

  var $ = function (id) { return document.getElementById(id); };

  /* ---------------- 유틸 ---------------- */

  function load(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function store(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function call(fn, args, cb) {
    var script = fn + '(' + args.map(function (a) { return JSON.stringify(a); }).join(',') + ')';
    cs.evalScript(script, function (res) {
      var d;
      try { d = JSON.parse(res); } catch (e) { d = { ok: false, err: res || '응답이 없습니다' }; }
      cb(d);
    });
  }

  function setStatus(msg, isErr) {
    $('status').textContent = msg || '';
    $('status').className = 'status' + (isErr ? ' err' : '');
  }

  function current() {
    var d = state.data;
    if (!d || !d.targets) return null;
    for (var i = 0; i < d.targets.length; i++) if (d.targets[i].key === state.key) return d.targets[i];
    return null;
  }

  function skipOf(t) {
    if (!state.skip[t.key]) {
      // 대상 안에서 몇 개만 골라 두었으면 그것만, 아니면 전부
      var s = {};
      if (t.sel > 0 && t.sel < t.count) t.items.forEach(function (it, i) { if (!it.s) s[i] = true; });
      state.skip[t.key] = s;
    }
    return state.skip[t.key];
  }

  function chosenCount(t) {
    var s = skipOf(t), n = 0;
    for (var i = 0; i < t.count; i++) if (!s[i]) n++;
    return n;
  }

  /* ---------------- 테마 ---------------- */

  function applyTheme() {
    try {
      var c = cs.getHostEnvironment().appSkinInfo.panelBackgroundColor.color;
      var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
      var root = document.documentElement;
      root.style.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
      var lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      root.setAttribute('data-theme', lum > 0.5 ? 'light' : 'dark');
      var p = lum > 0.5 ? Math.min(255, r + 12) : Math.min(255, r + 14);
      root.style.setProperty('--pop', 'rgb(' + p + ',' + Math.min(255, g + (p - r)) + ',' + Math.min(255, b + (p - r)) + ')');
    } catch (e) {}
  }

  /* ---------------- 읽기 ---------------- */

  function refresh(followSelection) {
    if (state.busy) return;
    state.lastRead = Date.now();
    call('hyLO_scan', [], function (d) {
      if (!d.ok) { setStatus(d.err || '읽기 실패', true); return; }
      var prevKey = state.key;
      state.data = d;
      var keep = !followSelection && state.manual && current();
      if (!keep) {
        state.manual = false;
        state.key = d.targets && d.targets.length ? d.targets[d.def || 0].key : null;
      }
      if (state.key !== prevKey) state.showAll = false;
      render();
    });
  }

  // 일러스트에서 선택·문서가 바뀌면 다시 읽고 선택을 따라간다
  var polling = false;
  function poll() {
    if (polling || state.busy) return;
    polling = true;
    cs.evalScript('hyLO_sig()', function (sig) {
      polling = false;
      if (sig === state.sig) return;
      var first = state.sig === null;
      state.sig = sig;
      if (!first) {
        state.skip = {};
        refresh(true);
      }
    });
  }

  /* ---------------- 그리기 ---------------- */

  function render() {
    var d = state.data;
    var empty = !d || !d.doc || !d.targets || !d.targets.length;
    $('docName').textContent = d && d.doc ? d.doc : '—';
    $('main').hidden = empty;
    $('emptyMsg').hidden = !empty;
    if (empty) {
      $('emptyMsg').textContent = !d || !d.doc ? '열린 문서가 없어요' : '꺼낼 항목이 든 레이어나 클립 그룹이 없어요';
      return;
    }
    var t = current();
    renderTargets(d, t);
    renderItems(t);
    renderClip(t);
    renderRun(t);
  }

  function renderTargets(d, t) {
    var list = d.targets, n = state.showAll ? list.length : Math.min(list.length, SHOW_TARGETS);
    // 고른 것이 접힌 쪽에 있으면 펼친다
    for (var k = n; k < list.length; k++) if (list[k].key === state.key) { n = list.length; break; }
    $('targetHint').innerHTML = d.fromSel ? '<span class="dot-in"></span>선택한 오브젝트가 든 곳' : '선택이 없어 문서에서 골랐어요';
    var html = '';
    for (var i = 0; i < n; i++) {
      var x = list[i];
      var pre = x.parts.slice(0, -1).join(' › ');
      html += '<div class="trow' + (x.key === state.key ? ' on' : '') + (x.fromSel ? ' fromsel' : '') + '" data-key="' + esc(x.key) + '">' +
        '<span class="pin"></span>' +
        '<span class="path">' + (pre ? '<span class="pre">' + esc(pre) + ' ›</span>' : '') +
        '<span class="last">' + esc(x.parts[x.parts.length - 1]) + '</span></span>' +
        '<span class="tags">' + (x.clip ? '<span class="tag clip">클립' + (x.clip > 1 ? ' ' + x.clip : '') + '</span>' : '') +
        (x.sel ? '<span class="tag sel">선택 ' + x.sel + '</span>' : '') +
        '<span class="tag">' + x.count + '</span></span></div>';
    }
    $('targetList').innerHTML = html;
    var more = $('moreBtn');
    more.hidden = list.length <= SHOW_TARGETS;
    more.textContent = n < list.length ? '더 보기 (' + (list.length - n) + ')' : '접기';
  }

  function renderItems(t) {
    var chips = $('itemChips'), note = $('itemNote');
    if (!t) { chips.innerHTML = ''; return; }
    var s = skipOf(t), n = chosenCount(t);
    $('itemCount').textContent = n + ' / ' + t.count;
    $('qSel').disabled = !(t.sel > 0);
    var html = '', unnamed = 0;
    for (var i = 0; i < t.items.length; i++) {
      var it = t.items[i], off = !!s[i];
      var label = it.n;
      if (!label) label = off ? '<' + it.t + '>' : '<' + it.t + ' ' + (++unnamed) + '>';
      html += '<button class="chip' + (off ? ' off' : '') + (it.n ? '' : ' auto') + (it.s ? ' sel' : '') + '" data-i="' + i + '"' +
        ' title="' + esc(label + ' · ' + it.t) + '"><span class="dot"></span><span class="nm">' + esc(label) + '</span></button>';
    }
    chips.innerHTML = html;
    if (t.count > t.items.length) {
      note.hidden = false;
      note.className = 'note warn';
      note.textContent = '항목이 ' + t.count + '개라 앞의 ' + t.items.length + '개만 보여요. 나머지는 전부 꺼냅니다.';
    } else if (t.sel > 0 && t.sel < t.count) {
      note.hidden = false;
      note.className = 'note';
      note.textContent = '선택한 ' + t.sel + '개만 켜 두었어요. 칩을 눌러 켜고 끌 수 있어요.';
    } else note.hidden = true;
  }

  function renderClip(t) {
    var has = t && t.clip > 0;
    $('clipBlock').hidden = !has;          // 클립 그룹 안이 아니면 고를 것이 없다
    $('clipLevels').textContent = has && t.clip > 1 ? '클립 ' + t.clip + '겹 — 모두 다시 씌움' : '';
    Array.prototype.forEach.call(document.querySelectorAll('#clipSeg button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-clip') === state.clip);
    });
    $('clipNote').textContent = has ? CLIP_NOTE[state.clip] : '';
    $('removeSwitch').classList.toggle('on', state.removeEmpty);
    $('flattenSwitch').classList.toggle('on', state.flatten);
  }

  function renderRun(t) {
    var b = $('runBtn');
    var n = t ? chosenCount(t) : 0;
    var confirming = Date.now() < state.confirmUntil;
    b.disabled = !n || state.busy;
    b.classList.toggle('confirm', confirming);
    b.textContent = !n ? '꺼낼 항목을 골라 주세요'
      : confirming ? '레이어 ' + n + '개가 생겨요 — 한 번 더 누르면 실행'
      : '레이어 ' + n + '개로 꺼내기';
  }

  /* ---------------- 실행 ---------------- */

  function runNow() {
    var t = current();
    if (!t || state.busy) return;
    var n = chosenCount(t);
    if (n > CONFIRM_OVER && Date.now() >= state.confirmUntil) {
      state.confirmUntil = Date.now() + 4000;
      renderRun(t);
      setTimeout(function () { renderRun(current()); }, 4100);
      return;
    }
    state.confirmUntil = 0;
    var s = skipOf(t), skip = [];
    for (var i = 0; i < t.count; i++) if (s[i]) skip.push(i);
    state.busy = true;
    $('busy').hidden = false;
    renderRun(t);
    var t0 = Date.now();
    setTimeout(function () {
      call('hyLO_run', [JSON.stringify({ key: t.key, skip: skip, clip: state.clip, removeEmpty: state.removeEmpty, flatten: state.flatten })], function (r) {
        state.busy = false;
        $('busy').hidden = true;
        if (!r.ok) {
          setStatus(r.err || '실패했어요', true);
          renderRun(current());
          return;
        }
        showResult(r, (Date.now() - t0) / 1000);
        setStatus('');
        state.skip = {};
        state.manual = false;
        state.sig = null;           // 바뀐 문서를 다시 읽고 선택 추적도 새로
        refresh(true);
      });
    }, 30);
  }

  function showResult(r, sec) {
    var head = '<span class="ok">✓</span> ' + r.moved + '개를 레이어로 꺼냈어요';
    var bits = [];
    if (r.hadClip && r.clipNeeded) bits.push('클리핑 ' + r.clipped + '/' + r.clipNeeded);
    if (r.pruned) bits.push('영역 밖 ' + r.pruned + '개 삭제');
    if (r.hadClip && state.clip === 'release') bits.push(r.areaKept ? "마스크는 '클립 영역'에" : '클리핑 해제');
    if (bits.length) head += ' <span class="sub">· ' + esc(bits.join(' · ')) + '</span>';
    $('resultHead').innerHTML = head;
    var w = r.warnings || [];
    $('resultWarn').innerHTML = w.slice(0, 12).map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') +
      (w.length > 12 ? '<li>… 외 ' + (w.length - 12) + '개</li>' : '');
    $('resultFoot').textContent = (r.menuClip ? '일부 클리핑을 Ctrl+7 방식으로 해서 되돌릴 때 Ctrl+Z를 여러 번 눌러야 할 수 있어요. ' : '') +
      '되돌리기: Ctrl+Z · ' + sec.toFixed(1) + '초';
    $('result').hidden = false;
  }

  /* ---------------- 입력 ---------------- */

  $('targetList').addEventListener('click', function (e) {
    var row = e.target.closest('.trow');
    if (!row || state.busy) return;
    state.key = row.getAttribute('data-key');
    state.manual = true;
    state.confirmUntil = 0;
    render();
  });

  $('moreBtn').onclick = function () { state.showAll = !state.showAll; render(); };

  $('itemChips').addEventListener('click', function (e) {
    var chip = e.target.closest('.chip');
    var t = current();
    if (!chip || !t) return;
    var i = +chip.getAttribute('data-i'), s = skipOf(t);
    if (s[i]) delete s[i]; else s[i] = true;
    state.confirmUntil = 0;
    renderItems(t);
    renderRun(t);
  });

  Array.prototype.forEach.call(document.querySelectorAll('#itemQuick button'), function (b) {
    b.onclick = function () {
      var t = current();
      if (!t) return;
      var q = b.getAttribute('data-q'), s = {};
      for (var i = 0; i < t.count; i++) {
        if (q === 'none') s[i] = true;
        else if (q === 'sel' && !(t.items[i] && t.items[i].s)) s[i] = true;
      }
      state.skip[t.key] = s;
      state.confirmUntil = 0;
      renderItems(t);
      renderRun(t);
    };
  });

  Array.prototype.forEach.call(document.querySelectorAll('#clipSeg button'), function (b) {
    b.onclick = function () {
      state.clip = b.getAttribute('data-clip');
      store('hyLayerOut.clip', state.clip);
      renderClip(current());
    };
  });

  $('flattenRow').onclick = function () {
    state.flatten = !state.flatten;
    store('hyLayerOut.flatten', state.flatten ? '1' : '0');
    renderClip(current());
  };

  $('removeRow').onclick = function () {
    state.removeEmpty = !state.removeEmpty;
    store('hyLayerOut.removeEmpty', state.removeEmpty ? '1' : '0');
    renderClip(current());
  };

  $('runBtn').onclick = runNow;
  $('refreshBtn').onclick = function () { setStatus(''); refresh(false); };

  // 일러스트에서 직접 고친 뒤 패널로 돌아오면 다시 읽기 (고른 대상은 그대로)
  window.addEventListener('focus', function () {
    if (Date.now() - state.lastRead < 800) return;
    refresh(false);
  });

  /* ---------------- 시작 ---------------- */

  applyTheme();
  cs.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, applyTheme);
  cs.addEventListener('documentAfterActivate', function () { state.skip = {}; refresh(true); });
  cs.addEventListener('documentAfterDeactivate', function () { setTimeout(function () { refresh(true); }, 150); });
  render();
  refresh(true);
  setInterval(poll, 700);
})();
