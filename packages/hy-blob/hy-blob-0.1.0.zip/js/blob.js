/* hy Blob — 계산 코어
 * 도형: 원 + 타원(회전 포함). 타원 거리는 근사 SDF(경계선은 정확)
 * 필드: 지수 smooth-min 거리  g(p) = -k·ln Σ exp(-sd_i(p)/k)
 *   - 떨어진 원은 정확히 원 그대로, 틈이 2k·ln2 이하인 원끼리만 이어짐
 *   - g <= 0 이 블롭 내부
 * 색: 같은 거리값의 softmax 가중치(폭 b)로 OKLab 평균
 * 좌표: 일러스트 스크립트 문서 좌표 (y 위쪽 +)
 */
var HB = (function () {
  'use strict';

  /* ---------- 색 ---------- */
  function s2l(c) { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function l2s(c) {
    if (c <= 0) return 0;
    var v = c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
    v = Math.round(v * 255);
    return v < 0 ? 0 : v > 255 ? 255 : v;
  }
  function toLab(rgb) {
    var r = s2l(rgb[0]), g = s2l(rgb[1]), b = s2l(rgb[2]);
    var l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
    var m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
    var s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
    return [0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
            1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
            0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s];
  }
  function toRgb(L, a, b) {
    var l = L + 0.3963377774 * a + 0.2158037573 * b;
    var m = L - 0.1055613458 * a - 0.0638541728 * b;
    var s = L - 0.0894841775 * a - 1.2914855480 * b;
    l = l * l * l; m = m * m * m; s = s * s * s;
    return [l2s(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
            l2s(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
            l2s(-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)];
  }
  function mixLab(p, q, t) { return [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, p[2] + (q[2] - p[2]) * t]; }

  /* ---------- 도형 (원/타원) ---------- */
  // {x,y,rx,ry,a(rad)} 또는 {x,y,r} → 계산용 필드 채우기
  function shape(c) {
    if (c.pts) return lineShape(c.pts, c.hw);
    var rx = c.rx || c.r, ry = c.ry || c.r, a = c.a || 0;
    var o = { x: c.x, y: c.y, rx: rx, ry: ry, ca: Math.cos(a), sa: Math.sin(a) };
    o.circ = Math.abs(rx - ry) < 1e-6 * Math.max(rx, ry);
    o.r = Math.sqrt(rx * ry);                 // 크기 기준(면적 등가 반지름)
    o.R = Math.max(rx, ry); o.rmin = Math.min(rx, ry);
    if (c.rgb) o.rgb = c.rgb;
    return o;
  }
  function prep(C) { return C.map(shape); }

  /* 연결선: 폴리라인 + 반폭 hw. 색은 없음(양 끝 도형 색이 흘러들어옴) */
  function lineShape(pts, hw) {
    var o = { type: 'line', pts: pts, hw: hw, n: pts.length };
    o.px = new Float64Array(pts.map(function (q) { return q[0]; }));
    o.py = new Float64Array(pts.map(function (q) { return q[1]; }));
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    pts.forEach(function (q) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); });
    o.bb = [x0 - hw, y0 - hw, x1 + hw, y1 + hw];
    o.x = (x0 + x1) / 2; o.y = (y0 + y1) / 2;
    return o;
  }
  function isLine(c) { return c.type === 'line'; }
  function lineDist(c, x, y) {
    var best = Infinity, px = c.px, py = c.py;
    for (var i = 0; i < c.n - 1; i++) {
      var ax = px[i], ay = py[i], dx = px[i + 1] - ax, dy = py[i + 1] - ay, L = dx * dx + dy * dy;
      var t = L ? ((x - ax) * dx + (y - ay) * dy) / L : 0;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      var ex = ax + t * dx - x, ey = ay + t * dy - y, d = ex * ex + ey * ey;
      if (d < best) best = d;
    }
    return Math.sqrt(best);
  }
  // 로컬 좌표(원점 ox,oy / +x축 = (ca,sa))로 옮기기
  function toLocal(c, ox, oy, ca, sa) {
    function tp(x, y) { var px = x - ox, py = y - oy; return [px * ca + py * sa, -px * sa + py * ca]; }
    if (isLine(c)) return lineShape(c.pts.map(function (q) { return tp(q[0], q[1]); }), c.hw);
    var p = tp(c.x, c.y);
    return shape({ x: p[0], y: p[1], rx: c.rx, ry: c.ry, a: Math.atan2(c.sa * ca - c.ca * sa, c.ca * ca + c.sa * sa) });
  }
  // 부호 거리 (타원은 Quilez 근사: 0 등고선이 정확히 타원)
  function sd(c, x, y) {
    if (c.type === 'line') return lineDist(c, x, y) - c.hw;
    var dx = x - c.x, dy = y - c.y;
    if (c.circ) return Math.sqrt(dx * dx + dy * dy) - c.rx;
    var lx = dx * c.ca + dy * c.sa, ly = -dx * c.sa + dy * c.ca;
    var ax = lx / c.rx, ay = ly / c.ry, k0 = Math.sqrt(ax * ax + ay * ay);
    var bx = ax / c.rx, by = ay / c.ry, k1 = Math.sqrt(bx * bx + by * by);
    return k1 > 1e-12 ? k0 * (k0 - 1) / k1 : -c.rmin;
  }
  // 중심에서 (ux,uy) 방향으로 잰 반지름
  function dirR(c, ux, uy) {
    var u = ux * c.ca + uy * c.sa, v = -ux * c.sa + uy * c.ca;
    return 1 / Math.sqrt((u / c.rx) * (u / c.rx) + (v / c.ry) * (v / c.ry));
  }

  /* ---------- 필드 ---------- */
  function gAt(C, k, x, y, tmp) {
    var n = C.length, m = Infinity, i, s, sum = 0;
    for (i = 0; i < n; i++) {
      s = sd(C[i], x, y);
      tmp[i] = s; if (s < m) m = s;
    }
    for (i = 0; i < n; i++) sum += Math.exp(-(tmp[i] - m) / k);
    return m - k * Math.log(sum);
  }

  function bounds(C, k) {
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    C.forEach(function (c) {
      if (isLine(c)) {
        x0 = Math.min(x0, c.bb[0]); y0 = Math.min(y0, c.bb[1]); x1 = Math.max(x1, c.bb[2]); y1 = Math.max(y1, c.bb[3]);
        return;
      }
      x0 = Math.min(x0, c.x - c.R); y0 = Math.min(y0, c.y - c.R);
      x1 = Math.max(x1, c.x + c.R); y1 = Math.max(y1, c.y + c.R);
    });
    var pad = k * Math.log(Math.max(2, C.length));
    return [x0 - pad, y0 - pad, x1 + pad, y1 + pad];
  }

  /* ---------- 다각형 유틸 ---------- */
  function area(P) {
    var a = 0, n = P.length;
    for (var i = 0, j = n - 1; i < n; j = i++) a += (P[j][0] * P[i][1] - P[i][0] * P[j][1]);
    return a / 2;
  }
  function pip(pt, P) {
    var x = pt[0], y = pt[1], ins = false;
    for (var i = 0, j = P.length - 1; i < P.length; j = i++) {
      var xi = P[i][0], yi = P[i][1], xj = P[j][0], yj = P[j][1];
      if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) ins = !ins;
    }
    return ins;
  }
  function segDist(p, a, b) {
    var dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy;
    var t = L ? ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    var ex = a[0] + t * dx - p[0], ey = a[1] + t * dy - p[1];
    return Math.sqrt(ex * ex + ey * ey);
  }
  // 닫힌 폴리라인 RDP (반복형)
  function simplifyClosed(P, tol) {
    var n = P.length;
    if (n <= 8) return P.slice();
    var far = 0, fd = -1;
    for (var i = 1; i < n; i++) {
      var dx = P[i][0] - P[0][0], dy = P[i][1] - P[0][1], d = dx * dx + dy * dy;
      if (d > fd) { fd = d; far = i; }
    }
    var Q = P.concat([P[0]]), keep = new Uint8Array(n + 1);
    keep[0] = keep[far] = keep[n] = 1;
    var stack = [[0, far], [far, n]];
    while (stack.length) {
      var s = stack.pop(), a = s[0], b = s[1], md = 0, mi = -1;
      for (var j = a + 1; j < b; j++) {
        var dd = segDist(Q[j], Q[a], Q[b]);
        if (dd > md) { md = dd; mi = j; }
      }
      if (md > tol && mi > 0) { keep[mi] = 1; stack.push([a, mi], [mi, b]); }
    }
    var out = [];
    for (var q = 0; q < n; q++) if (keep[q]) out.push(P[q]);
    if (out.length < 6) { // 너무 줄면 균등 추출
      out = [];
      for (var e = 0; e < 8; e++) out.push(P[Math.floor(e * n / 8)]);
    }
    return out;
  }
  // 곡률 따라가는 베지어 핸들 (원이면 거의 정확한 원)
  function handles(P) {
    var n = P.length, L = [], R = [];
    for (var i = 0; i < n; i++) {
      var p = P[(i - 1 + n) % n], c = P[i], q = P[(i + 1) % n];
      var tx = q[0] - p[0], ty = q[1] - p[1], tl = Math.sqrt(tx * tx + ty * ty) || 1;
      tx /= tl; ty /= tl;
      var dn = Math.hypot(q[0] - c[0], q[1] - c[1]) / 3, dp = Math.hypot(c[0] - p[0], c[1] - p[1]) / 3;
      R.push([c[0] + tx * dn, c[1] + ty * dn]);
      L.push([c[0] - tx * dp, c[1] - ty * dp]);
    }
    return { l: L, r: R };
  }

  /* ---------- 윤곽선 (마칭 스퀘어) ---------- */
  var CASES = { 1: [[3, 0]], 2: [[0, 1]], 3: [[3, 1]], 4: [[1, 2]], 6: [[0, 2]], 7: [[3, 2]],
                8: [[2, 3]], 9: [[0, 2]], 11: [[1, 2]], 12: [[1, 3]], 13: [[0, 1]], 14: [[3, 0]] };
  var DENS = [5, 9, 14];            // 최소 반지름당 격자 수
  var TOL = [0.03, 0.01, 0.0035];   // 단순화 허용오차 (최소 반지름 비율)

  // 임의 필드 fn(x,y) (<=0 내부)의 윤곽선. bb=[x0,y0,x1,y1], h=격자, tol=단순화 허용오차
  function march(fn, bb, h, tol) {
    var W = bb[2] - bb[0], H = bb[3] - bb[1];
    while ((W / h + 8) * (H / h + 8) > 450000) h *= 1.2;
    var ox = bb[0] - 3 * h, oy = bb[1] - 3 * h;
    var nx = Math.ceil(W / h) + 7, ny = Math.ceil(H / h) + 7;
    var V = new Float64Array(nx * ny), i, j;
    for (j = 0; j < ny; j++) for (i = 0; i < nx; i++) {
      var id = j * nx + i;
      if (i === 0 || j === 0 || i === nx - 1 || j === ny - 1) { V[id] = 1e9; continue; }
      var v = fn(ox + i * h, oy + j * h);
      V[id] = v === 0 ? 1e-9 : v;
    }
    var NN = nx * ny, pos = new Map(), adj = new Map();
    function ept(key) {
      if (pos.has(key)) return;
      var va, vb, t, x, y, ii, jj;
      if (key < NN) {
        jj = Math.floor(key / nx); ii = key % nx;
        va = V[jj * nx + ii]; vb = V[jj * nx + ii + 1]; t = va / (va - vb);
        x = ox + (ii + t) * h; y = oy + jj * h;
      } else {
        var kk = key - NN; jj = Math.floor(kk / nx); ii = kk % nx;
        va = V[jj * nx + ii]; vb = V[(jj + 1) * nx + ii]; t = va / (va - vb);
        x = ox + ii * h; y = oy + (jj + t) * h;
      }
      pos.set(key, [x, y]);
    }
    function link(a, b) {
      ept(a); ept(b);
      (adj.get(a) || adj.set(a, []).get(a)).push(b);
      (adj.get(b) || adj.set(b, []).get(b)).push(a);
    }
    for (j = 0; j < ny - 1; j++) for (i = 0; i < nx - 1; i++) {
      var a = V[j * nx + i], b = V[j * nx + i + 1], c = V[(j + 1) * nx + i + 1], d = V[(j + 1) * nx + i];
      var idx = (a <= 0 ? 1 : 0) | (b <= 0 ? 2 : 0) | (c <= 0 ? 4 : 0) | (d <= 0 ? 8 : 0);
      if (idx === 0 || idx === 15) continue;
      var E = [j * nx + i, NN + j * nx + i + 1, (j + 1) * nx + i, NN + j * nx + i];
      var segs = CASES[idx];
      if (idx === 5 || idx === 10) {
        var cen = (a + b + c + d) / 4 <= 0;
        segs = (idx === 5) === cen ? [[0, 1], [2, 3]] : [[3, 0], [1, 2]];
      }
      for (var s = 0; s < segs.length; s++) link(E[segs[s][0]], E[segs[s][1]]);
    }
    var seen = new Set(), raw = [];
    adj.forEach(function (_, start) {
      if (seen.has(start)) return;
      var pts = [], prev = -1, cur = start, guard = 0;
      while (guard++ < 5e6) {
        seen.add(cur);
        var p = pos.get(cur), last = pts[pts.length - 1];
        if (!last || Math.abs(last[0] - p[0]) + Math.abs(last[1] - p[1]) > h * 1e-3) pts.push(p);
        var nb = adj.get(cur), nxt = nb[0] !== prev ? nb[0] : nb[1];
        if (nxt === undefined) break;
        prev = cur; cur = nxt;
        if (cur === start || seen.has(cur)) break;
      }
      if (pts.length >= 4 && Math.abs(area(pts)) > h * h) raw.push(pts);
    });
    var loops = raw.map(function (P) { return { raw: P, p: simplifyClosed(P, tol) }; });
    loops.forEach(function (L, ia) {
      var dpt = 0;
      loops.forEach(function (M, ib) { if (ia !== ib && pip(L.raw[0], M.raw)) dpt++; });
      L.depth = dpt;
      var ar = area(L.p), hole = dpt % 2 === 1;
      if ((hole && ar > 0) || (!hole && ar < 0)) L.p.reverse(); // 바깥 CCW, 구멍 CW
      L.hole = hole;
      L.area = Math.abs(ar);
      var hd = handles(L.p); L.l = hd.l; L.r = hd.r;
    });
    loops.forEach(function (L) { delete L.raw; });
    return loops;
  }

  // 격자 기준 크기: 도형 최소 반지름, 선은 실제 목 두께(반폭+k 정도)
  function minRadius(C, k) {
    var m = Infinity;
    C.forEach(function (c) { var v = isLine(c) ? Math.max(c.hw, 0.6 * k) : c.rmin; if (v < m) m = v; });
    return m;
  }

  function contour(C, k, prec) {
    if (!C.length) return { loops: [] };
    prec = prec in DENS ? prec : 1;
    var minR = minRadius(C, k), tmp = new Float64Array(C.length);
    var loops = march(function (x, y) { return gAt(C, k, x, y, tmp); },
                      bounds(C, k), minR / DENS[prec], TOL[prec] * minR);
    return { loops: loops };
  }

  function loopBounds(loops) {
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    loops.forEach(function (L) {
      [L.p, L.l, L.r].forEach(function (A) {
        A.forEach(function (q) {
          if (q[0] < x0) x0 = q[0]; if (q[0] > x1) x1 = q[0];
          if (q[1] < y0) y0 = q[1]; if (q[1] > y1) y1 = q[1];
        });
      });
    });
    return [x0, y0, x1, y1];
  }

  /* ---------- 벡터 모드: 덩어리별 바탕색 ---------- */
  function components(loops, C, labs) {
    var out = [];
    loops.forEach(function (L, i) {
      if (L.hole) return;
      var idx = [i], holes = [];
      loops.forEach(function (Hh, j) {
        if (Hh.depth === L.depth + 1 && pip(Hh.p[0], L.p)) { idx.push(j); holes.push(Hh); }
      });
      var w = 0, acc = [0, 0, 0];
      C.forEach(function (c, ci) {
        if (isLine(c)) return;
        var pt = [c.x, c.y];
        if (pip(pt, L.p) && !holes.some(function (Hh) { return pip(pt, Hh.p); })) {
          var ww = c.rx * c.ry; w += ww;
          acc[0] += labs[ci][0] * ww; acc[1] += labs[ci][1] * ww; acc[2] += labs[ci][2] * ww;
        }
      });
      if (!w) {
        var best = 0, bd = Infinity;
        C.forEach(function (c, ci) {
          if (isLine(c)) return;
          var d = sd(c, L.p[0][0], L.p[0][1]);
          if (d < bd) { bd = d; best = ci; }
        });
        acc = labs[best].slice(); w = 1;
      }
      out.push({ loops: idx, rgb: toRgb(acc[0] / w, acc[1] / w, acc[2] / w) });
    });
    return out;
  }

  /* ---------- 벡터 모드: 이어진 원 쌍마다 그라디언트 브리지 ----------
   * 브리지 영역 = 전체 블롭 ∩ 두 원을 잇는 테이퍼 캡슐  (전체 블롭 안쪽이 보장됨)
   * 쌍마다 i를 원점, j를 +x축에 둔 로컬 좌표로 계산 → 일러스트에서 회전만 하면 그라디언트 방향이 맞음 */
  function pairs(C, labs, k, b, prec) {
    var n = C.length, D = [], RA = [], con = [], out = [], tmp = new Float64Array(n);
    var SH = C.filter(function (c) { return !isLine(c); });
    prec = prec in DENS ? prec : 1;
    for (var i = 0; i < n; i++) { D[i] = []; RA[i] = []; con[i] = []; }
    for (i = 0; i < n; i++) for (var j = i + 1; j < n; j++) {
      if (isLine(C[i]) || isLine(C[j])) { con[i][j] = con[j][i] = false; continue; }
      var dx = C[j].x - C[i].x, dy = C[j].y - C[i].y, d = Math.hypot(dx, dy), ok = true;
      D[i][j] = D[j][i] = d;
      if (d > 1e-6) {
        RA[i][j] = dirR(C[i], dx / d, dy / d);   // i에서 j쪽으로 잰 반지름
        RA[j][i] = dirR(C[j], -dx / d, -dy / d);
      } else { RA[i][j] = C[i].r; RA[j][i] = C[j].r; }
      var gap = d - RA[i][j] - RA[j][i];
      if (d > 1e-6 && gap > 0) {                 // 틈이 있으면 전체 필드로 이어졌는지 확인
        if (gap > 2 * k * Math.log(Math.max(2, n))) ok = false;
        for (var q = 1; q < 24 && ok; q++) {
          var t = (RA[i][j] + gap * q / 24) / d;
          if (gAt(SH, k, C[i].x + dx * t, C[i].y + dy * t, tmp) > 0) ok = false;  // 선 도움 없이 이어진 쌍만
        }
      }
      con[i][j] = con[j][i] = ok;
    }
    for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) {
      if (!con[i][j] || D[i][j] < 1e-6) continue;
      var dij = D[i][j], skip = false;
      for (var m = 0; m < n && !skip; m++) {  // 상대 이웃 그래프: 둘 다에 더 가까운 도형이 끼면 생략
        if (m !== i && m !== j && con[i][m] && con[j][m] && D[i][m] < dij && D[j][m] < dij) skip = true;
      }
      if (skip) continue;
      var ca = (C[j].x - C[i].x) / dij, sa = (C[j].y - C[i].y) / dij;
      var ri = RA[i][j], rj = RA[j][i];
      var wi = dirR(C[i], -sa, ca), wj = dirR(C[j], -sa, ca);   // 축에 수직인 반폭
      var LC = C.map(function (c) { return toLocal(c, C[i].x, C[i].y, ca, sa); }); // i 중심·i→j가 +x축
      var capsule = function (x, y) {
        var t = x / dij; t = t < 0 ? 0 : t > 1 ? 1 : t;
        return Math.hypot(x - t * dij, y) - (wi + (wj - wi) * t);
      };
      var fn = function (x, y) { return Math.max(gAt(LC, k, x, y, tmp), capsule(x, y)); };
      var rm = Math.min(C[i].rmin, C[j].rmin), R = Math.max(C[i].R, C[j].R);
      var loops = march(fn, [-C[i].R, -R, dij + C[j].R, R], rm / DENS[prec], TOL[prec] * rm), best = null;
      loops.forEach(function (L) { if (!L.hole && (!best || L.area > best.area)) best = L; });
      if (!best) continue;
      var ox = C[i].x, oy = C[i].y;
      var mv = function (A) { return A.map(function (p) { return [p[0] + ox, p[1] + oy]; }); };
      var s0 = ri, s1 = dij - rj;
      if (s0 >= s1) { s0 = 0; s1 = dij; }
      var mid = (s0 + s1) / 2, wt = Math.min(s1 - s0, 4 * b), xa = mid - wt / 2, xb = mid + wt / 2;
      var stops = [{ x: xa, c: 'i' }];
      [0.25, 0.5, 0.75].forEach(function (tt) {
        var lb = mixLab(labs[i], labs[j], tt);
        stops.push({ x: xa + (xb - xa) * tt, c: toRgb(lb[0], lb[1], lb[2]) });
      });
      stops.push({ x: xb, c: 'j' });
      out.push({
        i: i, j: j, ox: ox, oy: oy,
        ang: Math.atan2(sa, ca) * 180 / Math.PI,
        loop: { p: mv(best.p), l: mv(best.l), r: mv(best.r) },
        stops: stops
      });
    }
    return out;
  }

  /* ---------- 벡터 모드: 연결선 브리지 ----------
   * 선 양 끝에서 가장 가까운 도형 A→B 색으로, 선 시작점 기준 로컬 좌표에서 계산 */
  function connectors(C, labs, k, b, prec) {
    var out = [], tmp = new Float64Array(C.length);
    prec = prec in DENS ? prec : 1;
    function nearest(q) {
      var best = -1, bd = Infinity;
      C.forEach(function (c, ci) { if (isLine(c)) return; var d = sd(c, q[0], q[1]); if (d < bd) { bd = d; best = ci; } });
      return best;
    }
    C.forEach(function (ln, li) {
      if (!isLine(ln)) return;
      var P0 = ln.pts[0], P1 = ln.pts[ln.pts.length - 1];
      var ia = nearest(P0), ib = nearest(P1);
      if (ia < 0 || ib < 0 || ia === ib) return;
      var dx = P1[0] - P0[0], dy = P1[1] - P0[1], d = Math.hypot(dx, dy);
      if (d < 1e-6) return;
      var ca = dx / d, sa = dy / d;
      var LC = C.map(function (c) { return toLocal(c, P0[0], P0[1], ca, sa); });
      var LL = LC[li], tubeR = 1.5 * k;
      var fn = function (x, y) { return Math.max(gAt(LC, k, x, y, tmp), sd(LL, x, y) - tubeR); };
      var pad = LL.hw + tubeR + 2 * k;
      var bb = [LL.bb[0] - pad, LL.bb[1] - pad, LL.bb[2] + pad, LL.bb[3] + pad];
      var rm = Math.max(LL.hw, 0.6 * k);
      var loops = march(fn, bb, rm / DENS[prec], TOL[prec] * rm), best = null;
      loops.forEach(function (L) { if (!L.hole && (!best || L.area > best.area)) best = L; });
      if (!best) return;
      var A = LC[ia], B = LC[ib];
      var s0 = A.x + dirR(A, 1, 0), s1 = B.x - dirR(B, -1, 0);
      if (s0 >= s1) { s0 = A.x; s1 = B.x; }
      if (s0 >= s1) return;
      var mid = (s0 + s1) / 2, wt = Math.min(s1 - s0, 4 * b), xa = mid - wt / 2, xb = mid + wt / 2;
      var stops = [{ x: xa, c: 'i' }];
      [0.25, 0.5, 0.75].forEach(function (tt) {
        var lb = mixLab(labs[ia], labs[ib], tt);
        stops.push({ x: xa + (xb - xa) * tt, c: toRgb(lb[0], lb[1], lb[2]) });
      });
      stops.push({ x: xb, c: 'j' });
      var mv = function (Ar) { return Ar.map(function (p) { return [p[0] + P0[0], p[1] + P0[1]]; }); };
      out.push({ i: ia, j: ib, ox: P0[0], oy: P0[1], ang: Math.atan2(sa, ca) * 180 / Math.PI,
                 loop: { p: mv(best.p), l: mv(best.l), r: mv(best.r) }, stops: stops });
    });
    return out;
  }

  /* ---------- 픽셀 렌더 (미리보기 + 이미지 모드) ---------- */
  // o: {data, w, h, left, top, s(px/pt), alpha}
  function render(C, labs, k, b, o) {
    var n = C.length, tmp = new Float64Array(n), data = o.data, px = 1 / o.s;
    for (var yy = 0; yy < o.h; yy++) {
      var y = o.top - (yy + 0.5) / o.s;
      for (var xx = 0; xx < o.w; xx++) {
        var x = o.left + (xx + 0.5) / o.s, m = Infinity, mw = Infinity, i, w;
        for (i = 0; i < n; i++) {
          var s = sd(C[i], x, y);
          tmp[i] = s; if (s < m) m = s;
          if (labs[i] && s < mw) mw = s;
        }
        var o4 = (yy * o.w + xx) * 4, al = 255;
        if (o.alpha) {
          var sk = 0;
          for (i = 0; i < n; i++) sk += Math.exp(-(tmp[i] - m) / k);
          var g = m - k * Math.log(sk), f = 0.5 - g / px;
          f = f < 0 ? 0 : f > 1 ? 1 : f;
          al = Math.round(f * 255);
          if (!al) { data[o4 + 3] = 0; continue; }
        }
        var sw = 0, L = 0, A = 0, B = 0;
        for (i = 0; i < n; i++) {
          if (!labs[i]) continue;                       // 연결선은 색 없음
          w = Math.exp(-(tmp[i] - mw) / b); sw += w;
          L += w * labs[i][0]; A += w * labs[i][1]; B += w * labs[i][2];
        }
        var rgb = toRgb(L / sw, A / sw, B / sw);
        data[o4] = rgb[0]; data[o4 + 1] = rgb[1]; data[o4 + 2] = rgb[2]; data[o4 + 3] = al;
      }
    }
  }

  return {
    prep: prep, toLab: toLab, toRgb: toRgb, bounds: bounds, contour: contour, loopBounds: loopBounds,
    components: components, pairs: pairs, connectors: connectors, render: render, isLine: isLine
  };
})();
if (typeof module !== 'undefined') module.exports = HB;
