/* hy Blob — 패널 */
(function () {
  'use strict';
  var CEP = window.__adobe_cep__ || null;
  var $ = function (id) { return document.getElementById(id); };

  function jsx(code) {
    return new Promise(function (res) {
      if (!CEP) { res('{"error":"일러스트레이터 안에서 열어 주세요."}'); return; }
      CEP.evalScript(code, function (r) { res(r); });
    });
  }
  function parse(r) { try { return JSON.parse(r); } catch (e) { return { error: String(r || '응답이 없습니다.') }; } }
  function tick() { return new Promise(function (r) { setTimeout(r, 30); }); }

  /* ---------- 설정 ---------- */
  var DEF = { mode: 'raster', gap: 60, blend: 50, prec: 1, ppi: 300, orig: 'hide', lineW: 'mid' };
  var S = Object.assign({}, DEF);
  try { Object.assign(S, JSON.parse(localStorage.getItem('hyBlob') || '{}')); } catch (e) {}
  function save() { try { localStorage.setItem('hyBlob', JSON.stringify(S)); } catch (e) {} }

  var rawShapes = [], rawLines = [], circles = [], labs = [], busy = false;
  var LINE_W = { thin: 0.12, mid: 0.22, thick: 0.35 };   // 연결선 반폭 = 평균 반지름 × 비율

  function avgR() {
    var sh = circles.filter(function (c) { return !HB.isLine(c); });
    return sh.length ? sh.reduce(function (a, c) { return a + c.r; }, 0) / sh.length : 10;
  }
  // 도형 + 연결선(굵기 설정 반영) → 계산용 배열. 도형이 앞, 선이 뒤 (호스트 인덱스와 일치)
  function rebuild() {
    circles = HB.prep(rawShapes);
    var ar = avgR();
    circles = circles.concat(HB.prep(rawLines.map(function (l) {
      var hw = S.lineW === 'stroke' ? Math.max(0.25, l.sw / 2) : ar * (LINE_W[S.lineW] || LINE_W.mid);
      return { pts: l.pts, hw: hw };
    })));
    labs = circles.map(function (c) { return HB.isLine(c) ? null : HB.toLab(c.rgb); });
  }
  function kParam() { return Math.max(0.05, S.gap / 100 * avgR() / (2 * Math.LN2)); } // 틈이 반지름의 gap% 이하면 이어짐
  function bParam() { return Math.max(0.05, S.blend / 100 * avgR() * 0.5); }

  /* ---------- 테마 ---------- */
  function theme() {
    try {
      var c = JSON.parse(CEP.getHostEnvironment()).appSkinInfo.panelBackgroundColor.color;
      var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
      var dark = (0.299 * r + 0.587 * g + 0.114 * b) < 128, st = document.documentElement.style;
      function sh(d) { return 'rgb(' + [r, g, b].map(function (v) { return Math.max(0, Math.min(255, v + d)); }).join(',') + ')'; }
      st.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
      st.setProperty('--ctl', sh(dark ? 14 : -14));
      st.setProperty('--ctl-hi', sh(dark ? 26 : -26));
      st.setProperty('--stage', sh(dark ? -10 : 10));
      st.setProperty('--fg', dark ? '#e6e6e6' : '#222');
      st.setProperty('--muted', dark ? '#9a9a9a' : '#6b6b6b');
      st.setProperty('--dot', dark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.08)');
    } catch (e) {}
  }

  /* ---------- UI ---------- */
  var HINT = {
    raster: '겹치는 구간의 색이 픽셀 단위로 부드럽게 섞입니다. 외곽선은 벡터 클리핑이라 형태는 깔끔하게 유지됩니다.',
    vector: '원 사이를 그라디언트 브리지로 이어 붙입니다. 색과 형태를 나중에 직접 고칠 수 있습니다.'
  };

  function syncUI() {
    document.querySelectorAll('.seg').forEach(function (seg) {
      var key = seg.dataset.key;
      seg.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', String(S[key]) === b.dataset.v); });
    });
    $('gap').value = S.gap; $('vGap').textContent = S.gap + '%';
    $('blend').value = S.blend; $('vBlend').textContent = S.blend + '%';
    $('modeHint').textContent = HINT[S.mode];
    $('fPpi').style.display = S.mode === 'raster' ? '' : 'none';
    $('fLine').style.display = rawLines.length ? '' : 'none';
  }

  document.querySelectorAll('.seg').forEach(function (seg) {
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var key = seg.dataset.key, v = b.dataset.v;
      S[key] = (key === 'prec' || key === 'ppi') ? Number(v) : v;
      if (key === 'lineW') rebuild();
      save(); syncUI(); schedule();
    });
  });
  ['gap', 'blend'].forEach(function (id) {
    $(id).addEventListener('input', function () { S[id] = Number(this.value); syncUI(); schedule(); });
    $(id).addEventListener('change', save);
    $(id).addEventListener('dblclick', function () { S[id] = DEF[id]; save(); syncUI(); schedule(); });
  });

  function status(msg, err) { var el = $('status'); el.textContent = msg || ''; el.classList.toggle('err', !!err); }

  /* ---------- 미리보기 ---------- */
  var raf = 0;
  function schedule() { if (!raf) raf = requestAnimationFrame(function () { raf = 0; drawPreview(); }); }

  function drawPreview() {
    var cv = $('pv'), wrap = cv.parentNode, dpr = window.devicePixelRatio || 1;
    var W = Math.max(1, Math.round(wrap.clientWidth * dpr)), H = Math.max(1, Math.round(wrap.clientHeight * dpr));
    cv.width = W; cv.height = H;
    var ctx = cv.getContext('2d');
    $('empty').style.display = circles.length ? 'none' : '';
    if (!circles.length) return;
    var k = kParam(), b = bParam(), bb = HB.bounds(circles, k);
    var m = 14 * dpr, s = Math.min((W - 2 * m) / (bb[2] - bb[0]), (H - 2 * m) / (bb[3] - bb[1]));
    var cx = (bb[0] + bb[2]) / 2, cy = (bb[1] + bb[3]) / 2;
    var img = ctx.createImageData(W, H);
    HB.render(circles, labs, k, b, { data: img.data, w: W, h: H, left: cx - W / 2 / s, top: cy + H / 2 / s, s: s, alpha: true });
    ctx.putImageData(img, 0, 0);
  }
  window.addEventListener('resize', schedule);

  /* ---------- 가져오기 ---------- */
  function load() {
    return jsx('hb_read()').then(function (raw) {
      var r = parse(raw);
      if (r.error) { status(r.error, true); return; }
      rawShapes = r.circles.map(function (c) {
        return { x: c.x, y: c.y, rx: c.rx, ry: c.ry, a: c.a,
                 rgb: c.rgb.map(function (v) { return Math.max(0, Math.min(255, v)); }) };
      });
      rawLines = rawShapes.length ? (r.lines || []) : [];
      rebuild(); syncUI();
      var t = '원·타원 ' + rawShapes.length + '개';
      if (rawLines.length) t += ', 연결선 ' + rawLines.length + '개';
      if (r.skipped) t += ' (' + r.skipped + '개 제외)';
      $('count').textContent = rawShapes.length ? t : '';
      if (!rawShapes.length) status('선택 안에 채우기가 있는 원이나 타원이 없습니다.', true);
      else if (rawShapes.length < 2 && !rawLines.length) status('도형이 하나뿐이라 이어질 곳이 없습니다.');
      else status('');
      schedule();
    });
  }
  $('btnLoad').addEventListener('click', function () { if (!busy) load(); });

  /* ---------- 만들기 ---------- */
  function r3(v) { return Math.round(v * 1000) / 1000; }
  function packPts(A) { return A.map(function (q) { return [r3(q[0]), r3(q[1])]; }); }
  function packLoop(L) { return { p: packPts(L.p), l: packPts(L.l), r: packPts(L.r), hole: !!L.hole }; }

  function makeImage(loops, k, b) {
    return jsx('hb_temp()').then(function (tmp) {
      if (!tmp || tmp === 'EvalScript error.') throw new Error('임시 폴더를 찾지 못했습니다.');
      var bb = HB.loopBounds(loops), mg = 1;
      var left = bb[0] - mg, top = bb[3] + mg, wpt = bb[2] - bb[0] + 2 * mg, hpt = bb[3] - bb[1] + 2 * mg;
      var sc = S.ppi / 72, big = Math.max(wpt, hpt) * sc;
      if (big > 8000) sc *= 8000 / big;
      var w = Math.max(1, Math.ceil(wpt * sc)), h = Math.max(1, Math.ceil(hpt * sc));
      var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      var ctx = cv.getContext('2d'), img = ctx.createImageData(w, h);
      HB.render(circles, labs, k, b, { data: img.data, w: w, h: h, left: left, top: top, s: sc, alpha: false });
      ctx.putImageData(img, 0, 0);
      var b64 = cv.toDataURL('image/png').split(',')[1];
      var sep = tmp.indexOf('\\') >= 0 ? '\\' : '/';
      var path = tmp + sep + 'hy_blob_' + Date.now() + '.png';
      var wr = window.cep.fs.writeFile(path, b64, window.cep.encoding.Base64);
      if (wr.err) throw new Error('임시 이미지를 저장하지 못했습니다 (코드 ' + wr.err + ').');
      return { path: path, left: r3(left), top: r3(top), w: r3(w / sc), h: r3(h / sc) };
    });
  }

  function make() {
    if (busy) return;
    var pre = circles.length ? Promise.resolve() : load();
    pre.then(function () {
      if (!circles.length) return;
      busy = true; $('btnMake').disabled = true; status('만드는 중…');
      return tick().then(function () {
        var k = kParam(), b = bParam();
        var res = HB.contour(circles, k, S.prec);
        if (!res.loops.length) throw new Error('외곽선을 만들지 못했습니다.');
        var payload = { mode: S.mode, orig: S.orig, loops: res.loops.map(packLoop) };
        if (S.mode === 'vector') {
          payload.comps = HB.components(res.loops, circles, labs);
          payload.pairs = HB.pairs(circles, labs, k, b, S.prec).concat(HB.connectors(circles, labs, k, b, S.prec)).map(function (p) {
            return { i: p.i, j: p.j, ox: r3(p.ox), oy: r3(p.oy), ang: r3(p.ang), loop: packLoop(p.loop),
                     stops: p.stops.map(function (s) { return { x: r3(s.x), c: s.c }; }) };
          });
          return payload;
        }
        return makeImage(res.loops, k, b).then(function (im) { payload.image = im; return payload; });
      }).then(function (payload) {
        return jsx('hb_build(' + JSON.stringify(JSON.stringify(payload)) + ')');
      }).then(function (raw) {
        var r = parse(raw);
        if (r.error) throw new Error(r.error);
        var t = '블롭을 만들었습니다.';
        if (S.mode === 'vector') t += ' 그라디언트 브리지 ' + r.pairs + '개.';
        status(t);
        if (S.orig === 'delete') { rawShapes = []; rawLines = []; rebuild(); $('count').textContent = ''; syncUI(); schedule(); }
      });
    }).catch(function (e) {
      status(e && e.message ? e.message : String(e), true);
    }).then(function () {
      busy = false; $('btnMake').disabled = false;
    });
  }
  $('btnMake').addEventListener('click', make);

  /* ---------- 시작 ---------- */
  theme();
  if (CEP) { try { CEP.addEventListener('com.adobe.csxs.events.ThemeColorChanged', theme); } catch (e) {} }
  syncUI();
  schedule();
})();
