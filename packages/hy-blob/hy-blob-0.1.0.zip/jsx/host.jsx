/* hy Blob — Illustrator host (ExtendScript, ES3) */
var HBLOB = { items: [], lines: [] };

function hb_q(s) {
    return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n/g, ' ') + '"';
}
function hb_n(v) { return String(Math.round(v * 1000) / 1000); }
function hb_err(msg) { return '{"error":' + hb_q(msg) + '}'; }

/* ---------- 색 변환 ---------- */
function hb_toRGB(c) {
    if (!c) return null;
    var t = c.typename, v;
    if (t == 'RGBColor') return [c.red, c.green, c.blue];
    if (t == 'CMYKColor') {
        try {
            v = app.convertSampleColor(ImageColorSpace.CMYK, [c.cyan, c.magenta, c.yellow, c.black],
                                       ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
            return [v[0], v[1], v[2]];
        } catch (e) {
            var k = 1 - c.black / 100;
            return [255 * (1 - c.cyan / 100) * k, 255 * (1 - c.magenta / 100) * k, 255 * (1 - c.yellow / 100) * k];
        }
    }
    if (t == 'GrayColor') { v = 255 * (1 - c.gray / 100); return [v, v, v]; }
    if (t == 'SpotColor') {
        var b = hb_toRGB(c.spot.color), tn = c.tint / 100;
        if (!b) return null;
        return [255 - (255 - b[0]) * tn, 255 - (255 - b[1]) * tn, 255 - (255 - b[2]) * tn];
    }
    return null; // 그라디언트·패턴·없음
}

function hb_fromRGB(rgb) {
    var doc = app.activeDocument, c, v;
    if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
        c = new CMYKColor();
        try {
            v = app.convertSampleColor(ImageColorSpace.RGB, rgb, ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose);
            c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
        } catch (e) {
            var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, k = 1 - Math.max(r, g, b);
            c.black = k * 100;
            if (k < 1) { c.cyan = (1 - r - k) / (1 - k) * 100; c.magenta = (1 - g - k) / (1 - k) * 100; c.yellow = (1 - b - k) / (1 - k) * 100; }
        }
        return c;
    }
    c = new RGBColor(); c.red = rgb[0]; c.green = rgb[1]; c.blue = rgb[2];
    return c;
}

/* ---------- 선택 읽기 ---------- */
function hb_collect(list, out) {
    for (var i = 0; i < list.length; i++) {
        var it = list[i];
        if (it.typename == 'GroupItem') hb_collect(it.pageItems, out);
        else out.push(it);
    }
}

function hb_read() {
    var oldCS;
    try {
        if (app.documents.length == 0) return hb_err('열린 문서가 없습니다.');
        oldCS = app.coordinateSystem;
        app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
        var doc = app.activeDocument, sel = doc.selection;
        if (!sel || sel.length == 0) { app.coordinateSystem = oldCS; return hb_err('원이나 타원(연결선 포함)을 선택하세요.'); }
        var all = [], out = [], skip = 0;
        hb_collect(sel, all);
        HBLOB.items = []; HBLOB.lines = [];
        var lines = [];
        for (var i = 0; i < all.length; i++) {
            var p = all[i];
            if (p.typename == 'PathItem' && !p.closed && p.pathPoints.length >= 2) {   // 열린 패스 = 연결선
                HBLOB.lines.push(p);
                lines.push('{"pts":' + hb_flatten(p) + ',"sw":' + hb_n(p.stroked ? p.strokeWidth : 0) + '}');
                continue;
            }
            if (p.typename != 'PathItem' || !p.closed || !p.filled) { skip++; continue; }
            var e = hb_ellipse(p);
            if (!e) { skip++; continue; }
            var rgb = hb_toRGB(p.fillColor);
            if (!rgb) { skip++; continue; }
            HBLOB.items.push(p);
            out.push('{"x":' + hb_n(e.x) + ',"y":' + hb_n(e.y) + ',"rx":' + hb_n(e.rx) + ',"ry":' + hb_n(e.ry) +
                     ',"a":' + hb_n(e.a) + ',"rgb":[' + hb_n(rgb[0]) + ',' + hb_n(rgb[1]) + ',' + hb_n(rgb[2]) + ']}');
        }
        app.coordinateSystem = oldCS;
        return '{"circles":[' + out.join(',') + '],"lines":[' + lines.join(',') + '],"skipped":' + skip + '}';
    } catch (e) {
        try { app.coordinateSystem = oldCS; } catch (e2) {}
        return hb_err('선택을 읽지 못했습니다: ' + e.message);
    }
}

// 원·타원 판별. 회전된 타원은 기준점 4개(축 끝점)로 축과 각도를 구함
function hb_ellipse(p) {
    var ar = Math.abs(p.area), pp = p.pathPoints, n = pp.length;
    function okArea(rx, ry) { var q = ar / (Math.PI * rx * ry); return q > 0.97 && q < 1.03; }
    if (n == 4) {
        var A = [], cx = 0, cy = 0, i;
        for (i = 0; i < 4; i++) { A.push(pp[i].anchor); cx += A[i][0] / 4; cy += A[i][1] / 4; }
        var sym = Math.abs(A[0][0] + A[2][0] - 2 * cx) + Math.abs(A[0][1] + A[2][1] - 2 * cy) +
                  Math.abs(A[1][0] + A[3][0] - 2 * cx) + Math.abs(A[1][1] + A[3][1] - 2 * cy);
        var ux = A[0][0] - cx, uy = A[0][1] - cy, vx = A[1][0] - cx, vy = A[1][1] - cy;
        var a1 = Math.sqrt(ux * ux + uy * uy), a2 = Math.sqrt(vx * vx + vy * vy);
        if (a1 > 0.01 && a2 > 0.01) {
            var perp = Math.abs(ux * vx + uy * vy) / (a1 * a2);
            if (sym < 0.02 * (a1 + a2) && perp < 0.03 && okArea(a1, a2))
                return { x: cx, y: cy, rx: a1, ry: a2, a: Math.atan2(uy, ux) };
        }
    }
    // 그 외: 회전 없는 타원으로 보고 바운딩으로 판별
    var gb = p.geometricBounds, rx = (gb[2] - gb[0]) / 2, ry = (gb[1] - gb[3]) / 2;
    if (rx < 0.01 || ry < 0.01 || !okArea(rx, ry)) return null;
    return { x: (gb[0] + gb[2]) / 2, y: (gb[1] + gb[3]) / 2, rx: rx, ry: ry, a: 0 };
}

// 열린 패스를 폴리라인으로 (곡선 구간은 12등분)
function hb_flatten(p) {
    var pp = p.pathPoints, out = [], n = pp.length;
    function pt(x, y) { out.push('[' + hb_n(x) + ',' + hb_n(y) + ']'); }
    pt(pp[0].anchor[0], pp[0].anchor[1]);
    for (var i = 0; i < n - 1; i++) {
        var a = pp[i].anchor, c1 = pp[i].rightDirection, c2 = pp[i + 1].leftDirection, b = pp[i + 1].anchor;
        var straight = c1[0] == a[0] && c1[1] == a[1] && c2[0] == b[0] && c2[1] == b[1];
        var steps = straight ? 1 : 12;
        for (var s = 1; s <= steps; s++) {
            var t = s / steps, u = 1 - t;
            pt(u * u * u * a[0] + 3 * u * u * t * c1[0] + 3 * u * t * t * c2[0] + t * t * t * b[0],
               u * u * u * a[1] + 3 * u * u * t * c1[1] + 3 * u * t * t * c2[1] + t * t * t * b[1]);
        }
    }
    return '[' + out.join(',') + ']';
}

function hb_temp() { return Folder.temp.fsName; }

/* ---------- 패스 만들기 ---------- */
function hb_addPath(coll, L, hole) {
    var p = coll.add();
    p.setEntirePath(L.p);
    var pp = p.pathPoints;
    for (var i = 0; i < pp.length; i++) {
        pp[i].leftDirection = L.l[i];
        pp[i].rightDirection = L.r[i];
        pp[i].pointType = PointType.SMOOTH;
    }
    p.closed = true;
    p.stroked = false;
    if (hole !== undefined) {
        try { p.polarity = hole ? PolarityValues.NEGATIVE : PolarityValues.POSITIVE; } catch (e) {}
    }
    return p;
}

function hb_compound(grp, layer, loops, idxs, color) {
    var cp;
    try { cp = grp.compoundPathItems.add(); }
    catch (e) { cp = layer.compoundPathItems.add(); cp.move(grp, ElementPlacement.PLACEATBEGINNING); }
    for (var i = 0; i < idxs.length; i++) {
        var L = loops[idxs[i]], p = hb_addPath(cp.pathItems, L, !!L.hole);
        if (color) { p.filled = true; p.fillColor = color; } else p.filled = false;
    }
    return cp;
}

/* ---------- 클리핑 ----------
 * group.clipped 는 맨 위가 단일 PathItem 일 때만 허용됨.
 * 1) 외곽선이 하나면 일반 패스로 클리핑
 * 2) 여러 개(떨어진 덩어리·구멍)면 컴파운드 + 첫 패스 clipping 지정 후 시도
 * 3) 그래도 거부되면 메뉴 명령(클리핑 마스크 만들기)으로 처리 */
function hb_clip(doc, grp, layer, loops, idxs) {
    if (idxs.length == 1) {
        var p = hb_addPath(grp.pathItems, loops[idxs[0]]);
        p.filled = false;
        grp.clipped = true;
        return grp;
    }
    var cp = hb_compound(grp, layer, loops, idxs, null);
    try {
        cp.pathItems[0].clipping = true;
        grp.clipped = true;
        return grp;
    } catch (e) {}
    try { cp.pathItems[0].clipping = false; } catch (e) {}
    doc.selection = null;
    for (var i = 0; i < grp.pageItems.length; i++) grp.pageItems[i].selected = true;
    app.redraw();
    app.executeMenuCommand('makeMask');
    var cg = doc.selection && doc.selection.length ? doc.selection[0] : null;
    if (cg && cg.typename == 'GroupItem' && cg.clipped) {
        // 메뉴 명령이 grp 안에 클리핑 그룹을 새로 만듦 → 바깥 grp 이름만 유지
        return grp;
    }
    throw new Error('클리핑 마스크를 만들지 못했습니다.');
}

/* ---------- 만들기 ---------- */
function hb_build(json) {
    var oldCS, doc, d, items = [], i;
    try {
        if (app.documents.length == 0) return hb_err('열린 문서가 없습니다.');
        doc = app.activeDocument;
        d = eval('(' + json + ')');
        for (i = 0; i < HBLOB.items.length; i++) {
            try { HBLOB.items[i].typename; items.push(HBLOB.items[i]); }
            catch (e) { return hb_err('가져온 원이 바뀌었습니다. 다시 가져오세요.'); }
        }
        if (!items.length) return hb_err('가져온 원이 없습니다.');

        oldCS = app.coordinateSystem;
        app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;

        var ref = items[0], layer = ref.layer;
        if (layer.locked || !layer.visible) { app.coordinateSystem = oldCS; return hb_err('원이 있는 레이어가 잠겨 있거나 숨겨져 있습니다.'); }
        var grp = layer.groupItems.add();
        grp.name = 'hy Blob';
        try { grp.move(ref, ElementPlacement.PLACEBEFORE); } catch (e) {}

        var all = [];
        for (i = 0; i < d.loops.length; i++) all.push(i);

        if (d.mode == 'raster') {
            var pl;
            try { pl = grp.placedItems.add(); }
            catch (e) { pl = layer.placedItems.add(); pl.move(grp, ElementPlacement.PLACEATBEGINNING); }
            pl.file = new File(d.image.path);
            pl.width = d.image.w;
            pl.height = d.image.h;
            pl.position = [d.image.left, d.image.top];
            try { pl.embed(); } catch (e) {}
            try { new File(d.image.path).remove(); } catch (e) {}
        } else {
            // 1) 덩어리별 바탕
            for (i = 0; i < d.comps.length; i++) {
                var c = d.comps[i];
                hb_compound(grp, layer, d.loops, c.loops, hb_fromRGB(c.rgb));
            }
            // 2) 원 쌍 브리지 (그라디언트)
            var stamp = String(new Date().getTime()).slice(-6);
            for (i = 0; i < d.pairs.length; i++) hb_pair(doc, grp, items, d.pairs[i], 'hy Blob ' + stamp + '-' + (i + 1));
            // 3) 원 (원래 색 그대로)
            for (i = 0; i < items.length; i++) {
                var dup = items[i].duplicate(grp, ElementPlacement.PLACEATBEGINNING);
                dup.hidden = false;
                dup.stroked = false;
            }
        }
        // 외곽선으로 클리핑
        grp = hb_clip(doc, grp, layer, d.loops, all);

        var srcs = items.slice();
        for (i = 0; i < HBLOB.lines.length; i++) {
            try { HBLOB.lines[i].typename; srcs.push(HBLOB.lines[i]); } catch (e) {}
        }
        for (i = 0; i < srcs.length; i++) {
            if (d.orig == 'hide') srcs[i].hidden = true;
            else if (d.orig == 'delete') srcs[i].remove();
        }
        if (d.orig == 'delete') { HBLOB.items = []; HBLOB.lines = []; }

        doc.selection = null;
        grp.selected = true;
        app.coordinateSystem = oldCS;
        return '{"ok":true,"pairs":' + (d.pairs ? d.pairs.length : 0) + '}';
    } catch (e) {
        try { app.coordinateSystem = oldCS; } catch (e2) {}
        return hb_err('만들지 못했습니다: ' + e.message + ' (줄 ' + e.line + ')');
    }
}

// 로컬(회전 전) 좌표로 만든 브리지에 가로 그라디언트를 걸고, 그라디언트째 회전
function hb_pair(doc, grp, items, pr, name) {
    var p = hb_addPath(grp.pathItems, pr.loop);
    var gb = p.geometricBounds, L = gb[0], W = gb[2] - gb[0];
    if (W <= 0) return;

    var g = doc.gradients.add();
    try { g.name = name; } catch (e) {}
    g.type = GradientType.LINEAR;
    var st = pr.stops;
    while (g.gradientStops.length < st.length) g.gradientStops.add();
    for (var s = 0; s < st.length; s++) {
        var loc = (pr.ox + st[s].x - L) / W * 100;
        loc = loc < 0 ? 0 : loc > 100 ? 100 : loc;
        var gs = g.gradientStops[s];
        gs.rampPoint = loc;
        gs.midPoint = 50;
        gs.color = st[s].c == 'i' ? items[pr.i].fillColor
                 : st[s].c == 'j' ? items[pr.j].fillColor
                 : hb_fromRGB(st[s].c);
    }
    var gc = new GradientColor();
    gc.gradient = g;
    p.filled = true;
    p.fillColor = gc;

    // 바운딩 중심 기준 회전 → 원 i 중심 기준 회전이 되도록 보정 이동
    var cx = (gb[0] + gb[2]) / 2 - pr.ox, cy = (gb[1] + gb[3]) / 2 - pr.oy;
    var a = pr.ang * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
    p.rotate(pr.ang, true, false, true, false, Transformation.CENTER);
    p.translate((cx * ca - cy * sa) - cx, (cx * sa + cy * ca) - cy, true, false, true, false);
}
