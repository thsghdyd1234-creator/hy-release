/* hy Offset — panel */
(function () {
  'use strict';

  var STORE = 'hyOffset.v1';

  var DEFAULTS = {
    dir: 'out', mode: 'equal', count: 5, gap: 5, ratio: 1.5,
    list: '5, 10, 20, 40', listBase: 'edge', join: 'round', keepSource: true,
    stroke: { on: true, w1: 0.5, w2: 0.5, c1: '#1e1e1e', c2: '#1e1e1e' },
    fill: { on: false, c1: '#2f5d8a', c2: '#e3ecf5' },
    opacity: { o1: 100, o2: 100 },
    dash: { mode: 'none', len: 2, gap: 1 },
    cross: { on: false, count: 2, angle: 0, reach: 'outer', extend: 3, type: 'center', w: 0.25, color: '#d0021b', scale: 1 },
    label: { on: false, basis: 'dist', scale: 1, unit: 'mm', showUnit: true, pos: 'top', size: 7, color: 'ring', withSource: false },
    _auto: true
  };

  // 스타일 프리셋 — 선·칠·점선과 중심선·라벨 켜짐을 정함 (거리·개수는 그대로). 라벨은 어느 프리셋도 켜지 않음
  var PRESETS = [
    { name: '기본 선', set: {
      stroke: { on: true, w1: 0.5, w2: 0.5, c1: '#1e1e1e', c2: '#1e1e1e' }, fill: { on: false },
      opacity: { o1: 100, o2: 100 }, dash: { mode: 'none' },
      cross: { on: false }, label: { on: false } } },
    { name: '점점 옅게', set: {
      stroke: { on: true, w1: 1, w2: 0.25, c1: '#1e1e1e', c2: '#bdbdbd' }, fill: { on: false },
      opacity: { o1: 100, o2: 100 }, dash: { mode: 'none' },
      cross: { on: false }, label: { on: false } } },
    { name: '채움 단계', set: {
      stroke: { on: false }, fill: { on: true, c1: '#2f5d8a', c2: '#e3ecf5' },
      opacity: { o1: 100, o2: 100 }, dash: { mode: 'none' },
      cross: { on: false }, label: { on: false } } },
    { name: '영향권', set: {
      stroke: { on: true, w1: 0.35, w2: 0.35, c1: '#c0392b', c2: '#c0392b' }, fill: { on: false },
      opacity: { o1: 100, o2: 100 }, dash: { mode: 'all', len: 1.5, gap: 1 },
      cross: { on: true, type: 'center', color: '#c0392b' }, label: { on: false } } }
  ];

  /* ---------- 상태 ---------- */
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function merge(base, over) {
    var out = clone(base);
    (function walk(dst, src) {
      Object.keys(src || {}).forEach(function (k) {
        if (src[k] && typeof src[k] === 'object' && !Array.isArray(src[k]) && dst[k] && typeof dst[k] === 'object') walk(dst[k], src[k]);
        else if (k in dst) dst[k] = src[k];
      });
    })(out, over);
    return out;
  }
  // 지난 설정을 이어 쓰되 라벨은 패널을 열 때마다 꺼진 채로 시작
  function load() {
    var st = clone(DEFAULTS);
    try { var s = localStorage.getItem(STORE); if (s) st = merge(DEFAULTS, JSON.parse(s)); } catch (e) {}
    st.label.on = false;
    return st;
  }
  function save() { try { localStorage.setItem(STORE, JSON.stringify(S)); } catch (e) {} }

  var S = load();

  function get(path) {
    var o = S, ks = path.split('.');
    for (var i = 0; i < ks.length; i++) { if (o == null) return undefined; o = o[ks[i]]; }
    return o;
  }
  function set(path, v) {
    var o = S, ks = path.split('.');
    for (var i = 0; i < ks.length - 1; i++) o = o[ks[i]];
    o[ks[ks.length - 1]] = v;
  }
  function params() { var p = clone(S); delete p._auto; return p; }

  /* ---------- CEP ---------- */
  var cep = window.__adobe_cep__;
  function jsx(script) {
    return new Promise(function (res) {
      if (!cep) { res('err|일러스트레이터 밖에서 열렸습니다'); return; }
      cep.evalScript(script, function (r) { res(r == null ? '' : String(r)); });
    });
  }

  function applyTheme() {
    if (!cep) return;
    try {
      var env = JSON.parse(cep.getHostEnvironment());
      var c = env.appSkinInfo.panelBackgroundColor.color;
      document.documentElement.style.setProperty('--bg', 'rgb(' + Math.round(c.red) + ',' + Math.round(c.green) + ',' + Math.round(c.blue) + ')');
      var lum = c.red * 0.299 + c.green * 0.587 + c.blue * 0.114;
      document.documentElement.setAttribute('data-theme', lum > 128 ? 'light' : 'dark');
    } catch (e) {}
  }

  /* ---------- 표시 ---------- */
  var $ = function (q, r) { return (r || document).querySelector(q); };
  var $$ = function (q, r) { return Array.prototype.slice.call((r || document).querySelectorAll(q)); };

  function fmt(v, dec) {
    if (typeof v !== 'number' || isNaN(v)) return '';
    return String(parseFloat(v.toFixed(dec)));
  }

  function evalCond(expr) {
    var m = expr.match(/^([\w.]+)\s*(==|!=)\s*(.+)$/);
    if (m) {
      var v = String(get(m[1]));
      return m[2] === '==' ? v === m[3] : v !== m[3];
    }
    return !!get(expr);
  }

  function refresh() {
    $$('.seg[data-key]').forEach(function (seg) {
      var v = String(get(seg.dataset.key));
      $$('button', seg).forEach(function (b) { b.classList.toggle('on', b.dataset.v === v); });
    });
    $$('.sw[data-key]').forEach(function (sw) { sw.classList.toggle('on', !!get(sw.dataset.key)); });
    $$('.num[data-key]').forEach(function (el) {
      if (el.classList.contains('editing')) return;
      $('input', el).value = fmt(get(el.dataset.key), +el.dataset.dec || 0);
    });
    $$('input.text[data-key]').forEach(function (el) {
      if (document.activeElement !== el) el.value = get(el.dataset.key);
    });
    $$('input.cl[data-key]').forEach(function (el) { el.value = get(el.dataset.key); });
    $$('[data-show]').forEach(function (el) {
      // 부모 섹션의 조건까지 고려
      var ok = evalCond(el.dataset.show);
      el.classList.toggle('hide', !ok);
    });
    drawPreview();
  }

  /* ---------- 변경 ---------- */
  var autoTimer = null;
  function changed(key) {
    save();
    refresh();
    if (key === '_auto') return;
    if (S._auto) {
      clearTimeout(autoTimer);
      autoTimer = setTimeout(function () { apply(true); }, 260);
    }
  }
  function setVal(key, v) { set(key, v); changed(key); }

  /* ---------- 컨트롤 ---------- */
  function bindSeg(seg) {
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b || !seg.contains(b)) return;
      var v = seg.dataset.type === 'num' ? parseFloat(b.dataset.v) : b.dataset.v;
      setVal(seg.dataset.key, v);
    });
  }
  function bindSwitch(sw) {
    sw.addEventListener('click', function () { setVal(sw.dataset.key, !get(sw.dataset.key)); });
  }
  function bindColor(el) {
    el.addEventListener('input', function () { setVal(el.dataset.key, el.value); });
  }
  function bindText(el) {
    var t = null;
    el.addEventListener('input', function () {
      clearTimeout(t);
      t = setTimeout(function () { setVal(el.dataset.key, el.value); }, 300);
    });
    el.addEventListener('keydown', function (e) { if (e.key === 'Enter') el.blur(); });
    el.addEventListener('blur', function () { clearTimeout(t); if (el.value !== get(el.dataset.key)) setVal(el.dataset.key, el.value); });
  }

  // 숫자: 좌우로 끌어 조절(Shift ×10, Alt ×0.1), 클릭하면 입력, 위·아래 화살표로 한 단계
  function bindNum(el) {
    var key = el.dataset.key;
    var step = parseFloat(el.dataset.step) || 1;
    var min = el.dataset.min !== undefined ? parseFloat(el.dataset.min) : -Infinity;
    var max = el.dataset.max !== undefined ? parseFloat(el.dataset.max) : Infinity;
    var dec = parseInt(el.dataset.dec, 10) || 0;
    var inp = $('input', el);
    inp.readOnly = true;

    function norm(v) {
      v = Math.min(max, Math.max(min, v));
      return parseFloat(v.toFixed(dec));
    }
    function startEdit() {
      el.classList.add('editing');
      inp.readOnly = false;
      inp.focus();
      inp.select();
    }
    function endEdit(commit) {
      if (!el.classList.contains('editing')) return;
      el.classList.remove('editing');
      inp.readOnly = true;
      var v = parseFloat(String(inp.value).replace(',', '.'));
      if (commit && !isNaN(v) && norm(v) !== get(key)) setVal(key, norm(v));
      else refresh();
    }
    function nudge(dir, mult) { setVal(key, norm((get(key) || 0) + dir * step * mult)); }

    el.addEventListener('mousedown', function (e) {
      if (el.classList.contains('editing') || e.button !== 0) return;
      e.preventDefault();
      var x0 = e.clientX, v0 = get(key) || 0, dragging = false;
      function move(ev) {
        var dx = ev.clientX - x0;
        if (!dragging && Math.abs(dx) > 3) { dragging = true; el.classList.add('drag'); }
        if (dragging) {
          var mult = ev.shiftKey ? 10 : (ev.altKey ? 0.1 : 1);
          var v = norm(v0 + Math.round(dx / 4) * step * mult);
          if (v !== get(key)) setVal(key, v);
        }
      }
      function up() {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        el.classList.remove('drag');
        if (!dragging) startEdit();
      }
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    });
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { endEdit(true); inp.blur(); }
      else if (e.key === 'Escape') { endEdit(false); inp.blur(); }
      else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        var cur = parseFloat(inp.value);
        if (!isNaN(cur)) set(key, norm(cur));
        nudge(e.key === 'ArrowUp' ? 1 : -1, e.shiftKey ? 10 : 1);
        inp.value = fmt(get(key), dec);
        inp.select();
      }
    });
    inp.addEventListener('blur', function () { endEdit(true); });
    el.addEventListener('wheel', function (e) {
      if (!el.classList.contains('editing')) return;
      e.preventDefault();
      nudge(e.deltaY < 0 ? 1 : -1, e.shiftKey ? 10 : 1);
      inp.value = fmt(get(key), dec);
    }, { passive: false });
  }

  /* ---------- 미리보기 ---------- */
  function hex(h) {
    h = String(h || '#000').replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function mix(a, b, t) {
    var x = hex(a), y = hex(b);
    return 'rgb(' + Math.round(lerp(x[0], y[0], t)) + ',' + Math.round(lerp(x[1], y[1], t)) + ',' + Math.round(lerp(x[2], y[2], t)) + ')';
  }
  function listVals(s) {
    return String(s || '').split(/[\s,;\/]+/).map(parseFloat).filter(function (v) { return !isNaN(v) && v > 0; });
  }
  function uniqSort(a) {
    a.sort(function (x, y) { return x - y; });
    return a.filter(function (v, i) { return v > 0.001 && (i === 0 || Math.abs(v - a[i - 1]) > 0.001); });
  }

  // 원을 원본으로 가정한 미리보기용 계획 (mm)
  function previewPlan(P) {
    var pos = [], neg = [], r0, i;
    if (P.mode === 'list') {
      var vals = listVals(P.list);
      if (!vals.length) vals = [5];
      var mx = Math.max.apply(null, vals);
      if (P.listBase === 'center') {
        r0 = Math.min.apply(null, vals) * 0.45;
        vals.forEach(function (v) { if (v > r0) pos.push(v - r0); });
      } else {
        r0 = P.dir === 'out' ? Math.max(mx * 0.35, 2) : mx * 1.12;
        vals.forEach(function (v) { if (P.dir !== 'in') pos.push(v); if (P.dir !== 'out') neg.push(v); });
      }
    } else {
      var n = Math.max(1, Math.min(100, Math.round(P.count || 1)));
      var g = Math.max(0.01, P.gap || 1), acc = 0, ds = [];
      for (i = 0; i < n; i++) { acc += g; ds.push(acc); if (P.mode === 'ratio') g *= (P.ratio || 1); }
      r0 = P.dir === 'out' ? Math.max(acc * 0.32, (P.gap || 1) * 1.2) : acc * 1.12 + (P.gap || 1) * 0.6;
      ds.forEach(function (d) { if (P.dir !== 'in') pos.push(d); if (P.dir !== 'out') neg.push(d); });
    }
    pos = uniqSort(pos);
    neg = uniqSort(neg).filter(function (d) { return d < r0 - 0.001; });
    return { r0: r0, pos: pos, neg: neg };
  }

  function ringStyle(P, t, rank) {
    var st = { stroke: P.stroke.on, fill: P.fill.on };
    if (!st.stroke && !st.fill) st.stroke = true;
    st.w = lerp(+P.stroke.w1 || 0, +P.stroke.w2 || 0, t);
    st.sc = mix(P.stroke.c1, P.stroke.c2, t);
    st.fc = mix(P.fill.c1, P.fill.c2, t);
    st.op = Math.max(0, Math.min(100, lerp(+P.opacity.o1, +P.opacity.o2, t))) / 100;
    st.dash = P.dash.mode === 'all' || (P.dash.mode === 'alt' && rank % 2 === 1);
    return st;
  }

  function labelText(mm, L) {
    var v = mm * Math.max(0, +L.scale || 0);
    if (L.unit === 'm') v /= 1000; else if (L.unit === 'km') v /= 1e6;
    v = Math.round(v * 100) / 100;
    var s = v.toLocaleString('en-US', { maximumFractionDigits: 2 });
    return s + (L.showUnit === false ? '' : L.unit);
  }

  function svgRings(P, W, H, opts) {
    opts = opts || {};
    var pl = previewPlan(P);
    var cx = W / 2, cy = H / 2;
    var maxR = pl.r0 + (pl.pos.length ? pl.pos[pl.pos.length - 1] : 0);
    var reachExtra = (P.cross.on && !opts.thumb) ? Math.max(0, +P.cross.extend || 0) : 0;
    var room = (H / 2) - (opts.thumb ? 2 : 6) - ((P.label.on && !opts.thumb && P.label.pos === 'top') ? 8 : 0);
    var sc = room / Math.max(0.001, maxR + reachExtra);
    var out = [], i, e;

    var rings = [];
    pl.pos.forEach(function (d, k) { rings.push({ d: d, rank: k, t: pl.pos.length > 1 ? k / (pl.pos.length - 1) : 0 }); });
    pl.neg.forEach(function (d, k) { rings.push({ d: -d, rank: k, t: pl.neg.length > 1 ? k / (pl.neg.length - 1) : 0 }); });
    rings.sort(function (a, b) { return b.d - a.d; });   // 큰 것부터 그려서 작은 것이 위로

    var srcDrawn = false;
    function drawSource() {
      srcDrawn = true;
      if (P.keepSource === false) return;
      out.push('<circle cx="' + cx + '" cy="' + cy + '" r="' + (pl.r0 * sc).toFixed(2) + '" fill="none" stroke="#9a9a9a" stroke-width="' + (opts.thumb ? 0.8 : 1) + '"/>');
    }
    for (i = 0; i < rings.length; i++) {
      e = rings[i];
      if (!srcDrawn && e.d < 0) drawSource();
      var st = ringStyle(P, e.t, e.rank);
      var r = (pl.r0 + e.d) * sc;
      if (r <= 0.2) continue;
      var w = st.stroke ? Math.max(0.35, Math.min(opts.thumb ? 1.6 : 3.5, st.w * (opts.thumb ? 0.9 : 1.1))) : 0;
      var dashAttr = '';
      if (st.stroke && st.dash) {
        var a = Math.max(1.2, (+P.dash.len || 1) * sc), b = Math.max(1, (+P.dash.gap || 1) * sc);
        if (opts.thumb) { a = 2; b = 1.4; }
        dashAttr = ' stroke-dasharray="' + a.toFixed(2) + ' ' + b.toFixed(2) + '"';
      }
      out.push('<circle cx="' + cx + '" cy="' + cy + '" r="' + r.toFixed(2) + '" fill="' + (st.fill ? st.fc : 'none') +
        '" stroke="' + (st.stroke ? st.sc : 'none') + '" stroke-width="' + w.toFixed(2) + '" opacity="' + st.op.toFixed(2) + '"' + dashAttr + '/>');
      e.r = r; e.st = st;
    }
    if (!srcDrawn) drawSource();

    if (P.cross.on) {
      var C = P.cross, n = Math.max(1, Math.round(C.count || 1));
      var R = (C.reach === 'outer' && pl.pos.length ? maxR : pl.r0) * sc + (opts.thumb ? 1.5 : (+C.extend || 0) * sc);
      var k = +C.scale || 1;
      var da = C.type === 'center' ? (opts.thumb ? '3 1 0.8 1' : (6 * k) + ' ' + (1.6 * k) + ' ' + (1.2 * k) + ' ' + (1.6 * k)) :
               C.type === 'dash' ? (opts.thumb ? '1.5 1' : (2.5 * k) + ' ' + (2 * k)) : '';
      for (i = 0; i < n; i++) {
        var ang = ((+C.angle || 0) + i * 180 / n) * Math.PI / 180;
        var dx = Math.cos(ang) * R, dy = -Math.sin(ang) * R;
        out.push('<line x1="' + (cx - dx).toFixed(2) + '" y1="' + (cy - dy).toFixed(2) + '" x2="' + (cx + dx).toFixed(2) + '" y2="' + (cy + dy).toFixed(2) +
          '" stroke="' + C.color + '" stroke-width="' + (opts.thumb ? 0.7 : Math.max(0.6, Math.min(2.5, (+C.w || 0.25) * 2))) + '"' + (da ? ' stroke-dasharray="' + da + '"' : '') + '/>');
      }
    }

    if (P.label.on && !opts.thumb) {
      var L = P.label, fs = 8;
      var labs = rings.filter(function (x) { return x.r; });
      if (L.basis === 'radius' && L.withSource) labs.push({ d: 0, r: pl.r0 * sc, st: null, src: true });
      labs.forEach(function (x) {
        if (x.src && L.basis !== 'radius') return;
        var mm = L.basis === 'radius' ? (pl.r0 + x.d) : Math.abs(x.d);
        var col = (L.color === 'ring' && x.st) ? (x.st.stroke ? x.st.sc : x.st.fc) : '#111';
        var tx = cx, ty = cy - x.r - 2.5, anchor = 'middle';
        if (L.pos === 'bottom') ty = cy + x.r + fs;
        else if (L.pos === 'right') { tx = cx + x.r + 2.5; ty = cy + 3; anchor = 'start'; }
        else if (L.pos === 'left') { tx = cx - x.r - 2.5; ty = cy + 3; anchor = 'end'; }
        out.push('<text x="' + tx.toFixed(2) + '" y="' + ty.toFixed(2) + '" font-size="' + fs + '" text-anchor="' + anchor + '" fill="' + col + '" font-family="Segoe UI, sans-serif">' + labelText(mm, L) + '</text>');
      });
    }
    return out.join('');
  }

  function drawPreview() {
    var svg = $('#pv');
    if (svg) svg.innerHTML = svgRings(params(), 268, 128);
  }

  function buildPresets() {
    var box = $('#presets');
    PRESETS.forEach(function (p) {
      var demo = merge(merge(DEFAULTS, { dir: 'out', mode: 'equal', count: 4, gap: 3, keepSource: true }), p.set);
      demo.label.on = false;
      var b = document.createElement('button');
      b.className = 'preset';
      b.title = p.name + ' — 스타일만 바뀌고 거리·개수는 그대로입니다';
      b.innerHTML = '<svg viewBox="0 0 30 30">' + svgRings(demo, 30, 30, { thumb: true }) + '</svg><span>' + p.name + '</span>';
      b.addEventListener('click', function () {
        S = merge(S, p.set);
        changed('preset');
        status(p.name + ' 스타일을 적용했습니다', '');
      });
      box.appendChild(b);
    });
  }

  /* ---------- 실행 ---------- */
  function status(msg, kind) {
    var el = $('#status');
    el.textContent = msg;
    el.className = 'status' + (kind ? ' ' + kind : '');
  }

  var busy = false, queued = null;
  function apply(updateOnly) {
    if (busy) { queued = (queued === false || !updateOnly) ? false : true; return; }
    busy = true;
    var enc = encodeURIComponent(JSON.stringify(params()));
    jsx('hyOffset.run("' + enc + '",' + (updateOnly ? 'true' : 'false') + ')').then(function (r) {
      busy = false;
      report(r, updateOnly);
      if (queued !== null) { var q = queued; queued = null; apply(q); }
    });
  }

  function report(r, updateOnly) {
    if (r === 'skip') { if (!updateOnly) status('도형을 선택하세요', 'err'); return; }
    if (/^ok\|/.test(r)) {
      var p = r.split('|'), up = +p[1], mk = +p[2], sk = +p[3], gl = +p[4] || 0, msg = [];
      if (mk) msg.push(mk + '개 만듦');
      if (up) msg.push(up + '개 갱신');
      if (sk) msg.push(sk + '개 건너뜀(패스 아님)');
      if (gl) msg.push('hy Gradient 색 유지');
      status(msg.join(' · ') || '완료', 'ok');
      showGrad(gl);
      return;
    }
    if (/^err\|/.test(r)) { status(r.slice(4), 'err'); return; }
    if (/EvalScript/i.test(r)) { status('스크립트를 불러오지 못했습니다 — 패널을 닫았다 다시 열어 보세요', 'err'); return; }
    status(r || '응답 없음', 'err');
  }

  // hy Gradient로 칠한 그룹이면 [색 풀기] 줄을 보여 줌
  function showGrad(n) { $('#gradRow').style.display = n > 0 ? '' : 'none'; }
  function checkGrad() { jsx('hyOffset.gradState()').then(function (r) { showGrad(parseInt(r, 10) || 0); }); }
  function unlinkGrad() {
    jsx('hyOffset.unlinkGrad()').then(function (r) {
      if (/^ok\|/.test(r)) {
        var n = +r.split('|')[1];
        status(n ? 'hy Gradient 색을 풀고 단계 스타일로 다시 만들었습니다' : 'hy Gradient 색이 걸린 그룹이 없습니다', n ? 'ok' : '');
        showGrad(0);
        return;
      }
      status(/^err\|/.test(r) ? r.slice(4) : (r || '응답 없음'), 'err');
    });
  }

  function loadFromSelection() {
    jsx('hyOffset.load()').then(function (r) {
      if (!r || /EvalScript/i.test(r)) { status('hy Offset으로 만든 그룹을 선택하세요', 'err'); return; }
      try {
        var p = JSON.parse(decodeURIComponent(r));
        var auto = S._auto;
        S = merge(DEFAULTS, p);
        S._auto = auto;
        save();
        refresh();
        status('선택한 그룹의 설정을 불러왔습니다', 'ok');
        checkGrad();
      } catch (e) {
        status('설정을 읽지 못했습니다', 'err');
      }
    });
  }

  /* ---------- 시작 ---------- */
  applyTheme();
  if (cep) {
    try { cep.addEventListener('com.adobe.csxs.events.ThemeColorChanged', applyTheme); } catch (e) {}
  }
  $$('.seg[data-key]').forEach(bindSeg);
  $$('.sw[data-key]').forEach(bindSwitch);
  $$('.num[data-key]').forEach(bindNum);
  $$('input.cl[data-key]').forEach(bindColor);
  $$('input.text[data-key]').forEach(bindText);
  $('#btnApply').addEventListener('click', function () { apply(false); });
  $('#btnLoad').addEventListener('click', loadFromSelection);
  $('#btnUnlinkGrad').addEventListener('click', unlinkGrad);
  buildPresets();
  refresh();

  // 디버그·테스트용(패널 UI에는 노출하지 않음)
  window.__hyOffset = { state: function () { return S; }, params: params, previewPlan: previewPlan };
})();
