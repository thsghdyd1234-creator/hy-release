/*
  hy Offset — host script (ExtendScript / ES3)
  오프셋 반복 · 단계 스타일 · 중심선 · 라벨

  패널 → hyOffset.run(encodedJSON, updateOnly)
         hyOffset.load()
  결과 문자열:  ok|갱신수|생성수|건너뜀수   skip   err|메시지
*/
var hyOffset = (function () {
  var MM = 2.834645669291339;          // 1mm = 2.8346pt
  var TAG_P = 'hyOffsetParams';        // 결과 그룹에 저장하는 설정값
  var TAG_R = 'hyOffsetRole';          // 원본 도형 표시
  var TAG_G = 'hyGradPaint';           // hy Gradient가 링을 칠한 방식 (다시 만들 때 그대로 다시 칠함)
  var K = 0.5522847498;                // 원 베지어 핸들 비율

  /* ---------- 공통 ---------- */
  function parseParams(enc) {
    return eval('(' + decodeURIComponent(enc) + ')');
  }
  function num(v, d) { v = parseFloat(v); return isNaN(v) ? d : v; }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function uid(o) { try { return o.uuid; } catch (e) { return null; } }
  function dist(a, b) { var x = a[0] - b[0], y = a[1] - b[1]; return Math.sqrt(x * x + y * y); }

  function getTag(item, name) {
    try {
      var tags = item.tags;
      for (var i = 0; i < tags.length; i++) if (tags[i].name == name) return tags[i].value;
    } catch (e) {}
    return null;
  }
  function setTag(item, name, value) {
    var tags = item.tags;
    for (var i = 0; i < tags.length; i++) {
      if (tags[i].name == name) { tags[i].value = value; return; }
    }
    var t = tags.add();
    t.name = name;
    t.value = value;
  }
  function removeTag(item, name) {
    try {
      for (var i = item.tags.length - 1; i >= 0; i--) if (item.tags[i].name == name) item.tags[i].remove();
    } catch (e) {}
  }
  function clearTags(item) {
    try {
      for (var i = item.tags.length - 1; i >= 0; i--) item.tags[i].remove();
    } catch (e) {}
  }

  /* ---------- 색 ---------- */
  function hexToRGB(h) {
    h = String(h || '#000000').replace('#', '');
    if (h.length == 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var n = parseInt(h, 16);
    if (isNaN(n)) n = 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function lerpRGB(a, b, t) {
    return [Math.round(lerp(a[0], b[0], t)), Math.round(lerp(a[1], b[1], t)), Math.round(lerp(a[2], b[2], t))];
  }
  function makeColor(doc, rgb) {
    if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
      var c = new CMYKColor();
      var v = null;
      if (rgb[0] == 0 && rgb[1] == 0 && rgb[2] == 0) {
        v = [0, 0, 0, 100];
      } else {
        try {
          v = app.convertSampleColor(ImageColorSpace.RGB, [rgb[0], rgb[1], rgb[2]],
                                     ImageColorSpace.CMYK, ColorConvertPurpose.defaultpurpose);
        } catch (e) { v = null; }
        if (!v || v.length < 4) {
          var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255;
          var k = 1 - Math.max(r, Math.max(g, b));
          var d = k < 1 ? (1 - k) : 1;
          v = [(1 - r - k) / d * 100, (1 - g - k) / d * 100, (1 - b - k) / d * 100, k * 100];
        }
      }
      c.cyan = v[0]; c.magenta = v[1]; c.yellow = v[2]; c.black = v[3];
      return c;
    }
    var rc = new RGBColor();
    rc.red = rgb[0]; rc.green = rgb[1]; rc.blue = rgb[2];
    return rc;
  }

  /* ---------- 원본 도형 분석 ---------- */
  function isShape(it) {
    return it && (it.typename == 'PathItem' || it.typename == 'CompoundPathItem');
  }

  function analyze(item) {
    var b = item.geometricBounds; // [left, top, right, bottom]
    var info = {
      kind: 'path',
      l: b[0], t: b[1], r: b[2], b: b[3],
      cx: (b[0] + b[2]) / 2, cy: (b[1] + b[3]) / 2,
      rx: (b[2] - b[0]) / 2, ry: (b[1] - b[3]) / 2
    };
    if (item.typename == 'PathItem' && isEllipse(item, info)) info.kind = 'ellipse';
    return info;
  }

  // 축에 맞춘 원·타원(앵커 4개, 핸들 비율 0.5523)인지 확인
  function isEllipse(p, info) {
    try {
      if (!p.closed) return false;
      var pts = p.pathPoints;
      if (pts.length != 4) return false;
      var rx = info.rx, ry = info.ry;
      if (rx <= 0 || ry <= 0) return false;
      var tol = Math.max(rx, ry) * 0.01 + 0.01;
      for (var i = 0; i < 4; i++) {
        var a = pts[i].anchor, L = pts[i].leftDirection, R = pts[i].rightDirection;
        var dx = a[0] - info.cx, dy = a[1] - info.cy;
        var onH = Math.abs(dy) < tol && Math.abs(Math.abs(dx) - rx) < tol;   // 좌·우 끝점
        var onV = Math.abs(dx) < tol && Math.abs(Math.abs(dy) - ry) < tol;   // 위·아래 끝점
        if (!onH && !onV) return false;
        var expLen = onH ? K * ry : K * rx;
        var htol = tol * 2 + expLen * 0.05;
        if (Math.abs(dist(a, L) - expLen) > htol || Math.abs(dist(a, R) - expLen) > htol) return false;
        if (onH && (Math.abs(L[0] - a[0]) > tol || Math.abs(R[0] - a[0]) > tol)) return false;
        if (onV && (Math.abs(L[1] - a[1]) > tol || Math.abs(R[1] - a[1]) > tol)) return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ---------- 거리 계획 ---------- */
  function parseList(s) {
    var parts = String(s || '').split(/[\s,;\/]+/), out = [], i, v;
    for (i = 0; i < parts.length; i++) {
      v = parseFloat(parts[i]);
      if (!isNaN(v) && v > 0) out.push(v);
    }
    return out;
  }
  function sortUnique(arr) {
    arr.sort(function (a, b) { return a - b; });
    var out = [], i;
    for (i = 0; i < arr.length; i++) {
      if (arr[i] > 0.01 && (out.length == 0 || Math.abs(arr[i] - out[out.length - 1]) > 0.01)) out.push(arr[i]);
    }
    return out;
  }

  // pos: 바깥 오프셋(pt, 가까운 순)  neg: 안쪽 오프셋 크기(pt, 가까운 순)
  function plan(P, info) {
    var pos = [], neg = [], i, v;
    var dir = P.dir || 'out';
    if (P.mode == 'list') {
      var vals = parseList(P.list);
      var fromCenter = (P.listBase == 'center' && info.kind == 'ellipse');
      for (i = 0; i < vals.length; i++) {
        v = vals[i] * MM;
        if (fromCenter) {
          v = v - info.rx;
          if (v > 0.01) pos.push(v);
          else if (v < -0.01) neg.push(-v);
        } else {
          if (dir != 'in') pos.push(v);
          if (dir != 'out') neg.push(v);
        }
      }
    } else {
      var n = clamp(Math.round(num(P.count, 5)), 1, 100);
      var g = Math.max(0.01, num(P.gap, 5)) * MM;
      var ratio = clamp(num(P.ratio, 1.5), 0.1, 10);
      var acc = 0;
      for (i = 0; i < n; i++) {
        acc += g;
        if (dir != 'in') pos.push(acc);
        if (dir != 'out') neg.push(acc);
        if (P.mode == 'ratio') g *= ratio;
      }
    }
    return { pos: sortUnique(pos), neg: sortUnique(neg) };
  }

  /* ---------- 링 만들기 ---------- */
  function unwrap(item) {
    var guard = 0;
    while (item && item.typename == 'GroupItem' && item.pageItems.length == 1 && guard++ < 10) {
      var child = item.pageItems[0];
      child.move(item, ElementPlacement.PLACEBEFORE);
      item.remove();
      item = child;
    }
    return item;
  }
  function isEmpty(item) {
    if (!item) return true;
    try {
      if (item.typename == 'GroupItem' && item.pageItems.length == 0) return true;
      if (item.typename == 'CompoundPathItem' && item.pathItems.length == 0) return true;
      var b = item.geometricBounds;
      return (b[2] - b[0]) < 0.05 || (b[1] - b[3]) < 0.05;
    } catch (e) {
      return true;
    }
  }

  // 일반 도형: '패스 이동(Offset Path)' 효과를 걸고 모양 확장
  function offsetByEffect(container, src, d, join, doc) {
    var dup = src.duplicate(container, ElementPlacement.PLACEATBEGINNING);
    clearTags(dup);
    try { dup.locked = false; } catch (e1) {}
    dup.hidden = false;
    doc.selection = null;
    dup.selected = true;
    var jt = join == 'miter' ? 2 : (join == 'bevel' ? 1 : 0);
    dup.applyEffect('<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 4 R ofst ' +
                    d.toFixed(4) + ' I jntp ' + jt + ' "/></LiveEffect>');
    doc.selection = null;
    dup.selected = true;
    app.executeMenuCommand('expandStyle');
    var sel = doc.selection;
    doc.selection = null;
    if (!sel || sel.length == 0) return null;
    var res = unwrap(sel[0]);
    if (isEmpty(res)) {
      try { res.remove(); } catch (e2) {}
      return null;
    }
    clearTags(res);
    return res;
  }

  function makeRing(container, src, info, d, join, doc) {
    if (info.kind == 'ellipse') {
      var rx = info.rx + d, ry = info.ry + d;
      if (rx <= 0.05 || ry <= 0.05) return null;
      return container.pathItems.ellipse(info.cy + ry, info.cx - rx, rx * 2, ry * 2);
    }
    return offsetByEffect(container, src, d, join, doc);
  }

  function ringBounds(e, info) {
    if (info.kind == 'ellipse') {
      var rx = info.rx + e.d, ry = info.ry + e.d;
      return { l: info.cx - rx, t: info.cy + ry, r: info.cx + rx, b: info.cy - ry };
    }
    var b = e.item.geometricBounds;
    return { l: b[0], t: b[1], r: b[2], b: b[3] };
  }

  /* ---------- 단계 스타일 ---------- */
  function ringStyle(P, t, rank, doc) {
    var S = P.stroke || {}, F = P.fill || {}, O = P.opacity || {}, D = P.dash || {};
    var st = { stroke: !!S.on, fill: !!F.on };
    if (!st.stroke && !st.fill) st.stroke = true;   // 둘 다 끄면 보이지 않으므로 선을 살림
    if (st.stroke) {
      st.w = Math.max(0, lerp(num(S.w1, 0.5), num(S.w2, 0.5), t));
      st.sRGB = lerpRGB(hexToRGB(S.c1), hexToRGB(S.c2), t);
      st.sc = makeColor(doc, st.sRGB);
    }
    if (st.fill) {
      st.fRGB = lerpRGB(hexToRGB(F.c1), hexToRGB(F.c2), t);
      st.fc = makeColor(doc, st.fRGB);
    }
    st.opacity = clamp(lerp(num(O.o1, 100), num(O.o2, 100), t), 0, 100);
    var dashOn = D.mode == 'all' || (D.mode == 'alt' && rank % 2 == 1);
    st.dash = dashOn ? [Math.max(0.01, num(D.len, 2)) * MM, Math.max(0.01, num(D.gap, 1)) * MM] : [];
    return st;
  }

  function paintPath(p, st) {
    if (st.fill) { p.filled = true; p.fillColor = st.fc; } else { p.filled = false; }
    if (st.stroke) {
      p.stroked = true;
      p.strokeWidth = st.w;
      p.strokeColor = st.sc;
      p.strokeDashes = st.dash;
    } else {
      p.stroked = false;
    }
  }
  function paint(item, st) {
    var tn = item.typename, i;
    if (tn == 'PathItem') paintPath(item, st);
    else if (tn == 'CompoundPathItem') { if (item.pathItems.length) paintPath(item.pathItems[0], st); }
    else if (tn == 'GroupItem') { for (i = 0; i < item.pageItems.length; i++) paint(item.pageItems[i], st); }
  }

  /* ---------- hy Gradient 색 유지 ----------
     hy Gradient가 이 그룹의 링을 칠하면 그룹에 TAG_G(JSON)를 남긴다. 형식은 hy-gradient jsx/hyGradient.jsx 의
     'hy Offset 연동' 주석과 같다 (grad: 스와치 이름·종류·각도·걸치기 / dist: 순서·간격·색표 101색 / solid: 색).
     칠할 단위 = '링' 묶음 안의 보이는 객체 (숨긴 원본 제외) — hy Gradient와 같은 규칙. */
  function gpUnits(rings) {
    var out = [], i, it;
    for (i = 0; i < rings.pageItems.length; i++) {
      it = rings.pageItems[i];
      var hid = false;
      try { hid = it.hidden; } catch (e) {}
      if (!hid) out.push(it);
    }
    return out;
  }
  function gpLeaves(it, acc) {
    var t = it.typename, i;
    if (t == 'GroupItem') { for (i = 0; i < it.pageItems.length; i++) gpLeaves(it.pageItems[i], acc); }
    else if (t == 'CompoundPathItem') { for (i = 0; i < it.pathItems.length; i++) acc.push(it.pathItems[i]); }
    else if (t == 'PathItem') acc.push(it);
  }
  function gpSet(it, target, makeFn) {
    var ps = [], i;
    gpLeaves(it, ps);
    for (i = 0; i < ps.length; i++) {
      if (target == 'stroke') { ps[i].stroked = true; ps[i].strokeColor = makeFn(); }
      else { ps[i].filled = true; ps[i].fillColor = makeFn(); }
    }
  }
  function gpUnion(units) {
    var u = null, i, b;
    for (i = 0; i < units.length; i++) {
      b = units[i].geometricBounds;
      if (!u) u = [b[0], b[1], b[2], b[3]];
      else { u[0] = Math.min(u[0], b[0]); u[1] = Math.max(u[1], b[1]); u[2] = Math.max(u[2], b[2]); u[3] = Math.min(u[3], b[3]); }
    }
    return u;
  }
  function gpHex(lut, k) { return hexToRGB(lut.substring(k * 6, k * 6 + 6)); }

  // 그라디언트 방향 맞추기 — hy Gradient hyGrad_fit 과 같은 계산
  function gpFit(it, G, U) {
    var lin = G.type != 'radial';
    if (!lin && !U) return;
    var b = it.geometricBounds;
    var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, w = Math.max(b[2] - b[0], 0.01);
    var p0x = lin ? b[0] : cx, p0y = cy, len0 = lin ? w : w / 2;
    var r = U || b, rcx = (r[0] + r[2]) / 2, rcy = (r[1] + r[3]) / 2;
    var rw = Math.max(r[2] - r[0], 0.01), rh = Math.max(r[1] - r[3], 0.01);
    var ang = lin ? num(G.angle, 0) : 0, th = ang * Math.PI / 180, ux = Math.cos(th), uy = Math.sin(th);
    var lenD, sx, sy;
    if (lin) { lenD = Math.abs(rw * ux) + Math.abs(rh * uy); sx = rcx - ux * lenD / 2; sy = rcy - uy * lenD / 2; }
    else { lenD = Math.max(rw, rh) / 2; sx = rcx; sy = rcy; }
    if (Math.abs(ang) > 0.01) {
      it.rotate(ang, false, false, true, false, Transformation.CENTER);
      var dx = p0x - cx, dy = p0y - cy;
      p0x = cx + dx * ux - dy * uy; p0y = cy + dx * uy + dy * ux;
    }
    var k = lenD / len0;
    if (Math.abs(k - 1) > 1e-4) {
      it.resize(k * 100, k * 100, false, false, true, false, 100, Transformation.CENTER);
      p0x = cx + (p0x - cx) * k; p0y = cy + (p0y - cy) * k;
    }
    var tx = sx - p0x, ty = sy - p0y;
    if (Math.abs(tx) > 0.01 || Math.abs(ty) > 0.01) it.translate(tx, ty, false, false, true, false);
  }

  function gpKeys(units, order) {
    var U = gpUnion(units), ucx = (U[0] + U[2]) / 2, ucy = (U[1] + U[3]) / 2, keys = [], i, b, cx, cy;
    for (i = 0; i < units.length; i++) {
      b = units[i].geometricBounds; cx = (b[0] + b[2]) / 2; cy = (b[1] + b[3]) / 2;
      if (order == 'y') keys.push(-cy);
      else if (order == 'size') keys.push(Math.sqrt(Math.max(0, (b[2] - b[0]) * (b[1] - b[3]))));
      else if (order == 'radial') keys.push(Math.sqrt((cx - ucx) * (cx - ucx) + (cy - ucy) * (cy - ucy)));
      else keys.push(cx);
    }
    if (order == 'radial') {
      var mn = keys[0], mx = keys[0];
      for (i = 1; i < keys.length; i++) { mn = Math.min(mn, keys[i]); mx = Math.max(mx, keys[i]); }
      if (mx - mn < 0.5) return gpKeys(units, 'size');
    }
    return keys;
  }

  // 반환: true = 칠함, false = 태그는 있지만 칠하지 못함(스와치가 지워짐 등)
  function gradRepaint(rings, str, doc) {
    var G = eval('(' + str + ')'), units = gpUnits(rings), i;
    if (!units.length) return false;
    var target = G.target == 'stroke' ? 'stroke' : 'fill';
    if (G.mode == 'solid') {
      var rgb = hexToRGB(G.c);
      for (i = 0; i < units.length; i++) gpSet(units[i], target, function () { return makeColor(doc, rgb); });
      return true;
    }
    if (G.mode == 'dist') {
      var L = Math.floor(String(G.lut || '').length / 6);
      if (L < 2) return false;
      var keys = gpKeys(units, G.order), list = [];
      for (i = 0; i < units.length; i++) list.push({ it: units[i], k: keys[i], i: i });
      list.sort(function (a, b) { return a.k - b.k || a.i - b.i; });
      var n = list.length, kmin = list[0].k, kmax = list[n - 1].k;
      for (i = 0; i < n; i++) {
        var t = n < 2 ? 0 : (G.spacing == 'pos' && kmax - kmin > 1e-6 ? (list[i].k - kmin) / (kmax - kmin) : i / (n - 1));
        var c = gpHex(G.lut, Math.round(t * (L - 1)));
        gpSet(list[i].it, target, function () { return makeColor(doc, c); });
      }
      return true;
    }
    if (G.mode == 'grad') {
      var gr = null;
      try { gr = doc.gradients.getByName(G.grad); } catch (e) { gr = null; }
      if (!gr) return false;
      var U = G.span && target == 'fill' ? gpUnion(units) : null;
      for (i = 0; i < units.length; i++) {
        gpSet(units[i], target, function () { var gc = new GradientColor(); gc.gradient = gr; return gc; });
        if (target == 'fill' && units[i].typename != 'GroupItem') { try { gpFit(units[i], G, U); } catch (e2) {} }
        else if (target == 'fill') {   // 패스 이동으로 생긴 그룹 링은 안의 패스마다
          var ls = [], k2; gpLeaves(units[i], ls);
          for (k2 = 0; k2 < ls.length; k2++) { try { gpFit(ls[k2], G, U); } catch (e3) {} }
        }
      }
      return true;
    }
    return false;
  }

  /* ---------- 중심선 ---------- */
  function reachLen(shape, cx, cy, dx, dy) {
    if (shape.kind == 'ellipse') {
      var a = dx / shape.rx, b = dy / shape.ry;
      return 1 / Math.sqrt(a * a + b * b);
    }
    var tx = Infinity, ty = Infinity;
    if (dx > 1e-9) tx = (shape.r - cx) / dx; else if (dx < -1e-9) tx = (shape.l - cx) / dx;
    if (dy > 1e-9) ty = (shape.t - cy) / dy; else if (dy < -1e-9) ty = (shape.b - cy) / dy;
    return Math.min(tx, ty);
  }

  function drawCross(g, info, list, P, doc) {
    var C = P.cross || {};
    var ref = null, i;
    if (C.reach == 'outer') {
      for (i = 0; i < list.length; i++) if (list[i].d > 0 && (!ref || list[i].d > ref.d)) ref = list[i];
    }
    var shape;
    if (info.kind == 'ellipse') {
      var add = ref ? ref.d : 0;
      shape = { kind: 'ellipse', rx: info.rx + add, ry: info.ry + add };
    } else if (ref) {
      shape = { kind: 'box', l: ref.bounds.l, t: ref.bounds.t, r: ref.bounds.r, b: ref.bounds.b };
    } else {
      shape = { kind: 'box', l: info.l, t: info.t, r: info.r, b: info.b };
    }

    var grp = g.groupItems.add();
    grp.name = '중심선';
    var n = clamp(Math.round(num(C.count, 2)), 1, 36);
    var ext = num(C.extend, 0) * MM;
    var w = Math.max(0.05, num(C.w, 0.25));
    var col = makeColor(doc, hexToRGB(C.color));
    var k = Math.max(0.1, num(C.scale, 1));
    var dashes = C.type == 'center' ? [12 * k, 3 * k, 2 * k, 3 * k] : (C.type == 'dash' ? [4 * k, 3 * k] : []);
    for (i = 0; i < n; i++) {
      var ang = (num(C.angle, 0) + i * 180 / n) * Math.PI / 180;
      var dx = Math.cos(ang), dy = Math.sin(ang);
      var L = reachLen(shape, info.cx, info.cy, dx, dy) + ext;
      if (!(L > 0.05) || L == Infinity) continue;
      var p = grp.pathItems.add();
      p.setEntirePath([[info.cx - dx * L, info.cy - dy * L], [info.cx + dx * L, info.cy + dy * L]]);
      p.closed = false;
      p.filled = false;
      p.stroked = true;
      p.strokeWidth = w;
      p.strokeColor = col;
      p.strokeDashes = dashes;
      p.strokeCap = StrokeCap.BUTTENDCAP;
    }
    if (grp.pageItems.length == 0) grp.remove();
  }

  /* ---------- 라벨 ---------- */
  function fmtNum(v) {
    var neg = v < 0;
    v = Math.round(Math.abs(v) * 100) / 100;
    var s = String(v);
    if (s.indexOf('e') >= 0) s = v.toFixed(2);
    var parts = s.split('.');
    var ip = parts[0], out = '';
    while (ip.length > 3) { out = ',' + ip.substr(ip.length - 3) + out; ip = ip.substr(0, ip.length - 3); }
    out = ip + out;
    if (parts.length > 1 && parseInt(parts[1], 10) > 0) out += '.' + parts[1];
    return (neg ? '-' : '') + out;
  }
  function labelText(valPt, Lb) {
    var mm = valPt / MM * Math.max(0, num(Lb.scale, 1));
    var unit = Lb.unit || 'mm';
    var v = mm;
    if (unit == 'm') v = mm / 1000;
    else if (unit == 'km') v = mm / 1000000;
    return fmtNum(v) + (Lb.showUnit === false ? '' : unit);
  }

  function drawLabels(g, info, list, P, doc) {
    var Lb = P.label || {};
    var grp = g.groupItems.add();
    grp.name = '라벨';
    var size = clamp(num(Lb.size, 7), 1, 300);
    var pad = size * 0.35;
    var black = makeColor(doc, [0, 0, 0]);
    var entries = list.slice(0), i;
    if (Lb.withSource) entries.push({ d: 0, src: true, st: null, bounds: { l: info.l, t: info.t, r: info.r, b: info.b } });
    var radius = (Lb.basis == 'radius' && info.kind == 'ellipse');

    for (i = 0; i < entries.length; i++) {
      var e = entries[i];
      var val = radius ? info.rx + e.d : Math.abs(e.d);
      if (!radius && e.src) continue;          // 거리 기준이면 원본은 0이라 생략
      var b = e.bounds, x, y, just;
      var midX = (b.l + b.r) / 2, midY = (b.t + b.b) / 2;
      if (Lb.pos == 'bottom') { x = midX; y = b.b - pad - size * 0.72; just = Justification.CENTER; }
      else if (Lb.pos == 'right') { x = b.r + pad; y = midY - size * 0.35; just = Justification.LEFT; }
      else if (Lb.pos == 'left') { x = b.l - pad; y = midY - size * 0.35; just = Justification.RIGHT; }
      else { x = midX; y = b.t + pad; just = Justification.CENTER; }

      var col = black;
      if (Lb.color == 'ring' && e.st) col = e.st.stroke ? e.st.sc : (e.st.fill ? e.st.fc : black);

      var tf = grp.textFrames.pointText([x, y]);
      tf.contents = labelText(val, Lb);
      var tr = tf.textRange;
      tr.paragraphAttributes.justification = just;
      tr.characterAttributes.size = size;
      tr.characterAttributes.fillColor = col;
      tf.name = tf.contents;
    }
    if (grp.pageItems.length == 0) grp.remove();
  }

  /* ---------- 조립 ---------- */
  function fmtName(d) {
    return (d > 0 ? '+' : '-') + fmtNum(Math.abs(d) / MM) + 'mm';
  }

  // 실제로 만들어진 링 개수 기준으로 0→1 보간값을 나눔 (안쪽에서 중간에 멈춰도 끝 스타일까지 감)
  function spread(side, list) {
    var n = side.length;
    for (var i = 0; i < n; i++) {
      side[i].t = n > 1 ? i / (n - 1) : 0;
      list.push(side[i]);
    }
  }

  function build(g, rings, src, P, doc) {
    var info = analyze(src);
    src.hidden = (P.keepSource === false);
    var pl = plan(P, info);
    var list = [], i, d, it, side;

    // 바깥: 가까운 것부터 아래로 쌓음 → 큰 도형이 뒤로
    side = [];
    for (i = 0; i < pl.pos.length; i++) {
      d = pl.pos[i];
      it = makeRing(rings, src, info, d, P.join, doc);
      if (!it) break;
      it.move(rings, ElementPlacement.PLACEATEND);
      side.push({ d: d, item: it, rank: i });
    }
    spread(side, list);
    // 안쪽: 가까운 것부터 위로 쌓음 → 작은 도형이 앞으로
    side = [];
    for (i = 0; i < pl.neg.length; i++) {
      d = -pl.neg[i];
      it = makeRing(rings, src, info, d, P.join, doc);
      if (!it) break;                          // 도형이 사라지면 멈춤
      it.move(rings, ElementPlacement.PLACEATBEGINNING);
      side.push({ d: d, item: it, rank: i });
    }
    spread(side, list);

    for (i = 0; i < list.length; i++) {
      var e = list[i];
      e.st = ringStyle(P, e.t, e.rank, doc);
      paint(e.item, e.st);
      e.item.opacity = e.st.opacity;
      e.item.name = fmtName(e.d);
      e.bounds = ringBounds(e, info);
    }

    var gp = getTag(g, TAG_G);
    if (gp) { try { gradRepaint(rings, gp, doc); } catch (eg) {} }

    if (P.cross && P.cross.on) drawCross(g, info, list, P, doc);
    if (P.label && P.label.on) drawLabels(g, info, list, P, doc);
    return list.length;
  }

  function findSource(container) {
    var items = container.pageItems, i, it, r;
    for (i = 0; i < items.length; i++) {
      it = items[i];
      if (getTag(it, TAG_R) == 'source') return it;
      if (it.typename == 'GroupItem') { r = findSource(it); if (r) return r; }
    }
    return null;
  }

  function findHyGroup(item) {
    var p = item, guard = 0;
    while (p && guard++ < 60) {
      if (p.typename == 'GroupItem' && getTag(p, TAG_P) !== null) return p;
      if (p.typename == 'Layer' || p.typename == 'Document') return null;
      try { p = p.parent; } catch (e) { return null; }
    }
    return null;
  }

  function create(src, P, enc, doc) {
    var g = src.parent.groupItems.add();
    g.move(src, ElementPlacement.PLACEBEFORE);
    g.name = 'hy Offset';
    var rings = g.groupItems.add();
    rings.name = '링';
    src.move(rings, ElementPlacement.PLACEATEND);
    setTag(src, TAG_R, 'source');
    setTag(g, TAG_P, enc);
    build(g, rings, src, P, doc);
    return g;
  }

  function rebuild(g, P, enc, doc) {
    var src = findSource(g);
    if (!src) throw new Error('원본 도형을 찾지 못했습니다');
    var wasLocked = false;
    try { wasLocked = src.locked; src.locked = false; } catch (e0) {}
    src.move(g, ElementPlacement.PLACEATEND);
    var gid = uid(g), kill = [], i, it;
    for (i = 0; i < g.pageItems.length; i++) {
      it = g.pageItems[i];
      if (getTag(it, TAG_R) == 'source') continue;
      if (gid !== null && uid(it.parent) !== gid) continue;   // 직계 자식만
      kill.push(it);
    }
    for (i = kill.length - 1; i >= 0; i--) { try { kill[i].remove(); } catch (e1) {} }
    var rings = g.groupItems.add();
    rings.name = '링';
    src.move(rings, ElementPlacement.PLACEATEND);
    setTag(g, TAG_P, enc);
    build(g, rings, src, P, doc);
    if (wasLocked) { try { src.locked = true; } catch (e2) {} }
    return g;
  }

  /* ---------- 진입점 ---------- */
  function run(enc, updateOnly) {
    if (app.documents.length == 0) return updateOnly ? 'skip' : 'err|열린 문서가 없습니다';
    var doc = app.activeDocument;
    var sel = doc.selection;
    if (!sel || sel.typename == 'TextRange' || !sel.length) return updateOnly ? 'skip' : 'err|도형을 선택하세요';

    var P;
    try { P = parseParams(enc); } catch (e0) { return 'err|설정값을 읽지 못했습니다'; }

    var items = [], i;
    for (i = 0; i < sel.length; i++) items.push(sel[i]);

    var groups = [], gids = {}, sources = [], skipped = 0;
    for (i = 0; i < items.length; i++) {
      var g = findHyGroup(items[i]);
      if (g) {
        var id = uid(g);
        if (id === null || !gids[id]) { if (id !== null) gids[id] = true; groups.push(g); }
      } else if (!updateOnly) {
        if (isShape(items[i]) && !items[i].locked) sources.push(items[i]);
        else skipped++;
      }
    }
    if (groups.length == 0 && sources.length == 0) {
      return updateOnly ? 'skip' : 'err|패스나 복합 패스를 선택하세요';
    }

    var oldCS = app.coordinateSystem;
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    var made = [];
    try {
      for (i = 0; i < groups.length; i++) made.push(rebuild(groups[i], P, enc, doc));
      for (i = 0; i < sources.length; i++) made.push(create(sources[i], P, enc, doc));
      doc.selection = null;
      var linked = 0;
      for (i = 0; i < made.length; i++) { made[i].selected = true; if (getTag(made[i], TAG_G)) linked++; }
      return 'ok|' + groups.length + '|' + sources.length + '|' + skipped + '|' + linked;
    } catch (e) {
      return 'err|' + e.message + (e.line ? ' (줄 ' + e.line + ')' : '');
    } finally {
      app.coordinateSystem = oldCS;
    }
  }

  function load() {
    if (app.documents.length == 0) return '';
    var sel = app.activeDocument.selection;
    if (!sel || sel.typename == 'TextRange' || !sel.length) return '';
    for (var i = 0; i < sel.length; i++) {
      var g = findHyGroup(sel[i]);
      if (g) return getTag(g, TAG_P) || '';
    }
    return '';
  }

  function selectedGroups() {
    var out = [], ids = {}, i, g, id;
    if (app.documents.length == 0) return out;
    var sel = app.activeDocument.selection;
    if (!sel || sel.typename == 'TextRange' || !sel.length) return out;
    for (i = 0; i < sel.length; i++) {
      g = findHyGroup(sel[i]);
      if (!g) continue;
      id = uid(g);
      if (id !== null && ids[id]) continue;
      if (id !== null) ids[id] = true;
      out.push(g);
    }
    return out;
  }

  // 선택한 hy Offset 그룹 중 hy Gradient 색이 걸린 개수
  function gradState() {
    var gs = selectedGroups(), n = 0;
    for (var i = 0; i < gs.length; i++) if (getTag(gs[i], TAG_G)) n++;
    return String(n);
  }

  // hy Gradient 색을 풀고 그룹에 저장된 설정으로 다시 만들어 hy Offset 단계 스타일로 되돌림
  function unlinkGrad() {
    var gs = selectedGroups(), n = 0, i, enc;
    if (!gs.length) return 'err|hy Offset으로 만든 그룹을 선택하세요';
    var doc = app.activeDocument, oldCS = app.coordinateSystem;
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    try {
      for (i = 0; i < gs.length; i++) {
        if (!getTag(gs[i], TAG_G)) continue;
        removeTag(gs[i], TAG_G);
        enc = getTag(gs[i], TAG_P);
        if (enc) rebuild(gs[i], parseParams(enc), enc, doc);
        n++;
      }
      doc.selection = null;
      for (i = 0; i < gs.length; i++) gs[i].selected = true;
      return 'ok|' + n;
    } catch (e) {
      return 'err|' + e.message;
    } finally {
      app.coordinateSystem = oldCS;
    }
  }

  return { run: run, load: load, gradState: gradState, unlinkGrad: unlinkGrad, version: '0.2.0' };
})();
