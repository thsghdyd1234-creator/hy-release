/* ============================================================
   일러스트용 SVG 정리 — 보이는 모습은 그대로 두고, 일러스트에서 다루기 쉽게 바꿉니다
   1) 그룹에 걸린 투명도(opacity)를 그 안의 객체마다 직접 겁니다.
      그룹 투명도는 그룹을 한 장으로 합친 뒤 투명하게 하므로 안에서 겹친 곳이 진해지지 않습니다.
      그래서 같은 그룹 안에서 겹치는 면은 뒤(아래) 면에서 앞(위) 면 자리를 미리 빼고,
      같은 모양의 반투명 선은 한 패스로 모아 겹친 곳이 진해지지 않게 합니다.
   2) 여러 면이 한 패스(컴파운드)로 묶인 것은 면마다 하나의 패스로 풉니다.
      구멍이 있는 면(섬이 있는 바다, 안마당이 있는 건물 등)만 그 면 하나로 컴파운드가 남습니다.
   3) 여러 선이 한 패스로 묶인 것도 선마다 하나로 풉니다 (반투명 선은 겹친 곳이 진해지지 않게 그대로).
   M·L·Z 로만 된 패스만 손대고, 곡선·글자·그림은 그대로 둡니다.
   ============================================================ */
const TIDY_S = 100;                                   // Clipper 정수 좌표 배율 (0.01 단위)

/* d → [{pts:[[x,y]…], closed}] — M·L·Z(대문자)만, 다른 명령이 있으면 null */
function tidyParseD(d){
  if(!d || /[^MLZz0-9eE.,\s+\-]/.test(d)) return null;
  const subs = []; let cur = null, start = null;
  const re = /([MLZz])([^MLZz]*)/g; let m;
  while((m = re.exec(d))){
    const cmd = m[1], nums = (m[2].match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/g) || []).map(Number);
    if(cmd === 'Z' || cmd === 'z'){ if(cur){ cur.closed = true; cur = null; } continue; }
    if(nums.length % 2) return null;
    for(let i = 0; i < nums.length; i += 2){
      const p = [nums[i], nums[i + 1]];
      if((cmd === 'M' && i === 0) || !cur){
        if(cmd === 'L' && !cur && start){ cur = { pts:[start.slice()], closed:false }; subs.push(cur); }
        else{ cur = { pts:[], closed:false }; subs.push(cur); start = p; }
      }
      cur.pts.push(p);
    }
  }
  return subs.filter(s => s.pts.length);
}
const tidyN = v => { const s = (Math.round(v * 100) / 100).toString(); return s === '-0' ? '0' : s; };
const tidyRingD = (r, close) => 'M' + r.map(([x, y]) => tidyN(x) + ',' + tidyN(y)).join('L') + (close ? 'Z' : '');

/* 이어받는 속성 (조상까지 올라가며) */
function tidyAttr(el, name, stop){
  for(let e = el; e && e.nodeType === 1 && e !== stop; e = e.parentNode){
    const v = e.getAttribute(name);
    if(v != null && v !== '' && v !== 'inherit') return v;
  }
  return null;
}
const tidyOp = el => { const v = parseFloat(el.getAttribute('opacity')); return isFinite(v) ? v : 1; };

/* Clipper 도움 */
function tidyToPaths(subs){
  return subs.filter(s => s.pts.length >= 3).map(s => s.pts.map(([x, y]) => ({ X:Math.round(x * TIDY_S), Y:Math.round(y * TIDY_S) })));
}
function tidyExec(type, subj, clip, rule){
  const C = CL(), c = new C.Clipper(), ft = rule === 'evenodd' ? C.PolyFillType.pftEvenOdd : C.PolyFillType.pftNonZero;
  c.AddPaths(subj, C.PolyType.ptSubject, true);
  if(clip && clip.length) c.AddPaths(clip, C.PolyType.ptClip, true);
  const tree = new C.PolyTree();
  c.Execute(type, tree, ft, C.PolyFillType.pftNonZero);
  return C.JS.PolyTreeToExPolygons(tree).filter(e => e.outer && e.outer.length >= 3)
    .map(e => [e.outer, ...e.holes.filter(h => h.length >= 3)]);
}
const tidyFlat = ex => ex.flat();                                         // ExPolygons → 방향이 맞는 고리 목록
const tidyExD = ex => ex.map(r => tidyRingD(r.map(p => [p.X / TIDY_S, p.Y / TIDY_S]), true)).join('');
function tidyBox(paths){
  let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
  for(const r of paths) for(const p of r){ if(p.X < a) a = p.X; if(p.X > c) c = p.X; if(p.Y < b) b = p.Y; if(p.Y > d) d = p.Y; }
  return [a, b, c, d];
}
const tidyHit = (p, q) => p[0] <= q[2] && q[0] <= p[2] && p[1] <= q[3] && q[1] <= p[3];

/* 패스 한 개가 칠하는 면인지 선인지 */
function tidyKind(el, root){
  const fill = tidyAttr(el, 'fill', root), stroke = tidyAttr(el, 'stroke', root);
  const hasFill = fill !== 'none', hasStroke = !!stroke && stroke !== 'none';
  return hasFill ? 'fill' : hasStroke ? 'line' : null;
}

/* 1) 그룹 투명도 → 객체마다 */
function tidyGroupOpacity(doc, root){
  const groups = [...root.querySelectorAll('g')].filter(g => tidyOp(g) < 1);
  const depth = n => { let k = 0; for(let e = n; e && e !== root; e = e.parentNode) k++; return k; };
  groups.sort((p, q) => depth(q) - depth(p));                            // 안쪽 그룹부터
  const C = CL();
  for(const g of groups){
    const a = tidyOp(g);
    const leaves = [...g.querySelectorAll('*')].filter(e => e.tagName !== 'g' && e.namespaceURI === g.namespaceURI && !e.closest('defs,clipPath,mask,pattern'));
    // 면: 뒤 면에서 앞 면 자리를 뺍니다 (같은 그룹 안에서 겹치지 않게)
    const fills = [];
    for(const e of leaves){
      if(e.tagName !== 'path' || tidyKind(e, null) !== 'fill') continue;
      const subs = tidyParseD(e.getAttribute('d')); if(!subs) continue;
      const rule = tidyAttr(e, 'fill-rule', null) === 'evenodd' ? 'evenodd' : 'nonzero';
      const ex = tidyExec(C.ClipType.ctUnion, tidyToPaths(subs), null, rule), paths = tidyFlat(ex);
      fills.push({ e, ex, paths, box:paths.length ? tidyBox(paths) : null });
    }
    for(let i = fills.length - 1; i >= 0; i--){
      const f = fills[i]; if(!f.box) continue;
      const over = [];
      for(let j = i + 1; j < fills.length; j++){ const q = fills[j]; if(q.box && tidyHit(f.box, q.box)) over.push(...q.paths); }
      if(over.length){ f.ex = tidyExec(C.ClipType.ctDifference, f.paths, over, 'nonzero'); f.changed = true; }
    }
    for(const f of fills) if(f.changed){
      if(!f.ex.length){ f.e.remove(); continue; }
      f.e.setAttribute('d', tidyExD(f.ex)); f.e.setAttribute('fill-rule', 'evenodd');
    }
    // 반투명이 될 선: 같은 모양끼리 한 패스로 (겹친 곳이 진해지지 않게)
    const lineKey = e => ['stroke', 'stroke-width', 'stroke-dasharray', 'stroke-linecap', 'stroke-linejoin', 'stroke-opacity'].map(k => tidyAttr(e, k, null) || '').join('|') + '|' + tidyOp(e);
    const lines = new Map();                                              // 부모(하위 그룹)마다, 모양마다
    for(const e of leaves){
      if(!e.isConnected || e.tagName !== 'path' || tidyKind(e, null) !== 'line' || !tidyParseD(e.getAttribute('d'))) continue;
      let byStyle = lines.get(e.parentNode); if(!byStyle) lines.set(e.parentNode, byStyle = new Map());
      const k = lineKey(e); if(!byStyle.has(k)) byStyle.set(k, []);
      byStyle.get(k).push(e);
    }
    for(const byStyle of lines.values()) for(const list of byStyle.values()) if(list.length > 1){
      list[0].setAttribute('d', list.map(e => e.getAttribute('d')).join(''));
      for(const e of list.slice(1)) e.remove();
    }
    // 투명도를 객체로 내립니다
    for(const e of leaves){
      if(!e.isConnected) continue;
      const v = tidyOp(e) * a;
      if(v < 0.999) e.setAttribute('opacity', +v.toFixed(3)); else e.removeAttribute('opacity');
      if(e.tagName === 'path' && tidyKind(e, null) === 'line') e.setAttribute('data-keep', '1');   // 반투명 선은 한 패스 그대로
    }
    g.removeAttribute('opacity');
  }
}

/* 2)·3) 묶인 패스 풀기 */
const TIDY_GEOM = new Set(['d', 'id']);
function tidySplitPaths(doc, root){
  const C = CL();
  for(const e of [...root.querySelectorAll('path')]){
    if(!e.isConnected || e.closest('defs,clipPath,mask,pattern')) continue;
    if(e.getAttribute('data-keep')){ e.removeAttribute('data-keep'); continue; }
    const kind = tidyKind(e, null); if(!kind) continue;
    const subs = tidyParseD(e.getAttribute('d')); if(!subs || subs.length < 2) continue;
    let ds;
    if(kind === 'fill'){
      const rule = tidyAttr(e, 'fill-rule', null) === 'evenodd' ? 'evenodd' : 'nonzero';
      const ex = tidyExec(C.ClipType.ctUnion, tidyToPaths(subs), null, rule);
      if(ex.length < 2 && ex.every(p => p.length === subs.length)) continue;   // 이미 면 하나
      ds = ex.map(p => tidyExD(p));
      if(ex.some(p => p.length > 1)) e.setAttribute('fill-rule', 'evenodd');
    }else{
      if(tidyOp(e) * (parseFloat(tidyAttr(e, 'stroke-opacity', null)) || 1) < 0.999) continue;   // 반투명 선 묶음은 그대로
      ds = subs.filter(s => s.pts.length > 1).map(s => tidyRingD(s.pts, s.closed));
    }
    if(!ds.length){ e.remove(); continue; }
    const id = e.getAttribute('id'), parent = e.parentNode;
    let host = parent, before = e;
    if(id && ds.length > 1){                                               // 이름이 있던 패스는 같은 이름의 그룹으로
      host = doc.createElementNS(e.namespaceURI, 'g'); host.setAttribute('id', id);
      parent.insertBefore(host, e); before = null;
    }
    for(const d of ds){
      const n = doc.createElementNS(e.namespaceURI, 'path');
      for(const at of [...e.attributes]) if(!TIDY_GEOM.has(at.name)) n.setAttribute(at.name, at.value);
      if(id && ds.length === 1) n.setAttribute('id', id);
      n.setAttribute('d', d);
      host.insertBefore(n, before);
    }
    e.remove();
  }
}

/* 정리 — 실패하면 원본을 그대로 돌려줍니다 */
function tidySVG(text){
  if(!CL()) return text;
  try{
    const doc = new DOMParser().parseFromString(text, 'image/svg+xml');
    const root = doc.documentElement;
    if(!root || root.nodeName !== 'svg' || doc.getElementsByTagName('parsererror').length) return text;
    tidyGroupOpacity(doc, root);
    tidySplitPaths(doc, root);
    return new XMLSerializer().serializeToString(doc);
  }catch(err){
    console.warn('[클린 맵] SVG 정리 실패, 원본으로 저장합니다', err);
    return text;
  }
}
/* 정리 켜기 (기본 켬) — 내보내기 화면과 미리보기 저장이 같이 씁니다 */
const tidyOn = () => { try{ return localStorage.getItem('cleanmapTidy') !== '0'; }catch(e){ return true; } };
const tidySet = on => { try{ localStorage.setItem('cleanmapTidy', on ? '1' : '0'); }catch(e){} };
/* 체크 상자 — 지도 꾸미기·대지분석 내보내기 칸과 미리보기 창이 같은 설정을 씁니다 */
function tidySync(){ document.querySelectorAll('.tidychk').forEach(i => { i.checked = tidyOn(); }); }
document.addEventListener('change', e => {
  if(e.target && e.target.classList && e.target.classList.contains('tidychk')){ tidySet(e.target.checked); tidySync(); }
});
tidySync();
