/* 툴바 아이콘을 누르면 뷰어를 새 탭에서 엽니다 */
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
});

/* 구글맵에 얹은 버튼이 좌표나 검색어를 보내오면 그 위치로 엽니다 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'openViewer') return false;
  chrome.tabs.create({ url: chrome.runtime.getURL('index.html') + (msg.tail || '') });
  sendResponse({ ok: true });
  return false;   // 동기 응답이므로 채널을 열어 두지 않습니다
});
