/* ============================================================
   생활 시설과 관광·문화 자원
   · 15분 생활권: 대지에서 걸어서 5·10·15분 안에 학교·공원·병의원·약국·편의시설·버스가 몇 개, 가장 가까운 곳은 몇 분
     공원·학교는 확장에 넣은 표준데이터(data/*.json), 병의원·약국·편의점은 상가 데이터에서 업종으로 골라 씁니다.
   · 관광·문화 자원: 한국관광공사 국문 관광정보(TourAPI) 위치 기반 조회
   ============================================================ */
const LOCAL_DATA = {};
async function localData(name){
  if(LOCAL_DATA[name]) return LOCAL_DATA[name];
  const r = await fetch('data/' + name + '.json');
  if(!r.ok) throw new Error(name + ' 자료 파일을 읽지 못했습니다');
  return (LOCAL_DATA[name] = await r.json());
}
function bboxLL(){
  const FR = focusR();
  let x0, y0, x1, y1;
  if(SITE.range === 'view' && SITE.viewLL){ [[x0, y0], [x1, y1]] = viewRectM(); } else { x0 = -FR; y0 = -FR; x1 = FR; y1 = FR; }
  const [w, s] = toLL([x0, y0]), [e, n] = toLL([x1, y1]);
  return { w, s, e, n };
}

/* ============================================================
   15분 생활권
   ============================================================ */
const LIFE = { on:false, busy:false, res:null };
const LIFE_CATS = [
  { k:'elem',  name:'초등학교',     shape:'sq' },
  { k:'mid',   name:'중·고등학교',  shape:'sq' },
  { k:'park',  name:'공원',         shape:'ci' },
  { k:'clinic',name:'병의원',       shape:'cr' },
  { k:'pharm', name:'약국',         shape:'cr' },
  { k:'shop',  name:'편의점·마트',  shape:'di' },
  { k:'bus',   name:'버스 정류장',  shape:'tr' }
];
const lifeColor = k => { const st = ST(); return { elem:st.age, mid:hexMix(st.age, st.ink, 0.35), park:st.bizCats[8] || st.age, clinic:st.biz, pharm:hexMix(st.biz, st.paper, 0.35), shop:st.work, bus:st.bus }[k]; };

async function collectFacilities(){
  const bb = bboxLL(), inB = (lat, lng) => lat >= bb.s && lat <= bb.n && lng >= bb.w && lng <= bb.e;
  const out = [];
  const [parks, schools] = await Promise.all([localData('parks'), localData('schools')]);
  for(const [nm, kind, lat, lng, area] of parks.rows) if(inB(lat, lng)) out.push({ k:'park', name:nm, sub:kind, ll:[lng, lat], area });
  for(const [nm, lv, lat, lng] of schools.rows) if(inB(lat, lng)) out.push({ k:lv === '초등학교' ? 'elem' : 'mid', name:nm, sub:lv, ll:[lng, lat] });
  // 상가에서 생활 시설 고르기 — 상가를 아직 안 받았으면 받아 옵니다
  if(!BIZ.items){ $('lifesum').textContent = '생활 시설 고르려고 상가 받는 중'; await runBiz(); }
  for(const b of (BIZ.items || [])){
    const t = (b.m || '') + ' ' + (b.s || '');
    let k = null;
    if(/약국/.test(t)) k = 'pharm';
    else if(/의원|병원|치과|한의/.test(t) && /보건|의료/.test(b.l || '')) k = 'clinic';
    else if(/편의점|슈퍼|마트|식료품/.test(t)) k = 'shop';
    if(k) out.push({ k, name:b.name, sub:b.s, ll:b.ll });
  }
  const stops = BUS.wide ? BUS.wide.stops : BUS.stops;
  if(stops) for(const s of stops) out.push({ k:'bus', name:s.name || '정류장', ll:s.ll || toLL(s.m) });
  for(const f of out) f.m = toM(f.ll);
  return out.filter(f => inFocus(f.m));
}
async function runLife(){
  if(!hasRef()){ $('lifesum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(LIFE.busy) return;
  LIFE.busy = true; $('liferun').disabled = true;
  try{
    // 도로망 (보행) — 교통 카드를 안 켰어도 받아 옵니다
    if(!TR.ways || !TR.ways.length){
      $('lifesum').textContent = '도로망 받는 중';
      const raw = await fetchRoads(Math.min(focusR() + 300, 16000), null);
      TR.ways = raw.filter(e => e.type === 'way' && e.geometry).map(wayInfo).filter(Boolean);
    }
    $('lifesum').textContent = '보행 거리 계산 중';
    const iso = computeIso();
    const G = buildGraph(TR.ways, 'walk');
    // 출발점은 등시선과 같게 다시 (대지 경계 30m 안 교차점)
    const src = [];
    if(SITE.geom){ const sm = mapRings(SITE.geom, toM); G.nodes.forEach((p, i) => { if(pointInMulti(p, sm)) src.push([i, 0]); }); if(!src.length){ let b = -1, bd = 1e18; G.nodes.forEach((p, i) => { const d = Math.hypot(p[0], p[1]); if(d < bd){ bd = d; b = i; } }); src.push([b, bd]); } }
    else G.nodes.map((p, i) => [i, Math.hypot(p[0], p[1])]).sort((a, b) => a[1] - b[1]).slice(0, 3).forEach(s => src.push(s));
    const dist = dijkstra(G, src, 'len');
    // 교차점 찾기용 격자
    const CELL = 80, grid = new Map();
    G.nodes.forEach((p, i) => { if(!isFinite(dist[i])) return; const k = Math.floor(p[0] / CELL) + ',' + Math.floor(p[1] / CELL); if(!grid.has(k)) grid.set(k, []); grid.get(k).push(i); });
    $('lifesum').textContent = '생활 시설 모으는 중';
    const facs = await collectFacilities();
    for(const f of facs){
      const cx = Math.floor(f.m[0] / CELL), cy = Math.floor(f.m[1] / CELL); let best = Infinity;
      for(let x = cx - 2; x <= cx + 2; x++) for(let y = cy - 2; y <= cy + 2; y++) for(const i of (grid.get(x + ',' + y) || [])){
        const p = G.nodes[i], v = dist[i] + Math.hypot(p[0] - f.m[0], p[1] - f.m[1]); if(v < best) best = v;
      }
      f.min = isFinite(best) ? best / WALK : null;                     // 걸어서 몇 분
    }
    LIFE.res = { iso, facs };
    registerLifeLayers(); apply(); summarizeLife();
  }catch(err){ console.error(err); $('lifesum').textContent = '실패 — ' + err.message; }
  LIFE.busy = false; $('liferun').disabled = false;
}
function lifeTable(){
  const rows = [];
  for(const c of LIFE_CATS){
    const fs = LIFE.res.facs.filter(f => f.k === c.k && f.min != null).sort((a, b) => a.min - b.min);
    rows.push({ cat:c.name, nearest:fs[0] ? { name:fs[0].name, min:Math.round(fs[0].min) } : null,
      within5:fs.filter(f => f.min <= 5).length, within10:fs.filter(f => f.min <= 10).length, within15:fs.filter(f => f.min <= 15).length });
  }
  return rows;
}
function summarizeLife(){
  if(!LIFE.res) return;
  const T = lifeTable();
  $('lifesum').textContent = T.map(r => `${r.cat} ${r.nearest ? r.nearest.min + '분' : '없음'}`).join(' · ') + ' (가장 가까운 곳까지 걸어서)';
  $('lifetable').innerHTML = '<tr><th></th><th>가장 가까운 곳</th><th>5분</th><th>10분</th><th>15분</th></tr>' +
    T.map(r => `<tr${!r.within15 ? ' class="miss"' : ''}><td>${esc(r.cat)}</td><td>${r.nearest ? esc(r.nearest.name) + ' · ' + r.nearest.min + '분' : '<b>범위 안 없음</b>'}</td><td>${r.within5}</td><td>${r.within10}</td><td>${r.within15}</td></tr>`).join('');
  $('lifetable').hidden = false;
}
function registerLifeLayers(){
  extraRemove('life-');
  if(!LIFE.on || !LIFE.res || !hasRef()) return;
  const st = ST(), base = st.iso, ramp = rampFrom(base, 3), mpp = mppNow(), a = typeof CA === 'function' ? CA() : 0.7;
  // 등시선 (옅게 — 시설이 주인공)
  [...LIFE.res.iso.bands].reverse().forEach((b, idx) => {
    if(!b.g.length) return;
    extraSet('life-iso-' + b.m, { label:`분석_생활권_${3 - idx}_${b.m}분 보행권`, stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:mapRings(b.g, toLL) } }] },
      paint:{ 'fill-color':ramp[idx], 'fill-opacity':0.3 + a * 0.3 }, svg:{ kind:'fill', fill:ramp[idx], opacity:0.3 + a * 0.3 } });
    extraSet('life-iso-line-' + b.m, { label:`분석_생활권경계_${b.m}분_세부`, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[ringFeature(mapRings(b.g, toLL), {})] }, paint:{ 'line-color':base, 'line-width':0.8, 'line-dasharray':[3, 2] }, svg:{ kind:'line', stroke:base, width:0.6, dash:[3, 2] } });
  });
  // 시설 기호 — 15분 안은 진하게, 밖은 흐리게
  const shape = (s, x, y, r) => {
    const P = pts => [pts.map(([u, v]) => toLL([x + u, y + v]))];
    if(s === 'sq') return P([[-r, -r], [r, -r], [r, r], [-r, r], [-r, -r]]);
    if(s === 'tr') return P([[0, r * 1.2], [-r * 1.1, -r * 0.8], [r * 1.1, -r * 0.8], [0, r * 1.2]]);
    if(s === 'di') return P([[0, r * 1.3], [r * 1.3, 0], [0, -r * 1.3], [-r * 1.3, 0], [0, r * 1.3]]);
    if(s === 'cr'){ const t = r * 0.42; return P([[-t, r], [t, r], [t, t], [r, t], [r, -t], [t, -t], [t, -r], [-t, -r], [-t, -t], [-r, -t], [-r, t], [-t, t], [-t, r]]); }
    return [ringLL(x, y, r, 20)];
  };
  for(const c of LIFE_CATS){
    const col = lifeColor(c.k), fs = LIFE.res.facs.filter(f => f.k === c.k);
    for(const [inside, tag, op] of [[true, 'in', 1], [false, 'out', 0.3]]){
      const pick = fs.filter(f => inside ? (f.min != null && f.min <= 15) : !(f.min != null && f.min <= 15));
      if(!pick.length) continue;
      const r = mpp * (c.k === 'park' ? 4.5 : 3.6);
      extraSet(`life-${c.k}-${tag}`, { label:inside ? `분석_생활시설_${c.name}` : `분석_생활시설_${c.name}_15분 밖_세부`, stage:'top', type:'fill', nomerge:true,
        fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:pick.map(f => shape(c.shape, f.m[0], f.m[1], r)) } }] },
        paint:{ 'fill-color':col, 'fill-opacity':op }, svg:{ kind:'fill', fill:col, opacity:op } });
    }
  }
  // 성격마다 가장 가까운 곳까지 이름과 분
  const near = [];
  for(const c of LIFE_CATS){ const f = LIFE.res.facs.filter(x => x.k === c.k && x.min != null).sort((p, q) => p.min - q.min)[0]; if(f) near.push({ type:'Feature', properties:{ label:`${f.name} ${Math.round(f.min)}분` }, geometry:{ type:'Point', coordinates:f.ll } }); }
  extraSet('life-label', { label:'분석_생활시설_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:near },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10, 'text-offset':[0, 1.2], 'text-allow-overlap':false },
    paint:{ 'text-color':st.ink, 'text-halo-color':st.paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:st.ink, size:8 } });
}
function lifeSummary(){
  if(!LIFE.on || !LIFE.res) return null;
  return { method:'대지에서 도로망을 따라 걷는 거리(분당 80m)로 시설까지의 시간을 잰 값입니다', table:lifeTable(),
    sources:'공원: 전국도시공원정보표준데이터 · 학교: 한국교육시설안전원 초중등학교위치 · 병의원·약국·편의점: 소상공인 상가정보 업종 · 버스: TAGO' };
}
$('lifeon').addEventListener('change', e => {
  LIFE.on = e.target.checked; $('lifeopts').hidden = !LIFE.on; $('card-life').classList.toggle('on', LIFE.on);
  if(LIFE.on && !LIFE.res) runLife(); else { registerLifeLayers(); apply(); }
});
$('liferun').addEventListener('click', () => { LIFE.res = null; runLife(); });

/* ============================================================
   관광·문화 자원 — TourAPI 위치 기반 조회
   ============================================================ */
const TOUR = { on:false, busy:false, items:null, form:'points' };
const TOUR_TYPES = { 12:'관광지', 14:'문화시설', 15:'축제·공연·행사', 28:'레포츠', 32:'숙박', 38:'쇼핑' };
const tourColor = t => { const st = ST(); return { 12:st.age, 14:st.day, 15:st.biz, 28:st.bus, 32:st.work, 38:st.bizCats[7] || st.focus }[t] || st.focus; };
async function tourCall(params){
  // 새 GW 서비스(KorService2)를 먼저, 안 되면 예전 이름(KorService1)으로
  let r = await dataGo('apis.data.go.kr/B551011/KorService2/locationBasedList2', params);
  if(!r.ok && !['limit', 'busy'].includes(r.code)){ const r1 = await dataGo('apis.data.go.kr/B551011/KorService1/locationBasedList1', params); if(r1.ok) r = r1; }
  return r;
}
async function runTour(){
  if(!hasRef()){ $('toursum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(TOUR.busy) return;
  TOUR.busy = true; $('tourrun').disabled = true;
  try{
    const c = SITE.center, R = Math.min(20000, Math.round(focusR())), out = new Map();
    for(const t of Object.keys(TOUR_TYPES)){
      for(let page = 1; page <= 5; page++){
        $('toursum').textContent = `${TOUR_TYPES[t]} 받는 중 (${page}쪽)`;
        const r = await tourCall({ MobileOS:'ETC', MobileApp:'CleanMap', mapX:c[0].toFixed(6), mapY:c[1].toFixed(6), radius:String(R), contentTypeId:t, arrange:'E', numOfRows:'100', pageNo:String(page) });
        if(!r.ok){ if(['unreg', 'denied', 'key'].includes(r.code)) throw new Error('한국관광공사 국문 관광정보 서비스 활용신청이 필요합니다 — ' + r.msg); break; }
        for(const x of r.items){ const lng = +x.mapx, lat = +x.mapy; if(!isFinite(lng) || !isFinite(lat) || !lng) continue; const m = toM([lng, lat]); if(!inFocus(m)) continue;
          out.set(x.contentid || x.title + lng, { t:+(x.contenttypeid || t), name:x.title || '', addr:x.addr1 || '', ll:[lng, lat], m }); }
        if(r.items.length < 100) break;
      }
    }
    TOUR.items = [...out.values()];
    registerTourLayers(); apply(); summarizeTour();
  }catch(err){ $('toursum').textContent = '실패 — ' + err.message; }
  TOUR.busy = false; $('tourrun').disabled = false;
}
function summarizeTour(){
  if(!TOUR.items) return;
  const cnt = {}; TOUR.items.forEach(x => cnt[x.t] = (cnt[x.t] || 0) + 1);
  const near = TOUR.items.filter(x => x.t === 12 || x.t === 14).sort((a, b) => Math.hypot(...a.m) - Math.hypot(...b.m))[0];
  $('toursum').textContent = `${TOUR.items.length}곳 · ` + Object.entries(TOUR_TYPES).map(([k, n]) => cnt[k] ? `${n} ${cnt[k]}` : '').filter(Boolean).join(' · ')
    + (near ? ` · 가장 가까운 ${TOUR_TYPES[near.t]} "${near.name}" ${(Math.hypot(...near.m) / 1000).toFixed(1)}km` : '');
}
function registerTourLayers(){
  extraRemove('tour-');
  if(!TOUR.on || !TOUR.items || !TOUR.items.length || !hasRef()) return;
  const st = ST(), mpp = mppNow();
  if(TOUR.form === 'circles'){
    const res = kdePeaks(TOUR.items.filter(x => x.t !== 32).map(x => [x.m[0], x.m[1], 1]));
    registerCircles('tour-cir-', '관광문화거점', res, st.day, p => `${Math.round(p.mass)}곳`);
    return;
  }
  for(const [t, nm] of Object.entries(TOUR_TYPES)){
    const xs = TOUR.items.filter(x => x.t === +t); if(!xs.length) continue;
    const col = tourColor(+t), r = mpp * (t === '12' || t === '14' ? 4.5 : 3.2);
    extraSet('tour-' + t, { label:`분석_관광문화_${nm}`, stage:'top', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:xs.map(x => [ringLL(x.m[0], x.m[1], r, 18)]) } }] },
      paint:{ 'fill-color':col, 'fill-opacity':0.9, 'fill-outline-color':st.paper }, svg:{ kind:'fill', fill:col, opacity:0.9 } });
  }
  // 관광지·문화시설만 이름표
  extraSet('tour-label', { label:'분석_관광문화_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:TOUR.items.filter(x => x.t === 12 || x.t === 14).map(x => ({ type:'Feature', properties:{ label:x.name }, geometry:{ type:'Point', coordinates:x.ll } })) },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10, 'text-offset':[0, 1.1], 'text-allow-overlap':false },
    paint:{ 'text-color':st.ink, 'text-halo-color':st.paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:st.ink, size:8 } });
}
function tourSummary(){
  if(!TOUR.on || !TOUR.items) return null;
  const cnt = {}; TOUR.items.forEach(x => cnt[TOUR_TYPES[x.t] || x.t] = (cnt[TOUR_TYPES[x.t] || x.t] || 0) + 1);
  return { source:'한국관광공사 국문 관광정보 서비스', by_type:cnt,
    nearest:TOUR.items.slice().sort((a, b) => Math.hypot(...a.m) - Math.hypot(...b.m)).slice(0, 8).map(x => ({ name:x.name, type:TOUR_TYPES[x.t], distance_m:Math.round(Math.hypot(...x.m)) })) };
}
$('touron').addEventListener('change', e => {
  TOUR.on = e.target.checked; $('touropts').hidden = !TOUR.on; $('card-tour').classList.toggle('on', TOUR.on);
  if(TOUR.on && !TOUR.items) runTour(); else { registerTourLayers(); apply(); }
});
$('tourdiag').addEventListener('change', e => { TOUR.form = e.target.value; registerTourLayers(); apply(); });
$('tourrun').addEventListener('click', () => { TOUR.items = null; runTour(); });
function placesOnSiteChange(){ LIFE.res = null; TOUR.items = null; extraRemove('life-'); extraRemove('tour-'); $('lifetable').hidden = true;
  if(SITE.mode === 'site' && hasRef()){ if(LIFE.on) runLife(); if(TOUR.on) runTour(); } }
