/* 클린 맵 배경 스크립트 — 툴바 아이콘·구글맵 버튼으로 뷰어를 새 탭에서 열고, 새 버전이 깔려 있으면 다시 불러옵니다 */

/* ---------- 새 버전 적용 ----------
   허브는 설치 폴더의 파일을 새 버전으로 바꿔 두지만, 압축해제된 확장은 크롬이 다시 불러오기 전까지
   처음 불러온 버전을 씁니다. 뷰어를 열 때 폴더의 manifest.json 버전이 지금 버전과 다르면
   확장을 다시 불러오고(chrome.runtime.reload), 다시 켜진 뒤 열려던 화면을 엽니다. */
async function diskVersion(){
  try{
    const r = await fetch(chrome.runtime.getURL('manifest.json') + '?t=' + Date.now(), { cache:'no-store' });
    return (await r.json()).version || null;
  }catch(e){ return null; }
}

async function reloadThenOpen(urls){
  const v = await diskVersion();
  if(!v || v === chrome.runtime.getManifest().version) return false;
  // 같은 버전으로 1분 안에 또 다시 불러오지 않게 (폴더가 이상해서 계속 다를 때 무한 반복 방지)
  const { lastReload } = await chrome.storage.local.get('lastReload');
  if(lastReload && lastReload.v === v && Date.now() - lastReload.at < 60000) return false;
  await chrome.storage.local.set({ reopen: urls || [], lastReload: { v, at: Date.now() } });
  chrome.runtime.reload();
  return true;
}

async function openViewer(tail){
  const url = chrome.runtime.getURL('index.html') + (tail || '');
  if(await reloadThenOpen([url])) return;
  chrome.tabs.create({ url });
}

chrome.action.onClicked.addListener(() => { openViewer(''); });

/* 구글맵에 얹은 버튼이 좌표나 검색어를 보내오면 그 위치로 엽니다.
   뷰어 화면(update.js)이 새 버전을 찾으면 applyUpdate 로 다시 불러오기를 부탁합니다. */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg) return false;
  if(msg.type === 'openViewer'){
    openViewer(msg.tail);
    sendResponse({ ok: true });
    return false;   // 동기 응답이므로 채널을 열어 두지 않습니다
  }
  if(msg.type === 'applyUpdate'){
    reloadThenOpen(Array.isArray(msg.urls) ? msg.urls : []);
    return false;
  }
  return false;
});

/* 다시 불러온 뒤 (onInstalled: reason 'update') — 열려던 화면을 엽니다 */
chrome.runtime.onInstalled.addListener(async () => {
  try{
    const { reopen } = await chrome.storage.local.get('reopen');
    if(Array.isArray(reopen) && reopen.length){
      await chrome.storage.local.remove('reopen');
      const base = chrome.runtime.getURL('');
      for(const u of reopen) if(typeof u === 'string' && u.startsWith(base)) chrome.tabs.create({ url: u });
    }
  }catch(e){}
});
