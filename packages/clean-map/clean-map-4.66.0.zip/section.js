/* ============================================================
   단면 · 스카이라인
   지도에 선(A–A′)을 그으면 그 선으로 자른 지형과 건물 단면,
   선 뒤쪽 건물(멀수록 연하게)과 배경 산 능선을 그린 SVG 를 만듭니다.
   · 지형: 표고 타일 (영역 ISO 와 같은 것)
   · 건물: 건물_국내 (높이 = 층수 × 층고, 층수가 없으면 1층 — 3D 매스와 같은 규칙)
   · 바다: 지도 타일의 물 면 (없으면 표고 0 이하)
   ============================================================ */
const SEC = { pick:false, a:null, el:null, line:null, depth:250, bg:1500, exag:1, flip:false, site:true, ground:'fill', sampler:null, skey:'', busy:false };
try{ const v = JSON.parse(localStorage.getItem('cleanmapSec') || 'null'); if(v) for(const k of ['depth', 'bg', 'exag', 'site', 'ground']) if(v[k] != null) SEC[k] = v[k]; }catch(e){}
const secSave = () => { try{ localStorage.setItem('cleanmapSec', JSON.stringify({ depth:SEC.depth, bg:SEC.bg, exag:SEC.exag, site:SEC.site, ground:SEC.ground })); }catch(e){} };
const secNote = m => { const n = $('secnote'); if(n) n.textContent = m; };

/* ---------- 선 긋기 — A 를 누르고, A′ 를 누릅니다 ---------- */
function secPickStart(){
  if(typeof ISO !== 'undefined' && ISO.pick && typeof isoPickEnd === 'function') isoPickEnd();
  if(SITE.picking) stopPick();
  SEC.pick = true; SEC.a = null;
  $('secpick').classList.add('primary'); $('secpick').textContent = '긋는 중 — A 를 누르세요 (Esc 취소)';
  map.getCanvas().style.cursor = 'crosshair';
  secNote('단면을 시작할 곳(A)을 누르고, 끝(A′)을 누르세요. 선의 왼쪽(진행 방향 기준)을 바라본 단면이 됩니다.');
}
function secPickEnd(){
  SEC.pick = false; SEC.a = null;
  if(SEC.el){ SEC.el.remove(); SEC.el = null; }
  if(map) map.getCanvas().style.cursor = '';
  $('secpick').classList.remove('primary'); $('secpick').textContent = '지도에서 단면선 긋기';
}
function secDraft(pt){
  if(!SEC.a) return;
  if(!SEC.el){
    SEC.el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    SEC.el.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:5';
    map.getCanvasContainer().appendChild(SEC.el);
  }
  const a = map.project(SEC.a), ink = ST().ink;
  SEC.el.innerHTML = `<line x1="${a.x}" y1="${a.y}" x2="${pt.x}" y2="${pt.y}" stroke="${ink}" stroke-width="1.5" stroke-dasharray="8 3 2 3"/>`
    + `<circle cx="${a.x}" cy="${a.y}" r="9" fill="#fff" stroke="${ink}"/><text x="${a.x}" y="${a.y + 4}" text-anchor="middle" font-size="11" font-weight="bold" fill="${ink}">A</text>`;
  const A = [SEC.a.lng, SEC.a.lat], B = map.unproject([pt.x, pt.y]), kx = 111320 * Math.cos(A[1] * Math.PI / 180);
  setStatus(`단면 길이 ${Math.round(Math.hypot((B.lng - A[0]) * kx, (B.lat - A[1]) * 110540)).toLocaleString()} m`);
}
(function hookSec(){
  if(typeof map === 'undefined' || !map || !map.on){ setTimeout(hookSec, 400); return; }
  map.on('click', e => {
    if(!SEC.pick) return;
    if(!SEC.a){ SEC.a = e.lngLat; $('secpick').textContent = '긋는 중 — 끝(A′)을 누르세요'; secDraft(e.point); return; }
    const A = [SEC.a.lng, SEC.a.lat], B = [e.lngLat.lng, e.lngLat.lat];
    secPickEnd();
    SEC.line = [A, B];
    registerSecLayers(); apply();
    runSection();
  });
  map.on('mousemove', e => { if(SEC.pick && SEC.a) secDraft(e.point); });
  map.on('move', () => { if(SEC.pick && SEC.a && SEC.el) SEC.el.innerHTML = ''; });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && SEC.pick){ secPickEnd(); secNote('취소했습니다'); } });
})();

/* ---------- 지도 위 단면선 — A·A′ 이름과 바라보는 쪽 화살 ---------- */
function registerSecLayers(){
  extraRemove('sec-');
  if(!SEC.line || SITE.mode !== 'site') return;
  const st = ST(), ink = st.ink;
  const [A, B] = SEC.line, kx = 111320 * Math.cos(A[1] * Math.PI / 180), ky = 110540;
  const toLm = ([lng, lat]) => [(lng - A[0]) * kx, (lat - A[1]) * ky], toLl = ([x, y]) => [A[0] + x / kx, A[1] + y / ky];
  const b = toLm(B), L = Math.hypot(b[0], b[1]); if(L < 1) return;
  const t = [b[0] / L, b[1] / L], d = SEC.flip ? [t[1], -t[0]] : [-t[1], t[0]];     // 바라보는 쪽
  const m = Math.max(8, Math.min(60, L * 0.04));
  // 양 끝: 바라보는 쪽으로 꺾인 짧은 화살 (단면 기호)
  const mark = p => { const tip = [p[0] + d[0] * m, p[1] + d[1] * m], w = m * 0.28;
    return [[p, tip].map(toLl), [[tip[0] - d[0] * w + t[0] * w * 0.7, tip[1] - d[1] * w + t[1] * w * 0.7], tip, [tip[0] - d[0] * w - t[0] * w * 0.7, tip[1] - d[1] * w - t[1] * w * 0.7]].map(toLl)]; };
  extraSet('sec-line', { label:'분석_단면선', stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:[A, B] } }] },
    layout:{ 'line-cap':'butt' }, paint:{ 'line-color':ink, 'line-width':1.3, 'line-dasharray':[7, 2.5, 1.5, 2.5] },
    svg:{ kind:'line', stroke:ink, width:1.1, dash:[7, 2.5, 1.5, 2.5] } });
  extraSet('sec-mark', { label:'분석_단면선_세부', stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:[...mark([0, 0]), ...mark(b)] } }] },
    layout:{ 'line-cap':'round', 'line-join':'round' }, paint:{ 'line-color':ink, 'line-width':2 }, svg:{ kind:'line', stroke:ink, width:1.8 } });
  const off = p => toLl([p[0] - t[0] * m * 0.8, p[1] - t[1] * m * 0.8]), off2 = p => toLl([p[0] + t[0] * m * 0.8, p[1] + t[1] * m * 0.8]);
  extraSet('sec-label', { label:'분석_단면선이름', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{ label:'A' }, geometry:{ type:'Point', coordinates:off([0, 0]) } }, { type:'Feature', properties:{ label:'A′' }, geometry:{ type:'Point', coordinates:off2(b) } }] },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':13, 'text-allow-overlap':true },
    paint:{ 'text-color':ink, 'text-halo-color':st.paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:ink, size:12 } });
}

/* ---------- 계산 ---------- */
/* 다각형 고리와 단면선(v = 0)이 겹치는 u 구간들 — (u, v) 좌표의 고리 */
function cutIntervals(uv, L){
  const xs = [];
  for(let i = 0; i < uv.length; i++){
    const [u1, v1] = uv[i], [u2, v2] = uv[(i + 1) % uv.length];
    if((v1 > 0) !== (v2 > 0)) xs.push(u1 + (u2 - u1) * (0 - v1) / (v2 - v1));
  }
  xs.sort((a, b) => a - b);
  const out = [];
  for(let i = 0; i + 1 < xs.length; i += 2){ const a = Math.max(0, xs[i]), b = Math.min(L, xs[i + 1]); if(b - a > 0.2) out.push([a, b]); }
  return out;
}
/* 바다·강 — 지도 타일의 물 면 (경위도) */
function secWater(bb){
  const polys = [];
  try{
    for(const f of map.querySourceFeatures('omt', { sourceLayer:'water' })){
      for(const poly of asMulti(f.geometry)){
        const r = poly[0]; let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        for(const [x, y] of r){ if(x < x0) x0 = x; if(x > x1) x1 = x; if(y < y0) y0 = y; if(y > y1) y1 = y; }
        if(x1 < bb[0] || x0 > bb[2] || y1 < bb[1] || y0 > bb[3]) continue;
        polys.push({ r, b:[x0, y0, x1, y1], holes:poly.slice(1) });
      }
    }
  }catch(e){}
  return ([lng, lat]) => polys.some(p => lng >= p.b[0] && lng <= p.b[2] && lat >= p.b[1] && lat <= p.b[3] && ringHas(p.r, lng, lat) && !p.holes.some(h => ringHas(h, lng, lat)));
}
async function runSection(){
  if(!SEC.line || SEC.busy) return;
  SEC.busy = true;
  try{
    const st = ST(), dark = (() => { const c = st.paper.replace('#', ''); return (parseInt(c.slice(0, 2), 16) + parseInt(c.slice(2, 4), 16) + parseInt(c.slice(4, 6), 16)) / 3 < 110; })();
    if(!LOC) setLocal(SITE.center || [map.getCenter().lng, map.getCenter().lat]);
    let A = toM(SEC.line[0]), B = toM(SEC.line[1]), la = 'A', lb = 'A′';
    if(SEC.flip){ [A, B] = [B, A]; [la, lb] = [lb, la]; }
    const L = Math.hypot(B[0] - A[0], B[1] - A[1]);
    if(L < 10){ secNote('단면선이 너무 짧습니다 (10m 이상)'); return; }
    const t = [(B[0] - A[0]) / L, (B[1] - A[1]) / L], n = [-t[1], t[0]];                // n: 바라보는 쪽 (진행 방향 왼쪽)
    const UV = ([x, y]) => [(x - A[0]) * t[0] + (y - A[1]) * t[1], (x - A[0]) * n[0] + (y - A[1]) * n[1]];
    const XY = (u, v) => [A[0] + t[0] * u + n[0] * v, A[1] + t[1] * u + n[1] * v];
    const Dd = Math.max(0, +SEC.depth || 0), Db = Math.max(0, +SEC.bg || 0), Dmax = Math.max(Dd, Db, 20);
    // 표고 — 단면선과 뒤쪽 깊이만큼의 띠
    const cs = [XY(-30, -40), XY(L + 30, -40), XY(L + 30, Dmax + 40), XY(-30, Dmax + 40)].map(toLL);
    const bb = [Math.min(...cs.map(c => c[0])), Math.min(...cs.map(c => c[1])), Math.max(...cs.map(c => c[0])), Math.max(...cs.map(c => c[1]))];
    const key = bb.map(v => v.toFixed(5)).join(',') + '|' + LOC.lng.toFixed(6) + LOC.lat.toFixed(6);
    if(SEC.skey !== key){ secNote('표고 받는 중'); $('secp-busy') && ($('secp-busy').textContent = '표고 받는 중…'); SEC.sampler = await demSampler(bb[0], bb[1], bb[2], bb[3]); SEC.skey = key; }
    const Z = SEC.sampler;
    // 1) 지반선
    const N = Math.min(1500, Math.max(240, Math.ceil(L / 1.5))), du = L / N, ground = [];
    const wet = secWater(bb), wetAt = [];
    for(let i = 0; i <= N; i++){ const u = i * du, p = XY(u, 0); ground.push(Z(p[0], p[1])); wetAt.push(wet(toLL(p))); }
    const gAt = u => { const k = Math.max(0, Math.min(N, u / du)), i = Math.min(N - 1, Math.floor(k)), f = k - i; return ground[i] * (1 - f) + ground[i + 1] * f; };
    // 2) 배경 능선 — 뒤쪽 띠에서 가장 높은 땅
    const sil = [];
    if(Db > 0){
      const M = Math.min(500, N), vs = Math.max(10, Db / 60);
      for(let i = 0; i <= M; i++){ const u = L * i / M; let zmax = -1e9, dAt = 0; for(let v = vs; v <= Db; v += vs){ const p = XY(u, v), z = Z(p[0], p[1]); if(z > zmax){ zmax = z; dAt = v; } } sil.push([u, zmax, dAt]); }
    }
    // 3) 건물 — 잘린 것 · 뒤쪽에 보이는 것
    const fc = VW.data && VW.data.building_kr, fh = S.bldFH || 3, cut = [], beyond = [];
    if(fc) for(const f of fc.features){
      const hi = typeof useHi === 'function' ? useHi(f.properties) : null, h = (floorsOf(f.properties) || 1) * fh;
      for(const poly of asMulti(f.geometry)){
        const ring = poly[0].map(toM), uv = ring.map(UV);
        let u0 = 1e9, u1 = -1e9, v0 = 1e9, v1 = -1e9;
        for(const [u, v] of uv){ if(u < u0) u0 = u; if(u > u1) u1 = u; if(v < v0) v0 = v; if(v > v1) v1 = v; }
        if(u1 < 0 || u0 > L || v1 < 0 || v0 > Dd) continue;
        const base = Math.min(...ring.map(([x, y]) => Z(x, y)));
        if(v0 < 0) for(const iv of cutIntervals(uv, L)) cut.push({ a:iv[0], b:iv[1], base, top:base + h, hi });
        else beyond.push({ a:Math.max(0, u0), b:Math.min(L, u1), base, top:base + h, d:v0, hi });
      }
    }
    // 4) 대지 — 단면선이 대지를 지나는 구간
    const siteIv = [];
    if(SEC.site && SITE.geom) for(const poly of mapRings(SITE.geom, toM)) siteIv.push(...cutIntervals(poly[0].map(UV), L));
    // 5) 크기
    const anyWet = wetAt.some(Boolean);
    const zLo = Math.min(...ground, anyWet ? 0 : 1e9), zHi = Math.max(...ground, ...cut.map(c => c.top), ...beyond.map(c => c.top), ...sil.map(s => s[1]), zLo + 5);
    const zb = zLo - Math.max(6, (zHi - zLo) * 0.1), zTop = zHi + Math.max(4, (zHi - zLo) * 0.06);
    const OUTW = 1800, padL = 78, padR = 46, padT = 64, padB = 86;
    const sx = (OUTW - padL - padR) / L, sy = sx * SEC.exag;
    const OUTH = Math.max(380, Math.round((zTop - zb) * sy + padT + padB));
    const X = u => (padL + u * sx).toFixed(1), Y = z => (padT + (zTop - z) * sy).toFixed(1);
    const FONT = `font-family="'Noto Sans CJK KR','Malgun Gothic',sans-serif"`;
    const ink = st.ink, paper = st.paper;
    const out = [`<svg xmlns="http://www.w3.org/2000/svg" width="${OUTW}" height="${OUTH}" viewBox="0 0 ${OUTW} ${OUTH}">`, `<rect width="100%" height="100%" fill="${paper}"/>`];
    // 배경 능선 (멀리 있는 산) — 땅보다 높은 곳만
    if(sil.length){                                                        // 능선 ~ 지반선 사이만 칠합니다
      const pts = sil.map(([u, z]) => `${X(u)},${Y(Math.max(z, gAt(u)))}`), back = sil.slice().reverse().map(([u]) => `${X(u)},${Y(gAt(u))}`);
      out.push(`<g id="배경_능선"><path d="M${pts.join('L')}L${back.join('L')}Z" fill="${hexMix(paper, ink, dark ? 0.16 : 0.07)}"/>`
        + `<path d="M${pts.join('L')}" fill="none" stroke="${hexMix(paper, ink, dark ? 0.35 : 0.22)}" stroke-width="0.8"/></g>`);
    }
    // 뒤쪽 건물 — 먼 것부터, 멀수록 연하게
    if(beyond.length){
      beyond.sort((p, q) => q.d - p.d);
      const o = [];
      for(const b of beyond){
        const k = Dd ? Math.min(1, b.d / Dd) : 0, base = b.hi ? useColor(b.hi, st.mass) : st.mass;
        const fill = hexMix(base, paper, 0.12 + 0.6 * k), stroke = hexMix(st.massEdge, paper, 0.25 + 0.6 * k);
        o.push(`<rect x="${X(b.a)}" y="${Y(b.top)}" width="${Math.max(0.3, (b.b - b.a) * sx).toFixed(1)}" height="${Math.max(0.3, (b.top - b.base) * sy).toFixed(1)}" fill="${fill}" stroke="${stroke}" stroke-width="0.6"/>`);
      }
      out.push(`<g id="뒤쪽_건물">${o.join('')}</g>`);
    }
    // 지반 (자른 땅) — 채움 또는 선만
    const gpts = ground.map((z, i) => `${X(i * du)},${Y(z)}`).join('L');
    const gFill = hexMix(paper, ink, dark ? 0.4 : 0.62);
    out.push(`<g id="지반"><path d="M${X(0)},${Y(zb)}L${gpts}L${X(L)},${Y(zb)}Z" fill="${SEC.ground === 'line' ? paper : gFill}"/>`   // 선만이어도 땅 아래로 내려간 뒤쪽 건물은 가립니다
      + `<path d="M${gpts}" fill="none" stroke="${ink}" stroke-width="1.6" stroke-linejoin="round"/></g>`);
    // 바다·강 — 수면(표고 0)부터 아래로
    if(anyWet){
      const seg = []; let s0 = -1;
      for(let i = 0; i <= N; i++){ if(wetAt[i] && s0 < 0) s0 = i; if((!wetAt[i] || i === N) && s0 >= 0){ seg.push([s0 * du, (wetAt[i] ? i : i - 1) * du]); s0 = -1; } }
      const wc = hexMix(paper, '#4F86B5', dark ? 0.45 : 0.32);
      out.push(`<g id="물">${seg.filter(([a, b]) => b - a > 0.5).map(([a, b]) => `<rect x="${X(a)}" y="${Y(0)}" width="${((b - a) * sx).toFixed(1)}" height="${((0 - zb) * sy).toFixed(1)}" fill="${wc}"/><path d="M${X(a)},${Y(0)}H${X(b)}" stroke="${hexMix(wc, ink, 0.4)}" stroke-width="1"/>`).join('')}</g>`);
    }
    // 잘린 건물 — 진하게 (용도 칠하기를 켰으면 그 색)
    if(cut.length){
      const cutC = hexMix(paper, ink, dark ? 0.75 : 0.86);
      out.push(`<g id="잘린_건물">${cut.map(c => `<rect x="${X(c.a)}" y="${Y(c.top)}" width="${((c.b - c.a) * sx).toFixed(1)}" height="${((c.top - c.base) * sy).toFixed(1)}" fill="${c.hi ? hexMix(useColor(c.hi), ink, 0.25) : cutC}" stroke="${ink}" stroke-width="0.8"/>`).join('')}</g>`);
    }
    // 대지
    if(siteIv.length){
      const o = [];
      for(const [a, b] of siteIv){
        const zg = Math.max(...ground.slice(Math.floor(a / du), Math.ceil(b / du) + 1)), hTop = Math.max(zg + (zTop - zg) * 0.55, ...cut.filter(c => c.b > a && c.a < b).map(c => c.top));
        o.push(`<rect x="${X(a)}" y="${Y(hTop)}" width="${((b - a) * sx).toFixed(1)}" height="${((hTop - zg) * sy).toFixed(1)}" fill="${st.site}" fill-opacity="0.1"/>`,
          `<path d="M${X(a)},${Y(hTop)}V${Y(gAt(a))}M${X(b)},${Y(hTop)}V${Y(gAt(b))}" stroke="${st.site}" stroke-width="0.9" stroke-dasharray="4 3"/>`,
          `<path d="M${ground.map((z, i) => [i * du, z]).filter(([u]) => u >= a && u <= b).map(([u, z]) => `${X(u)},${Y(z)}`).join('L')}" fill="none" stroke="${st.site}" stroke-width="3.2" stroke-linecap="round"/>`,
          `<text x="${X((a + b) / 2)}" y="${(+Y(hTop) - 8).toFixed(1)}" text-anchor="middle" ${FONT} font-size="13" font-weight="bold" fill="${st.site}">대지</text>`);
      }
      out.push(`<g id="대지">${o.join('')}</g>`);
    }
    // 표고 눈금 (왼쪽)
    const span = zTop - zb, step = [1, 2, 5, 10, 20, 50, 100, 200].find(v => span / v <= 8) || 500, tk = [];
    for(let z = Math.ceil(zb / step) * step; z <= zTop; z += step) tk.push(`<path d="M${padL - 6},${Y(z)}H${padL}" stroke="${ink}" stroke-width="0.8"/><text x="${padL - 10}" y="${(+Y(z) + 3.5).toFixed(1)}" text-anchor="end" ${FONT} font-size="10" fill="${ink}" fill-opacity="0.75">${z === 0 ? 'EL ±0' : 'EL ' + (z > 0 ? '+' : '') + z}</text>`);
    out.push(`<g id="표고">` + `<path d="M${padL},${Y(zb)}V${Y(zTop)}" stroke="${ink}" stroke-width="0.8"/>` + tk.join('') + '</g>');
    // 끝 기호 A · A′
    const bub = (u, txt) => `<line x1="${X(u)}" y1="${padT - 14}" x2="${X(u)}" y2="${Y(gAt(u))}" stroke="${ink}" stroke-opacity="0.35" stroke-width="0.7" stroke-dasharray="2 3"/><circle cx="${X(u)}" cy="${padT - 30}" r="13" fill="${paper}" stroke="${ink}" stroke-width="1"/><text x="${X(u)}" y="${padT - 25.5}" text-anchor="middle" ${FONT} font-size="13" font-weight="bold" fill="${ink}">${txt}</text>`;
    out.push(`<g id="단면기호">${bub(0, la)}${bub(L, lb)}</g>`);
    // 축척 막대 · 제목
    const tgt = 160 / sx, pw = Math.pow(10, Math.floor(Math.log10(tgt))), mm = [1, 2, 5, 10].map(v => v * pw).find(v => v >= tgt * 0.6) || pw * 10;
    out.push(typeof scaleBarSVG === 'function' ? scaleBarSVG(typeof NS !== 'undefined' && NS.bar !== 'none' ? NS.bar : 'blocks', padL, OUTH - 34, mm, mm * sx, ink, paper, null) : '');
    const info = `단면 ${la}–${lb} · 길이 ${Math.round(L).toLocaleString()} m` + (SEC.exag !== 1 ? ` · 높이 ×${(+SEC.exag).toFixed(1)}` : '') + ` · 뒤쪽 건물 ${Math.round(Dd)} m · 배경 능선 ${Db >= 1000 ? (Db / 1000).toFixed(1) + ' km' : Math.round(Db) + ' m'} · 건물 높이 = 층수 × ${fh} m`;
    out.push(`<text x="${OUTW - padR}" y="${OUTH - 24}" text-anchor="end" ${FONT} font-size="11" fill="${ink}" fill-opacity="0.7">${esc(info)}</text>`, '</svg>');
    secNote(`완료 · 길이 ${Math.round(L).toLocaleString()} m · 잘린 건물 ${cut.length} · 뒤쪽 건물 ${beyond.length}` + (fc ? '' : ' (건물_국내를 아직 받지 못했습니다 — 줌 15 이상)'));
    showSecPreview(out.join(''), `${la}–${lb} ${Math.round(L)}m`);
  }catch(err){ console.error(err); secNote('실패 — ' + err.message); }
  finally{ SEC.busy = false; }
}

/* ---------- 미리보기 ---------- */
function secPreviewEl(){
  let el = $('secprev'); if(el) return el;
  el = document.createElement('div'); el.id = 'secprev';
  el.innerHTML = `
    <div class="sp-box">
      <div class="sp-head">
        <b>단면 · 스카이라인 미리보기</b> <span id="secp-title" class="num"></span>
        <label>뒤쪽 건물 <input type="range" id="secp-depth" min="0" max="800" step="25"> <span id="secp-depthv" class="num"></span></label>
        <label>배경 능선 <input type="range" id="secp-bg" min="0" max="3000" step="100"> <span id="secp-bgv" class="num"></span></label>
        <label>높이 과장 <input type="range" id="secp-exag" min="1" max="3" step="0.1"> <span id="secp-exagv" class="num"></span></label>
        <label><select id="secp-ground"><option value="fill">지반 채움</option><option value="line">지반 선만</option></select></label>
        <label><input type="checkbox" id="secp-site"> 대지 표시</label>
        <button class="btn" id="secp-flip" title="반대쪽을 바라본 단면 (A′ 가 왼쪽)">방향 뒤집기</button>
        <span id="secp-busy"></span>
      </div>
      <div class="sp-body" id="secp-body"></div>
      <div class="sp-foot">
        <span id="secp-info"></span>
        <button class="btn" id="secp-redraw">단면선 다시 긋기</button>
        <button class="btn primary" id="secp-save">SVG 저장</button>
        <button class="btn" id="secp-close">닫기</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  const css = document.createElement('style');
  css.textContent = `
    #secprev{position:fixed;inset:0;background:rgba(20,22,26,.55);z-index:9999;display:none;align-items:center;justify-content:center}
    #secprev .sp-box{background:var(--bg);color:var(--text);border:1px solid var(--line-2);width:min(1320px,96vw);height:min(820px,92vh);display:flex;flex-direction:column;border-radius:6px;overflow:hidden;box-shadow:var(--shadow)}
    #secprev .sp-head,#secprev .sp-foot{display:flex;gap:14px;align-items:center;padding:8px 12px;font-size:12px;border-bottom:1px solid var(--line);flex-wrap:wrap}
    #secprev .sp-foot{border-top:1px solid var(--line);border-bottom:0;justify-content:flex-end}
    #secprev .sp-foot #secp-info{margin-right:auto;color:var(--text-2)}
    #secprev .sp-head label{display:flex;gap:5px;align-items:center}
    #secprev .sp-head input[type=range]{width:110px}
    #secprev .sp-body{flex:1;overflow:auto;background:var(--bg-3);display:flex;align-items:flex-start;justify-content:center;padding:14px}
    #secprev .sp-body svg{max-width:100%;height:auto;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.12)}
    #secprev #secp-busy{color:var(--text-2)}
    #secprev select{width:auto;height:24px;font-size:12px;padding:0 4px}`;
  document.head.appendChild(css);
  let tmr = null;
  const later = () => { clearTimeout(tmr); tmr = setTimeout(() => { secSave(); runSection(); }, 250); };
  const sync = () => {
    $('secp-depthv').textContent = SEC.depth + ' m'; $('secp-bgv').textContent = SEC.bg >= 1000 ? (SEC.bg / 1000).toFixed(1) + ' km' : SEC.bg ? SEC.bg + ' m' : '없음';
    $('secp-exagv').textContent = '×' + (+SEC.exag).toFixed(1);
  };
  el.querySelector('#secp-depth').oninput = e => { SEC.depth = +e.target.value; sync(); later(); };
  el.querySelector('#secp-bg').oninput = e => { SEC.bg = +e.target.value; sync(); later(); };
  el.querySelector('#secp-exag').oninput = e => { SEC.exag = +e.target.value; sync(); later(); };
  el.querySelector('#secp-ground').onchange = e => { SEC.ground = e.target.value; secSave(); runSection(); };
  el.querySelector('#secp-site').onchange = e => { SEC.site = e.target.checked; secSave(); runSection(); };
  el.querySelector('#secp-flip').onclick = () => { SEC.flip = !SEC.flip; registerSecLayers(); apply(); runSection(); };
  el.querySelector('#secp-close').onclick = () => { el.style.display = 'none'; };
  el.querySelector('#secp-redraw').onclick = () => { el.style.display = 'none'; secPickStart(); };
  el.querySelector('#secp-save').onclick = () => {
    const svg = $('secp-body').querySelector('svg'); if(!svg) return;
    download(stamp() + '_단면_' + ($('secp-title').textContent || '').replace(/[\\/:*?"<>|\s]/g, '') + '.svg', new XMLSerializer().serializeToString(svg), 'image/svg+xml');
  };
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && el.style.display === 'flex') el.style.display = 'none'; });
  SEC.sync = sync;
  return el;
}
function showSecPreview(svg, title){
  const el = secPreviewEl();
  $('secp-depth').value = SEC.depth; $('secp-bg').value = SEC.bg; $('secp-exag').value = SEC.exag;
  $('secp-ground').value = SEC.ground; $('secp-site').checked = !!SEC.site; SEC.sync();
  $('secp-title').textContent = title;
  $('secp-body').innerHTML = svg;
  $('secp-busy').textContent = '';
  $('secp-info').textContent = ($('secnote') ? $('secnote').textContent : '').replace(/^완료 · /, '');
  el.style.display = 'flex';
}

/* ---------- 패널 ---------- */
$('secpick').addEventListener('click', () => { if(SEC.pick){ secPickEnd(); secNote('취소했습니다'); } else secPickStart(); });
$('secshow').addEventListener('click', () => { if(SEC.line) runSection(); else secNote('먼저 지도에서 단면선을 그어 주세요'); });
$('secclear').addEventListener('click', () => { SEC.line = null; extraRemove('sec-'); apply(); secNote('단면선을 지웠습니다'); });
