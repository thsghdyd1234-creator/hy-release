/* ============================================================
   패널 다루기 — 밝기 · 탭 · 설명(ⓘ) · 색 칩 작은 창
   기능 스크립트(app.js 등)는 그대로 두고, 패널 모양만 맡습니다.
   이 파일은 <head>에서 읽어 밝기를 먼저 정하고, 나머지는 문서가 다 읽힌 뒤에 붙입니다.
   ============================================================ */
(function(){
  const store = {
    get(k, d){ try{ const v = localStorage.getItem(k); return v === null ? d : v; }catch(e){ return d; } },
    set(k, v){ try{ localStorage.setItem(k, v); }catch(e){} }
  };

  /* --- 밝기 (어둡게 기본 · 밝게) --- */
  const THEME_KEY = 'cleanmapUiTheme';
  const applyTheme = t => { document.documentElement.dataset.theme = t === 'light' ? 'light' : 'dark'; };
  applyTheme(store.get(THEME_KEY, 'dark'));

  document.addEventListener('DOMContentLoaded', init);

  function init(){
    const $ = id => document.getElementById(id);
    let pop = null, anchor = null;                 // 색 창 (아래에서 씁니다)

    const tb = $('uitheme');
    const themeLabel = () => { if(tb) tb.title = document.documentElement.dataset.theme === 'light' ? '패널 어둡게' : '패널 밝게'; };
    themeLabel();
    if(tb) tb.addEventListener('click', () => {
      const t = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
      applyTheme(t); store.set(THEME_KEY, t); themeLabel();
    });

    /* --- 탭 --- */
    const navs = [...document.querySelectorAll('nav.tabs')];
    function selectTab(nav, id, keepScroll){
      const mode = nav.closest('.mode');
      for(const b of nav.querySelectorAll('[data-tab]')){
        const on = b.dataset.tab === id;
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        const p = $('pane-' + b.dataset.tab); if(p) p.hidden = !on;
      }
      store.set('cleanmapTab_' + nav.dataset.tabs, id);
      if(!keepScroll){ const sc = mode && mode.querySelector('.panes'); if(sc) sc.scrollTop = 0; }
      closePop();
    }
    for(const nav of navs){
      const btns = [...nav.querySelectorAll('[data-tab]')];
      btns.forEach(b => { const p = $('pane-' + b.dataset.tab); if(p) b.setAttribute('aria-controls', p.id); });
      const saved = store.get('cleanmapTab_' + nav.dataset.tabs, '');
      selectTab(nav, btns.some(b => b.dataset.tab === saved) ? saved : btns[0].dataset.tab, true);
      nav.addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if(b) selectTab(nav, b.dataset.tab); });
      nav.addEventListener('keydown', e => {
        if(e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        const i = btns.findIndex(b => b.getAttribute('aria-selected') === 'true');
        const n = btns[(i + (e.key === 'ArrowRight' ? 1 : btns.length - 1)) % btns.length];
        selectTab(nav, n.dataset.tab); n.focus(); e.preventDefault();
      });
    }
    /* 숨은 탭에 있는 칸을 보여 줘야 할 때 — 그 탭으로 넘어가 가운데로 */
    window.uiReveal = node => {
      const pane = node && node.closest('.pane'); if(!pane) return;
      const nav = pane.closest('.mode') && pane.closest('.mode').querySelector('nav.tabs');
      if(pane.hidden && nav) selectTab(nav, pane.id.replace(/^pane-/, ''), true);
      node.scrollIntoView({ block:'center' });
    };

    /* --- 설명: 칸 제목 옆 ⓘ 로 펼치고 접기 --- */
    for(const sec of document.querySelectorAll('.pane .sec')){
      if(!sec.querySelector('.tip')) continue;
      const head = sec.querySelector('.sec-h'); if(!head) continue;
      const b = document.createElement('button');
      b.className = 'tipbtn'; b.type = 'button'; b.textContent = 'i';
      b.title = '설명 보기'; b.setAttribute('aria-label', '설명 보기'); b.setAttribute('aria-pressed', 'false');
      b.addEventListener('click', () => {
        const on = sec.classList.toggle('tips-on');
        b.setAttribute('aria-pressed', String(on)); b.title = on ? '설명 접기' : '설명 보기';
        if(on) sec.querySelectorAll('details.more').forEach(d => { if(d.querySelector('.tip')) d.open = true; });
      });
      head.appendChild(b);
    }

    /* --- 스타일 칸 제목 옆에 고른 스타일 이름 --- */
    const presets = $('presets'), pname = $('presetname');
    const syncPreset = () => {
      if(!presets || !pname) return;
      const sel = presets.querySelector('.swatch[aria-pressed="true"]');
      pname.textContent = sel ? sel.textContent.trim().replace(/\s+/g, ' ') : '';
      presets.querySelectorAll('.swatch').forEach(s => { if(!s.title) s.title = s.textContent.trim().replace(/\s+/g, ' '); });
    };
    if(presets){ syncPreset(); new MutationObserver(syncPreset).observe(presets, { childList:true, subtree:true, attributes:true, attributeFilter:['aria-pressed'] }); }

    /* --- 켠 분석 개수 → 칸 제목과 탭에 --- */
    const anal = $('pane-t-anal'), analTab = document.querySelector('[data-tab="t-anal"]');
    const syncAnal = () => {
      if(!anal) return;
      const n = anal.querySelectorAll('.card.on').length;
      if($('analcount')) $('analcount').textContent = n ? n + '개 켬' : '';
      if(analTab){ let bd = analTab.querySelector('b'); if(n){ if(!bd){ bd = document.createElement('b'); analTab.appendChild(bd); } bd.textContent = n; } else if(bd) bd.remove(); }
    };
    if(anal){ syncAnal(); new MutationObserver(syncAnal).observe(anal, { subtree:true, attributes:true, attributeFilter:['class'] }); }

    /* --- 숨은 탭에서 할 일이 생기면 탭에 점 (예: 넓은 범위도 불러오기) --- */
    const attn = [['vwreload', 's-data']];
    for(const [id, tab] of attn){
      const n = $(id), t = document.querySelector(`[data-tab="${tab}"]`); if(!n || !t) continue;
      const sync = () => { let d = t.querySelector('b.dot'); if(!n.hidden){ if(!d){ d = document.createElement('b'); d.className = 'dot'; d.textContent = '!'; d.title = n.textContent; t.appendChild(d); } } else if(d) d.remove(); };
      sync(); new MutationObserver(sync).observe(n, { attributes:true, attributeFilter:['hidden'] });
    }

    /* --- 색 칩(레이어·층수·용도지역) → 그 자리에 작은 색 창 --- */
    const editor = $('coloredit'), home = editor && editor.parentNode, homeNext = editor && editor.nextSibling;
    function place(){
      if(!pop || !anchor) return;
      const r = anchor.getBoundingClientRect(), aside = $('panel').getBoundingClientRect();
      const W = pop.offsetWidth, H = pop.offsetHeight, vw = innerWidth, vh = innerHeight;
      let x = aside.right + 10, y = r.top + r.height / 2 - 24;
      if(x + W > vw - 8){ x = Math.max(8, Math.min(vw - W - 8, r.left)); y = r.bottom + 8; }   // 좁은 화면 — 칩 아래로
      y = Math.max(8, Math.min(vh - H - 8, y));
      pop.style.left = x + 'px'; pop.style.top = y + 'px';
    }
    function openPop(chip){
      if(!editor) return;
      if(!pop){
        pop = document.createElement('div'); pop.id = 'colorpop'; pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-label', '색 고치기');
        pop.innerHTML = '<div class="cp-h"><span>색 고치기 — SVG에도 그대로 들어갑니다</span><button class="iconbtn" type="button" aria-label="닫기" title="닫기 (Esc)">✕</button></div>';
        pop.querySelector('button').addEventListener('click', closePop);
        document.body.appendChild(pop);
      }
      pop.appendChild(editor); pop.hidden = false; anchor = chip; place();
      const hex = $('hex'); if(hex) hex.focus({ preventScroll:true });
    }
    function closePop(){
      if(!pop || pop.hidden) return;
      pop.hidden = true; anchor = null;
      if(home) home.insertBefore(editor, homeNext && homeNext.parentNode === home ? homeNext : null);
    }
    window.uiColorPop = openPop;
    document.addEventListener('click', e => {
      const chip = e.target.closest && e.target.closest('.lpick, .zpick, .bpick');
      if(chip){ openPop(chip); return; }
    });
    document.addEventListener('mousedown', e => {
      if(!pop || pop.hidden) return;
      if(pop.contains(e.target) || (e.target.closest && e.target.closest('.lpick, .zpick, .bpick'))) return;
      closePop();
    });
    document.addEventListener('keydown', e => { if(e.key === 'Escape') closePop(); });
    addEventListener('resize', place);
    document.querySelectorAll('.panes').forEach(p => p.addEventListener('scroll', closePop, { passive:true }));
    const modes = $('modes'); if(modes) modes.addEventListener('click', closePop);
  }
})();
