/* ============================================================
   상권 (소상공인시장진흥공단 상가(상권)정보) — transit.js 다음에 읽힙니다.
   반경조회를 여러 번 찍지 않고, 분석 범위를 사각형으로 받아 전체를 가져옵니다.
   한 사각형에 상가가 너무 많으면 네 조각으로 나눠 다시 받습니다.
   ============================================================ */
const SDSC = 'apis.data.go.kr/B553077/api/open/sdsc2';
const BIZ = { on:false, busy:false, items:null, form:'auto', cat:'', partial:false, calls:0 };
const BIZ_CATS = ['소매', '음식', '수리·개인', '과학·기술', '교육', '부동산', '시설관리·임대', '숙박', '예술·스포츠', '보건의료'];
const BIZ_COLORS = ['#E0782B', '#D4453A', '#8C6BB1', '#2F6FDB', '#2E9E8F', '#7A7A7A', '#A0856A', '#C9A227', '#58A55C', '#C2447C'];
const bizColor = name => { const i = BIZ_CATS.findIndex(c => (name || '').replace(/\s/g, '').startsWith(c.replace(/[·\s]/g, '').slice(0, 2))); return i >= 0 ? ST().bizCats[i] : ST().focus; };

$('bizon').addEventListener('change', e => {
  BIZ.on = e.target.checked;
  $('bizopts').hidden = !BIZ.on;
  $('card-biz').classList.toggle('on', BIZ.on);
  if(BIZ.on && hasRef() && !BIZ.items) runBiz(); else { registerBizLayers(); apply(); }
});
$('bizform').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; BIZ.form = b.dataset.v; segSync('bizform', BIZ.form); registerBizLayers(); apply(); });
$('bizcat').addEventListener('change', e => { BIZ.cat = e.target.value; registerBizLayers(); apply(); summarizeBiz(); });
$('bizrun').addEventListener('click', () => { BIZ.items = null; runBiz(); });
segSync('bizform', BIZ.form);
function bizOnSiteChange(){ BIZ.items = null; extraRemove('biz-'); if(BIZ.on && hasRef() && SITE.mode === 'site') runBiz(); }

/* 응답 한 줄 → 필요한 칸만 (열 이름이 한글이든 영문이든) */
function bizRow(x){
  const lon = +(x.lon ?? x['경도']), lat = +(x.lat ?? x['위도']);
  if(!isFinite(lon) || !isFinite(lat)) return null;
  return { id: x.bizesId ?? x['상가업소번호'], name: x.bizesNm ?? x['상호명'] ?? '',
           l: x.indsLclsNm ?? x['상권업종대분류명'] ?? '', m: x.indsMclsNm ?? x['상권업종중분류명'] ?? '',
           s: x.indsSclsNm ?? x['상권업종소분류명'] ?? '', fl: String(x.flrNo ?? x['층정보'] ?? ''), ll:[lon, lat] };
}

async function bizRect(x0, y0, x1, y1, depth, out, stat){
  if(stat.calls >= stat.max){ stat.partial = true; return; }
  // 범위(원·화면)와 겹치지 않는 조각은 건너뜁니다
  const cx = Math.max(x0, Math.min(0, x1)), cy = Math.max(y0, Math.min(0, y1));
  if(!(SITE.range === 'view' && SITE.viewLL) && Math.hypot(cx, cy) > focusR()) return;
  const [w, s] = toLL([x0, y0]), [e, n] = toLL([x1, y1]);
  const base = { minx:w.toFixed(6), miny:s.toFixed(6), maxx:e.toFixed(6), maxy:n.toFixed(6), type:'json', numOfRows:'1000' };
  stat.calls++; $('bizsum').textContent = `상가 받는 중 · 호출 ${stat.calls} · ${out.size.toLocaleString()}곳`;
  const r = await dataGo(SDSC + '/storeListInRectangle', { ...base, pageNo:'1' });
  if(!r.ok){
    if(['key', 'denied', 'unreg', 'limit'].includes(r.code)) throw new Error(r.msg);
    if(depth < 5){ return bizSplit(x0, y0, x1, y1, depth, out, stat); }   // 너무 넓어서 거절됐을 수 있어 나눠 봅니다
    stat.partial = true; return;
  }
  const total = r.total || r.items.length;
  if(total > 3000 && depth < 5) return bizSplit(x0, y0, x1, y1, depth, out, stat);
  const add = items => { for(const x of items){ const b = bizRow(x); if(b && !out.has(b.id)) out.set(b.id || b.ll.join(), b); } };
  add(r.items);
  for(let p = 2; p <= Math.ceil(total / 1000) && stat.calls < stat.max; p++){
    stat.calls++; $('bizsum').textContent = `상가 받는 중 · 호출 ${stat.calls} · ${out.size.toLocaleString()}곳`;
    const q = await dataGo(SDSC + '/storeListInRectangle', { ...base, pageNo:String(p) });
    if(q.ok) add(q.items); else break;
  }
}
async function bizSplit(x0, y0, x1, y1, depth, out, stat){
  const mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
  for(const [a, b, c, d] of [[x0, y0, mx, my], [mx, y0, x1, my], [x0, my, mx, y1], [mx, my, x1, y1]])
    await bizRect(a, b, c, d, depth + 1, out, stat);
}

async function runBiz(){
  if(!hasRef()){ $('bizsum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(BIZ.busy) return;
  BIZ.busy = true; $('bizrun').disabled = true;
  try{
    let x0, y0, x1, y1;
    if(SITE.range === 'view' && SITE.viewLL){ [[x0, y0], [x1, y1]] = viewRectM(); }
    else { const R = focusR(); x0 = -R; y0 = -R; x1 = R; y1 = R; }
    const out = new Map(), stat = { calls:0, max:120, partial:false };
    await bizRect(x0, y0, x1, y1, 0, out, stat);
    const items = [...out.values()].map(b => ({ ...b, m_:toM(b.ll) })).filter(b => inFocus(b.m_));
    BIZ.items = items; BIZ.partial = stat.partial; BIZ.calls = stat.calls; BIZ.street = null; BIZ.zones = null;
    // 업종 목록
    const cats = [...new Set(items.map(b => b.l).filter(Boolean))].sort();
    $('bizcat').innerHTML = '<option value="">전체 업종</option>' + cats.map(c => `<option>${esc(c)}</option>`).join('');
    $('bizcat').value = cats.includes(BIZ.cat) ? BIZ.cat : ''; BIZ.cat = $('bizcat').value;
    registerBizLayers(); apply(); summarizeBiz();
  }catch(err){
    $('bizsum').textContent = '실패 — ' + err.message;
    setStatus('상권 정보 실패 — ' + esc(err.message), true);
  }
  BIZ.busy = false; $('bizrun').disabled = false;
}

/* ---------- 밀도 격자 ---------- */
function bizGrid(list){
  const FR = focusR();
  const cell = Math.max(40, Math.min(300, Math.round(FR / 30 / 10) * 10));   // 범위에 맞춘 칸 크기
  const g = new Map();
  for(const b of list){ const k = Math.floor(b.m_[0] / cell) + ',' + Math.floor(b.m_[1] / cell); g.set(k, (g.get(k) || 0) + 1); }
  return { cell, g };
}
function registerBizLayers(){
  extraRemove('biz-');
  if(!BIZ.on || !BIZ.items || !hasRef()) return;
  const list = BIZ.cat ? BIZ.items.filter(b => b.l === BIZ.cat) : BIZ.items;
  if(!list.length) return;
  const form = BIZ.form === 'auto' ? (list.length > 400 || focusR() > 800 ? 'kde' : 'points') : BIZ.form;
  if(form === 'zones'){ drawZones(); return; }
  if(form === 'mix'){ drawBizMix(list); return; }
  if(form === 'street'){ drawBizStreet(); return; }
  if(form === 'circles'){
    const res = kdePeaks(list.map(b => [b.m_[0], b.m_[1], 1]));
    registerCircles('biz-cir-', BIZ.cat ? `상권거점(${BIZ.cat})` : '상권거점', res, BIZ.cat ? bizColor(BIZ.cat) : ST().biz, p => `${Math.round(p.mass).toLocaleString()}곳`);
    BIZ.peaks = res.peaks; return;
  }
  if(form === 'kde'){
    const res = kdeBands(list.map(b => [b.m_[0], b.m_[1], 1]));
    registerBands('biz-kde-', BIZ.cat ? `상가밀도(${BIZ.cat})` : '상가밀도', res, BIZ.cat ? bizColor(BIZ.cat) : ST().biz);
    BIZ.kde = res; return;
  }
  if(form === 'grid'){
    const { cell, g } = bizGrid(list);
    const vals = [...g.values()].sort((a, b) => a - b);
    const q = f => vals[Math.min(vals.length - 1, Math.floor(f * vals.length))];
    const cuts = [q(0.5), q(0.75), q(0.9), q(0.97)];
    const ramp = rampFrom(ST().biz, 5);
    const bins = [[], [], [], [], []];
    for(const [k, n] of g){
      const [i, j] = k.split(',').map(Number);
      const lvl = n >= cuts[3] ? 4 : n >= cuts[2] ? 3 : n >= cuts[1] ? 2 : n >= cuts[0] ? 1 : 0;
      const ring = [[i * cell, j * cell], [(i + 1) * cell, j * cell], [(i + 1) * cell, (j + 1) * cell], [i * cell, (j + 1) * cell], [i * cell, j * cell]].map(toLL);
      bins[lvl].push([ring]);
    }
    const perHa = v => (v / (cell * cell / 10000)).toFixed(0);
    bins.forEach((polys, k) => {
      if(!polys.length) return;
      extraSet('biz-grid-' + k, { label:`분석_상가밀도_${k + 1}_${k ? perHa(cuts[k - 1]) + '곳/ha 이상' : '하위'}`, stage:'ground', type:'fill', nomerge:true,
        fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{ k }, geometry:{ type:'MultiPolygon', coordinates:polys } }] },
        paint:{ 'fill-color':ramp[k], 'fill-opacity':0.9 }, svg:{ kind:'fill', fill:ramp[k], opacity:0.9 } });
    });
    BIZ.gridInfo = { cell, cuts };
  }else{
    // 업종별 작은 원 (내보내기에서도 면으로 남게 다각형으로 만듭니다)
    const by = new Map();
    for(const b of list){ if(!by.has(b.l)) by.set(b.l, []); by.get(b.l).push(b); }
    const r = Math.max(2.5, Math.min(8, focusR() / 200));
    for(const [cat, arr] of by){
      const polys = arr.map(b => [circleM(r, 8)[0][0].map(([x, y]) => toLL([b.m_[0] + x, b.m_[1] + y]))]);
      const col = bizColor(cat);
      extraSet('biz-pt-' + (BIZ_CATS.indexOf(cat) >= 0 ? BIZ_CATS.indexOf(cat) : cat), { label:`분석_상가_${cat || '미분류'}`, stage:'top', type:'fill', nomerge:true,
        fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:polys } }] },
        paint:{ 'fill-color':col, 'fill-opacity':0.85 }, svg:{ kind:'fill', fill:col, opacity:0.85 } });
    }
  }
}

function bizStats(){
  const list = BIZ.cat ? BIZ.items.filter(b => b.l === BIZ.cat) : BIZ.items;
  const count = (arr, key) => { const m = {}; for(const b of arr) m[b[key] || '미분류'] = (m[b[key] || '미분류'] || 0) + 1; return Object.entries(m).sort((a, b) => b[1] - a[1]); };
  const { cell, g } = bizGrid(list);
  let peak = null;
  for(const [k, n] of g) if(!peak || n > peak.n){ const [i, j] = k.split(',').map(Number); peak = { n, x:(i + 0.5) * cell, y:(j + 0.5) * cell }; }
  const near = list.filter(b => Math.hypot(b.m_[0], b.m_[1]) <= 400).length;
  const ground = list.filter(b => /^1$|^1층|지상1/.test(b.fl)).length, known = list.filter(b => b.fl).length;
  return { list, byL:count(list, 'l'), byM:count(list, 'm'), cell, peak, near, groundShare: known ? Math.round(ground / known * 100) : null };
}
function summarizeBiz(){
  if(!BIZ.items){ return; }
  if(!BIZ.items.length){ $('bizsum').textContent = `분석 범위 안에 상가가 없습니다 (${rangeLabel()})`; return; }
  const st = bizStats();
  const top = st.byL.slice(0, 3).map(([k, v]) => `${k} ${Math.round(v / st.list.length * 100)}%`).join(' · ');
  const pk = st.peak ? ` · 가장 밀집한 곳 ${dir8(Math.atan2(st.peak.x, st.peak.y) * 180 / Math.PI)}쪽 ${(Math.hypot(st.peak.x, st.peak.y) / 1000).toFixed(1)}km` : '';
  const extra = BIZ.form === 'mix' && BIZ.mix ? ` · 다양성 칸 ${BIZ.mix.cell}m` : BIZ.form === 'street' && BIZ.streetTop && BIZ.streetTop.length ? ` · 가게가 이어지는 길: ${BIZ.streetTop.slice(0, 3).map(r => `${r.name} ${r.per100m}곳/100m`).join(', ')}` : '';
  $('bizsum').textContent = `상가 ${st.list.length.toLocaleString()}곳 (${rangeLabel()}) · ${top}${pk}${extra}` + (BIZ.partial ? ' · 호출 한도로 일부만 받았습니다' : '') + ` · 호출 ${BIZ.calls}회`;
}
function commerceSummary(){
  if(!BIZ.on || !BIZ.items || !hasRef()) return null;
  const st = bizStats();
  return {
    source:'소상공인시장진흥공단 상가(상권)정보', analysis_range: rangeLabel(), category_filter: BIZ.cat || '전체',
    stores: st.list.length, partial: BIZ.partial,
    by_major_category: Object.fromEntries(st.byL.slice(0, 10)),
    top_mid_categories: Object.fromEntries(st.byM.slice(0, 12)),
    within_400m_of_center: st.near,
    densest_cell: st.peak ? { stores:st.peak.n, cell_m:st.cell, distance_m:Math.round(Math.hypot(st.peak.x, st.peak.y)), direction:dir8(Math.atan2(st.peak.x, st.peak.y) * 180 / Math.PI) } : null,
    ground_floor_share_pct: st.groundShare,
    diversity: BIZ.mix || null, active_streets: BIZ.streetTop || null,
    zones: BIZ.zones ? BIZ.zones.map(z => ({ name:z.name, kind:z.kind || null, stores:z.stores, distance_m:Math.round(Math.hypot(...centroidOf(z.m))), contains_site:pointInMulti([0, 0], z.m) })) : null,
    hubs: (BIZ.peaks || []).map(p => ({ stores:Math.round(p.mass), distance_m:Math.round(Math.hypot(p.x, p.y)), direction:dir8(Math.atan2(p.x, p.y) * 180 / Math.PI) })),
    note:'등록된 상가업소 위치 기준이며 매출·유동인구는 포함하지 않습니다. 층 정보가 비어 있는 업소가 많을 수 있습니다.'
  };
}


/* ============================================================
   상권 영역 — 같은 상가(상권)정보 API의 상권 경계 조회 (발달상권·골목상권·전통시장 등)
   ============================================================ */
/* WKT(POLYGON / MULTIPOLYGON) → 경위도 MultiPolygon */
function parseWKT(w){
  if(!w || typeof w !== 'string' || !/POLYGON/i.test(w)) return null;
  const nums = ring => ring.trim().split(/\s*,\s*/).map(p => p.trim().split(/\s+/).map(Number)).filter(p => p.length >= 2 && isFinite(p[0]) && isFinite(p[1]));
  const polys = [];
  const body = w.replace(/^\s*MULTIPOLYGON\s*/i, '').replace(/^\s*POLYGON\s*/i, '');
  const parts = /MULTIPOLYGON/i.test(w) ? body.split(/\)\s*\)\s*,\s*\(\s*\(/) : [body];
  for(let part of parts){
    part = part.replace(/^[\s(]+/, '').replace(/[\s)]+$/, '');
    const rings = part.split(/\)\s*,\s*\(/).map(nums).filter(r => r.length >= 4);
    if(rings.length) polys.push(rings);
  }
  if(!polys.length) return null;
  // 좌표가 경위도(127.x, 35.x)인지 확인 — 다른 좌표계면 버립니다
  const p0 = polys[0][0][0];
  if(!(p0[0] > 120 && p0[0] < 135 && p0[1] > 30 && p0[1] < 45)){
    if(p0[1] > 120 && p0[1] < 135) return polys.map(poly => poly.map(r => r.map(([a, b]) => [b, a])));   // 위도·경도 순서로 온 경우
    return null;
  }
  return polys;
}
const pick = (x, re) => { for(const k of Object.keys(x)) if(re.test(k)) return x[k]; return undefined; };
async function fetchZones(){
  const FR = focusR();
  let x0, y0, x1, y1;
  if(SITE.range === 'view' && SITE.viewLL){ [[x0, y0], [x1, y1]] = viewRectM(); } else { x0 = -FR; y0 = -FR; x1 = FR; y1 = FR; }
  const [w, s_] = toLL([x0, y0]), [e, n] = toLL([x1, y1]);
  const out = [];
  for(let page = 1; page <= 5; page++){
    $('bizsum').textContent = `상권 영역 받는 중 (${page}쪽)`;
    const r = await dataGo(SDSC + '/storeZoneInRectangle', { minx:w.toFixed(6), miny:s_.toFixed(6), maxx:e.toFixed(6), maxy:n.toFixed(6), type:'json', numOfRows:'500', pageNo:String(page) });
    if(!r.ok){ if(page === 1) throw new Error(r.msg); break; }
    for(const x of r.items){
      let geom = null;
      for(const v of Object.values(x)) if(typeof v === 'string' && /POLYGON/i.test(v)){ geom = parseWKT(v); if(geom) break; }
      if(!geom) continue;
      out.push({ name:pick(x, /mainTrarNm|trarNm|상권명/) || '상권', kind:pick(x, /trarSe|Se$|형태|구분|유형/) || '', stores:+(pick(x, /storeCo|점포|업소수/) || 0) || null,
                 area:+(pick(x, /trarArea|면적/) || 0) || null, geom, m:mapRings(geom, toM) });
    }
    if(r.items.length < 500) break;
  }
  BIZ.zones = out.filter(z => inter(z.m, focusGeomM()).length);
  return BIZ.zones;
}
const ZONE_KIND = k => /발달/.test(k) ? 0 : /골목/.test(k) ? 1 : /전통|시장/.test(k) ? 2 : /관광/.test(k) ? 3 : 4;
const ZONE_NAME = ['발달상권', '골목상권', '전통시장', '관광특구', '상권'];
function drawZones(){
  if(!BIZ.zones){ fetchZones().then(() => { registerBizLayers(); apply(); summarizeZones(); }).catch(e => { $('bizsum').textContent = '상권 영역 실패 — ' + e.message; }); return; }
  const st = ST(), cols = [st.biz, st.bizCats[0], st.bizCats[6], st.bizCats[3], st.focus], a = typeof CA === 'function' ? CA() : 0.7;
  const bins = [[], [], [], [], []];
  for(const z of BIZ.zones) bins[ZONE_KIND(String(z.kind))].push(z);
  bins.forEach((zs, k) => {
    if(!zs.length) return;
    const polys = zs.flatMap(z => z.geom);
    extraSet('biz-zone-' + k, { label:`분석_상권영역_${k + 1}_${ZONE_NAME[k]}`, stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:polys } }] },
      paint:{ 'fill-color':cols[k], 'fill-opacity':0.25 * a / 0.7 }, svg:{ kind:'fill', fill:cols[k], opacity:0.25 * a / 0.7 } });
    extraSet('biz-zone-line-' + k, { label:`분석_상권영역_${ZONE_NAME[k]}경계_세부`, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[ringFeature(polys, {})] }, paint:{ 'line-color':cols[k], 'line-width':1.2 }, svg:{ kind:'line', stroke:cols[k], width:1 } });
  });
  extraSet('biz-zone-label', { label:'분석_상권영역_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:BIZ.zones.map(z => ({ type:'Feature', properties:{ label:z.name + (z.stores ? ` · ${z.stores}곳` : '') }, geometry:{ type:'Point', coordinates:toLL(centroidOf(z.m)) } })) },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10.5, 'text-allow-overlap':false },
    paint:{ 'text-color':st.ink, 'text-halo-color':st.paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:st.ink, size:8.5 } });
}
function summarizeZones(){
  if(!BIZ.zones) return;
  if(!BIZ.zones.length){ $('bizsum').textContent = `범위 안에 등록된 상권 영역이 없습니다 (${rangeLabel()})`; return; }
  const inSite = BIZ.zones.find(z => pointInMulti([0, 0], z.m));
  const near = BIZ.zones.map(z => ({ z, d:Math.hypot(...centroidOf(z.m)) })).sort((a, b) => a.d - b.d)[0];
  const cnt = [0, 0, 0, 0, 0]; BIZ.zones.forEach(z => cnt[ZONE_KIND(String(z.kind))]++);
  $('bizsum').textContent = `상권 영역 ${BIZ.zones.length}곳 · ` + ZONE_NAME.map((n, k) => cnt[k] ? `${n} ${cnt[k]}` : '').filter(Boolean).join(' · ')
    + (inSite ? ` · ${SITE.geom ? '대지' : '중심'}가 "${inSite.name}" 안` : near ? ` · 가장 가까운 상권 "${near.z.name}" ${(near.d / 1000).toFixed(1)}km` : '');
}
