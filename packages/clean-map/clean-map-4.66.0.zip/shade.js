/* ============================================================
   지형 음영 — 표고 타일(AWS Terrain Tiles, Terrarium, 약 30m 격자)로 직접 그린 음영기복
   Esri 음영기복은 국내에서 고해상도 표고로 만들어져 도로 성토·절토, 매립지 경계가 선처럼 박혀 있습니다.
   여기서는 30m 표고를 조금 흐려서 그리므로 도로·논두렁 자국이 없고, 평지의 잔물결(도시 건물·레이더 잡티)은
   경사가 아주 낮은 곳의 음영을 빼서 지웁니다. 산의 능선·골짜기만 남습니다.

   maplibregl 사용자 프로토콜로 래스터 타일을 만들어 줍니다:
     hyshade://{z}/{x}/{y}?s=<그림자 색 hex>&h=<밝은 쪽 색 hex>&ha=<밝은 쪽 진하기 0~1>
   지도 캔버스와 같은 곳에서 만든 이미지라 PNG·SVG 내보내기에 그대로 담깁니다.
   타일은 ImageBitmap으로 바로 넘깁니다 (PNG로 다시 묶는 단계 없이).
   ============================================================ */
const SHADE = (() => {
  const DEM = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png';
  const DZ = 12;          // 표고 원자료(약 30m)에 맞는 줌 — 더 확대하면 부드럽게 늘려서 씁니다
  const T = 256;          // 타일 크기
  const M = 3;            // 목표 타일 가장자리 여유 (기울기 계산용)
  const SIG = 0.9;        // 표고 흐림 (표고 픽셀) — 레이더 잡티·도시 건물 요철을 누릅니다
  const EX = 1.2;         // 기울기 과장
  const FLAT0 = 4, FLAT1 = 10;   // 이 경사(도)보다 낮으면 음영을 빼고, 사이는 서서히 — 평지는 깨끗하게
  const SA = 0.72;        // 그림자 최대 진하기
  const AZ = 315 * Math.PI / 180, ALT = 45 * Math.PI / 180;
  const L = [Math.cos(ALT) * Math.sin(AZ), Math.cos(ALT) * Math.cos(AZ), Math.sin(ALT)];   // 북서쪽 위에서 비추는 빛
  const H0 = L[2];        // 평지의 밝기

  /* 표고 타일 → Float32Array(256×256, m). 바다(음수)는 0으로 눌러 바닥 음영을 그리지 않습니다 */
  const cache = new Map(), MAXC = 192;
  function demTile(z, x, y){
    const n = 2 ** z;
    if(y < 0 || y >= n) return Promise.resolve(null);
    x = ((x % n) + n) % n;
    const k = z + '/' + x + '/' + y;
    let p = cache.get(k);
    if(p){ cache.delete(k); cache.set(k, p); return p; }
    p = fetch(DEM.replace('{z}', z).replace('{x}', x).replace('{y}', y))
      .then(r => { if(!r.ok) throw new Error('표고 타일 ' + r.status); return r.blob(); })
      .then(b => createImageBitmap(b, { colorSpaceConversion:'none', premultiplyAlpha:'none' }))
      .then(bmp => {
        const c = new OffscreenCanvas(T, T), g = c.getContext('2d', { willReadFrequently:true });
        g.drawImage(bmp, 0, 0);
        const d = g.getImageData(0, 0, T, T).data, e = new Float32Array(T * T);
        for(let i = 0; i < T * T; i++){
          const v = d[i * 4] * 256 + d[i * 4 + 1] + d[i * 4 + 2] / 256 - 32768;
          e[i] = v > 0 ? v : 0;
        }
        return e;
      });
    p.catch(() => cache.delete(k));   // 실패한 타일은 다음에 다시 받습니다
    cache.set(k, p);
    if(cache.size > MAXC) cache.delete(cache.keys().next().value);
    return p;
  }

  /* 표고 줌 dz 의 전역 픽셀 [gx0, gx0+w) × [gy0, gy0+h) */
  async function windowAt(dz, gx0, gy0, w, h){
    const tx0 = Math.floor(gx0 / T), ty0 = Math.floor(gy0 / T);
    const tx1 = Math.floor((gx0 + w - 1) / T), ty1 = Math.floor((gy0 + h - 1) / T);
    const jobs = [];
    for(let ty = ty0; ty <= ty1; ty++) for(let tx = tx0; tx <= tx1; tx++)
      jobs.push(demTile(dz, tx, ty).then(e => ({ tx, ty, e })));
    const out = new Float32Array(w * h);
    for(const { tx, ty, e } of await Promise.all(jobs)){
      if(!e) continue;
      const x0 = Math.max(gx0, tx * T), x1 = Math.min(gx0 + w, tx * T + T);
      const y0 = Math.max(gy0, ty * T), y1 = Math.min(gy0 + h, ty * T + T);
      for(let gy = y0; gy < y1; gy++){
        const ro = (gy - gy0) * w - gx0, ri = (gy - ty * T) * T - tx * T;
        for(let gx = x0; gx < x1; gx++) out[ro + gx] = e[ri + gx];
      }
    }
    return out;
  }

  function blur(a, w, h, s){
    const r = Math.ceil(s * 2.5), k = new Float32Array(2 * r + 1);
    let sum = 0;
    for(let i = -r; i <= r; i++){ k[i + r] = Math.exp(-i * i / (2 * s * s)); sum += k[i + r]; }
    for(let i = 0; i < k.length; i++) k[i] /= sum;
    const t = new Float32Array(w * h), o = new Float32Array(w * h);
    for(let y = 0; y < h; y++){
      const ro = y * w;
      for(let x = 0; x < w; x++){
        let v = 0;
        for(let i = -r; i <= r; i++){ const xx = x + i < 0 ? 0 : x + i >= w ? w - 1 : x + i; v += k[i + r] * a[ro + xx]; }
        t[ro + x] = v;
      }
    }
    for(let y = 0; y < h; y++) for(let x = 0; x < w; x++){
      let v = 0;
      for(let i = -r; i <= r; i++){ const yy = y + i < 0 ? 0 : y + i >= h ? h - 1 : y + i; v += k[i + r] * t[yy * w + x]; }
      o[y * w + x] = v;
    }
    return o;
  }

  /* Catmull-Rom 가중치 — 확대할 때 면이 각지지 않게 */
  function cr(t){
    const t2 = t * t, t3 = t2 * t;
    return [(-t3 + 2 * t2 - t) / 2, (3 * t3 - 5 * t2 + 2) / 2, (-3 * t3 + 4 * t2 + t) / 2, (t3 - t2) / 2];
  }

  const hex = (h, d) => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); const v = parseInt(m ? m[1] : d, 16); return [v >> 16 & 255, v >> 8 & 255, v & 255]; };
  const smooth = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

  async function render(z, x, y, sh, hi, ha){
    const dz = Math.min(z, DZ), s = 2 ** (z - dz), W = T + 2 * M;
    const B = Math.ceil(SIG * 2.5) + 2;
    const gx0 = Math.floor((x * T - M) / s) - B, gy0 = Math.floor((y * T - M) / s) - B;
    const w = Math.ceil(((x + 1) * T + M) / s) + B - gx0, h = Math.ceil(((y + 1) * T + M) / s) + B - gy0;
    const e = blur(await windowAt(dz, gx0, gy0, w, h), w, h, SIG);

    // 목표 격자 (여유 M 포함) 로 늘리기
    const E = new Float32Array(W * W);
    if(s === 1){
      const ox = x * T - M - gx0, oy = y * T - M - gy0;
      for(let j = 0; j < W; j++) for(let i = 0; i < W; i++) E[j * W + i] = e[(j + oy) * w + i + ox];
    }else{
      const fxs = new Float32Array(W * 4), ixs = new Int32Array(W);
      for(let i = 0; i < W; i++){
        const f = (x * T - M + i + 0.5) / s - 0.5 - gx0, fi = Math.floor(f);
        ixs[i] = fi - 1; fxs.set(cr(f - fi), i * 4);
      }
      for(let j = 0; j < W; j++){
        const f = (y * T - M + j + 0.5) / s - 0.5 - gy0, fj = Math.floor(f), wy = cr(f - fj);
        for(let i = 0; i < W; i++){
          const ix = ixs[i], o = i * 4;
          let v = 0;
          for(let b = 0; b < 4; b++){
            const r = (fj - 1 + b) * w + ix;
            v += wy[b] * (fxs[o] * e[r] + fxs[o + 1] * e[r + 1] + fxs[o + 2] * e[r + 2] + fxs[o + 3] * e[r + 3]);
          }
          E[j * W + i] = v;
        }
      }
    }

    // 음영
    const n = 2 ** z, lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + 0.5) / n)));
    const res = 40075016.686 * Math.cos(lat) / (T * n);
    const [sr, sg, sb] = hex(sh, '3c3a36'), [hr, hg, hb] = hex(hi, 'ffffff');
    const img = new ImageData(T, T), d = img.data;
    for(let j = 0; j < T; j++){
      for(let i = 0; i < T; i++){
        const k = (j + M) * W + i + M;
        const dx = ((E[k - W + 1] + 2 * E[k + 1] + E[k + W + 1]) - (E[k - W - 1] + 2 * E[k - 1] + E[k + W - 1])) / (8 * res) * EX;
        const dy = ((E[k + W - 1] + 2 * E[k + W] + E[k + W + 1]) - (E[k - W - 1] + 2 * E[k - W] + E[k - W + 1])) / (8 * res) * EX;
        const g = Math.hypot(dx, dy), nl = Math.sqrt(1 + g * g);
        const lit = (-dx * L[0] + dy * L[1] + L[2]) / nl;          // 법선(-∂z/∂동, -∂z/∂북, 1)·빛
        const wgt = smooth(FLAT0, FLAT1, Math.atan(g / EX) * 180 / Math.PI);
        const p = (j * T + i) * 4;
        if(lit < H0){
          d[p] = sr; d[p + 1] = sg; d[p + 2] = sb;
          d[p + 3] = Math.round(255 * Math.min(1, (H0 - lit) / H0 * 1.6) * SA * wgt);
        }else{
          d[p] = hr; d[p + 1] = hg; d[p + 2] = hb;
          d[p + 3] = Math.round(255 * Math.min(1, (lit - H0) / (1 - H0) * 1.4) * ha * wgt);
        }
      }
    }
    return await createImageBitmap(img);
  }

  if(typeof maplibregl !== 'undefined' && maplibregl.addProtocol){
    maplibregl.addProtocol('hyshade', async params => {
      const m = /^hyshade:\/\/(\d+)\/(\d+)\/(\d+)(?:\?(.*))?$/.exec(params.url);
      if(!m) throw new Error('잘못된 음영 타일 주소');
      const q = new URLSearchParams(m[4] || '');
      return { data: await render(+m[1], +m[2], +m[3], q.get('s'), q.get('h'), +(q.get('ha') || 0.5)) };
    });
  }

  /* 스타일 바탕색에 맞춘 타일 주소 — 밝은 바탕은 글자색 계열 그림자, 어두운 바탕은 검정 그림자 + 옅은 빛 */
  function url(c){
    const bg = hex(c && c.bg, 'f5f5f2'), dark = (bg[0] + bg[1] + bg[2]) / 3 < 110;
    // 밝은 바탕: 글자색을 바탕 쪽으로 30% 섞은 그림자 (스타일 색조를 따라가되 너무 검지 않게)
    const lab = hex(c && c.label, '3c3a36');
    const ink = dark ? '000000' : lab.map((v, i) => Math.round(v * 0.7 + bg[i] * 0.3).toString(16).padStart(2, '0')).join('');
    return `hyshade://{z}/{x}/{y}?s=${ink}&h=ffffff&ha=${dark ? 0.16 : 0.6}`;
  }
  return { url, render, demTile };
})();
