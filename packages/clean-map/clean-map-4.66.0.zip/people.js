/* ============================================================
   SGIS (통계청 통계지리정보) — 인구·가구·사업체
   서비스 ID + 보안 키로 임시 토큰을 받아 호출합니다.
   ============================================================ */

/* 배포본에 넣을 기본 키 — 비워 두면 연결 설정 칸의 값을 씁니다 */
const SGIS_DEFAULT_ID = '29c2c1076654481abbbd';
const SGIS_DEFAULT_SECRET = 'e06ed205ae6f4151a5cb';
const SGIS_HOSTS = ['https://sgisapi.mods.go.kr', 'https://sgisapi.kostat.go.kr'];   // 국가데이터처 이관 후 새 주소 먼저
const SGIS = { token:null, until:0, host:null };

function sgisKeys(){
  let id = '', sec = '';
  try{ id = localStorage.getItem('cleanmapSgisId') || ''; sec = localStorage.getItem('cleanmapSgisSecret') || ''; }catch(e){}
  return { id: id || SGIS_DEFAULT_ID, secret: sec || SGIS_DEFAULT_SECRET };
}

async function sgisFetch(path, params){
  const qs = new URLSearchParams(params).toString();
  let lastErr;
  for(const host of (SGIS.host ? [SGIS.host] : SGIS_HOSTS)){
    try{
      const res = await fetch(host + path + '?' + qs);
      const text = await res.text();
      let js; try{ js = JSON.parse(text); }catch(e){ lastErr = new Error('응답을 읽지 못했습니다'); continue; }
      SGIS.host = host;
      return { js, raw: text.length > 520 ? text.slice(0, 260) + '  …  ' + text.slice(-240) : text };
    }catch(e){ lastErr = e; }
  }
  throw new Error('SGIS 서버에 연결하지 못했습니다 — ' + (lastErr && lastErr.message));
}

async function sgisToken(force){
  if(!force && SGIS.token && Date.now() < SGIS.until - 60e3) return SGIS.token;
  const k = sgisKeys();
  if(!k.id || !k.secret) throw new Error('SGIS 서비스 ID와 보안 키를 연결 설정 칸에 넣어 주세요');
  const { js, raw } = await sgisFetch('/OpenAPI3/auth/authentication.json', { consumer_key:k.id, consumer_secret:k.secret });
  if(String(js.errCd) !== '0' || !js.result || !js.result.accessToken){
    const e = new Error(sgisErr(js)); e.raw = raw; throw e;
  }
  SGIS.token = js.result.accessToken;
  SGIS.until = +js.result.accessTimeout || (Date.now() + 3.5 * 3600e3);
  return SGIS.token;
}
const sgisErr = js => {
  const cd = String(js && js.errCd), m = (js && js.errMsg) || '';
  if(cd === '-401' || /인증|auth|key/i.test(m)) return '서비스 ID 또는 보안 키가 맞지 않습니다 (' + m + ')';
  return (m || '알 수 없는 오류') + (cd && cd !== 'undefined' ? ' (' + cd + ')' : '');
};

/* 토큰이 만료되면 한 번 다시 받아 재시도합니다 */
async function sgisCall(path, params){
  let tok = await sgisToken();
  let r = await sgisFetch(path, { accessToken:tok, ...params });
  if(String(r.js.errCd) === '-401'){ tok = await sgisToken(true); r = await sgisFetch(path, { accessToken:tok, ...params }); }
  const ok = String(r.js.errCd) === '0';
  return { ok, result:r.js.result, msg: ok ? '정상' : sgisErr(r.js), raw:r.raw };
}

/* ---------- UTM-K (EPSG:5179) ↔ 경위도 — SGIS 경계는 UTM-K 로 옵니다 ---------- */
const UTMK = (() => {
  const a = 6378137, f = 1 / 298.257222101, e2 = f * (2 - f), ep2 = e2 / (1 - e2), k0 = 0.9996;
  const lat0 = 38 * Math.PI / 180, lon0 = 127.5 * Math.PI / 180, FE = 1000000, FN = 2000000;
  const e4 = e2 * e2, e6 = e4 * e2;
  const M = p => a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * p - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * p)
    + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * p) - (35 * e6 / 3072) * Math.sin(6 * p));
  const M0 = M(lat0);
  function fwd([lng, lat]){
    const p = lat * Math.PI / 180, l = lng * Math.PI / 180;
    const N = a / Math.sqrt(1 - e2 * Math.sin(p) ** 2), T = Math.tan(p) ** 2, C = ep2 * Math.cos(p) ** 2, A = (l - lon0) * Math.cos(p);
    const x = FE + k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120);
    const y = FN + k0 * (M(p) - M0 + N * Math.tan(p) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720));
    return [x, y];
  }
  function inv([x, y]){
    const m = M0 + (y - FN) / k0, mu = m / (a * (1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256));
    const e1 = (1 - Math.sqrt(1 - e2)) / (1 + Math.sqrt(1 - e2));
    const p1 = mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * Math.sin(2 * mu) + (21 * e1 * e1 / 16 - 55 * e1 ** 4 / 32) * Math.sin(4 * mu)
      + (151 * e1 ** 3 / 96) * Math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * Math.sin(8 * mu);
    const C1 = ep2 * Math.cos(p1) ** 2, T1 = Math.tan(p1) ** 2, s1 = Math.sin(p1);
    const N1 = a / Math.sqrt(1 - e2 * s1 * s1), R1 = a * (1 - e2) / Math.pow(1 - e2 * s1 * s1, 1.5), D = (x - FE) / (N1 * k0);
    const lat = p1 - (N1 * Math.tan(p1) / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * D ** 4 / 24
      + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * D ** 6 / 720);
    const lon = lon0 + (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * D ** 5 / 120) / Math.cos(p1);
    return [lon * 180 / Math.PI, lat * 180 / Math.PI];
  }
  return { fwd, inv };
})();

/* ============================================================
   인구·사업체 카드 — 읍면동 단위 총조사 주요지표 + 경계
   ============================================================ */
const POP = { on:false, busy:false, dongs:null, form:'pop', view:'kde', year:null };
const POP_FORMS = {
  pop:   { label:'인구 밀도',   unit:'명/km²', val:d => d.pop != null && d.km2 ? d.pop / d.km2 : null, fmt:v => Math.round(v).toLocaleString() },
  work:  { label:'종사자 밀도', unit:'명/km²', val:d => d.worker != null && d.km2 ? d.worker / d.km2 : null, fmt:v => Math.round(v).toLocaleString() },
  age:   { label:'평균 연령',   unit:'세',     val:d => d.age, fmt:v => v.toFixed(1) },
  day:   { label:'주간/야간 성격', unit:'종사자÷인구', val:d => d.pop ? (d.worker || 0) / d.pop : null, fmt:v => v.toFixed(2) }
};
const popRamp = form => rampFrom(ST()[form] || ST().pop, 5);

$('popon').addEventListener('change', e => {
  POP.on = e.target.checked; $('popopts').hidden = !POP.on; $('card-pop').classList.toggle('on', POP.on);
  if(POP.on && hasRef() && !POP.dongs) runPop(); else { registerPopLayers(); apply(); }
});
$('popform').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; POP.form = b.dataset.v; segSync('popform', POP.form);
$('popview').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; POP.view = b.dataset.v; segSync('popview', POP.view); registerPopLayers(); apply(); });
segSync('popview', POP.view); registerPopLayers(); apply(); summarizePop(); });
$('poprun').addEventListener('click', () => { POP.dongs = null; runPop(); });
segSync('popform', POP.form);
$('popview').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; POP.view = b.dataset.v; segSync('popview', POP.view); registerPopLayers(); apply(); });
segSync('popview', POP.view);
function popOnSiteChange(){ POP.dongs = null; extraRemove('pop-'); if(POP.on && hasRef() && SITE.mode === 'site') runPop(); }

const num = v => { const n = parseFloat(String(v ?? '').replace(/,/g, '')); return isFinite(n) ? n : null; };
async function sgisSggCodes(){
  // 범위 안 3×3 지점의 시군구 코드를 모읍니다
  const pts = [];
  if(SITE.range === 'view' && SITE.viewLL){ const [w, s_, e, n] = SITE.viewLL; for(const fy of [0.15, 0.5, 0.85]) for(const fx of [0.15, 0.5, 0.85]) pts.push([w + (e - w) * fx, s_ + (n - s_) * fy]); }
  else { const R = focusR() * 0.8; for(const [x, y] of [[0, 0], [R, 0], [-R, 0], [0, R], [0, -R]]) pts.push(toLL([x, y])); }
  const codes = new Map();
  for(const [lng, lat] of pts){
    const g = await sgisCall('/OpenAPI3/addr/rgeocodewgs84.json', { x_coor:lng.toFixed(6), y_coor:lat.toFixed(6), addr_type:'20' });
    const a = g.ok && Array.isArray(g.result) ? g.result[0] : null;
    if(a && a.sido_cd && a.sgg_cd) codes.set(String(a.sido_cd) + String(a.sgg_cd), (a.sido_nm || '') + ' ' + (a.sgg_nm || ''));
    if(codes.size >= 6) break;
  }
  return codes;
}
async function runPop(){
  if(!hasRef()){ $('popsum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(POP.busy) return;
  POP.busy = true; $('poprun').disabled = true;
  try{
    $('popsum').textContent = 'SGIS 연결 중'; await sgisToken();
    $('popsum').textContent = '범위의 시군구 찾는 중';
    const sgg = await sgisSggCodes();
    if(!sgg.size) throw new Error('범위의 행정구역을 찾지 못했습니다');
    const dongs = new Map();
    let year = new Date().getFullYear() - 3, used = null;
    for(const [cd, nm] of sgg){
      $('popsum').textContent = `${nm.trim()} 읍면동 경계 받는 중`;
      // 경계 — 연도가 아직 없으면 한 해씩 내려갑니다
      let bd = null;
      for(let y = used || year; y >= year - 3; y--){
        const r = await sgisFetch('/OpenAPI3/boundary/hadmarea.geojson', { accessToken:await sgisToken(), year:String(y), adm_cd:cd, low_search:'1' });
        const feats = (r.js && (r.js.features || (r.js.result && r.js.result.features))) || [];
        if(feats.length){ bd = feats; used = y; break; }
      }
      if(!bd) continue;
      for(const f of bd){
        const pr = f.properties || {};
        const polys = f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.type === 'MultiPolygon' ? f.geometry.coordinates : [];
        const ll = polys.map(poly => poly.map(ring => ring.map(p => UTMK.inv(p))));
        const mp = mapRings(ll, toM);
        const clip = inter(mp, focusGeomM());
        if(!clip.length) continue;
        dongs.set(String(pr.adm_cd), { cd:String(pr.adm_cd), name:pr.adm_nm || '', ll, m:mp, clip, km2:multiArea(mp) / 1e6, inKm2:multiArea(clip) / 1e6 });
      }
      $('popsum').textContent = `${nm.trim()} 인구·사업체 통계 받는 중`;
      const st = await sgisCall('/OpenAPI3/stats/population.json', { year:String(used), adm_cd:cd, low_search:'1' });
      if(st.ok && Array.isArray(st.result)) for(const x of st.result){
        const d = dongs.get(String(x.adm_cd)); if(!d) continue;
        d.pop = num(x.tot_ppltn ?? x.population); d.age = num(x.avg_age); d.family = num(x.tot_family); d.house = num(x.tot_house);
        d.worker = num(x.employee_cnt ?? x.tot_worker); d.corp = num(x.corp_cnt);
      }else if(!st.ok) POP.statErr = st.msg;
      // 총조사 주요지표에 사업체가 없으면 사업체 통계로 채웁니다
      if([...dongs.values()].some(d => d.corp == null)){
        const cp = await sgisCall('/OpenAPI3/stats/company.json', { year:String(used), adm_cd:cd, low_search:'1' });
        if(cp.ok && Array.isArray(cp.result)) for(const x of cp.result){
          const d = dongs.get(String(x.adm_cd)); if(!d) continue;
          if(d.corp == null) d.corp = num(x.corp_cnt); if(d.worker == null) d.worker = num(x.tot_worker);
        }
      }
    }
    POP.dongs = [...dongs.values()]; POP.year = used;
    registerPopLayers(); apply(); summarizePop();
  }catch(err){ $('popsum').textContent = '실패 — ' + err.message; }
  POP.busy = false; $('poprun').disabled = false;
}
function popClasses(){
  const F = POP_FORMS[POP.form];
  const vals = POP.dongs.map(F.val).filter(v => v != null && isFinite(v)).sort((a, b) => a - b);
  const q = f => vals.length ? vals[Math.min(vals.length - 1, Math.floor(f * vals.length))] : 0;
  return { F, cuts:[q(0.2), q(0.4), q(0.6), q(0.8)] };
}
/* 동 인구를 동 안 건물(층수×면적)에 나눠 점으로 — 건물이 없으면 동 안에 고르게 */
function popPoints(field){
  const fc = VW.data && VW.data.building_kr, pts = [];
  const blds = []; let useN = 0;
  if(fc) for(const f of fc.features){
    const fl = floorsOf(f.properties) || 1, mp = asMulti(f.geometry); if(!mp.length) continue;
    const m = mapRings([[mp[0][0]]], toM); const c = centroidOf(m), a = Math.abs(ringArea(m[0][0]));
    if(a < 15) continue;
    // 용도를 알면 — 거주 인구는 주택 쪽으로, 종사자는 주택이 아닌 쪽으로 무게를 줍니다 (모르면 지금처럼 면적 × 층수만)
    const u = typeof useOf === 'function' ? useOf(f.properties) : '정보 없음';
    let k = 1;
    if(u !== '정보 없음'){
      useN++;
      k = field === 'pop' ? (u === '단독주택' || u === '공동주택' ? 1 : u === '근린생활' ? 0.35 : 0.03)
                          : (u === '단독주택' || u === '공동주택' ? 0.05 : u === '기타' ? 0.5 : 1);
    }
    blds.push({ c, w:a * fl * k });
  }
  POP.dasy = { bld:0, uniform:0, useN };
  for(const d of POP.dongs){
    const v = d[field]; if(!v) continue;
    const inside = blds.filter(b => pointInMulti(b.c, d.m));
    const tw = inside.reduce((s, b) => s + b.w, 0);
    if(inside.length >= 5 && tw > 0){ for(const b of inside) pts.push([b.c[0], b.c[1], v * b.w / tw]); POP.dasy.bld++; continue; }
    // 건물 정보가 없는 동 — 동 안에 고르게
    const step = Math.max(40, Math.sqrt(d.km2 * 1e6) / 25), cells = [];
    let bb = [1e9, 1e9, -1e9, -1e9]; for(const poly of d.m) for(const [x, y] of poly[0]) bb = [Math.min(bb[0], x), Math.min(bb[1], y), Math.max(bb[2], x), Math.max(bb[3], y)];
    for(let y = bb[1] + step / 2; y < bb[3]; y += step) for(let x = bb[0] + step / 2; x < bb[2]; x += step) if(pointInMulti([x, y], d.m)) cells.push([x, y]);
    for(const [x, y] of cells) pts.push([x, y, v / cells.length]);
    POP.dasy.uniform++;
  }
  return pts;
}
function registerPopLayers(){
  extraRemove('pop-');
  if(!POP.on || !POP.dongs || !POP.dongs.length || !hasRef()) return;
  if(POP.view === 'dots' && (POP.form === 'pop' || POP.form === 'work')){ drawPopDots(POP.form === 'pop' ? 'pop' : 'worker'); return; }
  if(POP.view === 'circles' && (POP.form === 'pop' || POP.form === 'work')){
    const field = POP.form === 'pop' ? 'pop' : 'worker';
    const res = kdePeaks(popPoints(field));
    registerCircles('pop-cir-', POP.form === 'pop' ? '인구거점' : '종사자거점', res, POP.form === 'pop' ? ST().pop : ST().work,
      p => `약 ${(Math.round(p.mass / 100) * 100).toLocaleString()}명`);
    POP.peaks = res.peaks; return;
  }
  if(POP.view === 'kde' && (POP.form === 'pop' || POP.form === 'work')){
    const field = POP.form === 'pop' ? 'pop' : 'worker';
    const pts = popPoints(field);
    // 건물 정보 없이 동 안에 고르게 나눈 동이 많으면, 동 경계가 각지게 드러나지 않도록 더 넓게 퍼뜨립니다
    let opt = {};
    if(POP.dasy && POP.dasy.uniform > POP.dasy.bld){
      const meanKm2 = POP.dongs.reduce((a, d) => a + d.km2, 0) / POP.dongs.length;
      opt.h = Math.max(focusR() / 8, Math.min(900, Math.sqrt(meanKm2) * 1000 / 2.2));
    }
    const res = kdeBands(pts, opt);
    registerBands('pop-kde-', POP.form === 'pop' ? '인구분포' : '종사자분포', res, POP.form === 'pop' ? ST().pop : ST().work);
    extraSet('pop-line', { label:'분석_행정동경계', stage:'fill', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:POP.dongs.map(d => ringFeature(mapRings(d.clip, toLL), {})) },
      paint:{ 'line-color':ST().dongLine, 'line-width':0.6, 'line-dasharray':[2, 2] }, svg:{ kind:'line', stroke:ST().dongLine, width:0.5, dash:[2, 2] } });
    return;
  }
  const { F, cuts } = popClasses(), ramp = popRamp(POP.form);
  const bins = [[], [], [], [], []], labels = [];
  for(const d of POP.dongs){
    const v = F.val(d); if(v == null || !isFinite(v)) continue;
    const k = v >= cuts[3] ? 4 : v >= cuts[2] ? 3 : v >= cuts[1] ? 2 : v >= cuts[0] ? 1 : 0;
    bins[k].push(...mapRings(d.clip, toLL));
    const c = centroidOf(d.clip);
    labels.push({ type:'Feature', properties:{ label:`${d.name} ${F.fmt(v)}` }, geometry:{ type:'Point', coordinates:toLL(c) } });
  }
  bins.forEach((polys, k) => {
    if(!polys.length) return;
    const lo = k ? F.fmt(cuts[k - 1]) : '', hi = k < 4 ? F.fmt(cuts[k]) : '';
    extraSet('pop-' + k, { label:`분석_${F.label.replace(/\s|\//g, '')}_${k + 1}_${lo && hi ? lo + '–' + hi : lo ? lo + ' 이상' : hi + ' 미만'} ${F.unit}`, stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{ k }, geometry:{ type:'MultiPolygon', coordinates:polys } }] },
      paint:{ 'fill-color':ramp[k], 'fill-opacity':0.85, 'fill-outline-color':ST().paper }, svg:{ kind:'fill', fill:ramp[k], opacity:0.85 } });
  });
  extraSet('pop-line', { label:'분석_행정동경계', stage:'fill', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:POP.dongs.map(d => ringFeature(mapRings(d.clip, toLL), {})) },
    paint:{ 'line-color':ST().paper, 'line-width':1.2 }, svg:{ kind:'line', stroke:ST().paper, width:1 } });
  extraSet('pop-label', { label:'분석_행정동_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:labels },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10.5, 'text-allow-overlap':false },
    paint:{ 'text-color':ST().ink, 'text-halo-color':ST().paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:ST().ink, size:8.5 } });
}
function popTotals(){
  // 범위 안 추정치 = 동 값 × (범위 안 면적 ÷ 동 면적)
  let pop = 0, worker = 0, corp = 0, has = false;
  for(const d of POP.dongs){ const r = d.km2 ? d.inKm2 / d.km2 : 0; if(d.pop != null){ pop += d.pop * r; has = true; } if(d.worker != null) worker += d.worker * r; if(d.corp != null) corp += d.corp * r; }
  return has ? { pop:Math.round(pop), worker:Math.round(worker), corp:Math.round(corp) } : null;
}
function summarizePop(){
  if(!POP.dongs) return;
  if(!POP.dongs.length){ $('popsum').textContent = '범위 안 읍면동 경계를 받지 못했습니다'; return; }
  const t = popTotals(), { F } = popClasses();
  const site = POP.dongs.find(d => pointInMulti([0, 0], d.m));
  $('popsum').textContent = `${POP.year}년 · 읍면동 ${POP.dongs.length}곳` + (POP.dasy && POP.view !== 'dong' ? ` (건물로 나눔 ${POP.dasy.bld}곳 · 고르게 ${POP.dasy.uniform}곳${POP.dasy.useN ? ' · 건물 용도 반영' : ''})` : '') + (POP.view === 'dots' && POP.dotPer ? ` · 점 ${POP.dotCount.toLocaleString()}개, 1점 = ${POP.dotPer}명` : '') + (t ? ` · 범위 안 인구 약 ${t.pop.toLocaleString()}명 · 종사자 약 ${t.worker.toLocaleString()}명` : ' · 통계값 없음' + (POP.statErr ? ' (' + POP.statErr + ')' : ''))
    + (site && F.val(site) != null ? ` · 대지 쪽 ${site.name} ${F.label} ${F.fmt(F.val(site))} ${F.unit}` : '');
}
function peopleSummary(){
  if(!POP.on || !POP.dongs || !hasRef()) return null;
  const t = popTotals();
  const site = POP.dongs.find(d => pointInMulti([0, 0], d.m));
  const row = d => ({ name:d.name, population:d.pop, workers:d.worker, businesses:d.corp, avg_age:d.age, households:d.family,
    pop_density_km2: d.pop != null && d.km2 ? Math.round(d.pop / d.km2) : null, worker_to_resident: d.pop ? +((d.worker || 0) / d.pop).toFixed(2) : null,
    share_in_range_pct: d.km2 ? Math.round(d.inKm2 / d.km2 * 100) : null });
  return { source:'통계청 SGIS 총조사 주요지표 (읍면동)', year:POP.year, analysis_range:rangeLabel(),
    estimated_in_range: t, site_dong: site ? row(site) : null,
    hubs: (POP.peaks || []).map(p => ({ amount:Math.round(p.mass), distance_m:Math.round(Math.hypot(p.x, p.y)), direction:dir8(Math.atan2(p.x, p.y) * 180 / Math.PI), estimated:true })),
    dongs: POP.dongs.slice().sort((a, b) => b.inKm2 - a.inKm2).slice(0, 15).map(row),
    distribution_method: POP.view === 'kde' ? '읍면동 인구를 동 안 건물 연면적 비례로 배분한 뒤 커널 밀도로 표현 (건물 정보가 없는 동은 균등 배분)' : '읍면동 단위 단계 구분',
    note:'범위 안 추정치는 읍면동 값을 범위에 걸친 면적 비율로 나눈 값입니다. 총조사 기준 거주 인구이며 유동인구가 아닙니다. 분포 등고는 추정 배분입니다.' };
}

/* ---------- 연결 시험 (transit.js 의 연결 시험 버튼이 부릅니다) ---------- */
async function sgisProbe(c, rows, show){
  rows.push(['SGIS 인증', null, '시험 중…']); show();
  let i = rows.length - 1;
  try{
    await sgisToken(true);
    rows[i] = ['SGIS 인증', true, `정상 · 토큰 발급 (${SGIS.host.replace('https://', '')})`, '']; show();
  }catch(e){
    rows[i] = ['SGIS 인증', false, e.message, e.raw || '']; show(); return;
  }
  // 좌표 → 행정구역 코드
  rows.push(['SGIS 좌표→행정동', null, '시험 중…']); show(); i = rows.length - 1;
  const g = await sgisCall('/OpenAPI3/addr/rgeocodewgs84.json', { x_coor:c[0].toFixed(6), y_coor:c[1].toFixed(6), addr_type:'20' });
  const a = g.ok && Array.isArray(g.result) ? g.result[0] : null;
  const adm = a && (a.adm_dr_cd || a.emdong_cd || a.adm_cd);
  const admFull = a && ((a.sido_cd || '') + (a.sgg_cd || '') + (a.emdong_cd || '')) || adm;
  rows[i] = ['SGIS 좌표→행정동', g.ok, g.ok ? `정상 · ${[a && a.sido_nm, a && a.sgg_nm, a && (a.emdong_nm || a.adm_dr_nm)].filter(Boolean).join(' ') || '결과 확인'}` : g.msg, g.ok && a ? '' : g.raw]; show();
  if(!admFull) return;
  // 인구 통계
  rows.push(['SGIS 읍면동 주요지표', null, '시험 중…']); show(); i = rows.length - 1;
  const sggCd = a && a.sido_cd && a.sgg_cd ? String(a.sido_cd) + String(a.sgg_cd) : admFull.slice(0, 5);
  const yr = String(new Date().getFullYear() - 3);
  const p = await sgisCall('/OpenAPI3/stats/population.json', { year:yr, adm_cd:sggCd, low_search:'1' });
  const pr = p.ok && Array.isArray(p.result) ? p.result : null;
  rows[i] = ['SGIS 읍면동 주요지표', p.ok, p.ok && pr ? `정상 · ${yr}년 읍면동 ${pr.length}곳` : (p.ok ? '정상 · 응답 확인 필요' : p.msg), (p.raw || '').slice(0, 500)]; show();
  rows.push(['SGIS 읍면동 경계', null, '시험 중…']); show(); i = rows.length - 1;
  const b = await sgisFetch('/OpenAPI3/boundary/hadmarea.geojson', { accessToken:await sgisToken(), year:yr, adm_cd:sggCd, low_search:'1' });
  const fs = (b.js && (b.js.features || (b.js.result && b.js.result.features))) || [];
  const g0 = fs[0] && fs[0].geometry, p0 = g0 && (g0.type === 'Polygon' ? g0.coordinates[0][0] : g0.coordinates[0][0][0]);
  // 통계주제도 — 주거와 교통 (읍면동 단위 교통 관련 지표가 있는지)
  const tm = await sgisCall('/OpenAPI3/themamap/CTGR_002/list.json', {});
  const tl = tm.ok && Array.isArray(tm.result) ? tm.result : [];
  SGIS.themes = tl;
  const pickRows = tl.map(t => `${t.title}${t.region_div ? ' [' + [].concat(t.region_div).map(v => ({1:'시도', 2:'시군구', 3:'읍면동'})[v] || v).join('·') + ']' : ''}`);
  rows.push(['SGIS 주제도 (주거와 교통)', tm.ok, tm.ok ? `정상 · ${tl.length}개 항목` : tm.msg, tm.ok ? pickRows.join(' / ').slice(0, 900) : (tm.raw || '').slice(0, 400)]);
  rows[i] = ['SGIS 읍면동 경계', fs.length > 0, fs.length ? `정상 · 경계 ${fs.length}개 · 첫 점 ${p0 ? UTMK.inv(p0).map(v => v.toFixed(4)).reverse().join(', ') : '?'}` : sgisErr(b.js), fs.length ? '' : (b.raw || '').slice(0, 400)]; show();
}
