/* ============================================================
   추가 다이어그램 — 이미 받은 데이터로 만드는 일곱 가지
   · 교통: 보행 등시선, 근거리·광역 차이
   · 버스: 도보권 밖 생활권(사각지대)
   · 상권: 업종 다양성, 1층 가로 활성도
   · 인구: 도트 밀도
   · 종합: 거점 연결망
   그리고 각 카드의 "형식" 선택 상자를 여기서 연결합니다.
   ============================================================ */

/* ---------- 공통 도구 ---------- */
const mppNow = () => {
  const z = map && map.getZoom ? map.getZoom() : 15, lat = SITE.center ? SITE.center[1] : 35;
  return 156543.03 * Math.cos(lat * Math.PI / 180) / Math.pow(2, z);
};
function rng(seed){ let s = seed >>> 0 || 1; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; }
/* 선을 거리 구간 [s0, s1] 만큼 잘라내기 */
function subLine(pts, s0, s1){
  const out = []; let acc = 0;
  for(let i = 1; i < pts.length; i++){
    const a = pts[i - 1], b = pts[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if(acc + L >= s0 && acc <= s1){
      const t0 = Math.max(0, (s0 - acc) / L), t1 = Math.min(1, (s1 - acc) / L);
      const p0 = [a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0], p1 = [a[0] + (b[0] - a[0]) * t1, a[1] + (b[1] - a[1]) * t1];
      if(!out.length) out.push(p0);
      out.push(p1);
    }
    acc += L;
  }
  return out.length > 1 ? out : null;
}
/* 면 안을 빗금 선으로 채우기 (일러스트에서도 선으로 남게) */
function hatchMP(mp, spacing, angleDeg){
  if(!mp.length) return [];
  const C = CL(); if(!C) return [];
  let x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18;
  for(const poly of mp) for(const r of poly) for(const [x, y] of r){ x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  const a = angleDeg * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, R = Math.hypot(x1 - x0, y1 - y0) / 2 + spacing;
  const c = new C.Clipper();
  for(let s = -R; s <= R; s += spacing){
    const px = cx - dy * s, py = cy + dx * s;
    c.AddPath([{ X:Math.round((px - dx * R) * CLS), Y:Math.round((py - dy * R) * CLS) }, { X:Math.round((px + dx * R) * CLS), Y:Math.round((py + dy * R) * CLS) }], C.PolyType.ptSubject, false);
  }
  c.AddPaths(toPaths(mp), C.PolyType.ptClip, true);
  const tree = new C.PolyTree();
  c.Execute(C.ClipType.ctIntersection, tree, C.PolyFillType.pftNonZero, C.PolyFillType.pftNonZero);
  return C.Clipper.OpenPathsFromPolyTree(tree).map(p => p.map(q => [q.X / CLS, q.Y / CLS]));
}
const ringLL = (x, y, r, n) => circleM(r, n || 24)[0][0].map(([a, b]) => toLL([x + a, y + b]));

/* ============================================================
   1) 보행 등시선 — 대지에서 도로망을 따라 걸어서 닿는 범위
   ============================================================ */
function dijkstra(G, sources, key){
  const n = G.nodes.length, d = new Float64Array(n).fill(Infinity), heap = [];
  const push = (v, i) => { heap.push([v, i]); let k = heap.length - 1; while(k){ const p = (k - 1) >> 1; if(heap[p][0] <= heap[k][0]) break; [heap[p], heap[k]] = [heap[k], heap[p]]; k = p; } };
  const pop = () => { const top = heap[0], last = heap.pop(); if(heap.length){ heap[0] = last; let k = 0; for(;;){ const l = 2 * k + 1, r = l + 1; let m = k; if(l < heap.length && heap[l][0] < heap[m][0]) m = l; if(r < heap.length && heap[r][0] < heap[m][0]) m = r; if(m === k) break; [heap[m], heap[k]] = [heap[k], heap[m]]; k = m; } } return top; };
  for(const [s, d0] of sources){ if(d0 < d[s]){ d[s] = d0; push(d0, s); } }
  while(heap.length){
    const [v, i] = pop(); if(v > d[i]) continue;
    for(const o of G.out[i]){ const e = G.edges[o.e], nv = v + e[key]; if(nv < d[o.to]){ d[o.to] = nv; push(nv, o.to); } }
  }
  return d;
}
const ISO_MIN = [5, 10, 15], WALK = 80;                                // 분당 80m (시속 4.8km)
function computeIso(){
  if(!TR.ways || !TR.ways.length) return null;
  const G = buildGraph(TR.ways, 'walk');
  // 출발점: 대지 경계 30m 안의 교차점들 (대지가 없으면 화면 중심에서 가까운 세 곳)
  const src = [];
  if(SITE.geom){
    const sm = mapRings(SITE.geom, toM), ring = sm.flatMap(poly => poly[0]);
    G.nodes.forEach((p, i) => {
      if(pointInMulti(p, sm)){ src.push([i, 0]); return; }
      let best = 1e9; for(let k = 1; k < ring.length; k++){ const a = ring[k - 1], b = ring[k], vx = b[0] - a[0], vy = b[1] - a[1], L = vx * vx + vy * vy || 1, t = Math.max(0, Math.min(1, ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / L)); best = Math.min(best, Math.hypot(p[0] - a[0] - vx * t, p[1] - a[1] - vy * t)); }
      if(best <= 30) src.push([i, best]);
    });
  }
  if(!src.length) G.nodes.map((p, i) => [i, Math.hypot(p[0], p[1])]).sort((a, b) => a[1] - b[1]).slice(0, 3).forEach(s => src.push(s));
  const d = dijkstra(G, src, 'len');
  const bands = [], focus = focusGeomM(), buf = 28;
  for(const m of ISO_MIN){
    const T = m * WALK, lines = [];
    for(const e of G.edges){
      const da = d[e.a], db = d[e.b];
      if(!(da < T || db < T)) continue;
      const la = Math.max(0, Math.min(e.len, T - da)), lb = Math.max(0, Math.min(e.len, T - db));
      if(la + lb >= e.len){ lines.push(e.pts); continue; }
      if(la > 0){ const s = subLine(e.pts, 0, la); if(s) lines.push(s); }
      if(lb > 0){ const s = subLine(e.pts, e.len - lb, e.len); if(s) lines.push(s); }
    }
    if(!lines.length){ bands.push({ m, g:[] }); continue; }
    let g = offsetLines(lines, buf);
    g = offsetRound(offsetRound(union([g]), 30, 3), -30, 3);         // 길 사이 좁은 틈을 메워 하나의 영역으로
    g = cleanMP(inter(g, focus), { close:0, open:0, minPiece:400, minHole:2500, simplify:2 });
    bands.push({ m, g, km2:multiArea(g) / 1e6 });
  }
  TR.iso = { bands, src:src.length };
  return TR.iso;
}
function drawIso(){
  if(!TR.iso) computeIso();
  if(!TR.iso) return;
  const base = ST().iso || ST().age, ramp = rampFrom(base, 3), a = typeof CA === 'function' ? CA() : 0.7;
  // 바깥(15분)부터 옅게 → 안쪽(5분) 진하게
  [...TR.iso.bands].reverse().forEach((b, idx) => {
    if(!b.g.length) return;
    const k = idx, col = ramp[k];                                      // 15분 = 가장 옅게, 5분 = 가장 진하게
    extraSet('tr-iso-' + b.m, { label:`분석_보행등시선_${3 - k}_${b.m}분 (${b.m * WALK}m)`, stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:mapRings(b.g, toLL) } }] },
      paint:{ 'fill-color':col, 'fill-opacity':Math.min(1, 0.35 + a * 0.5) }, svg:{ kind:'fill', fill:col, opacity:Math.min(1, 0.35 + a * 0.5) } });
    extraSet('tr-iso-line-' + b.m, { label:`분석_보행등시선경계_${b.m}분_세부`, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[ringFeature(mapRings(b.g, toLL), {})] },
      paint:{ 'line-color':base, 'line-width':k === 2 ? 1.4 : 0.8, ...(k === 0 ? { 'line-dasharray':[3, 2] } : {}) }, svg:{ kind:'line', stroke:base, width:k === 2 ? 1.1 : 0.6, ...(k === 0 ? { dash:[3, 2] } : {}) } });
  });
  // 그 위에 도로망을 가늘게
  const parts = []; for(const w of TR.ways) if(!w.ped || w.c === 6) parts.push(...clipToFocus(w.pts));
  extraSet('tr-iso-roads', { label:'분석_보행등시선_도로_세부', stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[lineFeat(parts, {})] }, layout:{ 'line-cap':'round', 'line-join':'round' },
    paint:{ 'line-color':hexMix(ST().paper, ST().ink, 0.45), 'line-width':0.6 }, svg:{ kind:'line', stroke:hexMix(ST().paper, ST().ink, 0.45), width:0.45 } });
}

/* ============================================================
   2) 근거리·광역 차이 — 동네의 길 / 통과의 길 / 공통 중심축
   ============================================================ */
async function bcFor(G, scope, mode, label){
  const cutoff = mode === 'car' ? scope / (30 / 3.6) : scope;
  let src = []; G.nodes.forEach((p, i) => { if(inFocus(p) || Math.hypot(p[0], p[1]) <= focusR() + scope) src.push(i); });
  const MAX = scope > 1000 ? 1000 : 1800;
  if(src.length > MAX){ const st = src.length / MAX; src = Array.from({ length:MAX }, (_, k) => src[Math.floor(k * st)]); }
  return edgeBetweenness(G, src, cutoff, f => { $('trsum').textContent = `${label} 계산 중 ${Math.round(f * 100)}%`; });
}
async function computeDiff(){
  if(!TR.ways || TR.diffBusy) return;
  TR.diffBusy = true;
  try{
    const G = buildGraph(TR.ways, TR.mode);
    const bL = await bcFor(G, 800, TR.mode, '근거리'), bR = await bcFor(G, 2000, TR.mode, '광역');
    const rank = bc => {                                              // 범위 안 도로 중 백분위 (0~1)
      const idx = []; G.edges.forEach((e, i) => { if(bc[i] > 0 && e.pts.some(p => inFocus(p))) idx.push(i); });
      idx.sort((a, b) => bc[a] - bc[b]); const r = new Float32Array(G.edges.length); idx.forEach((i, k) => r[i] = (k + 1) / idx.length); return r;
    };
    TR.diff = { G, rL:rank(bL), rR:rank(bR) };
  }finally{ TR.diffBusy = false; }
}
function drawDiff(){
  if(!TR.diff){ computeDiff().then(() => { if(TR.form === 'diff'){ registerTrafficLayers(); apply(); summarizeTraffic(); } }); return; }
  const { G, rL, rR } = TR.diff, st = ST();
  const cls = { base:[], local:[], regional:[], both:[] }, len = { local:0, regional:0, both:0 };
  G.edges.forEach((e, i) => {
    if(!e.pts.some(p => inFocus(p))) return;
    const a = rL[i], b = rR[i]; let k = 'base';
    if(a >= 0.8 && b >= 0.8) k = 'both';
    else if(a - b >= 0.3 && a >= 0.5) k = 'local';
    else if(b - a >= 0.3 && b >= 0.5) k = 'regional';
    const parts = clipToFocus(e.pts); cls[k].push(...parts);
    if(k !== 'base') len[k] += e.len;
  });
  const def = [['base', hexMix(st.paper, st.ink, 0.25), 0.7, '바탕 도로_세부'], ['regional', st.bus, 2.8, '통과의 길 (광역에서 더 많이 지남)'],
               ['local', st.biz, 2.8, '동네의 길 (근거리에서 더 많이 지남)'], ['both', st.ink, 3.6, '공통 중심축 (둘 다 상위 20%)']];
  def.forEach(([k, col, w, nm], i) => {
    if(!cls[k].length) return;
    extraSet('tr-diff-' + k, { label:`분석_근거리광역차이_${i}_${nm}`, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[lineFeat(cls[k], {})] }, layout:{ 'line-cap':'round', 'line-join':'round' },
      paint:{ 'line-color':col, 'line-width':w }, svg:{ kind:'line', stroke:col, width:w * 0.8 } });
  });
  TR.diffLen = len;
}

/* 교통 카드 그리기 연결 — traffic.js 의 registerTrafficLayers 가 부릅니다 */
function drawExtraTraffic(){
  if(TR.form === 'iso') drawIso();
  else if(TR.form === 'diff') drawDiff();
}
function extraTrafficSummary(){
  if(TR.form === 'iso' && TR.iso) return '보행 등시선 · ' + TR.iso.bands.map(b => `${b.m}분 ${(b.km2 || 0).toFixed(2)}km²`).join(' · ') + (SITE.geom ? '' : ' (대지 없이 화면 중심에서)');
  if(TR.form === 'diff' && TR.diffLen){ const L = TR.diffLen; return `근거리·광역 차이 · 동네의 길 ${(L.local / 1000).toFixed(1)}km · 통과의 길 ${(L.regional / 1000).toFixed(1)}km · 공통 중심축 ${(L.both / 1000).toFixed(1)}km (추정)`; }
  if(TR.form === 'diff') return '근거리·광역 차이 계산 중…';
  return '';
}

/* ============================================================
   3) 버스: 도보권 밖 생활권 (사각지대)
   ============================================================ */
function drawBusGap(){
  const stops = BUS.wide ? BUS.wide.stops : (BUS.stops || []);
  if(!stops.length) return;
  const R = +$('buscatch').value || 400, st = ST(), focus = focusGeomM();
  const cover = union(stops.map(s => mapRings([[ringLL(s.m[0], s.m[1], R, 36)]], toM)));
  // 생활권 = 건물에서 30m 이내 (바다·산 제외). 건물이 없으면 범위 전체
  const fc = VW.data && VW.data.building_kr; let fabric = null;
  if(fc && fc.features.length){
    const polys = [];
    for(const f of fc.features) for(const poly of asMulti(f.geometry)){ const r = poly[0].map(toM); if(inFocus(centroidOf([[r]]))) polys.push([[r]]); }
    if(polys.length) fabric = cleanMP(inter(offsetRound(union(polys), 30, 3), focus), { close:20, open:0, minPiece:900, minHole:900, simplify:3 });
  }
  const base = fabric && fabric.length ? fabric : focus;
  const gap = cleanMP(diff(base, cover), { close:0, open:0, minPiece:400, minHole:400, simplify:2 });
  const col = st.bus, mpp = mppNow();
  extraSet('bus-gap-fill', { label:'분석_대중교통사각지대_바탕', stage:'ground', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:mapRings(gap, toLL) } }] },
    paint:{ 'fill-color':col, 'fill-opacity':0.07 }, svg:{ kind:'fill', fill:col, opacity:0.07 } });
  const hatch = hatchMP(gap, Math.max(6, mpp * 7), 45);
  extraSet('bus-gap-hatch', { label:`분석_대중교통사각지대_도보 ${R}m 밖 생활권`, stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[lineFeat(hatch, {})] }, paint:{ 'line-color':col, 'line-width':0.8, 'line-opacity':0.75 }, svg:{ kind:'line', stroke:col, width:0.5, opacity:0.75 } });
  extraSet('bus-gap-line', { label:'분석_대중교통사각지대_경계_세부', stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[ringFeature(mapRings(gap, toLL), {})] }, paint:{ 'line-color':col, 'line-width':1 }, svg:{ kind:'line', stroke:col, width:0.8 } });
  // 정류장 도보권 경계와 정류장 점
  extraSet('bus-gap-catch', { label:`분석_정류장도보권경계_${R}m`, stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[ringFeature(mapRings(cover, toLL), {})] }, paint:{ 'line-color':col, 'line-width':0.7, 'line-dasharray':[3, 2] }, svg:{ kind:'line', stroke:col, width:0.5, dash:[3, 2] } });
  extraSet('bus-gap-dot', { label:'분석_버스정류장', stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:stops.map(s => [ringLL(s.m[0], s.m[1], mpp * 2.6, 12)]) } }] },
    paint:{ 'fill-color':col }, svg:{ kind:'fill', fill:col, opacity:1 } });
  const A = multiArea(base), G = multiArea(gap);
  BUS.gap = { km2:G / 1e6, share:A ? G / A : 0, basis:fabric && fabric.length ? '건물 있는 생활권' : '범위 전체 (건물 정보 없음)', R };
}

/* ============================================================
   4) 상권: 업종 다양성 — 점 크기 = 상가 수, 색 = 업종이 섞인 정도
   ============================================================ */
const GRAIN_CELLS = { g1:6, g2:9, g3:12, g4:16, g5:22 };
function drawBizMix(list){
  const st = ST(), FR = focusR(), cell = FR / (GRAIN_CELLS[SITE.peakGrain] || 12);
  const cats = [...new Set(list.map(b => b.l).filter(Boolean))], K = Math.max(2, Math.min(10, cats.length));
  const g = new Map();
  for(const b of list){ const k = Math.floor(b.m_[0] / cell) + ',' + Math.floor(b.m_[1] / cell); if(!g.has(k)) g.set(k, new Map()); const m = g.get(k); m.set(b.l || '?', (m.get(b.l || '?') || 0) + 1); }
  const cellsOut = []; let nMax = 1;
  for(const [k, m] of g){
    let n = 0; for(const v of m.values()) n += v; if(n < 5) continue;
    let H = 0; for(const v of m.values()){ const p = v / n; H -= p * Math.log(p); }
    const [i, j] = k.split(',').map(Number);
    cellsOut.push({ x:(i + 0.5) * cell, y:(j + 0.5) * cell, n, h:H / Math.log(K), top:[...m.entries()].sort((a, b) => b[1] - a[1])[0][0] });
    nMax = Math.max(nMax, n);
  }
  const names = ['한 업종 위주', '조금 섞임', '섞임', '다양함'], cut = h => h >= 0.8 ? 3 : h >= 0.6 ? 2 : h >= 0.35 ? 1 : 0;
  const bins = [[], [], [], []];
  for(const c of cellsOut){ const r = cell * 0.47 * Math.max(0.28, Math.sqrt(c.n / nMax)); if(inFocus([c.x, c.y])) bins[cut(c.h)].push([ringLL(c.x, c.y, r, 28)]); }
  bins.forEach((polys, k) => {
    if(!polys.length) return;
    const col = hexMix(st.biz, st.bus, k / 3);
    extraSet('biz-mix-' + k, { label:`분석_업종다양성_${k + 1}_${names[k]}`, stage:'top', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:polys } }] },
      paint:{ 'fill-color':col, 'fill-opacity':0.85 }, svg:{ kind:'fill', fill:col, opacity:0.85 } });
  });
  BIZ.mix = { cells:cellsOut.length, cell:Math.round(cell), share:bins.map(b => b.length) };
}

/* ============================================================
   5) 상권: 1층 가로 활성도 — 길이 100m 당 1층 가게 수
   ============================================================ */
async function computeStreet(){
  let ways = TR.ways && TR.ways.length ? TR.ways : null;
  if(!ways){ $('bizsum').textContent = '가로 활성도: 도로망 받는 중'; const raw = await fetchRoads(focusR() + 100, null); ways = raw.filter(e => e.type === 'way' && e.geometry).map(wayInfo).filter(Boolean); }
  ways = ways.filter(w => w.c !== 0);
  const CELL = 60, idx = new Map();
  ways.forEach((w, wi) => { for(let i = 1; i < w.pts.length; i++){ const a = w.pts[i - 1], b = w.pts[i];
    const x0 = Math.floor(Math.min(a[0], b[0]) / CELL), x1 = Math.floor(Math.max(a[0], b[0]) / CELL), y0 = Math.floor(Math.min(a[1], b[1]) / CELL), y1 = Math.floor(Math.max(a[1], b[1]) / CELL);
    for(let x = x0; x <= x1; x++) for(let y = y0; y <= y1; y++){ const k = x + ',' + y; if(!idx.has(k)) idx.set(k, []); idx.get(k).push([wi, a, b]); } } });
  const cnt = new Float64Array(ways.length);
  const ground = BIZ.items.filter(b => !b.fl || /^(1|1층|지상1|1F)$/i.test(b.fl.trim()));
  for(const s of ground){
    const [px, py] = s.m_, cx = Math.floor(px / CELL), cy = Math.floor(py / CELL); let best = 35, bw = -1;
    for(let x = cx - 1; x <= cx + 1; x++) for(let y = cy - 1; y <= cy + 1; y++) for(const [wi, a, b] of (idx.get(x + ',' + y) || [])){
      const vx = b[0] - a[0], vy = b[1] - a[1], L = vx * vx + vy * vy || 1, t = Math.max(0, Math.min(1, ((px - a[0]) * vx + (py - a[1]) * vy) / L));
      const d = Math.hypot(px - a[0] - vx * t, py - a[1] - vy * t); if(d < best){ best = d; bw = wi; }
    }
    if(bw >= 0) cnt[bw]++;
  }
  const rows = ways.map((w, i) => { const parts = clipToFocus(w.pts); let L = 0; for(const p of parts) for(let k = 1; k < p.length; k++) L += Math.hypot(p[k][0] - p[k - 1][0], p[k][1] - p[k - 1][1]); return { w, parts, L, n:cnt[i], d:L > 20 ? cnt[i] / (L / 100) : 0 }; }).filter(r => r.parts.length);
  BIZ.street = { rows, ground:ground.length };
}
function drawBizStreet(){
  if(!BIZ.street){ computeStreet().then(() => { registerBizLayers(); apply(); summarizeBiz(); }).catch(e => { $('bizsum').textContent = '가로 활성도 실패 — ' + e.message; }); return; }
  const st = ST(), rows = BIZ.street.rows, act = rows.filter(r => r.n >= 2 && r.d > 0).sort((a, b) => a.d - b.d);
  const q = f => act.length ? act[Math.min(act.length - 1, Math.floor(f * act.length))].d : 0, cuts = [q(0.4), q(0.7), q(0.9)];
  const ramp = rampFrom(st.biz, 4), W = [1.3, 2.4, 3.6, 5.2], bins = [[], [], [], []], base = [];
  for(const r of rows){ if(r.n < 2 || r.d <= 0){ base.push(...r.parts); continue; } const k = r.d >= cuts[2] ? 3 : r.d >= cuts[1] ? 2 : r.d >= cuts[0] ? 1 : 0; bins[k].push(...r.parts); }
  extraSet('biz-st-base', { label:'분석_가로활성도_바탕_세부', stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[lineFeat(base, {})] }, paint:{ 'line-color':hexMix(st.paper, st.ink, 0.22), 'line-width':0.7 }, svg:{ kind:'line', stroke:hexMix(st.paper, st.ink, 0.22), width:0.5 } });
  const fmt = v => v.toFixed(1);
  bins.forEach((parts, k) => {
    if(!parts.length) return;
    const nm = k === 3 ? `100m당 ${fmt(cuts[2])}곳 이상` : k === 0 ? `100m당 ${fmt(cuts[0])}곳 미만` : `100m당 ${fmt(cuts[k - 1])}–${fmt(cuts[k])}곳`;
    extraSet('biz-st-' + k, { label:`분석_1층가로활성도_${k + 1}_${nm}`, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[lineFeat(parts, {})] }, layout:{ 'line-cap':'round', 'line-join':'round' },
      paint:{ 'line-color':ramp[k], 'line-width':W[k] }, svg:{ kind:'line', stroke:ramp[k], width:W[k] * 0.8 } });
  });
  BIZ.streetTop = act.slice(-5).reverse().map(r => ({ name:r.w.name || '(이름 없음)', per100m:+r.d.toFixed(1), stores:r.n }));
}

/* ============================================================
   6) 인구: 도트 밀도 — 1점 = N명
   ============================================================ */
function drawPopDots(field){
  const pts = popPoints(field); if(!pts.length) return;
  const total = pts.reduce((s, p) => s + p[2], 0), nice = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000];
  const per = nice.find(v => total / v <= 4000) || 5000, R = rng(7), mpp = mppNow(), r = Math.max(1.2, mpp * 1.5), jit = POP.dasy && POP.dasy.bld ? 5 : 25;
  const dots = [];
  for(const [x, y, w] of pts){
    let k = Math.floor(w / per + R());
    while(k-- > 0){ const px = x + (R() - 0.5) * 2 * jit, py = y + (R() - 0.5) * 2 * jit; if(inFocus([px, py])) dots.push([ringLL(px, py, r, 6)]); }
  }
  const col = field === 'pop' ? ST().pop : ST().work, nm = field === 'pop' ? '인구도트' : '종사자도트';
  extraSet('pop-dots', { label:`분석_${nm}_1점 = ${per.toLocaleString()}명`, stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:dots } }] },
    paint:{ 'fill-color':col, 'fill-opacity':0.85 }, svg:{ kind:'fill', fill:col, opacity:0.85 } });
  extraSet('pop-line', { label:'분석_행정동경계', stage:'fill', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:POP.dongs.map(d => ringFeature(mapRings(d.clip, toLL), {})) },
    paint:{ 'line-color':ST().dongLine, 'line-width':0.6, 'line-dasharray':[2, 2] }, svg:{ kind:'line', stroke:ST().dongLine, width:0.5, dash:[2, 2] } });
  POP.dotPer = per; POP.dotCount = dots.length;
}

/* ============================================================
   7) 거점 연결망 — 상권·인구 거점, 교통 결절점, 버스 거점 정류장을 잇기
   ============================================================ */
const HUB = { on:false };
function collectHubs(){
  const hubs = [];
  if(BIZ.on && BIZ.items && BIZ.items.length){
    const pk = BIZ.peaks || kdePeaks(BIZ.items.map(b => [b.m_[0], b.m_[1], 1])).peaks;
    pk.forEach(p => hubs.push({ t:'biz', x:p.x, y:p.y, v:p.mass }));
  }
  if(POP.on && POP.dongs && POP.dongs.length){
    const pk = POP.peaks || kdePeaks(popPoints(POP.form === 'work' ? 'worker' : 'pop')).peaks;
    pk.forEach(p => hubs.push({ t:'pop', x:p.x, y:p.y, v:p.mass }));
  }
  if(TR.on && TR.nodes) TR.nodes.forEach(n => { if(n.x != null) hubs.push({ t:'node', x:n.x, y:n.y, v:1 / n.rank }); });
  if(BUS.on){
    const st = BUS.wide ? BUS.wide.stops.map(s => ({ m:s.m, n:s.n })) : (BUS.stops || []).map(s => ({ m:s.m, n:(s.routes || []).length }));
    st.sort((a, b) => b.n - a.n).slice(0, 6).forEach(s => hubs.push({ t:'bus', x:s.m[0], y:s.m[1], v:s.n }));
  }
  return hubs.filter(h => inFocus([h.x, h.y]));
}
/* 거점 연결망 — 성격이 다른 거점끼리만 부드러운 호로 잇고, 대지에서 각 성격의 가장 가까운 거점까지 점선 호와 거리 */
const HUB_K = { g1:2, g2:3, g3:4, g4:5, g5:7 };
function arcPts(a, b, bend){
  const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, dx = b[0] - a[0], dy = b[1] - a[1];
  const c = [mx - dy * bend, my + dx * bend], out = [];
  for(let i = 0; i <= 20; i++){ const t = i / 20, u = 1 - t; out.push([u * u * a[0] + 2 * u * t * c[0] + t * t * b[0], u * u * a[1] + 2 * u * t * c[1] + t * t * b[1]]); }
  return out;
}
function registerHubLayers(){
  extraRemove('hub-');
  if(!HUB.on || !hasRef() || SITE.mode !== 'site') return;
  const st = ST(), mpp = mppNow(), a = typeof CA === 'function' ? CA() : 0.7, K = HUB_K[SITE.peakGrain] || 4;
  // 성격마다 강한 순으로 K곳만
  const all = collectHubs(), hubs = [];
  for(const t of ['biz', 'pop', 'node', 'bus']){ const hs = all.filter(h => h.t === t).sort((p, q) => q.v - p.v).slice(0, K); const vMax = hs.length ? hs[0].v : 1; hs.forEach(h => hubs.push({ ...h, s:Math.sqrt(h.v / (vMax || 1)) })); }
  if(hubs.length < 2){ $('hubsum').textContent = '이을 거점이 부족합니다 — 상권·인구 카드, 교통(축과 결절점), 버스 중 두 가지 이상을 켜 주세요'; return; }
  const TYPES = { biz:['상권 거점', st.biz], pop:[POP.form === 'work' ? '종사자 거점' : '인구 거점', POP.form === 'work' ? st.work : st.pop], node:['교통 결절점', st.flow[4]], bus:['버스 거점 정류장', st.kict] };   // 인구(파랑)와 겹치지 않게 버스는 보라 계열
  // 1) 다른 성격끼리: 서로가 서로에게 가장 가까운 짝(상호 최근접)만 — 한 점으로 선이 몰리지 않게
  const maxL = focusR() * 0.9, links = [];
  const nearestOf = (i, t) => { let best = -1, bd = maxL; hubs.forEach((g, j) => { if(g.t !== t) return; const d = Math.hypot(g.x - hubs[i].x, g.y - hubs[i].y); if(d < bd){ bd = d; best = j; } }); return best; };
  hubs.forEach((h, i) => {
    for(const t of Object.keys(TYPES)){
      if(t <= h.t) continue;                                          // 성격 쌍마다 한 번만
      const j = nearestOf(i, t); if(j < 0) continue;
      if(nearestOf(j, h.t) !== i) continue;                           // 서로 가장 가까울 때만
      links.push(arcPts([h.x, h.y], [hubs[j].x, hubs[j].y], 0.12).map(toLL));
    }
  });
  extraSet('hub-link', { label:'분석_거점연결망_1_성격이 다른 거점 사이', stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:links } }] },
    layout:{ 'line-cap':'round' }, paint:{ 'line-color':st.ink, 'line-width':1.1, 'line-opacity':Math.min(1, a + 0.15) }, svg:{ kind:'line', stroke:st.ink, width:0.9, opacity:Math.min(1, a + 0.15) } });
  // 2) 대지에서: 성격마다 가장 가까운 거점까지 점선 호 + 거리
  const siteLinks = [], labels = [];
  for(const t of Object.keys(TYPES)){
    const hs = hubs.filter(h => h.t === t); if(!hs.length) continue;
    const h = hs.reduce((p, q) => Math.hypot(p.x, p.y) <= Math.hypot(q.x, q.y) ? p : q), d = Math.hypot(h.x, h.y);
    if(d < mpp * 20) continue;
    const arc = arcPts([0, 0], [h.x, h.y], -0.1); siteLinks.push(arc.map(toLL));
    labels.push({ type:'Feature', properties:{ label:`${TYPES[t][0].replace(/ 거점| 정류장/g, '')} ${d >= 1000 ? (d / 1000).toFixed(1) + 'km' : Math.round(d / 10) * 10 + 'm'}` }, geometry:{ type:'Point', coordinates:toLL(arc[10]) } });
  }
  if(siteLinks.length){
    extraSet('hub-site', { label:`분석_거점연결망_2_${SITE.geom ? '대지' : '범위 중심'}에서 가장 가까운 거점`, stage:'top', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:siteLinks } }] },
      layout:{ 'line-cap':'round' }, paint:{ 'line-color':st.site, 'line-width':1.6, 'line-dasharray':[2.5, 1.8] }, svg:{ kind:'line', stroke:st.site, width:1.3, dash:[2.5, 1.8] } });
    extraSet('hub-site-label', { label:'분석_거점연결망_거리', stage:'top', type:'symbol', nomerge:true,
      fc:{ type:'FeatureCollection', features:labels },
      layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10, 'text-allow-overlap':false },
      paint:{ 'text-color':st.site, 'text-halo-color':st.paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:st.site, size:8 } });
  }
  // 3) 거점: 옅은 영향권 + 테두리 + 가운데 점 (투명도 슬라이더를 따름)
  for(const [t, [nm, col]] of Object.entries(TYPES)){
    const hs = hubs.filter(h => h.t === t); if(!hs.length) continue;
    const R = h => mpp * (12 + 12 * h.s);
    extraSet('hub-' + t + '-halo', { label:`분석_거점_${nm}`, stage:'top', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:hs.map(h => ({ type:'Feature', properties:{}, geometry:{ type:'Polygon', coordinates:[ringLL(h.x, h.y, R(h), 40)] } })) },
      paint:{ 'fill-color':col, 'fill-opacity':0.22 * a }, svg:{ kind:'fill', fill:col, opacity:0.22 * a } });
    extraSet('hub-' + t + '-ring', { label:`분석_거점_${nm}테두리_세부`, stage:'top', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:hs.map(h => ({ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:ringLL(h.x, h.y, R(h), 40) } })) },
      paint:{ 'line-color':col, 'line-width':1, 'line-opacity':Math.min(1, a + 0.2) }, svg:{ kind:'line', stroke:col, width:0.8, opacity:Math.min(1, a + 0.2) } });
    extraSet('hub-' + t + '-core', { label:`분석_거점_${nm}중심_세부`, stage:'top', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:hs.map(h => [ringLL(h.x, h.y, mpp * 3.2, 16)]) } }] },
      paint:{ 'fill-color':col, 'fill-opacity':Math.min(1, a + 0.3) }, svg:{ kind:'fill', fill:col, opacity:Math.min(1, a + 0.3) } });
  }
  // 대지 표시 (마름모)
  const r = mpp * 7;
  extraSet('hub-site-mark', { label:`분석_거점_${SITE.geom ? '대지' : '범위 중심'}`, stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'Polygon', coordinates:[[[0, r], [r, 0], [0, -r], [-r, 0], [0, r]].map(toLL)] } }] },
    paint:{ 'fill-color':st.site }, svg:{ kind:'fill', fill:st.site, opacity:1 } });
  const cnt = t => hubs.filter(h => h.t === t).length;
  $('hubsum').textContent = `거점 ${hubs.length}곳 (성격마다 강한 순 ${K}곳까지) · 상권 ${cnt('biz')} · 인구 ${cnt('pop')} · 결절점 ${cnt('node')} · 버스 ${cnt('bus')} · 서로 가장 가까운 짝 ${links.length}개 연결`;
  HUB.summary = { hubs:hubs.map(h => ({ type:h.t, distance_m:Math.round(Math.hypot(h.x, h.y)), direction:dir8(Math.atan2(h.x, h.y) * 180 / Math.PI) })),
    nearest_from_site:labels.map(f => f.properties.label), links:links.length, note:'성격이 다른 거점끼리 서로 가장 가까운 짝만 이은 연결망입니다.' };
}
// 확대·축소하면 원 크기(화면 기준)를 다시
(function hookHubZoom(){ if(typeof map === 'undefined' || !map || !map.on){ setTimeout(hookHubZoom, 400); return; } map.on('zoomend', () => { if(HUB.on){ registerHubLayers(); apply(); } }); })();
$('hubon').addEventListener('change', e => { HUB.on = e.target.checked; $('card-hub').classList.toggle('on', HUB.on); registerHubLayers(); apply(); });

/* ============================================================
   형식 선택 상자 연결
   ============================================================ */
$('trdiag').addEventListener('change', async e => {
  const v = e.target.value;
  if(v === 'hier') TR.form = 'hier';
  else if(v.startsWith('flow:')){ TR.form = 'flow'; TR.flowView = v.slice(5); }
  else TR.form = v;
  $('trflowopts').hidden = !(TR.form === 'flow' || TR.form === 'diff');
  if(!TR.on) return;
  if(!TR.ways){ runTraffic(); return; }
  if(TR.form === 'flow' && !TR.res){ runFlow(); return; }
  registerTrafficLayers(); applyBaseRoads && applyBaseRoads(); apply(); summarizeTraffic();
});
$('busdiag').addEventListener('change', e => { BUS.form = e.target.value; registerBusLayers(); apply(); summarizeBusGap(); });
$('buscatch').addEventListener('change', () => summarizeBusGap());
function summarizeBusGap(){
  if(BUS.form !== 'gap' || !BUS.gap) return;
  $('bussum').textContent = `도보 ${BUS.gap.R}m 밖 생활권 ${BUS.gap.km2.toFixed(2)}km² · ${BUS.gap.basis}의 ${Math.round(BUS.gap.share * 100)}%`;
}
$('bizdiag').addEventListener('change', e => { BIZ.form = e.target.value; registerBizLayers(); apply(); if(BIZ.form === 'zones') summarizeZones(); else summarizeBiz(); });
$('popdiag').addEventListener('change', e => {
  const [f, v] = e.target.value.split(':'); POP.form = f; POP.view = v;
  registerPopLayers(); apply(); summarizePop();
});
// 처음 값 맞추기
$('trdiag').value = TR.form === 'flow' ? 'flow:' + TR.flowView : TR.form;
$('trflowopts').hidden = !(TR.form === 'flow' || TR.form === 'diff');
$('busdiag').value = BUS.form; $('bizdiag').value = BIZ.form;
$('popdiag').value = POP.form + ':' + (POP.view === 'circles' || POP.view === 'kde' || POP.view === 'dots' ? POP.view : 'dong');
