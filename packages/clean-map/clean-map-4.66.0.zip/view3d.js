/* ============================================================
   기울인 3D 화면 그대로 SVG
   지도를 기울이거나(원근) 지형을 켠 상태에서 SVG 로 내보내면
   · 바닥 레이어(도로·분석·물 등)는 지금 화면과 같은 원근으로, 지형이 있으면 지형을 따라
   · 3D 매스를 켜 두었으면 건물을 지금 구도의 입체(벽·지붕)로 — 먼 것부터 그려 앞 건물이 뒤를 가립니다
   지도 엔진(MapLibre)이 화면을 그릴 때 쓰는 행렬을 그대로 써서 화면과 같은 자리에 놓입니다.
   ============================================================ */

/* 원근 투영 준비 — 평면(기울이지 않고 지형도 없음)이면 null (예전 방식 그대로) */
function perspSetup(f){
  if(typeof map === 'undefined' || !map || !map.transform || typeof maplibregl === 'undefined') return null;
  const pitch = map.getPitch ? map.getPitch() : 0, terr = map.terrain || null;
  if(pitch < 2 && !terr) return null;
  const tr = map.transform, M = tr.pixelMatrix3D || tr.pixelMatrix, ws = tr.worldSize, tz = tr.tileZoom;
  if(!M || !ws) return null;
  const near = Math.max(1, (tr.height || 600) / 50);
  const LL = maplibregl.LngLat, MC = maplibregl.MercatorCoordinate;
  // 땅 높이 — 지도에 보이는 지형과 같은 값 (높이 과장 포함)
  const zg = terr ? (lng, lat) => { try{ return terr.getElevationForLngLatZoom(new LL(lng, lat), tz) || 0; }catch(e){ return 0; } } : () => 0;
  // 동차 좌표 [X, Y, W] — W 는 카메라 앞쪽 거리 (0 이하면 카메라 뒤)
  const H = (lng, lat, z) => {
    const m = MC.fromLngLat([lng, lat]), x = m.x * ws, y = m.y * ws;
    return [M[0] * x + M[4] * y + M[8] * z + M[12], M[1] * x + M[5] * y + M[9] * z + M[13], M[3] * x + M[7] * y + M[11] * z + M[15]];
  };
  const div = h => [h[0] / h[2] - f.x, h[1] / h[2] - f.y];
  const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const cut = (a, b) => lerp(a, b, (near - a[2]) / (b[2] - a[2]));
  // 지형이 있으면 긴 변을 약 25m 로 잘게 나눠 땅을 따라 휘게
  const dens = coords => {
    if(!terr) return coords;
    const out = [];
    for(let i = 0; i < coords.length; i++){
      const p = coords[i];
      if(i){
        const q = coords[i - 1], dx = (p[0] - q[0]) * 111320 * Math.cos(p[1] * Math.PI / 180), dy = (p[1] - q[1]) * 110540;
        const n = Math.min(80, Math.floor(Math.hypot(dx, dy) / 25));
        for(let k = 1; k < n; k++) out.push([q[0] + (p[0] - q[0]) * k / n, q[1] + (p[1] - q[1]) * k / n]);
      }
      out.push(p);
    }
    return out;
  };
  const hg = c => H(c[0], c[1], zg(c[0], c[1]));
  // 카메라 앞쪽만 남기기 — 동차 좌표에서 잘라 나눗셈 전에 처리 (카메라 뒤 점이 뒤집혀 튀지 않게)
  const ring = coords => {
    const hs = dens(coords).map(hg), out = [];
    for(let i = 0; i < hs.length; i++){
      const a = hs[(i + hs.length - 1) % hs.length], b = hs[i], ai = a[2] > near, bi = b[2] > near;
      if(bi){ if(!ai) out.push(cut(a, b)); out.push(b); }
      else if(ai) out.push(cut(a, b));
    }
    return out.map(div);
  };
  const line = coords => {
    const hs = dens(coords).map(hg), parts = []; let cur = null;
    for(let i = 0; i < hs.length; i++){
      const b = hs[i], bi = b[2] > near;
      if(!i){ if(bi) cur = [b]; continue; }
      const a = hs[i - 1], ai = a[2] > near;
      if(ai && bi) cur.push(b);
      else if(ai){ cur.push(cut(a, b)); parts.push(cur); cur = null; }
      else if(bi) cur = [cut(a, b), b];
    }
    if(cur) parts.push(cur);
    return parts.map(p => p.map(div));
  };
  const P = ll => { const h = hg(ll); return h[2] > near ? div(h) : [-1e9, -1e9]; };
  return { P, ring, line, H, zg, div, near, terr:!!terr, pitch };
}

/* 3D 매스 — 지금 구도의 벽·지붕. clipRing·toD 는 내보내기 쪽 함수(틀 경계 자르기·경로 문자열)를 받아 씁니다 */
function mass3dSVG(ps, f, clipRing, toD){
  const d = EXTRA.layers.get('d3-mass');
  if(!d || !d.fc || !d.fc.features.length) return '';
  const st = ST(), mc = typeof massColors === 'function' ? massColors() : { mass:st.mass }, edge = st.massEdge;
  const area = pts => { let s = 0; for(let i = 0; i < pts.length; i++){ const p = pts[i], q = pts[(i + 1) % pts.length]; s += p[0] * q[1] - q[0] * p[1]; } return s; };
  // 보이는 면이 화면에서 감기는 방향 — 땅 위 반시계 사각형(위에서 보면 늘 보임)을 투영해서 정합니다
  const c0 = map.getCenter(), z0 = ps.zg(c0.lng, c0.lat), e = 2e-4;
  const ref = Math.sign(area([[0, 0], [e, 0], [e, e], [0, e]].map(([a, b]) => ps.div(ps.H(c0.lng + a, c0.lat + b, z0))))) || -1;
  const L = [-Math.SQRT1_2, Math.SQRT1_2];                                  // 북서쪽에서 오는 빛 — 벽 명암
  const W = f.w, Hh = f.h, out = [];
  for(const ft of d.fc.features){
    const pr = ft.properties || {}, h = +pr.h || 3, top0 = pr.c || mc.mass;
    for(const poly of asMulti(ft.geometry)){
      let ring = poly[0].slice();
      if(ring.length > 1 && ring[0][0] === ring[ring.length - 1][0] && ring[0][1] === ring[ring.length - 1][1]) ring.pop();
      if(ring.length < 3) continue;
      if(area(ring) < 0) ring.reverse();                                     // 경위도 평면에서 반시계로
      const gz = ring.map(([x, y]) => ps.zg(x, y));
      let cx = 0, cy = 0; for(const [x, y] of ring){ cx += x; cy += y; } cx /= ring.length; cy /= ring.length;
      const zt = ps.zg(cx, cy) + h;                                          // 지붕 = 가운데 땅 높이 + 건물 높이 (지도 엔진과 같은 규칙)
      const B = ring.map(([x, y], i) => ps.H(x, y, gz[i])), T = ring.map(([x, y]) => ps.H(x, y, zt));
      if(B.some(p => p[2] <= ps.near) || T.some(p => p[2] <= ps.near)) continue;   // 카메라에 걸친 건물은 뺍니다
      const Bs = B.map(ps.div), Ts = T.map(ps.div);
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      for(const [x, y] of [...Bs, ...Ts]){ if(x < x0) x0 = x; if(x > x1) x1 = x; if(y < y0) y0 = y; if(y > y1) y1 = y; }
      if(x1 < 0 || y1 < 0 || x0 > W || y0 > Hh) continue;                   // 틀 밖
      if((x1 - x0) * (y1 - y0) < 0.6) continue;                              // 점보다 작은 먼 건물
      const faces = [];
      for(let i = 0; i < ring.length; i++){
        const j = (i + 1) % ring.length, q = [Bs[i], Bs[j], Ts[j], Ts[i]], s = area(q);
        if(!s || Math.sign(s) !== ref) continue;                             // 뒤를 향한 벽
        const ex = (ring[j][0] - ring[i][0]) * Math.cos(cy * Math.PI / 180), ey = ring[j][1] - ring[i][1], el = Math.hypot(ex, ey) || 1;
        const lam = (ey / el) * L[0] + (-ex / el) * L[1];                     // 바깥 법선(오른쪽) · 빛
        faces.push({ w:(B[i][2] + B[j][2] + T[i][2] + T[j][2]) / 4, pts:q, col:hexMix(top0, edge, 0.06 + 0.16 * (1 - lam) / 2) });
      }
      faces.sort((a, b) => b.w - a.w);
      const html = [];
      for(const fc of faces){ const cp = clipRing(fc.pts); if(cp.length >= 3) html.push(`<path d="${toD(cp, true)}" fill="${fc.col}"/>`); }
      if(Math.sign(area(Ts)) === ref){ const cp = clipRing(Ts); if(cp.length >= 3) html.push(`<path d="${toD(cp, true)}" fill="${top0}"/>`); }
      if(html.length) out.push({ w:T.reduce((s, p) => s + p[2], 0) / T.length, html:html.join('') });
    }
  }
  if(!out.length) return '';
  out.sort((a, b) => b.w - a.w);                                             // 먼 건물부터
  return `<g id="분석_3D매스_입체" data-layer="mass3d" stroke="${edge}" stroke-width="0.35" stroke-linejoin="round">`
    + out.map(o => `<g>${o.html}</g>`).join('') + '</g>';
}
