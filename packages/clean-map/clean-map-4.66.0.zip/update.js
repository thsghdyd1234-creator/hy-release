/* ============================================================
   새 버전 적용 — 허브는 설치 폴더의 파일을 새 버전으로 바꿔 두지만, 크롬은 확장을 다시 불러오기 전까지
   처음 불러온 버전(manifest·배경 스크립트)을 계속 씁니다. 폴더의 manifest.json 버전이 지금 돌아가는 버전과
   다르면 확장을 다시 불러와 새 버전으로 바꿉니다 (배경 스크립트 background.js 가 다시 불러오고 화면을 다시 엽니다).
   - 막 연 화면: 아직 한 일이 없으니 바로 바꾸고 같은 자리로 다시 엽니다
   - 쓰던 화면: 위에 띠를 띄우고 [지금 적용]을 누를 때 바꿉니다 (작업 중인 분석은 사라지므로)
   ============================================================ */
(() => {
  const rt = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id ? chrome.runtime : null;
  if(!rt) return;                                   // 로컬 서버로 연 화면 등 — 확장이 아님
  const running = rt.getManifest().version;

  async function onDisk(){
    try{
      const r = await fetch(rt.getURL('manifest.json') + '?t=' + Date.now(), { cache:'no-store' });
      return (await r.json()).version || null;
    }catch(e){ return null; }                       // 허브가 바꾸는 중이면 다음에 다시 봅니다
  }

  /* 다시 열 주소 — 지금 보던 자리 (위도·경도·줌) */
  function here(){
    try{
      if(typeof map !== 'undefined' && map && map.getCenter){
        const c = map.getCenter();
        return rt.getURL('index.html') + '?q=' + encodeURIComponent(
          '@' + c.lat.toFixed(6) + ',' + c.lng.toFixed(6) + ',' + map.getZoom().toFixed(2) + 'z');
      }
    }catch(e){}
    return location.href;
  }

  function apply(){
    try{ rt.sendMessage({ type:'applyUpdate', urls:[here()] }); }catch(e){}
  }

  let bar = null;
  function banner(v){
    if(bar) return;
    bar = document.createElement('div');
    bar.id = 'updbar';
    bar.innerHTML = '<span>새 버전 <b class="num nv"></b>이 설치돼 있어요. 지금 화면은 <span class="num ov"></span>이에요.</span>'
      + '<button type="button" class="go">지금 적용</button><button type="button" class="x" aria-label="닫기">×</button>';
    bar.querySelector('.nv').textContent = v;
    bar.querySelector('.ov').textContent = running;
    bar.querySelector('.go').addEventListener('click', apply);
    bar.querySelector('.x').addEventListener('click', () => { bar.remove(); bar = null; dismissed = v; });
    (document.querySelector('main') || document.body).appendChild(bar);
  }

  let dismissed = null, busy = false;
  async function check(first){
    if(busy) return;
    busy = true;
    try{
      const v = await onDisk();
      if(!v || v === running) return;
      if(first) apply();
      else if(v !== dismissed) banner(v);
    }finally{ busy = false; }
  }

  check(true);
  document.addEventListener('visibilitychange', () => { if(!document.hidden) check(false); });
  window.addEventListener('focus', () => check(false));
  setInterval(() => { if(!document.hidden) check(false); }, 5 * 60 * 1000);
})();
