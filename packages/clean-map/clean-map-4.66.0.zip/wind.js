/* ============================================================
   바람 — 기상청 지상(종관, ASOS) 시간자료 (공공데이터포털, 같은 인증키)
   가장 가까운 관측소의 최근 몇 년 시간별 풍향·풍속을 받아
   방위 16 × 풍속 5단계 × 계절 4개로 집계합니다. 집계만 저장하므로 가볍습니다.
   ============================================================ */
const ASOS = 'apis.data.go.kr/1360000/AsosHourlyInfoService/getWthrDataList';
const ASOS_STN = [
  [90,'속초',38.251,128.565],[95,'철원',38.148,127.304],[98,'동두천',37.902,127.061],[99,'파주',37.886,126.767],[100,'대관령',37.677,128.718],
  [101,'춘천',37.903,127.736],[105,'강릉',37.752,128.891],[108,'서울',37.571,126.966],[112,'인천',37.478,126.625],[114,'원주',37.338,127.947],
  [119,'수원',37.272,126.985],[127,'충주',36.971,127.953],[129,'서산',36.777,126.494],[130,'울진',36.992,129.413],[131,'청주',36.639,127.441],
  [133,'대전',36.372,127.372],[135,'추풍령',36.220,127.995],[136,'안동',36.573,128.707],[138,'포항',36.033,129.380],[140,'군산',36.005,126.761],
  [143,'대구',35.878,128.653],[146,'전주',35.841,127.117],[152,'울산',35.560,129.320],[155,'창원',35.170,128.573],[156,'광주',35.173,126.892],
  [159,'부산',35.105,129.032],[162,'통영',34.846,128.436],[165,'목포',34.817,126.381],[168,'여수',34.739,127.741],[170,'완도',34.396,126.702],
  [184,'제주',33.514,126.530],[189,'서귀포',33.246,126.565],[192,'진주',35.164,128.040],[201,'강화',37.707,126.446],[211,'인제',38.060,128.167],
  [221,'제천',37.159,128.194],[232,'천안',36.762,127.293],[243,'부안',35.730,126.717],[247,'남원',35.421,127.397],[253,'김해시',35.229,128.890],
  [255,'북창원',35.226,128.673],[257,'양산시',35.307,129.020],[260,'장흥',34.689,126.920],[273,'문경',36.627,128.149],[278,'의성',36.356,128.689],
  [281,'영천',35.977,128.951],[288,'밀양',35.491,128.744],[289,'산청',35.413,127.879],[294,'거제',34.888,128.605],[295,'남해',34.817,127.926]
];
const WIND = { on:false, busy:false, stats:null, form:'rose', off:[0, 0], compass:true };
const SPD = [0.5, 1.5, 3.3, 5.4, 7.9];                                  // 무풍 기준 0.5, 이후 단계 경계 (m/s)
const SPD_NAME = ['0.5–1.5', '1.5–3.3', '3.3–5.4', '5.4–7.9', '7.9 이상'];
const SEASON = m => (m >= 3 && m <= 5) ? 0 : (m >= 6 && m <= 8) ? 1 : (m >= 9 && m <= 11) ? 2 : 3;
const SEASON_NAME = ['봄', '여름', '가을', '겨울'];
const DIR16 = ['북', '북북동', '북동', '동북동', '동', '동남동', '남동', '남남동', '남', '남남서', '남서', '서남서', '서', '서북서', '북서', '북북서'];

function nearestStation(){
  const c = SITE.center || [map.getCenter().lng, map.getCenter().lat];
  let best = null, bd = 1e18;
  for(const s of ASOS_STN){ const d = (s[2] - c[1]) ** 2 + ((s[3] - c[0]) * Math.cos(c[1] * Math.PI / 180)) ** 2; if(d < bd){ bd = d; best = s; } }
  return best;
}
(function fillStations(){
  const sel = $('windstn');
  sel.innerHTML = '<option value="auto">가장 가까운 관측소</option>' + ASOS_STN.map(s => `<option value="${s[0]}">${s[1]} (${s[0]})</option>`).join('');
})();
const emptyHist = () => ({ c:Array.from({ length:4 }, () => Array.from({ length:16 }, () => new Array(5).fill(0))), calm:[0, 0, 0, 0], n:[0, 0, 0, 0], ws:[0, 0, 0, 0] });

/* 한 달치 → 집계 (월마다 저장해 두고, 끊겨도 다음에 이어서) */
async function windMonth(stn, y, m){
  const key = `asos:${stn}:${y}${String(m).padStart(2, '0')}`;
  try{ const v = JSON.parse(localStorage.getItem(key) || 'null'); if(v) return v; }catch(e){}
  const last = new Date(y, m, 0).getDate(), ym = `${y}${String(m).padStart(2, '0')}`;
  const r = await dataGo(ASOS, { dataCd:'ASOS', dateCd:'HR', startDt:ym + '01', startHh:'00', endDt:ym + String(last).padStart(2, '0'), endHh:'23', stnIds:String(stn), numOfRows:'999', pageNo:'1', dataType:'JSON' });
  if(!r.ok){ const e = new Error(r.msg); e.code = r.code; throw e; }
  const h = { s:SEASON(m), c:Array.from({ length:16 }, () => new Array(5).fill(0)), calm:0, n:0, ws:0 };
  for(const it of r.items){
    const ws = parseFloat(it.ws), wd = parseFloat(it.wd);
    if(!isFinite(ws)) continue;
    h.n++; h.ws += ws;
    if(ws < SPD[0] || !isFinite(wd) || wd === 0 && ws < 0.5){ h.calm++; continue; }
    const d = Math.round(wd / 22.5) % 16, k = ws >= SPD[4] ? 4 : ws >= SPD[3] ? 3 : ws >= SPD[2] ? 2 : ws >= SPD[1] ? 1 : 0;
    h.c[d][k]++;
  }
  if(h.n) try{ localStorage.setItem(key, JSON.stringify(h)); }catch(e){}
  return h;
}
async function runWind(){
  if(!hasRef()){ $('windsum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(WIND.busy) return;
  WIND.busy = true; $('windrun').disabled = true;
  try{
    const sv = $('windstn').value, stn = sv === 'auto' ? nearestStation() : ASOS_STN.find(s => String(s[0]) === sv);
    const years = +$('windyears').value || 5, now = new Date(), y1 = now.getFullYear() - 1, y0 = y1 - years + 1;
    const H = emptyHist(); let done = 0, total = years * 12;
    for(let y = y0; y <= y1; y++) for(let m = 1; m <= 12; m++){
      $('windsum').textContent = `${stn[1]} 관측소 ${y}년 ${m}월 받는 중 (${++done}/${total})`;
      const h = await windMonth(stn[0], y, m);
      for(let d = 0; d < 16; d++) for(let k = 0; k < 5; k++) H.c[h.s][d][k] += h.c[d][k];
      H.calm[h.s] += h.calm; H.n[h.s] += h.n; H.ws[h.s] += h.ws;
    }
    WIND.stats = { stn, y0, y1, H };
    registerWindLayers(); apply(); summarizeWind();
  }catch(err){
    $('windsum').textContent = (['unreg', 'denied', 'key'].includes(err.code) ? '기상청 ASOS 시간자료 API 활용신청이 필요합니다 (공공데이터포털 "기상청_지상(종관, ASOS) 시간자료 조회서비스") — ' : '실패 — ') + err.message;
  }
  WIND.busy = false; $('windrun').disabled = false;
}
/* 계절(또는 전체)의 방위·풍속 비율 */
function windFreq(seasons){
  const c = Array.from({ length:16 }, () => new Array(5).fill(0)); let n = 0, calm = 0, ws = 0;
  for(const s of seasons){ for(let d = 0; d < 16; d++) for(let k = 0; k < 5; k++) c[d][k] += WIND.stats.H.c[s][d][k]; n += WIND.stats.H.n[s]; calm += WIND.stats.H.calm[s]; ws += WIND.stats.H.ws[s]; }
  const f = c.map(row => row.map(v => n ? v / n : 0)), dirTot = f.map(row => row.reduce((a, b) => a + b, 0));
  const top = dirTot.indexOf(Math.max(...dirTot));
  return { f, dirTot, top, calm:n ? calm / n : 0, mean:n ? ws / n : 0, n };
}

/* ---------- 그리기 ---------- */
function roseFeatures(cx, cy, R, fr, tag){
  // 가장 긴 꽃잎이 R 이 되도록 — 눈금은 5% 단위
  const mx = Math.max(0.05, ...fr.dirTot), scale = R / mx, ramp = rampFrom(ST().wind || ST().bus, 5);
  const bins = [[], [], [], [], []], half = 22.5 * 0.42 * Math.PI / 180;
  for(let d = 0; d < 16; d++){
    let r0 = R * 0.08, acc = 0;
    const th = d * 22.5 * Math.PI / 180;
    for(let k = 0; k < 5; k++){
      if(!fr.f[d][k]) continue;
      acc += fr.f[d][k]; const r1 = R * 0.08 + acc * scale * 0.92;
      const ring = [];
      for(let i = 0; i <= 6; i++){ const t = th - half + 2 * half * i / 6; ring.push([cx + Math.sin(t) * r1, cy + Math.cos(t) * r1]); }
      for(let i = 6; i >= 0; i--){ const t = th - half + 2 * half * i / 6; ring.push([cx + Math.sin(t) * r0, cy + Math.cos(t) * r0]); }
      ring.push(ring[0]);
      bins[k].push([ring.map(toLL)]);
      r0 = r1;
    }
  }
  bins.forEach((polys, k) => {
    if(!polys.length) return;
    extraSet(`wind-${tag}-${k}`, { label:`분석_바람장미_${k + 1}_${SPD_NAME[k]} m/s` + (tag === 'all' || tag === 's0' ? '' : '_세부'), stage:'top', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:polys } }] },
      paint:{ 'fill-color':ramp[k], 'fill-opacity':0.92 }, svg:{ kind:'fill', fill:ramp[k], opacity:0.92 } });
  });
  // 눈금 고리 (5% 마다) + 십자선
  const rings = [];
  for(let p = 0.05; p <= mx + 1e-9; p += 0.05){ const r = R * 0.08 + p * scale * 0.92; rings.push(circleM(r, 72)[0][0].map(([x, y]) => toLL([cx + x, cy + y]))); }
  const cross = [[[cx, cy - R * 1.05], [cx, cy + R * 1.12]], [[cx - R * 1.05, cy], [cx + R * 1.05, cy]]].map(l => l.map(toLL));
  extraSet(`wind-${tag}-grid`, { label:'분석_바람장미눈금_5% 간격_세부', stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:[...rings, ...cross] } }] },
    paint:{ 'line-color':hexMix(ST().paper, ST().ink, 0.45), 'line-width':0.6, 'line-dasharray':[2, 2] }, svg:{ kind:'line', stroke:hexMix(ST().paper, ST().ink, 0.45), width:0.5, dash:[2, 2] } });
  const q = R * 1.16;
  return { labelAt:toLL([cx, cy - R * 1.48]), compass:[['N', 0, q], ['E', q, 0], ['S', 0, -q], ['W', -q, 0]].map(([t, x, y]) => ({ t, ll:toLL([cx + x, cy + y]) })) };
}
function windArrows(fr, col, tag, name, shift){
  // 주풍향의 바람이 불어 가는 방향으로 범위 전체에 평행한 화살표 — 길이는 평균 풍속에 비례
  const FR = focusR(), from = fr.top * 22.5 * Math.PI / 180, to = [ -Math.sin(from), -Math.cos(from) ];
  const nrm = [-to[1], to[0]], sp = FR / 2.8, L = FR * 0.2 * Math.min(1.8, Math.max(0.6, fr.mean / 2.5));
  const lines = [], heads = [];
  for(let i = -3; i <= 3; i++) for(let j = -3; j <= 3; j++){
    const off = (j % 2 ? 0.5 : 0) + (shift || 0);
    const cx = nrm[0] * (i + off) * sp + to[0] * j * sp, cy = nrm[1] * (i + off) * sp + to[1] * j * sp;
    const a = [cx - to[0] * L / 2, cy - to[1] * L / 2], b = [cx + to[0] * L / 2, cy + to[1] * L / 2];
    if(!inFocus(a) || !inFocus(b)) continue;
    lines.push([a, b].map(toLL));
    const hw = L * 0.16, hl = L * 0.28;
    heads.push([[b, [b[0] - to[0] * hl + nrm[0] * hw, b[1] - to[1] * hl + nrm[1] * hw], [b[0] - to[0] * hl - nrm[0] * hw, b[1] - to[1] * hl - nrm[1] * hw], b].map(toLL)]);
  }
  extraSet(`wind-${tag}-line`, { label:`분석_바람길_${name} ${DIR16[fr.top]}풍 평균 ${fr.mean.toFixed(1)}m/s`, stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:lines } }] },
    layout:{ 'line-cap':'round' }, paint:{ 'line-color':col, 'line-width':2.2, 'line-opacity':0.85 }, svg:{ kind:'line', stroke:col, width:1.8, opacity:0.85 } });
  extraSet(`wind-${tag}-head`, { label:`분석_바람길_${name}화살촉_세부`, stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:heads } }] },
    paint:{ 'fill-color':col, 'fill-opacity':0.9 }, svg:{ kind:'fill', fill:col, opacity:0.9 } });
}
function registerWindLayers(){
  extraRemove('wind-');
  if(!WIND.on || !WIND.stats || !hasRef()) return;
  const FR = focusR(), labels = [], comp = [], [ox, oy] = WIND.off;
  const addCompass = o => { for(const c of o.compass) comp.push({ type:'Feature', properties:{ label:c.t }, geometry:{ type:'Point', coordinates:c.ll } }); };
  if(WIND.form === 'rose'){
    const fr = windFreq([0, 1, 2, 3]), o = roseFeatures(ox, oy, FR * 0.42, fr, 'all');
    labels.push({ type:'Feature', properties:{ label:`연간 · 주풍향 ${DIR16[fr.top]} · 무풍 ${Math.round(fr.calm * 100)}%` }, geometry:{ type:'Point', coordinates:o.labelAt } });
    addCompass(o);
  }else if(WIND.form === 'seasons'){
    const pos = [[-0.3, 0.34], [0.3, 0.34], [-0.3, -0.34], [0.3, -0.34]];   // 네 개를 한 묶음으로
    for(let s = 0; s < 4; s++){
      const fr = windFreq([s]), o = roseFeatures(ox + pos[s][0] * FR, oy + pos[s][1] * FR, FR * 0.17, fr, 's' + s);
      labels.push({ type:'Feature', properties:{ label:`${SEASON_NAME[s]} · ${DIR16[fr.top]} ${fr.mean.toFixed(1)}m/s` }, geometry:{ type:'Point', coordinates:o.labelAt } });
      addCompass(o);
    }
  }else{
    windArrows(windFreq([1]), ST().windSummer || ST().work, 'summer', '여름', 0);
    windArrows(windFreq([3]), ST().wind, 'winter', '겨울', 0.25);
  }
  if(labels.length) extraSet('wind-label', { label:'분석_바람_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:labels },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':11, 'text-allow-overlap':true },
    paint:{ 'text-color':ST().ink, 'text-halo-color':ST().paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:ST().ink, size:9 } });
  if(comp.length && WIND.compass) extraSet('wind-compass', { label:'분석_바람_방위', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:comp },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10, 'text-allow-overlap':true },
    paint:{ 'text-color':hexMix(ST().paper, ST().ink, 0.7), 'text-halo-color':ST().paper, 'text-halo-width':1.4 }, svg:{ kind:'text', fill:hexMix(ST().paper, ST().ink, 0.7), size:8 } });
}
function summarizeWind(){
  if(!WIND.stats) return;
  const W = WIND.stats, a = windFreq([0, 1, 2, 3]), su = windFreq([1]), wi = windFreq([3]);
  $('windsum').textContent = `${W.stn[1]}(${W.stn[0]}) ${W.y0}–${W.y1} · 연간 주풍향 ${DIR16[a.top]} · 평균 ${a.mean.toFixed(1)}m/s · 무풍 ${Math.round(a.calm * 100)}% · 여름 ${DIR16[su.top]} · 겨울 ${DIR16[wi.top]}`;
}
function windSummary(){
  if(!WIND.on || !WIND.stats) return null;
  const W = WIND.stats, s = i => { const f = windFreq([i]); return { prevailing:DIR16[f.top], share_pct:Math.round(f.dirTot[f.top] * 100), mean_ms:+f.mean.toFixed(1), calm_pct:Math.round(f.calm * 100) }; };
  return { source:'기상청 지상(종관, ASOS) 시간자료', station:`${W.stn[1]} (${W.stn[0]})`, years:`${W.y0}–${W.y1}`,
    station_distance_km: SITE.center ? +(Math.hypot((W.stn[3] - SITE.center[0]) * 111320 * Math.cos(SITE.center[1] * Math.PI / 180), (W.stn[2] - SITE.center[1]) * 110540) / 1000).toFixed(1) : null,
    annual:(() => { const f = windFreq([0, 1, 2, 3]); return { prevailing:DIR16[f.top], mean_ms:+f.mean.toFixed(1), calm_pct:Math.round(f.calm * 100) }; })(),
    spring:s(0), summer:s(1), autumn:s(2), winter:s(3),
    note:'관측소 값이라 대지 주변 건물·지형에 따른 국지풍은 반영되지 않습니다. 풍향은 바람이 불어오는 방향입니다.' };
}
$('windon').addEventListener('change', e => {
  WIND.on = e.target.checked; $('windopts').hidden = !WIND.on; $('card-wind').classList.toggle('on', WIND.on);
  if(WIND.on && !WIND.stats) runWind(); else { registerWindLayers(); apply(); }
});
$('winddiag').addEventListener('change', e => { WIND.form = e.target.value; registerWindLayers(); apply(); });
$('windrun').addEventListener('click', () => { WIND.stats = null; runWind(); });
$('windstn').addEventListener('change', () => { if(WIND.on){ WIND.stats = null; runWind(); } });
$('windyears').addEventListener('change', () => { if(WIND.on){ WIND.stats = null; runWind(); } });

/* ---------- 방위 표시 · 위치 ---------- */
$('windcompass').addEventListener('change', e => { WIND.compass = e.target.checked; registerWindLayers(); apply(); });
$('windreset').addEventListener('click', () => { WIND.off = [0, 0]; registerWindLayers(); apply(); });

/* ---------- 바람장미를 한 묶음으로 끌어 옮기기 ----------
   바람장미(또는 계절별 네 개) 위를 누르고 끌면 전체가 함께 움직입니다. 바람길(화살표 바탕)은 범위 전체에 깔리므로 옮기지 않습니다. */
(function hookWindDrag(){
  if(typeof map === 'undefined' || !map || !map.on){ setTimeout(hookWindDrag, 400); return; }
  let drag = null;
  const windIds = () => { const st = map.getStyle && map.getStyle(); return st ? st.layers.map(l => l.id).filter(id => /^wind-/.test(id)) : []; };
  const hit = e => {
    if(!WIND.on || !WIND.stats || WIND.form === 'paths' || SITE.mode !== 'site') return false;
    if(typeof DRAFT !== 'undefined' && DRAFT) return false;
    const ids = windIds(); if(!ids.length) return false;
    const pad = 6, b = [[e.point.x - pad, e.point.y - pad], [e.point.x + pad, e.point.y + pad]];
    return map.queryRenderedFeatures(b, { layers:ids }).length > 0;
  };
  const push = () => { for(const [id, d] of EXTRA.layers){ if(!/^wind-/.test(id)) continue; const src = map.getSource('x-' + id); if(src && src.setData) src.setData(d.fc); } };
  map.on('mousedown', e => {
    if(!hit(e)) return;
    e.preventDefault();
    drag = { p0:toM([e.lngLat.lng, e.lngLat.lat]), off0:WIND.off.slice() };
    map.dragPan.disable(); map.getCanvas().style.cursor = 'grabbing';
  });
  map.on('mousemove', e => {
    if(!drag){ if(WIND.on && WIND.form !== 'paths') map.getCanvas().style.cursor = hit(e) ? 'move' : ''; return; }
    const p = toM([e.lngLat.lng, e.lngLat.lat]);
    WIND.off = [drag.off0[0] + p[0] - drag.p0[0], drag.off0[1] + p[1] - drag.p0[1]];
    registerWindLayers(); push();                                      // 끄는 동안은 자료만 바꿔 끼워 부드럽게
  });
  const end = () => { if(!drag) return; drag = null; map.dragPan.enable(); map.getCanvas().style.cursor = ''; apply(); };
  map.on('mouseup', end);
  const cv = map.getCanvas && map.getCanvas(); if(cv && cv.addEventListener) cv.addEventListener('mouseleave', end);
})();
