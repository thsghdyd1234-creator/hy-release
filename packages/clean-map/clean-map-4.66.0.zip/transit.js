/* ============================================================
   대중교통(버스) — traffic.js 다음에 읽힙니다.
   국토교통부 TAGO 버스정류소정보: 좌표기반 근접정류소 · 정류소별 경유노선
   ============================================================ */

/* 공공데이터포털 사용자 인증키 — 계정 하나의 키로 신청한 모든 API를 부릅니다.
   파일을 여는 사람은 볼 수 있으니 외부로 퍼지면 포털에서 재발급하세요. */
const DATA_GO_DEFAULT_KEY = '8facf77a87cbcc7a012058fb43709f98c145e4d8106fa3ed5e824179d17373cd';
function dataGoKey(){
  try{ return localStorage.getItem('cleanmapDataKey') || DATA_GO_DEFAULT_KEY; }catch(e){ return DATA_GO_DEFAULT_KEY; }
}
const TAGO_STTN = 'apis.data.go.kr/1613000/BusSttnInfoInqireService';

/* ---------- 공공데이터포털 공통 호출 ---------- */
/* 응답이 JSON 이든 XML 오류든 한 가지 모양으로 돌려줍니다: {ok, code, msg, items, raw} */
const DG_CODES = { '30':['key', '키가 아직 등록되지 않았습니다 — 승인 직후라면 1~2시간 뒤 다시 시도하세요'],
                   '20':['denied', '이 API는 활용신청이 되어 있지 않습니다'],
                   '22':['limit', '오늘 호출 한도를 넘었습니다'],
                   '31':['expired', '활용기간이 만료됐습니다'],
                   '32':['ip', '등록되지 않은 IP입니다'] };
const DG_TEXT = [[/SERVICE_KEY_IS_NOT_REGISTERED/, '30'], [/SERVICE_ACCESS_DENIED|SERVICE ACCESS DENIED/, '20'],
                 [/LIMITED_NUMBER_OF_SERVICE_REQUESTS/, '22'], [/DEADLINE_HAS_EXPIRED/, '31'], [/UNREGISTERED_IP/, '32']];
function dgError(code, msg, raw){
  let c = String(code || '').replace(/^0+(?=\d{2})/, '');
  for(const [re, k] of DG_TEXT) if(re.test(msg || '')) c = k;
  const hit = DG_CODES[c];
  return { ok:false, code: hit ? hit[0] : (c || 'error'), msg: hit ? hit[1] : ((msg || '오류') + (c ? ' (' + c + ')' : '')), items:[], raw };
}
/* TAGO 는 서버 동시 접속(세션) 한도가 있어 "가용한 세션이 없습니다(99)" 가 가끔 옵니다.
   호출 사이에 간격을 두고, 99 가 오면 잠시 쉬었다가 다시 부릅니다. */
let DG_LAST = 0;
async function dataGo(path, params){
  for(let attempt = 0; attempt < 4; attempt++){
    const wait = DG_LAST + 150 - Date.now();
    if(wait > 0) await new Promise(r => setTimeout(r, wait));
    DG_LAST = Date.now();
    const r = await dataGoOnce(path, params);
    if(r.code !== 'busy') return r;
    if(attempt < 3) await new Promise(r2 => setTimeout(r2, 1500 * (attempt + 1)));
    else return { ...r, msg:'공공데이터 서버가 혼잡합니다 (동시 접속 한도) — 1~2분 뒤 다시 시도하세요' };
  }
}
async function dataGoOnce(path, params){
  const qs = new URLSearchParams({ serviceKey:dataGoKey(), _type:'json', ...params }).toString();
  let res, text, lastErr;
  for(const scheme of ['https://', 'http://']){                       // https 가 막히면 http 로 한 번 더
    try{ res = await fetch(scheme + path + '?' + qs); text = await res.text(); break; }
    catch(e){ lastErr = e; }
  }
  if(text == null) return { ok:false, code:'network', msg:'연결 실패 — ' + (lastErr && lastErr.message), items:[], raw:'' };
  const raw = text.length > 520 ? text.slice(0, 220) + '  …  ' + text.slice(-280) : text;
  const rawFull = text.slice(0, 1500);
  if(/^\s*</.test(text)){                                             // XML 로 온 오류
    const m = text.match(/<(returnAuthMsg|resultMsg|errMsg)>([^<]*)</);
    const code = (text.match(/<(returnReasonCode|resultCode)>([^<]*)</) || [])[2] || '';
    if(code === '00' || code === '0000' || code === '03'){                                // JSON 을 요청했는데 XML 로 온 정상 응답 — 항목을 직접 읽습니다
      const items = [...text.matchAll(/<item>([\s\S]*?)<\/item>/g)].map(m => {
        const obj = {}; for(const f of m[1].matchAll(/<(\w+)>([^<]*)<\/\1>/g)) obj[f[1]] = f[2]; return obj; });
      const total = +((text.match(/<totalCount>(\d+)</) || [])[1] || items.length);
      return { ok:true, code:'00', msg:'정상', items, total, raw, xml:true };
    }
    return dgError(code, (m && m[2]) || 'XML 응답', raw);
  }
  let js; try{ js = JSON.parse(text); }catch(e){ return { ok:false, code:'parse', msg:'응답을 읽지 못했습니다 (HTTP ' + res.status + ')', items:[], raw }; }
  if(js && (js.status === 401 || js.error === 'Unauthorized' || /등록되지 않은 서비스키|유효하지 않은 서비스키/.test(js.message || '')))
    return { ok:false, code:'unreg', msg:'이 API에 키가 등록되지 않았습니다 — 활용신청을 했는지 확인하세요 (신청 직후면 1~2시간 뒤)', items:[], raw };
  if(js && js.status && js.status >= 400) return { ok:false, code:'http' + js.status, msg:(js.message || js.error || 'HTTP ' + js.status), items:[], raw };
  if(js && js.OpenAPI_ServiceResponse){                               // 게이트웨이 오류가 JSON 으로 온 경우
    const h = js.OpenAPI_ServiceResponse.cmmMsgHeader || {};
    if(String(h.returnReasonCode) === '04') return { ok:false, code:'param', msg:'제공기관 서버가 요청을 거절했습니다 — 필수 요청값이 빠졌거나 형식이 다릅니다', items:[], raw };
    return dgError(h.returnReasonCode, h.returnAuthMsg || h.errMsg, raw);
  }
  const root = js.response || js;
  const head = root.header || {};
  if(head.resultCode === '03') return { ok:true, code:'00', msg:'정상', items:[], total:0, raw };   // NODATA
  if(String(head.resultCode) === '99' && /세션/.test(head.resultMsg || '')) return { ok:false, code:'busy', msg:head.resultMsg, items:[], raw };
  if(head.resultCode != null && !['00', '0000', '0', 0].includes(head.resultCode)) return dgError(head.resultCode, head.resultMsg, raw);   // 관광공사는 0000
  const body = root.body || {};
  let it = body.items; if(it && !Array.isArray(it)) it = it.item;
  if(!it){                                                             // 제공기관마다 목록 위치가 달라서 첫 배열을 찾습니다
    for(const k of ['item', 'data', 'list', 'rows']) if(Array.isArray(body[k]) || Array.isArray(root[k])){ it = body[k] || root[k]; break; }
    if(!it) for(const v of Object.values(body)) if(Array.isArray(v)){ it = v; break; }
    if(!it) for(const v of Object.values(root)) if(Array.isArray(v)){ it = v; break; }
  }
  let items = !it ? [] : Array.isArray(it) ? it : [it];
  // 열 이름(header.columns)과 값 배열로 온 경우 — 객체로 묶습니다
  const cols = head.columns || body.columns;
  if(items.length && Array.isArray(items[0]) && Array.isArray(cols)) items = items.map(row => Object.fromEntries(cols.map((c, i) => [c, row[i]])));
  return { ok:true, code:'00', msg:'정상', items, total:+(body.totalCount ?? root.totalCount ?? head.totalCount ?? root.total_count ?? (root.traffic ? root.count : undefined)) || items.length, raw, rawFull };
}

/* ---------- 정류장별 경유노선 캐시 (30일) ---------- */
function routeCacheGet(city, node){
  try{ const v = JSON.parse(localStorage.getItem('tagoRoutes:' + city + ':' + node) || 'null');
       if(v && Date.now() - v.t < 30 * 864e5) return v.r; }catch(e){}
  return null;
}
function routeCacheSet(city, node, r){ try{ localStorage.setItem('tagoRoutes:' + city + ':' + node, JSON.stringify({ t:Date.now(), r })); }catch(e){} }

const BUS = { on:false, busy:false, stops:null, err:null, form:'stop' };

$('buson').addEventListener('change', e => {
  BUS.on = e.target.checked;
  $('busopts').hidden = !BUS.on;
  $('card-bus').classList.toggle('on', BUS.on);
  if(BUS.on && hasRef() && !BUS.stops) runBus(); else { registerBusLayers(); apply(); }
});
$('busrun').addEventListener('click', () => { BUS.stops = null; runBus(); });
$('busform').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; BUS.form = b.dataset.v; segSync('busform', BUS.form); $('buscatchbox').hidden = BUS.form !== 'catch'; registerBusLayers(); apply(); });
$('buscatch').addEventListener('change', () => { registerBusLayers(); apply(); });
segSync('busform', BUS.form);

function busOnSiteChange(){ BUS.stops = null; BUS.wide = null; extraRemove('bus-'); if(BUS.on && hasRef() && SITE.mode === 'site') runBus(); }

/* 분석 원을 덮도록 조회 지점을 깝니다 (근접조회는 한 번에 최대 약 500m) */
function queryPoints(R){
  if(R <= 450) return [[0, 0]];
  const pts = [], s = 650;
  for(let y = -R; y <= R + 1; y += s * 0.866){
    const row = Math.round(y / (s * 0.866));
    for(let x = -R + (row % 2 ? s / 2 : 0); x <= R + 1; x += s)
      if(Math.hypot(x, y) <= R + 250) pts.push([x, y]);
  }
  return pts;
}

/* ---------- 정류장 출처 1: TAGO (서울 등 일부 지역은 제공하지 않습니다) ---------- */
async function tagoStops(FR){
  const qp = queryPoints(FR), found = new Map();
  for(let i = 0; i < qp.length; i++){
    $('bussum').textContent = `정류장 찾는 중 (TAGO) ${i + 1}/${qp.length}`;
    const [lng, lat] = toLL(qp[i]);
    const r = await dataGo(TAGO_STTN + '/getCrdntPrxmtSttnList',
      { gpsLati:lat.toFixed(6), gpsLong:lng.toFixed(6), numOfRows:'300', pageNo:'1' });
    if(!r.ok) throw Object.assign(new Error(r.msg), { code:r.code });
    for(const s of r.items){
      const la = +s.gpslati, lo = +s.gpslong;
      if(!isFinite(la) || !isFinite(lo)) continue;
      const m = toM([lo, la]);
      if(!inFocus(m)) continue;
      found.set(s.nodeid, { id:s.nodeid, name:s.nodenm, no:s.nodeno, city:String(s.citycode), ll:[lo, la], m, routes:null });
    }
  }
  const stops = [...found.values()];
  for(let i = 0; i < stops.length; i++){
    const s = stops[i];
    $('bussum').textContent = `노선 확인 중 ${i + 1}/${stops.length}`;
    let r = routeCacheGet(s.city, s.id);
    if(!r){
      const q = await dataGo(TAGO_STTN + '/getSttnThrghRouteList',
        { cityCode:s.city, nodeid:s.id, nodeId:s.id, numOfRows:'200', pageNo:'1' });
      if(q.ok){ r = q.items.map(x => ({ id:x.routeid, no:String(x.routeno), type:x.routetp || '' })); routeCacheSet(s.city, s.id, r); }
      else if(q.code === 'denied'){ BUS.routeErr = '정류소별 경유노선 조회가 막혀 있습니다 — ' + q.msg; }
    }
    s.routes = r;
  }
  return stops;
}

/* ---------- 정류장 출처 2: 서울특별시 정류소정보조회 (공공데이터포털 같은 키, 별도 활용신청 필요) ---------- */
const inSeoul = ([lng, lat]) => lat > 37.41 && lat < 37.72 && lng > 126.76 && lng < 127.19;
async function seoulCall(op, params){
  const qs = new URLSearchParams({ serviceKey:dataGoKey(), resultType:'json', ...params }).toString();
  let text, lastErr;
  for(const scheme of ['https://', 'http://']){
    try{ const res = await fetch(scheme + 'ws.bus.go.kr/api/rest/' + op + '?' + qs); text = await res.text(); break; }
    catch(e){ lastErr = e; }
  }
  if(text == null) return { ok:false, msg:'연결 실패 — ' + (lastErr && lastErr.message), items:[], raw:'' };
  const raw = text.slice(0, 300);
  // 게이트웨이 인증 오류 (comMsgHeader) — 키 미등록·미신청이 여기로 옵니다
  const auth = (text.match(/returnAuthMsg["'>:\s]*([A-Z_]+)/) || [])[1], reason = (text.match(/returnReasonCode["'>:\s]*"?(\d+)/) || [])[1];
  if(auth && auth !== 'NORMAL_SERVICE' && reason && reason !== '00'){
    const e = dgError(reason, auth, raw);
    if(e.code === 'denied' || e.code === 'key') e.msg = e.code === 'key'
      ? '키가 아직 서울 버스 API에 등록되지 않았습니다 — 활용신청 직후라면 1~2시간 기다리세요'
      : '서울 버스 API 활용신청이 필요합니다 (공공데이터포털 "서울특별시_정류소정보조회 서비스")';
    return { ok:false, msg:e.msg, items:[], raw };
  }
  if(/^\s*</.test(text)){
    const cd = (text.match(/<headerCd>([^<]*)</) || [])[1], msg = (text.match(/<headerMsg>([^<]*)</) || [])[1] || '';
    const items = [...text.matchAll(/<itemList>([\s\S]*?)<\/itemList>/g)].map(m => {
      const o = {}; for(const f of m[1].matchAll(/<(\w+)>([^<]*)<\/\1>/g)) o[f[1]] = f[2]; return o; });
    if(cd === '0' || cd === '4') return { ok:true, items };
    return { ok:false, msg:seoulMsg(cd, msg), items:[], raw };
  }
  let js; try{ js = JSON.parse(text); }catch(e){ return { ok:false, msg:'응답을 읽지 못했습니다', items:[], raw }; }
  if(js && (js.status === 401 || js.error === 'Unauthorized')) return { ok:false, msg:'서울 버스 API 활용신청이 필요합니다 (공공데이터포털 "서울특별시_정류소정보조회 서비스") — 신청 직후면 1~2시간 뒤', items:[], raw };
  const root = js.ServiceResult || js;
  const h = root.msgHeader || {}, cd = String(h.headerCd ?? '');
  if(cd !== '0' && cd !== '4') return { ok:false, msg:seoulMsg(cd, h.headerMsg), items:[], raw };
  js = root;
  const it = js.msgBody && js.msgBody.itemList;
  return { ok:true, items: !it ? [] : Array.isArray(it) ? it : [it] };
}
const seoulMsg = (cd, msg) => !cd && !msg ? '알 수 없는 응답 — 아래 원문을 확인하세요'
  : /KEY|키|인증|등록/.test(msg || '') || cd === '7' || cd === '30'
  ? '서울 버스 API 활용신청이 필요합니다 (공공데이터포털 "서울특별시_정류소정보조회 서비스")'
  : (msg || '오류') + (cd ? ' (' + cd + ')' : '');
async function seoulStops(FR){
  const [lng, lat] = SITE.center;
  $('bussum').textContent = '정류장 찾는 중 (서울시 버스정보)';
  const r = await seoulCall('stationinfo/getStationByPos', { tmX:lng.toFixed(6), tmY:lat.toFixed(6), radius:String(Math.min(Math.round(FR), 1500)) });
  if(!r.ok) throw new Error(r.msg);
  const stops = [];
  for(const x of r.items){
    const lo = +x.gpsX, la = +x.gpsY; if(!isFinite(lo) || !isFinite(la)) continue;
    const m = toM([lo, la]); if(!inFocus(m)) continue;
    stops.push({ id:x.arsId || x.stationId, name:x.stationNm, no:x.arsId, city:'seoul', ll:[lo, la], m, routes:null });
  }
  for(let i = 0; i < stops.length; i++){
    const s = stops[i];
    $('bussum').textContent = `노선 확인 중 ${i + 1}/${stops.length}`;
    let rt = routeCacheGet('seoul', s.id);
    if(!rt && s.no){
      const q = await seoulCall('stationinfo/getRouteByStation', { arsId:s.no });
      if(q.ok){ rt = q.items.map(x => ({ id:x.busRouteId, no:String(x.busRouteNm || x.busRouteAbrv || ''), type:SEOUL_TYPE[x.busRouteType] || '' })); routeCacheSet('seoul', s.id, rt); }
    }
    s.routes = rt;
  }
  return stops;
}
const SEOUL_TYPE = { '1':'공항', '2':'마을', '3':'간선', '4':'지선', '5':'순환', '6':'광역', '7':'인천', '8':'경기', '9':'폐지', '0':'공용' };

/* ---------- 정류장 출처 3: OSM (키 없음, 노선은 OSM에 등록된 버스 노선 관계 기준) ---------- */
async function osmStops(FR){
  const [lng, lat] = SITE.center;
  $('bussum').textContent = '정류장 찾는 중 (OSM)';
  const q = `[out:json][timeout:40];node["highway"="bus_stop"](around:${Math.round(FR)},${lat.toFixed(6)},${lng.toFixed(6)})->.s;.s out;rel(bn.s)["route"="bus"];out body;`;
  let js, lastErr;
  for(const url of OVERPASS){
    try{ const res = await fetch(url, { method:'POST', body:'data=' + encodeURIComponent(q), headers:{'Content-Type':'application/x-www-form-urlencoded'} });
         if(!res.ok) throw new Error('HTTP ' + res.status); js = await res.json(); break; }
    catch(e){ lastErr = e; }
  }
  if(!js) throw new Error('OSM 정류장을 받지 못했습니다 — ' + (lastErr && lastErr.message));
  const rels = js.elements.filter(e => e.type === 'relation');
  const byNode = new Map();
  for(const r of rels) for(const m of (r.members || [])) if(m.type === 'node'){
    if(!byNode.has(m.ref)) byNode.set(m.ref, new Map());
    byNode.get(m.ref).set(r.id, { id:'osm' + r.id, no:(r.tags && (r.tags.ref || r.tags.name)) || '', type:'' });
  }
  return js.elements.filter(e => e.type === 'node').map(n => {
    const m = toM([n.lon, n.lat]);
    const rt = byNode.get(n.id);
    return { id:'osm' + n.id, name:(n.tags && n.tags.name) || '(이름 없음)', city:'osm', ll:[n.lon, n.lat], m, routes: rt ? [...rt.values()] : [] };
  }).filter(s => inFocus(s.m));
}


/* ============================================================
   광역 방식 — 범위가 2km를 넘으면 정류장 하나하나 대신 "버스 노선 축"을 그립니다.
   표본 지점의 정류장에서 지나는 노선을 모으고, 노선마다 정류장 순서를 받아
   정류장-정류장 구간별로 몇 개 노선이 지나는지 셉니다.
   ============================================================ */
const TAGO_ROUTE = 'apis.data.go.kr/1613000/BusRouteInfoInqireService';
function cacheGet(key, days){ try{ const v = JSON.parse(localStorage.getItem(key) || 'null'); if(v && Date.now() - v.t < days * 864e5) return v.r; }catch(e){} return null; }
function cacheSet(key, r){ try{ localStorage.setItem(key, JSON.stringify({ t:Date.now(), r })); }catch(e){} }

async function runBusWide(){
  const FR = focusR();
  const sp = Math.max(1200, FR / 3.5);
  const pts = [];
  for(let y = -FR; y <= FR; y += sp) for(let x = -FR; x <= FR; x += sp) if(inFocus([x, y])) pts.push([x, y]);
  if(inFocus([0, 0]) && !pts.some(p => Math.hypot(p[0], p[1]) < sp / 2)) pts.unshift([0, 0]);
  const routes = new Map(), hubs = new Map();
  // 1-a) 도시 코드 알아내기 — 가까운 표본부터 정류장이 나올 때까지
  const cities = new Set();
  const order = pts.slice().sort((a, b) => Math.hypot(a[0], a[1]) - Math.hypot(b[0], b[1]));
  for(let i = 0; i < Math.min(order.length, 20) && cities.size === 0; i++){
    $('bussum').textContent = `도시 확인 중 ${i + 1}`;
    const [lng, lat] = toLL(order[i]);
    const r = await dataGo(TAGO_STTN + '/getCrdntPrxmtSttnList', { gpsLati:lat.toFixed(6), gpsLong:lng.toFixed(6), numOfRows:'10', pageNo:'1' });
    if(!r.ok){ if(['key', 'denied', 'unreg'].includes(r.code)) throw new Error(r.msg); continue; }
    for(const x of r.items) if(x.citycode) cities.add(String(x.citycode));
  }
  // 1-b) 그 도시의 노선 전체 — 표본에 기대지 않아 빠지는 노선이 없습니다
  let cityWide = false;
  for(const city of cities){
    const ck = 'tagoCityRoutes:' + city;
    let list = cacheGet(ck, 30);
    if(!list){
      list = [];
      for(let page = 1; page <= 10; page++){
        $('bussum').textContent = `도시 노선 목록 받는 중 (${page}쪽)`;
        const q = await dataGo(TAGO_ROUTE + '/getRouteNoList', { cityCode:city, numOfRows:'500', pageNo:String(page) });
        if(!q.ok){ list = null; if(['denied', 'unreg'].includes(q.code)) BUS.routeErr = '도시 노선 목록 조회가 막혀 있습니다 — ' + q.msg; break; }
        list.push(...q.items.map(x => ({ id:x.routeid, no:String(x.routeno), type:x.routetp || '' })));
        if(q.items.length < 500 || list.length >= (q.total || 0)) break;
      }
      if(list && list.length) cacheSet(ck, list);
    }
    if(list && list.length){ cityWide = true; for(const x of list) if(!routes.has(x.id)) routes.set(x.id, { ...x, city }); }
  }
  // 1-c) 도시 전체 목록이 안 되면 표본 지점 방식으로
  if(!cityWide) for(let i = 0; i < pts.length; i++){
    $('bussum').textContent = `노선 찾는 중 (표본 ${i + 1}/${pts.length})`;
    const [lng, lat] = toLL(pts[i]);
    const nk = 'tagoNear:' + lat.toFixed(4) + ',' + lng.toFixed(4);
    let r = cacheGet(nk, 7) ? { ok:true, items:cacheGet(nk, 7) } : null;
    if(!r){
      r = await dataGo(TAGO_STTN + '/getCrdntPrxmtSttnList', { gpsLati:lat.toFixed(6), gpsLong:lng.toFixed(6), numOfRows:'50', pageNo:'1' });
      if(!r.ok){ if(['key', 'denied', 'unreg'].includes(r.code)) throw new Error(r.msg); continue; }
      cacheSet(nk, r.items);
    }
    const near = r.items.filter(x => isFinite(+x.gpslati)).map(x => ({ ...x, d:Math.hypot(...(([a, b]) => [a - pts[i][0], b - pts[i][1]])(toM([+x.gpslong, +x.gpslati]))) }))
      .sort((a, b) => a.d - b.d).slice(0, 2);
    for(const st of near){
      const city = String(st.citycode);
      let rt = routeCacheGet(city, st.nodeid);
      if(!rt){
        const q = await dataGo(TAGO_STTN + '/getSttnThrghRouteList', { cityCode:city, nodeid:st.nodeid, nodeId:st.nodeid, numOfRows:'200', pageNo:'1' });
        if(q.ok){ rt = q.items.map(x => ({ id:x.routeid, no:String(x.routeno), type:x.routetp || '' })); routeCacheSet(city, st.nodeid, rt); }
      }
      for(const x of (rt || [])) if(!routes.has(x.id)) routes.set(x.id, { ...x, city });
    }
  }
  if(!routes.size) return { stops:[], segs:[], routes:0, cityWide, noCity: !cities.size };
  // 2) 노선별 정류장 순서
  const segs = new Map(), stopRoutes = new Map();
  let k = 0, failed = 0;
  for(const rt of routes.values()){
    k++; $('bussum').textContent = `노선 경로 받는 중 ${k}/${routes.size}`;
    const key = 'tagoRouteStops:' + rt.city + ':' + rt.id;
    let seq = cacheGet(key, 30);
    if(!seq){
      const q = await dataGo(TAGO_ROUTE + '/getRouteAcctoThrghSttnList', { cityCode:rt.city, routeId:rt.id, numOfRows:'1000', pageNo:'1' });
      if(!q.ok){ failed++; if(['denied', 'unreg'].includes(q.code)) BUS.routeErr = '노선별 경유정류소 조회가 막혀 있습니다 — ' + q.msg + ' (TAGO 버스노선정보)'; continue; }
      seq = q.items.filter(x => isFinite(+x.gpslati)).sort((a, b) => (+a.nodeord) - (+b.nodeord))
        .map(x => [x.nodeid, +x.gpslong, +x.gpslati, x.nodenm]);
      cacheSet(key, seq);
    }
    for(let i = 1; i < seq.length; i++){
      const a = seq[i - 1], b = seq[i];
      const pk = a[0] < b[0] ? a[0] + '|' + b[0] : b[0] + '|' + a[0];
      if(!segs.has(pk)) segs.set(pk, { a:[a[1], a[2]], b:[b[1], b[2]], routes:new Set() });
      segs.get(pk).routes.add(rt.id);
    }
    for(const s of seq){
      if(!stopRoutes.has(s[0])) stopRoutes.set(s[0], { id:s[0], name:s[3], ll:[s[1], s[2]], routes:new Set() });
      stopRoutes.get(s[0]).routes.add(rt.id);
    }
  }
  const segList = [...segs.values()].map(g => ({ ...g, n:g.routes.size, pts:[toM(g.a), toM(g.b)] }))
    .filter(g => Math.hypot(g.pts[1][0] - g.pts[0][0], g.pts[1][1] - g.pts[0][1]) < 3000 && (inFocus(g.pts[0]) || inFocus(g.pts[1])));
  const stops = [...stopRoutes.values()].map(s => ({ ...s, m:toM(s.ll), n:s.routes.size })).filter(s => inFocus(s.m));
  const inRange = new Set(); for(const g of segList) for(const id of g.routes) inRange.add(id);
  return { stops, segs:segList, routes:inRange.size, allRoutes:routes.size, failed, samples:pts.length, cityWide };
}

async function runBus(){
  if(!hasRef()){ $('bussum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(BUS.busy) return;
  BUS.busy = true; $('busrun').disabled = true; BUS.routeErr = null; BUS.note = '';
  if(isWide()){
    try{
      const W = await runBusWide();
      BUS.wide = W; BUS.stops = null; BUS.source = 'TAGO (노선 축)';
      registerBusLayers(); apply(); summarizeBus(); if(typeof summarizeBusGap === 'function') summarizeBusGap();
    }catch(err){ BUS.err = err.message; $('bussum').textContent = '실패 — ' + err.message; }
    BUS.busy = false; $('busrun').disabled = false; return;
  }
  BUS.wide = null;
  try{
    const FR = focusR();
    let stops = [], src = 'TAGO', notes = [];
    try{ stops = await tagoStops(FR); }
    catch(e){ notes.push('TAGO: ' + e.message); }
    if(!stops.length && inSeoul(SITE.center)){
      try{ stops = await seoulStops(FR); src = '서울시 버스정보'; }
      catch(e){ notes.push('서울: ' + e.message); }
    }
    if(!stops.length){
      try{ stops = await osmStops(FR); src = 'OSM'; }
      catch(e){ notes.push(e.message); }
    }
    BUS.source = src; BUS.note = notes.join(' · ');
    // 대지에서 가장 가까운 정류장 (대지 경계까지 직선거리)
    const siteM = SITE.geom ? mapRings(SITE.geom, toM) : null;
    const edgeDist = p => {
      if(!siteM) return Math.hypot(p[0], p[1]);                     // 대지가 없으면 화면 중심에서
      if(pointInMulti(p, siteM)) return 0;
      let d = 1e9;
      for(const poly of siteM) for(const ring of poly) for(let i = 1; i < ring.length; i++){
        const a = ring[i - 1], b = ring[i], dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy || 1e-9;
        const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L));
        d = Math.min(d, Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy));
      }
      return d;
    };
    for(const s of stops) s.d = edgeDist(s.m);
    stops.sort((a, b) => a.d - b.d);
    BUS.stops = stops; BUS.err = null;
    registerBusLayers(); apply(); summarizeBus();
  }catch(err){
    BUS.err = err.message;
    $('bussum').textContent = '실패 — ' + err.message;
    setStatus('버스 정보 실패 — ' + esc(err.message), true);
  }
  BUS.busy = false; $('busrun').disabled = false;
}

function busStats(){
  const st = BUS.stops || [];
  const uniq = new Map();
  for(const s of st) for(const r of (s.routes || [])) uniq.set(r.id, r);
  const byType = {};
  for(const r of uniq.values()) byType[r.type || '기타'] = (byType[r.type || '기타'] || 0) + 1;
  return { uniq, byType };
}
function summarizeBus(){
  if(BUS.wide){
    const W = BUS.wide;
    $('bussum').textContent = W.routes ? `범위를 지나는 노선 ${W.routes}개 · 노선 축 구간 ${W.segs.length}개 · 정류장 ${W.stops.length}곳 ` + (W.cityWide ? `(도시 전체 노선 ${W.allRoutes}개 중)` : `(표본 ${W.samples}곳에서 찾은 노선 기준)`)
      + (W.failed ? ` · 경로 못 받은 노선 ${W.failed}개` : '') + (BUS.routeErr ? ' · ' + BUS.routeErr : '')
      : (W.noCity ? '범위 안 표본 지점에서 정류장을 하나도 찾지 못해 도시를 알 수 없습니다 — 범위에 시내가 들어오게 해 주세요' : '범위 안에서 노선을 찾지 못했습니다') + (BUS.routeErr ? ' · ' + BUS.routeErr : '');
    return;
  }
  const st = BUS.stops || [];
  if(!st.length){ $('bussum').textContent = `분석 범위 안에 버스 정류장이 없습니다 (${rangeLabel()})` + (BUS.note ? ' · ' + BUS.note : ''); return; }
  const { uniq } = busStats(), n = st[0];
  $('bussum').textContent = `정류장 ${st.length}곳 · 노선 ${uniq.size}개 · 가장 가까운 정류장 "${n.name}" ${Math.round(n.d)}m`
    + (n.routes ? ` (${n.routes.length}개 노선)` : '') + ` · 출처 ${BUS.source}` + (BUS.source === 'OSM' ? ' (노선 수는 OSM 등록분만)' : '')
    + (BUS.routeErr ? ' · ' + BUS.routeErr : '') + (BUS.note && BUS.source !== 'TAGO' ? ' · ' + BUS.note : '');
}

function registerBusLayers(){
  extraRemove('bus-');
  if(BUS.on && BUS.form === 'gap' && hasRef()){ if(typeof drawBusGap === 'function') drawBusGap(); return; }
  if(BUS.on && BUS.form === 'catch' && hasRef()){
    // 정류장 도보권 — 반투명 원이 겹칠수록 진해집니다
    const stops = BUS.wide ? BUS.wide.stops : (BUS.stops || []);
    if(!stops.length) return;
    const R = +$('buscatch').value || 400, col = ST().bus;
    const ring = s => circleM(R, 48)[0][0].map(([x, y]) => toLL([s.m[0] + x, s.m[1] + y]));
    extraSet('bus-catch', { label:`분석_정류장도보권_${R}m`, stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:stops.map(s => ({ type:'Feature', properties:{}, geometry:{ type:'Polygon', coordinates:[ring(s)] } })) },
      paint:{ 'fill-color':col, 'fill-opacity':ST().catchOpacity * CA() / 0.7 }, svg:{ kind:'fill', fill:col, opacity:ST().catchOpacity * CA() / 0.7 } });
    extraSet('bus-catch-line', { label:'분석_정류장도보권경계', stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:stops.map(s => ({ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:ring(s) } })) },
      paint:{ 'line-color':col, 'line-width':0.6, 'line-opacity':0.5, 'line-dasharray':[3, 2] }, svg:{ kind:'line', stroke:col, width:0.4, dash:[3, 2] } });
    const dots = stops.map(s => [circleM(Math.max(4, R / 40), 12)[0][0].map(([x, y]) => toLL([s.m[0] + x, s.m[1] + y]))]);
    extraSet('bus-catch-dot', { label:'분석_버스정류장', stage:'top', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:dots } }] },
      paint:{ 'fill-color':col, 'fill-opacity':1 }, svg:{ kind:'fill', fill:col, opacity:1 } });
    // 대지가 도보권 안에 드는지
    BUS.catchHit = stops.filter(s => Math.hypot(s.m[0], s.m[1]) <= R).length;
    return;
  }
  if(BUS.on && BUS.wide && hasRef()){
    const col = ST().bus, W = BUS.wide;
    const cls = n => n >= 16 ? 4 : n >= 8 ? 3 : n >= 4 ? 2 : n >= 2 ? 1 : 0;
    const PXW = [0.8, 1.6, 2.8, 4.2, 6], names = ['1개 노선', '2–3개', '4–7개', '8–15개', '16개 이상'];
    const bins = [[], [], [], [], []];
    for(const g of W.segs) bins[cls(g.n)].push(...clipToFocus(g.pts));
    bins.forEach((parts, k) => {
      if(!parts.length) return;
      extraSet('bus-corr-' + k, { label:`분석_버스노선축_${k + 1}_${names[k]}`, stage:'line', type:'line', nomerge:true,
        fc:{ type:'FeatureCollection', features:[lineFeat(parts, { k })] },
        layout:{ 'line-cap':'round', 'line-join':'round' }, paint:{ 'line-color':col, 'line-width':PXW[k], 'line-opacity':0.35 + k * 0.15 },
        svg:{ kind:'line', stroke:col, width:PXW[k] * 0.8 } });
    });
    const hubs = W.stops.slice().sort((a, b) => b.n - a.n).slice(0, 8);
    extraSet('bus-hub-label', { label:'분석_버스거점정류장', stage:'top', type:'symbol', nomerge:true,
      fc:{ type:'FeatureCollection', features:hubs.map(h => ({ type:'Feature', properties:{ label:`${h.name} · ${h.n}개 노선` }, geometry:{ type:'Point', coordinates:h.ll } })) },
      layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10.5, 'text-allow-overlap':false },
      paint:{ 'text-color':ST().busText, 'text-halo-color':ST().paper, 'text-halo-width':1.5 },
      svg:{ kind:'text', fill:ST().busText, size:8.5 } });
    return;
  }
  if(!BUS.on || !BUS.stops || !BUS.stops.length || !hasRef()) return;
  const col = ST().bus;
  const circles = [], labels = [];
  const top = BUS.stops.slice().sort((a, b) => ((b.routes || []).length - (a.routes || []).length));
  const labelled = new Set([BUS.stops[0].id, ...top.slice(0, 4).map(s => s.id)]);
  for(const s of BUS.stops){
    const n = (s.routes || []).length;
    const r = 5 + 2.6 * Math.sqrt(Math.max(n, 1));                       // 노선 수에 비례하는 원 (미터)
    const ring = circleM(r, 24)[0][0].map(([x, y]) => toLL([s.m[0] + x, s.m[1] + y]));
    circles.push({ type:'Feature', properties:{ routes:n }, geometry:{ type:'Polygon', coordinates:[ring] } });
    if(labelled.has(s.id)) labels.push({ type:'Feature', properties:{ label:`${s.name} · ${s.routes ? n + '개 노선' : '노선 미확인'}` },
      geometry:{ type:'Point', coordinates:s.ll } });
  }
  extraSet('bus-stops', { label:'분석_버스정류장', stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:circles },
    paint:{ 'fill-color':col, 'fill-opacity':0.85, 'fill-outline-color':ST().paper },
    svg:{ kind:'fill', fill:col, opacity:0.85 } });
  // 대지 → 가장 가까운 정류장 점선
  const near = BUS.stops[0];
  if(near.d > 0){
    const siteC = [0, 0];
    extraSet('bus-nearest', { label:'분석_최근접정류장', stage:'top', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:[toLL(siteC), near.ll] } }] },
      paint:{ 'line-color':col, 'line-width':1.4, 'line-dasharray':[2, 1.5] },
      svg:{ kind:'line', stroke:col, width:1, dash:[2, 1.5] } });
  }
  extraSet('bus-label', { label:'분석_버스정류장_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:labels },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10.5, 'text-offset':[0, 1.3], 'text-allow-overlap':false },
    paint:{ 'text-color':ST().busText, 'text-halo-color':ST().paper, 'text-halo-width':1.5 },
    svg:{ kind:'text', fill:ST().busText, size:8.5 } });
}

/* AI 요약용 */
function transitSummary(){
  if(BUS.on && BUS.wide && hasRef()){
    const W = BUS.wide, lenBy = {};
    for(const g of W.segs){ const L = Math.hypot(g.pts[1][0] - g.pts[0][0], g.pts[1][1] - g.pts[0][1]); const k = g.n >= 8 ? '8개 이상' : g.n >= 4 ? '4–7개' : '1–3개'; lenBy[k] = Math.round((lenBy[k] || 0) + L); }
    let nearest = null;
    for(const g of W.segs) if(g.n >= 4) for(const p of g.pts){ const d = Math.hypot(p[0], p[1]); if(!nearest || d < nearest.d) nearest = { d, n:g.n }; }
    return { source:'국토교통부 TAGO 버스노선정보 (노선 축 방식)', analysis_range: rangeLabel(), routes_in_range: W.routes, method: W.cityWide ? '도시 전체 노선을 받아 범위를 지나는 구간만 집계' : `표본 지점 ${W.samples}곳 주변 정류장에서 찾은 노선만 집계`,
      corridor_length_m_by_routes: lenBy,
      nearest_corridor_4plus_routes_m: nearest ? Math.round(nearest.d) : null,
      hub_stops: W.stops.slice().sort((a, b) => b.n - a.n).slice(0, 8).map(h => ({ name:h.name, routes:h.n, distance_from_site_center_m:Math.round(Math.hypot(h.m[0], h.m[1])) })),
      note:(W.cityWide ? '' : '표본 지점 주변에서 찾은 노선만 포함되어 일부 노선이 빠질 수 있습니다. ') + '구간은 정류장 사이를 직선으로 이은 것입니다.' };
  }
  if(!BUS.on || !BUS.stops || !hasRef()) return null;
  const st = BUS.stops, { uniq, byType } = busStats();
  const within = d => st.filter(s => s.d <= d).length;
  return {
    source: BUS.source === 'OSM' ? 'OpenStreetMap 정류장·노선 (노선 수는 OSM 등록분만이라 실제보다 적을 수 있음)' : BUS.source === '서울시 버스정보' ? '서울특별시 정류소정보조회' : '국토교통부 TAGO 버스정류소정보',
    analysis_range: rangeLabel(),
    stops_in_area: st.length,
    stops_within_200m: within(200), stops_within_400m: within(400),
    unique_routes: uniq.size, routes_by_type: byType,
    nearest_stop: st[0] ? { name:st[0].name, distance_m:Math.round(st[0].d), routes:(st[0].routes || []).length } : null,
    busiest_stops: st.slice().sort((a, b) => (b.routes || []).length - (a.routes || []).length).slice(0, 5)
      .map(s => ({ name:s.name, routes:(s.routes || []).length, distance_m:Math.round(s.d) })),
    note:'거리는 대지 경계에서 정류장까지의 직선거리입니다. 배차 간격·이용객 수는 포함하지 않습니다.'
  };
}

/* ============================================================
   관리자: 데이터 API 연결 시험
   ============================================================ */
$('dgsave').addEventListener('click', () => {
  try{ const v = $('dgkey').value.trim(); if(v) localStorage.setItem('cleanmapDataKey', v); else localStorage.removeItem('cleanmapDataKey'); }catch(e){}
  toast('공공데이터포털 키를 저장했습니다');
});
try{ $('dgkey').value = localStorage.getItem('cleanmapDataKey') || ''; }catch(e){}
$('dgtest').addEventListener('click', async () => {
  // 시험은 지금 화면 중심에서 합니다 — 예전에 고른 대지가 다른 곳에 남아 있어도 헷갈리지 않게
  const mc = map.getCenter(), c = [mc.lng, mc.lat];
  const rows = [['시험 위치', true, `${c[1].toFixed(5)}, ${c[0].toFixed(5)} (지도 중심) — 키 확인용 작은 표본이며, 실제 분석은 분석 범위 전체를 씁니다`, '']];
  const show = () => { $('dgout').hidden = false; $('dgout').innerHTML = rows.map(r =>
    `<div class="row"><span>${esc(r[0])}</span><span style="color:${r[1] ? '#1E7B34' : '#A5261F'}">${esc(r[2])}</span></div>`
    + (r[3] ? `<div class="hint" style="margin:0 0 6px;word-break:break-all">${esc(r[3])}</div>` : '')).join(''); };
  rows.push(['TAGO 근접정류소', null, '시험 중…']); show();
  const iA = rows.length - 1;
  // 지도 중심에 정류장이 없으면 화면 안 여러 곳을 차례로 봅니다 (부두·바다가 중심이어도 시험되게)
  const bb = map.getBounds(), spots = [c];
  for(const fy of [0.3, 0.5, 0.7]) for(const fx of [0.3, 0.5, 0.7]) if(fx !== 0.5 || fy !== 0.5)
    spots.push([bb.getWest() + (bb.getEast() - bb.getWest()) * fx, bb.getSouth() + (bb.getNorth() - bb.getSouth()) * fy]);
  let a = null, at = 0;
  for(let i = 0; i < spots.length; i++){
    rows[iA] = ['TAGO 근접정류소', null, `시험 중… (${i + 1}/${spots.length}곳째)`]; show();
    a = await dataGo(TAGO_STTN + '/getCrdntPrxmtSttnList', { gpsLati:spots[i][1].toFixed(6), gpsLong:spots[i][0].toFixed(6), numOfRows:'5', pageNo:'1' });
    if(!a.ok || a.items.length){ at = i; break; }
  }
  rows[iA] = ['TAGO 근접정류소', a.ok, a.ok ? (a.items.length ? `정상 · ${a.items.length}곳` + (at ? ` (지도 중심엔 없어 화면 안 ${at + 1}번째 지점에서 찾음)` : '') : '정상 · 화면 안 9곳 모두 0곳 — 시내가 보이게 옮겨 주세요') : a.msg, (a.ok && a.items.length) ? '' : a.raw]; show();
  const first = a.ok && a.items[0];
  if(first){
    rows.push(['TAGO 경유노선', null, '시험 중…']); show();
    const iB = rows.length - 1;
    const b = await dataGo(TAGO_STTN + '/getSttnThrghRouteList', { cityCode:String(first.citycode), nodeid:first.nodeid, nodeId:first.nodeid, numOfRows:'5', pageNo:'1' });
    rows.push(['TAGO 도시 노선 목록', null, '시험 중…']); show();
    const iD = rows.length - 1;
    const dq = await dataGo(TAGO_ROUTE + '/getRouteNoList', { cityCode:String(first.citycode), numOfRows:'10', pageNo:'1' });
    rows[iD] = ['TAGO 도시 노선 목록', dq.ok, dq.ok ? `정상 · 도시 코드 ${first.citycode} 노선 ${dq.total || dq.items.length}개` : dq.msg, dq.ok && dq.items.length ? '' : dq.raw]; show();
    if(b.ok && b.items[0]){
      rows.push(['TAGO 노선별 정류장', null, '시험 중…']); show();
      const iC = rows.length - 1, rt = b.items[0];
      const cq = await dataGo(TAGO_ROUTE + '/getRouteAcctoThrghSttnList', { cityCode:String(first.citycode), routeId:rt.routeid, numOfRows:'500', pageNo:'1' });
      rows[iC] = ['TAGO 노선별 정류장', cq.ok, cq.ok ? `정상 · ${rt.routeno}번 정류장 ${cq.items.length}곳` : cq.msg, cq.ok && cq.items.length ? '' : cq.raw]; show();
    }
    rows[iB] = ['TAGO 경유노선', b.ok, b.ok ? `정상 · "${first.nodenm}" ${b.items.length}개 노선` : b.msg, b.ok ? '' : b.raw]; show();
  }else if(a.ok){
    rows.push(['TAGO 경유노선', false, inSeoul(c) ? '키는 정상입니다 — TAGO는 서울 정류장을 제공하지 않아 0곳입니다' : '근처에 정류장이 없어 시험하지 못했습니다 — 시내로 옮겨 다시 누르세요', '']); show();
  }
  // 인증만 보면 되는 API — 응답 형식이 달라도 "키 통과"인지 구분합니다
  const probe = async (name, path, params, count, showRaw) => {
    rows.push([name, null, '시험 중…']); show();
    const r = await dataGo(path, params);
    const i = rows.length - 1;
    if(r.ok) rows[i] = [name, true, `정상 · ${count ? count(r) : r.items.length + '건'}`, (r.items.length && !showRaw) ? '' : (r.rawFull || r.raw || '').slice(0, 500)];
    else if(r.code === 'param') rows[i] = [name, true, '키 통과 · ' + r.msg, ''];
    else if(['key', 'denied', 'unreg', 'expired', 'limit'].includes(r.code)) rows[i] = [name, false, r.msg, ''];
    else rows[i] = [name, true, '키 통과 — 요청 형식은 기능을 붙일 때 맞추겠습니다', r.raw];
    show();
  };
  await probe('상가(상권)정보', 'apis.data.go.kr/B553077/api/open/sdsc2/storeListInRadius',
    { radius:'300', cx:c[0].toFixed(6), cy:c[1].toFixed(6), type:'json', numOfRows:'10', pageNo:'1' },
    r => `표본 반경 300m 상가 ${r.total || r.items.length}곳`);
  // 상가 — 지금 화면 전체 사각형 (광역 조회가 되는지)
  { const b = map.getBounds();
    await probe('상가 화면 전체 (광역)', 'apis.data.go.kr/B553077/api/open/sdsc2/storeListInRectangle',
      { minx:b.getWest().toFixed(6), miny:b.getSouth().toFixed(6), maxx:b.getEast().toFixed(6), maxy:b.getNorth().toFixed(6), type:'json', numOfRows:'1', pageNo:'1' },
      r => `지금 화면 안 상가 ${(r.total || r.items.length).toLocaleString()}곳`); }
  // 건축물대장 — 받아 둔 필지의 PNU 로 지번을 만듭니다 (없으면 예시 지번)
  let pnu = null;
  const pfc = VW.data && VW.data.parcel;
  if(pfc && pfc.features.length){
    let best = null, bd = 1e18;
    for(const f of pfc.features){ const q = f.properties && f.properties.pnu; if(!q || q.length < 19) continue;
      const g = asMulti(f.geometry); if(!g.length) continue; const p0 = g[0][0][0];
      const d = (p0[0] - c[0]) ** 2 + (p0[1] - c[1]) ** 2; if(d < bd){ bd = d; best = q; } }
    pnu = best;
  }
  const P = pnu || '1111010100100010000';                      // 예시: 서울 종로구 청운동 1
  await probe('건축물대장 (표제부)', 'apis.data.go.kr/1613000/BldRgstHubService/getBrTitleInfo',
    { sigunguCd:P.slice(0, 5), bjdongCd:P.slice(5, 10), platGbCd:P[10] === '2' ? '1' : '0', bun:P.slice(11, 15), ji:P.slice(15, 19), numOfRows:'5', pageNo:'1' },
    r => `${pnu ? '가까운 필지' : '예시 지번'} 건물 ${r.total || r.items.length}동`);
  // 교통량 — 하루 100건 한도라 두 번만 부르고, 응답 모양을 보려고 원문을 길게 보여줍니다
  const kict = async (name, op, params) => {
    rows.push([name, null, '시험 중…']); show();
    const i = rows.length - 1, r = await dataGo('apis.data.go.kr/1613000/KictTms/' + op, { output:'json', ...params });
    rows[i] = [name, r.ok, r.ok ? `정상 · ${r.items.length}건` + (r.total > r.items.length ? ` (전체 ${r.total.toLocaleString()}건)` : '') : r.msg, r.ok ? '' : (r.rawFull || r.raw || '').slice(0, 600)]; show();
  };
  const y = String(new Date().getFullYear() - 2);
  await kict(`교통량 측정 지점 (${y}년 일반국도)`, 'spotlist', { year:y, dtype:'2', PageNo:'0', numOfRows:'3' });

  // 상권 영역 (같은 상가정보 API)
  { const b = map.getBounds();
    await probe('상권 영역 (화면 안)', 'apis.data.go.kr/B553077/api/open/sdsc2/storeZoneInRectangle',
      { minx:b.getWest().toFixed(6), miny:b.getSouth().toFixed(6), maxx:b.getEast().toFixed(6), maxy:b.getNorth().toFixed(6), type:'json', numOfRows:'5', pageNo:'1' },
      r => `상권 ${(r.total || r.items.length)}곳 · 첫 상권 "${r.items[0] ? (r.items[0].mainTrarNm || r.items[0]['상권명'] || '?') : '?'}"`, true); }
  // 관광 (TourAPI — 국문 관광정보 서비스_GW)
  await probe('관광정보 (반경 3km)', 'apis.data.go.kr/B551011/KorService2/locationBasedList2',
    { MobileOS:'ETC', MobileApp:'CleanMap', mapX:c[0].toFixed(6), mapY:c[1].toFixed(6), radius:'3000', numOfRows:'5', pageNo:'1' },
    r => `${(r.total || r.items.length)}곳 · "${r.items[0] ? r.items[0].title : '?'}"`, true);
  // 15분 생활권 — 공원·학교는 확장에 넣은 파일로 확인
  if(typeof localData === 'function'){
    for(const [nm, f] of [['공원 (내장 표준데이터)', 'parks'], ['학교 (내장 위치 자료)', 'schools']]){
      try{ const d = await localData(f); rows.push([nm, true, `정상 · 전국 ${d.rows.length.toLocaleString()}곳 (${d.date} 기준)`, '']); }catch(e){ rows.push([nm, false, e.message, '']); }
      show();
    }
  }
  if(typeof nearestStation === 'function'){
    const stn = nearestStation(), d = new Date(Date.now() - 3 * 864e5), ymd = d.toISOString().slice(0, 10).replace(/-/g, '');
    await probe(`기상청 ASOS 시간자료 (${stn[1]})`, 'apis.data.go.kr/1360000/AsosHourlyInfoService/getWthrDataList',
      { dataCd:'ASOS', dateCd:'HR', startDt:ymd, startHh:'00', endDt:ymd, endHh:'23', stnIds:String(stn[0]), numOfRows:'24', pageNo:'1', dataType:'JSON' }, r => `${r.items.length}시간 · 첫 시각 풍향 ${r.items[0] ? r.items[0].wd : '?'}° 풍속 ${r.items[0] ? r.items[0].ws : '?'}m/s`);
  }
  if(typeof sgisProbe === 'function') await sgisProbe(c, rows, show);
  if(inSeoul(c)){
    rows.push(['서울시 정류소정보', null, '시험 중…']); show();
    const sq = await seoulCall('stationinfo/getStationByPos', { tmX:c[0].toFixed(6), tmY:c[1].toFixed(6), radius:'300' });
    rows[rows.length - 1] = ['서울시 정류소정보', sq.ok, sq.ok ? `정상 · ${sq.items.length}곳` : sq.msg, sq.ok ? '' : (sq.raw || '')]; show();
  }
});
