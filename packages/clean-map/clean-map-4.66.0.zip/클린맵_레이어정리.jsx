/*
  클린 맵 SVG — 레이어 정리
  ---------------------------------------------------------------
  클린 맵에서 내보낸 SVG를 일러스트레이터에서 연 뒤 이 스크립트를 실행하면,
  배경·위성사진·물·산림·건물·도로·라벨 그룹이 각각 이름 붙은 레이어로 분리됩니다.

  쓰는 법
    1. SVG 를 일러스트레이터에서 엽니다.
    2. 파일 › 스크립트 › 기타 스크립트 (Ctrl+F12) 로 이 파일을 고릅니다.

  자주 쓰실 거면 일러스트레이터 설치 폴더의
  Presets/ko_KR/스크립트 안에 넣어 두면 메뉴에 바로 뜹니다.
*/

#target illustrator

(function () {
  if (app.documents.length === 0) {
    alert('먼저 SVG 파일을 열어 주세요.');
    return;
  }

  var doc = app.activeDocument;
  var made = 0;
  var unnamed = 0;

  // 정리 대상 레이어를 먼저 확보합니다 (순회 도중 레이어가 늘어나므로)
  var sources = [];
  for (var i = 0; i < doc.layers.length; i++) sources.push(doc.layers[i]);

  for (var s = 0; s < sources.length; s++) {
    var src = sources[s];
    if (src.locked) src.locked = false;
    if (!src.visible) src.visible = true;

    // 이 레이어에 직접 놓인 최상위 항목만 모읍니다
    var items = [];
    for (var k = 0; k < src.pageItems.length; k++) {
      var it = src.pageItems[k];
      if (it.parent === src) items.push(it);
    }
    if (items.length < 2) continue;   // 옮길 게 없는 레이어는 건너뜁니다

    // 아래쪽부터 옮겨야 새 레이어가 원래 순서대로 쌓입니다
    for (var n = items.length - 1; n >= 0; n--) {
      var item = items[n];
      var name = item.name;

      if (!name || name === '') {
        unnamed++;
        name = '이름없음 ' + (unnamed);
      }

      var lay;
      try {
        lay = doc.layers.getByName(name);      // 같은 이름이 있으면 합칩니다
      } catch (e) {
        lay = doc.layers.add();
        lay.name = name;
        made++;
      }
      item.move(lay, ElementPlacement.PLACEATBEGINNING);
    }

    // 비워진 원래 레이어는 지웁니다
    if (src.pageItems.length === 0) {
      try { src.remove(); } catch (e) {}
    }
  }

  if (made === 0) {
    alert('분리할 그룹을 찾지 못했습니다.\n\n'
        + '클린 맵에서 내보낸 SVG 가 맞는지, 이미 정리한 파일은 아닌지 확인해 주세요.');
  } else {
    alert('레이어 ' + made + '개로 나눴습니다.'
        + (unnamed > 0 ? '\n이름이 없던 항목 ' + unnamed + '개는 "이름없음" 으로 뒀습니다.' : ''));
  }
})();
