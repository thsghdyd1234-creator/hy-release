/* ============================================================
   커널 밀도 → 매끈한 등밀도 면 (벡터) — site.js 다음에 읽힙니다.
   점(가중치)을 격자에 부드럽게 퍼뜨린 뒤, 단계별로 "이 값 이상인 칸"을 합치고
   둥근 오프셋으로 가장자리를 다듬어 일러스트에서 그대로 쓸 수 있는 면으로 만듭니다.
   ============================================================ */

function offsetRound(mp, d, arcTol){
  if(!mp.length) return mp;
  const C = CL(); const co = new C.ClipperOffset(2, Math.max(0.02, arcTol || 0.25) * CLS);
  co.AddPaths(toPaths(mp), C.JoinType.jtRound, C.EndType.etClosedPolygon);
  const tree = new C.PolyTree(); co.Execute(tree, d * CLS);
  return fromTree(tree);
}

/* 차이킨 모서리 깎기 — 닫힌 고리를 매끈한 곡선으로 */
function chaikin(r, it){
  let pts = r.slice(0, -1);
  for(let k = 0; k < it; k++){
    const out = [];
    for(let i = 0; i < pts.length; i++){
      const a = pts[i], b = pts[(i + 1) % pts.length];
      out.push([a[0] * 0.75 + b[0] * 0.25, a[1] * 0.75 + b[1] * 0.25], [a[0] * 0.25 + b[0] * 0.75, a[1] * 0.25 + b[1] * 0.75]);
    }
    pts = out;
  }
  pts.push(pts[0]);
  return pts;
}
/* 흰색 → 기준색 → 진한 기준색 으로 n 단계 */
function rampFrom(hex, n, paperHex){
  const rgb = h => { const c = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(c.slice(i, i + 2), 16)); };
  const [r, g, b] = rgb(hex), [pr, pg, pb] = rgb(paperHex || (typeof ST === 'function' ? ST().paper : '#FFFFFF'));
  const dark = (pr + pg + pb) / 3 < 110;                   // 어두운 판이면 진한 쪽을 밝게
  const mix = (t) => {
    let R, G, B;
    if(t < 0.7){ const k = t / 0.7; R = pr + (r - pr) * k; G = pg + (g - pg) * k; B = pb + (b - pb) * k; }
    else { const k = (t - 0.7) / 0.3 * 0.45, T = dark ? 255 : 0; R = r + (T - r) * k; G = g + (T - g) * k; B = b + (T - b) * k; }
    return '#' + [R, G, B].map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
  };
  return Array.from({ length:n }, (_, i) => mix(0.12 + 0.88 * i / (n - 1)));
}

/* pts: [[x, y, w], …] (미터, 대지 중심 기준)
   반환: { bands:[{k, geom}], h, cell, cuts } — geom 은 미터 좌표 MultiPolygon, k 가 클수록 진함 */
function kdeBands(pts, opt){
  opt = opt || {};
  if(!pts.length) return { bands:[] };
  const FR = focusR();
  const h = opt.h || Math.max(60, Math.min(600, FR / 8));         // 퍼짐 반경
  const cell = opt.cell || h / 7;
  let x0, y0, x1, y1;
  if(SITE.range === 'view' && SITE.viewLL){ [[x0, y0], [x1, y1]] = viewRectM(); }
  else { x0 = -FR; y0 = -FR; x1 = FR; y1 = FR; }
  const nx = Math.ceil((x1 - x0) / cell) + 1, ny = Math.ceil((y1 - y0) / cell) + 1;
  if(nx * ny > 250000) return kdeBands(pts, { ...opt, h, cell:cell * Math.sqrt(nx * ny / 250000) });
  const G = new Float32Array(nx * ny), rc = Math.ceil(h / cell);
  // 4차 커널 (가장자리에서 0으로 부드럽게)
  for(const [px, py, w = 1] of pts){
    const ci = Math.round((px - x0) / cell), cj = Math.round((py - y0) / cell);
    for(let j = Math.max(0, cj - rc); j <= Math.min(ny - 1, cj + rc); j++){
      const dy = y0 + j * cell - py;
      for(let i = Math.max(0, ci - rc); i <= Math.min(nx - 1, ci + rc); i++){
        const dx = x0 + i * cell - px, u = (dx * dx + dy * dy) / (h * h);
        if(u < 1){ const k = 1 - u; G[j * nx + i] += w * k * k; }
      }
    }
  }
  const vals = []; for(let i = 0; i < G.length; i++) if(G[i] > 0) vals.push(G[i]);
  if(!vals.length) return { bands:[] };
  vals.sort((a, b) => a - b);
  const qs = opt.quantiles || [0.25, 0.45, 0.62, 0.76, 0.87, 0.95];
  const cuts = qs.map(q => vals[Math.min(vals.length - 1, Math.floor(q * vals.length))]);
  const focus = focusGeomM();
  const bands = [];
  cuts.forEach((cut, k) => {
    // 이 값 이상인 칸을 가로로 이어 붙인 띠로 모읍니다 (다각형 수를 줄이려고)
    const strips = [];
    for(let j = 0; j < ny; j++){
      let s = -1;
      for(let i = 0; i <= nx; i++){
        const on = i < nx && G[j * nx + i] >= cut;
        if(on && s < 0) s = i;
        if(!on && s >= 0){
          const ax = x0 + (s - 0.5) * cell, bx = x0 + (i - 0.5) * cell, ay = y0 + (j - 0.5) * cell, by = ay + cell;
          strips.push([[[[ax, ay], [bx, ay], [bx, by], [ax, by], [ax, ay]]]]); s = -1;
        }
      }
    }
    if(!strips.length) return;
    let g = union(strips);
    g = offsetRound(offsetRound(g, cell * 1.6, cell * 0.06), -cell * 1.6, cell * 0.06);   // 오목한 계단 메우기
    g = offsetRound(offsetRound(g, -cell * 0.8, cell * 0.06), cell * 0.8, cell * 0.06);   // 볼록한 계단 깎기
    g = g.map(poly => poly.map(r => chaikin(simplifyRing(r, cell * 0.25), 2)));          // 곡선으로 다듬기
    g = cleanMP(inter(g, focus), { close:0, open:0, minPiece:cell * cell * 2, minHole:cell * cell * 2, simplify:cell * 0.05 });
    if(g.length) bands.push({ k, geom:g });
  });
  return { bands, h, cell, cuts };
}

/* 단계면을 분석 레이어로 등록 — 낮은 단계부터 겹쳐 칠해 진한 곳이 위에 오게 */
function registerBands(prefix, title, res, baseColor, stage){
  extraRemove(prefix);
  if(!res || !res.bands.length) return;
  const n = 6, ramp = rampFrom(baseColor, n);
  for(const b of res.bands){
    const col = ramp[Math.min(n - 1, b.k)];
    extraSet(prefix + b.k, { label:`분석_${title}_${b.k + 1}_${b.k === 0 ? '낮음' : b.k === n - 1 ? '가장 높음' : ''}`.replace(/_$/, ''),
      stage:stage || 'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{ k:b.k }, geometry:{ type:'MultiPolygon', coordinates:mapRings(b.geom, toLL) } }] },
      paint:{ 'fill-color':col, 'fill-opacity':1, 'fill-antialias':true, 'fill-outline-color':col },
      svg:{ kind:'fill', fill:col, opacity:1 } });
  }
}


/* ============================================================
   밀도를 "거점 원"으로 — 밀도 봉우리를 찾아 동심원으로 그립니다
   원의 크기는 그 봉우리 주변에 모인 양(점 개수·인구 등)에 비례합니다.
   ============================================================ */
/* 거점 원 세분화 — 크게: 큰 덩어리 몇 개 / 보통 / 잘게: 동네 단위로 촘촘히 */
const PEAK_GRAIN = {
  g1:{ div:6,  max:7,  minD:2.6, rk:1.5,  outer:1.9 },    // 매우 크게
  g2:{ div:10, max:11, minD:2.2, rk:1.15, outer:1.7 },    // 크게
  g3:{ div:15, max:18, minD:2.0, rk:1.0,  outer:1.6 },    // 보통
  g4:{ div:22, max:28, minD:1.75, rk:0.85, outer:1.45 },  // 잘게
  g5:{ div:32, max:44, minD:1.6, rk:0.72, outer:1.35 }    // 매우 잘게
};
function kdePeaks(pts, opt){
  opt = opt || {};
  if(!pts.length) return { peaks:[] };
  const FR = focusR(), G0 = PEAK_GRAIN[SITE.peakGrain] || PEAK_GRAIN.g3;
  const h = opt.h || Math.max(60, Math.min(700, FR / G0.div));
  const cell = h / 4;
  let x0, y0, x1, y1;
  if(SITE.range === 'view' && SITE.viewLL){ [[x0, y0], [x1, y1]] = viewRectM(); } else { x0 = -FR; y0 = -FR; x1 = FR; y1 = FR; }
  const nx = Math.ceil((x1 - x0) / cell) + 1, ny = Math.ceil((y1 - y0) / cell) + 1;
  const G = new Float32Array(nx * ny), rc = Math.ceil(h / cell);
  for(const [px, py, w = 1] of pts){
    const ci = Math.round((px - x0) / cell), cj = Math.round((py - y0) / cell);
    for(let j = Math.max(0, cj - rc); j <= Math.min(ny - 1, cj + rc); j++) for(let i = Math.max(0, ci - rc); i <= Math.min(nx - 1, ci + rc); i++){
      const dx = x0 + i * cell - px, dy = y0 + j * cell - py, u = (dx * dx + dy * dy) / (h * h);
      if(u < 1){ const k = 1 - u; G[j * nx + i] += w * k * k; }
    }
  }
  const vals = []; for(let i = 0; i < G.length; i++) if(G[i] > 0) vals.push(G[i]);
  vals.sort((a, b) => a - b);
  const floor = vals.length ? vals[Math.floor(vals.length * (opt.q || 0.8))] : 0;
  // 8방향 이웃보다 큰 칸 = 봉우리
  const cand = [];
  for(let j = 1; j < ny - 1; j++) for(let i = 1; i < nx - 1; i++){
    const v = G[j * nx + i]; if(v < floor || v <= 0) continue;
    let top = true;
    for(let dj = -1; dj <= 1 && top; dj++) for(let di = -1; di <= 1; di++){ if((di || dj) && G[(j + dj) * nx + i + di] > v){ top = false; break; } }
    if(top) cand.push({ x:x0 + i * cell, y:y0 + j * cell, v });
  }
  cand.sort((a, b) => b.v - a.v);
  // 가까운 봉우리는 하나로 (가장 높은 것만)
  const peaks = [], minD = opt.minDist || h * G0.minD, max = opt.max || G0.max;   // 한 덩어리에는 원 하나만
  for(const c of cand){ if(peaks.some(p => Math.hypot(p.x - c.x, p.y - c.y) < minD)) continue; peaks.push(c); if(peaks.length >= max) break; }
  // 봉우리마다 주변에 모인 양 — 가장 가까운 봉우리에 배정
  for(const p of peaks) p.mass = 0;
  const reach = h * 1.4;
  for(const [px, py, w = 1] of pts){
    let best = null, bd = reach;
    for(const p of peaks){ const d = Math.hypot(p.x - px, p.y - py); if(d < bd){ bd = d; best = p; } }
    if(best) best.mass += w;
  }
  const mMax = Math.max(1, ...peaks.map(p => p.mass));
  for(const p of peaks) p.r = h * G0.rk * Math.max(0.35, Math.sqrt(p.mass / mMax));
  return { peaks:peaks.filter(p => p.mass > 0 && inFocus([p.x, p.y])), h, outer:G0.outer };
}
/* 거점 원 그리기 — 동심원 3겹 + 점선 바깥 고리 + 가운데 점 + 이름표 */
function registerCircles(prefix, title, res, color, fmt){
  extraRemove(prefix);
  if(!res || !res.peaks.length) return;
  const ring = (p, r) => circleM(r, 72)[0][0].map(([x, y]) => toLL([p.x + x, p.y + y]));
  const a = typeof CA === 'function' ? CA() : 0.7;
  const O = res.outer || 1.9, layers = [[O, 0.14 * a], [1 + (O - 1) * 0.45, 0.26 * a], [1.0, 0.46 * a]];
  layers.forEach(([k, op], i) => {
    extraSet(prefix + 'c' + i, { label:`분석_${title}_${i + 1}_${i === 2 ? '거점 중심부' : i === 1 ? '영향권' : '주변'}`, stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:res.peaks.map(p => ({ type:'Feature', properties:{}, geometry:{ type:'Polygon', coordinates:[ring(p, p.r * k)] } })) },
      paint:{ 'fill-color':color, 'fill-opacity':op }, svg:{ kind:'fill', fill:color, opacity:op } });
  });
  extraSet(prefix + 'ring', { label:`분석_${title}경계`, stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:res.peaks.map(p => ({ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:ring(p, p.r * O) } })) },
    paint:{ 'line-color':color, 'line-width':0.7, 'line-dasharray':[2, 2], 'line-opacity':Math.min(1, a + 0.1) }, svg:{ kind:'line', stroke:color, width:0.5, dash:[2, 2] } });
  const dot = Math.max(4, res.h / 12);
  extraSet(prefix + 'dot', { label:`분석_${title}_중심`, stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:res.peaks.map(p => [ring(p, dot)]) } }] },
    paint:{ 'fill-color':color, 'fill-opacity':Math.min(1, a + 0.3) }, svg:{ kind:'fill', fill:color, opacity:Math.min(1, a + 0.3) } });
  if(fmt) extraSet(prefix + 'label', { label:`분석_${title}_라벨`, stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:res.peaks.map(p => ({ type:'Feature', properties:{ label:fmt(p) }, geometry:{ type:'Point', coordinates:toLL([p.x, p.y]) } })) },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10.5, 'text-offset':[0, 1.3], 'text-allow-overlap':false },
    paint:{ 'text-color':ST().ink, 'text-halo-color':ST().paper, 'text-halo-width':1.6 }, svg:{ kind:'text', fill:ST().ink, size:8.5 } });
}
