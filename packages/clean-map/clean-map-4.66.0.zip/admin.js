/* ============================================================
   행정경계 (시군구 · 읍면동) — 브이월드 행정구역 면
   OSM 경계는 선 조각이라 해안에서 열리지만, 브이월드 행정구역은 닫힌 면이라 그대로 구역이 됩니다.
   시도 경계는 지금처럼 바탕 지도(OSM)를 쓰고, 시군구·읍면동만 여기서 받아 그립니다.
   ============================================================ */
const ADM = {
  level:'sido',            // sido(바탕 지도만) · sigungu · emd
  label:true,
  data:{ sigungu:new Map(), emd:new Map() },   // 코드 → Feature (한 번 받은 구역은 다시 받지 않음)
  got:{ sigungu:[], emd:[] },                  // 받아 둔 범위 상자들
  busy:false, err:''
};
const ADM_SRC = {
  sigungu:{ id:'LT_C_ADSIGG_INFO', name:'시군구', minzoom:8,
            code:p => p.sig_cd || p.SIG_CD, nm:p => p.sig_kor_nm || p.SIG_KOR_NM || p.full_nm || '' },
  emd:    { id:'LT_C_ADEMD_INFO', name:'읍면동', minzoom:11,
            code:p => p.emd_cd || p.EMD_CD, nm:p => p.emd_kor_nm || p.EMD_KOR_NM || p.full_nm || '' }
};
try{ const v = JSON.parse(localStorage.getItem('cleanmapAdm') || 'null'); if(v){ ADM.level = v.level || ADM.level; ADM.label = v.label !== false; } }catch(e){}
const admSave = () => { try{ localStorage.setItem('cleanmapAdm', JSON.stringify({ level:ADM.level, label:ADM.label })); }catch(e){} };
const admWant = () => ADM.level === 'emd' ? ['sigungu', 'emd'] : ADM.level === 'sigungu' ? ['sigungu'] : [];

/* 한 범위 상자 받기 — 브이월드 공통 요청을 그대로 씁니다 */
async function admBox(kind, box){
  VW_LAYERS.__adm = { id:ADM_SRC[kind].id, name:ADM_SRC[kind].name, kind:'line' };
  try{
    const out = [];
    for(let page = 1; page <= 5; page++){
      const fc = await vwFetch('__adm', box, undefined, page);
      out.push(...fc.features);
      if(fc.features.length < 1000) break;
    }
    return out;
  }finally{ delete VW_LAYERS.__adm; }
}
/* 화면 범위를 받기 — 한 번에 안 되면(브이월드 범위 제한) 작은 상자로 나눠서 */
async function admFetch(kind, b){
  const box = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()];
  const has = ADM.got[kind].some(g => g[0] <= box[0] && g[1] <= box[1] && g[2] >= box[2] && g[3] >= box[3]);
  if(has) return 0;
  const S0 = ADM_SRC[kind], put = list => { let n = 0; for(const f of list){ const p = f.properties || {}, k = S0.code(p) || S0.nm(p) + JSON.stringify(f.geometry).slice(0, 40); if(!ADM.data[kind].has(k)){ ADM.data[kind].set(k, f); n++; } } return n; };
  try{ put(await admBox(kind, box)); }
  catch(err){
    // 범위가 넓어 거절되면 약 9km² 이하 칸으로 나눠 받습니다 (최대 64칸)
    const W = box[2] - box[0], H = box[3] - box[1], km = boxAreaKm2(box);
    let n = Math.ceil(Math.sqrt(km / 9)); n = Math.max(2, Math.min(8, n));
    let ok = 0;
    for(let i = 0; i < n; i++) for(let j = 0; j < n; j++){
      const sub = [box[0] + W * i / n, box[1] + H * j / n, box[0] + W * (i + 1) / n, box[1] + H * (j + 1) / n];
      try{ put(await admBox(kind, sub)); ok++; }catch(e2){ ADM.err = e2.message; }
    }
    if(!ok) throw err;
  }
  ADM.got[kind].push(box);
  return 1;
}
/* 폴리곤 → 테두리 선 (닫힌 고리) */
function admLines(kind){
  const lines = [];
  for(const f of ADM.data[kind].values()){
    const g = f.geometry; if(!g) continue;
    const polys = g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : [];
    for(const poly of polys) for(const r of poly) lines.push(r);
  }
  return lines;
}
/* 구역 이름 자리 — 가장 큰 고리의 무게중심 (구멍 무시) */
function admLabelPts(kind){
  const S0 = ADM_SRC[kind], pts = [];
  for(const f of ADM.data[kind].values()){
    const g = f.geometry; if(!g) continue;
    const polys = g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : [];
    let best = null, ba = 0;
    for(const poly of polys){
      const r = poly[0]; let a = 0, cx = 0, cy = 0;
      for(let i = 1; i < r.length; i++){ const k = r[i - 1][0] * r[i][1] - r[i][0] * r[i - 1][1]; a += k; cx += (r[i - 1][0] + r[i][0]) * k; cy += (r[i - 1][1] + r[i][1]) * k; }
      if(Math.abs(a) > ba){ ba = Math.abs(a); best = [cx / (3 * a), cy / (3 * a)]; }
    }
    if(best && isFinite(best[0])) pts.push({ type:'Feature', properties:{ label:S0.nm(f.properties || {}) }, geometry:{ type:'Point', coordinates:best } });
  }
  return pts;
}
function registerAdmLayers(){
  extraRemove('adm-');
  const want = admWant(); if(!want.length) return;
  const c = colors();
  const col = c.boundary, lab = c.label, halo = c.labelHalo;
  // 읍면동: 가늘게 점선 · 시군구: 조금 굵게 점선 (바탕 시도 경계와 같은 계열)
  const ST_ = { emd:{ w:0.6, dash:[1.5, 1.5], label:'행정경계_읍면동' }, sigungu:{ w:1.1, dash:[3, 2], label:'행정경계_시군구' } };
  for(const kind of ['emd', 'sigungu']){
    if(!want.includes(kind)) continue;
    const lines = admLines(kind); if(!lines.length) continue;
    const s = ST_[kind];
    extraSet('adm-' + kind, { label:s.label, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:lines } }] },
      layout:{ 'line-cap':'round', 'line-join':'round' },
      paint:{ 'line-color':col, 'line-width':s.w, 'line-dasharray':s.dash },
      svg:{ kind:'line', stroke:col, width:s.w * 0.8, dash:s.dash } });
  }
  if(ADM.label){
    const kind = want[want.length - 1], pts = admLabelPts(kind);
    if(pts.length) extraSet('adm-label', { label:'행정경계_' + ADM_SRC[kind].name + '이름', stage:'top', type:'symbol', nomerge:true,
      fc:{ type:'FeatureCollection', features:pts },
      layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':kind === 'emd' ? 10.5 : 12, 'text-allow-overlap':false },
      paint:{ 'text-color':lab, 'text-halo-color':halo, 'text-halo-width':1.6 },
      svg:{ kind:'text', fill:lab, size:kind === 'emd' ? 9 : 10 } });
  }
}
let admTimer = null;
function admRefresh(){
  clearTimeout(admTimer);
  admTimer = setTimeout(async () => {
    const want = admWant();
    if(!want.length || !map){ registerAdmLayers(); return; }
    if(!VW.key && !VW.proxy){ admNote('브이월드 인증키가 필요합니다', true); return; }
    if(ADM.busy) return;
    ADM.busy = true;
    let changed = false;
    try{
      const z = map.getZoom(), b = map.getBounds();
      for(const kind of want){
        if(z < ADM_SRC[kind].minzoom){ admNote(`${ADM_SRC[kind].name} 경계는 줌 ${ADM_SRC[kind].minzoom} 이상에서 받습니다`); continue; }
        admNote(`${ADM_SRC[kind].name} 경계 받는 중`);
        if(await admFetch(kind, b)) changed = true;
      }
      const cnt = want.map(k => `${ADM_SRC[k].name} ${ADM.data[k].size}`).join(' · ');
      if(z >= ADM_SRC[want[want.length - 1]].minzoom) admNote(`행정경계 ${cnt}곳 (브이월드)` + (ADM.err ? ' · 일부 칸 실패' : ''));
    }catch(err){ admNote('행정경계를 받지 못했습니다 — ' + err.message, true); }
    ADM.busy = false;
    registerAdmLayers();
    if(changed || true) apply();
  }, 450);
}
function admNote(m, bad){ const e = document.getElementById('admnote'); if(e){ e.textContent = m; e.style.color = bad ? '#C0392B' : ''; } }
(function hookAdm(){
  if(typeof map === 'undefined' || !map || !map.on){ setTimeout(hookAdm, 400); return; }
  map.on('moveend', admRefresh);
  const sel = document.getElementById('admlevel'), lab = document.getElementById('admlabel');
  if(sel){ sel.value = ADM.level; sel.addEventListener('change', e => { ADM.level = e.target.value; admSave(); ADM.err = ''; if(!admWant().length){ admNote(''); registerAdmLayers(); apply(); } else admRefresh(); }); }
  if(lab){ lab.checked = ADM.label; lab.addEventListener('change', e => { ADM.label = e.target.checked; admSave(); registerAdmLayers(); apply(); }); }
  if(admWant().length) admRefresh();
})();
