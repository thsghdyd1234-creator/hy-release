/* 구글맵 위에 "클린 맵으로 열기" 버튼을 띄웁니다.
   현재 보고 있는 위치와 배율을 그대로 뷰어로 넘깁니다. */
(function () {
  const VER = '2.2.1';
  const ID = 'cleanmap-jump';
  let resetTimer;

  function flash(btn, text, ms) {
    btn.textContent = text;
    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => { btn.textContent = '클린 맵으로 열기';
    btn.title = '클린 맵 v' + VER; }, ms || 3000);
  }

  /* 주소 문자열에서 위치 읽기 — z(줌), m(카메라 높이), a(거리뷰 각도), 핀 좌표를 다룹니다 */
  function fromUrl(u) {
    if (!u) return null;
    let m = u.match(/@(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?),([\d.]+)([zmay])/);
    if (m) {
      const v = parseFloat(m[3]);
      const zoom = m[4] === 'z' ? v
                 : m[4] === 'm' ? Math.log2(35200000 / Math.max(v, 1))
                 : 18;
      return { lat: +m[1], lng: +m[2], zoom: Math.max(1, Math.min(20, zoom)) };
    }
    m = u.match(/!3d(-?\d{1,2}(?:\.\d+)?)!4d(-?\d{1,3}(?:\.\d+)?)/);
    if (m) return { lat: +m[1], lng: +m[2], zoom: 16 };
    // 정적 지도 이미지 주소: center=위도,경도&zoom=
    m = u.match(/center=(-?\d{1,2}(?:\.\d+)?)(?:,|%2C)(-?\d{1,3}(?:\.\d+)?)/i);
    if (m) {
      const z = u.match(/[?&]zoom=(\d+(?:\.\d+)?)/i);
      return { lat: +m[1], lng: +m[2], zoom: z ? +z[1] : 15 };
    }
    m = u.match(/@(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?)/);
    if (m) return { lat: +m[1], lng: +m[2], zoom: 16 };
    return null;
  }

  /* 주소창은 지도를 움직이면 갱신됩니다 — 가장 최근 값을 계속 들고 있습니다 */
  var fresh = null;
  function watchUrl() {
    const c = fromUrl(location.href);
    if (c) fresh = c;
  }
  watchUrl();
  setInterval(watchUrl, 400);
  window.addEventListener('popstate', watchUrl);
  window.addEventListener('hashchange', watchUrl);

  /* 페이지에 박혀 있는 값 — 첫 화면 기준이라 갱신되지 않습니다 */
  function stale() {
    const sources = [];
    const canon = document.querySelector('link[rel="canonical"]');
    if (canon) sources.push(canon.href);
    const meta = document.querySelector('meta[itemprop="image"], meta[property="og:image"]');
    if (meta) sources.push(meta.content);
    document.querySelectorAll('img[src*="staticmap"], img[src*="center="]')
      .forEach(img => sources.push(img.src));
    for (const s of sources) {
      const c = fromUrl(s);
      if (c) return c;
    }
    return null;
  }

  /* 좌표가 없는 검색·장소 주소에서는 이름을 꺼냅니다 */
  function term() {
    const m = location.pathname.match(/\/(?:place|search)\/([^/@?]+)/);
    if (m) return decodeURIComponent(m[1]).replace(/\+/g, ' ');
    const box = document.querySelector('#searchboxinput, input[name="q"]');
    const v = box && box.value && box.value.trim();
    return v || null;
  }

  function viewerUrl(tail) {
    try { return chrome.runtime.getURL('index.html') + tail; }
    catch (e) { return null; }   // 확장을 새로 불러오면 여기서 끊깁니다
  }

  function open(btn, tail) {
    const url = viewerUrl(tail);
    console.log('[클린 맵] 열기 요청 ·', tail, '·', url);
    if (!url) {
      flash(btn, '이 탭을 새로고침해 주세요', 5000);
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'openViewer', tail: tail }, () => {
        if (chrome.runtime.lastError) window.open(url, '_blank');   // 배경 스크립트가 잠들었을 때
      });
    } catch (e) {
      window.open(url, '_blank');
    }
  }

  function build() {
    if (document.getElementById(ID) || !document.body) return;
    const btn = document.createElement('button');
    btn.id = ID;
    btn.type = 'button';
    btn.textContent = '클린 맵으로 열기';
    btn.title = '클린 맵 v' + VER;
    Object.assign(btn.style, {
      position: 'fixed', top: '72px', right: '12px', zIndex: '2147483000',
      font: '500 13px/1 "Malgun Gothic","맑은 고딕",system-ui,sans-serif',
      color: '#fff', background: '#1B4DB1', border: '0', borderRadius: '2px',
      padding: '9px 13px', cursor: 'pointer', boxShadow: '0 1px 4px rgba(0,0,0,.3)'
    });
    btn.addEventListener('click', () => {
      console.log('[클린 맵] 버튼 눌림 ·', location.href);
      watchUrl();
      if (fresh) {
        console.log('[클린 맵] 주소창 좌표 사용 ·', JSON.stringify(fresh));
        open(btn, '#' + fresh.zoom.toFixed(2) + '/' + fresh.lat.toFixed(6) + '/' + fresh.lng.toFixed(6));
        return;
      }
      const t = term();                       // 검색 결과 화면에는 좌표가 없습니다
      if (t) {
        console.log('[클린 맵] 검색어로 엽니다 ·', t);
        open(btn, '?q=' + encodeURIComponent(t));
        return;
      }
      const old = stale();                    // 마지막 수단 — 첫 화면 위치입니다
      if (old) {
        console.warn('[클린 맵] 주소창에 좌표가 없어 첫 화면 위치로 엽니다 ·', JSON.stringify(old));
        flash(btn, '첫 화면 위치로 열었습니다', 4000);
        open(btn, '#' + old.zoom.toFixed(2) + '/' + old.lat.toFixed(6) + '/' + old.lng.toFixed(6));
        return;
      }
      console.warn('[클린 맵] 이 주소에서는 좌표도 검색어도 찾지 못했습니다');
      flash(btn, '지도를 끌어 움직인 뒤 눌러 주세요', 5000);
    });
    document.body.appendChild(btn);
    console.log('[클린 맵] 버튼을 붙였습니다');
  }

  console.log('[클린 맵] v' + VER + ' 시작 ·', location.host);
  build();
  // 구글맵은 화면을 통째로 갈아끼우기도 해서, 버튼이 사라지면 다시 답니다
  setInterval(build, 2000);
})();
