/* ============================================================
   행정구역으로 자르기 — 시도 · 시군구 · 읍면동 구역을 골라 그 모양대로 내보냅니다
   · 구역은 브이월드 행정구역 면(닫힌 면)을 받아 씁니다. 여러 곳을 고르면 하나로 합칩니다 (예: 창원시 5개 구)
   · SVG · DXF · GeoJSON 은 도형을 구역 경계에서 직접 잘라 냅니다 (클리핑 마스크 없이)
   · 도시 전체처럼 넓은 범위에서도 골목길까지 나오도록, 도로는 지도 타일(z14)을 직접 받아 씁니다
   ============================================================ */
const CLIP = {
  level:'sigungu', regions:[], geom:null, idx:null,
  on:true, blank:true, edge:true, detail:true, bld:false, out:'blank',    // out: 구역 밖 — 비우기 · 바다만 남기기 · 어둡게 한 육지·바다 면
  split:'none', zfill:true, zlabel:true, zones:null, subs:null,      // 나눠서 내보내기 (예: 창원시 → 마산 · 창원 · 진해)
  hires:null, busy:false, token:0, picking:false
};
const CLIP_SRC = {
  sido:   { id:'LT_C_ADSIDO_INFO', name:'시도',   search:'ctp_kor_nm', code:'ctprvn_cd', cd:p => p.ctprvn_cd, full:p => p.ctp_kor_nm || '' },
  sigungu:{ id:'LT_C_ADSIGG_INFO', name:'시군구', search:'full_nm',    code:'sig_cd',    cd:p => p.sig_cd,    full:p => p.full_nm || p.sig_kor_nm || '' },
  emd:    { id:'LT_C_ADEMD_INFO',  name:'읍면동', search:'full_nm',    code:'emd_cd',    cd:p => p.emd_cd,    full:p => p.full_nm || p.emd_kor_nm || '' }
};
try{
  const v = JSON.parse(localStorage.getItem('cleanmapClip') || '{}');
  for(const k of ['level', 'on', 'blank', 'edge', 'detail', 'bld', 'split', 'zfill', 'zlabel', 'out']) if(v[k] !== undefined) CLIP[k] = v[k];
  if(v.keepSea && !v.out) CLIP.out = 'sea';                             // 4.69 의 '구역 밖 바다는 남기기'
}catch(e){}
const clipSave = () => { try{ localStorage.setItem('cleanmapClip', JSON.stringify({ level:CLIP.level, on:CLIP.on, blank:CLIP.blank, edge:CLIP.edge, detail:CLIP.detail, bld:CLIP.bld, split:CLIP.split, zfill:CLIP.zfill, zlabel:CLIP.zlabel, out:CLIP.out })); }catch(e){} };
const clipNote = (m, bad) => { const n = document.getElementById('clipnote'); if(n){ n.textContent = m || ''; n.classList.toggle('bad', !!bad); } };
/* 구역은 지도 꾸미기 출력 탭에서만 고르고, 고른 구역은 대지분석 내보내기에도 그대로 씁니다 (대지분석 다이어그램도 구역 모양으로) */
const clipMode = () => true;
function clipActive(){ return !!(CLIP.on && CLIP.geom && CLIP.idx && clipMode()); }

/* ---------- 브이월드 행정구역 요청 ---------- */
async function clipQuery(level, params){
  const S0 = CLIP_SRC[level];
  const once = async domain => {
    const u = new URL(VW.proxy || 'https://api.vworld.kr/req/data');
    const p = { service:'data', request:'GetFeature', version:'2.0', data:S0.id, format:'json', size:'100', crs:'EPSG:4326', ...params };
    if(!VW.proxy){ p.key = VW.key; if(domain) p.domain = domain; }
    for(const [k, v] of Object.entries(p)) u.searchParams.set(k, v);
    const r = await (await fetch(u.toString())).json(), res = r && r.response;
    if(!res) throw new Error('응답이 이상합니다');
    if(res.status === 'NOT_FOUND') return { features:[], total:0 };
    if(res.status !== 'OK'){ const e = res.error || {}, err = new Error([e.code, e.text].filter(Boolean).join(' ') || res.status); err.code = e.code || res.status; throw err; }
    const fc = res.result && res.result.featureCollection;
    return { features:(fc && fc.features) || [], total:+(res.record && res.record.total) || 0 };
  };
  try{ return await once(VW.domain); }
  catch(err){
    if(err.code !== 'INCORRECT_KEY' || VW.proxy || typeof domainTries !== 'function') throw err;
    for(const d of domainTries()){ if(d === VW.domain) continue; try{ const r = await once(d); VW.domain = d; return r; }catch(e2){} }
    throw err;
  }
}
const asMP = g => !g ? [] : g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : [];

/* ---------- 구역 도형 색인 — 빠르게 "안인가 · 밖인가 · 경계에 걸쳤나"를 가립니다 ---------- */
function clipIndex(mp){
  const rings = []; for(const poly of mp) for(const r of poly) if(r.length > 3) rings.push(r);
  let n = 0; for(const r of rings) n += r.length - 1;
  const E = new Float64Array(n * 4); let k = 0;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for(const r of rings) for(let i = 1; i < r.length; i++){
    const a = r[i - 1], b = r[i];
    E[k++] = a[0]; E[k++] = a[1]; E[k++] = b[0]; E[k++] = b[1];
    if(a[0] < x0) x0 = a[0]; if(a[0] > x1) x1 = a[0]; if(a[1] < y0) y0 = a[1]; if(a[1] > y1) y1 = a[1];
  }
  const G = Math.max(16, Math.min(256, Math.ceil(Math.sqrt(n / 2)))), cw = (x1 - x0) / G || 1e-9, ch = (y1 - y0) / G || 1e-9;
  const cx = x => Math.max(0, Math.min(G - 1, Math.floor((x - x0) / cw))), cy = y => Math.max(0, Math.min(G - 1, Math.floor((y - y0) / ch)));
  // 칸마다 지나가는 변 목록 (CSR)
  const cnt = new Int32Array(G * G + 1);
  const each = (e, fn) => { const ax = E[e * 4], ay = E[e * 4 + 1], bx = E[e * 4 + 2], by = E[e * 4 + 3];
    for(let j = cy(Math.min(ay, by)); j <= cy(Math.max(ay, by)); j++) for(let i = cx(Math.min(ax, bx)); i <= cx(Math.max(ax, bx)); i++) fn(j * G + i); };
  for(let e = 0; e < n; e++) each(e, c => cnt[c + 1]++);
  for(let c = 0; c < G * G; c++) cnt[c + 1] += cnt[c];
  const fill = cnt.slice(0, G * G), list = new Int32Array(cnt[G * G]);
  for(let e = 0; e < n; e++) each(e, c => { list[fill[c]++] = e; });
  const stamp = new Int32Array(n); let tick = 0;
  // 점이 구역 안인가 — 오른쪽으로 반직선을 그어 몇 번 변을 넘는지 셉니다
  const pip = (x, y) => {
    if(x < x0 || x > x1 || y < y0 || y > y1) return false;
    const j = cy(y); tick++; let inside = false;
    for(let i = cx(x); i < G; i++){
      const c = j * G + i;
      for(let q = cnt[c]; q < cnt[c + 1]; q++){
        const e = list[q]; if(stamp[e] === tick) continue; stamp[e] = tick;
        const ay = E[e * 4 + 1], by = E[e * 4 + 3];
        if((ay > y) !== (by > y)){ const ax = E[e * 4], bx = E[e * 4 + 2]; if(x < ax + (y - ay) * (bx - ax) / (by - ay)) inside = !inside; }
      }
    }
    return inside;
  };
  // 선분 a→b 가 구역 경계를 넘는 자리 (0~1 사이 비율, 작은 순)
  const cross = (a, b) => {
    const out = []; tick++;
    const rx = b[0] - a[0], ry = b[1] - a[1];
    for(let j = cy(Math.min(a[1], b[1])); j <= cy(Math.max(a[1], b[1])); j++) for(let i = cx(Math.min(a[0], b[0])); i <= cx(Math.max(a[0], b[0])); i++){
      const c = j * G + i;
      for(let q = cnt[c]; q < cnt[c + 1]; q++){
        const e = list[q]; if(stamp[e] === tick) continue; stamp[e] = tick;
        const ex = E[e * 4], ey = E[e * 4 + 1], sx = E[e * 4 + 2] - ex, sy = E[e * 4 + 3] - ey;
        const den = rx * sy - ry * sx; if(!den) continue;
        const qx = ex - a[0], qy = ey - a[1], t = (qx * sy - qy * sx) / den, u = (qx * ry - qy * rx) / den;
        if(t > 1e-12 && t < 1 - 1e-12 && u >= 0 && u <= 1) out.push(t);
      }
    }
    return out.sort((p, q) => p - q);
  };
  // 쿼드트리 — 칸마다 구역 조각을 필요할 때만 잘라 둡니다 (꽉 참 · 빔 · 걸침)
  const area = mp2 => { let s = 0; for(const poly of mp2) poly.forEach((r, ri) => { let a = 0; for(let i = 1; i < r.length; i++) a += r[i - 1][0] * r[i][1] - r[i][0] * r[i - 1][1]; s += (ri ? -1 : 1) * Math.abs(a / 2); }); return s; };
  const rect = ([a, b, c, d]) => [[[a, b], [c, b], [c, d], [a, d], [a, b]]];
  const mkNode = (box, geom) => { const full = (box[2] - box[0]) * (box[3] - box[1]);
    return { box, geom, kids:null, state:!geom.length ? 'out' : area(geom) >= full * (1 - 1e-9) ? 'in' : 'part' }; };
  const root = { box:[x0, y0, x1, y1], geom:mp, kids:null, state:'part' };
  const MAXD = 7;
  const kid = (node, q) => {
    if(!node.kids) node.kids = [null, null, null, null];
    if(!node.kids[q]){
      const [a, b, c, d] = node.box, mx = (a + c) / 2, my = (b + d) / 2;
      const box = [[a, b, mx, my], [mx, b, c, my], [a, my, mx, d], [mx, my, c, d]][q];
      try{ node.kids[q] = mkNode(box, polygonClipping.intersection(node.geom, rect(box))); }
      catch(e){ node.kids[q] = { box, geom:node.geom, kids:null, state:'part', bad:true }; }   // 자르기에 실패한 칸은 더 나누지 않고 통째로
    }
    return node.kids[q];
  };
  const locate = bb => {
    if(bb[2] < x0 || bb[0] > x1 || bb[3] < y0 || bb[1] > y1) return { state:'out' };
    if(bb[0] < x0 || bb[2] > x1 || bb[1] < y0 || bb[3] > y1) return root;    // 구역 상자 밖으로 삐져나오면 칸 판정을 쓰지 않고 경계 검사로
    let node = root;
    for(let d = 0; d < MAXD && node.state === 'part' && !node.bad; d++){
      const [a, b, c, e] = node.box, mx = (a + c) / 2, my = (b + e) / 2;
      const qx = bb[2] <= mx ? 0 : bb[0] >= mx ? 1 : -1, qy = bb[3] <= my ? 0 : bb[1] >= my ? 1 : -1;
      if(qx < 0 || qy < 0) break;
      node = kid(node, qy * 2 + qx);
    }
    return node;
  };
  return { bbox:[x0, y0, x1, y1], pip, cross, locate, edges:n };
}

/* ---------- 도형 자르기 (경위도) ---------- */
const clipBBox = pts => { let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity; for(const p of pts){ if(p[0] < a) a = p[0]; if(p[0] > c) c = p[0]; if(p[1] < b) b = p[1]; if(p[1] > d) d = p[1]; } return [a, b, c, d]; };
function clipLine(pts, X){
  if(!pts || pts.length < 2) return [];
  const node = X.locate(clipBBox(pts));
  if(node.state === 'out') return [];
  if(node.state === 'in') return [pts];
  // 경계 근처 — 선분마다 경계를 넘는 자리에서 나누고, 나뉜 토막의 가운데가 안인지로 남길지 정합니다
  //   (시작점이 경계 위에 딱 놓인 선 — 바깥 구역에서 이미 잘린 선 — 도 놓치지 않게, 점 하나의 안·밖에 기대지 않습니다)
  const parts = []; let cur = null;
  const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
  for(let i = 1; i < pts.length; i++){
    const a = pts[i - 1], b = pts[i], ts = X.cross(a, b);
    let t0 = 0;
    for(const t1 of [...ts, 1]){
      if(t1 - t0 < 1e-12){ t0 = t1; continue; }
      const m = lerp(a, b, (t0 + t1) / 2);
      if(X.pip(m[0], m[1])){ if(!cur) cur = [t0 ? lerp(a, b, t0) : a]; cur.push(t1 === 1 ? b : lerp(a, b, t1)); }
      else if(cur){ if(cur.length > 1) parts.push(cur); cur = null; }
      t0 = t1;
    }
  }
  if(cur && cur.length > 1) parts.push(cur);
  return parts;
}
function clipPolys(mp, X){
  const out = [];
  for(const poly of mp){
    if(!poly.length || poly[0].length < 4) continue;
    const node = X.locate(clipBBox(poly[0]));
    if(node.state === 'out') continue;
    if(node.state === 'in'){ out.push(poly); continue; }
    try{ out.push(...polygonClipping.intersection([poly], node.geom)); }
    catch(e){ const p = poly[0][0]; if(X.pip(p[0], p[1])) out.push(poly); }          // 도형이 꼬였으면 통째로 판단
  }
  return out;
}
function clipGeom(g, X){
  if(!g) return null;
  switch(g.type){
    case 'Point': return X.pip(g.coordinates[0], g.coordinates[1]) ? g : null;
    case 'MultiPoint': { const c = g.coordinates.filter(p => X.pip(p[0], p[1])); return c.length ? { type:'MultiPoint', coordinates:c } : null; }
    case 'LineString': { const p = clipLine(g.coordinates, X); return !p.length ? null : p.length === 1 ? (p[0] === g.coordinates ? g : { type:'LineString', coordinates:p[0] }) : { type:'MultiLineString', coordinates:p }; }
    case 'MultiLineString': { const p = g.coordinates.flatMap(l => clipLine(l, X)); return p.length ? { type:'MultiLineString', coordinates:p } : null; }
    case 'Polygon': case 'MultiPolygon': {
      const src = asMP(g), mp = clipPolys(src, X);
      if(!mp.length) return null;
      if(mp.length === src.length && mp.every((p, i) => p === src[i])) return g;
      return mp.length === 1 ? { type:'Polygon', coordinates:mp[0] } : { type:'MultiPolygon', coordinates:mp };
    }
    default: return g;
  }
}
/* 내보내기용 레이어 묶음을 통째로 자릅니다 — 구역 경계선(clip-) 레이어는 그대로 */
function clipLayers(byLayer){
  if(!clipActive()) return byLayer;
  const X = CLIP.idx, out = new Map();
  // 도로·건물은 전부 받아 둔 타일 자료로 바꿔 끼웁니다 (넓은 범위에서도 골목길까지)
  if(CLIP.hires && CLIP.hires.key === clipKey()) for(const [id, list] of CLIP.hires.byId) if(SVGSTYLE[id] && list.length) byLayer.set(id, list);
  // 나눠서 내보낼 때는 나눈 구역마다 다시 잘라 이름(_zone)을 붙입니다 — 경계에 걸친 길은 경계에서 둘로 나뉩니다
  const Z = CLIP.zones && CLIP.zones.length > 1 ? CLIP.zones : null;
  for(const [id, fts] of byLayer){
    if(id.startsWith('clip-')){ out.set(id, fts); continue; }
    if(CLIP.out !== 'blank' && id === 'coast'){ out.set(id, fts); continue; }   // 구역 밖을 남기면 해안선은 자르지 않음
    const text = SVGSTYLE[id] && SVGSTYLE[id].kind === 'text', kept = [];
    for(const ft of fts){
      if(CLIP.out === 'sea' && id === 'water' && ft.properties && ft.properties.class === 'ocean'){ kept.push(ft); continue; }   // 바다만 남기기
      const g0 = ft.geometry, g = clipGeom(g0, X); if(!g) continue;
      if(!Z || text){ kept.push(g === g0 ? ft : { type:'Feature', properties:ft.properties, geometry:g, sourceLayer:ft.sourceLayer, layer:ft.layer }); continue; }
      const bb = geomBBox(g);
      for(const z of Z){
        const zb = z.idx.bbox; if(bb[2] < zb[0] || bb[0] > zb[2] || bb[3] < zb[1] || bb[1] > zb[3]) continue;
        const gz = clipGeom(g, z.idx);
        if(gz) kept.push({ type:'Feature', properties:{ ...(ft.properties || {}), _zone:z.name }, geometry:gz, sourceLayer:ft.sourceLayer, layer:ft.layer });
      }
    }
    if(kept.length) out.set(id, kept);
  }
  return out;
}

/* ---------- 고른 구역 → 하나의 도형 ---------- */
const clipKey0 = () => CLIP.regions.map(r => r.level + ':' + r.code).sort().join(',');
const clipKey = () => clipKey0() + '|' + (CLIP.bld ? 'b' : '');
/* 여러 구역을 하나로 — 이웃한 구끼리 맞닿은 경계가 미세하게 어긋나 합치기가 실패하는 일이 있어, 좌표를 1cm 격자에 맞춘 뒤 합칩니다 */
function clipSnapUnion(geoms){
  if(geoms.length === 1) return geoms[0];
  const snap = (mp, d) => mp.map(poly => poly.map(ring => { const out = []; for(const [x, y] of ring){ const q = [Math.round(x * d) / d, Math.round(y * d) / d], l = out[out.length - 1]; if(!l || l[0] !== q[0] || l[1] !== q[1]) out.push(q); } return out; }).filter(r => r.length >= 4)).filter(p => p.length);
  for(const d of [1e7, 1e6]){ try{ return polygonClipping.union(...geoms.map(g => snap(g, d))); }catch(e){} }
  return geoms.flat();                                                  // 그래도 안 되면 그냥 모읍니다 (맞닿은 구는 안·밖 판정이 그대로 맞습니다)
}
const geomBBox = g => { let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
  const walk = x => { if(typeof x[0] === 'number'){ if(x[0] < a) a = x[0]; if(x[0] > c) c = x[0]; if(x[1] < b) b = x[1]; if(x[1] > d) d = x[1]; } else x.forEach(walk); };
  walk(g.coordinates); return [a, b, c, d]; };
function clipRebuild(){
  CLIP.token++; CLIP.hires = null;
  if(!CLIP.regions.length){
    CLIP.geom = null; CLIP.idx = null; CLIP.zones = null; clipRender(); registerClipLayers(); apply();
    return;
  }
  const mp = clipSnapUnion(CLIP.regions.map(r => r.geom));
  CLIP.geom = mp; CLIP.idx = clipIndex(mp);
  clipZonesBuild();
  clipRender(); registerClipLayers(); apply();
  if(CLIP.split === 'sub' && !(CLIP.subs && CLIP.subs.key === clipKey0())) clipFetchSubs();
  if(CLIP.detail) clipFetchHiRes();
}

/* ---------- 나눠서 내보내기 — 고른 구역을 몇 덩어리로 (예: 창원시 → 마산 · 창원 · 진해) ----------
   none: 나누지 않음 · region: 고른 구역마다 · old: 옛 시로 · sub: 한 단계 아래로(구 → 동) · custom: 직접 묶기 */
const OLD_CITY = { '48121':'창원', '48123':'창원', '48125':'마산', '48127':'마산', '48129':'진해' };   // 2010년 통합 전 세 시 — 의창·성산 = 창원, 마산합포·마산회원 = 마산
const clipHasOld = () => CLIP.regions.some(r => r.level === 'sigungu' && OLD_CITY[r.code]);
const ZONE_COLORS = ['#E0785A', '#4A86C8', '#6BAF7A', '#E3B341', '#9A73C9', '#4FB0AE', '#C9667E', '#8E9A3E', '#C98A4A', '#5F7FB0'];
const CLIP_SUB = { sido:{ level:'sigungu', field:'sig_cd', nm:p => p.sig_kor_nm }, sigungu:{ level:'emd', field:'emd_cd', nm:p => p.emd_kor_nm } };
function clipZoneOf(r, mode){
  mode = mode || CLIP.split;
  return mode === 'old' ? (OLD_CITY[r.code] || r.name) : mode === 'custom' ? (r.zone || r.groupName || r.name) : (r.groupName || r.name);
}
/* 구역 하나 빼기 — "창원시 전체"에서 한 구를 빼면 나머지는 더 이상 "전체"가 아니라 하나씩 보입니다 */
function clipDrop(i){
  const r = CLIP.regions[i]; if(!r) return;
  CLIP.regions.splice(i, 1);
  if(r.group) for(const x of CLIP.regions) if(x.group === r.group){ delete x.group; delete x.groupName; }
}
/* 목록·이름에 쓰는 단위 — "창원시 전체"처럼 묶어 고른 것은 하나로 */
function clipUnits(){
  const out = [], at = new Map();
  CLIP.regions.forEach((r, i) => {
    const k = r.groupName ? 'g:' + r.group : 'r:' + i;
    if(!at.has(k)){ at.set(k, out.length); out.push({ key:k, name:r.groupName ? r.groupName + ' 전체' : r.name, idx:[] }); }
    out[at.get(k)].idx.push(i);
  });
  return out;
}
function clipZonesBuild(){
  CLIP.zones = null;
  if(!CLIP.regions.length || CLIP.split === 'none') return;
  if(CLIP.split === 'sub'){
    if(!CLIP.subs || CLIP.subs.key !== clipKey0()) return;              // 받는 중
    CLIP.zones = CLIP.subs.list.map((z, i) => ({ name:z.name, geom:z.geom, idx:clipIndex(z.geom), color:ZONE_COLORS[i % ZONE_COLORS.length] }));
    return;
  }
  const groups = new Map();
  for(const r of CLIP.regions){ const k = clipZoneOf(r); if(!groups.has(k)) groups.set(k, []); groups.get(k).push(r.geom); }
  if(groups.size < 2) return;                                           // 한 덩어리뿐이면 나누지 않은 것과 같습니다
  CLIP.zones = [...groups].map(([name, gs], i) => { const geom = clipSnapUnion(gs); return { name, geom, idx:clipIndex(geom), color:ZONE_COLORS[i % ZONE_COLORS.length] }; });
}
/* 한 단계 아래 구역 받기 — 시군구 코드로 시작하는 읍면동(시도 → 시군구)을 모두 */
async function clipFetchSubs(){
  const key = clipKey0(), token = CLIP.token;
  if(CLIP.regions.some(r => !CLIP_SUB[r.level])){ clipNote('읍면동은 더 작게 나눌 수 없습니다', true); return; }
  clipNote('아래 단계 구역 받는 중…');
  try{
    const list = [];
    for(const r of CLIP.regions){
      const sub = CLIP_SUB[r.level], S1 = CLIP_SRC[sub.level];
      for(let page = 1; page <= 5; page++){
        const res = await clipQuery(sub.level, { attrFilter:`${sub.field}:like:${r.code}`, geometry:'true', size:'1000', page:String(page) });
        for(const f of res.features){ const p = f.properties || {}; list.push({ code:S1.cd(p), name:sub.nm(p) || clipShort(sub.level, S1.full(p)), full:S1.full(p), level:sub.level, geom:asMP(f.geometry) }); }
        if(res.features.length < 1000) break;
      }
    }
    if(token !== CLIP.token) return;
    const seen = new Map(); for(const z of list) seen.set(z.name, (seen.get(z.name) || 0) + 1);
    for(const z of list) if(seen.get(z.name) > 1) z.name = clipShort(z.level, z.full);     // 같은 동 이름이 두 구에 있으면 "성산구 상남동"처럼
    CLIP.subs = { key, list };
    clipNote(`${CLIP_SRC[list[0] ? list[0].level : 'emd'].name} ${list.length}곳으로 나눴습니다`);
    clipZonesBuild(); clipRender(); registerClipLayers(); apply();
  }catch(err){ clipNote('아래 단계 구역을 받지 못했습니다 — ' + err.message, true); }
}
/* 구역 이름 자리 — 가장 큰 조각의 무게중심, 그게 바깥이면 그 높이에서 가장 넓은 안쪽 구간의 가운데 */
function clipLabelPt(mp, X){
  let best = null, ba = 0;
  for(const poly of mp){ const r = poly[0]; let a = 0, cx = 0, cy = 0;
    for(let i = 1; i < r.length; i++){ const k = r[i - 1][0] * r[i][1] - r[i][0] * r[i - 1][1]; a += k; cx += (r[i - 1][0] + r[i][0]) * k; cy += (r[i - 1][1] + r[i][1]) * k; }
    if(Math.abs(a) > ba){ ba = Math.abs(a); best = [cx / (3 * a), cy / (3 * a)]; } }
  if(!best || X.pip(best[0], best[1])) return best;
  const y = best[1], xs = [];
  for(const poly of mp) for(const r of poly) for(let i = 1; i < r.length; i++){ const [ax, ay] = r[i - 1], [bx, by] = r[i]; if((ay > y) !== (by > y)) xs.push(ax + (y - ay) * (bx - ax) / (by - ay)); }
  xs.sort((p, q) => p - q); let w = 0, out = best;
  for(let i = 0; i + 1 < xs.length; i += 2) if(xs[i + 1] - xs[i] > w){ w = xs[i + 1] - xs[i]; out = [(xs[i] + xs[i + 1]) / 2, y]; }
  return out;
}
function clipAreaKm2(mp){
  let s = 0;
  for(const poly of mp) poly.forEach((r, ri) => {
    let a = 0; const k = Math.cos(r[0][1] * Math.PI / 180) * 111.32 * 110.57;
    for(let i = 1; i < r.length; i++) a += r[i - 1][0] * r[i][1] - r[i][0] * r[i - 1][1];
    s += (ri ? -1 : 1) * Math.abs(a / 2) * k;
  });
  return s;
}
async function clipAdd(items, replace, fit = true){
  // items: [{level, code, name}] — 도형은 코드로 받아 옵니다
  clipNote('구역 모양 받는 중…');
  try{
    const got = await Promise.all(items.map(async it => {
      if(it.geom) return it;
      const S0 = CLIP_SRC[it.level];
      const r = await clipQuery(it.level, { attrFilter:`${S0.code}:=:${it.code}`, geometry:'true', size:'10' });
      const f = r.features[0]; if(!f) throw new Error(it.name + ' 모양을 받지 못했습니다');
      return { ...it, geom:asMP(f.geometry) };
    }));
    const keep = replace ? [] : CLIP.regions;
    const have = new Set(keep.map(r => r.level + ':' + r.code));
    CLIP.regions = keep.concat(got.filter(r => !have.has(r.level + ':' + r.code)));
    clipNote('');
    clipRebuild();
    if(fit && !CLIP.picking) clipFit();                                 // 지도에서 누르는 중에는 화면을 움직이지 않음
  }catch(err){ clipNote('구역을 받지 못했습니다 — ' + err.message, true); }
}
function clipFit(){
  if(!CLIP.idx || !map) return;
  const [a, b, c, d] = CLIP.idx.bbox;
  try{
    const cam = map.cameraForBounds([[a, b], [c, d]], { padding:48, bearing:map.getBearing() });
    if(cam) map.easeTo({ ...cam, pitch:0, duration:600 });
  }catch(e){ map.fitBounds([[a, b], [c, d]], { padding:48, duration:600 }); }
}

/* ---------- 넓은 범위 도로 — 지도 타일을 직접 받아 읽기 ---------- */
const CLIP_ROAD = { 'road-major':['motorway', 'trunk', 'primary', 'secondary', 'tertiary'], 'road-minor':['minor', 'service', 'track', 'path'], 'rail':['rail'] };
async function clipFetchHiRes(){
  if(!CLIP.idx || typeof VTLib === 'undefined') return;
  const token = CLIP.token, key = clipKey(), X = CLIP.idx;
  const [W0, S0, E0, N0] = X.bbox;
  const t2x = (lng, z) => Math.floor((lng + 180) / 360 * 2 ** z);
  const t2y = (lat, z) => { const r = lat * Math.PI / 180; return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 2 ** z); };
  const x2l = (x, z) => x / 2 ** z * 360 - 180;
  const y2l = (y, z) => { const n = Math.PI - 2 * Math.PI * y / 2 ** z; return 180 / Math.PI * Math.atan(Math.sinh(n)); };
  // 구역에 닿는 타일만 — 많으면 한 단계 낮은 줌으로 (z13 아래는 골목길이 빠집니다)
  let z = 14, tiles = [];
  for(; z >= 10; z--){
    tiles = [];
    const xs = [t2x(W0, z), t2x(E0, z)], ys = [t2y(N0, z), t2y(S0, z)];
    if((xs[1] - xs[0] + 1) * (ys[1] - ys[0] + 1) > 4000) continue;
    for(let x = xs[0]; x <= xs[1]; x++) for(let y = ys[0]; y <= ys[1]; y++){
      const box = [x2l(x, z), y2l(y + 1, z), x2l(x + 1, z), y2l(y, z)];
      if(X.locate(box).state !== 'out') tiles.push([z, x, y, box]);
    }
    if(tiles.length <= (CLIP.bld ? 450 : 700)) break;
  }
  if(!tiles.length) return;
  CLIP.busy = true; clipRender();
  const byId = new Map(Object.keys(CLIP_ROAD).map(id => [id, []]));
  if(CLIP.bld){ byId.set('building', []); byId.set('building-line', []); }
  const cls = {}; for(const [id, list] of Object.entries(CLIP_ROAD)) for(const c of list) cls[c] = id;
  const linesOf2 = g => g.type === 'LineString' ? [g.coordinates] : g.type === 'MultiLineString' ? g.coordinates : [];
  // 타일 버퍼(옆 타일과 겹치는 테두리)는 잘라 버려 같은 길이 두 번 나가지 않게
  const lbClip = (pts, [a, b, c, d]) => {
    const parts = []; let cur = null;
    for(let i = 1; i < pts.length; i++){
      const p = pts[i - 1], q = pts[i], dx = q[0] - p[0], dy = q[1] - p[1];
      let t0 = 0, t1 = 1, ok = true;
      for(const [pp, qq] of [[-dx, p[0] - a], [dx, c - p[0]], [-dy, p[1] - b], [dy, d - p[1]]]){
        if(pp === 0){ if(qq < 0){ ok = false; break; } continue; }
        const r = qq / pp; if(pp < 0){ if(r > t1){ ok = false; break; } if(r > t0) t0 = r; } else { if(r < t0){ ok = false; break; } if(r < t1) t1 = r; }
      }
      if(!ok){ if(cur){ parts.push(cur); cur = null; } continue; }
      const A = [p[0] + t0 * dx, p[1] + t0 * dy], B = [p[0] + t1 * dx, p[1] + t1 * dy];
      if(!cur || t0 > 0){ if(cur) parts.push(cur); cur = [A]; }
      cur.push(B);
      if(t1 < 1){ parts.push(cur); cur = null; }
    }
    if(cur) parts.push(cur);
    return parts.filter(p => p.length > 1);
  };
  const shClip = (ring, [a, b, c, d]) => {
    let out = ring.slice(0, -1);
    for(const [inside, cut] of [
      [p => p[0] >= a, (p, q) => [a, p[1] + (q[1] - p[1]) * (a - p[0]) / (q[0] - p[0])]],
      [p => p[0] <= c, (p, q) => [c, p[1] + (q[1] - p[1]) * (c - p[0]) / (q[0] - p[0])]],
      [p => p[1] >= b, (p, q) => [p[0] + (q[0] - p[0]) * (b - p[1]) / (q[1] - p[1]), b]],
      [p => p[1] <= d, (p, q) => [p[0] + (q[0] - p[0]) * (d - p[1]) / (q[1] - p[1]), d]]]){
      if(!out.length) break;
      const src = out; out = [];
      for(let i = 0; i < src.length; i++){ const cu = src[i], pr = src[(i + src.length - 1) % src.length], ci = inside(cu), pi = inside(pr);
        if(ci){ if(!pi) out.push(cut(pr, cu)); out.push(cu); } else if(pi) out.push(cut(pr, cu)); }
    }
    return out.length >= 3 ? [...out, out[0]] : null;
  };
  let done = 0, fail = 0;
  const one = async ([tz, tx, ty, box]) => {
    try{
      const url = TILES[0].replace('{z}', tz).replace('{x}', tx).replace('{y}', ty);
      const res = await fetch(url); if(!res.ok) throw new Error('HTTP ' + res.status);
      const vt = new VTLib.VectorTile(new VTLib.Protobuf(new Uint8Array(await res.arrayBuffer())));
      const L = vt.layers.transportation;
      if(L) for(let i = 0; i < L.length; i++){
        const f = L.feature(i), id = cls[f.properties.class]; if(!id) continue;
        for(const ln of linesOf2(f.toGeoJSON(tx, ty, tz).geometry)) for(const part of lbClip(ln, box))
          byId.get(id).push({ type:'Feature', properties:{ class:f.properties.class }, geometry:{ type:'LineString', coordinates:part } });
      }
      const B = CLIP.bld && vt.layers.building;
      if(B) for(let i = 0; i < B.length; i++){
        const g = B.feature(i).toGeoJSON(tx, ty, tz).geometry;
        for(const poly of asMP(g)){ const rings = poly.map(r => shClip(r, box)).filter(Boolean); if(!rings.length) continue;
          const ft = { type:'Feature', properties:{}, geometry:{ type:'Polygon', coordinates:rings } };
          byId.get('building').push(ft); byId.get('building-line').push(ft); }
      }
    }catch(e){ fail++; }
    done++;
    if(token === CLIP.token && (done % 8 === 0 || done === tiles.length)) clipNote(`도로 받는 중 ${done}/${tiles.length} (z${z} 지도 타일)`);
  };
  for(let i = 0; i < tiles.length && token === CLIP.token; i += 12) await Promise.all(tiles.slice(i, i + 12).map(one));   // 12장씩 동시에
  if(token !== CLIP.token) return;                                       // 그 사이 구역이 바뀌었으면 버립니다
  CLIP.busy = false;
  CLIP.hires = { key, z, byId };
  const nRoad = ['road-major', 'road-minor'].reduce((s, id) => s + byId.get(id).length, 0);
  clipNote(`도로 ${nRoad.toLocaleString()}조각을 받았습니다 (z${z}${z < 13 ? ' — 범위가 넓어 골목길은 빠졌습니다' : ''})` + (CLIP.bld ? ` · 건물 ${byId.get('building').length.toLocaleString()}동` : '') + (fail ? ` · 타일 ${fail}장 실패` : ''), !!fail);
  clipRender(); registerClipLayers(); apply();
}
/* 내보내기 직전 — 도로를 아직 안 받았으면 받고 시작 */
async function clipPrepare(){
  if(!clipActive() || !CLIP.detail) return;
  if(CLIP.hires && CLIP.hires.key === clipKey()) return;
  if(!CLIP.busy) await clipFetchHiRes();
  else await new Promise(ok => { const t = setInterval(() => { if(!CLIP.busy){ clearInterval(t); ok(); } }, 300); });
}

/* ---------- 지도 위 표시 — 구역 밖 어둡게, 경계선, 전부 받은 도로 ---------- */
function registerClipLayers(){
  extraRemove('clip-');
  if(!CLIP.geom || !clipMode()) return;
  const c = colors();
  const edgeFC = { type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:CLIP.geom.flatMap(p => p) } }] };
  if(!CLIP.on){                                                          // 자르기를 끄면 경계만 지도에 (내보내기는 그대로)
    extraSet('clip-edge', { label:'', stage:'top', type:'line', nomerge:true, noExport:true, fc:edgeFC, layout:{ 'line-join':'round' }, paint:{ 'line-color':c.label, 'line-width':1.2, 'line-dasharray':[3, 2] } });
    return;
  }
  const holes = CLIP.geom.map(poly => poly[0]);
  extraSet('clip-mask', { label:'', stage:'top', type:'fill', noExport:true, nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'Polygon', coordinates:[[[-180, -85], [180, -85], [180, 85], [-180, 85], [-180, -85]], ...holes] } }] },
    paint:{ 'fill-color':'#101216', 'fill-opacity':0.45 } });
  extraSet('clip-edge', { label:'구역경계_' + clipName(), stage:'top', type:'line', nomerge:true, noExport:!CLIP.edge,
    fc:edgeFC, layout:{ 'line-join':'round' }, paint:{ 'line-color':c.label, 'line-width':1.4 },
    svg:{ kind:'line', stroke:c.label, width:1 } });
  if(CLIP.zones){
    const Z = CLIP.zones, colOf = Object.fromEntries(Z.map(z => [z.name, z.color]));
    if(CLIP.zfill) extraSet('clip-zone-fill', { label:'나눈구역_면', stage:'ground', type:'fill', nomerge:true,
      fc:{ type:'FeatureCollection', features:Z.map(z => ({ type:'Feature', properties:{ zone:z.name, color:z.color }, geometry:{ type:'MultiPolygon', coordinates:z.geom } })) },
      paint:{ 'fill-color':['get', 'color'], 'fill-opacity':0.24 },
      svg:{ kind:'fill', fill:Z[0].color, opacity:0.3, split:'zone', keyOf:p => p.zone, colorOf:k => colOf[k] || '#999999', off:new Set() } });
    extraSet('clip-zone-line', { label:'나눈구역_경계', stage:'top', type:'line', nomerge:true, noExport:!CLIP.edge,
      fc:{ type:'FeatureCollection', features:Z.map(z => ({ type:'Feature', properties:{ _zone:z.name }, geometry:{ type:'MultiLineString', coordinates:z.geom.flat() } })) },
      layout:{ 'line-join':'round' }, paint:{ 'line-color':c.label, 'line-width':0.9, 'line-dasharray':[4, 2] },
      svg:{ kind:'line', stroke:c.label, width:0.7, dash:[4, 2] } });
    if(CLIP.zlabel) extraSet('clip-zone-label', { label:'나눈구역_이름', stage:'top', type:'symbol', nomerge:true,
      fc:{ type:'FeatureCollection', features:Z.map(z => { const pt = clipLabelPt(z.geom, z.idx); return pt && { type:'Feature', properties:{ label:z.name }, geometry:{ type:'Point', coordinates:pt } }; }).filter(Boolean) },
      layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':Z.length > 12 ? 11 : 14, 'text-allow-overlap':Z.length <= 12 },
      paint:{ 'text-color':c.label, 'text-halo-color':c.labelHalo || c.bg, 'text-halo-width':1.6 },
      svg:{ kind:'text', fill:c.label, size:Z.length > 12 ? 10 : 13 } });
  }
  if(CLIP.hires && CLIP.hires.key === clipKey()){
    for(const L of LINE_LAYERS){
      const list = CLIP.hires.byId.get(L.id); if(!list || !list.length || !visible(L.id)) continue;
      const k = (L.road ? S.weight : 1) * lw(L.id), w = L.w.map(([zz, v]) => [zz, +(v * k).toFixed(3)]);
      extraSet('clip-hr-' + L.id, { label:'', stage:'line', type:'line', noExport:true, nomerge:true,
        fc:{ type:'FeatureCollection', features:list }, layout:{ 'line-cap':'round', 'line-join':'round' },
        paint:{ 'line-color':c[L.color], 'line-width':stops(w) } });
    }
  }
}
function clipName(){
  const u = clipUnits();
  if(!u.length) return '';
  return u.length <= 3 ? u.map(x => x.name).join(' · ') : u[0].name + ' 외 ' + (u.length - 1) + '곳';
}

/* ---------- SVG 쪽에서 쓰는 도움 함수 (app.js buildSVG) ---------- */
/* 출력 틀을 구역에 딱 맞게 줄입니다 (틀 밖은 그대로 잘림) */
function clipFrame(f){
  if(!clipActive() || CLIP.out === 'dim') return f;                   // 구역 밖을 어둡게 남길 때는 화면 틀 그대로
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for(const poly of CLIP.geom) for(const p of poly[0]){ const q = map.project(p); if(q.x < x0) x0 = q.x; if(q.x > x1) x1 = q.x; if(q.y < y0) y0 = q.y; if(q.y > y1) y1 = q.y; }
  const m = 6;
  x0 = Math.max(f.x, Math.floor(x0 - m)); y0 = Math.max(f.y, Math.floor(y0 - m));
  x1 = Math.min(f.x + f.w, Math.ceil(x1 + m)); y1 = Math.min(f.y + f.h, Math.ceil(y1 + m));
  if(x1 - x0 < 20 || y1 - y0 < 20) return f;
  return { x:x0, y:y0, w:x1 - x0, h:y1 - y0 };
}
const clipBlank = () => clipActive() && CLIP.blank;
/* 캔버스(PNG · 위성 사진)에 구역 모양 경로 — 화면 좌표 → 출력 틀 기준 */
function clipCanvasPath(ctx, f, dpr){
  ctx.beginPath();
  for(const poly of CLIP.geom || []) for(const r of poly) r.forEach((p, i) => { const q = map.project(p), x = (q.x - f.x) * dpr, y = (q.y - f.y) * dpr; if(i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
}

/* ---------- 패널 ---------- */
function clipRender(){
  const list = document.getElementById('cliplist'), nm = document.getElementById('clipname');
  if(nm) nm.textContent = clipName();
  if(list){
    if(!CLIP.regions.length) list.innerHTML = '아직 고른 구역이 없습니다. 이름으로 찾거나, "지도에서 누르기"로 고르세요. 고른 뒤에 찾은 이름 옆 "+ 더하기"로 여러 곳을 같이 잡습니다.';
    else if(CLIP.split === 'custom') list.innerHTML = CLIP.regions.map((r, i) => `<div class="row"><span>${esc(r.name)}</span>`
        + `<input class="zin" data-i="${i}" type="text" value="${esc(r.zone || r.groupName || r.name)}" title="같은 이름끼리 한 덩어리로 묶습니다" style="width:84px;height:22px;flex:none;font-size:11px">`
        + `<button class="x" data-i="${i}" title="빼기">×</button></div>`).join('')
      + `<div class="row" style="margin-top:4px;color:var(--text-2)"><span>${CLIP.regions.length > 1 ? '합친 ' : ''}면적</span><span class="num">${Math.round(clipAreaKm2(CLIP.geom || [])).toLocaleString()} km²</span></div>`;
    else list.innerHTML = clipUnits().map(u => `<div class="row"><span>${esc(u.name)}${u.idx.length > 1 ? ` <small style="color:var(--text-3)">${u.idx.length}곳</small>` : ''}</span>`
        + `<button class="x" data-u="${esc(u.key)}" title="빼기">×</button></div>`).join('')
      + `<div class="row" style="margin-top:4px;color:var(--text-2)"><span>${CLIP.regions.length > 1 ? '합친 ' : ''}면적</span><span class="num">${Math.round(clipAreaKm2(CLIP.geom || [])).toLocaleString()} km²</span></div>`;
  }
  if(typeof map !== 'undefined' && map && map.boxZoom){ if(CLIP.picking) map.boxZoom.disable(); else map.boxZoom.enable(); }   // 누르는 동안 Shift+클릭이 상자 확대로 먹히지 않게
  const pk = document.getElementById('clippick');
  if(pk){ pk.classList.toggle('primary', CLIP.picking); pk.textContent = CLIP.picking ? '누를 때마다 더하고, 다시 누르면 빼요 (Esc)' : '지도에서 누르기'; }
  const fit = document.getElementById('clipfit'); if(fit) fit.disabled = !CLIP.geom;
  for(const [id, k] of [['clipon', 'on'], ['clipblank', 'blank'], ['clipedge', 'edge'], ['clipdetail', 'detail'], ['clipbld', 'bld']]){ const e = document.getElementById(id); if(e) e.checked = !!CLIP[k]; }
  { const o = document.getElementById('clipout'); if(o) o.value = CLIP.out || 'blank'; }
  for(const id of ['clipblank', 'clipedge', 'clipout']){ const e = document.getElementById(id); if(e) e.disabled = !CLIP.on; }
  const b = document.getElementById('clipbld'); if(b) b.disabled = !CLIP.detail;
  // 나누기
  if(CLIP.split === 'old' && CLIP.regions.length && !clipHasOld()) CLIP.split = 'region';
  const sp = document.getElementById('clipsplit');
  if(sp){
    const lv = CLIP.regions.length ? CLIP.regions[0].level : CLIP.level;
    const subName = lv === 'sido' ? '시군구' : lv === 'sigungu' ? '읍면동' : '';
    const o = v => sp.querySelector(`option[value="${v}"]`);
    o('old').hidden = !clipHasOld();
    o('sub').hidden = !subName; o('sub').textContent = '한 단계 아래로 (' + (subName || '없음') + ')';
    sp.value = CLIP.split; sp.disabled = !CLIP.regions.length;
  }
  const zb = document.getElementById('clipzopts'); if(zb) zb.hidden = CLIP.split === 'none';
  for(const [id, k] of [['clipzfill', 'zfill'], ['clipzlabel', 'zlabel']]){ const e = document.getElementById(id); if(e) e.checked = !!CLIP[k]; }
  const zl = document.getElementById('clipzones');
  if(zl){
    zl.innerHTML = CLIP.zones ? CLIP.zones.map(z => `<span class="zchip"><i style="background:${z.color}"></i>${esc(z.name)}</span>`).join('')
      : CLIP.split === 'sub' ? '<span class="zchip">받는 중…</span>' : CLIP.split !== 'none' && CLIP.regions.length ? '<span class="zchip">한 덩어리뿐이라 나누지 않습니다</span>' : '';
  }
  if(typeof segSync === 'function' && document.getElementById('cliplevel')) segSync('cliplevel', CLIP.level);
  // 대지분석 내보내기 탭 — 지도 꾸미기에서 고른 구역으로 잘린다는 것만 알립니다
  const sn = document.getElementById('stclipnote');
  if(sn){
    const on = !!(CLIP.on && CLIP.geom);
    sn.hidden = !on;
    if(on) sn.textContent = `행정구역(${clipName()}) 모양으로 잘라 내보냅니다. 바꾸거나 끄려면 지도 꾸미기 › 출력 › 행정구역으로 자르기.`;
  }
}
/* 이름 → 짧은 이름 (시도는 그대로, 나머지는 끝 두 마디: "창원시 의창구", "성산구 상남동") */
const clipShort = (level, full) => { const p = String(full || '').split(' '); return level === 'sido' ? full : p.length > 2 ? p.slice(-2).join(' ') : p[p.length - 1]; };
const clipItem = (level, code, full) => ({ level, code:String(code), name:clipShort(level, full), full, parent:String(full).split(' ').slice(0, -1).join(' ') });
/* 이름 찾기 — 브이월드 검색(행정구역)으로 찾고, 모양은 고를 때 코드로 받습니다
   (데이터 API 의 like 는 앞부분 일치만 돼서 "의창구"처럼 중간 이름은 못 찾습니다) */
async function clipSearch(){
  const qv = document.getElementById('clipq').value.trim(), box = document.getElementById('clipres');
  if(!qv){ box.hidden = true; return; }
  const S0 = CLIP_SRC[CLIP.level], cat = { sido:'L1', sigungu:'L2', emd:'L4' }[CLIP.level];
  box.hidden = false; box.innerHTML = '<p>찾는 중…</p>';
  try{
    let items = (await vwSearch(qv, 'district', cat, 60)).map(it => clipItem(CLIP.level, it.id, it.title));
    if(!items.length && CLIP.level === 'sido'){                                 // "경남"처럼 줄인 이름 — 앞부분 일치로 한 번 더
      const r = await clipQuery('sido', { attrFilter:`ctp_kor_nm:like:${qv}`, geometry:'false', size:'20' });
      items = r.features.map(f => clipItem('sido', S0.cd(f.properties || {}), S0.full(f.properties || {})));
    }
    if(!items.length){ box.innerHTML = `<p>${S0.name}에서 "${esc(qv)}"을(를) 찾지 못했습니다. 위에서 단계를 바꿔 보세요.</p>`; return; }
    // 같은 상위 구역에 둘 이상 걸리면 "전체" 묶음을 맨 위에 (예: 창원시 5개 구 → 창원시 전체)
    const groups = new Map(); for(const it of items) if(it.parent && CLIP.level !== 'sido'){ if(!groups.has(it.parent)) groups.set(it.parent, []); groups.get(it.parent).push(it); }
    CLIP.found = items; CLIP.foundGroups = [...groups].filter(([, l]) => l.length > 1);
    const add = (k, v) => CLIP.regions.length ? `<button class="add" data-${k}="${v}" title="지금 고른 구역에 더하기">+ 더하기</button>` : '';
    box.innerHTML = CLIP.foundGroups.map(([g, l], i) => `<div class="resrow"><button data-g="${i}"><em>합치기</em>${esc(g.split(' ').pop())} 전체<small>${esc(g)} · ${l.length}곳을 하나로</small></button>${add('g', i)}</div>`).join('')
      + items.map((it, i) => `<div class="resrow"><button data-i="${i}"><em>${S0.name}</em>${esc(it.name)}<small>${esc(it.full)}</small></button>${add('i', i)}</div>`).join('');
  }catch(err){ box.innerHTML = `<p>찾지 못했습니다 — ${esc(err.message)}</p>`; }
}
/* 모드를 바꾸면 '지도에서 누르기'를 멈춥니다 (대지분석의 필지 고르기와 겹치지 않게) */
function clipStopPick(){
  if(!CLIP.picking) return;
  CLIP.picking = false;
  if(typeof map !== 'undefined' && map) map.getCanvas().style.cursor = '';
  clipRender();
}
(function hookClip(){
  if(typeof map === 'undefined' || !map || !map.on || !document.getElementById('clipsec')){ setTimeout(hookClip, 400); return; }
  const $c = id => document.getElementById(id);
  $c('cliplevel').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; CLIP.level = b.dataset.v; clipSave(); clipRender(); if($c('clipq').value.trim()) clipSearch(); });
  $c('clipgo').addEventListener('click', clipSearch);
  $c('clipq').addEventListener('keydown', e => { if(e.key === 'Enter') clipSearch(); });
  $c('clipres').addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    const add = b.classList.contains('add') || e.shiftKey;                // 이름을 누르면 그것만, "+ 더하기"는 지금 구역에 더함
    if(b.dataset.g != null){
      const [g, l] = CLIP.foundGroups[+b.dataset.g], gn = g.split(' ').pop();
      clipAdd(l.map(it => ({ ...it, group:g, groupName:gn })), !add);
    }else clipAdd([CLIP.found[+b.dataset.i]], !add);
    $c('clipres').hidden = true;
  });
  $c('cliplist').addEventListener('click', e => {
    const b = e.target.closest('.x'); if(!b) return;
    if(b.dataset.u != null){ const u = clipUnits().find(x => x.key === b.dataset.u); if(u){ const drop = new Set(u.idx); CLIP.regions = CLIP.regions.filter((r, i) => !drop.has(i)); } }
    else clipDrop(+b.dataset.i);
    clipRebuild();
  });
  $c('clipclear').addEventListener('click', () => { CLIP.regions = []; CLIP.picking = false; map.getCanvas().style.cursor = ''; clipRebuild(); clipNote(''); });
  $c('clipfit').addEventListener('click', clipFit);
  $c('clippick').addEventListener('click', () => { CLIP.picking = !CLIP.picking; map.getCanvas().style.cursor = CLIP.picking ? 'crosshair' : ''; clipRender(); });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && CLIP.picking){ CLIP.picking = false; map.getCanvas().style.cursor = ''; clipRender(); } });
  map.on('click', async e => {
    if(!CLIP.picking || !clipMode()) return;
    clipNote('구역 찾는 중…');
    try{
      const S0 = CLIP_SRC[CLIP.level];
      const r = await clipQuery(CLIP.level, { geomFilter:`POINT(${e.lngLat.lng} ${e.lngLat.lat})`, geometry:'true', size:'5' });
      const f = r.features[0]; if(!f){ clipNote('그 자리에서 ' + S0.name + '을(를) 찾지 못했습니다 (바다일 수 있습니다)', true); return; }
      const p = f.properties || {}, it = clipItem(CLIP.level, S0.cd(p), S0.full(p));
      const at = CLIP.regions.findIndex(x => x.level === it.level && x.code === it.code);
      if(at >= 0){ clipDrop(at); clipNote(it.name + '을(를) 뺐습니다'); clipRebuild(); return; }   // 고른 구역을 다시 누르면 뺌
      await clipAdd([{ ...it, geom:asMP(f.geometry) }], false);
    }catch(err){ clipNote('구역을 찾지 못했습니다 — ' + err.message, true); }
  });
  const opt = (id, k, fn) => $c(id).addEventListener('change', e => { CLIP[k] = e.target.checked; clipSave(); clipRender(); if(fn) fn(); });
  const zoneRedraw = () => { clipZonesBuild(); clipRender(); registerClipLayers(); apply(); };
  $c('clipsplit').addEventListener('change', e => {
    const prev = CLIP.split, v = e.target.value;
    if(v === 'custom') for(const r of CLIP.regions) r.zone = clipZoneOf(r, prev === 'none' ? 'region' : prev);   // 직접 묶기는 지금 묶음에서 시작
    CLIP.split = v; clipSave();
    if(v === 'sub' && !(CLIP.subs && CLIP.subs.key === clipKey0())){ CLIP.zones = null; clipRender(); registerClipLayers(); apply(); clipFetchSubs(); }
    else zoneRedraw();
  });
  $c('cliplist').addEventListener('change', e => {
    const inp = e.target.closest('.zin'); if(!inp) return;
    const r = CLIP.regions[+inp.dataset.i]; if(!r) return;
    r.zone = inp.value.trim() || r.name; zoneRedraw();
  });
  opt('clipzfill', 'zfill', () => { registerClipLayers(); apply(); });
  opt('clipzlabel', 'zlabel', () => { registerClipLayers(); apply(); });
  opt('clipon', 'on', () => { registerClipLayers(); apply(); });
  opt('clipblank', 'blank');
  $c('clipout').addEventListener('change', e => { CLIP.out = e.target.value; clipSave(); clipRender(); });
  opt('clipedge', 'edge', () => { registerClipLayers(); apply(); });
  opt('clipdetail', 'detail', () => { CLIP.token++; CLIP.hires = null; CLIP.busy = false; registerClipLayers(); apply(); if(CLIP.detail && CLIP.geom) clipFetchHiRes(); else clipNote(''); });
  opt('clipbld', 'bld', () => { CLIP.token++; CLIP.hires = null; CLIP.busy = false; registerClipLayers(); apply(); if(CLIP.detail && CLIP.geom) clipFetchHiRes(); });
  clipRender();
})();
