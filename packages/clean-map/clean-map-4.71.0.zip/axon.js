/* ============================================================
   축측 SVG 내보내기 — 평평한 바닥 위의 스케치업 같은 매스 다이어그램
   · 도로: 위계별 폭의 면
   · 분석 레이어: 지금 켜 둔 축·원·등고 등을 바닥에
   · 건물: 층수 × 층고로 세웁니다 (흰 윗면·회색 벽·검은 모서리)
   ============================================================ */
const AX = { busy:false };
const AX_MOD = [[/^(tr-|kt-)/, '교통·가로망'], [/^bus-/, '대중교통'], [/^biz-/, '상권'], [/^pop-/, '인구·사업체'], [/^sun-/, '일조'], [/^wind-/, '바람'],
                [/^life-/, '15분 생활권'], [/^tour-/, '관광·문화'], [/^hub-/, '거점 연결망'], [/^site-/, '대지'], [/^clip-/, '행정구역']];
const AX_TOP = /^(biz-cir|pop-cir|tour-cir|tour-[0-9]|tr-node|tr-front|hub-|wind-|bus-catch-dot|bus-hub|bus-near|bus-stop|bus-dot|bus-gap-dot|kt-|life-(?!iso)|site-boundary|biz-pt|biz-mix|pop-dots)/;
const axIsTop = id => AXV.allTop || AX_TOP.test(id);
const axModOf = id => { for(const [re, n] of AX_MOD) if(re.test(id)) return n; return '기타'; };
/* [{id, html}] → 항목별 <g> 로 감싸기 (순서 유지, 같은 항목은 처음 나온 자리에 모음) */
function groupByModule(items){
  // 같은 항목이라도 면과 표지(거점 원·점)는 따로 묶어, 표지가 다른 항목의 면 아래로 깔리지 않게 합니다
  const wOf = id => typeof extraWeight === 'function' ? extraWeight(id) : 0;
  const order = [], by = new Map();
  for(const it of items){ const m = axModOf(it.id), k = m + '|' + wOf(it.id); if(!by.has(k)){ by.set(k, []); order.push(k); } by.get(k).push(it.html); }
  return order.map(k => { const [m, w] = k.split('|'); return `<g id="${m}${w === '1' ? '_거점·표지' : ''}">${by.get(k).join('')}</g>`; }).join('');
}
/* 건물 용도 색 — 켜 두면 매스 윗면을 용도 색으로, 벽은 그 색을 모서리 색 쪽으로 조금 어둡게.
   숨긴 용도는 매스에서 뺍니다. 정보 없는 건물은 스타일의 매스 색 그대로 */
const axUseOn = () => typeof useActive === 'function' && useActive();
function axUseOf(pr){ return { show:true, u:axUseOn() ? (useHi(pr) || '') : '' }; }     // u: 켠 용도일 때만 이름 (나머지는 매스 색)
const axTopColor = (b, st) => b.u ? useColor(b.u, st.mass) : st.mass;
/* 방위 — 땅 위에 놓인 원(투영하면 타원)과 북쪽 화살. gv(동, 북) → 그 땅 벡터의 화면 이동량 */
function axNorthSVG(gv, cx, cy, st){
  if(typeof NS !== 'undefined' && NS.compass === 'none') return '';
  const ring = []; for(let i = 0; i <= 48; i++){ const t = i / 48 * 2 * Math.PI; ring.push(gv(Math.cos(t), Math.sin(t))); }
  const R = Math.max(...ring.map(([x, y]) => Math.hypot(x, y))) || 1, k = 34 / R;
  const S = (x, y) => { const [a, b] = gv(x, y); return (cx + a * k).toFixed(1) + ',' + (cy + b * k).toFixed(1); };
  const ringD = 'M' + ring.map(([a, b]) => (cx + a * k).toFixed(1) + ',' + (cy + b * k).toFixed(1)).join('L') + 'Z';
  const [lx, ly] = gv(0, 1.55);
  return `<g id="방위"><path d="${ringD}" fill="${st.paper}" stroke="${st.ink}" stroke-width="0.8"/>`
    + `<path d="M${S(0, 0.92)}L${S(-0.36, -0.62)}L${S(0, -0.3)}Z" fill="${st.ink}"/>`
    + `<path d="M${S(0, 0.92)}L${S(0.36, -0.62)}L${S(0, -0.3)}Z" fill="${st.paper}" stroke="${st.ink}" stroke-width="0.6" stroke-linejoin="round"/>`
    + `<text x="${(cx + lx * k).toFixed(1)}" y="${(cy + ly * k + 4).toFixed(1)}" text-anchor="middle" font-family="'Noto Sans CJK KR','Malgun Gothic',sans-serif" font-size="14" font-weight="bold" fill="${st.ink}">N</text></g>`;
}
/* 용도 범례 한 줄 — 왼쪽 아래, 정보 글 위 */
function axUseLegend(blds, x, y, st, FONT){
  if(!axUseOn()) return '';
  const cnt = new Map(); let rest = 0; for(const b of blds){ if(b.u) cnt.set(b.u, (cnt.get(b.u) || 0) + 1); else rest++; }
  const names = BLD_USES.map(u => u.name).filter(n => cnt.has(n));
  if(!names.length) return '';
  if(rest){ names.push('그 외'); cnt.set('그 외', rest); }
  const tw = t => [...t].reduce((w, ch) => w + (/[가-힣]/.test(ch) ? 12 : 7), 0);
  const o = ['<g id="범례_건물용도">']; let cx = x;
  for(const n of names){
    const t = `${n} ${cnt.get(n)}`;
    o.push(`<rect x="${cx}" y="${y}" width="13" height="13" fill="${n === '그 외' ? st.mass : useColor(n, st.mass)}" stroke="${st.massEdge}" stroke-width="0.6"/>`,
           `<text x="${cx + 19}" y="${y + 11}" ${FONT} font-size="12" fill="${st.ink}" fill-opacity="0.85">${esc(t)}</text>`);
    cx += 19 + tw(t) + 20;
  }
  o.push('</g>');
  return o.join('');
}
/* 보기 각도 — 회전(도)과 기울기(도). 패널 선택과 미리보기 창의 슬라이더가 같이 씁니다 */
const AXV = { rot:0, tilt:30, fade:0.35, amt:0.94, shape:'rect', layout:'single', gapV:1.1, gapH:0.15, flatFill:true, thick:0.03,
  add:{}, combos:[{ id:'종합', pick:{ '지형':true, '도로':true } }], comboEnd:true };
  // add: 판마다 얹을 레이어 { 판:{ 레이어:true } } — 인구 판에 지형·도로를 얹는 식
  // thick: ISO 판 두께 (판 반폭 대비, 0.03 = 3%)
  // combos: 덧붙인 판(종합 판) 목록 — 고른 레이어만으로 한 판 · comboEnd: 덧붙인 판을 끝(위·오른쪽)에   // fade: 페이드 범위(영역 반폭 대비), amt: 페이드 정도(0 그대로 – 1 거의 사라짐)

/* ---------- 내보내기 ---------- */
async function exportAxon(){
  if(!hasRef()){ toast('먼저 대지를 정하거나 화면 범위를 고정하세요'); return; }
  if(AX.busy) return;
  AX.busy = true; const btn = $('axrun'); btn.disabled = true;
  const say = m => { $('axnote').textContent = m; };
  try{
    const st = ST(), FR = focusR(), focus = focusGeomM();
    let x0, y0, x1, y1;
    if(SITE.range === 'view' && SITE.viewLL){ [[x0, y0], [x1, y1]] = viewRectM(); } else { x0 = -FR; y0 = -FR; x1 = FR; y1 = FR; }
    // 지형은 넣지 않습니다 (평평한 바닥) — 지형 모형은 스케치업에서
    const exag = 1, T = { plates:[], base:0, step:0, lo:0, hi:0 };
    const levelAt = () => 0;
    // 2) 도로 — 받아 둔 도로가 없으면 지도 타일에서 바로 읽습니다
    say('도로 받는 중'); await sleep(0);
    // 출력 1px 이 몇 m 인지 — 넓은 범위는 도로를 낮은 줌 타일로 받고 선으로 그립니다 (영역 ISO 와 같은 기준)
    const mppA = ((x1 - x0) + (y1 - y0)) * Math.cos(AXV.tilt * Math.PI / 180) / 1720, lineA = mppA > ROAD_LINE_MPP;
    let ways = (TR.ways && TR.ways.length) ? TR.ways : null;
    if(!ways && lineA){
      const [w0, s0] = toLL([x0, y0]), [e0, n0] = toLL([x1, y1]);
      const raw = await hiResRoads(s0, w0, n0, e0, null, { zMax:roadTileZoom(mppA, (s0 + n0) / 2), zMin:7, maxTiles:80, progress:(d, t, z) => say(`도로 읽는 중 ${d}/${t} (지도 타일 z${z})`) });
      ways = raw.filter(e => e.type === 'way' && e.geometry).map(wayInfo).filter(Boolean);
    }
    if(!ways){ const raw = await fetchRoads(FR + 100, null); ways = raw.filter(e => e.type === 'way' && e.geometry).map(wayInfo).filter(Boolean); }
    say('도로 정리 중'); await sleep(0);
    let roads = [], roadLinesA = null;
    if(lineA) roadLinesA = roadLineGroups(ways.filter(w => w.c !== 6), mppA, focus);
    else{
      const byW = new Map();
      for(const w of ways){ if(w.c === 6 && !$('axfoot').checked) continue; const k = Math.max(2, w.w) / 2; if(!byW.has(k)) byW.set(k, []); byW.get(k).push(...clipToFocus(w.pts)); }
      const roadParts = []; for(const [hw, lines] of byW) if(lines.length) roadParts.push(offsetLines(lines, hw));
      roads = roadParts.length ? cleanMP(union(roadParts), { close:0.5, open:0, minPiece:4, minHole:4, simplify:0.4 }) : [];
    }
    // 3) 건물
    say('건물 정리 중'); await sleep(0);
    const fc = VW.data && VW.data.building_kr, fh = S.bldFH || 3, blds = [];
    if(fc) for(const f of fc.features){
      for(const poly of asMulti(f.geometry)){
        let ring = poly[0].map(toM); if(ringArea(ring) < 0) ring = ring.slice().reverse();   // 반시계로 맞춰야 앞·뒤 벽 판별이 맞습니다
        const c = centroidOf([[ring]]);
        if(!inFocus(c)) continue;
        if(SITE.exclude && SITE.geom && pointInMulti(c, mapRings(SITE.geom, toM))) continue;
        const us = axUseOf(f.properties); if(!us.show) continue;
        blds.push({ ring:ring.slice(0, -1), z0:levelAt(c[0], c[1]), h:(floorsOf(f.properties) || 1) * fh, c, u:us.u });
      }
    }
    // 4) 투영 — 보는 방향만큼 돌린 뒤 축측
    const view = 225 + AXV.rot, ang = AXV.tilt;
    const th = (view - 225) * Math.PI / 180, ct = Math.cos(th), sn = Math.sin(th);
    const Cc = Math.cos(ang * Math.PI / 180), Sc = Math.sin(ang * Math.PI / 180);
    const R = (x, y) => [x * ct - y * sn, x * sn + y * ct];
    const proj = (x, y, z) => { const [a, b] = R(x, y); return [(a - b) * Cc, -((a + b) * Sc + z)]; };
    const zT = v => (v - T.base) * exag;                               // 지형 높이 (과장)
    // 화면 맞춤
    let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
    const hMax = blds.reduce((m, b) => Math.max(m, zT(b.z0) + b.h), zT(T.hi));
    for(const [x, y] of [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]) for(const z of [0, hMax]){ const [px, py] = proj(x, y, z); bx0 = Math.min(bx0, px); bx1 = Math.max(bx1, px); by0 = Math.min(by0, py); by1 = Math.max(by1, py); }
    const legH = axUseOn() && blds.length ? 26 : 0;
    const OUTW = 1800, pad = 40, sc = (OUTW - pad * 2) / (bx1 - bx0), OUTH = Math.round((by1 - by0) * sc + pad * 2) + legH;
    const P = (x, y, z) => { const [px, py] = proj(x, y, z); return ((px - bx0) * sc + pad).toFixed(1) + ',' + ((py - by0) * sc + pad).toFixed(1); };
    const ringD = (ring, zf) => 'M' + ring.map(([x, y]) => P(x, y, zf(x, y))).join('L') + 'Z';
    const mpD = (mp, zf) => mp.map(poly => poly.map(r => ringD(r, zf)).join('')).join('');
    const dark = (() => { const c = st.paper.replace('#', ''); return (parseInt(c.slice(0, 2), 16) + parseInt(c.slice(2, 4), 16) + parseInt(c.slice(4, 6), 16)) / 3 < 110; })();
    const plateTop = k => hexMix(st.paper, st.ink, dark ? 0.10 + 0.05 * (k % 2) : 0.035 + 0.03 * (k % 2));
    const plateSide = hexMix(st.paper, st.ink, dark ? 0.28 : 0.16), plateEdge = hexMix(st.paper, st.ink, dark ? 0.45 : 0.32);
    const roadFill = dark ? hexMix(st.paper, st.ink, 0.22) : st.paper, roadEdge = hexMix(st.paper, st.ink, 0.38);
    const out = [`<svg xmlns="http://www.w3.org/2000/svg" width="${OUTW}" height="${OUTH}" viewBox="0 0 ${OUTW} ${OUTH}">`, `<rect width="100%" height="100%" fill="${st.paper}"/>`];
    // 5) 바닥판 (가장 낮은 판 = 범위 전체)
    say('그리는 중'); await sleep(0);
    out.push(`<g id="바닥"><path d="${mpD(focus, () => 0)}" fill="${plateTop(0)}" stroke="${plateEdge}" stroke-width="0.6"/></g>`);
    // 판마다: 옆면(한 단 아래) → 윗면 → 그 판 위의 도로
    const regions = T.plates.map(p => p.g);
    out.push('<g id="지형_등고판">');
    const roadByLevel = [];
    T.plates.forEach((p, k) => {
      const zTop = zT(p.L), zBot = zT(p.L - T.step);
      out.push(`<path d="${mpD(p.g, () => zBot)}" fill="${plateSide}"/>`);
      out.push(`<path d="${mpD(p.g, () => zTop)}" fill="${plateTop(k + 1)}" stroke="${plateEdge}" stroke-width="0.6" fill-rule="evenodd"/>`);
    });
    out.push('</g>');
    // 도로: 판 사이 띠마다 잘라 그 높이에
    out.push('<g id="도로">');
    const bandOf = k => { const top = regions[k], next = regions[k + 1]; return next ? diff(top, next) : top; };
    if(roadLinesA){
      const col = hexMix(st.paper, st.ink, dark ? 0.72 : 0.62);
      for(const [k, ls] of roadLinesA) out.push(`<path d="${ls.map(l => 'M' + l.map(([x, y]) => P(x, y, 0)).join('L')).join('')}" fill="none" stroke="${col}" stroke-width="${k}" stroke-linecap="round" stroke-linejoin="round"/>`);
    }
    if(roads.length){
      const ground = regions.length ? diff(roads, regions[0]) : roads;
      if(ground.length) out.push(`<path d="${mpD(ground, () => 0)}" fill="${roadFill}" stroke="${roadEdge}" stroke-width="0.45" fill-rule="evenodd"/>`);
      T.plates.forEach((p, k) => {
        const g = inter(roads, bandOf(k)); if(!g.length) return;
        out.push(`<path d="${mpD(g, () => zT(p.L))}" fill="${roadFill}" stroke="${roadEdge}" stroke-width="0.45" fill-rule="evenodd"/>`);
      });
    }
    out.push('</g>');
    // 6) 분석 레이어 — 지금 켜 둔 것 그대로, 판 높이에 얹기
    const zAt = (x, y) => zT(levelAt(x, y)) + 0.4;
    out.push('<g id="분석">');
    const axItems = [], axTop = [];
    const order = { ground:0, fill:1, line:2, top:3 };
    const L = [...EXTRA.layers.entries()].filter(([id, d]) => !/^d3-/.test(id) && !d.noExport && d.fc && d.fc.features.length && d.type !== 'symbol').sort((a, b) => order[a[1].stage] - order[b[1].stage] || (typeof extraWeight === 'function' ? extraWeight(a[0]) - extraWeight(b[0]) : 0));
    for(const [id, d] of L){
      const sv = d.svg || {}, parts = [];
      for(const f of d.fc.features){
        const g = f.geometry; if(!g) continue;
        if(g.type === 'Polygon' || g.type === 'MultiPolygon'){
          const mp = mapRings(g.type === 'Polygon' ? [g.coordinates] : g.coordinates, toM);
          parts.push(mpD(mp, zAt));
        }else if(/LineString/.test(g.type)){
          for(const ln of (g.type === 'LineString' ? [g.coordinates] : g.coordinates)){
            const m = ln.map(toM), dense = [];
            for(let i = 0; i < m.length; i++){                     // 판 경계에서 꺾이도록 잘게
              if(i){ const a = m[i - 1], b = m[i], n = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 15); for(let t = 1; t < n; t++) dense.push([a[0] + (b[0] - a[0]) * t / n, a[1] + (b[1] - a[1]) * t / n]); }
              dense.push(m[i]);
            }
            parts.push('M' + dense.map(([x, y]) => P(x, y, zAt(x, y))).join('L'));
          }
        }
      }
      if(!parts.length) continue;
      const nm = String(d.label || id).replace(/^분석_/, '');
      const bucket = axIsTop(id) ? axTop : axItems;
      if(sv.kind === 'fill') bucket.push({ id, html:`<path id="${esc(nm)}" d="${parts.join('')}" fill="${sv.fill}" fill-opacity="${sv.opacity ?? 1}" fill-rule="evenodd"/>` });
      else bucket.push({ id, html:`<path id="${esc(nm)}" d="${parts.join('')}" fill="none" stroke="${sv.stroke}" stroke-width="${(sv.width || 1) * 1.1}" stroke-opacity="${sv.opacity ?? 1}" stroke-linecap="round" stroke-linejoin="round"${sv.dash ? ` stroke-dasharray="${sv.dash.map(v => v * Math.max(1, sv.width || 1)).join(' ')}"` : ''}/>` });
    }
    out.push(groupByModule(axItems), '</g>');
    // 7) 건물 — 뒤에서 앞으로, 흰 윗면·회색 벽·검은 모서리
    out.push('<g id="건물">');
    const depth = b => { const [a, c] = R(b.c[0], b.c[1]); return a + c; };
    blds.sort((p, q) => depth(q) - depth(p));
    // 건물 색: 윗면 = 고른 색, 벽 두 면은 그 색을 조금씩 어둡게
    const edge = st.massEdge;
    for(const b of blds){
      const top = axTopColor(b, st), wallA = hexMix(top, st.massEdge, 0.08), wallB = hexMix(top, st.massEdge, 0.18);   // 벽 그늘은 모서리 색 쪽으로
      const zb = zT(b.z0), zt = zb + b.h, rg = b.ring;
      const faces = [];
      for(let i = 0; i < rg.length; i++){
        const p = rg[i], q = rg[(i + 1) % rg.length];
        const [pa, pb] = R(p[0], p[1]), [qa, qb] = R(q[0], q[1]);
        const nx = qb - pb, ny = -(qa - pa);
        if(nx + ny > 0) continue;                                        // 뒤를 향한 벽은 생략
        faces.push({ d:`M${P(p[0], p[1], zb)}L${P(q[0], q[1], zb)}L${P(q[0], q[1], zt)}L${P(p[0], p[1], zt)}Z`, c:(nx - ny) < 0 ? wallA : wallB, k:-(pa + pb + qa + qb) });
      }
      faces.sort((u, v) => u.k - v.k);
      for(const f of faces) out.push(`<path d="${f.d}" fill="${f.c}" stroke="${edge}" stroke-width="0.55" stroke-linejoin="round"/>`);
      out.push(`<path d="M${rg.map(([x, y]) => P(x, y, zt)).join('L')}Z" fill="${top}" stroke="${edge}" stroke-width="0.65" stroke-linejoin="round"/>`);
    }
    out.push('</g>');
    if(axTop.length) out.push('<g id="분석_위">' + groupByModule(axTop) + '</g>');
    // 8) 정보
    { const o0 = proj(0, 0, 0); out.push(axNorthSVG((x, y) => { const a = proj(x, y, 0); return [(a[0] - o0[0]) * sc, (a[1] - o0[1]) * sc]; }, pad + 50, pad + 46, st)); }   // 방위 (왼쪽 위)
    if(legH) out.push(axUseLegend(blds, pad, OUTH - 44, st, `font-family="'Noto Sans CJK KR','Malgun Gothic',sans-serif"`));
    out.push(`<text x="${pad}" y="${OUTH - 14}" font-family="'Noto Sans CJK KR','Malgun Gothic',sans-serif" font-size="12" fill="${st.ink}" fill-opacity="0.7">${esc(rangeLabel())} · 건물 ${blds.length}동 (층수 × 층고 ${fh}m)</text>`);
    out.push('</svg>');
    showAxPreview({ svg:out.join(''), name:'_축측다이어그램.svg', title:'분석 범위 축측', kind:'axon', rerun:exportAxon });
    say(`완료 · 건물 ${blds.length}동 · 도로 ${roads.length || (roadLinesA && roadLinesA.size) ? '포함' : '없음'}` + (roadLinesA ? ' (넓은 범위라 도로를 선으로 간소화)' : '') + (blds.length ? '' : ' (건물이 없으면 줌 15 이상에서 건물_국내를 받아 두세요)'));
  }catch(err){ console.error('[대지분석] 축측 실패', err); say('실패 — ' + err.message); }
  AX.busy = false; btn.disabled = false;
}
$('axrun').addEventListener('click', exportAxon);
$('axview').addEventListener('change', e => { AXV.rot = (+e.target.value - 225 + 360) % 360; });
$('axang').addEventListener('change', e => { AXV.tilt = +e.target.value; });
$('isoview').addEventListener('change', e => { AXV.rot = +e.target.value; AXV.tilt = 30; });
$('isofade').addEventListener('change', e => { const v = e.target.value; AXV.amt = v === 'flat' ? 0 : 0.94; AXV.fade = v === 'flat' ? 0.35 : +v; });

/* ============================================================
   영역 ISO 따기 — 사각형 또는 원으로 영역을 잘라 판(두께 있는 바닥) 위에 지형·매스·도로·분석을 축측으로
   · 한 판: 모두 겹쳐서. 영역 밖 도로·분석은 연해지게
   · 세로로 분리 / 가로로 분리: 지형·가구·도로·분석 항목·매스를 판마다 띄워 배열 (간격 조절)
   · 지형 위 면 다이어그램(밀도 면·거점 원 등)은 지형에 입히면 모양이 일그러지므로 덩어리마다 평평하게 띄웁니다.
     선(도로·축·노선)은 지형을 따라갑니다.
   ============================================================ */
const ISO = { pick:false, box:null, start:null, roadCache:null };
/* ---------- 넓은 범위 간소화 ----------
   출력 그림에서 1px 이 몇 m 인지(mpp)에 맞춰 도로를 다룹니다.
   · 도로 타일은 그만큼만 자세한 줌으로 받습니다 (넓으면 낮은 줌 — 큰 길만, 모양도 이미 간소화된 타일)
   · 1px 이 ROAD_LINE_MPP m 보다 넓으면 (대략 반지름 3km 이상) 도로를 폭 있는 면(오프셋·합치기 — 넓으면 몇 분씩 걸려 '응답 없음')
     대신 굵기만 다른 선으로 그립니다. 그 축척에서는 도로 폭이 1px 도 안 돼 눈으로는 같습니다 */
const ROAD_LINE_MPP = 4;
const ROAD_LINE_PX = [1.7, 1.35, 1.0, 0.75, 0.5, 0.35, 0.3];          // 위계별 선 굵기 (px) — 고속·주간선·보조간선·집산·국지·이면·보행
function roadTileZoom(mpp, lat){
  return Math.max(8, Math.min(14, Math.floor(Math.log2(40075016.686 * Math.cos(lat * Math.PI / 180) / (256 * mpp))) + 1));
}
/* 열린 선 더글러스–포이커 */
function simplifyLine(pts, tol){
  if(pts.length < 3) return pts;
  const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1;
  const stack = [[0, pts.length - 1]];
  while(stack.length){
    const [a, b] = stack.pop(), [ax, ay] = pts[a], [bx, by] = pts[b], L = Math.hypot(bx - ax, by - ay) || 1e-9;
    let md = 0, mi = -1;
    for(let i = a + 1; i < b; i++){ const d = Math.abs((bx - ax) * (ay - pts[i][1]) - (ax - pts[i][0]) * (by - ay)) / L; if(d > md){ md = d; mi = i; } }
    if(md > tol && mi > 0){ keep[mi] = 1; stack.push([a, mi], [mi, b]); }
  }
  return pts.filter((_, i) => keep[i]);
}
/* 도로 → 굵기별 선 묶음 Map(px → [선]) — 간소화하고 그릴 범위(mp) 안으로 자름 */
function roadLineGroups(ways, mpp, mp){
  const g = new Map();
  for(const x of ways){
    const px = Math.min(2.6, Math.max(x.w / mpp, ROAD_LINE_PX[x.c] || 0.3)), k = (Math.round(px * 20) / 20).toFixed(2);
    const s = simplifyLine(x.pts, mpp * 0.4); if(s.length < 2) continue;
    if(!g.has(k)) g.set(k, []); g.get(k).push(s);
  }
  if(mp) for(const [k, ls] of g){ const c = clipLinesMP(ls, mp); if(c.length) g.set(k, c); else g.delete(k); }
  return g;
}
const tick = () => new Promise(r => setTimeout(r, 0));             // 화면이 멈추지 않게 한 번씩 쉬어 갑니다
/* 열린 선을 다각형 안으로 자르기 (Clipper 열린 경로) */
function clipLinesMP(lines, mp){
  if(!lines.length || !mp.length) return [];
  const C = CL(); const c = new C.Clipper();
  for(const l of lines) if(l.length > 1) c.AddPath(l.map(([x, y]) => ({ X:Math.round(x * CLS), Y:Math.round(y * CLS) })), C.PolyType.ptSubject, false);
  c.AddPaths(toPaths(mp), C.PolyType.ptClip, true);
  const tree = new C.PolyTree(); c.Execute(C.ClipType.ctIntersection, tree, C.PolyFillType.pftNonZero, C.PolyFillType.pftNonZero);
  return C.Clipper.OpenPathsFromPolyTree(tree).map(p => p.map(q => [q.X / CLS, q.Y / CLS]));
}
/* 표고 격자 → 경위도 표본 함수 (표고 타일, 이중선형) */
async function demSampler(w, s, e, n){
  const t2x = (lng, z) => Math.floor((lng + 180) / 360 * 2 ** z);
  const t2y = (lat, z) => { const r = lat * Math.PI / 180; return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 2 ** z); };
  // 16장 안에 드는 가장 고운 줌 — 넓은 영역(시도 단위)은 z8 아래까지 내려갑니다.
  // (예전에는 z9 에서도 16장이 넘으면 z8 로 내려가면서 타일 번호는 z9 것을 써서 표고를 못 받고 평평하게 그렸습니다)
  let z = 14, tx0, tx1, ty0, ty1;
  for(;; z--){ tx0 = t2x(w, z); tx1 = t2x(e, z); ty0 = t2y(n, z); ty1 = t2y(s, z); if((tx1 - tx0 + 1) * (ty1 - ty0 + 1) <= 16 || z <= 4) break; }
  const W = (tx1 - tx0 + 1) * 256, H = (ty1 - ty0 + 1) * 256, full = new Float32Array(W * H);
  await Promise.all([...Array((ty1 - ty0 + 1) * (tx1 - tx0 + 1)).keys()].map(async k => {
    const tx = tx0 + k % (tx1 - tx0 + 1), ty = ty0 + Math.floor(k / (tx1 - tx0 + 1));
    const t = await fetchDemTile(z, tx, ty), ox = (tx - tx0) * 256, oy = (ty - ty0) * 256;
    for(let r = 0; r < 256; r++) full.set(t.subarray(r * 256, r * 256 + 256), (oy + r) * W + ox);
  }));
  const scale = 256 * 2 ** z;
  return (x, y) => {
    const [lng, lat] = toLL([x, y]);
    const px = (lng + 180) / 360 * scale - tx0 * 256, r = lat * Math.PI / 180;
    const py = (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * scale - ty0 * 256;
    const i = Math.max(0, Math.min(W - 2, Math.floor(px))), j = Math.max(0, Math.min(H - 2, Math.floor(py)));
    const fx = Math.max(0, Math.min(1, px - i)), fy = Math.max(0, Math.min(1, py - j));
    const v = full[j * W + i] * (1 - fx) * (1 - fy) + full[j * W + i + 1] * fx * (1 - fy) + full[(j + 1) * W + i] * (1 - fx) * fy + full[(j + 1) * W + i + 1] * fx * fy;
    return Math.max(0, v);                                               // 바다(음수)는 0
  };
}
/* 이름 자리 — 가장 큰 조각의 무게중심, 그게 조각 밖이면 그 높이에서 가장 넓은 안쪽 구간의 가운데 */
function labelPtM(mp){
  let best = null, ba = 0;
  for(const poly of mp){ const a = Math.abs(ringArea(poly[0])); if(a > ba){ ba = a; best = poly; } }
  if(!best) return null;
  const c = centroidOf([best]);
  if(pointInMulti(c, [best])) return c;
  const y = c[1], xs = [];
  for(const r of best) for(let i = 1; i < r.length; i++){ const [ax, ay] = r[i - 1], [bx, by] = r[i]; if((ay > y) !== (by > y)) xs.push(ax + (y - ay) * (bx - ax) / (by - ay)); }
  xs.sort((p, q) => p - q); let w = 0, out = c;
  for(let i = 0; i + 1 < xs.length; i += 2) if(xs[i + 1] - xs[i] > w){ w = xs[i + 1] - xs[i]; out = [(xs[i] + xs[i + 1]) / 2, y]; }
  return out;
}
/* 영역 ISO 에 얹을 행정구역 — 지도 꾸미기 › 출력 › 행정구역으로 자르기에서 고른 구역.
   판 좌표(m)로 옮기고 출력 1px 보다 잘게 꺾인 변은 폅니다. 판이 통째로 구역 안이거나 밖이면 null (강조할 게 없음) */
function localMP(mp, mpp){
  const tol = mpp * 0.5, minA = (mpp * 2) ** 2, o = [];
  for(const poly of mp){
    const rs = [];
    for(const r of poly){
      if(r.length < 4) { if(!rs.length) break; continue; }
      const m = simplifyRing(r.map(toM), tol);
      if(m.length >= 4 && Math.abs(ringArea(m)) >= minA) rs.push(m);
      else if(!rs.length) break;                                           // 바깥 고리가 너무 작으면 조각째 버림
    }
    if(rs.length) o.push(rs);
  }
  return o;
}
/* 영역 ISO 의 물 — 바다(ocean)와 강·호수 면, 해안선(바다와 육지의 경계). 판 위만 */
function isoWaterGeom(list, region, mpp){
  if(!list || !list.length) return null;
  const sea = [], inl = [];
  for(const w of list){ const m = localMP(w.mp, mpp); if(m.length) (w.cls === 'ocean' ? sea : inl).push(m); }
  const seaU = union(sea), seaIn = inter(seaU, region);
  const inlIn = diff(inter(union(inl), region), seaIn);
  if(!seaIn.length && !inlIn.length) return null;
  // 해안선 = 바다 면의 테두리를 판 안으로 자른 것 (타일 바깥 끝은 판 밖이라 잘려 나감)
  return { sea:seaIn, inland:inlIn, coast:seaIn.length ? clipLinesMP(seaU.flat(), region) : [] };
}
function isoAdminGeom(region, outer, mpp){
  if(typeof CLIP === 'undefined' || !CLIP.geom || !CLIP.regions || !CLIP.regions.length) return null;
  const toMP = mp => localMP(mp, mpp);
  const geo = toMP(CLIP.geom), all = inter(geo, outer);
  if(!all.length || !diff(region, all).length) return null;
  const rings = geo.flat();
  // 구역별 면 — 나눠 고르면(구역 나누기) 나눈 구역마다, 아니면 고른 구역(시·구, '창원시 전체'처럼 묶은 것은 하나)마다.
  // 일러스트에서 구역마다 따로 칠하도록 면을 하나씩 따로 둡니다
  const COLS = typeof ZONE_COLORS !== 'undefined' ? ZONE_COLORS : ['#E0785A', '#4A86C8', '#6BAF7A', '#E3B341', '#9A73C9', '#4FB0AE'];
  const zoned = !!(CLIP.zones && CLIP.zones.length > 1);
  let src;
  if(zoned) src = CLIP.zones.map(z => ({ name:z.name, color:z.color, mp:toMP(z.geom) }));
  else{
    const units = typeof clipUnits === 'function' ? clipUnits() : CLIP.regions.map((r, i) => ({ name:r.name, idx:[i] }));
    src = units.length > 60 ? [] : units.map((u, k) => ({ name:String(u.name).replace(/ 전체$/, ''), color:COLS[k % COLS.length], mp:union(u.idx.map(i => toMP(CLIP.regions[i].geom || []))) }));
  }
  const parts = [], used = new Set();
  for(const q of src){
    const g = inter(q.mp, region); if(!g.length) continue;
    let id = q.name || '구역', k = 2; while(used.has(id)) id = q.name + '_' + (k++); used.add(id);
    parts.push({ name:q.name, id, color:q.color, g, p:labelPtM(g), mp:q.mp });
  }
  const prings = src.length > 1 ? src.flatMap(q => q.mp.flat()) : null;          // 구역 사이 경계 (점선)
  const labels = parts.filter(q => q.p).map(q => ({ name:q.name, p:q.p }));
  return { all, rings, parts, prings, labels, zoned };
}
const bboxOf = pts => { let x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18; for(const [x, y] of pts){ if(x < x0) x0 = x; if(y < y0) y0 = y; if(x > x1) x1 = x; if(y > y1) y1 = y; } return [x0, y0, x1, y1]; };
/* 상자가 겹치는 것끼리 한 덩어리로 (거점 원의 동심원 · 밀도 등고의 여러 단계가 한 덩어리가 되게) */
function clusterBoxes(items){
  let cur = items.map(it => ({ b:it.b.slice(), pts:it.pts }));
  for(let iter = 0; iter < 8; iter++){
    cur.sort((p, q) => p.b[0] - q.b[0]);
    const par = cur.map((_, i) => i), f = i => { while(par[i] !== i){ par[i] = par[par[i]]; i = par[i]; } return i; };
    let changed = false; const act = [];
    for(let i = 0; i < cur.length; i++){
      const bi = cur[i].b;
      for(let k = act.length - 1; k >= 0; k--) if(cur[act[k]].b[2] < bi[0]) act.splice(k, 1);
      for(const j of act){ const bj = cur[j].b; if(bj[1] <= bi[3] && bj[3] >= bi[1]){ const a = f(i), c = f(j); if(a !== c){ par[a] = c; changed = true; } } }
      act.push(i);
    }
    if(!changed) break;
    const g = new Map();
    cur.forEach((c, i) => {
      const r = f(i); if(!g.has(r)) g.set(r, { b:c.b.slice(), pts:[] });
      const t = g.get(r); t.b = [Math.min(t.b[0], c.b[0]), Math.min(t.b[1], c.b[1]), Math.max(t.b[2], c.b[2]), Math.max(t.b[3], c.b[3])];
      for(const p of c.pts) t.pts.push(p);
    });
    cur = [...g.values()];
  }
  return cur;
}
/* 원 밖으로 나간 선분 끝을 원 둘레로 자르기 (판 좌표) */
function clipSegCircle(p, q, R){
  const ip = Math.hypot(p[0], p[1]) <= R, iq = Math.hypot(q[0], q[1]) <= R;
  if(ip && iq) return [p, q];
  if(!ip && !iq) return null;
  const [a, b] = ip ? [p, q] : [q, p], dx = b[0] - a[0], dy = b[1] - a[1];
  const A2 = dx * dx + dy * dy, B2 = 2 * (a[0] * dx + a[1] * dy), C2 = a[0] * a[0] + a[1] * a[1] - R * R;
  const t = (-B2 + Math.sqrt(Math.max(0, B2 * B2 - 4 * A2 * C2))) / (2 * A2 || 1);
  return [a, [a[0] + dx * t, a[1] + dy * t]];
}
const PLATE_NAME = { '지형':'지형', '물':'바다·물', '행정구역':'행정구역', '가구':'가구 (블록)', '도로':'도로망', '매스':'건물 매스', '종합':'종합' };
const plateName = id => PLATE_NAME[id] || String(id).replace(/^종합(\d+)$/, '종합 $1');
const PLATE_SHORT = { '가구':'가구', '도로':'도로', '매스':'매스', '지형':'지형', '물':'물', '행정구역':'구역' };

async function exportIsoArea(quadLL){
  const say = m => { $('isonote').textContent = m; };
  try{
    if(!LOC){ const qx = quadLL.reduce((a, p) => a + p[0], 0) / 4, qy = quadLL.reduce((a, p) => a + p[1], 0) / 4; setLocal([qx, qy]); }
    const st = ST(), Q = quadLL.map(toM);
    const cx = (Q[0][0] + Q[2][0]) / 2, cy = (Q[0][1] + Q[2][1]) / 2;
    const e1 = [Q[1][0] - Q[0][0], Q[1][1] - Q[0][1]], e2 = [Q[3][0] - Q[0][0], Q[3][1] - Q[0][1]];
    const th = Math.atan2(e1[1], e1[0]);
    const circ = AXV.shape === 'circle';
    const R = Math.min(Math.hypot(...e1), Math.hypot(...e2)) / 2;                // 원: 그린 사각형에 내접
    const A = circ ? R : Math.hypot(...e1) / 2, B = circ ? R : Math.hypot(...e2) / 2;
    const layout = AXV.layout || 'single', split = layout !== 'single';
    const ph = AXV.rot * Math.PI / 180, cph = Math.cos(ph), sph = Math.sin(ph);
    const V = (u, v) => [u * cph - v * sph, u * sph + v * cph];               // 보기 회전 (판을 돌려 봄)
    const ct = Math.cos(-th), sn = Math.sin(-th), c2 = Math.cos(th), s2 = Math.sin(th);
    const L = (x, y) => { const dx = x - cx, dy = y - cy; return [dx * ct - dy * sn, dx * sn + dy * ct]; };   // 판 좌표
    const VL = (x, y) => { const [u, v] = L(x, y); return V(u, v); };
    const W2 = (u, v) => [cx + u * c2 - v * s2, cy + u * s2 + v * c2];
    const inside = (u, v) => circ ? Math.hypot(u, v) <= R : (Math.abs(u) <= A && Math.abs(v) <= B);
    const NCIR = 96;
    const regionW = e => circ
      ? [[Array.from({ length:NCIR + 1 }, (_, i) => { const t = (i % NCIR) / NCIR * 2 * Math.PI; return W2((R + e) * Math.cos(t), (R + e) * Math.sin(t)); })]]
      : [[[W2(-A - e, -B - e), W2(A + e, -B - e), W2(A + e, B + e), W2(-A - e, B + e), W2(-A - e, -B - e)]]];
    // 페이드 (한 판에서만): 범위(바깥으로 얼마나) × 정도(얼마나 연하게)
    const amt = AXV.amt == null ? 0.94 : AXV.amt, M = Math.max(A, B);
    const fadeW = split ? 0 : M * (AXV.fade || 0);
    const fadeIn = (!split && fadeW === 0 && amt > 0) ? Math.min(M * 0.15, Math.min(A, B) * 0.6) : 0;
    const NB = 6, bands = [{ g:regionW(-fadeIn), op:1 }], span = fadeIn + fadeW;
    if(span > 0) for(let k = 1; k <= NB; k++){
      const a0 = -fadeIn + span * (k - 1) / NB, a1 = -fadeIn + span * k / NB;
      bands.push({ g:diff(regionW(a1), regionW(a0)), op:Math.max(0.03, 1 - amt * (k - 0.5) / NB), out:fadeW > 0 });   // out: 판 밖 띠
    }
    const region = regionW(0), outer = regionW(fadeW);
    // 출력 1px 이 몇 m 인지 (판 지름이 그림 폭 약 1700px 에 들어감) — 넓으면 도로를 선으로 간소화
    const mpp = 2.45 * (M + fadeW) / 1700, lineMode = mpp > ROAD_LINE_MPP;
    // 행정구역 강조 — 고른 구역이 판에 걸쳐 있을 때만 (구역 밖 어둡게 · 경계 · 이름 · 나눈 구역 색)
    let adm = null;
    try{ adm = isoAdminGeom(region, outer, mpp); }catch(err){ console.warn(err); }
    const oLL = outer[0][0].map(toLL), w = Math.min(...oLL.map(p => p[0])), e = Math.max(...oLL.map(p => p[0])), s = Math.min(...oLL.map(p => p[1])), n = Math.max(...oLL.map(p => p[1]));
    // 지형 — 판 안의 가장 낮은 곳을 0으로
    const useT = $('isoterrain').checked, exag = Math.max(0.1, +$('isoexag').value || 1.5);
    let Zr = () => 0, zMin = 0, zMax = 0, tFail = false;
    if(useT){
      say('표고 받는 중');
      try{
        const Z = await demSampler(w, s, e, n);
        zMin = 1e9; zMax = -1e9;
        for(let i = 0; i <= 48; i++) for(let j = 0; j <= 48; j++){ const u = -A + 2 * A * i / 48, v = -B + 2 * B * j / 48; if(!inside(u, v)) continue; const [x, y] = W2(u, v), z = Z(x, y); zMin = Math.min(zMin, z); zMax = Math.max(zMax, z); }
        if(zMin > zMax){ zMin = zMax = 0; }
        Zr = (x, y) => (Z(x, y) - zMin) * exag;
      }catch(err){ console.warn(err); tFail = true; say('표고를 받지 못해 평평하게 그립니다'); }
    }
    const tTxt = !useT ? '' : tFail ? ' · 표고를 받지 못해 평평하게' : ` · 표고 ${Math.round(zMin)}–${Math.round(zMax)}m (지형 ${+exag.toFixed(2)}배)`;
    const relief = (zMax - zMin) * exag;
    // 도로 — 페이드 띠까지
    say('도로 읽는 중'); await tick();
    const tz = roadTileZoom(mpp, toLL([cx, cy])[1]), rkey = [w, s, e, n].map(v => v.toFixed(5)).join(',') + '|' + tz;
    let ways0 = ISO.roadCache && ISO.roadCache.key === rkey ? ISO.roadCache.ways : null;          // 미리보기에서 다시 그릴 때는 받은 도로를 그대로
    if(!ways0){
      const raw = await hiResRoads(s, w, n, e, null, { zMax:tz, zMin:7, maxTiles:80, progress:(d, t, z) => say(`도로 읽는 중 ${d}/${t} (지도 타일 z${z})`) });
      say('도로 정리 중'); await tick();
      ways0 = raw.filter(el => el.type === 'way' && el.geometry).map(wayInfo).filter(Boolean);
      ISO.roadCache = { key:rkey, ways:ways0 };
    }
    // 물 — 바다·강·호수 면과 해안선 (도로와 같은 지도 타일이라 대개 받아 둔 것을 씀)
    let wat = null;
    { let wl = ISO.waterCache && ISO.waterCache.key === rkey ? ISO.waterCache.list : null;
      if(!wl){
        say('물·해안선 읽는 중'); await tick();
        try{ wl = await tileWater(s, w, n, e, { zMax:tz, zMin:7, maxTiles:80 }); ISO.waterCache = { key:rkey, list:wl }; }
        catch(err){ console.warn(err); wl = []; }
      }
      try{ wat = isoWaterGeom(wl, region, mpp); }catch(err){ console.warn(err); }
    }
    const ways = ways0.filter(x => (lineMode ? false : $('axfoot').checked) || x.c !== 6);    // 넓은 영역에서는 보행로를 뺍니다
    let roads = [], roadLines = null;
    if(lineMode){
      roadLines = roadLineGroups(ways, mpp, outer);
    }else{
      const byW = new Map(); for(const x of ways){ const k = Math.max(2, x.w) / 2; if(!byW.has(k)) byW.set(k, []); byW.get(k).push(x.pts); }
      const parts = []; for(const [hw, lines] of byW) parts.push(offsetLines(lines, hw));
      await tick();
      roads = parts.length ? cleanMP(inter(union(parts), outer), { close:0.5, open:0, minPiece:4, minHole:4, simplify:0.4 }) : [];
    }
    await tick();
    // 건물 — 영역 안에 든 것만
    say('매스 정리 중');
    const fc = VW.data && VW.data.building_kr, fh = S.bldFH || 3, blds = [];
    if(fc) for(const f of fc.features) for(const poly of asMulti(f.geometry)){
      let ring = poly[0].map(toM); if(ringArea(ring) < 0) ring = ring.slice().reverse();
      const c = centroidOf([[ring]]), [u, v] = L(c[0], c[1]);
      if(!inside(u, v)) continue;
      const rg = ring.slice(0, -1);
      const us = axUseOf(f.properties); if(!us.show) continue;
      blds.push({ ring:rg, h:(floorsOf(f.properties) || 1) * fh, c, u:us.u, zT:useT ? Math.min(...rg.map(([x, y]) => Zr(x, y))) : 0 });
    }
    const maxB = blds.reduce((m, b) => Math.max(m, b.h), 0);
    // 분석 레이어 — 면 · 닫힌 고리(원 테두리 등) · 열린 선(축·노선)으로 나눕니다
    const order = { ground:0, fill:1, line:2, top:3 };
    // 행정구역 표시(clip-)는 아래 '행정구역' 레이어가 따로 그립니다
    const Ls = [...EXTRA.layers.entries()].filter(([id, d]) => !/^(d3-|site-radius|adm-|clip-)/.test(id) && !d.noExport && d.type !== 'symbol' && d.fc && d.fc.features.length).sort((x, y) => order[x[1].stage] - order[y[1].stage] || (typeof extraWeight === 'function' ? extraWeight(x[0]) - extraWeight(y[0]) : 0));
    const items = [];
    for(const [id, d] of Ls){
      const sv = d.svg || {}, polys = [], rings = [], lines = [];
      for(const f of d.fc.features){
        const g = f.geometry; if(!g) continue;
        if(g.type === 'Polygon' || g.type === 'MultiPolygon'){
          const mp = mapRings(g.type === 'Polygon' ? [g.coordinates] : g.coordinates, toM);
          if(sv.kind === 'fill') polys.push(...mp); else for(const poly of mp) for(const r of poly) rings.push(r);
        }else if(/LineString/.test(g.type)) for(const l of (g.type === 'LineString' ? [g.coordinates] : g.coordinates)){
          const m = l.map(toM); if(m.length < 2) continue;
          const closed = m.length > 3 && Math.hypot(m[0][0] - m[m.length - 1][0], m[0][1] - m[m.length - 1][1]) < 0.5;
          (closed ? rings : lines).push(m);
        }
      }
      // drape: 땅에 붙는 면(일조 그림자)은 덩어리마다 평평하게 띄우지 않고 지형을 따라 깝니다
      if(polys.length || rings.length || lines.length) items.push({ id, sv, mod:axModOf(id), nm:esc(String(d.label || id).replace(/^분석_/, '')), polys, rings, lines, top:axIsTop(id), drape:/^sun-/.test(id) });
    }
    // 지형 위 면 다이어그램은 덩어리마다 평평하게 — 덩어리 높이는 그 자리 지형의 평균
    const flatFill = useT && AXV.flatFill !== false;
    const clusters = new Map();
    if(flatFill){
      const byMod = new Map(), samp = pts => { const k = Math.max(1, Math.floor(pts.length / 16)), o = []; for(let i = 0; i < pts.length; i += k) o.push(pts[i]); return o; };
      for(const it of items) if(!it.drape) for(const r of [...it.polys.map(p => p[0]), ...it.rings]){
        if(!byMod.has(it.mod)) byMod.set(it.mod, []);
        byMod.get(it.mod).push({ b:bboxOf(r), pts:samp(r) });
      }
      for(const [mod, list] of byMod) clusters.set(mod, clusterBoxes(list).map(c => {
        let sm = Zr((c.b[0] + c.b[2]) / 2, (c.b[1] + c.b[3]) / 2) * 2, cnt = 2;
        const k = Math.max(1, Math.floor(c.pts.length / 80));
        for(let i = 0; i < c.pts.length; i += k){ sm += Zr(c.pts[i][0], c.pts[i][1]); cnt++; }
        return { b:c.b, z:sm / cnt };
      }));
    }
    const zFlat = (mod, pts) => {
      let mx = 0, my = 0; for(const [x, y] of pts){ mx += x; my += y; } mx /= pts.length; my /= pts.length;
      const cl = clusters.get(mod);
      if(cl) for(const c of cl) if(mx >= c.b[0] - 1 && mx <= c.b[2] + 1 && my >= c.b[1] - 1 && my <= c.b[3] + 1) return c.z;
      return Zr(mx, my);
    };
    // 판 목록 (분리 배열) — 판마다 자기 레이어 + 얹은 레이어 (pick). 덧붙인 판(종합)은 고른 레이어만
    const plates = [];
    if(split){
      if(useT) plates.push({ id:'지형', kind:'terrain' });
      if(wat) plates.push({ id:'물', kind:'water' });
      if(adm) plates.push({ id:'행정구역', kind:'admin' });
      plates.push({ id:'가구', kind:'blocks' });
      plates.push({ id:'도로', kind:'roads' });
      const mods = []; for(const it of items) if(!mods.includes(it.mod)) mods.push(it.mod);
      for(const m of mods) plates.push({ id:m, kind:'analysis', items:items.filter(it => it.mod === m) });
      plates.push({ id:'매스', kind:'mass' });
      ISO.plateList = plates.map(p => p.id);
      const avail = new Set(ISO.plateList), add = AXV.add || {};
      for(const p of plates){ const ad = add[p.id] || {}; p.pick = new Set([p.id, ...Object.keys(ad).filter(k => ad[k] && avail.has(k))]); }
      const combos = (AXV.combos || []).map(c => ({ id:c.id, kind:'combo', pick:new Set(Object.keys(c.pick || {}).filter(k => c.pick[k] && avail.has(k))) }));
      if(AXV.comboEnd === false) plates.unshift(...combos); else plates.push(...combos);
      for(const p of plates){ p.terrain = useT && p.pick.has('지형'); p.extra = (p.terrain ? relief : 0) + (p.pick.has('매스') ? maxB : 0); }
    }
    const vis = plates.filter(p => !AXP.hidden.has('판_' + p.id));
    // 투영과 배치
    const ang = AXV.tilt * Math.PI / 180, Cc = Math.cos(ang), Sc = Math.sin(ang);
    const T = Math.max(0.5, M * (AXV.thick == null ? 0.03 : AXV.thick));   // 판 두께 (미리보기 '판 두께')
    ISO.lastM = M;
    const proj = (x, y, z) => { const [u, v] = VL(x, y); return [(u - v) * Cc, -((u + v) * Sc + z)]; };
    const boxOf = (ring, zs, zf) => { let x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18; for(const p of ring) for(const z of zs){ const [px, py] = proj(p[0], p[1], z + (zf ? zf(p[0], p[1]) : 0)); x0 = Math.min(x0, px); x1 = Math.max(x1, px); y0 = Math.min(y0, py); y1 = Math.max(y1, py); } return { x0, y0, x1, y1 }; };
    const fb = boxOf(region[0][0], [0, -T]), tb = boxOf(region[0][0], [0]), topH = tb.y1 - tb.y0, fbW = fb.x1 - fb.x0;
    let gx0, gy0, gx1, gy1;
    if(!split){
      const hMax = blds.reduce((m, b) => Math.max(m, b.zT + b.h), relief + 10);
      const ob = boxOf(outer[0][0], [-T, hMax]);
      [gx0, gy0, gx1, gy1] = [ob.x0, ob.y0, ob.x1, ob.y1];
    }else{
      const gV = AXV.gapV == null ? 1.1 : AXV.gapV, gH = AXV.gapH == null ? 0.15 : AXV.gapH;
      let oy = 0;
      vis.forEach((p, k) => {
        if(k && layout === 'stack') oy -= vis[k - 1].extra + T + gV * topH;
        p.ox = layout === 'row' ? k * fbW * (1 + gH) : 0;
        p.oy = layout === 'row' ? 0 : oy;
      });
      gx0 = gy0 = 1e18; gx1 = gy1 = -1e18;
      for(const p of vis){ gx0 = Math.min(gx0, fb.x0 + p.ox); gx1 = Math.max(gx1, fb.x1 + p.ox); gy0 = Math.min(gy0, fb.y0 + p.oy - p.extra); gy1 = Math.max(gy1, fb.y1 + p.oy); }
      if(!vis.length){ gx0 = fb.x0; gx1 = fb.x1; gy0 = fb.y0; gy1 = fb.y1; }
    }
    const LBLW = layout === 'stack' ? 240 : 0, LBLH = layout === 'row' ? 48 : 0;
    const OUTW = 1800, pad = 50, sc = (OUTW - pad * 2 - LBLW) / Math.max(1e-6, gx1 - gx0);
    const legH = axUseOn() && blds.length ? 28 : 0;
    const OUTH = Math.round((gy1 - gy0) * sc + pad * 2 + LBLH + 30 + legH);
    let OX = 0, OY = 0;
    const S2 = (px, py) => [(px + OX - gx0) * sc + pad, (py + OY - gy0) * sc + pad];
    const P = (x, y, z) => { const [px, py] = proj(x, y, z), [a, b] = S2(px, py); return a.toFixed(1) + ',' + b.toFixed(1); };
    // 경로 만들기 — 지형을 따라가는 것(drape)과 일정한 높이(flat)
    const DSTEP = Math.max(12, mpp * 2);                                // 지형을 따라갈 때 나누는 간격 — 2px 보다 잘게는 나누지 않음
    const dens = pts => { const o = [pts[0]]; for(let i = 1; i < pts.length; i++){ const a = pts[i - 1], b = pts[i], k = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / DSTEP); for(let t = 1; t < k; t++) o.push([a[0] + (b[0] - a[0]) * t / k, a[1] + (b[1] - a[1]) * t / k]); o.push(b); } return o; };
    const DR = (!split && useT) ? Zr : null;
    const mpD = (mp, dz, zf) => { zf = zf === undefined ? DR : zf; return mp.map(poly => poly.map(r => 'M' + (zf ? dens(r) : r).map(([x, y]) => P(x, y, (zf ? zf(x, y) : 0) + dz)).join('L') + 'Z').join('')).join(''); };
    const lnD = (ls, dz, zf) => { zf = zf === undefined ? DR : zf; return ls.map(l => 'M' + (zf ? dens(l) : l).map(([x, y]) => P(x, y, (zf ? zf(x, y) : 0) + dz)).join('L')).join(''); };
    const mpZ = (mp, z) => mp.map(poly => poly.map(r => 'M' + r.map(([x, y]) => P(x, y, z)).join('L') + 'Z').join('')).join('');
    const lnZ = (ls, z) => ls.map(l => 'M' + l.map(([x, y]) => P(x, y, z)).join('L')).join('');
    const PU = (uv, z) => { const [x, y] = W2(uv[0], uv[1]); return P(x, y, z); };
    const dark = (() => { const c = st.paper.replace('#', ''); return (parseInt(c.slice(0, 2), 16) + parseInt(c.slice(2, 4), 16) + parseInt(c.slice(4, 6), 16)) / 3 < 110; })();
    const edge = st.massEdge, slabTop = hexMix(st.paper, st.ink, dark ? 0.12 : 0.04), slabSide = hexMix(st.paper, st.ink, dark ? 0.3 : 0.14);
    const strokeOf = (sv, op) => `fill="none" stroke="${sv.stroke || sv.fill}" stroke-width="${(sv.width || 1) * 1.1}" stroke-linecap="round" stroke-linejoin="round" opacity="${op}"${sv.dash ? ` stroke-dasharray="${sv.dash.map(v => v * Math.max(1, sv.width || 1)).join(' ')}"` : ''}`;
    /* 판 옆면 — 보는 쪽 면만, 윗선은 ztop 을 따라감 */
    const sidesSVG = (ring, ztop, follow) => {
      const nE = ring.length - 1, fr = [], quads = [], lines = [];
      for(let i = 0; i < nE; i++){ const a = ring[i], b = ring[i + 1], [ua, va] = VL(a[0], a[1]), [ub, vb] = VL(b[0], b[1]); fr.push((vb - va) - (ub - ua) < 0); }
      for(let i = 0; i < nE; i++){
        if(!fr[i]) continue;
        const a = ring[i], b = ring[i + 1], N = follow ? Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / (M / 24))) : 1, top = [];
        for(let k = 0; k <= N; k++){ const x = a[0] + (b[0] - a[0]) * k / N, y = a[1] + (b[1] - a[1]) * k / N; top.push(P(x, y, ztop(x, y))); }
        quads.push(`M${top.join('L')}L${P(b[0], b[1], -T)}L${P(a[0], a[1], -T)}Z`);
        lines.push(`M${P(a[0], a[1], -T)}L${P(b[0], b[1], -T)}`);
      }
      for(let i = 0; i < nE; i++){
        const pf = fr[(i - 1 + nE) % nE], cf = fr[i];
        if(!pf && !cf) continue;
        let mark = pf !== cf;
        if(!mark){
          const p0 = ring[(i - 1 + nE) % nE], p1 = ring[i], p2 = ring[i + 1];
          let d = Math.abs(Math.atan2(p2[1] - p1[1], p2[0] - p1[0]) - Math.atan2(p1[1] - p0[1], p1[0] - p0[0])); if(d > Math.PI) d = 2 * Math.PI - d;
          mark = d > 0.35;                                                   // 모서리(사각형 귀퉁이)
        }
        if(mark){ const p = ring[i]; lines.push(`M${P(p[0], p[1], ztop(p[0], p[1]))}L${P(p[0], p[1], -T)}`); }
      }
      return quads.length ? `<path d="${quads.join('')}" fill="${slabSide}" stroke="${slabSide}" stroke-width="0.5" stroke-linejoin="round"/><path d="${lines.join('')}" fill="none" stroke="${edge}" stroke-width="0.6" stroke-linecap="round"/>` : '';
    };
    /* 지형 면 (원은 동심 격자, 사각형은 바둑판 격자) + 등고선 */
    const terrainSVG = () => {
      const cells = [], d0 = M / 60;
      const shade = (uc, vc) => {
        const z = (u, v) => { const [x, y] = W2(u, v); return Zr(x, y); };
        const gu = (z(uc + d0, vc) - z(uc - d0, vc)) / (2 * d0), gv = (z(uc, vc + d0) - z(uc, vc - d0)) / (2 * d0);
        const sh = Math.max(-1, Math.min(1, (-gu + gv) * 1.2));               // 북서쪽 빛
        return sh >= 0 ? hexMix(slabTop, st.paper, sh * 0.8) : hexMix(slabTop, slabSide, -sh * 0.9);
      };
      const cell = uvs => {
        const pts = uvs.map(([u, v]) => W2(u, v)), zs = pts.map(([x, y]) => Zr(x, y));
        const uc = uvs.reduce((a, p) => a + p[0], 0) / uvs.length, vc = uvs.reduce((a, p) => a + p[1], 0) / uvs.length, [ka, kb] = V(uc, vc);
        cells.push({ k:ka + kb, d:'M' + pts.map(([x, y], q) => P(x, y, zs[q])).join('L') + 'Z', c:shade(uc, vc) });
      };
      if(circ){
        const NRr = 20, NS = 72;
        for(let ri = 0; ri < NRr; ri++) for(let si = 0; si < NS; si++){
          const r0 = R * ri / NRr, r1 = R * (ri + 1) / NRr, t0 = si / NS * 2 * Math.PI, t1 = (si + 1) / NS * 2 * Math.PI;
          cell([[r0 * Math.cos(t0), r0 * Math.sin(t0)], [r1 * Math.cos(t0), r1 * Math.sin(t0)], [r1 * Math.cos(t1), r1 * Math.sin(t1)], [r0 * Math.cos(t1), r0 * Math.sin(t1)]]);
        }
      }else{
        const NU = Math.max(8, Math.round(48 * A / M)), NV = Math.max(8, Math.round(48 * B / M)), du = 2 * A / NU, dv = 2 * B / NV;
        for(let i = 0; i < NU; i++) for(let j = 0; j < NV; j++){ const u0 = -A + i * du, v0 = -B + j * dv; cell([[u0, v0], [u0 + du, v0], [u0 + du, v0 + dv], [u0, v0 + dv]]); }
      }
      cells.sort((p, q) => q.k - p.k);
      let out = cells.map(c => `<path d="${c.d}" fill="${c.c}" stroke="${c.c}" stroke-width="0.4"/>`).join('');
      // 등고선 (가볍게)
      const sp = zMax - zMin, step = [1, 2, 5, 10, 20].find(v => sp / v <= 12) || 25, segs = [];
      const GN = 60, gx = 2 * A / GN, gy = 2 * B / GN, grid = [];
      for(let i = 0; i <= GN; i++){ grid.push([]); for(let j = 0; j <= GN; j++){ const u = -A + i * gx, v = -B + j * gy, [x, y] = W2(u, v); grid[i].push({ u, v, z:Zr(x, y) / exag + zMin }); } }
      for(let lv = Math.ceil(zMin / step) * step; lv <= zMax; lv += step){
        const zz = (lv - zMin) * exag;
        for(let i = 0; i < GN; i++) for(let j = 0; j < GN; j++){
          const c4 = [grid[i][j], grid[i + 1][j], grid[i + 1][j + 1], grid[i][j + 1]], pts = [];
          for(let q = 0; q < 4; q++){ const p = c4[q], r = c4[(q + 1) % 4]; if((p.z - lv) * (r.z - lv) < 0){ const t = (lv - p.z) / (r.z - p.z); pts.push([p.u + (r.u - p.u) * t, p.v + (r.v - p.v) * t]); } }
          if(pts.length < 2) continue;
          let a = pts[0], b = pts[1];
          if(circ){ const c = clipSegCircle(a, b, R); if(!c) continue; [a, b] = c; }
          segs.push(`M${PU(a, zz)}L${PU(b, zz)}`);
        }
      }
      if(segs.length) out += `<path id="등고선" d="${segs.join('')}" fill="none" stroke="${slabSide}" stroke-width="0.5"/>`;
      return out;
    };
    /* 매스 — 뒤에서 앞으로 */
    const massSVG = onTerrain => {
      const o = [], depth = b => { const [u, v] = VL(b.c[0], b.c[1]); return u + v; };
      for(const b of blds.slice().sort((p, q) => depth(q) - depth(p))){
        const topC = axTopColor(b, st), wA = hexMix(topC, st.massEdge, 0.08), wB = hexMix(topC, st.massEdge, 0.18);
        const faces = [], rg = b.ring, z0 = onTerrain ? b.zT : 0, z1 = z0 + b.h;
        for(let i = 0; i < rg.length; i++){
          const p = rg[i], q = rg[(i + 1) % rg.length], [pu, pv] = VL(p[0], p[1]), [qu, qv] = VL(q[0], q[1]);
          const nx = qv - pv, ny = -(qu - pu); if(nx + ny > 0) continue;
          faces.push(`<path d="M${P(p[0], p[1], onTerrain ? Zr(p[0], p[1]) : z0)}L${P(q[0], q[1], onTerrain ? Zr(q[0], q[1]) : z0)}L${P(q[0], q[1], z1)}L${P(p[0], p[1], z1)}Z" fill="${(nx - ny) < 0 ? wA : wB}"/>`);
        }
        faces.push(`<path d="M${rg.map(([x, y]) => P(x, y, z1)).join('L')}Z" fill="${topC}"/>`);
        o.push(`<g stroke="${edge}" stroke-width="0.55" stroke-linejoin="round">${faces.join('')}</g>`);
      }
      return o.join('');
    };
    const roadFill = dark ? hexMix(st.paper, st.ink, 0.22) : st.paper, roadEdge = hexMix(st.paper, st.ink, 0.4);
    const out = [`<svg xmlns="http://www.w3.org/2000/svg" width="${OUTW}" height="${OUTH}" viewBox="0 0 ${OUTW} ${OUTH}">`, `<rect width="100%" height="100%" fill="${st.paper}"/>`];
    const FONT = `font-family="'Noto Sans CJK KR','Malgun Gothic',sans-serif"`;

    const roadsIn = inter(roads, region);
    // 선 모드에서는 가구 = 영역 판 위에 도로를 바탕색 선으로 그어 나눔 (면을 빼는 계산 없이)
    const wetMP = wat ? union([wat.sea, wat.inland]) : [];                // 가구는 물을 뺀 땅에서
    const blocks = split ? (lineMode ? diff(region, wetMP) : cleanMP(diff(region, union([roadsIn, wetMP])), { close:0, open:0.5, minPiece:20, minHole:20, simplify:0.4 })) : [];
    const linesIn = lineMode ? new Map([...roadLines].map(([k, ls]) => [k, clipLinesMP(ls, region)]).filter(([, ls]) => ls.length)) : null;
    const lineRoadC = hexMix(st.paper, st.ink, dark ? 0.72 : 0.62);
    /* 굵기별 선 묶음 → path (op: 투명도, col: 색, zf: 지형) */
    const linesSVG = (groups, col, op, zf, z) => [...groups].map(([k, ls]) => ls.length ? `<path d="${z != null ? lnZ(ls, z) : lnD(ls, 0.05, zf)}" fill="none" stroke="${col}" stroke-width="${k}" stroke-linecap="round" stroke-linejoin="round"${op < 1 ? ` opacity="${op.toFixed(2)}"` : ''}/>` : '').join('');
    const blockC = hexMix(st.paper, st.ink, dark ? 0.3 : 0.17), roadC = hexMix(st.paper, st.ink, dark ? 0.85 : 0.78);
    /* 행정구역 — 구역 밖 어둡게 · 나눈 구역 색 · 경계 · 이름 (지도에서 구역 밖을 어둡게 한 것처럼).
       판 위에만 그립니다 (페이드 띠로 나가지 않음). zf: 지형을 따라가기, zc: 일정한 높이 (판 하나만 따로 그릴 때) */
    /* 물 — 바다 면 · 강·호수 면 · 해안선. 판 위에만. 색은 지도 스타일의 물색 */
    const wPr = typeof mapBaseColors === 'function' ? mapBaseColors() : {};      // 바탕 지도(지도 꾸미기 스타일·색)의 물색
    const waterC = wPr.water || hexMix(st.paper, st.bus || '#4A86C8', 0.25), coastC = hexMix(wPr.waterLine || hexMix(st.paper, st.ink, 0.55), st.ink, 0.35);   // 해안선은 지도 물가선보다 조금 진하게
    const waterSVG = (zf, zc) => {
      if(!wat) return '';
      const PD = (mp, dz) => zc != null ? mpZ(mp, zc + dz) : mpD(mp, dz, zf);
      const LD = (ls, dz) => zc != null ? lnZ(ls, zc + dz) : lnD(ls, dz, zf);
      return (wat.sea.length ? `<g id="물_바다"><path d="${PD(wat.sea, 0.06)}" fill="${waterC}" fill-rule="evenodd"/></g>` : '')
        + (wat.inland.length ? `<g id="물_강호수"><path d="${PD(wat.inland, 0.06)}" fill="${waterC}" fill-rule="evenodd"/></g>` : '')
        + (wat.coast.length ? `<g id="해안선"><path d="${LD(wat.coast, 0.1)}" fill="none" stroke="${coastC}" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/></g>` : '');
    };
    const admVeil = dark ? '#000000' : hexMix(st.ink, '#000000', 0.3), admVeilOp = dark ? 0.5 : 0.3;
    const adminSVG = (zf, zc) => {
      if(!adm) return '';
      const PD = (mp, dz) => zc != null ? mpZ(mp, zc + dz) : mpD(mp, dz, zf);
      const LD = (ls, dz) => zc != null ? lnZ(ls, zc + dz) : lnD(ls, dz, zf);
      const o = [];
      // 물이 있으면 육지 · 바다 · 강호수로 나눠 그룹을 따로 (같은 색이라 보이는 모습은 그대로 — 일러스트에서 따로 칠하기)
      const wetSplit = mp => !wat ? null : [['육지', diff(mp, wetMP)], ['바다', inter(mp, wat.sea)], ['강호수', inter(mp, wat.inland)]].filter(([, g]) => g.length);
      const faceSVG = (mp, pre, attrs) => {
        const sp = wetSplit(mp);
        if(!sp || (sp.length === 1 && sp[0][0] === '육지')) return `<path d="${PD(mp, 0.12)}" ${attrs}/>`;
        return sp.map(([k, g]) => `<g id="${esc(pre + k)}"><path d="${PD(g, 0.12)}" ${attrs}/></g>`).join('');
      };
      const veil = diff(region, adm.all);
      if(veil.length) o.push(`<g id="행정구역_바깥">${faceSVG(veil, '구역밖_', `fill="${admVeil}" fill-rule="evenodd" opacity="${admVeilOp}"`)}</g>`);
      // 구역별 면 — 구역마다 <g id="구역 이름"> 하나 (일러스트에서 그 그룹을 골라 칠함), 물이 걸치면 그 안에서 육지·바다·강호수로
      if(adm.parts.length) o.push('<g id="행정구역_면">' + adm.parts.map(q => `<g id="${esc(q.id)}">${faceSVG(q.g, q.id + '_', `fill="${q.color}" fill-rule="evenodd" opacity="0.28"`)}</g>`).join('') + '</g>');
      const line = [];
      if(adm.prings){ const zl = clipLinesMP(adm.prings, region); if(zl.length) line.push(`<path d="${LD(zl, 0.2)}" fill="none" stroke="${st.ink}" stroke-width="0.8" stroke-dasharray="4 3" stroke-linecap="round" stroke-linejoin="round" opacity="0.8"/>`); }
      const ls = clipLinesMP(adm.rings, region);
      if(ls.length) line.push(`<path d="${LD(ls, 0.25)}" fill="none" stroke="${st.ink}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>`);
      if(line.length) o.push(`<g id="행정구역_경계">${line.join('')}</g>`);
      const placed = [];                                                   // 이름끼리 겹치면 아래로 비켜 씁니다
      const name = adm.labels.map(t => {
        const z = zc != null ? zc : (zf ? zf(t.p[0], t.p[1]) : 0), [px, py] = proj(t.p[0], t.p[1], z + 0.4);
        let [sx, sy] = S2(px, py); const hw = t.name.length * 8.5 + 4;
        for(let k = 0; k < 6 && placed.some(q => Math.abs(q[0] - sx) < q[2] + hw && Math.abs(q[1] - sy) < 21); k++) sy += 22;
        placed.push([sx, sy, hw]);
        return `<text x="${sx.toFixed(1)}" y="${(sy + 6).toFixed(1)}" text-anchor="middle" ${FONT} font-size="17" font-weight="700" letter-spacing="0.5" fill="${st.ink}" stroke="${st.paper}" stroke-width="4" stroke-linejoin="round" paint-order="stroke">${esc(t.name)}</text>`;
      }).join('');
      if(name) o.push(`<g id="행정구역_이름">${name}</g>`);
      return o.join('');
    };
    /* 한 판 그리기 — 한 판 배치와 종합 판이 같이 씁니다.
       opt: terrain(지형 위에) · blocks · roads · mods(넣을 분석 항목, null 이면 전부) · mass · bands(페이드 띠) */
    const composeParts = opt => {
      const zf = opt.terrain ? Zr : null, ff = opt.terrain && flatFill, part = {};
      part.sides = sidesSVG(region[0][0], opt.terrain ? Zr : () => 0, !!opt.terrain);
      part.surface = opt.terrain ? terrainSVG() : '';
      part.flatTop = opt.terrain ? '' : `<path d="${mpZ(region, 0)}" fill="${slabTop}"/>`;
      part.outline = `<path d="${mpD(region, 0, zf)}" fill="none" stroke="${edge}" stroke-width="0.8"/>`;
      if(opt.blocks && blocks.length) part.blocks = `<path d="${mpD(blocks, 0.03, zf)}" fill="${blockC}" fill-rule="evenodd"/>`
        + (lineMode ? linesSVG(linesIn, slabTop, 1, zf) : '');
      if(opt.roads){ const r = [], rOut = [], mainR = opt.main === '도로';                // 도로 판이면 도로가 주인공 — 도로 판처럼 진하게
        if(lineMode) opt.bands.forEach(b => {
          const g = b.g === region ? linesIn : new Map([...roadLines].map(([k, ls]) => [k, clipLinesMP(ls, b.g)]));
          (b.out ? rOut : r).push(linesSVG(g, mainR ? roadC : lineRoadC, b.op, zf));
        });
        else opt.bands.forEach(b => { const g = inter(roads, b.g); if(g.length) (b.out ? rOut : r).push(mainR ? `<path d="${mpD(g, 0.05, zf)}" fill="${roadC}" fill-rule="evenodd" opacity="${b.op.toFixed(2)}"/>` : `<path d="${mpD(g, 0.05, zf)}" fill="${roadFill}" stroke="${roadEdge}" stroke-width="0.45" fill-rule="evenodd" opacity="${b.op.toFixed(2)}"/>`); });
        part.roads = r.join(''); part.roadsOut = rOut.join(''); }
      if(opt.admin) part.admin = adminSVG(zf);
      if(opt.water) part.water = waterSVG(zf);
      const anItems = [], anTop = [], anOut = [];
      for(const it of items){
        if(opt.mods && !opt.mods.has(it.mod)) continue;
        const sv = it.sv, grp = [], grpOut = [];
        opt.bands.forEach(b => {
          const G = b.out ? grpOut : grp;
          const op = (b.op * (sv.opacity ?? 1)).toFixed(2);
          if(it.polys.length){
            const g = inter(it.polys, b.g);
            if(g.length){
              if(ff && !it.drape){
                const byZ = new Map();
                for(const poly of g){ const z = zFlat(it.mod, poly[0]) + 0.3, k = z.toFixed(1); byZ.set(k, (byZ.get(k) || '') + mpZ([poly], z)); }
                for(const d of byZ.values()) G.push(`<path d="${d}" fill="${sv.fill}" fill-rule="evenodd" opacity="${op}"/>`);
              }else G.push(`<path d="${mpD(g, 0.1, zf)}" fill="${sv.fill}" fill-rule="evenodd" opacity="${op}"/>`);
            }
          }
          if(it.rings.length){
            const ls = clipLinesMP(it.rings, b.g);
            if(ls.length){
              if(ff && !it.drape){
                const byZ = new Map();
                for(const l of ls){ const z = zFlat(it.mod, l) + 0.35, k = z.toFixed(1); byZ.set(k, (byZ.get(k) || '') + lnZ([l], z)); }
                for(const d of byZ.values()) G.push(`<path d="${d}" ${strokeOf(sv, op)}/>`);
              }else G.push(`<path d="${lnD(ls, 0.15, zf)}" ${strokeOf(sv, op)}/>`);
            }
          }
          if(it.lines.length){ const ls = clipLinesMP(it.lines, b.g); if(ls.length) G.push(`<path d="${lnD(ls, 0.15, zf)}" ${strokeOf(sv, op)}/>`); }
        });
        if(grp.length) ((it.top && opt.mass) ? anTop : anItems).push({ id:it.id, html:`<g id="${it.nm}">${grp.join('')}</g>` });
        if(grpOut.length) anOut.push({ id:it.id, html:`<g id="${it.nm}">${grpOut.join('')}</g>` });
      }
      part.an = groupByModule(anItems); part.anTop = anTop.length ? groupByModule(anTop) : ''; part.anOut = anOut.length ? groupByModule(anOut) : '';
      if(opt.mass) part.mass = massSVG(!!opt.terrain);
      return part;
    };

    if(!split){
      /* ---------- 한 판 ---------- */
      const pt = composeParts({ terrain:useT, blocks:false, roads:true, admin:!!adm, water:!!wat, mods:null, mass:true, bands });
      if(pt.roadsOut || pt.anOut) out.push('<g id="페이드">' + (pt.roadsOut ? `<g id="페이드_도로">${pt.roadsOut}</g>` : '') + (pt.anOut ? `<g id="페이드_분석">${pt.anOut}</g>` : '') + '</g>');   // 판 밖 — 판이 앞쪽을 가리게 먼저
      out.push('<g id="판">' + pt.sides + '</g>');
      out.push('<g id="지형">' + pt.surface + pt.flatTop + pt.outline + '</g>');
      if(pt.water) out.push('<g id="물">' + pt.water + '</g>');
      out.push('<g id="도로">' + (pt.roads || '') + '</g>');
      if(pt.admin) out.push('<g id="행정구역">' + pt.admin + '</g>');
      out.push('<g id="분석">' + pt.an + '</g>');
      out.push('<g id="매스">' + (pt.mass || '') + '</g>');
      if(pt.anTop) out.push('<g id="분석_위">' + pt.anTop + '</g>');
    }else{
      /* ---------- 판마다 분리 ---------- */
      const lblX = pad + (gx1 - gx0) * sc + 36;
      for(const p of plates){
        if(AXP.hidden.has('판_' + p.id)){ out.push(`<g id="판_${esc(p.id)}" data-off="1"></g>`); continue; }   // 꺼 둔 판은 자리도 비움
        OX = p.ox; OY = p.oy;
        const isT = p.terrain, o = [];
        if(p.kind === 'combo' || p.pick.size > 1){
          // 여러 레이어를 얹은 판 · 덧붙인 판 — 한 판처럼 (지형을 얹으면 지형 위에, 선은 지형을 따라, 면 다이어그램은 덩어리마다 평평하게)
          const pk = p.pick;
          const pt = composeParts({ terrain:p.terrain, blocks:pk.has('가구'), roads:pk.has('도로'), admin:pk.has('행정구역'), water:pk.has('물'), mods:new Set(pk), mass:pk.has('매스'), bands:[{ g:region, op:1 }], main:p.kind === 'combo' ? null : p.id });
          o.push(`<g id="판_${esc(p.id)}_받침">${pt.sides}${pt.flatTop}</g>`);
          if(pt.surface) o.push(`<g id="지형">${pt.surface}</g>`);
          if(pt.water) o.push(`<g id="물">${pt.water}</g>`);
          if(pt.blocks) o.push(`<g id="가구">${pt.blocks}</g>`);
          if(pt.roads) o.push(`<g id="도로">${pt.roads}</g>`);
          if(pt.admin) o.push(`<g id="행정구역">${pt.admin}</g>`);
          o.push(pt.an, pt.outline);
          if(pt.mass) o.push(`<g id="매스">${pt.mass}</g>`);
          if(pt.anTop) o.push(`<g id="분석_위">${pt.anTop}</g>`);
        }else{
          // 레이어 하나만 — 원래 판 그대로
          o.push(`<g id="판_${esc(p.id)}_받침">` + sidesSVG(region[0][0], isT ? Zr : () => 0, isT) + (isT ? terrainSVG() : `<path d="${mpZ(region, 0)}" fill="${slabTop}"/>`) + '</g>');
          if(p.kind === 'blocks' && blocks.length) o.push(`<g id="가구"><path d="${mpZ(blocks, 0.05)}" fill="${blockC}" fill-rule="evenodd"/>${lineMode ? linesSVG(linesIn, slabTop, 1, null, 0.05) : ''}</g>`);
          if(p.kind === 'roads' && roadsIn.length) o.push(`<g id="도로"><path d="${mpZ(roadsIn, 0.05)}" fill="${roadC}" fill-rule="evenodd"/></g>`);
          if(p.kind === 'roads' && lineMode && linesIn.size) o.push(`<g id="도로">${linesSVG(linesIn, roadC, 1, null, 0.05)}</g>`);
          if(p.kind === 'admin') o.push(`<g id="행정구역">${adminSVG(null, 0)}</g>`);
          if(p.kind === 'water') o.push(`<g id="물">${waterSVG(null, 0)}</g>`);
          if(p.kind === 'analysis') for(const it of p.items){
            const sv = it.sv, op = (sv.opacity ?? 1).toFixed(2), grp = [];
            if(it.polys.length){ const g = inter(it.polys, region); if(g.length) grp.push(`<path d="${mpZ(g, 0.1)}" fill="${sv.fill}" fill-rule="evenodd" opacity="${op}"/>`); }
            const ls = clipLinesMP([...it.rings, ...it.lines], region);
            if(ls.length) grp.push(`<path d="${lnZ(ls, 0.15)}" ${strokeOf(sv, op)}/>`);
            if(grp.length) o.push(`<g id="${it.nm}">${grp.join('')}</g>`);
          }
          o.push(`<path d="${isT ? mpD(region, 0, Zr) : mpZ(region, 0)}" fill="none" stroke="${edge}" stroke-width="0.8"/>`);
          if(p.kind === 'mass') o.push(massSVG(false));
        }
        // 이름표 — 세로면 오른쪽에 점선 지시선, 가로면 판 아래
        const name = esc(plateName(p.id));
        if(layout === 'stack'){
          let best = null; for(const q of region[0][0]){ const pr = proj(q[0], q[1], isT ? Zr(q[0], q[1]) : 0); if(!best || pr[0] > best[0]) best = pr; }
          const [ax, ay] = S2(best[0], best[1]);
          o.push(`<g id="판_${esc(p.id)}_이름"><path d="M${(ax + 8).toFixed(1)},${ay.toFixed(1)}H${(lblX - 10).toFixed(1)}" fill="none" stroke="${st.ink}" stroke-opacity="0.55" stroke-width="0.9" stroke-dasharray="1.5 3"/><text x="${lblX.toFixed(1)}" y="${(ay + 5).toFixed(1)}" ${FONT} font-size="15" letter-spacing="1.2" fill="${st.ink}">${name}</text></g>`);
        }else{
          const [mx, my] = S2((fb.x0 + fb.x1) / 2, fb.y1);
          o.push(`<g id="판_${esc(p.id)}_이름"><text x="${mx.toFixed(1)}" y="${(my + 30).toFixed(1)}" text-anchor="middle" ${FONT} font-size="15" letter-spacing="1.2" fill="${st.ink}">${name}</text></g>`);
        }
        out.push(`<g id="판_${esc(p.id)}">` + o.join('') + '</g>');
      }
      OX = OY = 0;
    }
    { const o0 = proj(0, 0, 0); out.push(axNorthSVG((x, y) => { const a = proj(x, y, 0); return [(a[0] - o0[0]) * sc, (a[1] - o0[1]) * sc]; }, pad + 50, pad + 46, st)); }   // 방위 (왼쪽 위)
    if(legH) out.push(axUseLegend(blds, pad, OUTH - 46, st, FONT));
    const lay = { single:'한 판', stack:'세로로 분리', row:'가로로 분리' }[layout];
    const sizeTxt = circ ? `지름 ${Math.round(R * 2)} m` : `${Math.round(A * 2)} × ${Math.round(B * 2)} m`;
    out.push(`<text x="${pad}" y="${OUTH - 16}" ${FONT} font-size="12" fill="${st.ink}" fill-opacity="0.7">영역 ${sizeTxt} · ${lay} · 건물 ${blds.length}동` + tTxt + (adm ? ` · 행정구역 ${esc(clipName())}` : '')
      + (split ? '' : (fadeW ? ` · 도로·분석 영역 밖 ${Math.round(fadeW)}m까지` : (fadeIn ? ' · 도로·분석 영역 가장자리 안쪽에서' : ' · 도로·분석 영역에서 자름')) + (span ? (amt ? ` 페이드 ${Math.round(amt * 100)}%` : ' 그대로') : '')) + `</text>`, '</svg>');
    say(`완료 · 영역 ${sizeTxt} · ${lay} · 건물 ${blds.length}동` + tTxt.replace(/ \(지형.*\)$/, '') + (adm ? ` · 행정구역 ${clipName()} 강조` : '')
      + (lineMode ? ` · 넓은 영역이라 도로를 선으로 간소화 (지도 타일 z${tz}, 보행로 제외)` : '') + (blds.length ? '' : ' (건물이 없으면 줌 16 이상에서 건물_국내를 받아 두세요)'));
    ISO.lastQuad = quadLL;
    showAxPreview({ svg:out.join(''), name:'_영역ISO.svg', title:'영역 ISO', kind:'iso', rerun:() => exportIsoArea(ISO.lastQuad) });
  }catch(err){ console.error(err); say('실패 — ' + err.message); }
}
/* ---------- 지도에서 영역 그리기 — 사각형: 끌어서 / 원: 가운데를 누르고 반지름만큼 끌어서 ---------- */
function isoPickStart(){
  ISO.pick = true; $('isopick').classList.add('primary');
  $('isonote').textContent = AXV.shape === 'circle' ? '원의 가운데를 누르고 반지름만큼 끄세요 (Esc 취소)' : '지도에서 끌어 영역을 그리세요 (Esc 취소)';
  map.dragPan.disable(); map.getCanvas().style.cursor = 'crosshair';
}
function isoPickEnd(){
  ISO.pick = false; ISO.start = null; $('isopick').classList.remove('primary');
  if(ISO.box){ ISO.box.remove(); ISO.box = null; }
  map.dragPan.enable(); map.getCanvas().style.cursor = '';
}
(function hookIso(){
  if(typeof map === 'undefined' || !map || !map.on){ setTimeout(hookIso, 400); return; }
  map.on('mousedown', e => {
    if(!ISO.pick) return;
    e.preventDefault(); ISO.start = e.point;
    ISO.box = document.createElement('div');
    Object.assign(ISO.box.style, { position:'absolute', border:'1.5px dashed #2F6FDB', background:'rgba(47,111,219,0.08)', pointerEvents:'none', zIndex:5, borderRadius:AXV.shape === 'circle' ? '50%' : '0' });
    map.getContainer().appendChild(ISO.box);
  });
  map.on('mousemove', e => {
    if(!ISO.pick || !ISO.start || !ISO.box) return;
    const a = ISO.start, b = e.point;
    if(AXV.shape === 'circle'){ const r = Math.hypot(b.x - a.x, b.y - a.y); Object.assign(ISO.box.style, { left:(a.x - r) + 'px', top:(a.y - r) + 'px', width:2 * r + 'px', height:2 * r + 'px' }); }
    else Object.assign(ISO.box.style, { left:Math.min(a.x, b.x) + 'px', top:Math.min(a.y, b.y) + 'px', width:Math.abs(b.x - a.x) + 'px', height:Math.abs(b.y - a.y) + 'px' });
  });
  map.on('mouseup', e => {
    if(!ISO.pick || !ISO.start) return;
    const a = ISO.start, b = e.point;
    let x0, x1, y0, y1;
    if(AXV.shape === 'circle'){
      const r = Math.hypot(b.x - a.x, b.y - a.y); if(r < 10){ isoPickEnd(); return; }
      x0 = a.x - r; x1 = a.x + r; y0 = a.y + r; y1 = a.y - r;                // 원을 감싸는 정사각형
    }else{
      if(Math.abs(b.x - a.x) < 12 || Math.abs(b.y - a.y) < 12){ isoPickEnd(); return; }
      x0 = Math.min(a.x, b.x); x1 = Math.max(a.x, b.x); y0 = Math.max(a.y, b.y); y1 = Math.min(a.y, b.y);
    }
    // 화면 왼쪽 아래부터 반시계: 지도를 돌려 놓았으면 이 네 점이 돌아간 사각형이 됩니다
    const quad = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]].map(([x, y]) => { const ll = map.unproject([x, y]); return [ll.lng, ll.lat]; });
    isoPickEnd();
    exportIsoArea(quad);
  });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && ISO.pick){ isoPickEnd(); $('isonote').textContent = '취소했습니다'; } });
})();
$('isopick').addEventListener('click', () => { if(ISO.pick) isoPickEnd(); else isoPickStart(); });
$('isoshape').addEventListener('change', e => { AXV.shape = e.target.value; });
$('isoexag').addEventListener('input', e => { $('isoexagv').textContent = (+e.target.value).toFixed(1) + '배'; });


/* ============================================================
   미리보기 — 바로 내려받지 않고 먼저 보여 줍니다. 각도·모양·배치·지형을 바꾸면 그 자리에서 다시 그립니다.
   ============================================================ */
const AXP = { cur:null, el:null, hidden:new Set() };
function axPreviewEl(){
  if(AXP.el) return AXP.el;
  const el = document.createElement('div');
  el.id = 'axprev';
  el.innerHTML = `
    <div class="axp-box">
      <div class="axp-head">
        <b id="axp-title">미리보기</b>
        <span class="axp-presets" id="axp-presets"></span>
        <label>회전 <input type="range" id="axp-rot" min="0" max="359" step="1"> <span id="axp-rotv" class="num"></span></label>
        <label>기울기 <input type="range" id="axp-tilt" min="10" max="75" step="1"> <span id="axp-tiltv" class="num"></span></label>
      </div>
      <div class="axp-head axp-head2">
        <span class="axp-seg" id="axp-shape"><button data-v="rect">사각</button><button data-v="circle">원</button></span>
        <label id="axp-laybox">배치 <select id="axp-layout"><option value="single">한 판</option><option value="stack">세로로 분리</option><option value="row">가로로 분리</option></select></label>
        <label id="axp-gapbox">간격 <input type="range" id="axp-gap" min="0" max="300" step="5"> <span id="axp-gapv" class="num"></span></label>
        <label id="axp-thickbox" title="판 두께 — 판 반폭(원은 반지름) 대비 %">판 두께 <input type="range" id="axp-thick" min="0.5" max="20" step="0.5"> <span id="axp-thickv" class="num"></span></label>
        <label id="axp-terrbox"><input type="checkbox" id="axp-terr"> 지형 <input type="range" id="axp-exag" min="0.5" max="10" step="0.1"> <span id="axp-exagv" class="num"></span></label>
        <label id="axp-flatbox" title="밀도 면·거점 원처럼 닫힌 도형은 지형에 입히면 일그러집니다. 켜면 덩어리마다 평평하게 띄워 모양을 지킵니다. 선(도로·축)은 지형을 따라갑니다."><input type="checkbox" id="axp-flat"> 면 다이어그램 평평하게</label>
        <span id="axp-fadebox">도로 페이드 <label>범위 <input type="range" id="axp-fade" min="0" max="100" step="5"> <span id="axp-fadev" class="num"></span></label> <label>정도 <input type="range" id="axp-amt" min="0" max="100" step="5"> <span id="axp-amtv" class="num"></span></label></span>
        <label id="axp-topbox"><input type="checkbox" id="axp-alltop"> 분석 전부 건물 위로</label>
        <label id="axp-usebox" title="켜 둔 용도만 매스를 용도 색으로 칠합니다. 칠할 용도와 색은 대지분석 > 3 표현 > 건물 용도 칠하기에서 고릅니다. 끄면 고른 목록은 기억해 두고 잠깐 매스 색으로만"><input type="checkbox" id="axp-use"> 용도 색</label>
        <span id="axp-busy"></span>
      </div>
      <div class="axp-mid"><div class="axp-layers" id="axp-layers"></div><div class="axp-body" id="axp-body"></div></div>
      <div class="axp-foot">
        <span id="axp-info"></span>
        <button class="btn" id="axp-redraw">영역 다시 그리기</button>
        <label class="tidyrow" title="보이는 모습은 그대로 두고, 그룹에 걸린 투명도를 객체마다 직접 걸고 한 패스로 묶인 도형을 하나씩 풉니다. 구멍이 있는 면만 컴파운드로 남습니다."><input type="checkbox" class="tidychk"${typeof tidyOn === 'function' && !tidyOn() ? '' : ' checked'}> 일러스트용 정리</label>
        <button class="btn primary" id="axp-save">SVG 저장</button>
        <button class="btn" id="axp-close">닫기</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  const css = document.createElement('style');
  css.textContent = `
    #axprev{position:fixed;inset:0;background:rgba(20,22,26,.55);z-index:9999;display:none;align-items:center;justify-content:center}
    #axprev .axp-box{background:var(--bg);color:var(--text);border:1px solid var(--line-2);width:min(1240px,95vw);height:min(900px,93vh);display:flex;flex-direction:column;border-radius:6px;overflow:hidden;box-shadow:var(--shadow)}
    #axprev .axp-head,#axprev .axp-foot{display:flex;gap:12px;align-items:center;padding:8px 12px;font-size:12px;border-bottom:1px solid var(--line);flex-wrap:wrap}
    #axprev .axp-head2{background:var(--bg-2)}
    #axprev .axp-foot{border-top:1px solid var(--line);border-bottom:0;justify-content:flex-end}
    #axprev .axp-foot #axp-info{margin-right:auto;color:var(--text-2)}
    #axprev select{width:auto;height:24px;font-size:12px;padding:0 4px}
    #axprev .axp-mid{flex:1;display:flex;min-height:0}
    #axprev .axp-layers{width:210px;overflow:auto;border-right:1px solid var(--line);padding:8px 10px;font-size:12px}
    #axprev .axp-layers label{display:flex;gap:6px;align-items:center;margin:3px 0;cursor:pointer}
    #axprev .axp-layers .sub{margin-left:16px}
    #axprev .axp-layers .sub2{margin-left:32px}
    #axprev .axp-layers .hd{font-weight:600;margin:6px 0 2px;color:var(--text)}
    #axprev .axp-layers{width:240px}
    #axprev .pl{border:1px solid var(--line);border-radius:3px;margin:4px 0;padding:3px 5px;background:var(--bg)}
    #axprev .pl.open{border-color:var(--line-2);background:var(--bg-2)}
    #axprev .plh{display:flex;align-items:center;gap:4px}
    #axprev .plh label{flex:1;min-width:0;margin:0}
    #axprev .plh b{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    #axprev .pe{border:0;background:none;color:var(--text-2);font:inherit;font-size:10.5px;cursor:pointer;padding:1px 2px;max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    #axprev .pe:hover{color:var(--text)}
    #axprev .px{border:0;background:none;color:var(--text-3);cursor:pointer;font-size:13px;padding:0 2px}
    #axprev .chips{display:flex;flex-wrap:wrap;gap:3px;margin:4px 0 2px}
    #axprev .chip{display:inline-flex !important;gap:3px !important;margin:0 !important;border:1px solid var(--line-2);border-radius:10px;padding:1px 7px 1px 4px;font-size:11px;color:var(--text-2);background:var(--bg)}
    #axprev .chip.on{border-color:var(--text-2);color:var(--text);background:var(--bg-3)}
    #axprev .chip input{margin:0;width:11px;height:11px}
    #axprev .plf{display:flex;gap:8px;align-items:center;margin:6px 0 4px;font-size:11px;color:var(--text-2)}
    #axprev .plf button{border:1px dashed var(--line-2);background:var(--bg);color:var(--text);border-radius:3px;padding:3px 8px;font:inherit;font-size:11px;cursor:pointer}
    #axprev .plf label{margin:0 !important}
    #axprev .sub0 summary{cursor:pointer;color:var(--text-2);margin:3px 0}
    #axprev .sub0 label{margin-left:12px}
    #axprev .axp-body{flex:1;overflow:auto;display:flex;align-items:center;justify-content:center;background:#EDEDEB}
    #axprev .axp-body svg{width:100%;height:100%;display:block}
    #axprev #axp-busy{color:var(--hl)}
    #axprev .axp-presets button,#axprev .axp-seg button{font:inherit;font-size:11.5px;padding:3px 8px;border:1px solid var(--line-2);background:var(--bg-2);color:var(--text);border-radius:3px;cursor:pointer;margin-right:3px}
    #axprev .axp-presets button.on,#axprev .axp-seg button.on{background:var(--sel-bg);color:var(--sel-fg);border-color:var(--sel-bg)}
    #axprev input[type=range]{width:110px;vertical-align:middle}
    #axprev .num{display:inline-block;min-width:34px;color:var(--text-2)}
    #axprev .tidyrow{display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--text-2);margin-right:4px;cursor:pointer}`;
  document.head.appendChild(css);
  el.querySelector('#axp-close').onclick = () => { el.style.display = 'none'; };
  // 저장: 지금 꺼 둔 레이어는 빼고 저장 (일러스트에 숨은 레이어로 남지 않게)
  el.querySelector('#axp-save').onclick = () => {
    if(!AXP.cur) return;
    const svg = $('axp-body').querySelector('svg'); if(!svg) return;
    const cl = svg.cloneNode(true);
    cl.querySelectorAll('[data-off="1"]').forEach(n => n.remove());
    let txt = new XMLSerializer().serializeToString(cl);
    if(typeof tidySVG === 'function' && tidyOn()) txt = tidySVG(txt);       // 일러스트용 정리 (svgtidy.js)
    const tag = AXP.hidden.size ? '_' + [...AXP.hidden].slice(0, 3).map(t => t.replace(/[\\/:*?"<>|\s]/g, '')).join('-') + '끔' : '';
    download(stamp() + AXP.cur.name.replace('.svg', tag + '.svg'), txt, 'image/svg+xml');
  };
  const rerun = async () => {
    if(!AXP.cur) return;
    if(AXP.cur.kind === 'iso'){ $('isoterrain').checked = $('axp-terr').checked; $('isoexag').value = $('axp-exag').value; $('isoexagv').textContent = (+$('axp-exag').value).toFixed(1) + '배'; $('isoshape').value = AXV.shape || 'rect'; }
    $('axp-busy').textContent = '다시 그리는 중…';
    await AXP.cur.rerun();
  };
  AXP.rerun = rerun;
  el.querySelector('#axp-layers').onchange = e => {
    const ds = e.target.dataset || {};
    if(ds.padd){                                                           // 판에 레이어 얹기·빼기 → 다시 그림
      const cmb = (AXV.combos || []).find(c => c.id === ds.padd);
      const tgt = cmb ? (cmb.pick || (cmb.pick = {})) : ((AXV.add || (AXV.add = {}))[ds.padd] || (AXV.add[ds.padd] = {}));
      tgt[ds.layer] = e.target.checked;
      rerun(); return;
    }
    if(ds.pend){ AXV.comboEnd = e.target.value === '1'; rerun(); return; }
    const id = ds.lid; if(!id) return;
    if(e.target.checked) AXP.hidden.delete(id); else AXP.hidden.add(id);
    // 분리 배열에서 판을 끄고 켜면 자리를 비우거나 채우도록 다시 배치
    applyHidden();
    if(/^판_[^/]+$/.test(id) && AXP.cur && AXP.cur.kind === 'iso' && (AXV.layout || 'single') !== 'single') rerun();
  };
  el.querySelector('#axp-layers').onclick = e => {
    const b = e.target.closest('button'); if(!b) return;
    const ds = b.dataset;
    if(ds.pedit){ AXP.open = AXP.open === ds.pedit ? null : ds.pedit; renderLayerList(); return; }   // 얹을 레이어 펼치기
    if(ds.pdel){ AXV.combos = (AXV.combos || []).filter(c => c.id !== ds.pdel); AXP.hidden.delete('판_' + ds.pdel); if(AXP.open === ds.pdel) AXP.open = null; rerun(); return; }
    if(ds.pnew){                                                           // 빈 판을 덧붙이고 바로 고르게
      const have = new Set((AXV.combos || []).map(c => c.id)); let k = 1, id = '종합'; while(have.has(id)) id = '종합' + (++k);
      (AXV.combos || (AXV.combos = [])).push({ id, pick:{ '지형':true, '도로':true } });
      AXP.open = id; rerun(); return;
    }
  };
  el.querySelector('#axp-redraw').onclick = () => { el.style.display = 'none'; isoPickStart(); };
  let tmr = null;
  const later = () => { clearTimeout(tmr); tmr = setTimeout(rerun, 220); };      // 슬라이더를 끄는 동안은 조금 기다렸다가
  el.querySelector('#axp-rot').oninput = e => { AXV.rot = +e.target.value; $('axp-rotv').textContent = AXV.rot + '°'; markPreset(); later(); };
  el.querySelector('#axp-tilt').oninput = e => { AXV.tilt = +e.target.value; $('axp-tiltv').textContent = AXV.tilt + '°'; markPreset(); later(); };
  el.querySelector('#axp-terr').onchange = () => { syncIsoBoxes(); rerun(); };
  el.querySelector('#axp-thick').oninput = e => { AXV.thick = +e.target.value / 100; thickText(); later(); };
  el.querySelector('#axp-exag').oninput = e => { $('axp-exagv').textContent = (+e.target.value).toFixed(1) + '배'; later(); };
  el.querySelector('#axp-flat').onchange = e => { AXV.flatFill = e.target.checked; rerun(); };
  el.querySelector('#axp-alltop').onchange = e => { AXV.allTop = e.target.checked; rerun(); };
  el.querySelector('#axp-use').onchange = e => {
    if(typeof toggleUseAll !== 'function') return;
    const on = toggleUseAll(e.target.checked);                       // 끄면 고른 목록을 기억해 두고, 켜면 되살립니다
    if(e.target.checked && !on && typeof toast === 'function') toast('칠할 용도는 대지분석 > 3 표현 > 건물 용도 칠하기에서 고르세요');
    e.target.checked = on;
    rerun();
  };
  el.querySelector('#axp-shape').onclick = e => { const b = e.target.closest('button'); if(!b) return; AXV.shape = b.dataset.v; syncIsoBoxes(); rerun(); };
  el.querySelector('#axp-layout').onchange = e => { AXV.layout = e.target.value; syncIsoBoxes(); rerun(); };
  el.querySelector('#axp-gap').oninput = e => { const v = +e.target.value / 100; if(AXV.layout === 'row') AXV.gapH = v; else AXV.gapV = v; $('axp-gapv').textContent = e.target.value + '%'; later(); };
  const fadeText = () => { const v = Math.round(AXV.fade * 100); $('axp-fadev').textContent = v ? `${v}%` : '안쪽'; $('axp-amtv').textContent = Math.round(AXV.amt * 100) + '%'; };
  el.querySelector('#axp-fade').oninput = e => { AXV.fade = +e.target.value / 100; fadeText(); later(); };
  el.querySelector('#axp-amt').oninput = e => { AXV.amt = +e.target.value / 100; fadeText(); later(); };
  AXP.fadeText = fadeText;
  // 프리셋 — 누르면 바로 다시 그림
  const PRE = [['등각 앞', 0, 30], ['등각 오른쪽', 90, 30], ['등각 뒤', 180, 30], ['등각 왼쪽', 270, 30], ['정면 비스듬히', 25, 28], ['높게', 0, 50], ['낮게', 0, 18]];
  const box = el.querySelector('#axp-presets');
  box.innerHTML = PRE.map(([n], i) => `<button data-i="${i}">${n}</button>`).join('');
  box.onclick = e => { const b = e.target.closest('button'); if(!b) return; const [, r, t] = PRE[+b.dataset.i]; AXV.rot = r; AXV.tilt = t; syncView(); rerun(); };
  AXP.PRE = PRE;
  el.addEventListener('click', e => { if(e.target === el) el.style.display = 'none'; });
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && el.style.display === 'flex') el.style.display = 'none'; });
  AXP.el = el; return el;
}
function markPreset(){
  if(!AXP.PRE) return;
  document.querySelectorAll('#axp-presets button').forEach(b => { const [, r, t] = AXP.PRE[+b.dataset.i]; b.classList.toggle('on', r === AXV.rot && t === AXV.tilt); });
}
function syncView(){
  $('axp-rot').value = AXV.rot; $('axp-rotv').textContent = AXV.rot + '°';
  $('axp-tilt').value = AXV.tilt; $('axp-tiltv').textContent = AXV.tilt + '°';
  markPreset();
}
/* 판 두께 표시 — % (마지막으로 그린 판에서 몇 m 인지) */
function thickText(){
  const v = +$('axp-thick').value, m = ISO.lastM ? ISO.lastM * v / 100 : 0;
  $('axp-thickv').textContent = v + '%' + (m ? ` (${m >= 100 ? Math.round(m) : +m.toFixed(1)}m)` : '');
}
/* 영역 ISO 전용 칸 — 배치·지형에 따라 보이고 숨김 */
function syncIsoBoxes(){
  const iso = AXP.cur && AXP.cur.kind === 'iso', lay = AXV.layout || 'single', split = lay !== 'single';
  const show = (id, on) => { const n = $(id); if(n) n.style.display = on ? '' : 'none'; };
  show('axp-shape', iso); show('axp-laybox', iso); show('axp-gapbox', iso && split);
  show('axp-terrbox', iso); show('axp-thickbox', iso); show('axp-flatbox', iso && !split && $('axp-terr').checked);
  show('axp-fadebox', iso && !split); show('axp-topbox', !split || !iso); show('axp-redraw', iso);
  document.querySelectorAll('#axp-shape button').forEach(b => b.classList.toggle('on', b.dataset.v === (AXV.shape || 'rect')));
  $('axp-layout').value = lay;
  $('axp-thick').value = +(100 * (AXV.thick == null ? 0.03 : AXV.thick)).toFixed(1); thickText();
  const g = Math.round(100 * (lay === 'row' ? (AXV.gapH == null ? 0.15 : AXV.gapH) : (AXV.gapV == null ? 1.1 : AXV.gapV)));
  $('axp-gap').value = g; $('axp-gapv').textContent = g + '%';
}
/* 미리보기 SVG 안의 그룹을 레이어 목록으로 — 판·지형·등고선·도로·분석(항목별)·매스 / 분리 배열이면 판마다 */
const LAYER_NAMES = { '판':'판 (두께)', '지형':'지형 면', '등고선':'등고선', '바닥':'바닥', '도로':'도로', '물':'바다·물', '행정구역':'행정구역 강조', '페이드':'판 밖 페이드', '분석':'분석 레이어', '매스':'매스', '건물':'매스' };
const ADM_SUB = { '행정구역_바깥':'구역 밖 어둡게', '행정구역_면':'구역별 면', '행정구역_경계':'경계선', '행정구역_이름':'이름', '페이드_도로':'도로', '페이드_분석':'분석', '물_바다':'바다 면', '물_강호수':'강·호수 면', '해안선':'해안선 (육지·바다 경계)', '구역밖_육지':'육지', '구역밖_바다':'바다', '구역밖_강호수':'강·호수' };
function layerNodes(svg){
  const out = [];
  const plates = [...svg.querySelectorAll(':scope > g[id^="판_"]')];
  if(plates.length){
    out.push({ hd:'판 (끄면 자리도 비움)' });
    for(const g of plates){
      const nm = g.id.slice(2);
      out.push({ id:g.id, node:g, name:plateName(nm), mod:true });
      for(const c of g.querySelectorAll(':scope > g[id]')) if(!/_(받침|이름)$/.test(c.id)) out.push({ id:g.id + '/' + c.id, node:c, name:c.id.replace(/_세부$/, ''), sub:true, parent:plateName(nm) });
    }
    for(const g of svg.querySelectorAll(':scope > g[id]')) if(!/^판_/.test(g.id)) out.push({ id:g.id, node:g, name:g.id.replace(/_/g, ' '), extra:true });   // 방위 · 범례
    return out;
  }
  for(const g of svg.querySelectorAll(':scope > g[id]')){
    const id = g.id;
    if(id === '분석' || id === '분석_위'){
      out.push({ hd:id === '분석' ? '분석 (건물 아래)' : '분석 (건물 위)' });
      for(const m of g.querySelectorAll(':scope > g[id]')){
        out.push({ id:id + '/' + m.id, node:m, name:m.id, mod:true });
        for(const c of m.querySelectorAll(':scope > [id]')) out.push({ id:id + '/' + m.id + '/' + c.id, node:c, name:c.id.replace(/_세부$/, ''), sub:true, parent:m.id });
      }
    }else{
      out.push({ id, node:g, name:LAYER_NAMES[id] || id });
      if(id === '지형'){ const ctr = g.querySelector('#등고선'); if(ctr) out.push({ id:'지형/등고선', node:ctr, name:'등고선', sub:true }); }
      if(id === '행정구역' || id === '페이드' || id === '물') for(const c of g.querySelectorAll(':scope > g[id]')){
        out.push({ id:id + '/' + c.id, node:c, name:ADM_SUB[c.id] || c.id, sub:true });
        if(c.id === '행정구역_면' || c.id === '행정구역_바깥') for(const z of c.querySelectorAll(':scope > g[id]')) out.push({ id:id + '/' + c.id + '/' + z.id, node:z, name:ADM_SUB[z.id] || z.id, sub:true, sub2:true });   // 구역마다 · 구역 밖 육지·바다
      }
    }
  }
  return out;
}
function applyHidden(){
  const svg = $('axp-body').querySelector('svg'); if(!svg) return;
  for(const L of layerNodes(svg)){ if(!L.node) continue; const off = AXP.hidden.has(L.id); L.node.style.display = off ? 'none' : ''; if(off) L.node.setAttribute('data-off', '1'); else L.node.removeAttribute('data-off'); }
}
function renderLayerList(){
  const svg = $('axp-body').querySelector('svg'); if(!svg) return;
  const items = layerNodes(svg);
  const cb = L => `<label class="${L.sub2 ? 'sub sub2' : L.sub ? 'sub' : ''}"><input type="checkbox" data-lid="${esc(L.id)}"${AXP.hidden.has(L.id) ? '' : ' checked'}>${esc(L.name)}</label>`;
  let html = '';
  // 분리 배열: 판 구성 — 판마다 얹을 레이어를 고르고, 판을 덧붙이거나 끕니다
  const splitIso = AXP.cur && AXP.cur.kind === 'iso' && (AXV.layout || 'single') !== 'single' && ISO.plateList;
  if(splitIso){
    const ids = [...svg.querySelectorAll(':scope > g[id^="판_"]')].map(g => g.id.slice(2));
    if((AXV.layout || 'single') === 'stack') ids.reverse();                 // 세로: 그림처럼 위 판부터
    const short = l => PLATE_SHORT[l] || l;
    html += '<div class="hd">판 구성 — 판마다 얹을 레이어</div>';
    for(const id of ids){
      const cmb = (AXV.combos || []).find(c => c.id === id);
      const pick = cmb ? (cmb.pick || {}) : ((AXV.add || {})[id] || {});
      const ex = ISO.plateList.filter(l => l !== id && pick[l]);
      const open = AXP.open === id;
      html += `<div class="pl${open ? ' open' : ''}"><div class="plh"><label><input type="checkbox" data-lid="판_${esc(id)}"${AXP.hidden.has('판_' + id) ? '' : ' checked'}><b>${esc(plateName(id))}</b></label>`
        + `<button class="pe" data-pedit="${esc(id)}" title="이 판에 얹을 레이어">${ex.length ? '+ ' + esc(ex.map(short).join('·')) : (cmb ? '레이어 고르기' : '+ 얹기')} ${open ? '▴' : '▾'}</button>`
        + (cmb ? `<button class="px" data-pdel="${esc(id)}" title="이 판 지우기">×</button>` : '') + '</div>'
        + (open ? `<div class="chips">${ISO.plateList.filter(l => l !== id).map(l => `<label class="chip${pick[l] ? ' on' : ''}"><input type="checkbox" data-padd="${esc(id)}" data-layer="${esc(l)}"${pick[l] ? ' checked' : ''}>${esc(short(l))}</label>`).join('')}</div>` : '')
        + '</div>';
    }
    html += `<div class="plf"><button data-pnew="1">+ 판 덧붙이기</button><label>덧붙인 판 <select data-pend="1"><option value="1"${AXV.comboEnd !== false ? ' selected' : ''}>끝에</option><option value="0"${AXV.comboEnd === false ? ' selected' : ''}>처음에</option></select></label></div>`;
  }
  html += `<div class="hd">${splitIso ? '판 안의 레이어 (끄고 저장하면 빠짐)' : '레이어 (끄고 저장하면 빠짐)'}</div>`;
  for(let i = 0; i < items.length; i++){
    const L = items[i];
    if(L.hd){ if(!splitIso) html += `<div class="hd">${esc(L.hd)}</div>`; continue; }
    if(L.mod){                                                               // 분석 항목·판: 체크 + 접히는 세부
      const subs = []; while(items[i + 1] && items[i + 1].sub && items[i + 1].parent === L.name) subs.push(items[++i]);
      if(splitIso && /^판_/.test(L.id)){                                     // 판 켜고 끄기는 위 판 구성에서 — 여기는 판 안의 레이어만
        if(subs.length) html += `<details class="sub0"><summary>${esc(L.name)} <span style="color:#999">${subs.length}</span></summary>${subs.map(cb).join('')}</details>`;
        continue;
      }
      html += cb(L) + (subs.length > 1 ? `<details class="sub"><summary style="font-size:11px;color:#888;cursor:pointer">세부 ${subs.length}</summary>${subs.map(cb).join('')}</details>` : '');
      continue;
    }
    html += cb(L);
  }
  $('axp-layers').innerHTML = html;
  applyHidden();
}
function showAxPreview(p){
  const el = axPreviewEl();
  AXP.cur = p;
  $('axp-title').textContent = p.title + ' 미리보기';
  syncView();
  $('axp-alltop').checked = !!AXV.allTop;
  $('axp-use').checked = typeof useActive === 'function' && useActive();
  $('axp-terr').checked = $('isoterrain').checked;
  $('axp-exag').value = $('isoexag').value; $('axp-exagv').textContent = (+$('isoexag').value).toFixed(1) + '배';
  $('axp-flat').checked = AXV.flatFill !== false;
  $('axp-fade').value = Math.round(AXV.fade * 100); $('axp-amt').value = Math.round(AXV.amt * 100); AXP.fadeText && AXP.fadeText();
  syncIsoBoxes();
  $('axp-body').innerHTML = p.svg;
  renderLayerList();                                                     // 꺼 둔 레이어는 다시 그려도 계속 꺼져 있음
  $('axp-busy').textContent = '';
  $('axp-info').textContent = (p.kind === 'iso' ? $('isonote').textContent : $('axnote').textContent).replace(/^완료 · /, '');
  el.style.display = 'flex';
}
