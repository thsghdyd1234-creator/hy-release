/* 확장 프로그램 환경에서는 워커를 blob 대신 로컬 파일로 띄웁니다 (MV3 CSP 대응) */
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL
    && typeof maplibregl !== 'undefined' && maplibregl.setWorkerUrl) {
  maplibregl.setWorkerUrl(chrome.runtime.getURL('lib/maplibre-gl-csp-worker.js'));
}

/* ============================================================
   1. 타일 소스 (키 없음, 전세계 OpenStreetMap 벡터타일)
   ============================================================ */
let GLYPHS = 'https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf';
let TILES  = ['https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf'];

async function resolveSource(){
  try{
    const base = await fetch('https://tiles.openfreemap.org/styles/liberty').then(r=>r.json());
    if(base.glyphs) GLYPHS = base.glyphs;
    const src = base.sources?.openmaptiles || Object.values(base.sources||{}).find(s=>s.type==='vector');
    if(src?.tiles) TILES = src.tiles;
    else if(src?.url){
      const tj = await fetch(src.url).then(r=>r.json());
      if(tj.tiles) TILES = tj.tiles;
    }
  }catch(e){ /* 하드코딩된 기본값 사용 */ }
}

/* ============================================================
   2. 프리셋
   ============================================================ */
const DEFAULT_PRESETS = [
  {id:'blueprint',name:'인디고 청사진',hidden:[],colors:{bg:'#0E2C54',water:'#123A68',waterLine:'#3A78B5',green:'#123761',wood:'#143E6D',building:'#17416F',buildingLine:'#4A86C4',roadMajor:'#BFD9F2',roadMinor:'#4E84BC',rail:'#3A78B5',boundary:'#7FAEDC',label:'#E4F0FB',labelHalo:'#0E2C54'}},
  {id:'ink',name:'백지 잉크',hidden:[],colors:{bg:'#FFFFFF',water:'#EDEDED',waterLine:'#B4B4B4',green:'#F4F4F4',wood:'#ECECEC',building:'#E6E6E6',buildingLine:'#8C8C8C',roadMajor:'#1A1A1A',roadMinor:'#9B9B9B',rail:'#6E6E6E',boundary:'#C0C0C0',label:'#111111',labelHalo:'#FFFFFF'}},
  {id:'paper',name:'미색 종이',hidden:[],colors:{bg:'#F2EBDD',water:'#D9E2DD',waterLine:'#A9BCB4',green:'#E3E5D0',wood:'#D7DCC0',building:'#E4DBC7',buildingLine:'#B6A98D',roadMajor:'#8A7A5E',roadMinor:'#C6B99C',rail:'#A3947A',boundary:'#BCAE92',label:'#4A412F',labelHalo:'#F2EBDD'}},
  {id:'concrete',name:'탠저린 · 슬레이트 그레이 · 화이트',hidden:[],colors:{bg:'#FFFFFF',water:'#D1D4D7',waterLine:'#9DA3A9',green:'#EFF3EA',wood:'#E6ECDE',building:'#EAEBEB',buildingLine:'#C0C2C4',roadMajor:'#CB6922',roadMinor:'#C9CACC',rail:'#A1A4A7',boundary:'#B6B8BA',label:'#2E353B',labelHalo:'#FFFFFF'}},
  {id:'midnight',name:'야간',hidden:[],colors:{bg:'#14161A',water:'#0E1319',waterLine:'#2A3A4A',green:'#171B1E',wood:'#1A211C',building:'#1E2228',buildingLine:'#333941',roadMajor:'#6E7783',roadMinor:'#2D333B',rail:'#333941',boundary:'#414A55',label:'#C8CFD8',labelHalo:'#14161A'}},
  {id:'wash',name:'담채',hidden:[],colors:{bg:'#FBFAF7',water:'#CFE3EC',waterLine:'#A8CADA',green:'#DCE8D4',wood:'#CBDFC0',building:'#EDE7DF',buildingLine:'#D3C9BC',roadMajor:'#B08968',roadMinor:'#E0D5C8',rail:'#C4B6A6',boundary:'#D8CFC2',label:'#5C5346',labelHalo:'#FBFAF7'}},
  {id:'outline',name:'선만',hidden:['water','green','wood','landcover','building'],colors:{bg:'#FFFFFF',water:'#FFFFFF',waterLine:'#4A4A4A',green:'#FFFFFF',wood:'#FFFFFF',building:'#FFFFFF',buildingLine:'#1F1F1F',roadMajor:'#1F1F1F',roadMinor:'#808080',rail:'#5A5A5A',boundary:'#A0A0A0',label:'#1F1F1F',labelHalo:'#FFFFFF'}},
  {id:'sepia',name:'딥 버건디 · 모스 그린 · 웜 그레이',hidden:[],colors:{bg:'#E9E5DF',water:'#C2C3B1',waterLine:'#969C7C',green:'#DCDCCF',wood:'#D5D7C5',building:'#D8D4CE',buildingLine:'#B4B0AB',roadMajor:'#6A252F',roadMinor:'#BCB8B2',rail:'#9A9692',boundary:'#ACA8A3',label:'#3A3633',labelHalo:'#E9E5DF'}},
  {id:'teal',name:'머스터드 · 틸 블루 · 오프화이트',hidden:[],colors:{bg:'#F7F4EC',water:'#BBD2CE',waterLine:'#75ABAB',green:'#E8E9DA',wood:'#E0E3CF',building:'#E1E0D9',buildingLine:'#B6B7B2',roadMajor:'#AA841F',roadMinor:'#BFBFBA',rail:'#969996',boundary:'#ABADA9',label:'#1F2A2C',labelHalo:'#F7F4EC'}},
  {id:'negative',name:'흑백 반전',hidden:[],colors:{bg:'#000000',water:'#0E0E0E',waterLine:'#6E6E6E',green:'#121212',wood:'#171717',building:'#1C1C1C',buildingLine:'#8A8A8A',roadMajor:'#FFFFFF',roadMinor:'#5E5E5E',rail:'#7A7A7A',boundary:'#4A4A4A',label:'#FFFFFF',labelHalo:'#000000'}},
  {id:'sand',name:'테라코타 · 올리브 · 베이지',hidden:[],colors:{bg:'#EFE6D2',water:'#CAC8A7',waterLine:'#A0A577',green:'#E2DDC3',wood:'#DAD8BB',building:'#DDD4C1',buildingLine:'#B9B09F',roadMajor:'#A05739',roadMinor:'#C0B7A6',rail:'#9E9586',boundary:'#B0A796',label:'#3A3128',labelHalo:'#EFE6D2'}},
  {id:'moss',name:'살몬 · 파인 그린 · 라이트 그레이',hidden:[],colors:{bg:'#ECEDEB',water:'#B7C5BD',waterLine:'#7B9788',green:'#DFE3D9',wood:'#D8DECF',building:'#D9DAD8',buildingLine:'#B2B4B2',roadMajor:'#B96F5B',roadMinor:'#BABCB9',rail:'#959895',boundary:'#A8AAA8',label:'#2B2F2C',labelHalo:'#ECEDEB'}},
  {id:'plum',name:'플럼 · 코발트 · 실버 그레이',hidden:[],colors:{bg:'#E7E8EB',water:'#AFBDE0',waterLine:'#6F8CD4',green:'#DBDFD9',wood:'#D4DACF',building:'#D4D5D8',buildingLine:'#ADAEB2',roadMajor:'#663961',roadMinor:'#B5B6BA',rail:'#909296',boundary:'#A3A5A9',label:'#26282E',labelHalo:'#E7E8EB'}},
  {id:'crimson',name:'브릭 레드 · 네이비 · 샌드',hidden:[],colors:{bg:'#EADFC8',water:'#B1AEA8',waterLine:'#707584',green:'#DDD7BB',wood:'#D6D3B3',building:'#D6CCB9',buildingLine:'#ADA79B',roadMajor:'#863B30',roadMinor:'#B5AEA1',rail:'#8F8B85',boundary:'#A39E94',label:'#1F2433',labelHalo:'#EADFC8'}},
  {id:'indigo_ochre',name:'인디고 · 오커 · 크림',hidden:[],colors:{bg:'#F5EEDC',water:'#BDBCC4',waterLine:'#7E82A9',green:'#E7E4CC',wood:'#DFDEC3',building:'#E0DACF',buildingLine:'#B4B2B4',roadMajor:'#9E7538',roadMinor:'#BDBABA',rail:'#9494A1',boundary:'#AAA8AE',label:'#1E2558',labelHalo:'#F5EEDC'}},
  {id:'mauve_taupe',name:'모브 · 토프 · 차콜',hidden:[],colors:{bg:'#F2EFEB',water:'#D5CFC7',waterLine:'#B5A99E',green:'#E4E5D9',wood:'#DCDFCF',building:'#DFDCD8',buildingLine:'#B9B6B2',roadMajor:'#8B697F',roadMinor:'#C0BDBA',rail:'#9C9996',boundary:'#AFACA9',label:'#33302E',labelHalo:'#F2EFEB'}},
  {id:'lavender_mint',name:'라벤더 · 민트 · 차콜',hidden:[],colors:{bg:'#F6F5F8',water:'#CBE9E1',waterLine:'#9ADBC7',green:'#E8EAE4',wood:'#DFE4D9',building:'#E3E2E5',buildingLine:'#BCBBBF',roadMajor:'#8275B3',roadMinor:'#C4C3C7',rail:'#9F9EA2',boundary:'#B2B1B6',label:'#34343A',labelHalo:'#F6F5F8'}},
  {id:'emerald_peach',name:'에메랄드 · 피치 · 아이보리',hidden:[],colors:{bg:'#FBF8F0',water:'#BDDFCC',waterLine:'#76C2A2',green:'#ECEDDD',wood:'#E3E6D3',building:'#E5E4DD',buildingLine:'#BABEB6',roadMajor:'#BD8162',roadMinor:'#C3C5BE',rail:'#9AA099',boundary:'#AFB4AC',label:'#23352E',labelHalo:'#FBF8F0'}},
  {id:'magenta_cyan',name:'마젠타 · 시안 · 페일 옐로우',hidden:[],colors:{bg:'#FBF7DC',water:'#B5E0DA',waterLine:'#64C6D8',green:'#ECECCC',wood:'#E3E5C3',building:'#E5E1CA',buildingLine:'#B8B5A5',roadMajor:'#AF2070',roadMinor:'#C1BEAC',rail:'#979489',boundary:'#ADAA9C',label:'#1C1C24',labelHalo:'#FBF7DC'}},
  {id:'sky_mahogany',name:'스카이 블루 · 마호가니 · 라이트 샌드',hidden:[],colors:{bg:'#EEE6D6',water:'#CAD8D9',waterLine:'#A2C7DC',green:'#E1DDC7',wood:'#D9D8BE',building:'#DCD3C4',buildingLine:'#B8AEA1',roadMajor:'#6A372C',roadMinor:'#BFB5A8',rail:'#9D9186',boundary:'#AFA498',label:'#3A2A24',labelHalo:'#EEE6D6'}},
  {id:'neon_black',name:'네온 핑크 · 일렉트릭 블루 · 딥 블랙',hidden:[],colors:{bg:'#07070A',water:'#0C1B3B',waterLine:'#143E91',green:'#111114',wood:'#161619',building:'#1D1D20',buildingLine:'#0F2A60',roadMajor:'#FF2E9A',roadMinor:'#47474A',rail:'#5E5E60',boundary:'#113478',label:'#E6E6EE',labelHalo:'#07070A'}},
  {id:'olive_petrol',name:'올리브 옐로우 · 페트롤 블루 · 웜 그레이',hidden:[],colors:{bg:'#E8E5DE',water:'#AFBFC0',waterLine:'#6F959E',green:'#DCDCCE',wood:'#D4D7C4',building:'#D6D3CD',buildingLine:'#B0B0AA',roadMajor:'#94893E',roadMinor:'#B8B7B1',rail:'#959590',boundary:'#A7A7A1',label:'#2F3330',labelHalo:'#E8E5DE'}},
  {id:'lime_blue',name:'라임 · 블루 · 블랙',hidden:[],colors:{bg:'#0C0D0F',water:'#13203F',waterLine:'#1F4193',green:'#161719',wood:'#1B1C1D',building:'#222325',buildingLine:'#182E63',roadMajor:'#B8F02A',roadMinor:'#4B4C4D',rail:'#616263',boundary:'#1B377B',label:'#E6E6EE',labelHalo:'#0C0D0F'}},
  {id:'sage_rusk',name:'세이지 · 러스크 · 차콜',hidden:[],colors:{bg:'#EFEDE6',water:'#D0D5C7',waterLine:'#ACBAA3',green:'#E2E3D5',wood:'#DADECB',building:'#DDDBD5',buildingLine:'#B9B8B2',roadMajor:'#99683D',roadMinor:'#C0BFB9',rail:'#9E9D99',boundary:'#B0AFAA',label:'#3A3B3A',labelHalo:'#EFEDE6'}},
  {id:'ivory_apricot',name:'아이보리 · 애프리콧 · 네이비',hidden:[],colors:{bg:'#FBF7EC',water:'#BDBFC3',waterLine:'#777E94',green:'#ECECDA',wood:'#E3E5CF',building:'#E5E2DD',buildingLine:'#B8BABE',roadMajor:'#BC8465',roadMinor:'#C1C2C4',rail:'#979BA7',boundary:'#ADAFB6',label:'#1C2A52',labelHalo:'#FBF7EC'}},
  {id:'cream_coral',name:'크림 · 코랄 · 블루',hidden:[],colors:{bg:'#F8F1E2',water:'#C3CDDF',waterLine:'#86A3DC',green:'#E9E7D1',wood:'#E1E1C8',building:'#E3DED1',buildingLine:'#BAB7B0',roadMajor:'#BE6252',roadMinor:'#C2BFB6',rail:'#9B9A96',boundary:'#B0ADA7',label:'#2A2F3A',labelHalo:'#F8F1E2'}},
  {id:'forest_lilac',name:'포레스트 · 라일락 · 옐로우',hidden:[],colors:{bg:'#1F3A2E',water:'#405053',waterLine:'#797594',green:'#284236',wood:'#2C463B',building:'#334C41',buildingLine:'#58606F',roadMajor:'#F5D94A',roadMinor:'#596D64',rail:'#6D7F77',boundary:'#696B82',label:'#E6E6EE',labelHalo:'#1F3A2E'}},
];
let PRESETS = DEFAULT_PRESETS.slice();

/* 바탕 사진 타일 (키 없음) */
const SAT_SOURCES = {
  esri: {
    name:'위성 사진',
    tiles:['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],
    maxzoom:19,
    credit:'위성 사진 © Esri, Maxar, Earthstar Geographics'
  },
  hill: {
    name:'지형 음영',
    tiles:['https://server.arcgisonline.com/ArcGIS/rest/services/Elevation/World_Hillshade/MapServer/tile/{z}/{y}/{x}'],
    maxzoom:16,
    credit:'음영기복 © Esri'
  }
};


/* ============================================================
   2-b. 브이월드 국내 데이터
   ============================================================ */
const VW_LAYERS = {
  zone:        { id:'LT_C_UQ111',       name:'용도지역', minzoom:14, kind:'fill' },
  parcel:      { id:'LP_PA_CBND_BUBUN', name:'필지',     minzoom:16, kind:'line' },
  building_kr: { id:'LT_C_SPBD',        name:'건물',     minzoom:16, kind:'fill' },
  district:    { id:'LT_C_UPISUQ151',   name:'지구단위계획', minzoom:14, kind:'fill' }
};


/* 건물 서비스ID 는 문서마다 달라서, 되는 것을 찾으면 저장해 씁니다 */
const VW_BUILDING_TRIES = ['LT_C_SPBD','LT_C_SPBD_NL','LT_L_SPBD','LT_C_BLDINFO','LT_C_BUILDING'];
try{
  const saved = localStorage.getItem('vworldBuildingId');
  if(saved) VW_LAYERS.building_kr.id = saved;
}catch(e){}
let VW_OFF;
/* 연구실 공용 인증키 — 각자 발급받지 않아도 되도록 넣어 둡니다.
   파일을 열면 보이는 값이니, 외부로 퍼지면 vworld.kr 에서 재발급하세요. */
const VW_DEFAULT_KEY = '75AD704D-5222-47D4-97B6-E0BAF9078CB8';
const VW_DEFAULT_DOMAIN = 'http://localhost';   // 키에 등록한 서비스URL
const VW = { key:'', domain:'', proxy:'', data:{}, bbox:{}, cells:{}, busy:false, level:3, run:0 };   // 기본은 전부 받기 (패널에서 고르면 그 값을 기억)
/* 줌 문턱과 한 번에 받을 최대 개수 */
const VW_LEVELS = [
  {name:'가볍게',   zoom:16, cap:1000},
  {name:'보통',     zoom:15, cap:5000},
  {name:'촘촘하게', zoom:14, cap:20000},
  {name:'제한 없음', zoom:13, cap:Infinity}   // 개수 제한 없음 — 다만 줌 13보다 넓으면 버튼을 눌러야 받습니다 (도시 전체를 저절로 받지 않게)
];
const vwLevel = () => VW_LEVELS[VW.level];
VW_OFF = new Set();   // 숨긴 용도지역 이름
/* 용도지역 색 — 계열은 색상으로, 1·2·3종은 명도로 구분합니다 */
const ZONE_FAMILY = [
  [/전용주거/, 52], [/일반주거/, 42], [/준주거/, 32],
  [/상업/,      4],
  [/공업/,    282],
  [/녹지/,    122]
];
function zoneColorAuto(name){
  const t = String(name || '');
  let hue = 210, sat = 14;
  for(const [re, h] of ZONE_FAMILY){ if(re.test(t)){ hue = h; sat = 62; break; } }
  let l = 62;
  if(/제1종/.test(t)) l = 74;
  else if(/제2종/.test(t)) l = 62;
  else if(/제3종/.test(t)) l = 50;
  return hslToHex(hue, sat, l);
}
/* 고급 색 조정에서 개별 지정한 값이 있으면 그것을 먼저 씁니다 */
function zoneColor(name){
  return (S.custom && S.custom['zone:' + name]) || zoneColorAuto(name);
}
const zoneName = props => props && (props.uname || props.UNAME || props.dgm_nm || props.name) || '미분류';
/* 현재 받아둔 용도지역 종류 */
function zoneKinds(){
  const fc = VW.data.zone;
  const map = new Map();
  if(fc) for(const f of fc.features){
    const n = zoneName(f.properties);
    map.set(n, (map.get(n) || 0) + 1);
  }
  return [...map.entries()].sort((a,b)=>b[1]-a[1]);
}

VW.key = VW_DEFAULT_KEY;
VW.domain = VW_DEFAULT_DOMAIN;
try{
  VW.key = localStorage.getItem('vworldKey') || VW_DEFAULT_KEY;
  VW.domain = localStorage.getItem('vworldDomain') || VW_DEFAULT_DOMAIN;
  VW.proxy  = localStorage.getItem('vworldProxy') || '';
  const lv = parseInt(localStorage.getItem('vworldLevel'), 10);
  if(lv >= 0 && lv < 4) VW.level = lv;
}catch(e){}
/* 브이월드가 받아주는 domain 값을 찾기 위해 차례로 시험합니다 */
const VW_DOMAIN_TRIES = ['', 'http://localhost', 'localhost', 'http://localhost:8000', location.origin];
/* 도메인 칸에 넣은 값을 맨 앞에, 흔한 변형(http 유무, 끝 슬래시, www)도 함께 시험합니다 */
function domainTries(){
  const f = (typeof el === 'function' && el('vwdomain')) ? el('vwdomain').value.trim() : (VW.domain || '');
  const out = [];
  const add = v => { if(v != null && !out.includes(v)) out.push(v); };
  if(f){
    const bare = f.replace(/^https?:\/\//, '').replace(/\/+$/, '');
    add(f); add(f.replace(/\/+$/, '')); add(f.replace(/\/+$/, '') + '/');
    add('http://' + bare); add('https://' + bare); add(bare);
    if(!bare.startsWith('www.')){ add('http://www.' + bare); add('www.' + bare); }
  }
  VW_DOMAIN_TRIES.forEach(add);
  return out;
}

const EMPTY_FC = {type:'FeatureCollection', features:[]};

async function vwFetch(which, bounds, domain, page, signal){   // signal: null 이면 화면 갱신에 끊기지 않는 요청
  const L = VW_LAYERS[which];
  const u = new URL(VW.proxy || 'https://api.vworld.kr/req/data');
  u.searchParams.set('service','data');
  u.searchParams.set('request','GetFeature');
  u.searchParams.set('version','2.0');
  if(!VW.proxy) u.searchParams.set('key', VW.key);   // 중계 서버는 서버가 키를 붙입니다
  u.searchParams.set('data', L.id);
  u.searchParams.set('format','json');
  u.searchParams.set('size','1000');
  u.searchParams.set('page', String(page || 1));
  u.searchParams.set('geometry','true');
  u.searchParams.set('crs','EPSG:4326');
  if(!VW.proxy){
    if(domain === undefined) domain = VW.domain;
    if(domain) u.searchParams.set('domain', domain);
  }
  const bx = Array.isArray(bounds) ? bounds
           : [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()];
  u.searchParams.set('geomFilter', `BOX(${bx[0]},${bx[1]},${bx[2]},${bx[3]})`);

  const raw = await fetch(u.toString(), {signal: signal !== undefined ? (signal || undefined) : (VW.abort && VW.abort.signal)});
  const text = await raw.text();
  let r;
  try{ r = JSON.parse(text); }
  catch(e){ throw new Error('HTTP ' + raw.status + ' · ' + text.slice(0,120)); }
  const res = r && r.response;
  if(!res) throw new Error(JSON.stringify(r).slice(0,150));
  if(res.status === 'NOT_FOUND') return EMPTY_FC;
  if(res.status !== 'OK'){
    const e = res.error || {};
    const err = new Error([e.code, e.text].filter(Boolean).join(' ') || res.status || '알 수 없는 오류');
    err.code = e.code || res.status;
    throw err;
  }
  return (res.result && res.result.featureCollection) || EMPTY_FC;
}

/* 브이월드는 한 요청에 1000건까지만 주고, 페이지도 무한정 넘길 수 없습니다.
   그래서 범위를 4분할해 가며 나눠 받고 합칩니다. */
const VW_PAGE_LIMIT = 5;        // 한 칸에서 넘길 수 있는 페이지 수
const VW_DEPTH_LIMIT = 10;      // 4분할 최대 깊이
const VW_MAX_AREA = 9;          // 브이월드 한 요청 상한은 10km² — 여유를 둡니다
/* 경위도 상자의 대략적인 면적(km²) */
function boxAreaKm2(b){
  const latMid = (b[1] + b[3]) / 2;
  const wkm = (b[2] - b[0]) * 111.32 * Math.cos(latMid * Math.PI / 180);
  const hkm = (b[3] - b[1]) * 110.57;
  return Math.abs(wkm * hkm);
}

async function vwFetchAll(which, bounds, onProgress){
  const cap = vwLevel().cap;
  const budget = [16, 64, 200, 900][VW.level];   // 단계별 최대 요청 구역 수
  const acc = [], seen = new Set();
  const box0 = [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()];
  let cells = 0, overflow = false;

  // 같은 필지라도 요청 칸마다 잘린 조각이 다를 수 있어, 첫 좌표까지 넣어 구분합니다
  const firstXY = g => { let c = g && g.coordinates; while(Array.isArray(c) && Array.isArray(c[0])) c = c[0];
                         return Array.isArray(c) ? c[0].toFixed(7) + ',' + c[1].toFixed(7) : ''; };
  const keyOf = f => {
    const pr = f.properties || {};
    return (pr.pnu || pr.id || pr.ogc_fid || pr.uid || '') + '|' + firstXY(f.geometry);
  };
  const cellList = [];
  const take = list => {
    for(const f of list){
      const k = keyOf(f);
      if(k && seen.has(k)) continue;
      if(k) seen.add(k);
      acc.push(f);
    }
  };

  const tryFetch = async (box, page) => {
    try{ return await vwFetch(which, box, undefined, page); }
    catch(err){
      if(err.name === 'AbortError') throw err;
      if(err.code === 'INCORRECT_KEY' && !VW.proxy){
        for(const d of domainTries()){
          if(d === VW.domain) continue;
          try{
            const fc = await vwFetch(which, box, d, page);
            VW.domain = d;
            try{ localStorage.setItem('vworldDomain', d); }catch(e){}
            const f = el('vwdomain'); if(f) f.value = d;
            console.log('[클린 맵] 인증 복구 · domain =', JSON.stringify(d));
            vwStatus('도메인 ' + (d || '(없음)') + ' 으로 인증에 성공했습니다');
            return fc;
          }catch(e2){
            if(e2.name === 'AbortError') throw e2;
            console.warn('[클린 맵] domain=' + JSON.stringify(d) + ' → ' + e2.message);
          }
        }
        const e = new Error('모든 도메인 조합이 거부됐습니다. 브이월드에 등록한 서비스URL을 도메인 칸에 정확히 넣어 주세요');
        e.code = 'INCORRECT_KEY';
        throw e;
      }
      for(const wait of [600, 1800]){
        await new Promise(r=>setTimeout(r, wait));
        try{ return await vwFetch(which, box, undefined, page); }
        catch(e3){ if(e3.name === 'AbortError') throw e3; err = e3; }
      }
      throw err;
    }
  };

  async function walk(box, depth){
    if(cap !== Infinity && acc.length >= cap) return;
    if(cells >= budget){ overflow = true; return; }
    // 면적 상한을 넘으면 요청하기 전에 먼저 쪼갭니다
    if(boxAreaKm2(box) > VW_MAX_AREA && depth < VW_DEPTH_LIMIT){
      const [w0, s0, e0, n0] = box, mx0 = (w0+e0)/2, my0 = (s0+n0)/2;
      for(const sub of [[w0,s0,mx0,my0],[mx0,s0,e0,my0],[w0,my0,mx0,n0],[mx0,my0,e0,n0]]){
        await walk(sub, depth + 1);
        if(overflow || (cap !== Infinity && acc.length >= cap)) return;
      }
      return;
    }
    let page = 1, feats = [], full = false;
    while(page <= VW_PAGE_LIMIT){
      const fc = await tryFetch(box, page);
      const got = (fc.features || []).length;
      feats = feats.concat(fc.features || []);
      if(got < 1000){ full = false; break; }
      if(page === VW_PAGE_LIMIT) full = true;
      page++;
      await new Promise(r=>setTimeout(r, 60));
    }
    if(full && depth < VW_DEPTH_LIMIT){          // 아직 더 있는 듯하면 4분할
      const [w, so, e, n] = box, mx = (w+e)/2, my = (so+n)/2;
      for(const sub of [[w,so,mx,my],[mx,so,e,my],[w,my,mx,n],[mx,my,e,n]]){
        await walk(sub, depth + 1);
        if(cap !== Infinity && acc.length >= cap) return;
      }
      return;
    }
    take(feats);
    cellList.push(box);
    cells++;
    if(onProgress) onProgress(acc.length, cells);
  }

  await walk(box0, 0);
  const features = (cap !== Infinity && acc.length > cap) ? acc.slice(0, cap) : acc;
  return {type:'FeatureCollection', features, partial: overflow, cells: cellList};
}

let vwTimer;
/* 이미 받아둔 범위 안이면 다시 부르지 않습니다 */
function covered(which, b){
  const p = VW.bbox[which];
  if(!p) return false;
  if(p[4] !== VW.level) return false;              // 단계가 바뀌면 다시
  if(!p[6]) return false;                          // 빈 결과였으면 다시
  if(Math.abs(p[5] - map.getZoom()) > 1.2) return false;  // 줌이 많이 바뀌면 다시
  return b.getWest() >= p[0] && b.getSouth() >= p[1]
      && b.getEast() <= p[2] && b.getNorth() <= p[3];
}
function vwRefresh(force){
  clearTimeout(vwTimer);
  vwTimer = setTimeout(async ()=>{
    const run = ++VW.run;                    // 더 새 요청이 시작되면 이 실행은 스스로 멈춥니다
    if(VW.abort) VW.abort.abort();
    VW.abort = new AbortController();
    for(const which in VW_LAYERS){
      if(run !== VW.run) return;
      if(!S.on[which]) continue;
      const L = VW_LAYERS[which];
      if(!VW.key && !VW.proxy){ vwStatus('인증키나 중계 서버 주소를 넣어 주세요', true); return; }
      const minz = vwLevel().zoom;
      if(!force && map.getZoom() < minz){
        vwStatus('많이 축소한 상태라 국내 데이터를 자동으로 받지 않습니다. 넓은 범위는 시간이 걸립니다.');
        vwAction('이 넓은 범위도 불러오기');
        continue;
      }
      vwAction('');
      const b = map.getBounds();
      if(!force && covered(which, b)){
        const n = (VW.data[which] || EMPTY_FC).features.length;
        vwStatus(L.name + ' ' + n + '개 (받아둔 범위)');
        continue;
      }
      try{
        VW.busy = true; vwStatus(L.name + ' 불러오는 중');
        const fc = await vwFetchAll(which, b,
          (n, cells) => { if(run === VW.run) vwStatus(L.name + ' ' + n + '개 받는 중 · 구역 ' + cells); });
        if(run !== VW.run) return;             // 받는 사이 새 요청이 들어왔으면 버립니다
        if(which === 'building_kr') tagUses(fc);  // 용도는 받자마자 붙여 둡니다 (지도 색 식이 읽음)
        VW.data[which] = fc;
        VW.cells[which] = fc.cells || [];
        VW.bbox[which] = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth(),
                          VW.level, map.getZoom(), fc.features.length];
        const src = map.getSource('vw-' + which);
        if(src){ src.setData(fc); map.triggerRepaint(); }
        if(which === 'zone') renderZones();
        if(which === 'building_kr'){ renderBands(); renderUses(); if(useWanted()) ensureUses(); }
        apply();                               // 껐다 켰을 때와 같은 반영을 항상 해 줍니다
        const capped = vwLevel().cap !== Infinity && fc.features.length >= vwLevel().cap;
        vwStatus(L.name + ' ' + fc.features.length + '개'
          + (fc.partial ? ' · 범위가 넓어 일부만 받았습니다 (더 확대하세요)'
            : capped ? ' · 개수 한도에 걸렸습니다' : ''));
      }catch(err){
        if(err.name === 'AbortError') continue;   // 새 요청으로 대체된 것은 오류가 아닙니다
        vwStatus(L.name + ' 실패 — ' + err.message + ' (이전 데이터 유지)', true);
        vwAction('다시 시도');
      }finally{ VW.busy = false; }
    }
  }, 900);
}
function vwStatus(msg, bad){
  const n = el('vwnote'); if(!n) return;
  n.textContent = msg; n.classList.toggle('bad', !!bad);
}
/* 버튼은 할 일이 있을 때만 보입니다 — 넓게 축소했을 때, 실패했을 때 */
function vwAction(label){
  const b = el('vwreload'); if(!b) return;
  b.hidden = !label;
  if(label) b.textContent = label;
}

/* ============================================================
   등고선 — 표고 격자에서 직접 계산합니다
   ============================================================ */
const CONTOUR = { fc:null, interval:10, busy:false };

/* 격자(nx×ny, 값은 m)에서 한 높이의 등고선을 폴리라인들로 뽑습니다.
   마칭 스퀘어 + 끝점 이어 붙이기. 좌표는 격자 칸 단위입니다. */
function isoLines(g, nx, ny, levels){
  const out = new Map();            // 높이 → [폴리라인...]
  const segs = new Map();           // 높이 → [[edgeA, edgeB]...]
  const pts = new Map();            // 높이 → Map(edge → [x,y])
  for(const t of levels){ segs.set(t, []); pts.set(t, new Map()); }
  const lo = levels[0], hi = levels[levels.length - 1];
  const step = levels.length > 1 ? levels[1] - levels[0] : 1;

  for(let j = 0; j < ny - 1; j++){
    for(let i = 0; i < nx - 1; i++){
      const v0 = g[j*nx + i], v1 = g[j*nx + i + 1], v2 = g[(j+1)*nx + i + 1], v3 = g[(j+1)*nx + i];
      const mn = Math.min(v0, v1, v2, v3), mx = Math.max(v0, v1, v2, v3);
      if(mx < lo || mn > hi) continue;
      let k0 = Math.max(0, Math.ceil((mn - lo) / step));
      const k1 = Math.min(levels.length - 1, Math.floor((mx - lo) / step));
      for(let k = k0; k <= k1; k++){
        const t = levels[k];
        let c = 0;
        if(v0 >= t) c |= 8; if(v1 >= t) c |= 4; if(v2 >= t) c |= 2; if(v3 >= t) c |= 1;
        if(c === 0 || c === 15) continue;
        const P = pts.get(t), S = segs.get(t);
        // 변 이름: 위 h{i},{j} · 아래 h{i},{j+1} · 왼쪽 v{i},{j} · 오른쪽 v{i+1},{j}
        const T = 'h' + i + ',' + j,       B = 'h' + i + ',' + (j+1);
        const L = 'v' + i + ',' + j,       R = 'v' + (i+1) + ',' + j;
        const at = (a, b) => (t - a) / ((b - a) || 1e-9);
        if(!P.has(T)) P.set(T, [i + at(v0, v1), j]);
        if(!P.has(B)) P.set(B, [i + at(v3, v2), j + 1]);
        if(!P.has(L)) P.set(L, [i, j + at(v0, v3)]);
        if(!P.has(R)) P.set(R, [i + 1, j + at(v1, v2)]);
        const mid = (v0 + v1 + v2 + v3) / 4 >= t;
        switch(c){
          case 1: case 14: S.push([L, B]); break;
          case 2: case 13: S.push([B, R]); break;
          case 3: case 12: S.push([L, R]); break;
          case 4: case 11: S.push([T, R]); break;
          case 6: case 9:  S.push([T, B]); break;
          case 7: case 8:  S.push([T, L]); break;
          case 5:  if(mid){ S.push([T, L]); S.push([B, R]); } else { S.push([T, R]); S.push([L, B]); } break;
          case 10: if(mid){ S.push([T, R]); S.push([L, B]); } else { S.push([T, L]); S.push([B, R]); } break;
        }
      }
    }
  }

  // 같은 변을 공유하는 조각끼리 이어 붙입니다
  for(const t of levels){
    const S = segs.get(t), P = pts.get(t), lines = [];
    const byEdge = new Map();
    S.forEach((s, idx) => {
      for(const e of s){ if(!byEdge.has(e)) byEdge.set(e, []); byEdge.get(e).push(idx); }
    });
    const used = new Uint8Array(S.length);
    const nextFrom = (edge, from) => {
      const list = byEdge.get(edge) || [];
      for(const idx of list) if(!used[idx] && idx !== from) return idx;
      return -1;
    };
    for(let s0 = 0; s0 < S.length; s0++){
      if(used[s0]) continue;
      used[s0] = 1;
      const chain = [S[s0][0], S[s0][1]];
      // 뒤로 늘리기
      let cur = s0, tail = S[s0][1];
      for(;;){
        const n = nextFrom(tail, cur); if(n < 0) break;
        used[n] = 1; const [a, b] = S[n]; tail = (a === tail) ? b : a; chain.push(tail); cur = n;
        if(tail === chain[0]) break;
      }
      // 앞으로 늘리기
      if(chain[chain.length - 1] !== chain[0]){
        cur = s0; let head = S[s0][0];
        for(;;){
          const n = nextFrom(head, cur); if(n < 0) break;
          used[n] = 1; const [a, b] = S[n]; head = (a === head) ? b : a; chain.unshift(head); cur = n;
        }
      }
      lines.push(chain.map(e => P.get(e)));
    }
    out.set(t, lines);
  }
  return out;
}

/* 격자 → GeoJSON. toLngLat(gx, gy) 로 좌표를 바꿉니다 */
function contoursToGeoJSON(g, nx, ny, interval, toLngLat, opts){
  opts = opts || {};
  let mn = Infinity, mx = -Infinity;
  for(let i = 0; i < g.length; i++){ const v = g[i]; if(v < mn) mn = v; if(v > mx) mx = v; }
  const start = Math.max(opts.landOnly ? interval : -Infinity, Math.ceil(mn / interval) * interval);
  const levels = [];
  for(let t = start; t <= mx; t += interval) levels.push(t);
  if(!levels.length) return {type:'FeatureCollection', features:[], min:mn, max:mx};
  const lines = isoLines(g, nx, ny, levels);
  const majorEvery = interval * 5;
  const features = [];
  for(const [t, ls] of lines){
    const major = Math.abs(t % majorEvery) < 1e-6;
    for(const l of ls){
      if(l.length < 3) continue;
      let len = 0; for(let q = 1; q < l.length; q++) len += Math.hypot(l[q][0]-l[q-1][0], l[q][1]-l[q-1][1]);
      if(len < 4) continue;                               // 격자 몇 칸짜리 잡음은 버립니다
      features.push({type:'Feature',
        properties:{ele:t, major, name: major ? String(t) : ''},
        geometry:{type:'LineString', coordinates:l.map(([x, y]) => toLngLat(x, y))}});
    }
  }
  return {type:'FeatureCollection', features, min:mn, max:mx};
}

/* 표고 타일 (AWS Terrain Tiles, Terrarium 형식, 키 없음) */
const DEM_URL = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png';
const DEM_CREDIT = '표고 © Mapzen · AWS Terrain Tiles (SRTM 등)';

async function fetchDemTile(z, x, y){
  const r = await fetch(DEM_URL.replace('{z}', z).replace('{x}', x).replace('{y}', y));
  if(!r.ok) throw new Error('표고 타일 ' + r.status);
  const bmp = await createImageBitmap(await r.blob(), {colorSpaceConversion:'none', premultiplyAlpha:'none'});
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 256;
  const cx = cv.getContext('2d', {willReadFrequently:true});
  cx.drawImage(bmp, 0, 0);
  const d = cx.getImageData(0, 0, 256, 256).data;
  const out = new Float32Array(256 * 256);
  for(let i = 0; i < out.length; i++) out[i] = d[i*4]*256 + d[i*4+1] + d[i*4+2]/256 - 32768;
  return out;
}

async function makeContours(interval){
  const b = map.getBounds();
  const lng2x = (lng, z) => (lng + 180) / 360 * Math.pow(2, z);
  const lat2y = (lat, z) => { const r = lat * Math.PI / 180;
    return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * Math.pow(2, z); };

  // 화면을 덮는 타일이 너무 많지 않도록 줌을 고릅니다 (원자료가 30m 라 14 이상은 의미가 없습니다)
  let z = Math.max(9, Math.min(14, Math.floor(map.getZoom())));
  let tx0, tx1, ty0, ty1;
  for(;;){
    tx0 = Math.floor(lng2x(b.getWest(), z));  tx1 = Math.floor(lng2x(b.getEast(), z));
    ty0 = Math.floor(lat2y(b.getNorth(), z)); ty1 = Math.floor(lat2y(b.getSouth(), z));
    if((tx1 - tx0 + 1) * (ty1 - ty0 + 1) <= 30 || z <= 9) break;
    z--;
  }
  const ntx = tx1 - tx0 + 1, nty = ty1 - ty0 + 1;
  const W = ntx * 256, H = nty * 256;
  const full = new Float32Array(W * H);
  let done = 0;
  const jobs = [];
  for(let ty = ty0; ty <= ty1; ty++) for(let tx = tx0; tx <= tx1; tx++){
    jobs.push(fetchDemTile(z, tx, ty).then(t => {
      const ox = (tx - tx0) * 256, oy = (ty - ty0) * 256;
      for(let r = 0; r < 256; r++) full.set(t.subarray(r*256, r*256 + 256), (oy + r) * W + ox);
      ctStatus('표고 받는 중 · ' + (++done) + '/' + (ntx * nty));
    }));
  }
  await Promise.all(jobs);

  // 격자를 적당히 줄이면서 평균을 내 계단 무늬를 없앱니다
  const sf = Math.max(1, Math.ceil(Math.max(W, H) / 700));
  const nx = Math.floor(W / sf), ny = Math.floor(H / sf);
  let g = new Float32Array(nx * ny);
  for(let j = 0; j < ny; j++) for(let i = 0; i < nx; i++){
    let sum = 0;
    for(let dy = 0; dy < sf; dy++) for(let dx = 0; dx < sf; dx++) sum += full[(j*sf + dy) * W + i*sf + dx];
    g[j*nx + i] = sum / (sf * sf);
  }
  const blur = new Float32Array(nx * ny);          // 3×3 평활화 한 번
  for(let j = 0; j < ny; j++) for(let i = 0; i < nx; i++){
    let sum = 0, n = 0;
    for(let dy = -1; dy <= 1; dy++) for(let dx = -1; dx <= 1; dx++){
      const x = i + dx, y = j + dy;
      if(x >= 0 && y >= 0 && x < nx && y < ny){ sum += g[y*nx + x]; n++; }
    }
    blur[j*nx + i] = sum / n;
  }
  g = blur;

  const scale = 256 * Math.pow(2, z);
  const toLngLat = (gx, gy) => {
    const px = tx0 * 256 + (gx + 0.5) * sf, py = ty0 * 256 + (gy + 0.5) * sf;
    const lng = px / scale * 360 - 180;
    const lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * py / scale))) * 180 / Math.PI;
    return [lng, lat];
  };
  ctStatus('등고선 계산 중');
  await new Promise(r => setTimeout(r, 20));
  const fc = contoursToGeoJSON(g, nx, ny, interval, toLngLat, {landOnly:true});
  fc.meta = {z, sf, cell: Math.round(40075016 * Math.cos(map.getCenter().lat*Math.PI/180) / scale * sf)};
  return fc;
}

function ctStatus(msg, bad){
  const n = el('ctnote'); if(!n) return;
  n.textContent = msg; n.classList.toggle('bad', !!bad);
}


/* 건물 층수 — 지상 층수(gro_flo_co)로 높이를 만듭니다 */
const BLD_BANDS = [
  {max:2,        name:'1~2층'},
  {max:4,        name:'3~4층'},
  {max:9,        name:'5~9층'},
  {max:19,       name:'10~19층'},
  {max:Infinity, name:'20층 이상'}
];
let BLD_OFF = new Set();                      // 숨긴 층수 구간
const floorsOf = pr => { const v = parseFloat(pr && (pr.gro_flo_co ?? pr.GRO_FLO_CO)); return isFinite(v) ? v : 0; };
const bandOf = pr => { const f = floorsOf(pr); return (BLD_BANDS.find(b => f <= b.max) || BLD_BANDS[0]).name; };
function bandColorAuto(name){
  const i = Math.max(0, BLD_BANDS.findIndex(b => b.name === name));
  const [h, sa, l] = hexToHsl(baseColors().building);
  return hslToHex(h, clamp(sa + i * 6, 0, 100), clamp(l + 10 - i * 11, 6, 96));
}
function bandColor(name){ return (S.custom && S.custom['bld:' + name]) || bandColorAuto(name); }
function bandCounts(){
  const fc = VW.data.building_kr, m = new Map();
  BLD_BANDS.forEach(b => m.set(b.name, 0));
  if(fc) for(const f of fc.features) m.set(bandOf(f.properties), (m.get(bandOf(f.properties)) || 0) + 1);
  return [...m.entries()].filter(([, n]) => n > 0);
}

/* 건물 용도 — 건물 용도 코드(건축법 시행령 별표1 순서: 01 단독주택, 02 공동주택, 03·04 근린생활 …)를
   다이어그램에 쓰기 좋게 8가지로 묶습니다. 코드가 없고 용도 이름만 있으면 이름으로 가립니다.
   색은 토지이용 현황도 관례(주거 노랑 · 상업 빨강 · 공공 파랑 · 산업 보라)를 따르되 채도를 낮췄습니다. */
const BLD_USES = [
  { name:'단독주택',   hsl:[48, 72, 78],  codes:['01'],                     re:/단독|다가구|다중주택|공관/ },
  { name:'공동주택',   hsl:[38, 78, 62],  codes:['02'],                     re:/공동주택|아파트|연립|다세대|기숙사/ },
  { name:'근린생활',   hsl:[20, 72, 68],  codes:['03', '04'],               re:/근린/ },
  { name:'상업·숙박',  hsl:[356, 60, 62], codes:['07', '15', '16', '27'],   re:/판매|숙박|위락|관광휴게|시장|상점|백화점|호텔/ },
  { name:'업무',       hsl:[262, 38, 66], codes:['14'],                     re:/업무|오피스|사무/ },
  { name:'공공·교육',  hsl:[205, 52, 62], codes:['05', '06', '09', '10', '11', '12', '13', '23', '24'], re:/교육|학교|의료|병원|노유자|수련|문화|집회|종교|운동|교정|군사|방송|공공|청사/ },
  { name:'산업·물류',  hsl:[288, 18, 56], codes:['08', '17', '18', '19', '20', '21', '22', '25'], re:/공장|창고|위험물|자동차|운수|동물|식물|자원순환|분뇨|쓰레기|발전/ },
  { name:'기타',       hsl:[30, 8, 72],   codes:[],                         re:null }
];
const USE_NONE = '정보 없음';
/* 칠할 용도 — 켠 용도만 용도 색, 나머지는 원래 건물 색(층수별·한 색 / 매스 색)을 따릅니다.
   고른 용도와 바꾼 색은 다음에 열어도 그대로입니다. */
const USE_ON = new Set();
const USE_COL = {};                                           // 바꾼 용도 색
let USE_STASH = [];                                           // 미리보기에서 잠깐 끈 동안 기억해 둘 목록
try{
  const v = JSON.parse(localStorage.getItem('cleanmapUse') || 'null');
  if(v){ (v.on || []).forEach(n => { if(BLD_USES.some(u => u.name === n)) USE_ON.add(n); }); Object.assign(USE_COL, v.col || {}); }
}catch(e){}
function useSave(){ try{ localStorage.setItem('cleanmapUse', JSON.stringify({ on:[...USE_ON], col:USE_COL })); }catch(e){} }
const useActive = () => USE_ON.size > 0;
const USE_CODE_KEYS = ['bdtyp_cd', 'main_purps_cd', 'mainpurpscd', 'buld_prpos_cd', 'prpos_cd', 'bd_typ_cd', 'bldg_use_cd', 'use_cd'];
const USE_NAME_KEYS = ['bdtyp_nm', 'main_purps_cd_nm', 'mainpurpscdnm', 'main_purps_nm', 'buld_prpos_nm', 'prpos_nm', 'bldg_use_nm', 'buld_use', 'usage'];
/* 속성 이름은 대소문자가 섞여 오므로 소문자로 맞춰 찾습니다 */
function useField(pr, keys){
  if(!pr) return '';
  for(const k of Object.keys(pr)){ if(k === '_use') continue; if(keys.includes(k.toLowerCase())){ const v = pr[k]; if(v != null && String(v).trim() !== '') return String(v).trim(); } }
  return '';
}
function useOf(pr){
  if(pr && pr._use) return pr._use;
  const code = useField(pr, USE_CODE_KEYS);
  if(code){
    if(/^[A-Za-z]/.test(code)) return '기타';                         // Z0000 같은 기타 코드
    let d = code.replace(/\D/g, '');
    if(d.length === 4) d = '0' + d;                                    // 01000 이 숫자로 와서 1000 이 된 경우
    if(d.length >= 2){
      const u = BLD_USES.find(x => x.codes.includes(d.slice(0, 2)));
      return u ? u.name : '기타';
    }
    if(/[가-힣]/.test(code)){ const u = BLD_USES.find(x => x.re && x.re.test(code)); return u ? u.name : '기타'; }
  }
  const nm = useField(pr, USE_NAME_KEYS);
  if(nm){ const u = BLD_USES.find(x => x.re && x.re.test(nm)); return u ? u.name : '기타'; }
  return USE_NONE;
}
function useColorAuto(name){
  const u = BLD_USES.find(x => x.name === name);
  return u ? hslToHex(...u.hsl) : null;
}
function useColor(name, fallback){
  return USE_COL[name] || useColorAuto(name) || fallback || baseColors().building;
}
/* 켠 용도면 용도 색, 아니면 null (쓰는 쪽의 원래 색) */
const useHi = pr => { if(!useActive()) return null; const u = useOf(pr); return USE_ON.has(u) ? u : null; };
/* ---------- 용도 정보 — 브이월드 GIS건물통합정보(WFS getBldgisSpceWFS · dt_d010) ----------
   건물_국내(도로명주소 건물)에는 용도 칸이 없어서, 건축물대장 용도코드(buld_prpos_code)가 붙은
   GIS건물통합정보를 따로 받아 위치로 맞춥니다 (건물 가운데 점을 품은 통합정보 건물의 용도). */
const USE_SRC = { polys:[], grid:new Map(), boxes:[], ver:0, busy:false, err:'', done:0, total:0, partial:false };
const USE_CELL = 0.0005;                                       // 격자 칸 (도, 약 50m)
const useCodeName = code => { const c = String(code || '').trim(); return c ? useOf({ bdtyp_cd:c }) : USE_NONE; };
function useIndex(poly){
  const k = USE_SRC.polys.push(poly) - 1, [x0, y0, x1, y1] = poly.b;
  for(let gx = Math.floor(x0 / USE_CELL); gx <= Math.floor(x1 / USE_CELL); gx++)
    for(let gy = Math.floor(y0 / USE_CELL); gy <= Math.floor(y1 / USE_CELL); gy++){
      const key = gx + ',' + gy; if(!USE_SRC.grid.has(key)) USE_SRC.grid.set(key, []); USE_SRC.grid.get(key).push(k);
    }
}
const ringHas = (r, x, y) => { let inside = false; for(let i = 0, j = r.length - 1; i < r.length; j = i++){ const [xi, yi] = r[i], [xj, yj] = r[j]; if((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside; } return inside; };
function useAt(x, y){
  const ids = USE_SRC.grid.get(Math.floor(x / USE_CELL) + ',' + Math.floor(y / USE_CELL)); if(!ids) return null;
  let near = null, nd = 1e9;
  for(const k of ids){
    const p = USE_SRC.polys[k];
    if(x >= p.b[0] && x <= p.b[2] && y >= p.b[1] && y <= p.b[3] && ringHas(p.r, x, y)) return p;
    const cx = (p.b[0] + p.b[2]) / 2, cy = (p.b[1] + p.b[3]) / 2, d = Math.hypot(cx - x, cy - y);
    if(d < nd){ nd = d; near = p; }
  }
  return nd < 0.00008 ? near : null;                           // 안에 없으면 약 8m 안의 가장 가까운 것
}
/* 건물 한 동의 대표점 — 바깥 고리의 면적 중심 (안 되면 꼭짓점 평균) */
function bldPoint(g){
  const r = g && (g.type === 'Polygon' ? g.coordinates[0] : g.type === 'MultiPolygon' ? g.coordinates[0][0] : null); if(!r || r.length < 3) return null;
  let a = 0, cx = 0, cy = 0; const x0 = r[0][0], y0 = r[0][1];
  for(let i = 1; i < r.length; i++){ const p = r[i - 1], q = r[i], k = (p[0] - x0) * (q[1] - y0) - (q[0] - x0) * (p[1] - y0); a += k; cx += (p[0] - x0 + q[0] - x0) * k; cy += (p[1] - y0 + q[1] - y0) * k; }
  if(Math.abs(a) > 1e-14) return [x0 + cx / (3 * a), y0 + cy / (3 * a)];
  return [r.reduce((s, p) => s + p[0], 0) / r.length, r.reduce((s, p) => s + p[1], 0) / r.length];
}
/* 받은 건물에 용도를 붙입니다 — 통합정보가 있으면 그 용도, 없으면 건물 자체 속성(대개 정보 없음) */
function tagUses(fc, force){
  if(!fc || !fc.features) return;
  if(!force && fc._useTag === USE_SRC.ver + 1) return;
  for(const f of fc.features){
    if(!f.properties) f.properties = {};
    const pr = f.properties; delete pr._use;
    let u = useOf(pr);
    if(u === USE_NONE && USE_SRC.polys.length){ const pt = bldPoint(f.geometry), hit = pt && useAt(pt[0], pt[1]); if(hit) u = useCodeName(hit.code); }
    pr._use = u;
  }
  fc._useTag = USE_SRC.ver + 1;
  try{ const src = map && map.getSource && map.getSource('vw-building_kr'); if(src && VW.data.building_kr === fc) src.setData(fc); }catch(e){}
}
async function useWfsBox(box, depth, budget){
  if(budget.left <= 0){ budget.partial = true; return []; }
  budget.left--;
  const u = new URL('https://api.vworld.kr/ned/wfs/getBldgisSpceWFS');
  const q = { key:VW.key, typename:'dt_d010', bbox:box.map(v => v.toFixed(6)).join(','), srsName:'EPSG:4326', maxFeatures:'1000', output:'text/xml; subtype=gml/2.1.2' };
  if(VW.domain) q.domain = VW.domain;
  for(const [k, v] of Object.entries(q)) u.searchParams.set(k, v);
  const text = await (await fetch(u.toString())).text();
  if(/^\s*\{/.test(text)){ let m = text.slice(0, 160); try{ const r = JSON.parse(text).response || {}; m = (r.error && (r.error.text || r.error.code)) || r.status || m; }catch(e){} throw new Error(m); }
  const doc = new DOMParser().parseFromString(text, 'text/xml');
  const mem = doc.getElementsByTagNameNS('*', 'featureMember');
  if(!mem.length){
    const ex = doc.getElementsByTagNameNS('*', 'ServiceException')[0] || doc.getElementsByTagName('error')[0];
    if(ex || !/FeatureCollection/.test(text)) throw new Error(((ex && ex.textContent) || text).replace(/\s+/g, ' ').trim().slice(0, 140));
    budget.done++; return [];
  }
  if(mem.length >= 1000 && depth < 5){                         // 상한에 걸리면 넷으로 나눠 다시
    const [x0, y0, x1, y1] = box, mx = (x0 + x1) / 2, my = (y0 + y1) / 2, out = [];
    for(const sb of [[x0, y0, mx, my], [mx, y0, x1, my], [x0, my, mx, y1], [mx, my, x1, y1]]) out.push(...await useWfsBox(sb, depth + 1, budget));
    return out;
  }
  const polys = [];
  for(const m of mem){
    const el0 = [...m.children][0]; if(!el0) continue;
    const val = n => { const e = el0.getElementsByTagNameNS('*', n)[0]; return e ? e.textContent.trim() : ''; };
    const code = val('buld_prpos_code'), id = val('gis_idntfc_no') || val('buld_idntfc_no');
    // 건물 모양은 바깥 고리(outerBoundaryIs)의 좌표 — 맨 앞의 boundedBy 상자 좌표는 건너뜁니다
    const outs = [...el0.getElementsByTagNameNS('*', 'outerBoundaryIs')];
    const rings = (outs.length ? outs : [...el0.getElementsByTagNameNS('*', 'LinearRing')]).map(o => o.getElementsByTagNameNS('*', 'coordinates')[0]).filter(Boolean);
    rings.forEach((co, k) => {
      const r = co.textContent.trim().split(/\s+/).map(t => t.split(',').map(Number)).filter(p => p.length >= 2 && isFinite(p[0]) && isFinite(p[1]));
      if(r.length < 3) return;
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; for(const [x, y] of r){ x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
      polys.push({ r, b:[x0, y0, x1, y1], code, id:id ? id + (k ? '#' + k : '') : '' });
    });
  }
  budget.done++;
  return polys;
}
/* 받아 둔 건물 범위의 용도 정보를 (없는 만큼만) 받아 맞춥니다 */
async function ensureUses(){
  const fc = VW.data.building_kr, bb = VW.bbox.building_kr;
  if(!fc || !fc.features.length || !bb || USE_SRC.busy) return;
  const box = bb.slice(0, 4);
  if(USE_SRC.boxes.some(g => g[0] <= box[0] && g[1] <= box[1] && g[2] >= box[2] && g[3] >= box[3])){ tagUses(fc); renderUses(); return; }
  if(!VW.key){ USE_SRC.err = '브이월드 인증키가 필요합니다'; renderUses(); return; }
  USE_SRC.busy = true; USE_SRC.err = ''; renderUses();
  const budget = { left:200, done:0, partial:false };           // 마산 2×2km 약 1.4만 동에 45번 정도
  const tick = setInterval(() => { USE_SRC.done = budget.done; renderUses(); }, 700);
  try{
    // 넓으면 처음부터 나눠서 (한 번에 약 0.6km²) — 동시에 3개씩
    const W = box[2] - box[0], H = box[3] - box[1], n = Math.max(1, Math.min(6, Math.ceil(Math.sqrt(W * H / 0.00006))));
    const cells = []; for(let i = 0; i < n; i++) for(let j = 0; j < n; j++) cells.push([box[0] + W * i / n, box[1] + H * j / n, box[0] + W * (i + 1) / n, box[1] + H * (j + 1) / n]);
    const seen = new Set(USE_SRC.polys.map(p => p.id).filter(Boolean));
    let next = 0;
    const worker = async () => { while(next < cells.length){ const c = cells[next++]; const got = await useWfsBox(c, 0, budget); for(const p of got){ if(p.id && seen.has(p.id)) continue; if(p.id) seen.add(p.id); useIndex(p); } } };
    await Promise.all([worker(), worker(), worker()]);
    if(!budget.partial) USE_SRC.boxes.push(box);
    USE_SRC.partial = budget.partial;
    USE_SRC.ver++;
  }catch(err){ USE_SRC.err = err.message || String(err); }
  clearInterval(tick);
  USE_SRC.busy = false;
  tagUses(VW.data.building_kr, true);
  renderUses();
  if(useActive()){ if(typeof register3d === 'function' && typeof SITE !== 'undefined' && SITE.view3d) register3d(); apply(); }
}
const useWanted = () => useActive() || (el('usebox') && el('usebox').open) || (el('stusebox') && el('stusebox').open);
function useCounts(){
  const fc = VW.data.building_kr, m = new Map();
  [...BLD_USES.map(u => u.name), USE_NONE].forEach(n => m.set(n, 0));
  if(fc){ tagUses(fc); for(const f of fc.features){ const u = useOf(f.properties); m.set(u, (m.get(u) || 0) + 1); } }
  return [...m.entries()].filter(([, n]) => n > 0);
}
/* 용도 정보가 하나도 없으면 — 브이월드가 실제로 준 속성 이름을 보여 줘서 어느 칸을 읽어야 할지 알 수 있게 */
function useDiag(){
  const fc = VW.data.building_kr;
  if(!fc || !fc.features.length) return '건물_국내를 받으면 용도를 받아 셉니다';
  if(USE_SRC.busy) return `용도 받는 중 — 브이월드 건물통합정보 ${USE_SRC.done}구역…`;
  const rows = useCounts(), none = (rows.find(r => r[0] === USE_NONE) || [0, 0])[1], all = fc.features.length;
  if(USE_SRC.err) return '용도를 받지 못했습니다 — ' + USE_SRC.err + (/key|KEY|인증키 정보|도메인|domain|권한|승인/.test(USE_SRC.err) ? ' (브이월드 인증키에 국가중점데이터·WFS 사용이 켜져 있어야 합니다)' : '');
  if(none < all) return (useActive() ? '켠 용도만 칠하고 나머지는 원래 건물 색 · ' : '칠할 용도를 켜세요 — 끈 용도는 원래 건물 색 · ')
    + `용도 ${all - none}/${all}동 (건물통합정보)` + (USE_SRC.partial ? ' · 범위가 넓어 일부만' : '');
  if(!USE_SRC.ver) return '목록을 열면 용도를 받아 옵니다';
  return '이 범위에서는 용도를 찾지 못했습니다' + (USE_SRC.polys.length ? ` (통합정보 ${USE_SRC.polys.length}동과 위치가 맞지 않음)` : ' (통합정보 0동)');
}
/* 용도 목록 — 지도 꾸미기와 대지분석 두 곳에 같은 목록을 그립니다 (정보 없음은 칠할 수 없어 목록에서 뺍니다) */
function renderUses(){
  const rows = useCounts().filter(([n]) => n !== USE_NONE);
  const html = rows.map(([n, cnt]) => `
    <div class="zrow urow ${USE_ON.has(n) ? 'on' : ''}" data-u="${esc(n)}">
      <input type="checkbox" class="uon" ${USE_ON.has(n) ? 'checked' : ''} title="이 용도 칠하기">
      <input type="color" class="ucol" value="${useColor(n)}" title="색 바꾸기">
      <span>${esc(n)}</span><b>${cnt}</b>
    </div>`).join('');
  for(const [listId, noteId] of [['uselist', 'usenote'], ['stuselist', 'stusenote']]){
    if(el(listId)) el(listId).innerHTML = html;
    if(el(noteId)) el(noteId).textContent = useDiag();
  }
  const sum = USE_ON.size ? [...USE_ON].join(' · ') : '';
  for(const id of ['usecount', 'stusecount']) if(el(id)) el(id).textContent = sum;
  if(el('axp-use')) el('axp-use').checked = useActive();
}
/* 칠할 용도를 바꾸면 평면 지도 · 3D 매스 · 축측 · 영역 ISO 가 모두 따라갑니다 */
function useChanged(){
  if(useActive()) tagUses(VW.data.building_kr);
  useSave(); renderUses();
  if(typeof register3d === 'function' && typeof SITE !== 'undefined' && SITE.view3d) register3d();
  apply();
}
function setUseOn(name, on){ if(on) USE_ON.add(name); else USE_ON.delete(name); USE_STASH = []; useChanged(); if(on) ensureUses(); }
/* 미리보기의 "용도 색" — 끄면 고른 목록을 잠깐 치워 두고, 다시 켜면 되살립니다 */
function toggleUseAll(on){
  if(on){ if(!USE_ON.size && USE_STASH.length) USE_STASH.forEach(n => USE_ON.add(n)); USE_STASH = []; }
  else{ if(USE_ON.size) USE_STASH = [...USE_ON]; USE_ON.clear(); }
  useChanged();
  return useActive();
}
/* ============================================================
   3. 상태
   ============================================================ */
const S = {
  preset:'ink', labelMode:1, lang:'ko', weight:1, ratio:'free',
  on:{parcel:false, building_kr:true, zone:false, district:false},   // 건물_국내는 기본으로 받습니다   // 브이월드 데이터 받기 여부
  vis:{'vw-parcel-fill':false, 'building':false, 'building-line':false},   // 레이어별 표시 여부 — 바탕 지도(OSM) 건물은 기본으로 끔 (브이월드 건물을 씁니다)
  lw:{},                                              // 레이어별 선 굵기 배수
  parcelFill:false, bldFloors:true, bldFH:3.0, bldZ:true, noMaritime:true, closeCoast:true,
  custom:{}, adj:{h:0, s:0, l:0}, slot:'roadMajor',
  sat:'none', satOpacity:1, satInSvg:true, dxfUnit:'mm',
  fills:true, fillOpacity:1
};
const SLOTS = [
  ['bg','배경'],['water','물'],['waterLine','물가 선'],['green','녹지'],['wood','산림'],
  ['building','건물'],['buildingLine','건물 선'],['roadMajor','주요 도로'],['roadMinor','이면 도로'],
  ['rail','철도'],['boundary','경계'],['label','라벨'],['labelHalo','라벨 테두리'],['parcel','필지선'],['parcelFill','필지면'],['zone','용도지역 기타'],['district','지구단위계획'],['contour','등고선'],['contourMajor','계곡선']
];
/* 레이어 목록 — 표시 토글과 색 슬롯을 한 줄에서 다룹니다 */
function layerRows(){
  const rows = [];
  for(const L of FILL_LAYERS) rows.push({id:L.id, slot:L.color});
  for(const L of LINE_LAYERS) rows.push({id:L.id, slot:L.color, line:true});
  rows.push({id:'vw-zone',             slot:'zone',         which:'zone'});
  rows.push({id:'vw-parcel-fill',      slot:'parcelFill',   which:'parcel'});
  rows.push({id:'vw-parcel',           slot:'parcel',       which:'parcel', line:true});
  rows.push({id:'vw-building_kr',      slot:'building',     which:'building_kr'});
  rows.push({id:'vw-building_kr-line', slot:'buildingLine', which:'building_kr', line:true});
  rows.push({id:'vw-building_kr-label', slot:'label',        which:'building_kr'});
  rows.push({id:'vw-district',         slot:'district',     which:'district'});
  if(CONTOUR.fc){
    rows.push({id:'contour-minor', slot:'contour',      line:true});
    rows.push({id:'contour-major', slot:'contourMajor', line:true});
  }
  return rows;
}
const visible = id => S.vis[id] !== false;
const lw = id => (S.lw[id] == null ? 1 : S.lw[id]);

/* ============================================================
   4. 레이어 정의 — 스타일과 SVG 출력이 같은 정의를 공유합니다
   ============================================================ */
const stops = (arr)=>['interpolate',['linear'],['zoom'],...arr.flat()];
function evalStops(arr,z){
  if(z<=arr[0][0]) return arr[0][1];
  if(z>=arr[arr.length-1][0]) return arr[arr.length-1][1];
  for(let i=0;i<arr.length-1;i++){
    const [z0,v0]=arr[i],[z1,v1]=arr[i+1];
    if(z>=z0&&z<=z1) return v0+(v1-v0)*(z-z0)/(z1-z0);
  }
  return arr[arr.length-1][1];
}

const FILL_LAYERS = [
  {id:'water',      sl:'water',      group:'water',    color:'water'},
  {id:'green',      sl:'park',       group:'green',    color:'green'},
  {id:'wood',       sl:'landcover',  group:'green',    color:'wood',
   filter:['in','class','wood','scrub']},
  {id:'landcover',  sl:'landcover',  group:'green',    color:'green',
   filter:['in','class','grass','farmland']},
  {id:'building',   sl:'building',   group:'building', color:'building', minzoom:13}
];
const LINE_LAYERS = [
  {id:'waterway',      sl:'waterway',       group:'water',    color:'waterLine', w:[[7,.5],[12,1.1],[16,2.2]]},
  {id:'building-line', sl:'building',       group:'building', color:'buildingLine', minzoom:14, w:[[14,.25],[18,.5]]},
  {id:'rail',          sl:'transportation', group:'rail',     color:'rail', road:true,
   filter:['==','class','rail'], w:[[9,.4],[14,.8],[18,1.6]]},
  {id:'road-minor',    sl:'transportation', group:'road',     color:'roadMinor', road:true,
   filter:['in','class','minor','service','track','path'], w:[[12,.35],[15,1],[18,3],[20,8]]},
  {id:'road-major',    sl:'transportation', group:'road',     color:'roadMajor', road:true,
   filter:['in','class','motorway','trunk','primary','secondary','tertiary'],
   w:[[5,.4],[10,1],[14,2.2],[17,6],[20,16]]},
  {id:'boundary',      sl:'boundary',       group:'boundary', color:'boundary',
   filter:['<=','admin_level',4], dash:[3,2], w:[[3,.6],[10,1.1]]}
];
// tier 1=지역명 2=세부지명 3=전체
const LABEL_LAYERS = [
  {id:'label-country',  sl:'place', tier:1, filter:['==','class','country'], s:[[2,10],[6,15]]},
  {id:'label-state',    sl:'place', tier:1, filter:['==','class','state'],   s:[[4,9],[9,13]]},
  {id:'label-city',     sl:'place', tier:1, filter:['in','class','city','town'], s:[[5,10],[12,15]]},
  {id:'label-locality', sl:'place', tier:2, filter:['in','class','village','suburb','neighbourhood','quarter','hamlet'], s:[[11,10],[16,13]]},
  {id:'label-peak',     sl:'mountain_peak', tier:2, minzoom:10, s:[[10,9],[15,12]]},
  {id:'label-water',    sl:'water_name', tier:3, s:[[8,9],[15,12]], italic:true},
  {id:'label-road',     sl:'transportation_name', tier:3, line:true, minzoom:13, s:[[13,9],[18,12]]},
  {id:'label-poi',      sl:'poi', tier:3, minzoom:15, s:[[15,9],[18,11]]}
];

function textField(){
  if(S.lang==='local') return ['get','name'];
  const key = S.lang==='ko' ? 'name:ko' : 'name:en';
  return ['coalesce',['get',key],['get','name:latin'],['get','name']];
}
function preset(){ return PRESETS.find(p=>p.id===S.preset) || PRESETS[0]; }

/* --- 색 변환 --- */
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
function hexToRgb(h){
  h = String(h).replace('#','');
  if(h.length===3) h = h.split('').map(c=>c+c).join('');
  return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
}
function rgbToHex(r,g,b){
  const f = v => clamp(Math.round(v),0,255).toString(16).padStart(2,'0');
  return '#' + f(r) + f(g) + f(b);
}
function rgbToHsl(r,g,b){
  r/=255; g/=255; b/=255;
  const mx = Math.max(r,g,b), mn = Math.min(r,g,b), d = mx-mn, l = (mx+mn)/2;
  let h = 0, s = 0;
  if(d){
    s = l>0.5 ? d/(2-mx-mn) : d/(mx+mn);
    h = mx===r ? ((g-b)/d + (g<b?6:0)) : mx===g ? ((b-r)/d + 2) : ((r-g)/d + 4);
    h *= 60;
  }
  return [h, s*100, l*100];
}
function hslToRgb(h,s,l){
  h = ((h%360)+360)%360; s = clamp(s,0,100)/100; l = clamp(l,0,100)/100;
  const c = (1-Math.abs(2*l-1))*s, x = c*(1-Math.abs((h/60)%2-1)), m = l-c/2;
  let r,g,b;
  if(h<60)       [r,g,b]=[c,x,0];
  else if(h<120) [r,g,b]=[x,c,0];
  else if(h<180) [r,g,b]=[0,c,x];
  else if(h<240) [r,g,b]=[0,x,c];
  else if(h<300) [r,g,b]=[x,0,c];
  else           [r,g,b]=[c,0,x];
  return [(r+m)*255,(g+m)*255,(b+m)*255];
}
const hexToHsl = h => rgbToHsl(...hexToRgb(h));
const hslToHex = (h,s,l) => rgbToHex(...hslToRgb(h,s,l));

/* 프리셋 색 + 개별 수정 + 전체 보정을 합친 최종 색 */
function baseColors(){
  const b = {...preset().colors, ...S.custom};
  if(!b.parcel) b.parcel = b.buildingLine;   // 프리셋에 없으면 건물선 색을 씁니다
  if(!b.zone) b.zone = b.green;
  if(!b.parcelFill) b.parcelFill = b.parcel;
  if(!b.district) b.district = b.zone || b.green;
  if(!b.contour) b.contour = b.boundary;
  if(!b.contourMajor) b.contourMajor = b.buildingLine;
  return b;
}
function colors(){
  const base = baseColors(), a = S.adj;
  if(!a.h && !a.s && !a.l) return base;
  const out = {};
  for(const k in base){
    const [h,s,l] = hexToHsl(base[k]);
    out[k] = hslToHex(h + a.h, clamp(s*(1+a.s/100),0,100), clamp(l + a.l,0,100));
  }
  return out;
}
function labelOf(p){
  if(p && p.label != null) return p.label;      // 분석 레이어 라벨
  if(S.lang==='local') return p.name;
  const key = S.lang==='ko' ? 'name:ko' : 'name:en';
  return p[key] || p['name:latin'] || p.name;
}

let SVGSTYLE = {};   // 레이어 id → SVG 출력용 스타일 (현재 줌 기준)
let ORDER = [];      // SVG 그룹 출력 순서

/* 추가 레이어 — 대지분석(site.js)처럼 바깥 모듈이 계산한 지오JSON을 지도·SVG·DXF에 함께 태웁니다.
   stage: ground(브이월드 면 아래) · fill(면 위) · line(선 위) · top(라벨 위) */
const EXTRA = { layers:new Map() };
function extraSet(id, def){ EXTRA.layers.set(id, def); }
/* 그리는 순서 가중치 — 0: 면 다이어그램, 1: 거점 원·결절점·점 같은 표지 */
const EXTRA_MARK = /(-cir-|^hub-|^tr-node|^tr-front|^tour-|^life-(?!iso)|^biz-pt|^biz-mix|^pop-dots|^bus-(stop|dot|hub|near|gap-dot)|^kt-|^wind-)/;
function extraWeight(id){ return EXTRA_MARK.test(id) ? 1 : 0; }
function extraRemove(prefix){ for(const id of [...EXTRA.layers.keys()]) if(id.startsWith(prefix)) EXTRA.layers.delete(id); }

function buildStyle(){
  if(typeof beforeBuildStyle === 'function') beforeBuildStyle();
  if(typeof registerAdmLayers === 'function' && admWant().length) registerAdmLayers();
  if(typeof registerClipLayers === 'function') registerClipLayers();      // 행정구역으로 자르기 — 구역 밖 어둡게·경계선   // 스타일 색이 바뀌면 행정경계 색도   // 대지분석: 새로 받은 건물로 3D 매스 갱신
  const p = preset(), c = colors(), hidden = new Set(p.hidden||[]);
  const layers = [{id:'bg', type:'background', paint:{'background-color':c.bg}}];
  // 국내 건물이 들어와 있으면 겹치는 OSM 건물은 그리지 않습니다 (해외에서는 그대로)
  const krBld = S.on.building_kr && visible('vw-building_kr')
             && VW.data.building_kr && VW.data.building_kr.features.length > 0;
  const osmOff = id => krBld && (id === 'building' || id === 'building-line');
  const sources = {omt:{type:'vector', tiles:TILES, maxzoom:14,
    attribution:'© OpenStreetMap contributors'}};
  const sat = SAT_SOURCES[S.sat];
  if(sat){
    sources.sat = {type:'raster', tiles:sat.tiles, tileSize:256,
      maxzoom:sat.maxzoom, attribution:sat.credit};
    layers.push({id:'sat', type:'raster', source:'sat',
      paint:{'raster-opacity':S.satOpacity}});
  }
  const z = (map && typeof map.getZoom === 'function') ? map.getZoom() : 12;
  SVGSTYLE = {}; ORDER = [];

  for(const L of FILL_LAYERS){
    if(!visible(L.id) || osmOff(L.id)) continue;
    const off = !S.fills || hidden.has(L.id);          // 화면에서만 감춤 (형상은 남김)
    const op = off ? 0 : S.fillOpacity;
    layers.push({
      id:L.id, type:'fill', source:'omt', 'source-layer':L.sl,
      ...(L.minzoom?{minzoom:L.minzoom}:{}), ...(L.filter?{filter:L.filter}:{}),
      paint:{'fill-color':c[L.color], 'fill-opacity':op, 'fill-antialias':true}
    });
    SVGSTYLE[L.id]={kind:'fill', fill:c[L.color], opacity:op,
      q:{sourceLayer:L.sl, filter:L.filter}}; ORDER.push(L.id);
  }
  pushExtra('ground');                // 분석 면(일영 등)은 건물 아래로
  pushVW('fill');                     // 면은 도로 아래로
  pushExtra('fill');

  if(CONTOUR.fc && CONTOUR.fc.features.length){
    sources.contour = {type:'geojson', data: CONTOUR.fc};
    const cm = [[10,.25],[14,.5],[17,.9]].map(([zz,v])=>[zz, v*lw('contour-minor')]);
    const cM = [[10,.6],[14,1.1],[17,1.8]].map(([zz,v])=>[zz, v*lw('contour-major')]);
    if(visible('contour-minor')){
      layers.push({id:'contour-minor', type:'line', source:'contour',
        filter:['!=', ['get','major'], true],
        layout:{'line-join':'round','line-cap':'round'},
        paint:{'line-color':c.contour, 'line-width':stops(cm)}});
      SVGSTYLE['contour-minor'] = {kind:'line', stroke:c.contour, width:+evalStops(cm, z).toFixed(2), q:{contour:'minor'}};
      ORDER.push('contour-minor');
    }
    if(visible('contour-major')){
      layers.push({id:'contour-major', type:'line', source:'contour',
        filter:['==', ['get','major'], true],
        layout:{'line-join':'round','line-cap':'round'},
        paint:{'line-color':c.contourMajor, 'line-width':stops(cM)}});
      SVGSTYLE['contour-major'] = {kind:'line', stroke:c.contourMajor, width:+evalStops(cM, z).toFixed(2), q:{contour:'major'}};
      ORDER.push('contour-major');
      if(S.labelMode > 0 && visible('contour-label')){
        layers.push({id:'contour-label', type:'symbol', source:'contour',
          filter:['==', ['get','major'], true],
          layout:{'symbol-placement':'line','text-field':['to-string',['get','ele']],
                  'text-font':['Noto Sans Regular'],'text-size':10,'text-max-angle':30,
                  'symbol-spacing':320},
          paint:{'text-color':c.contourMajor,'text-halo-color':c.bg,'text-halo-width':1.5}});
        SVGSTYLE['contour-label'] = {kind:'text', fill:c.contourMajor, size:10};
        ORDER.push('contour-label');
      }
    }
  }

  for(const L of LINE_LAYERS){
    if(!visible(L.id) || hidden.has(L.id) || osmOff(L.id)) continue;
    const k = (L.road ? S.weight : 1) * lw(L.id);
    const w = L.w.map(([zz,v])=>[zz, +(v*k).toFixed(3)]);
    // 행정경계에서 해상 경계를 뺍니다 (해안선을 따라가는 바다 위 경계)
    const flt = (L.id === 'boundary' && S.noMaritime && L.filter)
      ? ['all', L.filter, ['!=', 'maritime', 1], ['!=', 'maritime', true]]
      : L.filter;
    layers.push({
      id:L.id, type:'line', source:'omt', 'source-layer':L.sl,
      ...(L.minzoom?{minzoom:L.minzoom}:{}), ...(flt?{filter:flt}:{}),
      layout:{'line-cap':'round','line-join':'round'},
      paint:{'line-color':c[L.color], 'line-width':stops(w), ...(L.dash?{'line-dasharray':L.dash}:{})}
    });
    SVGSTYLE[L.id]={kind:'line', stroke:c[L.color], width:+evalStops(w,z).toFixed(2), dash:L.dash,
      q:{sourceLayer:L.sl, filter:flt}};
    ORDER.push(L.id);
    // 해상 경계를 빼면 경계선이 해안에서 끊겨 열려 보입니다 → 바다 가장자리(해안선)를 같은 선으로 그어 닫습니다
    if(L.id === 'boundary' && S.noMaritime && S.closeCoast !== false){
      const cf = ['==', 'class', 'ocean'];
      layers.push({ id:'boundary-coast', type:'line', source:'omt', 'source-layer':'water', filter:cf,
        layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':c[L.color], 'line-width':stops(w), ...(L.dash?{'line-dasharray':L.dash}:{})} });
      SVGSTYLE['boundary-coast'] = {label:'행정경계_해안선', kind:'line', stroke:c[L.color], width:+evalStops(w,z).toFixed(2), dash:L.dash, ring:true,
        q:{sourceLayer:'water', filter:cf}};
      ORDER.push('boundary-coast');
    }
  }
  pushVW('line');                     // 선은 도로 위로
  pushExtra('line');

  for(const L of LABEL_LAYERS){
    if(L.tier>S.labelMode) continue;
    layers.push({
      id:L.id, type:'symbol', source:'omt', 'source-layer':L.sl,
      ...(L.minzoom?{minzoom:L.minzoom}:{}), ...(L.filter?{filter:L.filter}:{}),
      layout:{
        'text-font':['Noto Sans Regular'],
        'text-field':textField(),
        'text-size':stops(L.s),
        'text-max-width':7,
        ...(L.line?{'symbol-placement':'line','text-rotation-alignment':'map'}:{})
      },
      paint:{'text-color':c.label,'text-halo-color':c.labelHalo,'text-halo-width':1.3,'text-halo-blur':.3}
    });
    SVGSTYLE[L.id]={kind:'text', fill:c.label, size:+evalStops(L.s,z).toFixed(1), italic:!!L.italic, line:!!L.line};
    ORDER.push(L.id);
  }
  pushExtra('top');
  function pushExtra(stage){
    // 같은 단계 안에서는 면(격자·밀도 등고·동별 색 등)을 먼저, 거점 원·점 같은 표지를 나중에 — 표지가 면에 묻히지 않게
    const list = [...EXTRA.layers].map((e, i) => [e, i]).sort((a, b) => extraWeight(a[0][0]) - extraWeight(b[0][0]) || a[1] - b[1]).map(x => x[0]);
    for(const [id, d] of list){
      if(d.stage !== stage || !visible(id)) continue;
      if(d.type === 'symbol' && typeof siteLabelHidden === 'function' && siteLabelHidden(id)) continue;   // 대지분석 이름표 끄기
      if(!d.fc || !d.fc.features || !d.fc.features.length) continue;
      sources['x-' + id] = {type:'geojson', data:d.fc};
      layers.push({id, type:d.type, source:'x-' + id, ...(d.layout?{layout:d.layout}:{}), paint:d.paint || {}});
      if(d.noExport) continue;            // 지도에만 (예: 자를 구역 밖 어둡게)
      SVGSTYLE[id] = {...d.svg, label:d.label, q:{extra:id}, nomerge:!!d.nomerge};
      ORDER.push(id);
    }
  }
  function pushVW(want){
    for(const which in VW_LAYERS){
      if(!S.on[which]) continue;
      const L = VW_LAYERS[which], lid = 'vw-' + which;
      if((L.kind === 'fill' ? 'fill' : 'line') !== want) continue;   // 면·선 단계를 나눠 그립니다
      const minz = vwLevel().zoom;          // 레이어별 고정 문턱 없이 단계 설정만 따릅니다
      sources[lid] = {type:'geojson', data: VW.data[which] || EMPTY_FC};
      if(L.kind === 'fill'){
        const isZone = which === 'zone';
        const flat = isZone || which === 'district';
      const isBld = which === 'building_kr';
      const col = isZone ? c.zone : (which === 'district' ? c.district : c.building);
        const op  = flat ? 0.42 : S.fillOpacity;
        let paintCol = col, zFilter = null;
        if(isZone){
          const kinds = zoneKinds();
          if(kinds.length){
            const m = ['match', ['get', 'uname']];
            for(const [n] of kinds){ m.push(n, zoneColor(n)); }
            m.push(col);
            paintCol = m;
          }
          if(VW_OFF.size) zFilter = ['!', ['in', ['get','uname'], ['literal', [...VW_OFF]]]];
        }
        let bFilter = null;
        if(isBld){
          const fl = ['to-number', ['coalesce', ['get','gro_flo_co'], 0]];
          if(S.bldFloors){                                  // 층수 구간별 색
            const ramp = ['step', fl, bandColor(BLD_BANDS[0].name)];
            for(let i = 1; i < BLD_BANDS.length; i++) ramp.push(BLD_BANDS[i-1].max + 0.5, bandColor(BLD_BANDS[i].name));
            paintCol = ramp;
          }
          if(useActive()){                                  // 켠 용도만 용도 색 — 나머지는 위의 층수별·한 색 그대로
            tagUses(VW.data.building_kr);
            const m = ['match', ['coalesce', ['get', '_use'], USE_NONE]];
            for(const n of USE_ON) m.push(n, useColor(n));
            m.push(paintCol);
            paintCol = m;
          }
          if(BLD_OFF.size){                                 // 숨긴 구간 제외
            const any = ['any'];
            BLD_BANDS.forEach((b, i) => {
              if(BLD_OFF.has(b.name)) return;
              const lo = i ? BLD_BANDS[i-1].max + 0.5 : -1e9;
              any.push(['all', ['>', fl, lo], ['<=', fl, b.max === Infinity ? 1e9 : b.max]]);
            });
            bFilter = any.length > 1 ? any : ['==', fl, -1e9];
          }
        }
        if(visible(lid)){
        layers.push({id:lid, type:'fill', source:lid, 
          ...(zFilter?{filter:zFilter}:{}), ...(bFilter?{filter:bFilter}:{}),
          paint:{'fill-color':paintCol, 'fill-opacity':op, 'fill-antialias':true}});
        SVGSTYLE[lid] = {kind:'fill', fill:col, opacity:op, q:{which},
          ...(isZone?{split:'uname', colorOf:zoneColor, keyOf:zoneName, off:VW_OFF}:{}),
          ...(isBld && useActive()?{split:'use',                  // 켠 용도는 용도별로, 나머지는 층수 구간(또는 한 묶음)으로
                keyOf:pr => BLD_OFF.has(bandOf(pr)) ? '__off' : (useHi(pr) || (S.bldFloors ? bandOf(pr) : '그 외')),
                colorOf:k => USE_ON.has(k) ? useColor(k) : S.bldFloors ? bandColor(k) : col,
                off:new Set(['__off'])}
             : isBld && S.bldFloors?{split:'band', colorOf:bandColor, keyOf:bandOf, off:BLD_OFF}:{})};
        ORDER.push(lid);
      }
        if(isZone){
          layers.push({id:lid+'-label', type:'symbol', source:lid, minzoom:Math.max(minz,14),
            ...(zFilter?{filter:zFilter}:{}),
            layout:{'text-font':['Noto Sans Regular'], 'text-field':['get','uname'],
                    'text-size':stops([[14,9],[17,12]]), 'text-max-width':6},
            paint:{'text-color':c.label,'text-halo-color':c.labelHalo,'text-halo-width':1.3}});
          SVGSTYLE[lid+'-label'] = {kind:'text', fill:c.label,
            size:+evalStops([[14,9],[17,12]], z).toFixed(1)};
          ORDER.push(lid+'-label');
        }
        if(isBld && visible(lid+'-label') && S.labelMode > 0){
          layers.push({id:lid+'-label', type:'symbol', source:lid,
            ...(bFilter?{filter:bFilter}:{}),
            layout:{'text-font':['Noto Sans Regular'],
                    'text-field':['concat', ['to-string', ['coalesce', ['get','gro_flo_co'], '?']], '층'],
                    'text-size':stops([[16,9],[19,12]])},
            paint:{'text-color':c.label,'text-halo-color':c.labelHalo,'text-halo-width':1.2}});
          SVGSTYLE[lid+'-label'] = {kind:'text', fill:c.label, size:+evalStops([[16,9],[19,12]], z).toFixed(1)};
          ORDER.push(lid+'-label');
        }
        if(!flat && visible(lid+'-line')){
          const bw = [[15,.3],[18,.6],[20,1.2]].map(([zz,v])=>[zz, v*lw(lid+'-line')]);
          layers.push({id:lid+'-line', type:'line', source:lid, 
            paint:{'line-color':c.buildingLine, 'line-width':stops(bw)}});
          SVGSTYLE[lid+'-line'] = {kind:'line', stroke:c.buildingLine,
            width:+evalStops(bw, z).toFixed(2), q:{which}};
          ORDER.push(lid+'-line');
        }
      }else{
        if(which === 'parcel' && visible(lid+'-fill')){
          layers.push({id:lid+'-fill', type:'fill', source:lid, 
            paint:{'fill-color':c.parcelFill, 'fill-opacity':0.32, 'fill-antialias':true}});
          SVGSTYLE[lid+'-fill'] = {kind:'fill', fill:c.parcelFill, opacity:0.32, q:{which}};
          ORDER.push(lid+'-fill');
        }
        const pw = [[15,.4],[18,1],[20,2]].map(([zz,v])=>[zz, v*lw(lid)]);
        if(visible(lid)){
          layers.push({id:lid, type:'line', source:lid, 
            layout:{'line-cap':'round','line-join':'round'},
            paint:{'line-color':c.parcel, 'line-width':stops(pw)}});
          SVGSTYLE[lid] = {kind:'line', stroke:c.parcel, width:+evalStops(pw, z).toFixed(2), q:{which}};
          ORDER.push(lid);
        }
      }
    }
  }
  const seenId = new Set(), clean = [];
  for(const L of layers){
    if(seenId.has(L.id)){ console.warn('[클린 맵] 중복 레이어 제외:', L.id); continue; }
    seenId.add(L.id); clean.push(L);
  }
  const styleObj = {version:8, glyphs:GLYPHS, sources, layers:clean};
  if(typeof styleExtras === 'function') styleExtras(styleObj);   // 대지분석: 지형(3D) 등
  return styleObj;
}

/* ============================================================
   5. 지도
   ============================================================ */
let map;
const el = id => document.getElementById(id);

function setStatus(html, bad){
  const n = el('status'); if(!n) return;
  n.innerHTML = html; n.classList.toggle('bad', !!bad);
}
function loadScript(src){
  return new Promise((ok,no)=>{
    const s = document.createElement('script');
    s.src = src; s.onload = ok; s.onerror = ()=>no(new Error(src));
    document.head.appendChild(s);
  });
}

async function boot(){
  if(typeof maplibregl === 'undefined'){
    setStatus('지도 라이브러리를 다시 받는 중입니다');
    try{ await loadScript('https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js'); }catch(e){}
  }
  if(typeof maplibregl === 'undefined'){
    setStatus('지도 라이브러리를 불러오지 못했습니다. 인터넷 연결을 확인하거나 파일을 로컬 서버로 여세요.<br><b>python -m http.server 8000</b>', true);
    return;
  }

  await resolveSource();
  let firstError = '';
  try{
    map = new maplibregl.Map({
      container:'map',
      style:buildStyle(),
      center:[126.9784, 37.5666],
      zoom:13,
      preserveDrawingBuffer:true,
      attributionControl:false,
      hash:true
    });
  }catch(e){
    setStatus('지도를 만들지 못했습니다 — ' + e.message + '<br>브라우저에서 WebGL이 꺼져 있을 수 있습니다.', true);
    return;
  }
  el('map').style.background = colors().bg;
  map.addControl(new maplibregl.NavigationControl({showCompass:true}), 'top-right');
  map.on('move', readout);
  map.on('moveend', ()=>vwRefresh());
  map.on('zoomend', ()=>{ buildStyle(); });   // SVG 선굵기를 현재 줌에 동기화
  map.on('error', e=>{ if(!firstError) firstError = (e && e.error && e.error.message) || '알 수 없는 오류'; });
  map.on('load', ()=>{
    setStatus('준비됐습니다'); readout(); layoutFrame();
    if(Object.keys(VW_LAYERS).some(k => S.on[k])) vwRefresh(true);
    const q = new URLSearchParams(location.search).get('q');
    if(q){ el('q').value = q; goTo(q); }
  });
  setTimeout(()=>{
    if(!map.loaded()){
      setStatus('타일을 받지 못했습니다' + (firstError ? ' — ' + esc(firstError) : '')
        + '<br>로컬 서버로 열었는지, 방화벽이 tiles.openfreemap.org를 막는지 확인해 주세요.', true);
    }
  }, 9000);
  window.addEventListener('resize', layoutFrame);
}

let applyTimer = null;
function apply(){
  if(!map || typeof map.setStyle !== 'function') return;
  if(applyTimer) return;                 // 연달아 부르면 한 번만 반영합니다
  applyTimer = setTimeout(()=>{
    applyTimer = null;
    try{
      map.setStyle(buildStyle());
      el('map').style.background = colors().bg;
    }catch(e){
      setStatus('스타일 적용 실패 — ' + e.message, true);
      console.error('[클린 맵] setStyle 실패', e);
    }
  }, 0);
}

/* 축척·좌표 표시 */
function metersPerPixel(){
  return 156543.03392 * Math.cos(map.getCenter().lat*Math.PI/180) / Math.pow(2, map.getZoom());
}
function niceScale(){
  const mpp = metersPerPixel(), target = mpp*130;
  const pow = Math.pow(10, Math.floor(Math.log10(target)));
  const m = [1,2,5,10].map(n=>n*pow).find(n=>n>=target*0.55) || pow*10;
  return {m, px:m/mpp};
}
/* ---------- 방위·축척 — SVG 내보내기에 붙는 방위표와 축척 막대 (지도 꾸미기 · 대지분석 같은 설정) ---------- */
const NS = { compass:'circle', bar:'blocks', pos:'bl', scale:'screen' };
try{ Object.assign(NS, JSON.parse(localStorage.getItem('cleanmapNS') || '{}')); }catch(e){}
const nsSave = () => { try{ localStorage.setItem('cleanmapNS', JSON.stringify(NS)); }catch(e){} };
const NS_FONT = `font-family="'Noto Sans CJK KR','Malgun Gothic',sans-serif"`;
/* 방위표 — (cx, cy) 가운데, rot: 북쪽이 화면 위에서 시계 방향으로 돈 각도 */
function compassSVG(kind, cx, cy, rot, ink, paper){
  if(!kind || kind === 'none') return '';
  const N = y => `<text x="0" y="${y}" text-anchor="middle" ${NS_FONT} font-size="10" font-weight="bold" fill="${ink}" stroke="none">N</text>`;
  const body = kind === 'arrow' ? `<path d="M0 -15L-6 3L0 -1L6 3Z" fill="${ink}"/>` + N(-18)
    : kind === 'cross' ? `<path d="M0 -16L3 -3L16 0L3 3L0 16L-3 3L-16 0L-3 -3Z" fill="${paper}" stroke="${ink}" stroke-width="0.8" stroke-linejoin="round"/><path d="M0 -16L3 -3L0 0L-3 -3Z" fill="${ink}"/>` + N(-20)
    : `<circle r="13" fill="${paper}" stroke="${ink}" stroke-width="0.8"/><path d="M0 -11L0 8L-5 8Z" fill="${ink}"/><path d="M0 -11L5 8L0 8Z" fill="${paper}" stroke="${ink}" stroke-width="0.6" stroke-linejoin="round"/>` + N(-17);
  return `<g id="방위" data-layer="north" transform="translate(${cx.toFixed(1)},${cy.toFixed(1)}) rotate(${rot.toFixed(1)})">${body}</g>`;
}
/* 축척 막대 — m: 막대가 나타내는 길이(미터), px: 그 화면 길이, ratio: 1:N 표기 (없으면 생략) */
function scaleBarSVG(kind, x, y, m, px, ink, paper, ratio){
  if(!kind || kind === 'none') return '';
  const lab = v => v >= 1000 ? +(v / 1000).toFixed(2) + ' km' : +v.toFixed(1) + ' m', num = v => v >= 1000 ? +(v / 1000).toFixed(2) : +v.toFixed(1);
  const F = `${NS_FONT} font-size="9" fill="${ink}" stroke="none"`;
  const X = f => (x + px * f).toFixed(1);
  let s = '';
  if(kind === 'bracket') s = `<path d="M${x} ${y - 6}V${y}H${X(1)}V${y - 6}" fill="none" stroke="${ink}" stroke-width="1"/><text x="${x}" y="${y + 12}" ${F}>${lab(m)}</text>`;
  else if(kind === 'ticks'){
    s = `<path d="M${x} ${y}H${X(1)}" stroke="${ink}" stroke-width="1"/>` + [0, 0.25, 0.5, 0.75, 1].map(f => `<path d="M${X(f)} ${y}V${y - (f === 0 || f === 0.5 || f === 1 ? 7 : 4)}" stroke="${ink}" stroke-width="1"/>`).join('')
      + [0, 0.5, 1].map(f => `<text x="${X(f)}" y="${y + 11}" text-anchor="middle" ${F}>${f === 1 ? lab(m) : num(m * f)}</text>`).join('');
  }else{                                                                 // 흑백 막대 — 0 · ¼ · ½ · 1
    const segs = [[0, 0.25], [0.25, 0.5], [0.5, 1]];
    s = segs.map(([a, b], i) => `<rect x="${X(a)}" y="${y - 5}" width="${(px * (b - a)).toFixed(1)}" height="5" fill="${i % 2 ? paper : ink}" stroke="${ink}" stroke-width="0.7"/>`).join('')
      + [0, 0.5, 1].map(f => `<text x="${X(f)}" y="${y + 10}" text-anchor="middle" ${F}>${f === 1 ? lab(m) : num(m * f)}</text>`).join('');
  }
  if(ratio) s += `<text x="${X(1)}" y="${y - 9}" text-anchor="end" ${NS_FONT} font-size="10" fill="${ink}" stroke="none">1:${ratio}</text>`;
  return `<g id="축척" data-layer="scale">${s}</g>`;
}
/* 방위표 + 축척 막대 한 묶음 — 고른 모서리에 (대지분석 범례가 오른쪽 아래에 있으면 그 위로) */
function nsBlockSVG(W, H, ink, paper, ratio){
  const {m, px} = niceScale(), bearing = map.getBearing ? map.getBearing() : 0;
  const pitched = map.getPitch && map.getPitch() > 5;
  const right = /r$/.test(NS.pos), top = /^t/.test(NS.pos), padX = 22;
  let yBar = top ? 76 : H - 22, yC = top ? 34 : H - 62;
  if(!top && right && typeof SITE !== 'undefined' && SITE.legendBox){ const lb = SITE.legendBox; yBar = lb.y0 - 16; yC = lb.y0 - 56; }
  const bx = right ? W - padX - px : padX, cx = right ? W - padX - 14 : padX + 14;
  return compassSVG(NS.compass, cx, yC, -bearing, ink, paper) + (pitched ? '' : scaleBarSVG(NS.bar, bx, yBar, m, px, ink, paper, ratio));
}
/* 고른 축척(1:N)이면 SVG 크기를 그 축척의 실제 크기(mm)로 — 일러스트레이터에서 100%로 열면 그 축척 */
function nsPhysical(W, H){
  const n = +NS.scale; if(!n) return null;
  const mpp = metersPerPixel();
  return { n, wmm:W * mpp * 1000 / n, hmm:H * mpp * 1000 / n };
}
/* 패널 — 두 모드에 같은 칸을 그립니다 */
function renderNS(){
  const opt = (k, list) => `<select data-ns="${k}">${list.map(([v, t]) => `<option value="${v}"${String(NS[k]) === String(v) ? ' selected' : ''}>${t}</option>`).join('')}</select>`;
  const html = `<div class="nsrow">${opt('compass', [['circle', '방위표: 원형'], ['arrow', '방위표: 화살'], ['cross', '방위표: 십자'], ['none', '방위표 없음']])}${opt('bar', [['blocks', '축척 막대: 흑백'], ['ticks', '축척 막대: 눈금'], ['bracket', '축척 막대: 괄호'], ['none', '축척 막대 없음']])}</div>`
    + `<div class="nsrow">${opt('pos', [['bl', '왼쪽 아래'], ['br', '오른쪽 아래'], ['tl', '왼쪽 위'], ['tr', '오른쪽 위']])}${opt('scale', [['screen', '크기: 화면 그대로'], ['500', '1:500 실제 크기'], ['1000', '1:1000 실제 크기'], ['1200', '1:1200 실제 크기'], ['2500', '1:2500 실제 크기'], ['5000', '1:5000 실제 크기']])}</div>`;
  for(const id of ['nsbox1', 'nsbox2']){ const b = el(id); if(b) b.innerHTML = html; }
  const ph = (NS.scale !== 'screen' && map) ? nsPhysical(100, 100) : null, note = NS.scale === 'screen' ? '지도를 돌려 두면 방위표도 같이 돕니다. 3D로 기울이면 축척 막대와 실제 크기(1:N)는 빠집니다.'
    : `SVG를 1:${NS.scale} 실제 크기(mm)로 저장합니다 — 일러스트레이터에서 100%로 열면 1:${NS.scale}. 지금 화면 100px ≈ ${ph ? ph.wmm.toFixed(1) : '?'}mm`;
  for(const id of ['nsnote1', 'nsnote2']){ const n = el(id); if(n) n.textContent = note; }
}
for(const id of ['nsbox1', 'nsbox2']){
  const b = el(id); if(!b) continue;
  b.addEventListener('change', e => { const k = e.target.dataset.ns; if(!k) return; NS[k] = e.target.value; nsSave(); renderNS(); });
}
renderNS();
(function hookNS(){ if(!map || !map.on){ setTimeout(hookNS, 500); return; } map.on('zoomend', () => { if(NS.scale !== 'screen') renderNS(); }); })();
function readout(){
  const {m,px} = niceScale();
  el('bar').style.width = px.toFixed(0)+'px';
  el('barlabel').textContent = m>=1000 ? (m/1000)+' km' : m+' m';
  const c = map.getCenter();
  el('coords').textContent = c.lat.toFixed(5)+', '+c.lng.toFixed(5)+'  ·  z'+map.getZoom().toFixed(1);
}

/* 출력 틀 */
function frameRect(){
  const r = el('map').getBoundingClientRect();
  if(S.ratio==='free') return {x:0,y:0,w:Math.round(r.width),h:Math.round(r.height)};
  const [a,b] = S.ratio.split(':').map(Number);
  const pad = 44, aw = r.width-pad*2, ah = r.height-pad*2;
  let w = aw, h = w*b/a;
  if(h>ah){ h = ah; w = h*a/b; }
  return {x:Math.round((r.width-w)/2), y:Math.round((r.height-h)/2), w:Math.round(w), h:Math.round(h)};
}
function layoutFrame(){
  const f = frameRect(), n = el('frame');
  if(S.ratio==='free'){ n.classList.add('hidden'); return; }
  n.classList.remove('hidden');
  n.style.left=f.x+'px'; n.style.top=f.y+'px'; n.style.width=f.w+'px'; n.style.height=f.h+'px';
}

/* ============================================================
   6. 내보내기
   ============================================================ */
const esc = s => String(s).replace(/[<>&"']/g,m=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[m]));
const r1 = n => Math.round(n*10)/10;

function collect(noClip){
  const f = frameRect();
  const feats = map.queryRenderedFeatures([[f.x,f.y],[f.x+f.w,f.y+f.h]]);
  const byLayer = new Map();
  for(const ft of feats){
    const id = ft.layer.id;
    if(!SVGSTYLE[id]) continue;
    if(!byLayer.has(id)) byLayer.set(id,[]);
    byLayer.get(id).push(ft);
  }
  // 등고선·브이월드는 화면에 그려진 조각 대신 받아둔 원본을 씁니다
  for(const id of ORDER){
    const st = SVGSTYLE[id];
    if(!st || !st.q || st.kind === 'text') continue;
    if(st.q.contour){
      const want = st.q.contour === 'major';
      const list = (CONTOUR.fc ? CONTOUR.fc.features : []).filter(x => !!x.properties.major === want);
      if(list.length) byLayer.set(id, list); else byLayer.delete(id);
    }else if(st.q.which){
      const fc = VW.data[st.q.which];
      if(fc && fc.features.length) byLayer.set(id, fc.features); else byLayer.delete(id);
    }else if(st.q.extra){
      const d = EXTRA.layers.get(st.q.extra);
      if(d && d.fc.features.length) byLayer.set(id, d.fc.features); else byLayer.delete(id);
    }
  }
  // 행정구역으로 자르기 — 구역 밖 도형은 빼고, 걸친 도형은 경계에서 자릅니다 (clip.js)
  if(!noClip && typeof clipLayers === 'function') return {f, byLayer:clipLayers(byLayer)};
  return {f, byLayer};
}

/* SVG 그룹 이름 — 일러스트레이터 레이어 패널에 이 이름이 그대로 보입니다 */
const SVG_NAMES = {
  'background':'배경', 'satellite':'위성사진', 'scale':'축척',
  'water':'물', 'waterway':'하천', 'green':'녹지', 'wood':'산림', 'landcover':'초지',
  'building':'건물', 'building-line':'건물선', 'rail':'철도',
  'road-minor':'이면도로', 'road-major':'주요도로', 'boundary':'행정경계', 'vw-parcel':'필지', 'vw-parcel-fill':'필지면', 'vw-building_kr':'건물_국내', 'vw-building_kr-line':'건물선_국내', 'vw-building_kr-label':'건물층수_국내', 'vw-zone':'용도지역', 'vw-district':'지구단위계획', 'contour-minor':'등고선_주곡선', 'contour-major':'등고선_계곡선', 'contour-label':'등고선_표고', 'vw-zone-label':'용도지역_이름',
  'label-country':'라벨_국가', 'label-state':'라벨_광역', 'label-city':'라벨_도시',
  'label-locality':'라벨_지역', 'label-peak':'라벨_산', 'label-water':'라벨_수계',
  'label-road':'라벨_도로', 'label-poi':'라벨_시설'
};
const svgName = id => (SVGSTYLE[id] && SVGSTYLE[id].label) || SVG_NAMES[id] || id;

let satWarning = '';
/* 화면 캔버스에서 출력 틀만 잘라 데이터 URL로 */
function cropCanvas(f, type, quality, clip){
  const src = map.getCanvas();
  const dpr = src.width / src.getBoundingClientRect().width;
  const cv = document.createElement('canvas');
  cv.width = Math.round(f.w*dpr); cv.height = Math.round(f.h*dpr);
  const ctx = cv.getContext('2d');
  if(clip && typeof clipCanvasPath === 'function'){ clipCanvasPath(ctx, f, dpr); ctx.clip('evenodd'); }   // 행정구역 모양으로 — 밖은 투명
  ctx.drawImage(src, f.x*dpr, f.y*dpr, f.w*dpr, f.h*dpr, 0, 0, cv.width, cv.height);
  return cv.toDataURL(type||'image/png', quality);
}
/* 사진 말고 다른 레이어를 모두 잠시 숨기고 위성 사진만 캡처
   (분석·행정구역 표시처럼 지도에만 그리는 레이어도 함께 숨겨 사진에 찍히지 않게) */
function satSnapshot(f, clip){
  return new Promise(resolve=>{
    const keep = new Set(['bg', 'sat']);
    const ids = ((map.getStyle() || {}).layers || []).map(l => l.id)
      .filter(id => !keep.has(id) && map.getLayoutProperty(id, 'visibility') !== 'none');
    ids.forEach(id=>map.setLayoutProperty(id,'visibility','none'));
    map.triggerRepaint();
    map.once('idle', ()=>{
      let url = null;
      // 행정구역으로 자를 때는 구역 밖을 투명하게 뺀 PNG — 클리핑 마스크 없이 일러스트레이터에서 그대로 보입니다
      try{ url = cropCanvas(f, clip ? 'image/png' : 'image/jpeg', 0.85, clip); }
      catch(e){ url = null; }   // 타일 서버가 CORS를 막으면 캔버스를 읽을 수 없습니다
      ids.forEach(id=>{ if(map.getLayer(id)) map.setLayoutProperty(id,'visibility','visible'); });
      resolve(url);
    });
  });
}

async function buildSVG(){
  if(typeof clipPrepare === 'function') await clipPrepare();             // 행정구역으로 자를 때 — 넓은 범위 도로를 먼저 받습니다
  let {f, byLayer} = collect();
  if(typeof clipFrame === 'function') f = clipFrame(f);                   // 출력 틀을 구역에 딱 맞게
  // 기울인 3D 화면이면 지금 구도 그대로 (원근 · 지형 따라) — view3d.js
  const persp = typeof perspSetup === 'function' ? perspSetup(f) : null;
  const mass3d = !!(persp && typeof SITE !== 'undefined' && SITE.view3d && EXTRA.layers.has('d3-mass'));
  const P = persp ? persp.P : ll => { const p = map.project(ll); return [p.x-f.x, p.y-f.y]; };
  const W = f.w, H = f.h;

  /* 클리핑 마스크 대신 도형을 틀 경계에서 직접 잘라냅니다 */
  // 면: Sutherland–Hodgman (사각형 틀은 볼록하므로 어떤 다각형이든 정확히 잘립니다)
  const clipRing = pts => {
    const edges = [
      [p => p[0] >= 0, (a,b) => { const t = (0 - a[0]) / (b[0] - a[0]); return [0, a[1] + t*(b[1]-a[1])]; }],
      [p => p[0] <= W, (a,b) => { const t = (W - a[0]) / (b[0] - a[0]); return [W, a[1] + t*(b[1]-a[1])]; }],
      [p => p[1] >= 0, (a,b) => { const t = (0 - a[1]) / (b[1] - a[1]); return [a[0] + t*(b[0]-a[0]), 0]; }],
      [p => p[1] <= H, (a,b) => { const t = (H - a[1]) / (b[1] - a[1]); return [a[0] + t*(b[0]-a[0]), H]; }]
    ];
    let out = pts;
    for(const [inside, cut] of edges){
      if(!out.length) break;
      const src = out; out = [];
      for(let i = 0; i < src.length; i++){
        const cur = src[i], prev = src[(i + src.length - 1) % src.length];
        const ci = inside(cur), pi = inside(prev);
        if(ci){ if(!pi) out.push(cut(prev, cur)); out.push(cur); }
        else if(pi){ out.push(cut(prev, cur)); }
      }
    }
    return out;
  };
  // 선: 구간마다 Liang–Barsky 로 자르고, 이어지는 조각끼리 다시 붙입니다
  const clipSeg = (a, b) => {
    let t0 = 0, t1 = 1;
    const dx = b[0]-a[0], dy = b[1]-a[1];
    const tests = [[-dx, a[0]], [dx, W - a[0]], [-dy, a[1]], [dy, H - a[1]]];
    for(const [p, q] of tests){
      if(p === 0){ if(q < 0) return null; continue; }
      const r = q / p;
      if(p < 0){ if(r > t1) return null; if(r > t0) t0 = r; }
      else     { if(r < t0) return null; if(r < t1) t1 = r; }
    }
    return [[a[0]+t0*dx, a[1]+t0*dy], [a[0]+t1*dx, a[1]+t1*dy], t0 > 0, t1 < 1];
  };
  const clipLine = pts => {
    const parts = []; let cur = null;
    for(let i = 1; i < pts.length; i++){
      const r = clipSeg(pts[i-1], pts[i]);
      if(!r){ if(cur){ parts.push(cur); cur = null; } continue; }
      const [a, b, enteredMid, leftMid] = r;
      if(!cur || enteredMid) { if(cur) parts.push(cur); cur = [a]; }
      cur.push(b);
      if(leftMid){ parts.push(cur); cur = null; }
    }
    if(cur) parts.push(cur);
    return parts;
  };
  const toD = (pts, close) => {
    let d = '', px = null, py = null;
    for(let i = 0; i < pts.length; i++){
      const [x, y] = pts[i];
      if(i && Math.abs(x-px) < 0.18 && Math.abs(y-py) < 0.18 && i !== pts.length-1) continue;
      d += (d ? 'L' : 'M') + r1(x) + ' ' + r1(y);
      px = x; py = y;
    }
    return d && close ? d + 'Z' : d;
  };
  const ringD = coords => {
    const pts = persp ? persp.ring(coords) : coords.map(P);
    if(pts.length > 1){ const a = pts[0], z = pts[pts.length-1]; if(a[0]===z[0] && a[1]===z[1]) pts.pop(); }
    const c = clipRing(pts);
    return c.length >= 3 ? toD(c, true) : '';
  };
  const lineD = coords => (persp ? persp.line(coords) : [coords.map(P)]).flatMap(clipLine).filter(p => p.length > 1).map(p => toD(p, false)).join('');
  const shape = (g, asRing) => {
    if(!g) return '';
    if(asRing && (g.type === 'Polygon' || g.type === 'MultiPolygon'))
      return (g.type === 'Polygon' ? [g.coordinates] : g.coordinates).map(p => p.map(lineD).join('')).join('');
    switch(g.type){
      case 'LineString':      return lineD(g.coordinates);
      case 'MultiLineString': return g.coordinates.map(lineD).join('');
      case 'Polygon':         return g.coordinates.map(ringD).join('');
      case 'MultiPolygon':    return g.coordinates.map(p => p.map(ringD).join('')).join('');
      default: return '';
    }
  };

  const c = colors();
  const out = [];
  const phys = persp && persp.pitch >= 2 ? null : nsPhysical(f.w, f.h);   // 1:N 실제 크기로 저장할 때만 mm 크기 (기울인 화면은 축척이 하나가 아니라 제외)
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${phys ? phys.wmm.toFixed(2) + 'mm' : f.w}" height="${phys ? phys.hmm.toFixed(2) + 'mm' : f.h}" viewBox="0 0 ${f.w} ${f.h}">`);
  const ctr = map.getCenter(), b = map.getBounds(), mpp = metersPerPixel();
  out.push(`<metadata>center=${ctr.lat.toFixed(6)},${ctr.lng.toFixed(6)} zoom=${map.getZoom().toFixed(2)} `
    +`bbox=${b.getWest().toFixed(6)},${b.getSouth().toFixed(6)},${b.getEast().toFixed(6)},${b.getNorth().toFixed(6)} `
    +`m_per_px=${mpp.toFixed(4)} projection=${persp ? `perspective pitch=${map.getPitch().toFixed(1)} bearing=${map.getBearing().toFixed(1)}${persp.terr ? ' terrain' : ''}` : 'EPSG:3857'} style=${preset().id} ${phys ? 'scale=1:' + phys.n + ' ' : ''}`
    +`data=© OpenStreetMap contributors (ODbL)</metadata>`);
  // 행정구역으로 자를 때는 바탕도 구역 모양으로 — 구역 밖은 비웁니다
  const clipD = (typeof clipBlank === 'function' && clipBlank()) ? shape({type:'MultiPolygon', coordinates:CLIP.geom}) : '';
  if(clipD) out.push(`<path id="배경" data-layer="background" d="${clipD}" fill="${c.bg}" fill-rule="evenodd"/>`);
  else out.push(`<rect id="배경" data-layer="background" x="0" y="0" width="${f.w}" height="${f.h}" fill="${c.bg}"/>`);

  satWarning = '';
  if(SAT_SOURCES[S.sat] && S.satInSvg){
    const img = await satSnapshot(f, !!clipD);
    if(img){
      out.push(`<g id="위성사진" data-layer="satellite"><image x="0" y="0" width="${f.w}" height="${f.h}" `
        + `preserveAspectRatio="none" href="${img}" xlink:href="${img}"/></g>`);
    }else{
      satWarning = '사진은 담지 못했습니다 — 타일 서버가 이미지 추출을 막았습니다';
    }
  }

  const chunks = [], pushL = (id, html) => chunks.push({ id, html });
  for(const id of ORDER){
    const st = SVGSTYLE[id], fts0 = byLayer.get(id);
    if(!st || !fts0 || !fts0.length) continue;
    if(mass3d && (id === 'd3-mass' || id === 'd3-foot')) continue;          // 입체로 따로 그립니다
    const fts = mergeForExport(id, st, fts0);
    if(st.kind==='text'){
      const seen = new Set(), items = [];
      for(const ft of fts){
        const g = ft.geometry;
        const pt = g.type==='Point' ? g.coordinates
                 : g.type==='MultiPoint' ? g.coordinates[0]
                 : g.type==='LineString' ? g.coordinates[Math.floor(g.coordinates.length/2)] : null;
        if(!pt) continue;
        const name = labelOf(ft.properties);
        if(!name) continue;
        const [x,y] = P(pt);
        if(x < 0 || y < 0 || x > f.w || y > f.h) continue;   // 틀 밖 라벨은 뺍니다
        const key = name+'|'+Math.round(x/4)+'|'+Math.round(y/4);
        if(seen.has(key)) continue; seen.add(key);
        items.push(`<text x="${r1(x)}" y="${r1(y)}">${esc(name)}</text>`);
      }
      if(items.length) pushL(id, `<g id="${svgName(id)}" data-layer="${id}" fill="${st.fill}" font-family="sans-serif" font-size="${st.size}"`
        +`${st.italic?' font-style="italic"':''} text-anchor="middle">${items.join('')}</g>`);
    }else if(st.split){
      const bins = new Map();
      for(const ft of fts){
        const key = (st.keyOf || zoneName)(ft.properties);
        const d = shape(ft.geometry, st && st.ring);
        if(!d) continue;
        if(!bins.has(key)) bins.set(key, new Set());
        bins.get(key).add(d);
      }
      for(const [key, set] of bins){
        if((st.off || VW_OFF).has(key)) continue;
        const paths = [...set].map(d=>`<path d="${d}"/>`).join('');
        // 투명도는 그룹에 한 번만 겁니다 — 조각이 겹쳐도 진해지지 않습니다
        pushL(id, `<g id="${svgName(id)}_${esc(key)}" data-layer="${id}" `
          + `fill="${st.colorOf(key)}" stroke="none" fill-rule="evenodd"`
          + (st.opacity < 1 ? ` opacity="${st.opacity}"` : '') + `>`
          + paths + `</g>`);
      }
    }else{
      // 행정구역을 나눴으면(마산·창원·진해 등) 레이어 안에서 나눈 구역마다 하위 그룹으로
      const seen = new Set(), bins = new Map();
      for(const ft of fts){
        const d = shape(ft.geometry, st && st.ring);
        if(!d || seen.has(d)) continue; seen.add(d);
        const zk = (ft.properties && ft.properties._zone) || '';
        if(!bins.has(zk)) bins.set(zk, []);
        bins.get(zk).push(`<path d="${d}"/>`);
      }
      if(!bins.size) continue;
      const paths = bins.size === 1 && bins.has('') ? bins.get('')
        : [...bins].map(([zk, ps]) => zk ? `<g id="${svgName(id)}_${esc(zk)}">${ps.join('')}</g>` : ps.join(''));
      const op = st.opacity != null ? st.opacity : 1;
      const attrs = st.kind==='fill'
        ? `fill="${st.fill}" stroke="none" fill-rule="evenodd"` + (op < 1 ? ` opacity="${op}"` : '')
        : `fill="none" stroke="${st.stroke}" stroke-width="${st.width}" stroke-linecap="round" stroke-linejoin="round"`
          + (st.dash?` stroke-dasharray="${st.dash.map(v=>v*(st.width||1)).join(' ')}"`:'') + (op < 1 ? ` opacity="${op}"` : '');
      pushL(id, `<g id="${svgName(id)}" data-layer="${id}" ${attrs}>${paths.join('')}</g>`);
    }
  }
  // 3D 매스 — 바닥 레이어(면·도로·분석 선) 위, 글자 라벨과 위 단계 표지(거점 원 등) 아래 — 화면과 같은 순서
  if(mass3d){
    const html = mass3dSVG(persp, f, clipRing, toD);
    if(html){
      let at = chunks.findIndex(ch => (SVGSTYLE[ch.id] && SVGSTYLE[ch.id].kind === 'text') || (EXTRA.layers.get(ch.id) || {}).stage === 'top');
      if(at < 0) at = chunks.length;
      chunks.splice(at, 0, { id:'__mass3d', html });
    }
  }
  // 레이어는 원래대로 하나씩 내보내고, 층수 구간처럼 한 레이어가 여러 묶음으로 나뉜 것만 하나로 묶습니다
  //   (예: 건물_국내 → 1–5층 · 6–10층 · 11층 이상)
  {
    let i = 0;
    while(i < chunks.length){
      let j = i; while(j < chunks.length && chunks[j].id === chunks[i].id) j++;
      if(j - i > 1) out.push(`<g id="${svgName(chunks[i].id)}">` + chunks.slice(i, j).map(c => c.html).join('') + `</g>`);
      else out.push(chunks[i].html);
      i = j;
    }
  }
  if(typeof SITE !== 'undefined') SITE.legendBox = null;
  if(typeof siteLegendSVG === 'function'){ const lg = siteLegendSVG(W, H); if(lg) out.push(lg); }   // 대지분석 범례
  out.push(nsBlockSVG(W, H, c.label, c.bg, phys ? phys.n : null));                                   // 방위·축척
  out.push(`</svg>`);
  return out.join('\n');
}


/* ============================================================
   DXF 내보내기 — 실척(미터) 좌표, 레이어 분리
   ============================================================ */
const R_EARTH = 6378137;
function toMerc(lng, lat){
  const x = R_EARTH * lng * Math.PI/180;
  const y = R_EARTH * Math.log(Math.tan(Math.PI/4 + (lat*Math.PI/180)/2));
  return [x, y];
}
/* 화면에 보이는 것이 아니라, 받아둔 데이터 전체를 모읍니다 */
function collectAll(){
  const byLayer = new Map();
  const rendered = collect(true).byLayer;     // 라벨은 겹침 정리된 화면 기준을 씁니다
  for(const id of ORDER){
    const st = SVGSTYLE[id];
    if(!st) continue;
    if(st.kind === 'text'){
      if(rendered.has(id)) byLayer.set(id, rendered.get(id));
      continue;
    }
    if(!st.q){ if(rendered.has(id)) byLayer.set(id, rendered.get(id)); continue; }
    if(st.q.contour){                          // 등고선 — 계산해 둔 전체
      const want = st.q.contour === 'major';
      const fts = (CONTOUR.fc ? CONTOUR.fc.features : []).filter(f => !!f.properties.major === want);
      if(fts.length) byLayer.set(id, fts);
      continue;
    }
    if(st.q.which){                            // 브이월드 — 받아둔 전체
      const fc = VW.data[st.q.which];
      if(fc && fc.features.length) byLayer.set(id, fc.features);
    }else if(st.q.extra){                      // 분석 레이어 — 계산해 둔 전체
      const d = EXTRA.layers.get(st.q.extra);
      if(d && d.fc.features.length) byLayer.set(id, d.fc.features);
    }else{                                     // OSM — 불러온 타일 전체
      try{
        const opt = {sourceLayer: st.q.sourceLayer};
        if(st.q.filter) opt.filter = st.q.filter;
        const fts = map.querySourceFeatures('omt', opt);
        if(fts.length) byLayer.set(id, fts);
      }catch(e){
        if(rendered.has(id)) byLayer.set(id, rendered.get(id));
      }
    }
  }
  return typeof clipLayers === 'function' ? clipLayers(byLayer) : byLayer;   // 행정구역으로 자르기
}

function buildDXF(){
  const f = frameRect();
  const byLayer = collectAll();
  const ctr = map.getCenter();
  const [cx, cy] = toMerc(ctr.lng, ctr.lat);
  const unit = S.dxfUnit === 'mm' ? 1000 : 1;                 // 캐드 기본 단위는 밀리미터
  const k = Math.cos(ctr.lat * Math.PI/180) * unit;           // 메르카토르 왜곡 보정 + 단위 환산
  const P = ll => {
    const [x, y] = toMerc(ll[0], ll[1]);
    return [(x-cx)*k, (y-cy)*k];
  };
  const n6 = v => (Math.round(v*1000)/1000).toFixed(3);

  const used = [];
  const body = [];

  /* R12 DXF 는 ASCII 파일입니다. 한글은 오토캐드 표준 \U+XXXX 로 적습니다 */
  const enc = str => String(str).replace(/[^\x20-\x7E]/g, ch => {
    const c = ch.charCodeAt(0);
    return c > 0xFFFF ? '' : '\\U+' + c.toString(16).toUpperCase().padStart(4, '0');
  });
  // 레이어 이름에 쓸 수 없는 문자는 밑줄로
  const layerName = str => enc(String(str).replace(/[<>\/\\":;?*|=`,]/g, '_').trim() || '0');

  const seen = new Set();
  const poly = (coords, closed, layer, zval) => {
    const pts = coords.map(P);
    const zs = n6(zval || 0);
    if(closed && pts.length > 2){
      const a = pts[0], z = pts[pts.length-1];
      if(Math.abs(a[0]-z[0]) < 1e-6 && Math.abs(a[1]-z[1]) < 1e-6) pts.pop();   // 닫힘 표시로 처리
    }
    if(pts.length < 2) return;
    const key = layer + '|' + zs + '|' + pts.length + '|' + n6(pts[0][0]) + ',' + n6(pts[0][1])
              + '|' + n6(pts[pts.length-1][0]) + ',' + n6(pts[pts.length-1][1]);
    if(seen.has(key)) return;
    seen.add(key);
    body.push('0','POLYLINE','8',layer,'66','1','70',closed?'1':'0','10','0.0','20','0.0','30',zs);
    for(const [x,y] of pts) body.push('0','VERTEX','8',layer,'10',n6(x),'20',n6(y),'30',zs);
    body.push('0','SEQEND','8',layer);
  };
  const text = (pt, str, layer, h) => {
    const [x,y] = P(pt);
    body.push('0','TEXT','8',layer,'10',n6(x),'20',n6(y),'30','0.0',
              '40',n6(h),'1',enc(str),'72','1','11',n6(x),'21',n6(y),'31','0.0');
  };

  const mPerPx = metersPerPixel() * k;   // 화면 1px 이 실제로 몇 단위인지

  /* 조각 이음매 찾기 — 경계에 딱 붙은 수평·수직 변은 원래 도형의 변이 아닙니다 */
  const zt = Math.min(14, Math.floor(map.getZoom()));
  const fracNear = v => Math.abs(v - Math.round(v)) < 0.02;          // 타일 경계 + 여유폭
  const tx = (lng, z) => (lng + 180) / 360 * Math.pow(2, z);
  const ty = (lat, z) => { const r = lat * Math.PI / 180;
    return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * Math.pow(2, z); };
  const tileSeam = (a, b) => {
    if(a[0] === b[0]) for(let z = zt; z >= zt - 2; z--) if(fracNear(tx(a[0], z))) return true;
    if(a[1] === b[1]) for(let z = zt; z >= zt - 2; z--) if(fracNear(ty(a[1], z))) return true;
    return false;
  };
  const vwSeam = which => {
    const cells = VW.cells[which] || [];
    if(!cells.length) return null;
    const X = new Set(), Y = new Set();
    for(const [w, so, e, n] of cells){ X.add(w); X.add(e); Y.add(so); Y.add(n); }
    const xs = [...X], ys = [...Y], eps = 1e-7;
    return (a, b) => xs.some(x => Math.abs(a[0]-x) < eps && Math.abs(b[0]-x) < eps)
                  || ys.some(y => Math.abs(a[1]-y) < eps && Math.abs(b[1]-y) < eps);
  };
  // 이음매 변을 빼고, 남은 부분을 열린 선으로 이어 내보냅니다
  const ringOut = (r, layer, isSeam, zv) => {
    if(!isSeam || r.length < 3){ poly(r, true, layer, zv); return; }
    const m = r.length - 1, seg = new Array(m);
    let any = false;
    for(let i = 0; i < m; i++){ seg[i] = isSeam(r[i], r[i+1]); if(seg[i]) any = true; }
    if(!any){ poly(r, true, layer, zv); return; }
    const start = seg.indexOf(true);
    let run = [];
    for(let q = 1; q <= m; q++){
      const i = (start + q) % m;
      if(seg[i]){ if(run.length > 1) poly(run, false, layer, zv); run = []; continue; }
      if(!run.length) run.push(r[i]);
      run.push(r[i + 1]);
    }
    if(run.length > 1) poly(run, false, layer, zv);
  };
  // DXF 에는 채움이 없어 면도 닫힌 선으로 나갑니다. 같은 경계의 선 레이어가 있으면 면은 빼서 겹침을 막습니다
  const inOrder = new Set(ORDER);
  const twin = id => (id.endsWith('-fill') && inOrder.has(id.slice(0, -5)))
                  || inOrder.has(id + '-line');
  for(const id of ORDER){
    const st = SVGSTYLE[id], fts0 = byLayer.get(id);
    if(!st || !fts0 || !fts0.length) continue;
    if(st.kind === 'fill' && twin(id)) continue;
    const fts = mergeForExport(id, st, fts0);
    const base = svgName(id);
    const seamOf = st.q && st.q.which ? vwSeam(st.q.which)
                 : (st.q && st.q.sourceLayer ? tileSeam : null);
    for(const ft of fts){
      const g = ft.geometry;
      if(!g) continue;
      let layer = layerName(base + (ft.properties && ft.properties._zone ? '_' + ft.properties._zone : ''));   // 나눈 구역마다 레이어
      if(st.split){
        const key = (st.keyOf || zoneName)(ft.properties);
        if((st.off || VW_OFF).has(key)) continue;
        layer = layerName(base + '_' + key);
      }
      if(!used.includes(layer)) used.push(layer);
      if(st.kind === 'text'){
        const pt = g.type==='Point' ? g.coordinates
                 : g.type==='MultiPoint' ? g.coordinates[0]
                 : g.type==='LineString' ? g.coordinates[Math.floor(g.coordinates.length/2)] : null;
        const name = pt && labelOf(ft.properties);
        if(name) text(pt, name, layer, (st.size || 10) * mPerPx);
      }else if(g.type === 'LineString'){
        const zval = (id.startsWith('contour-') && ft.properties && ft.properties.ele != null)
                   ? ft.properties.ele * (S.dxfUnit === 'mm' ? 1000 : 1) : 0;
        const a0 = g.coordinates[0], a1 = g.coordinates[g.coordinates.length - 1];
        const ring = id.startsWith('contour-') && a0 && a1 && a0[0] === a1[0] && a0[1] === a1[1];
        poly(g.coordinates, ring, layer, zval);
      }else if(g.type === 'MultiLineString'){
        g.coordinates.forEach(l => poly(l, false, layer));
      }else if(g.type === 'Polygon' || g.type === 'MultiPolygon'){
        const zb = (S.bldZ && (id === 'vw-building_kr' || id === 'vw-building_kr-line'))
                 ? floorsOf(ft.properties) * S.bldFH * (S.dxfUnit === 'mm' ? 1000 : 1) : 0;
        if(g.type === 'Polygon') g.coordinates.forEach(r => ringOut(r, layer, seamOf, zb));
        else g.coordinates.forEach(pp => pp.forEach(r => ringOut(r, layer, seamOf, zb)));
      }
    }
  }

  const layers = [...new Set(used)];
  const out = ['999', 'Clean Map export · units ' + (S.dxfUnit === 'mm' ? 'millimeters' : 'meters'),
    '0','SECTION','2','HEADER',
    '9','$ACADVER','1','AC1009',
    '9','$INSBASE','10','0.0','20','0.0','30','0.0',
    '0','ENDSEC',
    '0','SECTION','2','TABLES',
    '0','TABLE','2','LTYPE','70','1',
    '0','LTYPE','2','CONTINUOUS','70','0','3','Solid line','72','65','73','0','40','0.0',
    '0','ENDTAB',
    '0','TABLE','2','LAYER','70',String(layers.length + 1),
    '0','LAYER','2','0','70','0','62','7','6','CONTINUOUS'];
  layers.forEach((name, i) => {
    out.push('0','LAYER','2',name,'70','0','62',String((i % 7) + 1),'6','CONTINUOUS');
  });
  out.push('0','ENDTAB','0','ENDSEC','0','SECTION','2','ENTITIES');
  // 도형이 많으면 배열을 펼쳐 넣을 때 호출 한계를 넘습니다 — 문자열로 이어 붙입니다
  const tail = ['0','ENDSEC','0','EOF'];
  return out.join('\r\n') + '\r\n' + body.join('\r\n') + '\r\n' + tail.join('\r\n') + '\r\n';
}


/* ============================================================
   내보내기용 병합 — 타일·요청 단위로 조각난 면을 다시 하나로
   ============================================================ */
function unionPieces(list){
  const PC = (typeof polygonClipping !== 'undefined') ? polygonClipping : null;
  if(!PC || list.length < 2) return list;
  const polys = [];
  for(const f of list){
    const g = f.geometry; if(!g) continue;
    if(g.type === 'Polygon') polys.push(g.coordinates);
    else if(g.type === 'MultiPolygon') for(const q of g.coordinates) polys.push(q);
  }
  if(polys.length < 2) return list;
  try{
    const res = PC.union(polys[0], ...polys.slice(1));
    return res.map(pp => ({type:'Feature', properties:list[0].properties,
                           geometry:{type:'Polygon', coordinates:pp}}));
  }catch(e){
    console.warn('[클린 맵] 면 병합 실패, 원본으로 내보냅니다', e);
    return list;
  }
}

function mergeForExport(id, st, fts){
  if(!st || st.kind === 'text' || !fts || fts.length < 2 || st.nomerge) return fts;
  const gt = fts[0].geometry && fts[0].geometry.type;
  if(gt !== 'Polygon' && gt !== 'MultiPolygon') return fts;   // 선·점은 병합 대상이 아닙니다
  if(id === 'building') return fts;            // OSM 건물은 서로 맞붙어 있어 합치지 않습니다
  if(fts.length > 4000) return fts;            // 너무 많으면 시간이 오래 걸립니다
  const isVW = !!(st.q && st.q.which);
  const keyer = st.split ? (st.keyOf || zoneName)
              : isVW ? (pr => (pr && (pr.pnu || pr.id || pr.ogc_fid)) || '')
                     : (() => '*');
  const groups = new Map();
  for(const f of fts){
    const k0 = keyer(f.properties || {});
    if(isVW && !st.split && !k0){ groups.set('@' + groups.size, [f]); continue; }   // 식별자가 없으면 합치지 않습니다
    const k = ((f.properties && f.properties._zone) || '') + '|' + k0;            // 행정구역을 나눴으면 나눈 구역끼리만 합칩니다
    if(!groups.has(k)) groups.set(k, []);
    groups.get(k).push(f);
  }
  const out = [];
  for(const [, list] of groups) out.push(...(list.length > 1 ? unionPieces(list) : list));
  return out;
}

function buildGeoJSON(){
  const {byLayer} = collect();
  const features = [];
  for(const id of ORDER){
    for(const ft of (byLayer.get(id)||[])){
      features.push({type:'Feature', geometry:ft.geometry,
        properties:{...ft.properties, _layer:id, _sourceLayer:ft.sourceLayer}});
    }
  }
  return JSON.stringify({type:'FeatureCollection',
    attribution:'© OpenStreetMap contributors (ODbL)', features}, null, 1);
}

function download(name, text, mime){
  const url = URL.createObjectURL(new Blob([text],{type:mime}));
  const a = document.createElement('a');
  a.href=url; a.download=name; a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 2000);
}
function stamp(){
  const c = map.getCenter();
  return `map_${c.lat.toFixed(4)}_${c.lng.toFixed(4)}_z${map.getZoom().toFixed(0)}_${preset().id}`;
}
function exportPNG(){
  let f = frameRect();
  const src = map.getCanvas(), clip = typeof clipActive === 'function' && clipActive() && CLIP.blank;
  if(clip) f = clipFrame(f);
  const dpr = src.width / src.getBoundingClientRect().width;
  const cv = document.createElement('canvas');
  cv.width = Math.round(f.w*dpr); cv.height = Math.round(f.h*dpr);
  const ctx = cv.getContext('2d');
  if(clip){ clipCanvasPath(ctx, f, dpr); ctx.clip('evenodd'); }   // 행정구역으로 자르기 — 구역 밖은 투명하게
  ctx.drawImage(src, f.x*dpr, f.y*dpr, f.w*dpr, f.h*dpr, 0, 0, cv.width, cv.height);
  cv.toBlob(bl=>{
    const url = URL.createObjectURL(bl);
    const a = document.createElement('a'); a.href=url; a.download=stamp()+'.png'; a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 2000);
    toast('PNG를 저장했습니다');
  });
}

/* ============================================================
   7. 위치 이동
   ============================================================ */
function zoomFromMeters(m){ return clamp(Math.log2(35200000/Math.max(m,1)), 1, 20); }

function parseLoc(q){
  let m;
  // 구글 어스: @위도,경도,고도a,카메라거리d — 거리로 줌을 잡습니다
  if(m = q.match(/@(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?),[\d.]+a,([\d.]+)d/))
    return {lat:+m[1], lng:+m[2], zoom: zoomFromMeters(+m[3])};
  // 지도 중심: @위도,경도,17z · 위성/3D 에서는 z 대신 m(카메라 높이)이 옵니다
  if(m = q.match(/@(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?),([\d.]+)([zmay])/))
    return {lat:+m[1], lng:+m[2],
            zoom: m[4]==='z' ? clamp(+m[3],1,20)
                : m[4]==='m' ? zoomFromMeters(+m[3])
                : 18};   // 거리뷰(3a,75y) 는 각도 값이라 환산하지 않습니다
  // 장소 핀: !3d위도!4d경도
  if(m = q.match(/!3d(-?\d{1,2}(?:\.\d+)?)!4d(-?\d{1,3}(?:\.\d+)?)/))
    return {lat:+m[1], lng:+m[2], zoom:16};
  // 지도 퍼가기(iframe) 코드: !2d경도!3d위도
  if(m = q.match(/!2d(-?\d{1,3}(?:\.\d+)?)!3d(-?\d{1,2}(?:\.\d+)?)/))
    return {lat:+m[2], lng:+m[1], zoom:16};
  // 줌 표기가 없는 @위도,경도
  if(m = q.match(/@(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?)/))
    return {lat:+m[1], lng:+m[2], zoom:16};
  // 주소 파라미터
  if(m = q.match(/[?&](?:ll|center|q|sll|daddr|destination)=(-?\d{1,2}(?:\.\d+)?)(?:,|%2C)(-?\d{1,3}(?:\.\d+)?)/i))
    return {lat:+m[1], lng:+m[2], zoom:15};
  // 좌표만 붙여넣은 경우
  if(m = q.match(/^\s*(-?\d{1,2}(?:\.\d+)?)\s*[,\s]\s*(-?\d{1,3}(?:\.\d+)?)\s*$/))
    return {lat:+m[1], lng:+m[2], zoom:15};
  return null;
}

/* 확장 프로그램 안에서는 단축 링크의 리다이렉트를 따라갈 수 있습니다 */
async function expandShortLink(u){
  try{
    const res = await fetch(u, {redirect:'follow'});
    return (res.url && res.url !== u) ? res.url : null;
  }catch(e){ return null; }
}
function namedTerm(u){
  const m = u.match(/\/(?:place|search)\/([^/@?]+)/);
  return m ? decodeURIComponent(m[1]).replace(/\+/g,' ') : null;
}
async function geocode(term){
  try{
    const res = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='
      + encodeURIComponent(term), {headers:{'Accept-Language':'ko'}}).then(r=>r.json());
    if(!res.length) return toast('"' + term + '" 을(를) 찾지 못했습니다');
    map.jumpTo({center:[+res[0].lon, +res[0].lat], zoom:14});
    toast(res[0].display_name.split(',').slice(0,2).join(',').trim());
  }catch(e){
    toast('지명 검색에 연결하지 못했습니다. 좌표를 직접 입력해 주세요');
  }
}

async function goTo(raw){
  let q = (raw || '').trim();
  if(!q) return;

  // 1. 단축 링크면 먼저 펼칩니다
  if(/maps\.app\.goo\.gl|goo\.gl\/maps/.test(q)){
    toast('단축 링크를 푸는 중입니다');
    const full = await expandShortLink(q);
    if(full) q = full;
    else return toast('단축 링크를 풀지 못했습니다. 구글맵 주소창의 긴 주소를 붙여넣어 주세요');
  }

  // 2. 좌표
  const loc = parseLoc(q);
  if(loc){
    map.jumpTo({center:[loc.lng, loc.lat], zoom:loc.zoom});
    return toast('좌표로 이동했습니다');
  }

  // 3. 주소에 담긴 장소 이름
  const named = namedTerm(q);
  if(named) return geocode(named);

  // 4. 그 밖의 주소는 읽을 것이 없습니다
  if(/^https?:\/\//i.test(q))
    return toast('이 링크에는 좌표가 없습니다. 구글맵에서 지도를 한 번 움직인 뒤 주소창을 복사해 주세요');

  // 5. 지명 검색
  geocode(q);
}

/* ============================================================
   8. UI 연결
   ============================================================ */
let toastTimer;
function toast(msg){
  const t = el('toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>t.classList.remove('on'), 2600);
}
function renderPresets(){
  el('presets').innerHTML = PRESETS.map(p=>`
    <button class="swatch" data-id="${p.id}" aria-pressed="${p.id===S.preset}">
      <span class="chip" style="background:${p.colors.bg}">
        <i class="w" style="background:${p.colors.water}"></i>
        <i class="r1" style="background:${p.colors.roadMajor}"></i>
        <i class="r2" style="background:${p.colors.roadMinor}"></i>
      </span>
      <span>${esc(p.name)}</span>
    </button>`).join('');
}
function renderChecks(){
  const c = colors();
  const rows = layerRows().map(r=>{
    const nm = r.name || svgName(r.id) || r.id;
    let col;
    try{ col = c[r.slot] || slotColor(r.slot); }catch(e){ col = '#999999'; }
    const vw = r.which ? ' data-w="' + r.which + '"' : '';
    const wid = r.line
      ? `<input class="lw" type="range" min="0.2" max="4" step="0.1" value="${lw(r.id)}" title="선 굵기 ${lw(r.id).toFixed(1)}배">`
      : '';
    const on = r.which ? (S.on[r.which] && visible(r.id)) : visible(r.id);
    return `<div class="lrow" data-l="${r.id}"${vw}>
      <input type="checkbox" ${on?'checked':''}>
      <i class="lpick" data-s="${r.slot}" title="색 조정" style="background:${col}"></i>
      <span>${esc(nm)}</span>${wid}
    </div>`;
  });
  el('layerlist').innerHTML = rows.join('');
}

function segSync(id, val){
  [...el(id).children].forEach(b=>b.setAttribute('aria-pressed', String(b.dataset.v===String(val))));
}

window.addEventListener('error', e=>{
  const n = document.getElementById('status');
  if(n){ n.innerHTML = '오류 — ' + (e.message || '') + '<br>' + (e.filename||'') + ':' + (e.lineno||''); n.classList.add('bad'); }
});
renderPresets(); renderChecks();
segSync('labelmode', S.labelMode); segSync('ratio', S.ratio);

/* --- 고급 색 조정 --- */

function renderZones(){
  const box = el('zonebox'), list = el('zonelist');
  if(!box) return;
  const kinds = zoneKinds();
  box.hidden = !(S.on.zone && kinds.length);
  el('zonecount').textContent = kinds.length ? kinds.length + '종' : '';
  list.innerHTML = kinds.map(([n, cnt])=>`
    <div class="zrow ${VW_OFF.has(n)?'off':''}" data-z="${esc(n)}">
      <i class="zpick" title="색 조정" style="background:${zoneColor(n)}"></i>
      <span>${esc(n)}</span><b>${cnt}</b>
    </div>`).join('');
}

function renderSlots(){
  const c = colors();
  const rows = SLOTS.map(([k,label])=>`
    <button class="slot" data-k="${k}" aria-pressed="${k===S.slot}">
      <i style="background:${c[k]}"></i>${label}
    </button>`);
  el('slots').innerHTML = rows.join('');
}
function slotLabel(slot){
  if(slot.startsWith('zone:')) return slot.slice(5);
  if(slot.startsWith('bld:')) return slot.slice(4);
  if(slot.startsWith('use:')) return slot.slice(4);
  const f = SLOTS.find(x=>x[0]===slot);
  return f ? f[1] : slot;
}
function slotColor(slot){
  if(slot.startsWith('zone:')) return zoneColor(slot.slice(5));
  if(slot.startsWith('bld:')) return bandColor(slot.slice(4));
  if(slot.startsWith('use:')) return useColor(slot.slice(4));
  return baseColors()[slot];
}
function syncEditor(){
  const hex = slotColor(S.slot);
  const [h,s,l] = hexToHsl(hex);
  el('slotname').textContent = slotLabel(S.slot);
  el('hex').value = hex.toUpperCase();
  el('sh').value = Math.round(h); el('vh').textContent = Math.round(h);
  el('ss').value = Math.round(s); el('vs').textContent = Math.round(s);
  el('sl').value = Math.round(l); el('vl').textContent = Math.round(l);
  el('sh').style.background = 'linear-gradient(90deg,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00)';
  el('ss').style.background = `linear-gradient(90deg,${hslToHex(h,0,l)},${hslToHex(h,100,l)})`;
  el('sl').style.background = `linear-gradient(90deg,#000,${hslToHex(h,s,50)},#fff)`;
}
function pushColor(){
  S.custom[S.slot] = hslToHex(+el('sh').value, +el('ss').value, +el('sl').value);
  apply(); renderSlots(); syncEditor();
  if(S.slot.startsWith('zone:')) renderZones();
  if(S.slot.startsWith('bld:')) renderBands();
  renderChecks();
}
el('slots').addEventListener('click', e=>{
  const b = e.target.closest('.slot'); if(!b) return;
  S.slot = b.dataset.k; renderSlots(); syncEditor();
  renderChecks();
});
['sh','ss','sl'].forEach(id=>el(id).addEventListener('input', pushColor));
el('hex').addEventListener('change', e=>{
  const v = e.target.value.trim().replace(/^#?/,'#');
  if(!/^#[0-9a-f]{6}$/i.test(v)) return syncEditor();
  S.custom[S.slot] = v.toUpperCase(); apply(); renderSlots(); syncEditor();
  renderChecks();                                  // 레이어 목록의 색 칩도 같이
});
function pushAdjust(){
  S.adj = {h:+el('ah').value, s:+el('as').value, l:+el('al').value};
  el('vah').textContent = S.adj.h; el('vas').textContent = S.adj.s; el('val').textContent = S.adj.l;
  apply(); renderSlots(); syncEditor();
}
['ah','as','al'].forEach(id=>el(id).addEventListener('input', pushAdjust));
el('resetcolors').addEventListener('click', ()=>{
  S.custom = {}; S.adj = {h:0,s:0,l:0};
  el('ah').value = el('as').value = el('al').value = 0;
  el('vah').textContent = el('vas').textContent = el('val').textContent = '0';
  apply(); renderSlots(); syncEditor();
  toast('프리셋 원래 색으로 되돌렸습니다');
});
renderSlots(); syncEditor();

el('presets').addEventListener('click', e=>{
  const b = e.target.closest('.swatch'); if(!b) return;
  S.preset = b.dataset.id;
  S.custom = {}; S.adj = {h:0,s:0,l:0};
  el('ah').value = el('as').value = el('al').value = 0;
  el('vah').textContent = el('vas').textContent = el('val').textContent = '0';
  renderPresets(); apply(); renderSlots(); syncEditor();
});
el('labelmode').addEventListener('click', e=>{
  const b = e.target.closest('button'); if(!b) return;
  S.labelMode = +b.dataset.v; segSync('labelmode', S.labelMode); apply();
});
el('ratio').addEventListener('click', e=>{
  const b = e.target.closest('button'); if(!b) return;
  S.ratio = b.dataset.v; segSync('ratio', S.ratio); layoutFrame();
});
el('lang').addEventListener('change', e=>{ S.lang = e.target.value; apply(); });

/* --- 위성 사진 --- */
const OSM_CREDIT = '지도 데이터 © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> 기여자 · 타일 OpenFreeMap';
function syncSat(){
  const sat = SAT_SOURCES[S.sat];
  segSync('satseg', S.sat);
  el('satopts').hidden = !sat;
  el('attrib').innerHTML = OSM_CREDIT + (sat ? ' · ' + esc(sat.credit) : '')
    + (CONTOUR.fc ? ' · ' + esc(DEM_CREDIT) : '');
}
el('satseg').addEventListener('click', e=>{
  const b = e.target.closest('button'); if(!b) return;
  S.sat = b.dataset.v;
  const sat = SAT_SOURCES[S.sat];
  if(sat && S.fills && S.fillOpacity > 0.8){
    S.fillOpacity = 0.4;
    el('fillop').value = 40; el('fillval').textContent = '40%';
    toast('사진이 비치도록 면 투명도를 40%로 낮췄습니다');
  }else if(!sat && S.fillOpacity < 1){
    S.fillOpacity = 1;
    el('fillop').value = 100; el('fillval').textContent = '100%';
  }
  syncSat(); apply();
  if(sat && map.getZoom() > sat.maxzoom)
    toast(sat.name + '은 줌 ' + sat.maxzoom + '까지만 선명합니다');
});
el('satop').addEventListener('input', e=>{
  S.satOpacity = +e.target.value/100;
  el('satval').textContent = e.target.value + '%';
  if(map && map.getLayer('sat')) map.setPaintProperty('sat','raster-opacity',S.satOpacity);
});
el('satsvg').addEventListener('change', e=>{ S.satInSvg = e.target.checked; });
syncSat();
el('layerlist').addEventListener('input', e=>{
  if(!e.target.classList.contains('lw')) return;
  const row = e.target.closest('.lrow'); if(!row) return;
  S.lw[row.dataset.l] = +e.target.value;
  e.target.title = '선 굵기 ' + (+e.target.value).toFixed(1) + '배';
  apply();
});
el('layerlist').addEventListener('change', e=>{
  if(e.target.type !== 'checkbox') return;
  const row = e.target.closest('.lrow'); if(!row) return;
  const id = row.dataset.l, which = row.dataset.w;
  S.vis[id] = e.target.checked;
  if(which && e.target.checked){                   // 켜면 지금 화면 기준으로 받아옵니다
    S.on[which] = true;
    apply(); renderChecks(); vwRefresh(true);
    return;
  }
  if(which && !e.target.checked){                  // 같은 데이터를 쓰는 형제가 모두 꺼졌으면 중단
    const alive = layerRows().some(r=>r.which===which && visible(r.id));
    if(!alive) S.on[which] = false;
  }
  apply(); renderChecks();
});
el('layerlist').addEventListener('click', e=>{
  if(!e.target.classList.contains('lpick')) return;
  S.slot = e.target.dataset.s;
  renderSlots(); syncEditor();
});
el('nomaritime').checked = S.noMaritime;
el('nomaritime').addEventListener('change', e=>{ S.noMaritime = e.target.checked; el('closecoast').disabled = !S.noMaritime; apply(); });
el('closecoast').checked = S.closeCoast !== false;
el('closecoast').addEventListener('change', e=>{ S.closeCoast = e.target.checked; apply(); });
el('fills').addEventListener('change', e=>{
  S.fills = e.target.checked;
  el('fillopts').hidden = !S.fills;
  apply();
});
el('fillop').addEventListener('input', e=>{
  S.fillOpacity = +e.target.value/100;
  el('fillval').textContent = e.target.value + '%';
  apply();
});
el('weight').addEventListener('input', e=>{
  S.weight = +e.target.value; el('wval').textContent = S.weight.toFixed(1); apply();
});
el('go').addEventListener('click', ()=>goTo(el('q').value));
el('q').addEventListener('keydown', e=>{ if(e.key==='Enter') goTo(el('q').value); });

/* --- 브이월드 --- */
el('vwkey').value = VW.key;
el('vwdomain').value = VW.domain;
el('vwproxy').value = VW.proxy;
el('vwproxy').addEventListener('change', e=>{
  VW.proxy = e.target.value.trim().replace(/\/+$/, '');
  try{ localStorage.setItem('vworldProxy', VW.proxy); }catch(err){}
  VW.bbox = {};
  vwStatus(VW.proxy ? '중계 서버를 씁니다 · ' + VW.proxy : '브이월드를 직접 부릅니다');
  vwRefresh(true);
});
el('vwdomain').addEventListener('change', e=>{
  VW.domain = e.target.value.trim();
  try{ localStorage.setItem('vworldDomain', VW.domain); }catch(err){}
  VW.bbox = {};
  vwStatus('도메인을 ' + (VW.domain || '(없음)') + ' 으로 바꿨습니다');
  vwRefresh(true);
});
el('vwkey').addEventListener('change', e=>{
  VW.key = e.target.value.trim();
  try{ localStorage.setItem('vworldKey', VW.key); }catch(err){}
  vwStatus(VW.key ? '인증키를 저장했습니다' : '인증키를 지웠습니다');
});
el('vwreload').addEventListener('click', ()=>{
  VW.bbox = {};
  vwAction('');
  vwStatus('불러오는 중');
  apply();
  vwRefresh(true);
});
el('vwreset').addEventListener('click', ()=>{
  VW.key = VW_DEFAULT_KEY; VW.domain = VW_DEFAULT_DOMAIN; VW.proxy = '';
  try{ ['vworldKey','vworldDomain','vworldProxy'].forEach(k=>localStorage.removeItem(k)); }catch(e){}
  el('vwkey').value = VW.key;
el('vwdomain').value = VW.domain;
el('vwproxy').value = VW.proxy;
el('vwproxy').addEventListener('change', e=>{
  VW.proxy = e.target.value.trim().replace(/\/+$/, '');
  try{ localStorage.setItem('vworldProxy', VW.proxy); }catch(err){}
  VW.bbox = {};
  vwStatus(VW.proxy ? '중계 서버를 씁니다 · ' + VW.proxy : '브이월드를 직접 부릅니다');
  vwRefresh(true);
});
el('vwdomain').addEventListener('change', e=>{
  VW.domain = e.target.value.trim();
  try{ localStorage.setItem('vworldDomain', VW.domain); }catch(err){}
  VW.bbox = {};
  vwStatus('도메인을 ' + (VW.domain || '(없음)') + ' 으로 바꿨습니다');
  vwRefresh(true);
});
  vwStatus('기본 설정으로 되돌렸습니다');
  vwRefresh(true);
});
el('vwtest').addEventListener('click', async ()=>{
  VW.key = el('vwkey').value.trim();
  try{ localStorage.setItem('vworldKey', VW.key); }catch(err){}
  VW.proxy = el('vwproxy').value.trim().replace(/\/+$/, '');
  if(!VW.key && !VW.proxy) return vwStatus('인증키나 중계 서버 주소를 넣어 주세요', true);

  const box = { getWest:()=>126.9770, getSouth:()=>37.5655,
                getEast:()=>126.9790, getNorth:()=>37.5675 };
  if(VW.proxy){
    vwStatus('중계 서버 확인 중');
    try{
      const fc = await vwFetch('parcel', box, undefined, 1);
      return vwStatus('중계 서버 연결 성공 · 시험 조회 ' + fc.features.length + '건');
    }catch(err){
      return vwStatus('중계 서버 실패 — ' + err.message, true);
    }
  }
  let lastErr = '';
  for(const d of domainTries()){
    vwStatus('연결 확인 중 · domain=' + (d || '(없음)'));
    try{
      const fc = await vwFetch('parcel', box, d);
      VW.domain = d;
      try{ localStorage.setItem('vworldDomain', d); }catch(err){}
      el('vwdomain').value = d;
      vwStatus('연결 성공 · 시험 조회 ' + fc.features.length + '건'
        + ' · domain=' + (d || '(없음)'));
      console.log('[클린 맵] 브이월드 연결 성공, domain =', JSON.stringify(d));
      return;
    }catch(err){
      lastErr = err.message;
      console.warn('[클린 맵] domain=' + JSON.stringify(d) + ' 실패 —', err.message);
    }
  }
  vwStatus('모두 실패 — ' + lastErr + ' (F12 콘솔에 시도 내역이 있습니다)', true);
});

el('vwlevel').value = String(VW.level);
el('vwlevel').addEventListener('change', e=>{
  VW.level = +e.target.value;
  try{ localStorage.setItem('vworldLevel', String(VW.level)); }catch(err){}
  apply(); vwRefresh();
});
el('zonelist').addEventListener('click', e=>{
  const row = e.target.closest('.zrow'); if(!row) return;
  const n = row.dataset.z;
  if(e.target.classList.contains('zpick')){      // 색 칩 → 고급 색 조정으로
    S.slot = 'zone:' + n;
    renderSlots(); syncEditor();
    if(typeof uiColorPop !== 'function') el('slotname').scrollIntoView({block:'center'});   // 패널이 색 창을 띄웁니다
    return;
  }
  if(VW_OFF.has(n)) VW_OFF.delete(n); else VW_OFF.add(n);
  renderZones(); apply();
});
el('dxfunit').value = S.dxfUnit;
el('dxfunit').addEventListener('change', e=>{ S.dxfUnit = e.target.value; });


/* --- 관리자 설정 (숨김) --- */
function syncAdmin(){
  let on = false;
  try{ on = localStorage.getItem('cleanmapAdmin') === '1'; }catch(e){}
  if(/[?&]admin\b/.test(location.search)) on = true;
  el('adminbox').hidden = !on;
}
el('brandtitle').addEventListener('click', e=>{
  if(!e.shiftKey) return;
  let on = false;
  try{ on = localStorage.getItem('cleanmapAdmin') === '1'; }catch(err){}
  try{ localStorage.setItem('cleanmapAdmin', on ? '0' : '1'); }catch(err){}
  syncAdmin();
  toast(on ? '관리자 설정을 숨겼습니다' : '관리자 설정을 열었습니다');
});
syncAdmin();

/* --- 관리자: 레이어 코드 시험 --- */
el('vwprobe2').addEventListener('click', async ()=>{
  const id = el('vwprobeid').value.trim().toUpperCase();
  if(!id) return vwStatus('레이어 코드를 넣어 주세요', true);
  const c = map.getCenter(), d = 0.004;            // 지금 화면 중심 근처만 조회합니다
  const box = [c.lng - d, c.lat - d, c.lng + d, c.lat + d];
  VW_LAYERS.__probe = {id, name:id, kind:'line'};
  vwStatus(id + ' 조회 중');
  try{
    const fc = await vwFetch('__probe', box, undefined, 1);
    const n = fc.features.length;
    if(!n){ vwStatus(id + ' · 응답은 왔지만 이 근처에 데이터가 없습니다 (산지로 옮겨 다시 시험해 보세요)'); return; }
    const props = fc.features[0].properties || {};
    const keys = Object.keys(props);
    const sample = keys.slice(0, 6).map(k => k + '=' + String(props[k]).slice(0, 12)).join(', ');
    vwStatus(id + ' · ' + n + '건 · ' + (fc.features[0].geometry || {}).type + ' · ' + sample);
    console.log('[클린 맵] ' + id + ' 속성 전체:', props);
  }catch(err){
    vwStatus(id + ' 실패 — ' + err.message, true);
  }finally{ delete VW_LAYERS.__probe; }
});

/* --- 등고선 --- */
el('ctmake').addEventListener('click', async ()=>{
  if(CONTOUR.busy) return;
  const iv = +el('ctint').value;
  CONTOUR.busy = true;
  const btn = el('ctmake'); btn.disabled = true; btn.textContent = '만드는 중…';
  try{
    ctStatus('표고 받는 중');
    const fc = await makeContours(iv);
    CONTOUR.fc = fc; CONTOUR.interval = iv;
    const major = fc.features.filter(f=>f.properties.major).length;
    ctStatus(fc.features.length
      ? '등고선 ' + fc.features.length + '개 (계곡선 ' + major + ') · 표고 ' + Math.round(fc.min) + '~' + Math.round(fc.max) + 'm · 격자 약 ' + fc.meta.cell + 'm'
      : '이 화면에는 ' + iv + 'm 간격으로 그릴 만한 높낮이가 없습니다');
    S.vis['contour-minor'] = S.vis['contour-major'] = true;     // 새로 만들면 보이게
    renderChecks(); syncSat(); apply(); ctSync();
  }catch(err){
    ctStatus('등고선을 만들지 못했습니다 — ' + err.message, true);
  }finally{
    CONTOUR.busy = false; btn.disabled = false; btn.textContent = '이 화면 등고선 만들기';
  }
});
/* 만든 등고선 — 보이기 · 표고 숫자 · 지우기 (레이어 탭 목록과 같은 설정) */
function ctSync(){
  const has = !!(CONTOUR.fc && CONTOUR.fc.features.length);
  el('ctctl').hidden = !has;
  el('cton').checked = visible('contour-minor') || visible('contour-major');
  el('ctlabel').checked = visible('contour-label');
}
el('cton').addEventListener('change', e => { S.vis['contour-minor'] = S.vis['contour-major'] = e.target.checked; renderChecks(); apply(); });
el('ctlabel').addEventListener('change', e => { S.vis['contour-label'] = e.target.checked; apply(); });
el('ctclear').addEventListener('click', () => {
  CONTOUR.fc = null; ctStatus('등고선을 지웠습니다');
  renderChecks(); syncSat(); apply(); ctSync();
});
el('layerlist').addEventListener('change', () => setTimeout(ctSync, 0));   // 레이어 탭에서 끄고 켜도 맞춰 둡니다
ctSync();

/* --- 건물 층수 --- */
function renderBands(){
  const box = el('bldbox'), list = el('bldlist');
  if(!box) return;
  const rows = bandCounts();
  box.hidden = !(S.bldFloors && S.on.building_kr && rows.length);
  el('bldcount').textContent = rows.length ? rows.length + '구간' : '';
  list.innerHTML = rows.map(([n, cnt])=>`
    <div class="zrow ${BLD_OFF.has(n)?'off':''}" data-b="${esc(n)}">
      <i class="bpick" title="색 조정" style="background:${bandColor(n)}"></i>
      <span>${esc(n)}</span><b>${cnt}</b>
    </div>`).join('');
}
el('bldfloors').checked = S.bldFloors;
el('bldfloors').addEventListener('change', e=>{ S.bldFloors = e.target.checked; apply(); renderBands(); });
/* 용도 목록 — 체크한 용도만 칠하기 · 색 바꾸기 (지도 꾸미기 · 대지분석 같은 목록) */
for(const id of ['uselist', 'stuselist']){
  const list = el(id); if(!list) continue;
  list.addEventListener('input', e=>{
    if(!e.target.classList.contains('ucol')) return;
    const n = e.target.closest('.zrow').dataset.u;
    USE_COL[n] = e.target.value;
    clearTimeout(list._t); list._t = setTimeout(()=>{ useSave(); if(USE_ON.has(n)){ if(typeof register3d === 'function' && typeof SITE !== 'undefined' && SITE.view3d) register3d(); apply(); } }, 120);
  });
  list.addEventListener('change', e=>{ if(e.target.classList.contains('ucol')) renderUses(); });
  list.addEventListener('click', e=>{
    if(e.target.classList.contains('ucol')) return;
    const row = e.target.closest('.zrow'); if(!row) return;
    const n = row.dataset.u;
    setUseOn(n, e.target.classList.contains('uon') ? e.target.checked : !USE_ON.has(n));
  });
}
// 목록을 열면 그 범위의 용도를 받아 옵니다 (브이월드 건물통합정보)
for(const id of ['usebox', 'stusebox']) if(el(id)) el(id).addEventListener('toggle', e=>{ if(e.target.open) ensureUses(); });
renderUses();
if(useActive()) setTimeout(()=>{ try{ ensureUses(); }catch(e){} }, 0);
el('bldz').checked = S.bldZ;
el('bldz').addEventListener('change', e=>{ S.bldZ = e.target.checked; });
el('bldfh').value = S.bldFH;
el('bldfh').addEventListener('input', e=>{
  S.bldFH = +e.target.value;
  el('bldfhval').textContent = S.bldFH.toFixed(1) + ' m';
});
el('bldlist').addEventListener('click', e=>{
  const row = e.target.closest('.zrow'); if(!row) return;
  const n = row.dataset.b;
  if(e.target.classList.contains('bpick')){ S.slot = 'bld:' + n; renderSlots(); syncEditor(); return; }
  if(BLD_OFF.has(n)) BLD_OFF.delete(n); else BLD_OFF.add(n);
  renderBands(); apply();
});

el('svg').addEventListener('click', async ()=>{
  const btn = el('svg');
  btn.disabled = true; btn.textContent = '내보내는 중…';
  try{
    const svg = await buildSVG();
    download(stamp()+'.svg', svg, 'image/svg+xml');
    toast(satWarning || ('SVG를 저장했습니다 · 레이어 ' + ORDER.length + '개'));
  }catch(e){
    toast('내보내기에 실패했습니다 — ' + e.message);
  }
  btn.disabled = false; btn.textContent = 'SVG로 내보내기';
});
el('dxf').addEventListener('click', async ()=>{
  try{
    if(typeof clipPrepare === 'function') await clipPrepare();
    const txt = buildDXF();
    const n = (txt.match(/\r\nPOLYLINE\r\n/g) || []).length;
    download(stamp()+'.dxf', txt, 'application/dxf');
    toast('DXF 저장 · 도형 ' + n + '개 · 단위 ' + (S.dxfUnit==='mm'?'밀리미터':'미터')
          + ' · 원점은 화면 중심');
  }catch(e){ toast('DXF 내보내기 실패 — ' + e.message); }
});
el('geo').addEventListener('click', async ()=>{
  if(typeof clipPrepare === 'function') await clipPrepare();
  download(stamp()+'.geojson', buildGeoJSON(), 'application/geo+json');
  toast('GeoJSON을 저장했습니다');
});
el('png').addEventListener('click', exportPNG);

el('loadpreset').addEventListener('click', ()=>el('presetfile').click());
el('presetfile').addEventListener('change', async e=>{
  const file = e.target.files[0]; if(!file) return;
  try{
    const json = JSON.parse(await file.text());
    const list = Array.isArray(json) ? json : json.presets;
    if(!Array.isArray(list) || !list.length) throw new Error();
    PRESETS = list;
    if(!PRESETS.find(p=>p.id===S.preset)) S.preset = PRESETS[0].id;
    renderPresets(); apply();
    toast('프리셋 ' + PRESETS.length + '개를 불러왔습니다');
  }catch(err){
    toast('프리셋 파일을 읽지 못했습니다. presets.json 형식을 확인해 주세요');
  }
  e.target.value = '';
});
el('copypreset').addEventListener('click', async ()=>{
  const edited = JSON.stringify(S.custom)!=='{}' || S.adj.h || S.adj.s || S.adj.l;
  const list = PRESETS.map(p => p.id===S.preset
    ? {...p, id: edited ? p.id+'-custom' : p.id,
            name: edited ? p.name+' (수정)' : p.name, colors: colors()}
    : p);
  const text = JSON.stringify({schema:'clean-map-presets/1', presets:list}, null, 2);
  try{ await navigator.clipboard.writeText(text); toast(edited?'수정한 색을 포함해 복사했습니다':'프리셋 JSON을 복사했습니다'); }
  catch(e){ download('presets.json', text, 'application/json'); toast('클립보드를 쓸 수 없어 파일로 저장했습니다'); }
});

boot();
