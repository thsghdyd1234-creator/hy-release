/* ============================================================
   대지분석 모드 — app.js 다음에 읽힙니다.
   지도·브이월드 데이터·내보내기는 app.js 것을 그대로 쓰고,
   계산한 결과는 EXTRA 레이어로 등록해 SVG·DXF에 함께 나갑니다.
   ============================================================ */

/* ---------- 색 스타일 (다이어그램 색 옷) ---------- */
/* ---------- 다이어그램 스타일 — 모든 분석 레이어의 색·선이 여기서 나옵니다 ---------- */
const SITE_STYLES = {
  basic: { label:'기본 (지도형)', base:'ink', paper:'#FFFFFF', ink:'#1A1A1A', site:'#E0322B', focus:'#77766F',
    road:['#8A2B1E', '#111111', '#555555', '#8C8C8C', '#B4B4B4', '#D2D2D2', '#7FA870'], flow:['#FFE7A1', '#FDBB5A', '#F4873A', '#DD4F2A', '#A8231A'],
    front:'#E0782B', frontText:'#7A3A10', bus:'#2F6FDB', busText:'#123A7A', catchOpacity:0.1,
    biz:'#D4453A', bizCats:['#E0782B', '#D4453A', '#8C6BB1', '#2F6FDB', '#2E9E8F', '#7A7A7A', '#A0856A', '#C9A227', '#58A55C', '#C2447C'],
    pop:'#2C6BB3', work:'#D9622B', age:'#4E9A45', day:'#7C5BB2', dongLine:'#8A8A86', kict:'#6B3FA0', kictText:'#4A2A73',
    shadow:['#CFDBF1', '#8FA9DC', '#3D5FB3'], outline:['#AEBBD8', '#7D91BE', '#4A62A8', '#1B3A8C', '#0F2A6B', '#0A1F52', '#07173F'] },
  clean_grid: { label:'화이트 그리드', base:'ink', paper:'#FFFFFF', ink:'#1A1A1A', site:'#E0322B', focus:'#77766F',
    road:['#7A1F14', '#D7301F', '#F07C2C', '#F6B04A', '#BDBDBD', '#DADADA', '#7FA870'], flow:['#FFE7A1', '#FDBB5A', '#F4873A', '#DD4F2A', '#A8231A'],
    front:'#E0782B', frontText:'#7A3A10', bus:'#2F6FDB', busText:'#123A7A', catchOpacity:0.1,
    biz:'#D4453A', bizCats:['#E0782B', '#D4453A', '#8C6BB1', '#2F6FDB', '#2E9E8F', '#7A7A7A', '#A0856A', '#C9A227', '#58A55C', '#C2447C'],
    pop:'#2C6BB3', work:'#D9622B', age:'#4E9A45', day:'#7C5BB2', dongLine:'#8A8A86', kict:'#6B3FA0', kictText:'#4A2A73',
    shadow:['#CFDBF1', '#8FA9DC', '#3D5FB3'], outline:['#AEBBD8', '#7D91BE', '#4A62A8', '#1B3A8C', '#0F2A6B', '#0A1F52', '#07173F'] },
  blueprint: { label:'블루프린트', base:'ink', paper:'#FFFFFF', ink:'#0B2A7A', site:'#1D4ED8', focus:'#6F8FD1',
    road:['#0B2A7A', '#1D4ED8', '#3D67DD', '#6F8FD1', '#9DB6E8', '#C7D6F3', '#8FB0E8'], flow:['#DCE6F7', '#AFC4EE', '#7A9BE0', '#3D67DD', '#0B2A7A'],
    front:'#0B2A7A', frontText:'#0B2A7A', bus:'#1D4ED8', busText:'#0B2A7A', catchOpacity:0.08,
    biz:'#1D4ED8', bizCats:['#0B2A7A', '#1D4ED8', '#3D67DD', '#6F8FD1', '#9DB6E8', '#2A3F6E', '#4C6FB8', '#7E9BD6', '#163A9E', '#5A7FD8'],
    pop:'#1D4ED8', work:'#0B2A7A', age:'#3D67DD', day:'#6F8FD1', dongLine:'#9DB6E8', kict:'#0B2A7A', kictText:'#0B2A7A',
    shadow:['#DCE6F7', '#9DB6E8', '#1D4ED8'], outline:['#9DB6E8', '#6F8FD1', '#4A6FD0', '#1D4ED8', '#1A43B8', '#163A9E', '#122F82'] },
  soft_paper: { label:'소프트 페이퍼', base:'paper', paper:'#F2EBDD', ink:'#3B352E', site:'#C8553D', focus:'#8C8377',
    road:['#6E3B22', '#B5532F', '#D9874A', '#E3B276', '#C9BFAE', '#DDD5C7', '#8FA68A'], flow:['#F1E2C6', '#E5C48F', '#D49A5C', '#B56B3B', '#7A4122'],
    front:'#C8553D', frontText:'#7A4122', bus:'#4A9A8F', busText:'#2E5F58', catchOpacity:0.12,
    biz:'#C8553D', bizCats:['#D08A4E', '#C8553D', '#9C7FB0', '#5C7FA3', '#4A9A8F', '#8C8377', '#A0856A', '#C9A227', '#7FA06A', '#B86A8A'],
    pop:'#5C7FA3', work:'#C98B3C', age:'#7FA06A', day:'#9C7FB0', dongLine:'#B9AE9F', kict:'#7D6A9E', kictText:'#4F4366',
    shadow:['#EAD8E3', '#D2A9C3', '#A9709A'], outline:['#D2A9C3', '#C08FB2', '#AD77A2', '#A9709A', '#8E5A80', '#744768', '#5B3651'] },
  dark_board: { label:'다크 보드', base:'midnight', paper:'#14161A', ink:'#F2F2F0', site:'#FF6B5C', focus:'#9A9A96',
    road:['#FF8A65', '#FF5A4E', '#FFB14A', '#FFE27A', '#7A7A76', '#55554F', '#6F9E62'], flow:['#3A2F12', '#7A5C16', '#C08A1E', '#F2B632', '#FFE27A'],
    front:'#FFB14A', frontText:'#FFB14A', bus:'#5AD1E6', busText:'#5AD1E6', catchOpacity:0.14,
    biz:'#FF6B5C', bizCats:['#FFB14A', '#FF6B5C', '#C59BFF', '#5AA9FF', '#5AD1E6', '#BDBDBD', '#D7B48A', '#FFE27A', '#8EE08A', '#FF8AC2'],
    pop:'#5AA9FF', work:'#FFB14A', age:'#8EE08A', day:'#C59BFF', dongLine:'#6E6E6B', kict:'#C59BFF', kictText:'#C59BFF',
    shadow:['#5B4E1F', '#A88F2E', '#F5D34A'], outline:['#8C7A30', '#A88F2E', '#C4A63A', '#E0BE44', '#F5D34A', '#F8DC6A', '#FBE58A'] },
  mono_line: { label:'모노 라인', base:'outline', paper:'#FFFFFF', ink:'#1A1A1A', site:'#E0322B', focus:'#6B6B68',
    road:['#1A1A1A', '#1A1A1A', '#4A4A4A', '#7A7A7A', '#A6A6A6', '#C9C9C9', '#7A7A7A'], flow:['#E6E6E6', '#BDBDBD', '#8C8C8C', '#4D4D4D', '#111111'],
    front:'#E0322B', frontText:'#E0322B', bus:'#1A1A1A', busText:'#1A1A1A', catchOpacity:0.07,
    biz:'#1A1A1A', bizCats:['#111111', '#333333', '#555555', '#777777', '#999999', '#222222', '#444444', '#666666', '#888888', '#AAAAAA'],
    pop:'#1A1A1A', work:'#4A4A4A', age:'#1A1A1A', day:'#1A1A1A', dongLine:'#A6A6A6', kict:'#1A1A1A', kictText:'#1A1A1A',
    shadow:['#E6E6E6', '#B9B9B9', '#7A7A7A'], outline:['#B4B4B4', '#9A9A9A', '#7E7E7E', '#5E5E5E', '#3E3E3E', '#262626', '#111111'] }
};
/* 추가 스타일 */
Object.assign(SITE_STYLES, {
  red_highlight: {"label": "레드 하이라이트", "base": "crimson", "paper": "#F4F4F4", "ink": "#2A2A2A", "site": "#111111", "focus": "#8A8A8A", "road": ["#7A1020", "#C8102E", "#E04A5F", "#EE8A98", "#C9C9C9", "#DDDDDD", "#9DB39A"], "flow": ["#FBE0E4", "#F4A9B4", "#E8677B", "#C8102E", "#7A0A1C"], "front": "#C8102E", "frontText": "#2A2A2A", "bus": "#C8102E", "busText": "#7A0A1C", "catchOpacity": 0.12, "biz": "#E0405A", "bizCats": ["#C8102E", "#E0405A", "#8E1B3A", "#F07A8C", "#5A0A18", "#DA6B7D", "#E88898", "#B77284", "#F2ABB6", "#986870"], "pop": "#C8102E", "work": "#8E1B3A", "age": "#E0405A", "day": "#8E1B3A", "dongLine": "#BDBDBD", "kict": "#5A0A18", "kictText": "#5A0A18", "shadow": ["#E9BBC2", "#D86678", "#C8102E"], "outline": ["#C2C2C2", "#A8A8A8", "#8F8F8F", "#767676", "#5C5C5C", "#434343", "#2A2A2A"]},
  orange_circle: {"label": "오렌지 서클", "base": "concrete", "paper": "#E8E8E8", "ink": "#2B2B2B", "site": "#1F1F1F", "focus": "#8C8C8C", "road": ["#8A3B12", "#E8692A", "#F09450", "#F6BC86", "#BDBDBD", "#D3D3D3", "#9AAE8E"], "flow": ["#FBE3CF", "#F6BC86", "#F09450", "#E8692A", "#A8420F"], "front": "#E8692A", "frontText": "#2B2B2B", "bus": "#E8692A", "busText": "#8A3B12", "catchOpacity": 0.14, "biz": "#F07A3C", "bizCats": ["#E8692A", "#F09450", "#B0471A", "#D9A066", "#7A3A10", "#E89C76", "#EDB68D", "#C6876C", "#DFBD9A", "#A68066"], "pop": "#E8692A", "work": "#B0471A", "age": "#F09450", "day": "#B0471A", "dongLine": "#BDBDBD", "kict": "#7A3A10", "kictText": "#7A3A10", "shadow": ["#E8C8B8", "#E89971", "#E8692A"], "outline": ["#B9B9B9", "#A1A1A1", "#8A8A8A", "#727272", "#5A5A5A", "#434343", "#2B2B2B"]},
  navy_blueprint: {"label": "네이비 청사진", "base": "blueprint", "paper": "#0E2C54", "ink": "#E8F0FF", "site": "#FF6B5C", "focus": "#9DBBEA", "road": ["#FF9E7A", "#FFFFFF", "#CFE0FF", "#9DBBEA", "#6E8FC4", "#4A6A9E", "#8FD3B6"], "flow": ["#1B3E6E", "#3F67A3", "#7FA6DD", "#C4D9F7", "#FFFFFF"], "front": "#C4D9F7", "frontText": "#E8F0FF", "bus": "#7FE0FF", "busText": "#BFF0FF", "catchOpacity": 0.14, "biz": "#FFD166", "bizCats": ["#FFD166", "#7FE0FF", "#FFB3C7", "#9BE89B", "#FFFFFF", "#9F8F5F", "#5298BB", "#9F7D99", "#639D7F", "#9FABBB"], "pop": "#7FE0FF", "work": "#FFD166", "age": "#9BE89B", "day": "#FFB3C7", "dongLine": "#4A6A9E", "kict": "#FFB3C7", "kictText": "#FFB3C7", "shadow": ["#2A597F", "#559CBF", "#7FE0FF"], "outline": ["#445D7F", "#607694", "#7B8EAA", "#96A6BF", "#B2BFD4", "#CDD8EA", "#E8F0FF"]},
  neon_night: {"label": "네온 나이트", "base": "plum", "paper": "#191320", "ink": "#F4EEFF", "site": "#FFD23F", "focus": "#8574A8", "road": ["#FF4FD8", "#F4EEFF", "#B9A8D9", "#8574A8", "#5C4E7A", "#43385A", "#6FE3B0"], "flow": ["#2A1F3D", "#5B2A7A", "#A63FBF", "#FF4FD8", "#FFC2F2"], "front": "#FF4FD8", "frontText": "#F4EEFF", "bus": "#3FE0FF", "busText": "#3FE0FF", "catchOpacity": 0.16, "biz": "#FF4FD8", "bizCats": ["#FF4FD8", "#3FE0FF", "#FFD23F", "#6FE3B0", "#FF8A5C", "#A3378E", "#308EA6", "#A38633", "#4D9076", "#A35A44"], "pop": "#3FE0FF", "work": "#FFD23F", "age": "#6FE3B0", "day": "#FF8A5C", "dongLine": "#43385A", "kict": "#FFD23F", "kictText": "#FFD23F", "shadow": ["#224658", "#3193AB", "#3FE0FF"], "outline": ["#504A58", "#6B6574", "#868090", "#A29CAB", "#BDB7C7", "#D9D3E3", "#F4EEFF"]},
  green_urban: {"label": "그린 어반", "base": "moss", "paper": "#EDEFE8", "ink": "#253025", "site": "#C8102E", "focus": "#7F8C7A", "road": ["#2F4A2A", "#2E6B3F", "#4E9A5A", "#86C08A", "#B9C6B4", "#D3DCCF", "#7FA6B8"], "flow": ["#E2EED8", "#B9DCA8", "#7DBB75", "#3F8F4A", "#1E5A2C"], "front": "#3F8F4A", "frontText": "#253025", "bus": "#2E7D8C", "busText": "#1D4F59", "catchOpacity": 0.12, "biz": "#C8693A", "bizCats": ["#C8693A", "#2E7D8C", "#4E9A5A", "#B89B3A", "#7A5FA0", "#D79F80", "#7AABB1", "#8EBC93", "#CDBD80", "#A899BD"], "pop": "#2E7D8C", "work": "#C8693A", "age": "#4E9A5A", "day": "#7A5FA0", "dongLine": "#B9C6B4", "kict": "#5A3F7A", "kictText": "#5A3F7A", "shadow": ["#BDD2D1", "#76A8AE", "#2E7D8C"], "outline": ["#BBBFB7", "#A2A79F", "#899086", "#70786E", "#576056", "#3E483D", "#253025"]},
  duotone: {"label": "듀오톤 (인디고·코랄)", "base": "wash", "paper": "#FBFAF7", "ink": "#22223B", "site": "#FF4D2E", "focus": "#8D8DA6", "road": ["#22223B", "#3D3D8F", "#7272C2", "#B0B0E0", "#C9C9D6", "#DDDDE6", "#7FB8A8"], "flow": ["#FFE5DD", "#FFB8A3", "#FF8466", "#E5533A", "#9C2E1C"], "front": "#E5533A", "frontText": "#22223B", "bus": "#3D3D8F", "busText": "#22223B", "catchOpacity": 0.1, "biz": "#FF7A5C", "bizCats": ["#FF7A5C", "#3D3D8F", "#E5533A", "#7272C2", "#9C2E1C", "#FDAD9A", "#8989B9", "#EE9686", "#A9A8D7", "#C28074"], "pop": "#3D3D8F", "work": "#FF7A5C", "age": "#3D3D8F", "day": "#FF7A5C", "dongLine": "#C9C9D6", "kict": "#3D3D8F", "kictText": "#3D3D8F", "shadow": ["#CCCBDD", "#8484B6", "#3D3D8F"], "outline": ["#C5C4C8", "#AAA9B0", "#8E8E99", "#737382", "#58586A", "#3D3D52", "#22223B"]},
  sepia_drawing: {"label": "세피아 도면", "base": "sepia", "paper": "#EFE6D6", "ink": "#3B2E20", "site": "#A6321E", "focus": "#9C8C74", "road": ["#5A3A1E", "#3B2E20", "#6B5640", "#9C8C74", "#BFB29C", "#D8CDB8", "#8FA07A"], "flow": ["#E6D8BE", "#CDB48A", "#AD8B5A", "#7E5E36", "#4A3420"], "front": "#7E5E36", "frontText": "#3B2E20", "bus": "#6B5640", "busText": "#3B2E20", "catchOpacity": 0.12, "biz": "#A6321E", "bizCats": ["#A6321E", "#6B5640", "#AD8B5A", "#7E5E36", "#4A3420", "#C37A68", "#A0907C", "#C7AF8C", "#AB9476", "#8C7B69"], "pop": "#6B5640", "work": "#A6321E", "age": "#7E5E36", "day": "#AD8B5A", "dongLine": "#BFB29C", "kict": "#4A3420", "kictText": "#4A3420", "shadow": ["#CEC2B0", "#9C8C78", "#6B5640"], "outline": ["#C2B8A8", "#ACA192", "#958A7B", "#7E7364", "#685C4E", "#524537", "#3B2E20"]}
});
/* 팔레트 스타일 (15색 조합) — 비슷한 기존 스타일은 이 색으로 바꾸고, 없던 조합은 새로 추가 */
Object.assign(SITE_STYLES, {"soft_paper": {"label": "테라코타 · 올리브 · 베이지", "base": "sand", "paper": "#EFE6D2", "ink": "#3A3128", "site": "#C2643F", "focus": "#948C7D", "road": ["#925237", "#3A3128", "#746B5E", "#988F80", "#B5AC9C", "#CBC2B0", "#99A06F"], "flow": ["#E5C9B2", "#D9A88B", "#CE8665", "#C2643F", "#925237"], "front": "#C2643F", "frontText": "#854D35", "bus": "#6B7A3A", "busText": "#575D33", "catchOpacity": 0.12, "biz": "#C2643F", "bizCats": ["#C2643F", "#6B7A3A", "#966F3C", "#D59B7D", "#A2A77A", "#8C5036", "#575D33", "#948C7D", "#AC6A3E", "#81743B"], "pop": "#6B7A3A", "work": "#C2643F", "age": "#85733C", "day": "#8E713C", "dongLine": "#B0A796", "kict": "#5C6435", "kictText": "#525631", "shadow": ["#CECBAC", "#A6AB7E", "#646F37"], "outline": ["#B4B58E", "#A5A582", "#979576", "#888569", "#77735B", "#66614D", "#554E3E"], "mass": "#F9F5ED", "massEdge": "#3A3128"}, "mustard_teal": {"label": "머스터드 · 틸 블루 · 오프화이트", "base": "teal", "paper": "#F7F4EC", "ink": "#1F2A2C", "site": "#D9A21B", "focus": "#8B8F8C", "road": ["#987821", "#1F2A2C", "#646B69", "#8F9390", "#B2B3AF", "#CCCCC6", "#6BA5A6"], "flow": ["#F0E2BE", "#E9CD88", "#E1B751", "#D9A21B", "#987821"], "front": "#D9A21B", "frontText": "#856C23", "bus": "#1F7A80", "busText": "#1F5A5E", "catchOpacity": 0.12, "biz": "#D9A21B", "bizCats": ["#D9A21B", "#1F7A80", "#7C8E4E", "#E6C473", "#7AADAD", "#8F7222", "#1F5A5E", "#8B8F8C", "#AA9834", "#4E8467"], "pop": "#1F7A80", "work": "#D9A21B", "age": "#578662", "day": "#698A58", "dongLine": "#ABADA9", "kict": "#1F6267", "kictText": "#1F5256", "shadow": ["#C1D6D1", "#80B1B1", "#1F6E73"], "outline": ["#96BDBB", "#88ABAA", "#799A99", "#6B8888", "#5A7474", "#4A5F5F", "#394A4B"], "mass": "#FCFBF7", "massEdge": "#1F2A2C"}, "green_urban": {"label": "살몬 · 파인 그린 · 라이트 그레이", "base": "moss", "paper": "#ECEDEB", "ink": "#2B2F2C", "site": "#E8846B", "focus": "#8C8E8C", "road": ["#A66655", "#2B2F2C", "#696C69", "#8F928F", "#AEB0AE", "#C5C7C5", "#718F80"], "flow": ["#EBD6CF", "#EABBAE", "#E99F8C", "#E8846B", "#A66655"], "front": "#E8846B", "frontText": "#935E4F", "bus": "#2F5D46", "busText": "#2D4B3C", "catchOpacity": 0.12, "biz": "#E8846B", "bizCats": ["#E8846B", "#2F5D46", "#8C7058", "#EAB0A1", "#7E998B", "#9C6252", "#2D4B3C", "#8C8E8C", "#BA7A62", "#5D674F"], "pop": "#2F5D46", "work": "#E8846B", "age": "#666951", "day": "#796D55", "dongLine": "#A8AAA8", "kict": "#2E4F3E", "kictText": "#2D4639", "shadow": ["#BDC9C2", "#849E90", "#2E5642"], "outline": ["#97ACA1", "#8A9D93", "#7D8E85", "#707F77", "#616E66", "#525C56", "#434A46"], "mass": "#F7F8F7", "massEdge": "#2B2F2C"}, "duotone": {"label": "인디고 · 오커 · 크림", "base": "indigo_ochre", "paper": "#F5EEDC", "ink": "#1E2558", "site": "#C8902E", "focus": "#8A8A9A", "road": ["#8C6B3D", "#1E2558", "#636582", "#8E8E9D", "#B0AEB2", "#CAC6C2", "#7479A5"], "flow": ["#EBD9B6", "#DFC188", "#D4A85B", "#C8902E", "#8C6B3D"], "front": "#C8902E", "frontText": "#7C6041", "bus": "#2E3A87", "busText": "#283274", "catchOpacity": 0.12, "biz": "#C8902E", "bizCats": ["#C8902E", "#2E3A87", "#7B655A", "#DBB777", "#8286AB", "#84653F", "#283274", "#8A8A9A", "#A27A44", "#545071"], "pop": "#2E3A87", "work": "#C8902E", "age": "#5C546C", "day": "#6C5C63", "dongLine": "#AAA8AE", "kict": "#293479", "kictText": "#263070", "shadow": ["#C3C1C7", "#888BAD", "#2C3780"], "outline": ["#9B9DB6", "#8C8FAB", "#7D809F", "#6E7294", "#5C6187", "#4B507A", "#3A3F6D"], "mass": "#FBF8F1", "massEdge": "#1E2558"}, "orange_circle": {"label": "탠저린 · 슬레이트 그레이 · 화이트", "base": "concrete", "paper": "#FFFFFF", "ink": "#2E353B", "site": "#FF7A1A", "focus": "#969A9D", "road": ["#B66226", "#2E353B", "#71767A", "#9B9EA1", "#BCBEC0", "#D5D7D8", "#949CA2"], "flow": ["#FFE2CD", "#FFBF91", "#FF9D56", "#FF7A1A", "#B66226"], "front": "#FF7A1A", "frontText": "#A15B29", "bus": "#5B6670", "busText": "#49525B", "catchOpacity": 0.12, "biz": "#FF7A1A", "bizCats": ["#FF7A1A", "#5B6670", "#AD7045", "#FFB27A", "#A0A6AC", "#AB5E27", "#49525B", "#969A9D", "#D67530", "#846B5A"], "pop": "#5B6670", "work": "#FF7A1A", "age": "#8C6C56", "day": "#9D6E4E", "dongLine": "#B6B8BA", "kict": "#4E5760", "kictText": "#444E56", "shadow": ["#D6D9DB", "#A5ABB0", "#545F68"], "outline": ["#B5BABF", "#A5AAAF", "#959A9F", "#848A8F", "#72787D", "#5F656B", "#4C5258"], "mass": "#FFFFFF", "massEdge": "#2E353B"}, "mauve_taupe": {"label": "모브 · 토프 · 차콜", "base": "mauve_taupe", "paper": "#F2EFEB", "ink": "#33302E", "site": "#A87C9A", "focus": "#92908C", "road": ["#7F6174", "#33302E", "#706D6A", "#969390", "#B5B2AF", "#CCC9C5", "#B0A498"], "flow": ["#E2D6D9", "#CEB8C4", "#BB9AAF", "#A87C9A", "#7F6174"], "front": "#A87C9A", "frontText": "#735A69", "bus": "#8C7B6B", "busText": "#685D53", "catchOpacity": 0.12, "biz": "#A87C9A", "bizCats": ["#A87C9A", "#8C7B6B", "#9A7C82", "#C7ACBC", "#B7ACA1", "#795E6F", "#685D53", "#92908C", "#A17C8E", "#937B77"], "pop": "#8C7B6B", "work": "#A87C9A", "age": "#947B79", "day": "#977B7E", "dongLine": "#AFACA9", "kict": "#716459", "kictText": "#60564C", "shadow": ["#D8D2CB", "#BAAFA5", "#7F7062"], "outline": ["#C4BBB1", "#B3AAA1", "#A19A92", "#908982", "#7C7670", "#67625D", "#534F4B"], "mass": "#FAF9F7", "massEdge": "#33302E"}, "red_highlight": {"label": "브릭 레드 · 네이비 · 샌드", "base": "crimson", "paper": "#EADFC8", "ink": "#1F2433", "site": "#A8432F", "focus": "#84827E", "road": ["#783830", "#1F2433", "#606063", "#898580", "#A9A398", "#C1BAAA", "#666D7F"], "flow": ["#DBBDA6", "#CA947F", "#B96C57", "#A8432F", "#783830"], "front": "#A8432F", "frontText": "#6A3531", "bus": "#1F2F57", "busText": "#1F2B49", "catchOpacity": 0.12, "biz": "#A8432F", "bizCats": ["#A8432F", "#1F2F57", "#643943", "#C4856F", "#747986", "#713731", "#1F2B49", "#84827E", "#863E39", "#41344D"], "pop": "#1F2F57", "work": "#A8432F", "age": "#48354B", "day": "#563747", "dongLine": "#A39E94", "kict": "#1F2C4C", "kictText": "#1F2A45", "shadow": ["#B7B3AC", "#7A7E8A", "#1F2D52"], "outline": ["#8F9095", "#828389", "#74767D", "#676972", "#575A64", "#474B56", "#383C49"], "mass": "#F7F2E9", "massEdge": "#1F2433"}, "lavender_mint": {"label": "라벤더 · 민트 · 차콜", "base": "lavender_mint", "paper": "#F6F5F8", "ink": "#34343A", "site": "#9C8BDB", "focus": "#959499", "road": ["#786DA3", "#34343A", "#727277", "#99989D", "#B8B7BB", "#CFCED2", "#92D8C3"], "flow": ["#E2DEF2", "#CBC2EA", "#B3A7E3", "#9C8BDB", "#786DA3"], "front": "#9C8BDB", "frontText": "#6D6493", "bus": "#5CC9A7", "busText": "#4C8D7B", "catchOpacity": 0.12, "biz": "#9C8BDB", "bizCats": ["#9C8BDB", "#5CC9A7", "#7CAAC1", "#C2B8E7", "#9DDBC9", "#72689B", "#4C8D7B", "#959499", "#8C9ACE", "#6CBAB4"], "pop": "#5CC9A7", "work": "#9C8BDB", "age": "#6FB6B7", "day": "#76B0BC", "dongLine": "#B2B1B6", "kict": "#509C86", "kictText": "#487E70", "shadow": ["#D0EAE4", "#A1DDCB", "#56B397"], "outline": ["#B1E1D4", "#A2CCC2", "#93B7AF", "#84A39D", "#728A87", "#617271", "#505A5C"], "mass": "#FBFBFC", "massEdge": "#34343A"}, "sepia_drawing": {"label": "딥 버건디 · 모스 그린 · 웜 그레이", "base": "sepia", "paper": "#E9E5DF", "ink": "#3A3633", "site": "#7A1F2E", "focus": "#928E89", "road": ["#642730", "#3A3633", "#726E6A", "#95918C", "#B1ADA8", "#C6C2BD", "#8F9674"], "flow": ["#D1B9B8", "#B4868A", "#97525C", "#7A1F2E", "#642730"], "front": "#7A1F2E", "frontText": "#5D2930", "bus": "#5E6B3A", "busText": "#505637", "catchOpacity": 0.12, "biz": "#7A1F2E", "bizCats": ["#7A1F2E", "#5E6B3A", "#6C4534", "#A97278", "#989E7F", "#602830", "#505637", "#928E89", "#733231", "#655837"], "pop": "#5E6B3A", "work": "#7A1F2E", "age": "#665436", "day": "#694D35", "dongLine": "#ACA8A3", "kict": "#535B38", "kictText": "#4C5036", "shadow": ["#C6C6B6", "#9DA284", "#596339"], "outline": ["#AAAE95", "#9DA089", "#8F917D", "#828372", "#727264", "#626156", "#535049"], "mass": "#F6F5F2", "massEdge": "#3A3633"}, "emerald_peach": {"label": "에메랄드 · 피치 · 아이보리", "base": "emerald_peach", "paper": "#FBF8F0", "ink": "#23352E", "site": "#F09A74", "focus": "#8F968F", "road": ["#A8775C", "#23352E", "#68736C", "#939A93", "#B6BAB2", "#D0D1C9", "#6BBE9C"], "flow": ["#F9E3D5", "#F6CBB4", "#F3B294", "#F09A74", "#A8775C"], "front": "#F09A74", "frontText": "#946D54", "bus": "#1E9E6E", "busText": "#207454", "catchOpacity": 0.12, "biz": "#F09A74", "bizCats": ["#F09A74", "#1E9E6E", "#879C71", "#F5C1A8", "#7BC4A5", "#9E7258", "#207454", "#8F968F", "#BC9B72", "#529D70"], "pop": "#1E9E6E", "work": "#F09A74", "age": "#5D9D70", "day": "#729C70", "dongLine": "#AFB4AC", "kict": "#207E5B", "kictText": "#206A4E", "shadow": ["#C4E2D0", "#81C6A8", "#1F8E64"], "outline": ["#98D0B6", "#8ABDA6", "#7CAB95", "#6E9885", "#5E8272", "#4D6D5F", "#3D574C"], "mass": "#FDFCF9", "massEdge": "#23352E"}, "magenta_cyan": {"label": "마젠타 · 시안 · 페일 옐로우", "base": "magenta_cyan", "paper": "#FBF7DC", "ink": "#1C1C24", "site": "#E0218A", "focus": "#8C8A80", "road": ["#9B1F66", "#1C1C24", "#63625F", "#908E84", "#B4B1A1", "#CECBB7", "#58C2D8"], "flow": ["#F5C8CA", "#EE90B5", "#E7599F", "#E0218A", "#9B1F66"], "front": "#E0218A", "frontText": "#881F5C", "bus": "#00A6D6", "busText": "#0B6F8F", "catchOpacity": 0.12, "biz": "#E0218A", "bizCats": ["#E0218A", "#00A6D6", "#7064B0", "#EB7BAC", "#69C8D9", "#921F61", "#0B6F8F", "#8C8A80", "#A8429D", "#3885C3"], "pop": "#00A6D6", "work": "#E0218A", "age": "#437EBF", "day": "#5A71B8", "dongLine": "#ADAA9C", "kict": "#087DA1", "kictText": "#0E617D", "shadow": ["#BCE3DA", "#71CAD9", "#0491BB"], "outline": ["#8AD3D9", "#7DBDC3", "#70A7AE", "#629198", "#53787E", "#445E65", "#34444C"], "mass": "#FDFCF1", "massEdge": "#1C1C24"}, "sky_mahogany": {"label": "스카이 블루 · 마호가니 · 라이트 샌드", "base": "sky_mahogany", "paper": "#EEE6D6", "ink": "#3A2A24", "site": "#7A3B2E", "focus": "#94887D", "road": ["#64352A", "#3A2A24", "#74665D", "#988C81", "#B4AA9D", "#CAC0B2", "#9BC5DC"], "flow": ["#D4C0B1", "#B69485", "#98675A", "#7A3B2E", "#64352A"], "front": "#7A3B2E", "frontText": "#5D332A", "bus": "#6FB3E0", "busText": "#5A7C95", "catchOpacity": 0.12, "biz": "#7A3B2E", "bizCats": ["#7A3B2E", "#6FB3E0", "#747787", "#AB8375", "#A4C8DC", "#60342A", "#5A7C95", "#94887D", "#77595A", "#7295B4"], "pop": "#6FB3E0", "work": "#7A3B2E", "age": "#728FAB", "day": "#738399", "dongLine": "#AFA498", "kict": "#5F8AA8", "kictText": "#546E82", "shadow": ["#CED9D8", "#A8CADC", "#679EC4"], "outline": ["#B5CFDA", "#A6BBC4", "#97A7AE", "#899498", "#787C7F", "#666566", "#554E4C"], "mass": "#F8F5EF", "massEdge": "#3A2A24"}, "plum_cobalt": {"label": "플럼 · 코발트 · 실버 그레이", "base": "plum", "paper": "#E7E8EB", "ink": "#26282E", "site": "#7B3F72", "focus": "#86888C", "road": ["#5D375A", "#26282E", "#64656A", "#8A8C90", "#A9ABAF", "#C0C2C5", "#6585D2"], "flow": ["#CFC3D0", "#B397B1", "#976B91", "#7B3F72", "#5D375A"], "front": "#7B3F72", "frontText": "#553553", "bus": "#1F4FC4", "busText": "#223F88", "catchOpacity": 0.12, "biz": "#7B3F72", "bizCats": ["#7B3F72", "#1F4FC4", "#4D479B", "#A886A5", "#738FD4", "#593657", "#223F88", "#86888C", "#644386", "#364BB0"], "pop": "#1F4FC4", "work": "#7B3F72", "age": "#3B4AAB", "day": "#4449A3", "dongLine": "#A3A5A9", "kict": "#214397", "kictText": "#223C79", "shadow": ["#B5C2E1", "#7994D6", "#2049AE"], "outline": ["#8DA3D9", "#8194C4", "#7485B0", "#68779B", "#5A6684", "#4B546C", "#3D4354"], "mass": "#F5F6F7", "massEdge": "#26282E"}, "neon_night": {"label": "네온 핑크 · 일렉트릭 블루 · 딥 블랙", "base": "neon_black", "paper": "#07070A", "ink": "#F2F2F7", "site": "#FF2E9A", "focus": "#7C7C80", "road": ["#FF2E9A", "#E6E6EB", "#A0A0A4", "#717175", "#4E4E51", "#363639", "#1E6BFF"], "flow": ["#45112E", "#831A52", "#C12476", "#FF2E9A", "#FF8CC7"], "front": "#FF2E9A", "frontText": "#FF6DB8", "bus": "#1E6BFF", "busText": "#78A6FF", "catchOpacity": 0.14, "biz": "#FF2E9A", "bizCats": ["#FF2E9A", "#1E6BFF", "#8E4CCC", "#971E5E", "#144198", "#FA7CBF", "#73A1FC", "#7C7C80", "#C73DB3", "#565CE6"], "pop": "#1E6BFF", "work": "#FF2E9A", "age": "#6259E1", "day": "#7853D7", "dongLine": "#59595D", "kict": "#6297FF", "kictText": "#8EB5FF", "shadow": ["#0E2554", "#15439D", "#1E6BFF"], "outline": ["#102F6C", "#2B467D", "#465E8D", "#61759E", "#8190B2", "#A1ACC5", "#C0C7D8"], "mass": "#3E3E40", "massEdge": "#ACACB0"}, "olive_petrol": {"label": "올리브 옐로우 · 페트롤 블루 · 웜 그레이", "base": "olive_petrol", "paper": "#E8E5DE", "ink": "#2F3330", "site": "#B5A642", "focus": "#8C8C87", "road": ["#867E3C", "#2F3330", "#6A6C68", "#8F908A", "#ADACA6", "#C3C1BB", "#658E99"], "flow": ["#DDD7BC", "#D0C793", "#C2B66B", "#B5A642", "#867E3C"], "front": "#B5A642", "frontText": "#79723A", "bus": "#1E5F74", "busText": "#254D59", "catchOpacity": 0.12, "biz": "#B5A642", "bizCats": ["#B5A642", "#1E5F74", "#6A825B", "#CAC084", "#7397A1", "#7F783B", "#254D59", "#8C8C87", "#8F944E", "#447168"], "pop": "#1E5F74", "work": "#B5A642", "age": "#4B7465", "day": "#5A7B60", "dongLine": "#A7A7A1", "kict": "#235260", "kictText": "#264952", "shadow": ["#B6C4C4", "#799BA4", "#21586A"], "outline": ["#8DA9AE", "#829B9F", "#768D90", "#6B7F81", "#5E6E6F", "#515D5D", "#444D4C"], "mass": "#F6F5F2", "massEdge": "#2F3330"}});
/* 팔레트 스타일 (15색 조합) — 비슷한 기존 스타일은 이 색으로 바꾸고, 없던 조합은 새로 추가 */
Object.assign(SITE_STYLES, {"soft_paper": {"label": "테라코타 · 올리브 · 베이지", "base": "sand", "paper": "#EFE6D2", "ink": "#3A3128", "site": "#C2643F", "focus": "#948C7D", "road": ["#925237", "#3A3128", "#746B5E", "#988F80", "#B5AC9C", "#CBC2B0", "#99A06F"], "flow": ["#E5C9B2", "#D9A88B", "#CE8665", "#C2643F", "#925237"], "front": "#C2643F", "frontText": "#854D35", "bus": "#6B7A3A", "busText": "#575D33", "catchOpacity": 0.12, "biz": "#C2643F", "bizCats": ["#C2643F", "#6B7A3A", "#966F3C", "#D59B7D", "#A2A77A", "#8C5036", "#575D33", "#948C7D", "#AC6A3E", "#81743B"], "pop": "#6B7A3A", "work": "#C2643F", "age": "#85733C", "day": "#8E713C", "dongLine": "#B0A796", "kict": "#5C6435", "kictText": "#525631", "shadow": ["#CECBAC", "#A6AB7E", "#646F37"], "outline": ["#B4B58E", "#A5A582", "#979576", "#888569", "#77735B", "#66614D", "#554E3E"], "mass": "#F9F5ED", "massEdge": "#3A3128"}, "mustard_teal": {"label": "머스터드 · 틸 블루 · 오프화이트", "base": "teal", "paper": "#F7F4EC", "ink": "#1F2A2C", "site": "#D9A21B", "focus": "#8B8F8C", "road": ["#987821", "#1F2A2C", "#646B69", "#8F9390", "#B2B3AF", "#CCCCC6", "#6BA5A6"], "flow": ["#F0E2BE", "#E9CD88", "#E1B751", "#D9A21B", "#987821"], "front": "#D9A21B", "frontText": "#856C23", "bus": "#1F7A80", "busText": "#1F5A5E", "catchOpacity": 0.12, "biz": "#D9A21B", "bizCats": ["#D9A21B", "#1F7A80", "#7C8E4E", "#E6C473", "#7AADAD", "#8F7222", "#1F5A5E", "#8B8F8C", "#AA9834", "#4E8467"], "pop": "#1F7A80", "work": "#D9A21B", "age": "#578662", "day": "#698A58", "dongLine": "#ABADA9", "kict": "#1F6267", "kictText": "#1F5256", "shadow": ["#C1D6D1", "#80B1B1", "#1F6E73"], "outline": ["#96BDBB", "#88ABAA", "#799A99", "#6B8888", "#5A7474", "#4A5F5F", "#394A4B"], "mass": "#FCFBF7", "massEdge": "#1F2A2C"}, "green_urban": {"label": "살몬 · 파인 그린 · 라이트 그레이", "base": "moss", "paper": "#ECEDEB", "ink": "#2B2F2C", "site": "#E8846B", "focus": "#8C8E8C", "road": ["#A66655", "#2B2F2C", "#696C69", "#8F928F", "#AEB0AE", "#C5C7C5", "#718F80"], "flow": ["#EBD6CF", "#EABBAE", "#E99F8C", "#E8846B", "#A66655"], "front": "#E8846B", "frontText": "#935E4F", "bus": "#2F5D46", "busText": "#2D4B3C", "catchOpacity": 0.12, "biz": "#E8846B", "bizCats": ["#E8846B", "#2F5D46", "#8C7058", "#EAB0A1", "#7E998B", "#9C6252", "#2D4B3C", "#8C8E8C", "#BA7A62", "#5D674F"], "pop": "#2F5D46", "work": "#E8846B", "age": "#666951", "day": "#796D55", "dongLine": "#A8AAA8", "kict": "#2E4F3E", "kictText": "#2D4639", "shadow": ["#BDC9C2", "#849E90", "#2E5642"], "outline": ["#97ACA1", "#8A9D93", "#7D8E85", "#707F77", "#616E66", "#525C56", "#434A46"], "mass": "#F7F8F7", "massEdge": "#2B2F2C"}, "duotone": {"label": "인디고 · 오커 · 크림", "base": "indigo_ochre", "paper": "#F5EEDC", "ink": "#1E2558", "site": "#C8902E", "focus": "#8A8A9A", "road": ["#8C6B3D", "#1E2558", "#636582", "#8E8E9D", "#B0AEB2", "#CAC6C2", "#7479A5"], "flow": ["#EBD9B6", "#DFC188", "#D4A85B", "#C8902E", "#8C6B3D"], "front": "#C8902E", "frontText": "#7C6041", "bus": "#2E3A87", "busText": "#283274", "catchOpacity": 0.12, "biz": "#C8902E", "bizCats": ["#C8902E", "#2E3A87", "#7B655A", "#DBB777", "#8286AB", "#84653F", "#283274", "#8A8A9A", "#A27A44", "#545071"], "pop": "#2E3A87", "work": "#C8902E", "age": "#5C546C", "day": "#6C5C63", "dongLine": "#AAA8AE", "kict": "#293479", "kictText": "#263070", "shadow": ["#C3C1C7", "#888BAD", "#2C3780"], "outline": ["#9B9DB6", "#8C8FAB", "#7D809F", "#6E7294", "#5C6187", "#4B507A", "#3A3F6D"], "mass": "#FBF8F1", "massEdge": "#1E2558"}, "orange_circle": {"label": "탠저린 · 슬레이트 그레이 · 화이트", "base": "concrete", "paper": "#FFFFFF", "ink": "#2E353B", "site": "#FF7A1A", "focus": "#969A9D", "road": ["#B66226", "#2E353B", "#71767A", "#9B9EA1", "#BCBEC0", "#D5D7D8", "#949CA2"], "flow": ["#FFE2CD", "#FFBF91", "#FF9D56", "#FF7A1A", "#B66226"], "front": "#FF7A1A", "frontText": "#A15B29", "bus": "#5B6670", "busText": "#49525B", "catchOpacity": 0.12, "biz": "#FF7A1A", "bizCats": ["#FF7A1A", "#5B6670", "#AD7045", "#FFB27A", "#A0A6AC", "#AB5E27", "#49525B", "#969A9D", "#D67530", "#846B5A"], "pop": "#5B6670", "work": "#FF7A1A", "age": "#8C6C56", "day": "#9D6E4E", "dongLine": "#B6B8BA", "kict": "#4E5760", "kictText": "#444E56", "shadow": ["#D6D9DB", "#A5ABB0", "#545F68"], "outline": ["#B5BABF", "#A5AAAF", "#959A9F", "#848A8F", "#72787D", "#5F656B", "#4C5258"], "mass": "#FFFFFF", "massEdge": "#2E353B"}, "mauve_taupe": {"label": "모브 · 토프 · 차콜", "base": "mauve_taupe", "paper": "#F2EFEB", "ink": "#33302E", "site": "#A87C9A", "focus": "#92908C", "road": ["#7F6174", "#33302E", "#706D6A", "#969390", "#B5B2AF", "#CCC9C5", "#B0A498"], "flow": ["#E2D6D9", "#CEB8C4", "#BB9AAF", "#A87C9A", "#7F6174"], "front": "#A87C9A", "frontText": "#735A69", "bus": "#8C7B6B", "busText": "#685D53", "catchOpacity": 0.12, "biz": "#A87C9A", "bizCats": ["#A87C9A", "#8C7B6B", "#9A7C82", "#C7ACBC", "#B7ACA1", "#795E6F", "#685D53", "#92908C", "#A17C8E", "#937B77"], "pop": "#8C7B6B", "work": "#A87C9A", "age": "#947B79", "day": "#977B7E", "dongLine": "#AFACA9", "kict": "#716459", "kictText": "#60564C", "shadow": ["#D8D2CB", "#BAAFA5", "#7F7062"], "outline": ["#C4BBB1", "#B3AAA1", "#A19A92", "#908982", "#7C7670", "#67625D", "#534F4B"], "mass": "#FAF9F7", "massEdge": "#33302E"}, "red_highlight": {"label": "브릭 레드 · 네이비 · 샌드", "base": "crimson", "paper": "#EADFC8", "ink": "#1F2433", "site": "#A8432F", "focus": "#84827E", "road": ["#783830", "#1F2433", "#606063", "#898580", "#A9A398", "#C1BAAA", "#666D7F"], "flow": ["#DBBDA6", "#CA947F", "#B96C57", "#A8432F", "#783830"], "front": "#A8432F", "frontText": "#6A3531", "bus": "#1F2F57", "busText": "#1F2B49", "catchOpacity": 0.12, "biz": "#A8432F", "bizCats": ["#A8432F", "#1F2F57", "#643943", "#C4856F", "#747986", "#713731", "#1F2B49", "#84827E", "#863E39", "#41344D"], "pop": "#1F2F57", "work": "#A8432F", "age": "#48354B", "day": "#563747", "dongLine": "#A39E94", "kict": "#1F2C4C", "kictText": "#1F2A45", "shadow": ["#B7B3AC", "#7A7E8A", "#1F2D52"], "outline": ["#8F9095", "#828389", "#74767D", "#676972", "#575A64", "#474B56", "#383C49"], "mass": "#F7F2E9", "massEdge": "#1F2433"}, "lavender_mint": {"label": "라벤더 · 민트 · 차콜", "base": "lavender_mint", "paper": "#F6F5F8", "ink": "#34343A", "site": "#9C8BDB", "focus": "#959499", "road": ["#786DA3", "#34343A", "#727277", "#99989D", "#B8B7BB", "#CFCED2", "#92D8C3"], "flow": ["#E2DEF2", "#CBC2EA", "#B3A7E3", "#9C8BDB", "#786DA3"], "front": "#9C8BDB", "frontText": "#6D6493", "bus": "#5CC9A7", "busText": "#4C8D7B", "catchOpacity": 0.12, "biz": "#9C8BDB", "bizCats": ["#9C8BDB", "#5CC9A7", "#7CAAC1", "#C2B8E7", "#9DDBC9", "#72689B", "#4C8D7B", "#959499", "#8C9ACE", "#6CBAB4"], "pop": "#5CC9A7", "work": "#9C8BDB", "age": "#6FB6B7", "day": "#76B0BC", "dongLine": "#B2B1B6", "kict": "#509C86", "kictText": "#487E70", "shadow": ["#D0EAE4", "#A1DDCB", "#56B397"], "outline": ["#B1E1D4", "#A2CCC2", "#93B7AF", "#84A39D", "#728A87", "#617271", "#505A5C"], "mass": "#FBFBFC", "massEdge": "#34343A"}, "sepia_drawing": {"label": "딥 버건디 · 모스 그린 · 웜 그레이", "base": "sepia", "paper": "#E9E5DF", "ink": "#3A3633", "site": "#7A1F2E", "focus": "#928E89", "road": ["#642730", "#3A3633", "#726E6A", "#95918C", "#B1ADA8", "#C6C2BD", "#8F9674"], "flow": ["#D1B9B8", "#B4868A", "#97525C", "#7A1F2E", "#642730"], "front": "#7A1F2E", "frontText": "#5D2930", "bus": "#5E6B3A", "busText": "#505637", "catchOpacity": 0.12, "biz": "#7A1F2E", "bizCats": ["#7A1F2E", "#5E6B3A", "#6C4534", "#A97278", "#989E7F", "#602830", "#505637", "#928E89", "#733231", "#655837"], "pop": "#5E6B3A", "work": "#7A1F2E", "age": "#665436", "day": "#694D35", "dongLine": "#ACA8A3", "kict": "#535B38", "kictText": "#4C5036", "shadow": ["#C6C6B6", "#9DA284", "#596339"], "outline": ["#AAAE95", "#9DA089", "#8F917D", "#828372", "#727264", "#626156", "#535049"], "mass": "#F6F5F2", "massEdge": "#3A3633"}, "emerald_peach": {"label": "에메랄드 · 피치 · 아이보리", "base": "emerald_peach", "paper": "#FBF8F0", "ink": "#23352E", "site": "#F09A74", "focus": "#8F968F", "road": ["#A8775C", "#23352E", "#68736C", "#939A93", "#B6BAB2", "#D0D1C9", "#6BBE9C"], "flow": ["#F9E3D5", "#F6CBB4", "#F3B294", "#F09A74", "#A8775C"], "front": "#F09A74", "frontText": "#946D54", "bus": "#1E9E6E", "busText": "#207454", "catchOpacity": 0.12, "biz": "#F09A74", "bizCats": ["#F09A74", "#1E9E6E", "#879C71", "#F5C1A8", "#7BC4A5", "#9E7258", "#207454", "#8F968F", "#BC9B72", "#529D70"], "pop": "#1E9E6E", "work": "#F09A74", "age": "#5D9D70", "day": "#729C70", "dongLine": "#AFB4AC", "kict": "#207E5B", "kictText": "#206A4E", "shadow": ["#C4E2D0", "#81C6A8", "#1F8E64"], "outline": ["#98D0B6", "#8ABDA6", "#7CAB95", "#6E9885", "#5E8272", "#4D6D5F", "#3D574C"], "mass": "#FDFCF9", "massEdge": "#23352E"}, "magenta_cyan": {"label": "마젠타 · 시안 · 페일 옐로우", "base": "magenta_cyan", "paper": "#FBF7DC", "ink": "#1C1C24", "site": "#E0218A", "focus": "#8C8A80", "road": ["#9B1F66", "#1C1C24", "#63625F", "#908E84", "#B4B1A1", "#CECBB7", "#58C2D8"], "flow": ["#F5C8CA", "#EE90B5", "#E7599F", "#E0218A", "#9B1F66"], "front": "#E0218A", "frontText": "#881F5C", "bus": "#00A6D6", "busText": "#0B6F8F", "catchOpacity": 0.12, "biz": "#E0218A", "bizCats": ["#E0218A", "#00A6D6", "#7064B0", "#EB7BAC", "#69C8D9", "#921F61", "#0B6F8F", "#8C8A80", "#A8429D", "#3885C3"], "pop": "#00A6D6", "work": "#E0218A", "age": "#437EBF", "day": "#5A71B8", "dongLine": "#ADAA9C", "kict": "#087DA1", "kictText": "#0E617D", "shadow": ["#BCE3DA", "#71CAD9", "#0491BB"], "outline": ["#8AD3D9", "#7DBDC3", "#70A7AE", "#629198", "#53787E", "#445E65", "#34444C"], "mass": "#FDFCF1", "massEdge": "#1C1C24"}, "sky_mahogany": {"label": "스카이 블루 · 마호가니 · 라이트 샌드", "base": "sky_mahogany", "paper": "#EEE6D6", "ink": "#3A2A24", "site": "#7A3B2E", "focus": "#94887D", "road": ["#64352A", "#3A2A24", "#74665D", "#988C81", "#B4AA9D", "#CAC0B2", "#9BC5DC"], "flow": ["#D4C0B1", "#B69485", "#98675A", "#7A3B2E", "#64352A"], "front": "#7A3B2E", "frontText": "#5D332A", "bus": "#6FB3E0", "busText": "#5A7C95", "catchOpacity": 0.12, "biz": "#7A3B2E", "bizCats": ["#7A3B2E", "#6FB3E0", "#747787", "#AB8375", "#A4C8DC", "#60342A", "#5A7C95", "#94887D", "#77595A", "#7295B4"], "pop": "#6FB3E0", "work": "#7A3B2E", "age": "#728FAB", "day": "#738399", "dongLine": "#AFA498", "kict": "#5F8AA8", "kictText": "#546E82", "shadow": ["#CED9D8", "#A8CADC", "#679EC4"], "outline": ["#B5CFDA", "#A6BBC4", "#97A7AE", "#899498", "#787C7F", "#666566", "#554E4C"], "mass": "#F8F5EF", "massEdge": "#3A2A24"}, "plum_cobalt": {"label": "플럼 · 코발트 · 실버 그레이", "base": "plum", "paper": "#E7E8EB", "ink": "#26282E", "site": "#7B3F72", "focus": "#86888C", "road": ["#5D375A", "#26282E", "#64656A", "#8A8C90", "#A9ABAF", "#C0C2C5", "#6585D2"], "flow": ["#CFC3D0", "#B397B1", "#976B91", "#7B3F72", "#5D375A"], "front": "#7B3F72", "frontText": "#553553", "bus": "#1F4FC4", "busText": "#223F88", "catchOpacity": 0.12, "biz": "#7B3F72", "bizCats": ["#7B3F72", "#1F4FC4", "#4D479B", "#A886A5", "#738FD4", "#593657", "#223F88", "#86888C", "#644386", "#364BB0"], "pop": "#1F4FC4", "work": "#7B3F72", "age": "#3B4AAB", "day": "#4449A3", "dongLine": "#A3A5A9", "kict": "#214397", "kictText": "#223C79", "shadow": ["#B5C2E1", "#7994D6", "#2049AE"], "outline": ["#8DA3D9", "#8194C4", "#7485B0", "#68779B", "#5A6684", "#4B546C", "#3D4354"], "mass": "#F5F6F7", "massEdge": "#26282E"}, "neon_night": {"label": "네온 핑크 · 일렉트릭 블루 · 딥 블랙", "base": "neon_black", "paper": "#07070A", "ink": "#F2F2F7", "site": "#FF2E9A", "focus": "#7C7C80", "road": ["#FF2E9A", "#E6E6EB", "#A0A0A4", "#717175", "#4E4E51", "#363639", "#1E6BFF"], "flow": ["#45112E", "#831A52", "#C12476", "#FF2E9A", "#FF8CC7"], "front": "#FF2E9A", "frontText": "#FF6DB8", "bus": "#1E6BFF", "busText": "#78A6FF", "catchOpacity": 0.14, "biz": "#FF2E9A", "bizCats": ["#FF2E9A", "#1E6BFF", "#8E4CCC", "#971E5E", "#144198", "#FA7CBF", "#73A1FC", "#7C7C80", "#C73DB3", "#565CE6"], "pop": "#1E6BFF", "work": "#FF2E9A", "age": "#6259E1", "day": "#7853D7", "dongLine": "#59595D", "kict": "#6297FF", "kictText": "#8EB5FF", "shadow": ["#0E2554", "#15439D", "#1E6BFF"], "outline": ["#102F6C", "#2B467D", "#465E8D", "#61759E", "#8190B2", "#A1ACC5", "#C0C7D8"], "mass": "#3E3E40", "massEdge": "#ACACB0"}, "olive_petrol": {"label": "올리브 옐로우 · 페트롤 블루 · 웜 그레이", "base": "olive_petrol", "paper": "#E8E5DE", "ink": "#2F3330", "site": "#B5A642", "focus": "#8C8C87", "road": ["#867E3C", "#2F3330", "#6A6C68", "#8F908A", "#ADACA6", "#C3C1BB", "#658E99"], "flow": ["#DDD7BC", "#D0C793", "#C2B66B", "#B5A642", "#867E3C"], "front": "#B5A642", "frontText": "#79723A", "bus": "#1E5F74", "busText": "#254D59", "catchOpacity": 0.12, "biz": "#B5A642", "bizCats": ["#B5A642", "#1E5F74", "#6A825B", "#CAC084", "#7397A1", "#7F783B", "#254D59", "#8C8C87", "#8F944E", "#447168"], "pop": "#1E5F74", "work": "#B5A642", "age": "#4B7465", "day": "#5A7B60", "dongLine": "#A7A7A1", "kict": "#235260", "kictText": "#264952", "shadow": ["#B6C4C4", "#799BA4", "#21586A"], "outline": ["#8DA9AE", "#829B9F", "#768D90", "#6B7F81", "#5E6E6F", "#515D5D", "#444D4C"], "mass": "#F6F5F2", "massEdge": "#2F3330"}, "lime_blue": {"label": "라임 · 블루 · 블랙", "base": "lime_blue", "paper": "#0C0D0F", "ink": "#F2F4F2", "site": "#B8F02A", "focus": "#7F8080", "road": ["#B8F02A", "#E6E8E7", "#A2A3A3", "#737575", "#515253", "#3A3B3C", "#2E6BFF"], "flow": ["#374616", "#627E1C", "#8DB723", "#B8F02A", "#D8F78A"], "front": "#B8F02A", "frontText": "#CDF46A", "bus": "#2E6BFF", "busText": "#82A6FF", "catchOpacity": 0.14, "biz": "#B8F02A", "bizCats": ["#B8F02A", "#2E6BFF", "#73AE94", "#70911F", "#20449A", "#CFF27A", "#7CA2FA", "#7F8080", "#96CF5F", "#508CCA"], "pop": "#2E6BFF", "work": "#B8F02A", "age": "#5793BF", "day": "#65A0AA", "dongLine": "#5C5E5E", "kict": "#6D97FF", "kictText": "#96B5FF", "shadow": ["#162957", "#20459F", "#2E6BFF"], "outline": ["#1A336F", "#344A7F", "#4E618E", "#68789E", "#8694B0", "#A4AFC3", "#C2CAD5"], "mass": "#414244", "massEdge": "#ADAFAE"}, "sage_rusk": {"label": "세이지 · 러스크 · 차콜", "base": "sage_rusk", "paper": "#EFEDE6", "ink": "#3A3B3A", "site": "#B9773E", "focus": "#949490", "road": ["#8D623D", "#3A3B3A", "#747471", "#989893", "#B5B4AF", "#CBC9C4", "#A6B69E"], "flow": ["#E3D3C1", "#D5B495", "#C7966A", "#B9773E", "#8D623D"], "front": "#B9773E", "frontText": "#805C3C", "bus": "#7F9877", "busText": "#63735F", "catchOpacity": 0.12, "biz": "#B9773E", "bizCats": ["#B9773E", "#7F9877", "#9C885A", "#D0A985", "#AEBCA6", "#865F3C", "#63735F", "#949490", "#AA7F4C", "#8E9069"], "pop": "#7F9877", "work": "#B9773E", "age": "#908E66", "day": "#968B60", "dongLine": "#B0AFAA", "kict": "#6A7C65", "kictText": "#5C6A58", "shadow": ["#D3D8CA", "#B1BEA9", "#758A6E"], "outline": ["#BDC7B4", "#ADB6A5", "#9EA597", "#8E9588", "#7C8177", "#696D66", "#575A55"], "mass": "#F9F8F5", "massEdge": "#3A3B3A"}, "ivory_apricot": {"label": "아이보리 · 애프리콧 · 네이비", "base": "ivory_apricot", "paper": "#FBF7EC", "ink": "#1C2A52", "site": "#F2A26B", "focus": "#8C909F", "road": ["#A77862", "#1C2A52", "#636C83", "#9095A2", "#B4B5BB", "#CECECD", "#6C748D"], "flow": ["#F9E4D0", "#F7CEAE", "#F4B88D", "#F2A26B", "#A77862"], "front": "#F2A26B", "frontText": "#926C60", "bus": "#1F2E5A", "busText": "#1E2C57", "catchOpacity": 0.12, "biz": "#F2A26B", "bizCats": ["#F2A26B", "#1F2E5A", "#886862", "#F6C6A1", "#7B8297", "#9C7261", "#1E2C57", "#8C909F", "#BD8567", "#544B5E"], "pop": "#1F2E5A", "work": "#F2A26B", "age": "#5E515F", "day": "#735C61", "dongLine": "#ADAFB6", "kict": "#1E2D58", "kictText": "#1E2C56", "shadow": ["#C4C5C8", "#82889C", "#1F2D59"], "outline": ["#989DAA", "#898F9F", "#7A8195", "#6B748A", "#5A647E", "#495372", "#374365"], "mass": "#FDFCF7", "massEdge": "#1C2A52"}, "cream_coral": {"label": "크림 · 코랄 · 블루", "base": "cream_coral", "paper": "#F8F1E2", "ink": "#2A2F3A", "site": "#F0735A", "focus": "#91908E", "road": ["#AB5B4F", "#2A2F3A", "#6C6D70", "#959491", "#B6B3AC", "#CFCAC0", "#7C9CDC"], "flow": ["#F6D5C4", "#F4B5A1", "#F2947D", "#F0735A", "#AB5B4F"], "front": "#F0735A", "frontText": "#97544C", "bus": "#3A6FD8", "busText": "#345599", "catchOpacity": 0.12, "biz": "#F0735A", "bizCats": ["#F0735A", "#3A6FD8", "#957199", "#F3A893", "#8AA6DC", "#A1584D", "#345599", "#91908E", "#C2727A", "#6870B8"], "pop": "#3A6FD8", "work": "#F0735A", "age": "#7170B2", "day": "#8371A6", "dongLine": "#B0ADA7", "kict": "#355CA9", "kictText": "#324F89", "shadow": ["#C8D0E0", "#90AADC", "#3865C0"], "outline": ["#A2B6DE", "#94A6CA", "#8596B7", "#7785A3", "#66728C", "#556075", "#444D5E"], "mass": "#FCF9F3", "massEdge": "#2A2F3A"}, "forest_lilac": {"label": "포레스트 · 라일락 · 옐로우", "base": "forest_lilac", "paper": "#1F3A2E", "ink": "#EEF2EA", "site": "#F5D94A", "focus": "#86968C", "road": ["#F5D94A", "#E4E9E1", "#A6B2A8", "#7C8D83", "#5D7166", "#485F54", "#C3A6E8"], "flow": ["#546235", "#8A8A3C", "#C0B143", "#F5D94A", "#FAEA9B"], "front": "#F5D94A", "frontText": "#F8E480", "bus": "#C3A6E8", "busText": "#DBCAF1", "catchOpacity": 0.14, "biz": "#F5D94A", "bizCats": ["#F5D94A", "#C3A6E8", "#DCC099", "#9B963E", "#7E799A", "#F2E38A", "#D4C4E9", "#86968C", "#E8CC72", "#D0B3C0"], "pop": "#C3A6E8", "work": "#F5D94A", "age": "#D2B5B9", "day": "#D7BAA9", "dongLine": "#677A70", "kict": "#D5C1EF", "kictText": "#E1D2F4", "shadow": ["#505A66", "#817B9E", "#C3A6E8"], "outline": ["#616578", "#727686", "#838793", "#9498A1", "#A8ACB1", "#BBBFC1", "#CFD3D1"], "mass": "#50655C", "massEdge": "#B0BBB2"}});
/* 사용자가 바꾼 색을 스타일 위에 덮어씁니다 — 스타일마다 따로 저장 */
const COLOR_KEYS = [
  ['site', '대지'], ['focus', '분석 범위선'], ['roadBase', '도로 위계 (주간선 기준)'], ['flowBase', '통과 잠재량·축·결절점'], ['front', '접도'],
  ['bus', '버스·도보권'], ['biz', '상권'], ['pop', '인구'], ['work', '종사자'], ['age', '평균 연령'], ['day', '주간/야간'], ['kict', '측정 지점'],
  ['iso', '보행 등시선'], ['wind', '바람장미·겨울 바람길'], ['windSummer', '여름 바람길'], ['shadowNow', '시각 그림자'], ['shadowBase', '하루 누적 음영'], ['mass', '건물 매스 (3D·축측)'], ['massEdge', '건물 모서리선 (축측)']
];
let COLOR_OV = {}; try{ COLOR_OV = JSON.parse(localStorage.getItem('cleanmapColorOv') || '{}'); }catch(e){}
let ST_CACHE = null;
function hexMix(a, b, t){
  const p = h => [0, 2, 4].map(i => parseInt(h.replace('#', '').slice(i, i + 2), 16));
  const A = p(a), B = p(b);
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join('');
}
function ST(){
  if(ST_CACHE && ST_CACHE.key === SITE.style) return ST_CACHE.st;
  const st = stOf(SITE.style);
  ST_CACHE = { key:SITE.style, st };
  return st;
}
/* 스타일 하나의 실제 색 (사용자가 바꾼 색까지) — 지금 스타일이 아니어도 됩니다 (스타일 미리보기용) */
function stOf(key){
  const base = SITE_STYLES[key] || SITE_STYLES.clean_grid, ov = COLOR_OV[key] || {};
  const st = { ...base };
  // 건물 매스 기본값: 밝은 판은 흰색, 어두운 판은 판보다 조금 밝은 회색
  const isDark = (() => { const c = base.paper.replace('#', ''); return (parseInt(c.slice(0, 2), 16) + parseInt(c.slice(2, 4), 16) + parseInt(c.slice(4, 6), 16)) / 3 < 110; })();
  st.iso = base.iso || base.age;
  st.wind = base.wind || (base.bizCats && base.bizCats[4]) || base.bus;
  st.windSummer = base.windSummer || base.work;
  st.shadowNow = base.shadowNow || base.shadow[1];
  st.mass = base.mass || (isDark ? hexMix(base.paper, base.ink, 0.3) : '#FFFFFF');
  st.massEdge = base.massEdge || (isDark ? hexMix(base.paper, base.ink, 0.7) : base.ink);   // 블루프린트면 파란 모서리
  for(const [k] of COLOR_KEYS) if(ov[k] && !/Base$/.test(k)) st[k] = ov[k];
  if(ov.flowBase){                                                     // 통과 잠재량: 종이색 → 고른 색 5단계
    st.flow = [0.15, 0.35, 0.58, 0.8, 1].map(t => hexMix(base.paper, ov.flowBase, t));
    st.front = ov.front || st.front;
  }
  if(ov.roadBase){                                                     // 도로 위계: 주간선 = 고른 색, 아래 단계는 점점 옅게
    st.road = [base.road[0], ov.roadBase, ...[0.72, 0.5, 0.3, 0.18].map(t => hexMix(base.paper, ov.roadBase, t)), base.road[6]];
  }
  if(ov.shadowBase) st.shadow = [0.3, 0.62, 1].map(t => hexMix(base.paper, ov.shadowBase, t));   // 누적 음영 3단계
  if(ov.bus) st.busText = hexMix(ov.bus, base.ink, 0.35);
  if(ov.kict) st.kictText = hexMix(ov.kict, base.ink, 0.35);
  return st;
}
function invalidateST(){ ST_CACHE = null; }

/* 배포본에 넣어 둘 수 있는 AI 키 — 비워 두면 관리자 설정에서 넣습니다.
   브이월드 키와 달리 호출마다 비용이 생기니, 외부로 퍼지면 콘솔에서 바로 폐기하세요. */
const AI_DEFAULT_KEY = '';
const AI_DEFAULT_MODEL = 'claude-sonnet-5-5';

/* ---------- 분석 범위 — "대지 경계에서 반경" 또는 "고정한 화면 범위" ---------- */
function viewRectM(){
  const [w, s_, e, n] = SITE.viewLL;
  return [toM([w, s_]), toM([e, n])];                       // [[minx,miny],[maxx,maxy]]
}
/* 거리 필터용 반지름 — 범위를 모두 감싸는 원 */
function focusR(){
  if(SITE.range === 'view' && SITE.viewLL){
    const [[x0, y0], [x1, y1]] = viewRectM();
    return Math.round(Math.max(...[[x0, y0], [x0, y1], [x1, y0], [x1, y1]].map(([x, y]) => Math.hypot(x, y))));
  }
  if(!SITE.geom) return SITE.radius;
  let m = 0;
  for(const poly of SITE.geom) for(const p of poly[0]){ const [x, y] = toM(p); m = Math.max(m, Math.hypot(x, y)); }
  return Math.round(m + SITE.radius);
}
function inFocus(p){
  if(SITE.range === 'view' && SITE.viewLL){ const [[x0, y0], [x1, y1]] = viewRectM(); return p[0] >= x0 && p[0] <= x1 && p[1] >= y0 && p[1] <= y1; }
  return Math.hypot(p[0], p[1]) <= focusR();
}
function focusGeomM(){
  if(SITE.range === 'view' && SITE.viewLL){ const [[x0, y0], [x1, y1]] = viewRectM(); return [[[[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]]]; }
  return circleM(focusR(), 96);
}
/* 선을 범위 안으로 자르기 — 원이면 traffic.js 의 원 자르기, 사각형이면 리앙–바스키 */
function clipToFocus(pts){
  if(!(SITE.range === 'view' && SITE.viewLL)) return clipToCircle(pts, focusR());
  const [[x0, y0], [x1, y1]] = viewRectM(), out = []; let cur = null;
  for(let i = 1; i < pts.length; i++){
    const a = pts[i - 1], b = pts[i], dx = b[0] - a[0], dy = b[1] - a[1];
    let t0 = 0, t1 = 1, ok = true;
    for(const [p, q] of [[-dx, a[0] - x0], [dx, x1 - a[0]], [-dy, a[1] - y0], [dy, y1 - a[1]]]){
      if(p === 0){ if(q < 0){ ok = false; break; } continue; }
      const r = q / p; if(p < 0){ if(r > t1){ ok = false; break; } if(r > t0) t0 = r; } else { if(r < t0){ ok = false; break; } if(r < t1) t1 = r; }
    }
    if(!ok){ if(cur){ out.push(cur); cur = null; } continue; }
    const A = [a[0] + t0 * dx, a[1] + t0 * dy], B = [a[0] + t1 * dx, a[1] + t1 * dy];
    if(!cur || t0 > 0){ if(cur) out.push(cur); cur = [A]; }
    cur.push(B);
    if(t1 < 1){ out.push(cur); cur = null; }
  }
  if(cur && cur.length > 1) out.push(cur);
  return out;
}
function rangeLabel(){
  if(SITE.range === 'view' && SITE.viewLL){ const [[x0, y0], [x1, y1]] = viewRectM(); return `화면 범위 ${((x1 - x0) / 1000).toFixed(1)} × ${((y1 - y0) / 1000).toFixed(1)} km`; }
  return `대지 경계에서 ${SITE.radius >= 1000 ? (SITE.radius / 1000) + 'km' : SITE.radius + 'm'}`;
}
const isWide = () => focusR() > 2000;          // 광역 방식으로 바꾸는 기준
/* 분석 기준이 있는가 — 대지를 정했거나, 대지 없이 화면 범위를 고정했을 때 */
const hasRef = () => !!SITE.geom || (SITE.range === 'view' && !!SITE.viewLL && !!SITE.center);
const SITE = {
  mode:'style', prev:null, picking:false,
  draw:'parcel',         // 대지 정하는 방식: parcel · rect · circle
  shape:null,            // 그린 영역 {kind, geom(경위도 MultiPolygon), label}
  parcels:[],            // 고른 필지 feature (브이월드 원본)
  geom:null,             // 대지 다각형 (경위도, polygon-clipping 형식)
  center:null,           // [lng, lat]
  radius:250, style:'clean_grid', range:'radius', viewLL:null, peakGrain:'g3', circleAlpha:0.7,
  exclude:true,          // 대지 안 기존 건물을 계산에서 뺄지 (필지: 철거 전제로 켬 · 그린 영역: 끔)
  sun:{ on:false, date:'winter', day:'', from:9, to:15, step:60, form:'now', result:null, now:null, busy:false, cache:null },
  ai:{ text:'', md:'', busy:false, summary:null }
};

const $ = id => document.getElementById(id);
const CL = () => (typeof ClipperLib !== 'undefined') ? ClipperLib : null;
const CLS = 1000;   // Clipper 는 정수 좌표 — 밀리미터로 올려 씁니다

/* ---------- 좌표: 대지 중심 기준 미터 평면 ---------- */
let LOC = null;   // {lng, lat, kx, ky}
function setLocal(center){
  const [lng, lat] = center;
  LOC = { lng, lat, kx: 111320 * Math.cos(lat * Math.PI / 180), ky: 110540 };
}
const r3 = v => Math.round(v * 1000) / 1000;      // 밀리미터로 반올림 — 겹치는 변이 정확히 맞물리게
const toM  = ([lng, lat]) => [r3((lng - LOC.lng) * LOC.kx), r3((lat - LOC.lat) * LOC.ky)];
const toLL = ([x, y])     => [LOC.lng + x / LOC.kx, LOC.lat + y / LOC.ky];
const mapRings = (mp, fn) => mp.map(poly => poly.map(ring => ring.map(fn)));   // MultiPolygon 좌표 변환

/* ---------- 도형 도우미 ---------- */
function asMulti(g){          // GeoJSON geometry → MultiPolygon 좌표 배열
  if(!g) return [];
  if(g.type === 'Polygon') return [g.coordinates];
  if(g.type === 'MultiPolygon') return g.coordinates;
  return [];
}
function circleM(r, n){
  const ring = [];
  for(let i = 0; i < (n || 64); i++){ const a = i / (n || 64) * Math.PI * 2; ring.push([r * Math.cos(a), r * Math.sin(a)]); }
  ring.push(ring[0]);
  return [[ring]];
}
function ringArea(ring){
  let a = 0;
  for(let i = 0; i < ring.length - 1; i++) a += ring[i][0] * ring[i+1][1] - ring[i+1][0] * ring[i][1];
  return a / 2;
}
function multiArea(mp){
  let a = 0;
  for(const poly of mp){ poly.forEach((ring, i) => { a += (i ? -1 : 1) * Math.abs(ringArea(ring)); }); }
  return a;
}
function pointInRing(pt, ring){
  let inside = false;
  for(let i = 0, j = ring.length - 1; i < ring.length; j = i++){
    const xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
    if(((yi > pt[1]) !== (yj > pt[1])) && (pt[0] < (xj - xi) * (pt[1] - yi) / (yj - yi) + xi)) inside = !inside;
  }
  return inside;
}
function pointInMulti(pt, mp){
  for(const poly of mp){
    if(!pointInRing(pt, poly[0])) continue;
    let hole = false;
    for(let i = 1; i < poly.length; i++) if(pointInRing(pt, poly[i])){ hole = true; break; }
    if(!hole) return true;
  }
  return false;
}
function centroidOf(mp){
  // 경위도처럼 큰 좌표는 곱셈에서 정밀도를 잃으므로 첫 점 기준으로 옮겨 계산합니다
  const [ox, oy] = mp[0][0][0];
  let sx = 0, sy = 0, sa = 0;
  for(const poly of mp){
    const r = poly[0].map(([x, y]) => [x - ox, y - oy]);
    const A = ringArea(r); if(!A) continue;
    let cx = 0, cy = 0;
    for(let i = 0; i < r.length - 1; i++){
      const f = r[i][0] * r[i+1][1] - r[i+1][0] * r[i][1];
      cx += (r[i][0] + r[i+1][0]) * f; cy += (r[i][1] + r[i+1][1]) * f;
    }
    const w = Math.abs(A);
    sx += cx / (6 * A) * w; sy += cy / (6 * A) * w; sa += w;
  }
  return sa ? [ox + sx / sa, oy + sy / sa] : [ox, oy];
}
/* ---------- 불리언 연산 (Clipper, 정수 기반이라 겹친 변에 강합니다) ---------- */
function toPaths(mp){
  const out = [];
  for(const poly of mp) poly.forEach((ring, i) => {
    const a = ringArea(ring);
    let r = ring.slice(0, -1);
    if((i === 0) !== (a > 0)) r = r.slice().reverse();          // 바깥은 +, 구멍은 -
    out.push(r.map(([x, y]) => ({X:Math.round(x * CLS), Y:Math.round(y * CLS)})));
  });
  return out;
}
function fromTree(tree){
  const C = CL();
  const ex = C.JS.PolyTreeToExPolygons(tree), mp = [];
  for(const e of ex){
    if(!e.outer || e.outer.length < 3) continue;
    const conv = p => { const r = p.map(q => [q.X / CLS, q.Y / CLS]); r.push(r[0]); return r; };
    mp.push([conv(e.outer), ...e.holes.filter(h => h.length >= 3).map(conv)]);
  }
  return mp;
}
function clip(type, a, b){
  const C = CL(); const c = new C.Clipper();
  c.AddPaths(toPaths(a), C.PolyType.ptSubject, true);
  if(b) c.AddPaths(toPaths(b), C.PolyType.ptClip, true);
  const tree = new C.PolyTree();
  c.Execute(type, tree, C.PolyFillType.pftNonZero, C.PolyFillType.pftNonZero);
  return fromTree(tree);
}
/* 오프셋 — 양수면 부풀리고 음수면 줄입니다 */
function offsetMP(mp, d){
  if(!mp.length) return mp;
  const C = CL(); const co = new C.ClipperOffset(2, 0.05 * CLS);
  co.AddPaths(toPaths(mp), C.JoinType.jtMiter, C.EndType.etClosedPolygon);
  const tree = new C.PolyTree(); co.Execute(tree, d * CLS);
  return fromTree(tree);
}
/* 잔선 정리 — 틈 메우기(닫힘) → 가시 제거(열림) → 작은 조각·구멍 버리기
   close: 이 폭보다 좁은 틈은 메웁니다 · open: 이 폭의 두 배보다 가는 가시는 지웁니다 */
const CLEAN = { close:0.3, open:0.4, minPiece:4, minHole:4, simplify:0.25 };
function cleanMP(mp, opt){
  if(!mp || !mp.length) return [];
  const o = {...CLEAN, ...(opt || {})};
  let m = mp;
  if(o.close) m = offsetMP(offsetMP(m, o.close), -o.close);
  if(o.open)  m = offsetMP(offsetMP(m, -o.open), o.open);
  const out = [];
  for(const poly of m){
    if(Math.abs(ringArea(poly[0])) < o.minPiece) continue;
    const rings = [poly[0], ...poly.slice(1).filter(h => Math.abs(ringArea(h)) >= o.minHole)];
    out.push(o.simplify ? rings.map(r => simplifyRing(r, o.simplify)) : rings);
  }
  return out;
}
/* 더글러스–포이커 단순화 — 계단처럼 잘게 꺾인 변을 펴 줍니다 */
function simplifyRing(r, tol){
  if(r.length < 6) return r;
  const pts = r.slice(0, -1), keep = new Uint8Array(pts.length);
  keep[0] = 1; keep[pts.length - 1] = 1;
  const stack = [[0, pts.length - 1]];
  while(stack.length){
    const [a, b] = stack.pop();
    let md = 0, mi = -1;
    const [ax, ay] = pts[a], [bx, by] = pts[b];
    const L = Math.hypot(bx - ax, by - ay) || 1e-9;
    for(let i = a + 1; i < b; i++){
      const d = Math.abs((bx - ax) * (ay - pts[i][1]) - (ax - pts[i][0]) * (by - ay)) / L;
      if(d > md){ md = d; mi = i; }
    }
    if(md > tol && mi > 0){ keep[mi] = 1; stack.push([a, mi], [mi, b]); }
  }
  const out = pts.filter((_, i) => keep[i]);
  if(out.length < 3) return r;
  out.push(out[0]);
  return out;
}
/* 여러 시각의 그림자 중 k개 이상이 겹친 곳 — 감김수를 이용해 한 번에 구합니다.
   각 시각 그림자를 +1 로 쌓고, 범위 원을 뒤집어 (k-1)번 넣은 뒤 "양수만 채우기" */
function atLeast(list, k, frame){
  const C = CL(); const c = new C.Clipper();
  for(const mp of list) if(mp.length) c.AddPaths(toPaths(mp), C.PolyType.ptSubject, true);
  const neg = toPaths(frame).map(p => p.slice().reverse());
  for(let i = 0; i < k - 1; i++) c.AddPaths(neg, C.PolyType.ptSubject, true);
  const tree = new C.PolyTree();
  c.Execute(C.ClipType.ctUnion, tree, C.PolyFillType.pftPositive, C.PolyFillType.pftPositive);
  return fromTree(tree);
}
const union = (list) => { const l = list.filter(m => m && m.length); if(!l.length) return []; if(l.length === 1) return l[0]; return clip(CL().ClipType.ctUnion, [].concat(...l)); };
const diff = (a, b) => (!a || !a.length) ? [] : (!b || !b.length) ? a : clip(CL().ClipType.ctDifference, a, b);
const inter = (a, b) => (!a || !b || !a.length || !b.length) ? [] : clip(CL().ClipType.ctIntersection, a, b);
function feature(mp, props){
  const g = mp.length === 1 ? {type:'Polygon', coordinates:mp[0]} : {type:'MultiPolygon', coordinates:mp};
  return {type:'Feature', properties:props || {}, geometry:g};
}
function ringFeature(mp, props){        // 면의 테두리를 선으로
  const lines = [];
  for(const poly of mp) for(const ring of poly) lines.push(ring);
  return {type:'Feature', properties:props || {}, geometry:{type:'MultiLineString', coordinates:lines}};
}

/* ---------- 태양 위치 ---------- */
const DECL = { winter:-23.44, equinox:0, summer:23.44 };
const DATE_LABEL = { winter:'동지', equinox:'춘·추분', summer:'하지' };
const DATE_DOY = { winter:355, equinox:80, summer:172 };
function doyOf(str){ const d = new Date(str + 'T12:00:00'); if(isNaN(d)) return 355; const s0 = new Date(d.getFullYear(), 0, 0); return Math.round((d - s0) / 864e5); }
/* 지금 고른 날짜의 적위·연중일·이름 */
function sunDay(){
  if(SITE.sun.date === 'custom' && SITE.sun.day){
    const n = doyOf(SITE.sun.day);
    return { n, decl: 23.44 * Math.sin(2 * Math.PI * (284 + n) / 365), label: SITE.sun.day.slice(5).replace('-', '/') };
  }
  const k = SITE.sun.date === 'custom' ? 'winter' : SITE.sun.date;
  return { n: DATE_DOY[k], decl: DECL[k], label: DATE_LABEL[k] };
}
/* 균시차(분) */
function eot(n){ const B = 2 * Math.PI * (n - 81) / 364; return 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B); }
/* 한국 표준시(동경 135°) → 진태양시 */
const clockToSolar = (h, lng, n) => h + (lng - 135) / 15 + eot(n) / 60;
function sunPos(hour, decl, lat){
  const H = (15 * (hour - 12)) * Math.PI / 180, d = decl * Math.PI / 180, p = lat * Math.PI / 180;
  const alt = Math.asin(Math.sin(p) * Math.sin(d) + Math.cos(p) * Math.cos(d) * Math.cos(H));
  const az = Math.atan2(-Math.sin(H), Math.tan(d) * Math.cos(p) - Math.sin(p) * Math.cos(H));
  return { alt: alt * 180 / Math.PI, az: ((az * 180 / Math.PI) + 360) % 360 };
}

/* ============================================================
   1. 모드 전환
   ============================================================ */
function setMode(m){
  if(m === SITE.mode) return;
  SITE.mode = m;
  [...$('modes').children].forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === m)));
  $('mode-style').hidden = m !== 'style';
  $('mode-site').hidden  = m !== 'site';
  if(m === 'site'){
    SITE.prev = { preset:S.preset, labelMode:S.labelMode, parcel:S.on.parcel, building:S.on.building_kr, parcelVis:S.vis['vw-parcel'] };
    S.vis['vw-parcel'] = $('stparcel').checked;
    S.on.parcel = true; S.on.building_kr = true;
    applyStyle();
    if(typeof trafficOnSiteChange === 'function') trafficOnSiteChange();
  if(typeof busOnSiteChange === 'function') busOnSiteChange();
  if(typeof bizOnSiteChange === 'function') bizOnSiteChange();
  if(typeof popOnSiteChange === 'function') popOnSiteChange();
  if(typeof placesOnSiteChange === 'function') placesOnSiteChange();
    if(typeof vwRefresh === 'function') vwRefresh(true);
    setStatus('대지분석 — 필지를 골라 시작하세요');
  }else{
    stopPick();
    if(SITE.view3d && typeof set3d === 'function') set3d(false);
    if(typeof trafficOnSiteChange === 'function') trafficOnSiteChange();
  if(typeof busOnSiteChange === 'function') busOnSiteChange();
  if(typeof bizOnSiteChange === 'function') bizOnSiteChange();
  if(typeof popOnSiteChange === 'function') popOnSiteChange();
  if(typeof placesOnSiteChange === 'function') placesOnSiteChange();
    if(typeof registerSecLayers === 'function') registerSecLayers();      // 단면선은 대지분석에서만
    if(SITE.prev){
      S.preset = SITE.prev.preset; S.labelMode = SITE.prev.labelMode;
      S.on.parcel = SITE.prev.parcel;
      if(SITE.prev.parcelVis === undefined) delete S.vis['vw-parcel']; else S.vis['vw-parcel'] = SITE.prev.parcelVis;
      renderPresets(); segSync('labelmode', S.labelMode); renderChecks(); apply();
    }
    setStatus('준비됐습니다');
  }
}
$('modes').addEventListener('click', e => { const b = e.target.closest('button'); if(b) setMode(b.dataset.v); });

function applyStyle(){
  invalidateST();
  const st = SITE_STYLES[SITE.style];
  if(PRESETS.find(p => p.id === st.base)) S.preset = st.base;
  S.labelMode = 0;
  renderPresets(); segSync('labelmode', 0); renderChecks();
  registerSiteLayers(); registerSunLayers();
  if(typeof registerTrafficLayers === 'function') registerTrafficLayers();
  if(typeof registerBusLayers === 'function') registerBusLayers();
  if(typeof registerBizLayers === 'function') registerBizLayers();
  if(typeof registerKictLayers === 'function') registerKictLayers();
  if(typeof registerPopLayers === 'function') registerPopLayers();
  if(typeof register3d === 'function') register3d();
  if(typeof registerHubLayers === 'function') registerHubLayers();
  if(typeof registerWindLayers === 'function') registerWindLayers();
  if(typeof registerLifeLayers === 'function') registerLifeLayers();
  if(typeof registerTourLayers === 'function') registerTourLayers();
  if(typeof registerSecLayers === 'function') registerSecLayers();
  apply();
}
/* ---------- 스타일 미리보기 — 작은 대지분석 장면을 스타일마다 그려 고르기 전에 느낌을 봅니다 ----------
   바탕 지도(물·녹지·건물·길) 위에 대지·분석 범위·도로 위계·통과 축과 결절점·인구/상권 거점 원·버스 도보권·그림자 */
function stylePreviewSVG(key){
  const st = stOf(key), pr = (PRESETS.find(p => p.id === st.base) || {}).colors || {};
  const bg = pr.bg || st.paper, water = pr.water || hexMix(st.paper, st.bus, 0.25), green = pr.green || hexMix(st.paper, '#7FA870', 0.3);
  const bld = pr.building || hexMix(st.paper, st.ink, 0.12), bldLine = pr.buildingLine || hexMix(st.paper, st.ink, 0.3);
  const minor = pr.roadMinor || hexMix(st.paper, st.ink, 0.25);
  const sh = st.shadow[1], road = st.road, flow = st.flow;
  const B = [[40,6,10,9],[53,7,11,8],[76,6,8,10],[87,8,7,7],[9,29,9,7],[20,31,9,11],[75,29,7,7],[84,30,9,12],[9,55,8,9],[19,56,10,7],[40,56,9,8],[52,57,12,10],[75,55,8,7],[100,30,13,8],[101,41,9,6]];
  const shadow = B.filter((b, i) => i % 3 === 0).map(([x, y, w, h]) => `<path d="M${x} ${y}h${w}l-6 -5h-${w}z M${x} ${y}v${h}l-6 -5v-${h}z"/>`).join('');
  return `<svg viewBox="0 0 120 76" preserveAspectRatio="xMidYMid slice" aria-hidden="true">`
    + `<rect width="120" height="76" fill="${bg}"/>`
    + `<path d="M86 76V66q8-9 18-6t16-4V76z" fill="${water}"/>`
    + `<rect x="5" y="4" width="25" height="15" rx="2" fill="${green}"/>`
    + `<g stroke="${minor}" stroke-width=".8" fill="none"><path d="M0 24H120M0 51H120M34 0V76M70 0V76M96 0V52"/></g>`
    + `<g fill="${sh}" opacity=".55">${shadow}</g>`
    + `<g fill="${bld}" stroke="${bldLine}" stroke-width=".35">${B.map(([x, y, w, h]) => `<rect x="${x}" y="${y}" width="${w}" height="${h}"/>`).join('')}</g>`
    + `<circle cx="22" cy="62" r="12" fill="${st.pop}" fill-opacity=".22" stroke="${st.pop}" stroke-width=".8"/>`
    + `<circle cx="84" cy="38" r="8.5" fill="${st.biz}" fill-opacity=".28" stroke="${st.biz}" stroke-width=".8"/>`
    + `<circle cx="104" cy="16" r="10" fill="${st.bus}" fill-opacity="${Math.min(0.35, (st.catchOpacity || 0.1) * 1.8)}" stroke="${st.bus}" stroke-width=".5" stroke-dasharray="1.5 1.2"/>`
    + `<path d="M0 51H120" stroke="${road[1]}" stroke-width="2.6"/><path d="M70 0V76" stroke="${road[2]}" stroke-width="1.8"/><path d="M34 24V76" stroke="${road[3]}" stroke-width="1.2"/>`
    + `<path d="M0 24H96L104 16" fill="none" stroke="${flow[3]}" stroke-width="3" stroke-linecap="round" opacity=".92"/>`
    + `<g fill="${flow[4]}" stroke="${bg}" stroke-width=".7"><circle cx="34" cy="24" r="2.6"/><circle cx="70" cy="24" r="3.2"/></g>`
    + `<circle cx="104" cy="16" r="1.7" fill="${st.bus}" stroke="${bg}" stroke-width=".5"/>`
    + `<circle cx="53" cy="37" r="25" fill="none" stroke="${st.focus}" stroke-width=".7" stroke-dasharray="2 1.6"/>`
    + `<path d="M44 30L61 29L63 44L45 45Z" fill="${st.site}" fill-opacity=".28" stroke="${st.site}" stroke-width="1.3" stroke-linejoin="round"/>`
    + `</svg>`;
}
function renderStyleCards(){
  const box = $('stgrid'); if(!box) return;
  box.innerHTML = Object.entries(SITE_STYLES).map(([k, v]) =>
    `<button class="stcard" type="button" data-k="${k}" aria-pressed="${k === SITE.style}" title="${esc(v.label)}" aria-label="${esc(v.label)}">${stylePreviewSVG(k)}</button>`).join('');
  showStyleBig(SITE.style);
}
/* 큰 미리보기 — 작은 칸에 마우스를 올리면 그 스타일, 떼면 지금 스타일 */
function showStyleBig(k){
  const big = $('stbig'); if(!big) return;
  const cur = k === SITE.style, v = SITE_STYLES[k] || {};
  big.innerHTML = `<span class="th">${stylePreviewSVG(k)}</span><span class="cap"><b>${esc(v.label || '')}</b><span>${cur ? '지금 스타일' : '미리보기 · 누르면 적용'}</span></span>`;
  big.classList.toggle('peek', !cur);
}
(function initStyleSelect(){
  const sel = $('ststyle');
  sel.innerHTML = Object.entries(SITE_STYLES).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('');
  sel.value = SITE.style;
  sel.addEventListener('change', () => { SITE.style = sel.value; invalidateST(); applyStyle(); renderColorPickers(); });
  const grid = $('stgrid');
  if(grid){
    grid.addEventListener('click', e => {
      const b = e.target.closest('.stcard'); if(!b || b.dataset.k === SITE.style) return;
      sel.value = b.dataset.k; sel.dispatchEvent(new Event('change'));
    });
    const peek = e => { const b = e.target.closest && e.target.closest('.stcard'); if(b) showStyleBig(b.dataset.k); };
    grid.addEventListener('mouseover', peek); grid.addEventListener('focusin', peek);
    grid.addEventListener('mouseleave', () => showStyleBig(SITE.style));
    grid.addEventListener('focusout', e => { if(!grid.contains(e.relatedTarget)) showStyleBig(SITE.style); });
  }
  renderStyleCards();
})();

/* 관리자 상자는 app.js 가 여닫습니다 — 그 상태를 따라갑니다 */
/* 연결 설정 상자는 두 모드가 함께 씁니다 — app.js 가 여닫는 상태를 감싸는 칸에 옮겨 줍니다 */
const syncAdminSec = () => { $('adminsec').hidden = $('adminbox').hidden; };
new MutationObserver(syncAdminSec).observe($('adminbox'), {attributes:true, attributeFilter:['hidden']});
syncAdminSec();
/* SGIS 키 — 인구·사업체 분석에서 씁니다 */
try{ $('sgisid').value = localStorage.getItem('cleanmapSgisId') || ''; $('sgissecret').value = localStorage.getItem('cleanmapSgisSecret') || ''; }catch(e){}
$('sgissave').addEventListener('click', () => {
  try{ localStorage.setItem('cleanmapSgisId', $('sgisid').value.trim()); localStorage.setItem('cleanmapSgisSecret', $('sgissecret').value.trim()); }catch(e){}
  toast('SGIS 키를 저장했습니다');
});

/* ============================================================
   2. 대지 지정 — 필지 클릭
   ============================================================ */
const PICK_LABEL = { parcel:'필지 고르기', rect:'사각형 그리기', circle:'원 그리기' };
function startPick(){
  SITE.picking = true;
  $('stpick').textContent = SITE.draw === 'parcel' ? '고르는 중 — 필지를 클릭 (다시 누르면 끝)' : '그리는 중 — 지도에서 끌어 주세요';
  $('stpick').classList.remove('primary');
  map.getCanvas().style.cursor = 'crosshair';
  if(SITE.draw === 'parcel'){
    S.vis['vw-parcel'] = true; apply();
    if(map.getZoom() < 16) toast('필지가 보이도록 더 확대하세요 (줌 16 이상)');
  }else{
    map.dragPan.disable(); map.boxZoom.disable();
  }
}
function stopPick(){
  if(SITE.picking && SITE.mode === 'site' && SITE.draw === 'parcel'){ S.vis['vw-parcel'] = $('stparcel').checked; apply(); }
  SITE.picking = false;
  $('stpick').textContent = PICK_LABEL[SITE.draw];
  $('stpick').classList.add('primary');
  if(map){ map.getCanvas().style.cursor = ''; map.dragPan.enable(); map.boxZoom.enable(); }
  endDraft();
}
$('stexclude').checked = SITE.exclude;
$('stexclude').addEventListener('change', e => { SITE.exclude = e.target.checked; SITE.sun.cache = null; SITE.sun.result = null; if(SITE.sun.form === 'bands'){ extraRemove('sun-'); apply(); $('sunsum').textContent = ''; } scheduleNow(); });
$('stdraw').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  if(SITE.picking) stopPick();
  SITE.draw = b.dataset.v; segSync('stdraw', SITE.draw);
  SITE.exclude = SITE.draw === 'parcel'; $('stexclude').checked = SITE.exclude; SITE.sun.cache = null;
  $('stpick').textContent = PICK_LABEL[SITE.draw];
  if(!SITE.shape && !SITE.parcels.length) $('stlist').innerHTML = EMPTY_TEXT[SITE.draw];
});
segSync('stdraw', SITE.draw);

/* ---------- 사각형·원 그리기 — 끄는 동안은 화면 위 미리보기, 놓으면 도형으로 ---------- */
let DRAFT = null;
function endDraft(){ if(DRAFT && DRAFT.el) DRAFT.el.remove(); DRAFT = null; }
function onDown(e){
  if(!SITE.picking || SITE.draw === 'parcel') return;
  e.preventDefault();
  const el = document.createElement('div');
  const col = SITE_STYLES[SITE.style].site;
  el.style.cssText = `position:absolute;pointer-events:none;border:2px dashed ${col};background:${col}14;z-index:5;`
    + (SITE.draw === 'circle' ? 'border-radius:50%;' : '');
  map.getCanvasContainer().appendChild(el);
  DRAFT = { a:e.point, b:e.point, el, tip:null };
  drawDraft();
}
function onMove(e){ if(!DRAFT) return; DRAFT.b = e.point; drawDraft(); }
function drawDraft(){
  const {a, b, el} = DRAFT;
  if(SITE.draw === 'rect'){
    el.style.left = Math.min(a.x, b.x) + 'px'; el.style.top = Math.min(a.y, b.y) + 'px';
    el.style.width = Math.abs(b.x - a.x) + 'px'; el.style.height = Math.abs(b.y - a.y) + 'px';
  }else{
    const r = Math.hypot(b.x - a.x, b.y - a.y);
    el.style.left = (a.x - r) + 'px'; el.style.top = (a.y - r) + 'px';
    el.style.width = el.style.height = (2 * r) + 'px';
  }
  const m = draftMeters();
  setStatus(SITE.draw === 'rect' ? `사각형 ${m.w.toFixed(1)} × ${m.h.toFixed(1)} m` : `원 반지름 ${m.r.toFixed(1)} m`);
}
/* 기준점 o 로 잠깐 쓰는 변환 — 전역 LOC 는 바꾸지 않습니다 */
function localConv([lng0, lat0]){
  const kx = 111320 * Math.cos(lat0 * Math.PI / 180), ky = 110540;
  return { m:([lng, lat]) => [(lng - lng0) * kx, (lat - lat0) * ky], ll:([x, y]) => [lng0 + x / kx, lat0 + y / ky] };
}
function draftMeters(){
  const A = map.unproject(DRAFT.a), B = map.unproject(DRAFT.b), cv = localConv([A.lng, A.lat]);
  const [x, y] = cv.m([B.lng, B.lat]);
  const C = map.unproject([DRAFT.b.x, DRAFT.a.y]), D = map.unproject([DRAFT.a.x, DRAFT.b.y]);
  return { r:Math.hypot(x, y), w:Math.hypot(...cv.m([C.lng, C.lat])), h:Math.hypot(...cv.m([D.lng, D.lat])) };
}
function onUp(){
  if(!DRAFT) return;
  const {a, b} = DRAFT;
  const m = draftMeters();
  let geom, label;
  if(SITE.draw === 'rect'){
    if(m.w < 3 || m.h < 3){ endDraft(); toast('너무 작습니다 — 끌어서 그려 주세요'); return; }
    const corners = [[a.x, a.y], [b.x, a.y], [b.x, b.y], [a.x, b.y]].map(p => { const q = map.unproject(p); return [q.lng, q.lat]; });
    const cv = localConv(corners[0]);
    let ring = corners.map(cv.m); ring.push(ring[0]);
    if(ringArea(ring) < 0) ring = ring.reverse();
    geom = [[ring.map(cv.ll)]];
    label = `사각형 ${m.w.toFixed(1)} × ${m.h.toFixed(1)} m`;
  }else{
    if(m.r < 2){ endDraft(); toast('너무 작습니다 — 중심에서 바깥으로 끌어 주세요'); return; }
    const A = map.unproject(a), cv = localConv([A.lng, A.lat]);
    geom = mapRings(circleM(m.r, 96), cv.ll);
    label = `원 반지름 ${m.r.toFixed(1)} m`;
  }
  SITE.shape = { kind:SITE.draw, geom, label };
  SITE.parcels = [];
  stopPick();
  setStatus('대지를 정했습니다 — ' + label);
  rebuildSite();
}
$('stpick').addEventListener('click', () => SITE.picking ? stopPick() : startPick());

/* ---------- 대지 찾기 — 주소·지번·건물 이름 (브이월드 검색) ----------
   지번·도로명 주소를 고르면 그 자리 필지를 바로 대지로 정하고,
   장소(건물·시설 이름)를 고르면 그곳으로 옮긴 뒤 필지를 눌러 정하게 합니다. */
async function vwSearch(query, type, category, size){
  const u = new URL('https://api.vworld.kr/req/search');
  const p = { service:'search', request:'search', version:'2.0', crs:'EPSG:4326', size:String(size || 5), page:'1', query, type, format:'json', errorformat:'json', key:VW.key };
  if(category) p.category = category;
  if(VW.domain) p.domain = VW.domain;
  for(const [k, v] of Object.entries(p)) u.searchParams.set(k, v);
  const r = await fetch(u.toString()).then(x => x.json());
  const res = r && r.response;
  if(!res || res.status === 'NOT_FOUND') return [];
  if(res.status !== 'OK') throw new Error((res.error && (res.error.text || res.error.code)) || res.status);
  const items = (res.result && res.result.items) || [];
  return items.map(it => {
    const ad = it.address || {}, pt = it.point || {};
    return { kind:type === 'place' ? 'place' : category, id:String(it.id || ''), title:it.title || '', cat:it.category || '',
             road:ad.road || '', parcel:ad.parcel || '', bld:ad.bldnm || '', x:+pt.x, y:+pt.y };
  }).filter(it => isFinite(it.x) && isFinite(it.y));
}
const SQ = { list:[], busy:false };
function sqRender(msg){
  const box = $('stqres');
  if(msg){ box.hidden = false; box.innerHTML = `<p>${esc(msg)}</p>`; return; }
  if(!SQ.list.length){ box.hidden = true; box.innerHTML = ''; return; }
  const TAG = { parcel:'지번', road:'도로명', place:'장소', osm:'지명' };
  box.hidden = false;
  box.innerHTML = SQ.list.map((it, i) => {
    const main = it.kind === 'place' || it.kind === 'osm' ? it.title : it.kind === 'road' ? it.road + (it.bld ? ' ' + it.bld : '') : it.parcel;
    const sub = it.kind === 'place' ? (it.road || it.parcel) + (it.cat ? ' · ' + it.cat.split('>').pop().trim() : '')
              : it.kind === 'road' ? it.parcel : it.kind === 'parcel' ? it.road : '';
    return `<button data-i="${i}"><em>${TAG[it.kind] || ''}</em>${esc(main || '')}${sub ? `<small>${esc(sub)}</small>` : ''}</button>`;
  }).join('');
}
async function siteSearch(raw){
  const q = (raw || '').trim(); if(!q || SQ.busy) return;
  // 좌표나 구글맵 주소는 지도 꾸미기의 이동 기능 그대로
  if(/^https?:\/\//i.test(q) || (typeof parseLoc === 'function' && parseLoc(q))){ if(typeof goTo === 'function') goTo(q); return; }
  SQ.busy = true; SQ.list = []; sqRender('찾는 중…');
  const out = [], errs = [];
  if(VW.key){
    const jobs = await Promise.allSettled([vwSearch(q, 'address', 'parcel', 5), vwSearch(q, 'address', 'road', 5), vwSearch(q, 'place', null, 6)]);
    for(const j of jobs){ if(j.status === 'fulfilled') out.push(...j.value); else errs.push(j.reason && j.reason.message); }
  }
  // 브이월드에서 못 찾으면 지명 검색(OSM)으로 한 번 더
  if(!out.length){
    try{
      const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=kr&q=' + encodeURIComponent(q), { headers:{ 'Accept-Language':'ko' } }).then(x => x.json());
      for(const it of r || []) out.push({ kind:'osm', title:it.display_name.split(',').slice(0, 3).join(',').trim(), x:+it.lon, y:+it.lat });
    }catch(e){ errs.push(e.message); }
  }
  const seen = new Set();
  SQ.list = out.filter(it => { const k = it.kind + '|' + it.x.toFixed(5) + ',' + it.y.toFixed(5); if(seen.has(k)) return false; seen.add(k); return true; }).slice(0, 12);
  SQ.busy = false;
  if(!SQ.list.length){ sqRender(`"${q}" 을(를) 찾지 못했습니다` + (errs.length ? ' — ' + errs.filter(Boolean)[0] : '')); return; }
  sqRender();
  if(SQ.list.length === 1) sqChoose(SQ.list[0]);
}
/* 그 자리의 필지 한 장 — 같은 지번(PNU)이 있으면 그것, 없으면 점을 품은 필지 */
async function parcelAt(x, y, pnu){
  const d = 0.0006;
  const fc = await vwFetch('parcel', [x - d, y - d, x + d, y + d], undefined, 1, null);   // 옮기자마자 도는 화면 갱신에 끊기지 않게
  const fs = (fc && fc.features) || [];
  return fs.find(f => pnu && f.properties && f.properties.pnu === pnu) || fs.find(f => pointInMulti([x, y], asMulti(f.geometry))) || null;
}
async function sqChoose(it){
  map.jumpTo({ center:[it.x, it.y], zoom:Math.max(map.getZoom(), 17.5) });
  const isAddr = it.kind === 'parcel' || it.kind === 'road';
  if(!isAddr || SITE.draw !== 'parcel'){
    // 장소 이름 · 사각형/원 모드 — 옮기기만 하고 고르기(그리기)를 시작
    if(!SITE.picking) startPick();
    setStatus(SITE.draw === 'parcel' ? '옮겼습니다 — 대지로 쓸 필지를 누르세요' : '옮겼습니다 — 지도에서 끌어 대지를 그리세요');
    return;
  }
  try{
    setStatus('필지 찾는 중');
    const hit = await parcelAt(it.x, it.y, /^\d{19}$/.test(it.id) ? it.id : null);
    if(!hit){ if(!SITE.picking) startPick(); setStatus('그 자리 필지를 찾지 못했습니다 — 지도에서 필지를 눌러 주세요'); return; }
    if(SITE.picking) stopPick();
    SITE.shape = null; SITE.parcels = [hit];
    rebuildSite();
    setStatus('대지를 정했습니다 — ' + pName(hit) + ' (옆 필지를 더하려면 "필지 고르기")');
  }catch(err){
    if(!SITE.picking) startPick();
    setStatus('필지를 받지 못했습니다 — ' + err.message + ' · 지도에서 필지를 눌러 주세요');
  }
}
$('stgo').addEventListener('click', () => siteSearch($('stq').value));
$('stq').addEventListener('keydown', e => { if(e.key === 'Enter') siteSearch($('stq').value); if(e.key === 'Escape'){ SQ.list = []; sqRender(); } });
$('stqres').addEventListener('click', e => {
  const b = e.target.closest('button[data-i]'); if(!b) return;
  const it = SQ.list[+b.dataset.i]; if(!it) return;
  [...$('stqres').querySelectorAll('button')].forEach(x => x.classList.toggle('on', x === b));
  sqChoose(it);
});
$('stparcel').addEventListener('change', e => { if(!SITE.picking){ S.vis['vw-parcel'] = e.target.checked; apply(); } });
$('stclear').addEventListener('click', () => { SITE.parcels = []; SITE.shape = null; rebuildSite(); });

function onMapClick(e){
  if(!SITE.picking || SITE.draw !== 'parcel') return;
  const fc = VW.data.parcel;
  if(!fc || !fc.features.length){ toast('아직 필지를 받지 못했습니다. 잠시 기다리거나 더 확대하세요.'); return; }
  const pt = [e.lngLat.lng, e.lngLat.lat];
  const hit = fc.features.find(f => pointInMulti(pt, asMulti(f.geometry)));
  if(!hit){ toast('클릭한 곳에 필지가 없습니다'); return; }
  const key = pKey(hit);
  const i = SITE.parcels.findIndex(f => pKey(f) === key);
  SITE.shape = null;
  if(i >= 0) SITE.parcels.splice(i, 1); else SITE.parcels.push(hit);
  rebuildSite();
}
const pKey = f => (f.properties && (f.properties.pnu || f.properties.id || f.properties.ogc_fid)) || JSON.stringify(f.geometry.coordinates[0][0]);
const pName = f => (f.properties && (f.properties.jibun || f.properties.addr || f.properties.pnu)) || '필지';

function rebuildSite(){
  const empty = !SITE.shape && !SITE.parcels.length;
  if(empty){
    SITE.geom = null; SITE.center = null;
    if(SITE.range === 'view' && SITE.viewLL){ SITE.center = [(SITE.viewLL[0] + SITE.viewLL[2]) / 2, (SITE.viewLL[1] + SITE.viewLL[3]) / 2]; setLocal(SITE.center); }
    $('stlist').innerHTML = EMPTY_TEXT[SITE.draw];
    extraRemove('site-'); extraRemove('sun-'); SITE.sun.result = null; $('sunsum').textContent = '';
    apply(); return;
  }
  let mpM, rows;
  if(SITE.shape){
    const g = SITE.shape.geom;
    setLocal(g[0][0][0]);
    mpM = mapRings(g, toM);
    rows = [`<div class="row"><span>${esc(SITE.shape.label)}</span><button class="x" data-k="@shape" title="지우기">×</button></div>`];
  }else{
    setLocal(asMulti(SITE.parcels[0].geometry)[0][0][0]);   // 임시 기준점 — 미터로 바꿔 합칩니다
    mpM = union(SITE.parcels.map(f => mapRings(asMulti(f.geometry), toM)));
    rows = SITE.parcels.map(f => `<div class="row"><span>${esc(pName(f))}</span><button class="x" data-k="${esc(pKey(f))}" title="빼기">×</button></div>`);
  }
  const geomLL = mapRings(mpM, toLL);
  const cM = centroidOf(mpM);
  SITE.center = toLL(cM);
  SITE.geom = geomLL;
  setLocal(SITE.center);                                   // 이후 계산은 대지 중심 기준
  const area = multiArea(mapRings(SITE.geom, toM));
  $('stlist').innerHTML = rows.join('')
    + `<div class="row" style="margin-top:4px;color:var(--ink-soft)"><span>면적</span><span class="num">${Math.round(area).toLocaleString()} ㎡</span></div>`;
  SITE.sun.result = null; SITE.sun.now = null; SITE.sun.cache = null; $('sunsum').textContent = '';
  extraRemove('sun-');
  registerSiteLayers();
  if(typeof trafficOnSiteChange === 'function') trafficOnSiteChange();
  if(typeof busOnSiteChange === 'function') busOnSiteChange();
  if(typeof bizOnSiteChange === 'function') bizOnSiteChange();
  if(typeof popOnSiteChange === 'function') popOnSiteChange();
  if(typeof placesOnSiteChange === 'function') placesOnSiteChange();
  apply();
  scheduleNow();
}
const EMPTY_TEXT = {
  parcel:'아직 고른 필지가 없습니다. 필지가 보일 만큼 확대한 뒤 "필지 고르기"를 누르고 지도에서 클릭하세요. 여러 필지를 이어서 누르면 합쳐집니다.',
  rect:'"사각형 그리기"를 누르고 지도에서 끌어 영역을 그리세요.',
  circle:'"원 그리기"를 누르고 중심에서 바깥으로 끌어 영역을 그리세요.'
};
$('stlist').addEventListener('click', e => {
  const b = e.target.closest('.x'); if(!b) return;
  if(b.dataset.k === '@shape') SITE.shape = null;
  else SITE.parcels = SITE.parcels.filter(f => pKey(f) !== b.dataset.k);
  rebuildSite();
});
function onRangeChanged(){
  SITE.sun.result = null; SITE.sun.now = null; SITE.sun.cache = null; $('sunsum').textContent = ''; extraRemove('sun-');
  registerSiteLayers(); if(typeof trafficOnSiteChange === 'function') trafficOnSiteChange();
  if(typeof busOnSiteChange === 'function') busOnSiteChange();
  if(typeof bizOnSiteChange === 'function') bizOnSiteChange();
  if(typeof popOnSiteChange === 'function') popOnSiteChange();
  if(typeof placesOnSiteChange === 'function') placesOnSiteChange(); apply(); scheduleNow();
  $('strangeinfo').textContent = (SITE.range === 'radius' && !SITE.geom) ? rangeLabel() + ' — 대지를 정하면 적용됩니다'
    : rangeLabel() + (SITE.geom ? '' : ' · 대지 없이 화면 중심 기준') + (isWide() ? ' · 넓은 범위라 버스·도로는 광역 방식으로 계산합니다' : '');
}
$('strange').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  SITE.range = b.dataset.v; segSync('strange', SITE.range);
  $('stradbox').hidden = SITE.range !== 'radius'; $('stviewbox').hidden = SITE.range !== 'view';
  if(SITE.range === 'view' && !SITE.viewLL) setViewRange(); else onRangeChanged();
});
function setViewRange(){
  const b = map.getBounds();
  SITE.viewLL = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()];
  if(!SITE.geom){                                  // 대지 없이 화면만 분석 — 화면 중심을 기준점으로
    SITE.center = [(SITE.viewLL[0] + SITE.viewLL[2]) / 2, (SITE.viewLL[1] + SITE.viewLL[3]) / 2];
    setLocal(SITE.center);
  }
  onRangeChanged();
}
$('stviewset').addEventListener('click', setViewRange);
$('stradius').addEventListener('change', e => {
  const v = e.target.value;
  $('stradcustom').hidden = v !== 'custom';
  if(v === 'custom') return;
  SITE.radius = +v; onRangeChanged();
});
$('stradcustom').addEventListener('change', e => {
  const v = Math.max(50, Math.min(30000, Math.round(+e.target.value || 0)));
  if(!v) return; SITE.radius = v; onRangeChanged();
});
segSync('strange', SITE.range);

function registerSiteLayers(){
  extraRemove('site-');
  if(!hasRef()) return;
  const st = SITE_STYLES[SITE.style];
  const ring = mapRings(focusGeomM(), toLL);
  extraSet('site-radius', { label:'분석_반경', stage:'top', type:'line', nomerge:true,
    fc:{type:'FeatureCollection', features:[ringFeature(ring, {label:rangeLabel()})]},
    paint:{'line-color':st.focus, 'line-width':1, 'line-dasharray':[3, 3]},
    svg:{kind:'line', stroke:st.focus, width:0.8, dash:[3, 3]} });
  if(!SITE.geom) return;
  extraSet('site-boundary', { label:'분석_대지', stage:'top', type:'line', nomerge:true,
    fc:{type:'FeatureCollection', features:[ringFeature(SITE.geom, {label:'대지'})]},
    paint:{'line-color':st.site, 'line-width':2.4, 'line-dasharray':[2, 1.4]},
    svg:{kind:'line', stroke:st.site, width:2, dash:[2, 1.4]} });
}

/* ============================================================
   3. 일조 그림자
   ============================================================ */
$('sunon').addEventListener('change', e => {
  SITE.sun.on = e.target.checked;
  $('sunopts').hidden = !SITE.sun.on;
  $('card-sun').classList.toggle('on', SITE.sun.on);
  if(!SITE.sun.on){ stopPlay(); extraRemove('sun-'); apply(); }
  else if(SITE.sun.form === 'now') scheduleNow();
  else if(SITE.sun.result) registerSunLayers(), apply();
});
$('sundate').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  SITE.sun.date = b.dataset.v; segSync('sundate', b.dataset.v);
  $('sunday').hidden = b.dataset.v !== 'custom';
  if(b.dataset.v === 'custom' && !$('sunday').value){ const d = new Date(); $('sunday').value = d.toISOString().slice(0, 10); SITE.sun.day = $('sunday').value; }
  SITE.sun.result = null; if(SITE.sun.form === 'bands'){ extraRemove('sun-'); apply(); $('sunsum').textContent = ''; }
  scheduleNow();
});
$('sunday').addEventListener('change', e => { SITE.sun.day = e.target.value; scheduleNow(); });
$('sunform').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  SITE.sun.form = b.dataset.v; segSync('sunform', b.dataset.v);
  $('nowbox').hidden = SITE.sun.form !== 'now'; $('bandbox').hidden = SITE.sun.form !== 'bands';
  stopPlay();
  registerSunLayers(); apply();
  if(SITE.sun.form === 'now') scheduleNow();
  else $('sunsum').textContent = SITE.sun.result ? SITE.sun.result.text : '';
});
segSync('sundate', SITE.sun.date); segSync('sunform', SITE.sun.form);
$('nowtime').addEventListener('input', () => { nowLabel(); scheduleNow(); });
$('sunminfl').addEventListener('change', () => { if(SITE.sun.form === 'now') scheduleNow(); });
$('sunrun').addEventListener('click', runSun);

function convexHull(pts){
  const P = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  if(P.length < 3) return P;
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = []; for(const p of P){ while(lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop(); lower.push(p); }
  const upper = []; for(let i = P.length - 1; i >= 0; i--){ const p = P[i]; while(upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop(); upper.push(p); }
  const h = lower.slice(0, -1).concat(upper.slice(0, -1)); h.push(h[0]); return h;
}
const isConvexish = ring => { const h = convexHull(ring); return Math.abs(ringArea(h)) <= Math.abs(ringArea(ring)) * 1.12; };

/* 건물 하나의 그림자 — 볼록한 건물은 껍질 하나로, 오목한 건물은 바닥면 + 옮긴 면 + 모서리 띠 */
function buildingShadow(rings, dx, dy, h, convex){
  const parts = [];
  for(const ring of rings){
    const moved = ring.map(([x, y]) => [r3(x + dx * h), r3(y + dy * h)]);
    if(convex){ parts.push([[convexHull(ring.concat(moved))]]); continue; }
    parts.push([[ring]], [[moved]]);
    for(let i = 0; i < ring.length - 1; i++){
      parts.push([[[ring[i], ring[i+1], moved[i+1], moved[i], ring[i]]]]);
    }
  }
  return parts;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- 그림자 계산 엔진 ----------
   건물 수천 동을 한 번에 합치면(Clipper) 화면이 몇 초씩 멈춥니다(응답 없음).
   · 범위를 150m 칸으로 나눠 칸마다 합치고 칸 경계로 자릅니다 — 칸끼리는 겹치지 않음
   · 칸 사이마다 잠깐 쉬어 화면이 계속 움직이게, 새 시각이 들어오면 바로 그만둡니다
   · 다 되면 칸들을 넷씩 묶어 이어 붙여 이음매를 없앱니다 (이것도 쉬어 가며)
   예전의 열고 닫기 정리(오프셋)는 넓은 범위에서 수 초씩 걸려 빼고, 작은 조각·구멍만 버립니다 */
const SH_TILE = 150;
const shNow = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
const bbOfMP = mp => { const b = [1e9, 1e9, -1e9, -1e9]; for(const poly of mp) for(const [x, y] of poly[0]){ if(x < b[0]) b[0] = x; if(y < b[1]) b[1] = y; if(x > b[2]) b[2] = x; if(y > b[3]) b[3] = y; } return b; };
/* 건물 그림자 조각들 — 볼록한 건물은 껍질 하나, 오목한 건물은 바닥·옮긴 바닥·모서리 띠 (합치기는 칸에서) */
function shadowPieces(blds, dx, dy, k, opt){
  const out = [];
  for(const b of blds){
    if(opt.reach != null && b.d != null && b.d > opt.reach + b.h * k + 60) continue;
    if(opt.minFl && b.floors < opt.minFl) continue;
    for(const mp of buildingShadow(b.rings, dx, dy, b.h, b.convex)) out.push({ mp, b:bbOfMP(mp) });
  }
  return out;
}
/* 그림자 바닥 상자 — Clipper 없이 (대지에 닿는지 먼저 거를 때) */
function shadowBox(b, dx, dy){
  const bb = [1e9, 1e9, -1e9, -1e9];
  for(const r of b.rings) for(const [x, y] of r){ for(const [px, py] of [[x, y], [x + dx * b.h, y + dy * b.h]]){ if(px < bb[0]) bb[0] = px; if(py < bb[1]) bb[1] = py; if(px > bb[2]) bb[2] = px; if(py > bb[3]) bb[3] = py; } }
  return bb;
}
/* 칸 — 범위(focus)마다 한 번 만들어 둡니다 (칸과 범위가 겹치는 모양까지) */
function shGrid(focus){
  const fb = bbOfMP(focus), key = fb.map(v => v.toFixed(1)).join(',') + '|' + focus.length + '|' + SH_TILE;
  if(SITE.sun.grid && SITE.sun.grid.key === key) return SITE.sun.grid;
  const nx = Math.max(1, Math.ceil((fb[2] - fb[0]) / SH_TILE)), ny = Math.max(1, Math.ceil((fb[3] - fb[1]) / SH_TILE));
  const regions = new Map();
  const region = id => {
    if(regions.has(id)) return regions.get(id);
    const i = Math.floor(id / 10000), j = id % 10000, x0 = fb[0] + i * SH_TILE, y0 = fb[1] + j * SH_TILE;
    const r = inter([[[[x0, y0], [x0 + SH_TILE, y0], [x0 + SH_TILE, y0 + SH_TILE], [x0, y0 + SH_TILE], [x0, y0]]]], focus);
    regions.set(id, r); return r;
  };
  SITE.sun.grid = { key, fb, nx, ny, region };
  return SITE.sun.grid;
}
/* 칸마다 합치고 자르기 → Map(칸 → MultiPolygon). stale() 이 참이 되면 null */
async function tileUnion(pieces, grid, stale){
  const { fb, nx, ny } = grid, buckets = new Map();
  for(const p of pieces){
    const i0 = Math.max(0, Math.floor((p.b[0] - fb[0]) / SH_TILE)), i1 = Math.min(nx - 1, Math.floor((p.b[2] - fb[0]) / SH_TILE));
    const j0 = Math.max(0, Math.floor((p.b[1] - fb[1]) / SH_TILE)), j1 = Math.min(ny - 1, Math.floor((p.b[3] - fb[1]) / SH_TILE));
    for(let i = i0; i <= i1; i++) for(let j = j0; j <= j1; j++){ const id = i * 10000 + j; let l = buckets.get(id); if(!l) buckets.set(id, l = []); l.push(p.mp); }
  }
  const out = new Map(); let last = shNow();
  for(const [id, list] of buckets){
    const reg = grid.region(id);
    if(reg.length){ const r = inter(union(list), reg); if(r.length) out.set(id, r); }
    if(shNow() - last > 14){ await sleep(0); last = shNow(); if(stale && stale()) return null; }
  }
  return out;
}
/* 칸들을 넷씩 묶어 이어 붙이기 (이음매 없애기) */
async function mergeTiles(tiles, stale){
  let level = new Map(tiles), last = shNow();
  while(level.size > 1){
    const groups = new Map();
    for(const [id, mp] of level){ const g = Math.floor(Math.floor(id / 10000) / 2) * 10000 + Math.floor((id % 10000) / 2); let l = groups.get(g); if(!l) groups.set(g, l = []); l.push(mp); }
    const next = new Map();
    for(const [g, l] of groups){
      next.set(g, l.length > 1 ? union(l) : l[0]);
      if(shNow() - last > 14){ await sleep(0); last = shNow(); if(stale && stale()) return null; }
    }
    level = next;
  }
  return [...level.values()][0] || [];
}
/* 가벼운 정리 — 작은 조각·구멍만 버리고 잘게 꺾인 변을 폅니다 (오프셋 없이) */
function lightClean(mp, minA){
  const m = minA || 2, out = [];
  for(const poly of mp){
    if(Math.abs(ringArea(poly[0])) < m) continue;
    out.push([poly[0], ...poly.slice(1).filter(h => Math.abs(ringArea(h)) >= m)].map(r => simplifyRing(r, 0.15)));
  }
  return out;
}
const tilesToMP = tiles => [].concat(...tiles.values());

async function runSun(){
  if(!SITE.geom){ toast('먼저 대지를 고르세요'); return; }
  if(SITE.sun.form !== 'bands'){ SITE.sun.form = 'bands'; segSync('sunform', 'bands'); $('nowbox').hidden = true; $('bandbox').hidden = false; }
  if(!CL()){ toast('clipper 라이브러리가 없습니다 (lib/clipper.js)'); return; }
  const fc = VW.data.building_kr;
  if(!fc || !fc.features.length){ toast('건물_국내 데이터가 없습니다. 지도를 움직여 받아오세요.'); return; }
  if(SITE.sun.busy) return;
  SITE.sun.busy = true; $('sunrun').disabled = true;
  const from = +$('sunfrom').value, to = +$('sunto').value, step = +$('sunstep').value;
  SITE.sun.from = from; SITE.sun.to = to; SITE.sun.step = step;
  const day = sunDay(), decl = day.decl, lat = SITE.center[1];
  const fh = S.bldFH || 3;
  const focus = focusGeomM();
  const siteM = mapRings(SITE.geom, toM);

  let excluded = 0;
  // 범위 + 그림자 도달 거리 안의 건물만
  const samples = [];
  for(let t = from; t <= to + 1e-9; t += step / 60) samples.push(t);
  let minAlt = 90;
  for(const t of samples){ const sp = sunPos(t, decl, lat); if(sp.alt > 0) minAlt = Math.min(minAlt, sp.alt); }
  const blds = [];
  for(const f of fc.features){
    const floors = floorsOf(f.properties) || 1;                      // 3D 매스와 같은 규칙: 층수가 비어 있으면 1층
    const h = floors * fh;
    const reach = h / Math.tan(Math.max(minAlt, 3) * Math.PI / 180);
    const rings = [];
    for(const poly of asMulti(f.geometry)) rings.push(poly[0].map(toM));   // 바깥 고리만 (안뜰은 무시)
    const c = rings[0][0];
    if(Math.hypot(c[0], c[1]) > focusR() + reach + 60) continue;
    if(SITE.exclude && pointInMulti(centroidOf([[rings[0]]]), siteM)){ excluded++; continue; }   // 대지 안 기존 건물 — 철거 전제
    blds.push({ rings, h, floors, props:f.properties, hits:0, convex:rings.length === 1 && isConvexish(rings[0]) });
  }
  if(!blds.length){ $('sunsum').textContent = '반경 안에 층수 정보가 있는 건물이 없습니다 (건물_국내를 받았는지 확인하세요)'; SITE.sun.busy = false; $('sunrun').disabled = false; return; }

  const minFl = +$('sunminfl').value || 1;              // 화면에 그릴 그림자의 최소 층수
  const siteSh = [], hours = [];
  let siteBox = [1e9, 1e9, -1e9, -1e9];
  for(const poly of siteM) for(const [x, y] of poly[0]){ siteBox = [Math.min(siteBox[0], x), Math.min(siteBox[1], y), Math.max(siteBox[2], x), Math.max(siteBox[3], y)]; }
  const bbox = mp => { let b = [1e9, 1e9, -1e9, -1e9]; for(const poly of mp) for(const [x, y] of poly[0]) b = [Math.min(b[0], x), Math.min(b[1], y), Math.max(b[2], x), Math.max(b[3], y)]; return b; };
  const overlaps = (p, q) => p[0] <= q[2] && p[2] >= q[0] && p[1] <= q[3] && p[3] >= q[1];
  try{
    const grid = shGrid(focus), perTile = new Map();
    let N = 0;
    for(let i = 0; i < samples.length; i++){
      const t = samples[i];
      const sp = sunPos(t, decl, lat);
      if(sp.alt <= 0) continue;
      $('sunsum').textContent = `계산 중 ${i + 1}/${samples.length} · ${fmtH(t)} · 건물 ${blds.length}동`;
      await sleep(0);
      const k = 1 / Math.tan(sp.alt * Math.PI / 180);
      const dx = -Math.sin(sp.az * Math.PI / 180) * k, dy = -Math.cos(sp.az * Math.PI / 180) * k;
      // 화면에 그릴 그림자 — 칸마다 합쳐 둡니다 (시각마다 칸 하나에 한 조각 → 나중에 몇 시각 겹쳤는지 셈)
      const tiles = await tileUnion(shadowPieces(blds, dx, dy, k, { minFl }), grid, null);
      for(const [id, mp] of tiles){ let l = perTile.get(id); if(!l) perTile.set(id, l = []); l.push(mp); }
      // 대지를 가리는지 — 그림자 상자가 대지에 닿는 건물만 하나씩 (층수 제한 없이 모두)
      const hitParts = [];
      for(const b of blds){
        if(!overlaps(shadowBox(b, dx, dy), siteBox)) continue;
        const cast = diff(union(buildingShadow(b.rings, dx, dy, b.h, b.convex)), b.rings.map(r => [r]));   // 건물 발자국을 뺀, 땅에 떨어진 그림자
        if(multiArea(inter(cast, siteM)) > 1){ b.hits++; hitParts.push(cast); }   // 1㎡ 넘게 덮어야 차폐로 봅니다
      }
      siteSh.push(hitParts.length ? inter(union(hitParts), siteM) : []);
      hours.push(t); N++;
    }
    // 누적: k개 이상 시각에서 그늘 — 칸마다 감김수 한 번으로, 그다음 칸 이어 붙이기
    const perHour = 60 / step;
    const bandDefs = [2, 4, 6].map(hh => ({ hours:hh, k:Math.round(hh * perHour) })).filter(b => b.k >= 1 && b.k <= N);
    const bands = [];
    for(const bd of bandDefs){
      $('sunsum').textContent = `누적 계산 중 · ${bd.hours}시간 이상`; await sleep(0);
      const tiles = new Map(); let last = shNow();
      for(const [id, list] of perTile){
        if(list.length < bd.k) continue;
        const r = atLeast(list, bd.k, grid.region(id)); if(r.length) tiles.set(id, r);
        if(shNow() - last > 14){ await sleep(0); last = shNow(); }
      }
      // 누적 면은 칸끼리 이어 붙이면 수십 초가 걸려(구멍이 많은 큰 면) 칸 조각 그대로 둡니다 — 조각끼리 겹치지 않고 맞닿기만 합니다
      bands.push({ ...bd, geom:lightClean(tilesToMP(tiles), 2) });
    }
    // 대지 안 표본점으로 음영시간
    const pts = [];
    let minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9;
    for(const poly of siteM) for(const [x, y] of poly[0]){ minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); }
    const n = 14;
    for(let i = 0; i < n; i++) for(let j = 0; j < n; j++){
      const p = [minx + (maxx - minx) * (i + .5) / n, miny + (maxy - miny) * (j + .5) / n];
      if(pointInMulti(p, siteM)) pts.push(p);
    }
    const counts = pts.map(p => siteSh.reduce((a, sh) => a + (pointInMulti(p, sh) ? 1 : 0), 0));
    const toH = c => c * step / 60;
    const avg = counts.length ? toH(counts.reduce((a, b) => a + b, 0) / counts.length) : 0;
    const max = counts.length ? toH(Math.max(...counts)) : 0;
    const over4 = counts.length ? counts.filter(c => toH(c) >= 4).length / counts.length : 0;
    const over2 = counts.length ? counts.filter(c => toH(c) >= 2).length / counts.length : 0;

    // 주요 차폐 건물
    const obs = blds.filter(b => b.hits).sort((a, b) => b.hits - a.hits).slice(0, 4).map(b => {
      const c = centroidOf([[b.rings[0]]]);
      const d = Math.hypot(c[0], c[1]);
      const bearing = (Math.atan2(c[0], c[1]) * 180 / Math.PI + 360) % 360;
      return { floors:b.floors, height_m:+b.h.toFixed(1), distance_m:Math.round(d), direction:dir16(bearing), shading_hours:+toH(b.hits).toFixed(1) };
    });

    const obsB = blds.filter(b => b.hits).sort((a, b) => b.hits - a.hits).slice(0, 5);
    const text = `${day.label} 진태양시 ${fmtH(from)}–${fmtH(to)} · 대지 평균 음영 ${avg.toFixed(1)}시간 · 최대 ${max.toFixed(1)}시간 · 4시간 이상 그늘 ${Math.round(over4 * 100)}%`;
    SITE.sun.result = { date:day.label, text, decl, from, to, step, hours, bands, obsB, minFl,
      stats:{ site_avg_h:+avg.toFixed(1), site_max_h:+max.toFixed(1), site_pct_over_2h:Math.round(over2 * 100), site_pct_over_4h:Math.round(over4 * 100),
              noon_altitude:+sunPos(12, decl, lat).alt.toFixed(1), buildings_considered:blds.length, sample_points:pts.length, display_min_floors:minFl },
      obstructions:obs };
    $('sunsum').textContent = text;
    registerSunLayers(); apply();
    const nl = [...EXTRA.layers.keys()].filter(k => k.startsWith('sun-')).length;
    const pieces = bands.reduce((a, b) => a + b.geom.length, 0);
    toast(pieces ? `일조 계산 완료 · 분석 레이어 ${nl}개`
      : excluded > 20 ? `그릴 그림자가 없습니다 — 대지 안 건물 ${excluded}동을 철거 전제로 뺐습니다. 넓은 영역을 그렸다면 "대지 안 기존 건물 제외"를 끄세요`
      : '그릴 그림자가 없습니다 — "그림자 표시" 층수를 낮춰 보세요');
    setStatus(`일조 · 건물 ${blds.length}동 · 그림자 조각 ${pieces}개`);
  }catch(err){
    console.error('[대지분석] 일조 계산 실패', err);
    $('sunsum').textContent = '계산 실패 — ' + err.message;
    setStatus('일조 계산 실패 — ' + esc(err.message), true);
  }
  SITE.sun.busy = false; $('sunrun').disabled = false;
}
const fmtH = t => { const h = Math.floor(t), m = Math.round((t - h) * 60); return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`; };
const dir16 = deg => ['북','북북동','북동','동북동','동','동남동','남동','남남동','남','남남서','남서','서남서','서','서북서','북서','북북서'][Math.round(deg / 22.5) % 16];

function registerSunLayers(){
  extraRemove('sun-');
  if(!SITE.sun.on || !hasRef()) return;
  const st = SITE_STYLES[SITE.style];
  if(SITE.sun.form === 'now'){
    const nw = SITE.sun.now;
    if(!nw || !nw.disp.length) return;
    extraSet('sun-now', nowLayer(nw, st));
  }else{
    const r = SITE.sun.result;
    if(!r) return;
    r.bands.forEach((b, i) => {
      if(!b.geom.length) return;
      const sh = ST().shadow, col = sh[Math.min(i, sh.length - 1)], op = SITE.shadowAlpha == null ? 1 : SITE.shadowAlpha;
      extraSet('sun-band-' + b.hours, { label:`분석_일영_${r.date}_${b.hours}h이상`, stage:'ground', type:'fill', nomerge:true,
        fc:{type:'FeatureCollection', features:[feature(mapRings(b.geom, toLL), {hours:b.hours})]},
        paint:{'fill-color':col, 'fill-opacity':op, 'fill-antialias':true, 'fill-outline-color':col},
        svg:{kind:'fill', fill:col, opacity:op} });
    });
  }
  extraSet('sun-focus', { label:'분석_일영_범위', stage:'line', type:'line', nomerge:true,
    fc:{type:'FeatureCollection', features:[ringFeature(mapRings(focusGeomM(), toLL), {})]},
    paint:{'line-color':st.focus, 'line-width':0.8, 'line-dasharray':[2, 2]},
    svg:{kind:'line', stroke:st.focus, width:0.6, dash:[2, 2]} });
}
function nowLayer(nw, st){
  st = ST();
  const col = st.shadowNow || st.shadow[1], op = SITE.shadowAlpha == null ? 1 : SITE.shadowAlpha;
  return { label:`분석_그림자_${nw.day}_${fmtH(nw.clock).replace(':', '')}`, stage:'ground', type:'fill', nomerge:true,
    fc:{type:'FeatureCollection', features:[feature(mapRings(nw.disp, toLL), {time:fmtH(nw.clock)})]},
    paint:{'fill-color':col, 'fill-opacity':op, 'fill-antialias':true, 'fill-outline-color':col},
    svg:{kind:'fill', fill:col, opacity:op} };
}

/* ---------- 시각 그림자 ---------- */
/* 반경 주변 건물을 미터 좌표로 한 번만 준비해 두고, 시각이 바뀔 때마다 재사용합니다 */
function prepBuildings(){
  const fc = VW.data.building_kr;
  if(!fc || !fc.features.length || !hasRef()) return null;
  const key = [SITE.center.join(), SITE.radius, SITE.range, SITE.viewLL && SITE.viewLL.join(), fc.features.length, S.bldFH, SITE.exclude, !!SITE.geom].join('|');
  if(SITE.sun.cache && SITE.sun.cache.key === key) return SITE.sun.cache;
  const fh = S.bldFH || 3, siteM = SITE.geom ? mapRings(SITE.geom, toM) : [];
  const blds = []; let excludedN = 0;
  for(const f of fc.features){
    const floors = floorsOf(f.properties) || 1;                      // 3D 매스와 같은 규칙: 층수가 비어 있으면 1층
    const rings = [];
    for(const poly of asMulti(f.geometry)) rings.push(poly[0].map(toM));
    const c = centroidOf([[rings[0]]]), d = Math.hypot(c[0], c[1]);
    if(d > focusR() + 500) continue;
    if(SITE.exclude && siteM.length && pointInMulti(c, siteM)){ excludedN++; continue; }  // 대지 안 기존 건물 — 철거 전제
    blds.push({ rings, h:floors * fh, floors, d, bearing:(Math.atan2(c[0], c[1]) * 180 / Math.PI + 360) % 360,
                convex:rings.length === 1 && isConvexish(rings[0]) });
  }
  let box = [1e9, 1e9, -1e9, -1e9];
  for(const poly of siteM) for(const [x, y] of poly[0]) box = [Math.min(box[0], x), Math.min(box[1], y), Math.max(box[2], x), Math.max(box[3], y)];
  SITE.sun.cache = { key, blds, siteM, siteBox:box, siteArea:multiArea(siteM), excluded:excludedN };
  return SITE.sun.cache;
}
function nowLabel(){
  const m = +$('nowtime').value, h = m / 60;
  $('nowlabel').textContent = fmtH(h);
  if(SITE.center){
    const day = sunDay(), sol = clockToSolar(h, SITE.center[0], day.n), sp = sunPos(sol, day.decl, SITE.center[1]);
    $('nowsun').textContent = sp.alt > 0 ? `진태양시 ${fmtH(sol)} · 고도 ${sp.alt.toFixed(1)}° · ${dir16(sp.az)}쪽 해` : `진태양시 ${fmtH(sol)} · 해가 지평선 아래`;
  }
}
let nowTimer = null, nowSeq = 0;
function scheduleNow(){
  nowLabel();
  if(!SITE.sun.on || SITE.sun.form !== 'now') return;
  clearTimeout(nowTimer);
  nowTimer = setTimeout(runNow, 120);
}
async function runNow(){
  if(!hasRef()){ $('sunsum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(!CL()){ $('sunsum').textContent = 'clipper 라이브러리가 없습니다'; return; }
  const P = prepBuildings();
  if(!P || !P.blds.length){ $('sunsum').textContent = '반경 안에 층수 정보가 있는 건물이 없습니다 (건물_국내를 받았는지 확인하세요)'; return; }
  const seq = ++nowSeq;
  const clock = +$('nowtime').value / 60, day = sunDay();
  const sol = clockToSolar(clock, SITE.center[0], day.n), sp = sunPos(sol, day.decl, SITE.center[1]);
  if(sp.alt <= 0.5){
    SITE.sun.now = null; registerSunLayers(); apply();
    $('sunsum').textContent = `${day.label} ${fmtH(clock)} — 해가 떠 있지 않습니다`; return;
  }
  const minFl = +$('sunminfl').value || 1, FR = focusR(), focus = focusGeomM();
  const k = 1 / Math.tan(sp.alt * Math.PI / 180);
  const dx = -Math.sin(sp.az * Math.PI / 180) * k, dy = -Math.cos(sp.az * Math.PI / 180) * k;
  const stale = () => seq !== nowSeq;                                       // 시각이 또 바뀌었으면 이 계산은 버립니다
  // 대지 그늘 — 그림자 상자가 대지에 닿는 건물만 하나씩 (층수 제한 없이 모두)
  const hits = [], hitGeo = [];
  const overlaps = (p, q) => p[0] <= q[2] && p[2] >= q[0] && p[1] <= q[3] && p[3] >= q[1];
  if(P.siteM.length) for(const b of P.blds){
    if(b.d > FR + b.h * k + 60 || !overlaps(shadowBox(b, dx, dy), P.siteBox)) continue;
    const cast = inter(diff(union(buildingShadow(b.rings, dx, dy, b.h, b.convex)), b.rings.map(r => [r])), P.siteM);
    const a = multiArea(cast);
    if(a > 1){ hits.push({ b, a }); hitGeo.push(cast); }
  }
  const shadedA = hitGeo.length ? multiArea(union(hitGeo)) : 0;
  const pct = P.siteArea ? Math.min(100, Math.round(shadedA / P.siteArea * 100)) : 0;
  hits.sort((x, y) => y.a - x.a);
  const info = { clock, solar:sol, day:day.label, alt:+sp.alt.toFixed(1), az:+sp.az.toFixed(0), site_shaded_pct:pct,
    casters: hits.slice(0, 4).map(({b, a}) => ({ floors:b.floors, height_m:+b.h.toFixed(1), distance_m:Math.round(b.d), direction:dir16(b.bearing), shaded_m2:Math.round(a) })) };
  const top = info.casters[0];
  const label = SITE.geom ? `${day.label} ${fmtH(clock)} · 대지의 ${pct}% 가 그늘` + (top ? ` · 주로 ${top.direction}쪽 ${top.floors}층 건물` : '')
    : `${day.label} ${fmtH(clock)} · 태양 고도 ${sp.alt.toFixed(0)}° · 범위 전체 그림자 (대지를 정하면 대지 그늘 비율도 계산합니다)`;
  // 화면 그림자 — 칸마다 합쳐 바로 보여 주고, 멈추면 칸을 이어 붙여 이음매를 없앱니다
  const pieces = shadowPieces(P.blds, dx, dy, k, { reach:FR, minFl });
  const big = pieces.length > 1500;
  if(big) $('sunsum').textContent = `${day.label} ${fmtH(clock)} · 그림자 계산 중 (건물 ${P.blds.length}동)…`;
  const tiles = await tileUnion(pieces, shGrid(focus), stale);
  if(!tiles || stale()) return;
  if(big){ showNow({ ...info, disp:tilesToMP(tiles) }, label + ' · 다듬는 중…'); await sleep(0); if(stale()) return; }
  const merged = await mergeTiles(tiles, stale);
  if(!merged || stale()) return;
  const disp = lightClean(merged);
  if(!disp.length && P.excluded > 20) toast(`대지 안 건물 ${P.excluded}동을 철거 전제로 빼서 그림자가 적습니다 — 넓은 영역이면 "대지 안 기존 건물 제외"를 끄세요`);
  showNow({ ...info, disp }, label);
}
/* 그림자 바꿔 끼우기 — 이미 있는 레이어는 데이터만 바꿔 슬라이더가 끊기지 않게 */
function showNow(nw, label){
  SITE.sun.now = nw;
  $('sunsum').textContent = label;
  const st = SITE_STYLES[SITE.style];
  const def = nowLayer(SITE.sun.now, st);
  const src = map && map.getSource && map.getSource('x-sun-now');
  if(src && EXTRA.layers.has('sun-now') && def.fc.features.length){
    EXTRA.layers.get('sun-now').fc = def.fc; EXTRA.layers.get('sun-now').label = def.label;
    src.setData(def.fc);
    if(typeof buildStyle === 'function') buildStyle();                      // 내보내기용 이름·순서만 갱신
  }else{
    registerSunLayers(); apply();
  }
}
/* 시각 바꾸기 — 재생 대신 휠로 (슬라이더 위에서 휠: 10분, Shift 를 같이 누르면 30분 · 지도 위에서는 Shift + 휠: 10분) */
function stepNow(dir, big){
  const el = $('nowtime'), st = +el.step || 10, v = Math.max(+el.min, Math.min(+el.max, +el.value + dir * st * (big ? 3 : 1)));
  if(v === +el.value) return;
  el.value = v; nowLabel(); scheduleNow();
}
function stopPlay(){}                                                        // 예전 '하루 재생' 자리 (호출하는 곳 호환)
(function hookWheel(){
  const dOf = e => e.deltaY || e.deltaX;                                    // 맥에서는 Shift 를 누르면 세로 휠이 가로로 바뀝니다
  $('nowtime').addEventListener('wheel', e => { const d = dOf(e); if(!d) return; e.preventDefault(); stepNow(d > 0 ? 1 : -1, e.shiftKey); }, { passive:false });
  if(typeof map === 'undefined' || !map || !map.getCanvasContainer){ setTimeout(hookWheel, 400); return; }
  map.getCanvasContainer().addEventListener('wheel', e => {
    if(!e.shiftKey || !SITE.sun.on || SITE.sun.form !== 'now' || SITE.mode !== 'site') return;
    const d = dOf(e); if(!d) return;
    e.preventDefault(); e.stopPropagation();                               // 지도 확대·축소 대신 시각을
    stepNow(d > 0 ? 1 : -1, false);
  }, { passive:false, capture:true });
})();

/* ============================================================
   4. 요약 JSON → AI 해설
   ============================================================ */
function contextSummary(){
  if(!hasRef()) return null;
  const siteM = SITE.geom ? mapRings(SITE.geom, toM) : [];
  const area = SITE.geom ? multiArea(siteM) : 0;
  const bfc = VW.data.building_kr, zfc = VW.data.zone;
  const near = [];
  if(bfc) for(const f of bfc.features){
    const fl = floorsOf(f.properties); const mp = asMulti(f.geometry); if(!mp.length) continue;
    const c = centroidOf([[mp[0][0].map(toM)]]);
    const d = Math.hypot(c[0], c[1]);
    if(inFocus(c)) near.push({ floors:fl, d, bearing:(Math.atan2(c[0], c[1]) * 180 / Math.PI + 360) % 360 });
  }
  const fl = near.map(b => b.floors).filter(Boolean);
  const bandsN = { '1~3층':0, '4~7층':0, '8~15층':0, '16층 이상':0 };
  for(const v of fl) bandsN[v <= 3 ? '1~3층' : v <= 7 ? '4~7층' : v <= 15 ? '8~15층' : '16층 이상']++;
  const tall = near.filter(b => b.floors >= 10).sort((a, b) => a.d - b.d).slice(0, 5)
    .map(b => ({ floors:b.floors, distance_m:Math.round(b.d), direction:dir16(b.bearing) }));
  let zone = null;
  if(zfc){ const z = zfc.features.find(f => pointInMulti(SITE.center, asMulti(f.geometry))); if(z) zone = zoneName(z.properties); }
  const r = SITE.sun.result;
  return {
    site: !SITE.geom ? { kind:'none', note:'대지를 정하지 않고 화면 범위 전체를 분석했습니다 (기준점: 화면 중심)', center:{lat:+SITE.center[1].toFixed(6), lng:+SITE.center[0].toFixed(6)}, zoning:zone } : { kind: SITE.shape ? SITE.shape.kind : 'parcel', parcels: SITE.shape ? [SITE.shape.label] : SITE.parcels.map(pName), area_m2:Math.round(area), center:{lat:+SITE.center[1].toFixed(6), lng:+SITE.center[0].toFixed(6)}, zoning:zone },
    context: { analysis_range:rangeLabel(), radius_from_site_edge_m: SITE.range === 'radius' ? SITE.radius : null, analysis_extent_radius_m:focusR(), existing_buildings_on_site_excluded:SITE.exclude, buildings:near.length, avg_floors: fl.length ? +(fl.reduce((a, b) => a + b, 0) / fl.length).toFixed(1) : null,
               max_floors: fl.length ? Math.max(...fl) : null, floor_bands:bandsN, tall_buildings_nearby:tall },
    traffic: (typeof trafficSummary === 'function') ? trafficSummary() : null,
    transit: (typeof transitSummary === 'function') ? transitSummary() : null,
    commerce: (typeof commerceSummary === 'function') ? commerceSummary() : null,
    people: (typeof peopleSummary === 'function') ? peopleSummary() : null,
    hub_network: (typeof HUB !== 'undefined' && HUB.on) ? HUB.summary || null : null,
    wind: (typeof windSummary === 'function') ? windSummary() : null,
    living_area_15min: (typeof lifeSummary === 'function') ? lifeSummary() : null,
    tourism_culture: (typeof tourSummary === 'function') ? tourSummary() : null,
    sun_at_time: SITE.sun.now ? { date:SITE.sun.now.day, clock_time_kst:fmtH(SITE.sun.now.clock), solar_time:fmtH(SITE.sun.now.solar), sun_altitude:SITE.sun.now.alt, sun_azimuth:SITE.sun.now.az, site_shaded_pct:SITE.sun.now.site_shaded_pct, casters:SITE.sun.now.casters } : null,
    sun: r ? { date:r.date, window_solar_time:`${fmtH(r.from)}–${fmtH(r.to)}`, step_min:r.step, floor_height_m:S.bldFH, ...r.stats, main_obstructions:r.obstructions } : null,
    note: '수치는 클린 맵이 브이월드 건물 층수·OSM 도로망·TAGO 버스·소상공인 상가정보·태양 위치 계산으로 구한 값입니다. '
  };
}

function aiConfig(){
  let key = '', model = '';
  try{ key = localStorage.getItem('cleanmapAiKey') || ''; model = localStorage.getItem('cleanmapAiModel') || ''; }catch(e){}
  return { key: key || AI_DEFAULT_KEY, model: model || AI_DEFAULT_MODEL };
}
$('aisavekey').addEventListener('click', () => {
  try{ localStorage.setItem('cleanmapAiKey', $('aikey').value.trim()); localStorage.setItem('cleanmapAiModel', $('aimodel').value.trim()); }catch(e){}
  toast('AI 연결 설정을 저장했습니다');
});
try{ $('aikey').value = localStorage.getItem('cleanmapAiKey') || ''; $('aimodel').value = localStorage.getItem('cleanmapAiModel') || ''; }catch(e){}

const AI_SYSTEM = `당신은 한국 건축설계사무소의 대지분석 담당자입니다. 아래 JSON은 프로그램이 공공데이터와 지도 데이터로 계산한 값입니다.
들어올 수 있는 항목: site(대지), context(주변 건물), traffic(도로 위계·접도·통과 잠재량·측정 지점), transit(버스), commerce(상가), people(인구·사업체), sun / sun_at_time(일조). 없는 항목은 분석하지 않은 것이니 언급하지 마세요.

해석 요령:
- 통과 잠재량 근거리(800m)는 동네 안 짧은 이동이 몰리는 길, 광역(2km)은 지나가는 차량이 몰리는 길입니다. 대지 앞 도로가 근거리에서 높고 광역에서 낮으면 "동네의 길", 반대면 "통과 교통의 길"입니다.
- people.worker_to_resident 가 1보다 크면 낮에 일하러 오는 사람이 많은 동네, 작으면 주거 중심 동네입니다.
- 상가 밀집지와 통과 잠재량 상위 가로가 어긋나는 곳, 정류장 도보권 밖의 사각지대, 노선 축과 대지 사이 거리처럼 두 가지 이상을 엮은 해석을 synthesis 에 쓰세요.
- site.kind 가 none 이면 대지 없이 범위 전체를 본 것이니 "대지"를 지어내지 말고 범위 전체의 특성으로 쓰세요.

규칙:
- JSON에 있는 수치만 근거로 쓰고, 없는 수치·지명·규제·도로 이름을 지어내지 마세요. 모르는 것은 "확인 필요"로 적으세요.
- estimated:true 이거나 "추정"이라 적힌 값은 문장에 추정이라고 밝히세요. 매출·유동인구·배차간격·교통량 숫자처럼 JSON에 없는 수치는 절대 만들지 마세요. 도로 폭이 추정값이면 법정 접도 여부를 단정하지 마세요.
- 각 문장은 "관찰 → 설계 함의" 순서로, 짧고 단정하게. 발표 판에 그대로 올릴 수 있는 문체로.
- diagram_ideas 의 layers 에는 다음 이름만 쓰세요: 도로 위계, 통과 잠재량 근거리, 통과 잠재량 광역, 접도, 버스 노선 축, 정류장 도보권, 상가 밀도, 업종별 상가, 인구 분포, 종사자 분포, 평균 연령, 주간/야간, 교통량 측정 지점, 일조 그림자.
- 반드시 아래 JSON 형식으로만 답하세요. 다른 말은 붙이지 마세요.
{"headline":"한 줄 요약","sections":[{"topic":"교통·가로망","findings":["관찰 → 함의"]}],"synthesis":["두 가지 이상을 엮은 해석"],"design_hints":["설계 시사점"],"diagram_ideas":[{"title":"다이어그램 제목","layers":["상가 밀도","통과 잠재량 근거리"],"why":"이 조합으로 보여줄 것"}],"caveats":["한계·확인 필요 사항"]}`;

$('airun').addEventListener('click', async () => {
  if(typeof flowCompare === 'function' && TR.on && TR.ways){
    $('ainote').textContent = '통과 잠재량 근거리·광역 비교 계산 중…';
    try{ await flowCompare(); }catch(e){ console.warn(e); }
  }
  const sum = contextSummary();
  if(!sum){ toast('먼저 대지를 정하거나 화면 범위를 고정하세요'); return; }
  const { key, model } = aiConfig();
  if(!key){ $('ainote').textContent = 'AI 키가 없습니다. 제목 "클린 맵"을 Shift+클릭해 관리자 설정을 열고 키를 넣으세요.'; return; }
  if(SITE.ai.busy) return;
  SITE.ai.busy = true; SITE.ai.summary = sum;
  const btn = $('airun'); btn.disabled = true; btn.textContent = '해설 만드는 중…';
  try{
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method:'POST',
      headers:{ 'content-type':'application/json', 'x-api-key':key, 'anthropic-version':'2023-06-01',
                'anthropic-dangerous-direct-browser-access':'true' },
      body: JSON.stringify({ model, max_tokens:3500, system:AI_SYSTEM,
        messages:[{ role:'user', content:'대지분석 데이터:\n' + JSON.stringify(sum, null, 1) }] })
    });
    const data = await res.json();
    if(!res.ok) throw new Error((data.error && data.error.message) || ('HTTP ' + res.status));
    const text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n');
    const clean = text.replace(/```json|```/g, '').trim();
    let parsed; try{ parsed = JSON.parse(clean); }catch(e){ parsed = { headline:'', findings:[{title:'해설', body:clean}], design_hints:[], caveats:[] }; }
    SITE.ai.text = clean; SITE.ai.md = toMarkdown(parsed, sum);
    renderAI(parsed);
    $('ainote').textContent = '수치는 계산값, 문장은 AI가 쓴 것입니다. 발표 전에 한 번 읽고 손보세요.';
  }catch(err){
    $('ainote').textContent = '해설 실패 — ' + err.message;
  }
  SITE.ai.busy = false; btn.disabled = false; btn.textContent = 'AI 해설 만들기';
});
function renderAI(p){
  const li = arr => (arr || []).map(x => `<li>${esc(x)}</li>`).join('');
  let h = p.headline ? `<h4>${esc(p.headline)}</h4>` : '';
  for(const sct of p.sections || []) h += `<h4>${esc(sct.topic || '')}</h4><ul>${li(sct.findings)}</ul>`;
  for(const f of p.findings || []) h += `<h4>${esc(f.title || '')}</h4><div>${esc(f.body || '')}</div>`;
  if(p.synthesis && p.synthesis.length) h += `<h4>종합</h4><ul>${li(p.synthesis)}</ul>`;
  if(p.design_hints && p.design_hints.length) h += `<h4>설계 시사점</h4><ul>${li(p.design_hints)}</ul>`;
  if(p.diagram_ideas && p.diagram_ideas.length) h += `<h4>다이어그램 제안</h4><ul>${p.diagram_ideas.map(d => `<li><b>${esc(d.title || '')}</b> — ${esc((d.layers || []).join(' + '))}<br>${esc(d.why || '')}</li>`).join('')}</ul>`;
  if(p.caveats && p.caveats.length) h += `<h4>확인 필요</h4><ul>${li(p.caveats)}</ul>`;
  $('aiout').innerHTML = h; $('aiout').hidden = false; $('aitools').hidden = false;
}
function toMarkdown(p, sum){
  const L = [], st = sum.site || {};
  L.push('# 대지분석 해설', '');
  if(st.kind === 'none') L.push(`범위: ${sum.context && sum.context.analysis_range || ''} (대지 없이 범위 전체)`, '');
  else L.push(`대지: ${(st.parcels || []).join(', ')} · ${(st.area_m2 || 0).toLocaleString()} ㎡` + (st.zoning ? ` · ${st.zoning}` : '') + ` · 범위 ${sum.context && sum.context.analysis_range || ''}`, '');
  if(p.headline) L.push(`**${p.headline}**`, '');
  for(const sct of p.sections || []){ L.push(`## ${sct.topic || ''}`); (sct.findings || []).forEach(x => L.push('- ' + x)); L.push(''); }
  for(const f of p.findings || []) L.push(`## ${f.title || ''}`, f.body || '', '');
  const list = (t, a) => { if(a && a.length){ L.push('## ' + t); a.forEach(x => L.push('- ' + x)); L.push(''); } };
  list('종합', p.synthesis); list('설계 시사점', p.design_hints);
  if(p.diagram_ideas && p.diagram_ideas.length){ L.push('## 다이어그램 제안'); p.diagram_ideas.forEach(d => L.push(`- **${d.title}** — ${(d.layers || []).join(' + ')}: ${d.why || ''}`)); L.push(''); }
  list('확인 필요', p.caveats);
  L.push('---', '```json', JSON.stringify(sum, null, 2), '```');
  return L.join('\n');
}
$('aicopy').addEventListener('click', async () => { try{ await navigator.clipboard.writeText(SITE.ai.md); toast('해설을 복사했습니다'); }catch(e){ toast('복사 실패'); } });
$('aisave').addEventListener('click', () => { if(SITE.ai.md) download(stamp() + '_대지분석해설.md', SITE.ai.md, 'text/markdown'); });
$('aijson').addEventListener('click', () => { const s = contextSummary(); if(s) download(stamp() + '_대지분석요약.json', JSON.stringify(s, null, 2), 'application/json'); });

/* ============================================================
   5. 내보내기 — 지도 꾸미기 모드의 버튼을 그대로 누릅니다
   ============================================================ */
$('stsvg').addEventListener('click', () => $('svg').click());
$('stdxf').addEventListener('click', () => $('dxf').click());

/* 지도가 준비된 뒤에 클릭을 잇습니다 */
(function hookMap(){
  if(typeof map === 'undefined' || !map){ setTimeout(hookMap, 300); return; }
  map.on('click', onMapClick);
  map.on('error', onMapError);
  // 그래픽 메모리가 모자라 화면이 날아가면(WebGL 컨텍스트 손실) 지형을 끄고 다시 그립니다
  map.on('webglcontextlost', () => { if(SITE.view3d) disable3dHard('그래픽 메모리가 부족해 3D 지형을 껐습니다 — 범위를 좁히거나 지형 없이 써 주세요'); });
  map.on('webglcontextrestored', () => { apply(); });
  map.on('mousedown', onDown);
  map.on('mousemove', onMove);
  map.on('mouseup', onUp);
  window.addEventListener('keydown', e => { if(e.key === 'Escape' && SITE.picking) stopPick(); });
})();


/* ============================================================
   다이어그램 범례·방위 — SVG 내보내기에 붙습니다 (대지분석 모드에서만)
   분석 레이어 이름 "분석_묶음_순번_설명" 을 읽어 묶음별로 정리합니다.
   ============================================================ */
const LEGEND_GROUP = { '도로위계':'도로 위계', '통과잠재량':'통과 잠재량 (추정)', '버스노선축':'버스 노선 축 (지나는 노선 수)',
  '버스정류장':'버스 정류장', '최근접정류장':'가장 가까운 정류장', '상가':'상가 업종', '접도':'접도',
  '교통량측정지점':'교통량 측정 지점', '인구밀도':'인구 밀도', '종사자밀도':'종사자 밀도', '평균연령':'평균 연령', '주간야간성격':'주간/야간 (종사자÷인구)', '행정동경계':'행정동 경계', '상가밀도':'상가 밀도', '인구분포':'인구 분포 (추정)', '종사자분포':'종사자 분포 (추정)', '정류장도보권':'정류장 도보권', '상권거점':'상권 거점', '인구거점':'인구 거점 (추정)', '종사자거점':'종사자 거점 (추정)', '상권거점경계':'상권 거점 영향권', '인구거점경계':'인구 거점 영향권', '통과잠재량축':'통과 축 (추정)', '통과위계':'통과 잠재량 (굵기 = 도로 위계)', '보행등시선':'보행 등시선', '근거리광역차이':'근거리·광역 차이 (추정)', '대중교통사각지대':'대중교통 사각지대', '업종다양성':'업종 다양성 (점 크기 = 상가 수)', '1층가로활성도':'1층 가로 활성도', '인구도트':'인구', '종사자도트':'종사자', '거점연결망':'거점 연결망', '거점':'거점', '바람장미':'바람장미 (풍속 m/s, 불어오는 방향)', '상권영역':'상권 영역', '생활권':'15분 생활권 (보행)', '생활시설':'생활 시설 (15분 안)', '관광문화':'관광·문화 자원', '관광문화거점':'관광·문화 거점', '바람길':'바람길 (주풍향)', '통과결절점':'통과 결절점 (추정)', '종사자거점경계':'종사자 거점 영향권', '정류장도보권경계':'도보권 경계', '일영':'누적 음영', '그림자':'그림자', '대지':'대지', '반경':'분석 범위', '일영_범위':'일조 분석 범위', '단면선':'단면선' };
function siteLegendSVG(W, H){
  if(SITE.mode !== 'site' || !$('stlegend') || !$('stlegend').checked) return '';
  const groups = new Map();
  for(const [id, d] of EXTRA.layers){
    if(d.type === 'symbol' || !d.fc || !d.fc.features.length) continue;
    if(/_(강조띠|바탕|세부)$/.test(d.label || '') || id === 'wind-compass') continue;               // 보조 레이어는 범례에서 뺍니다
    if(S.vis && S.vis[id] === false) continue;
    const parts = String(d.label || '').replace(/^분석_/, '').split('_');
    let g = parts[0], rest = parts.slice(1).filter(x => !/^\d+$/.test(x)).join(' ');
    if(g === '일영' && /범위/.test(rest)){ g = '일영_범위'; rest = ''; }
    if(g === '반경') rest = rangeLabel();
    const name = LEGEND_GROUP[g] || g;
    if(!groups.has(name)) groups.set(name, []);
    groups.get(name).push({ text: rest.replace(/(\d)h이상/, '$1시간 이상').replace(/%$/, '') + (/^(상위|하위|\d+–\d+)/.test(rest) && !/%/.test(rest) && g === '통과잠재량' ? '%' : ''), svg:d.svg || {} });
  }
  // 건물 용도별 색을 켰으면 용도 견본도 범례에
  if(typeof useActive === 'function' && useActive() && S.on.building_kr !== false){
    const items = useCounts().filter(([n]) => USE_ON.has(n)).map(([n]) => ({ text:n, svg:{ kind:'fill', fill:useColor(n) } }));
    if(items.length) groups.set('건물 용도', items);
  }
  if(!groups.size) return '';
  const singles = [], rows = [];
  for(const [g, items] of groups){
    if(items.length === 1 && !items[0].text){ singles.push({ text:g, svg:items[0].svg }); continue; }   // 한 줄짜리는 이름과 견본을 한 줄에, 맨 위로
    rows.push({ head:g }); for(const it of items) rows.push(it);
  }
  rows.unshift(...singles);
  const LH = 13, pad = 8, boxW = 170, boxH = pad * 2 + rows.length * LH;
  const x0 = W - boxW - 14, y0 = H - boxH - 30;
  const out = [`<g id="범례" data-layer="legend" font-family="'Noto Sans CJK KR','Malgun Gothic','Apple SD Gothic Neo',sans-serif">`,
    `<rect x="${x0}" y="${y0}" width="${boxW}" height="${boxH}" fill="${ST().paper}" fill-opacity="0.92" stroke="${ST().ink}" stroke-width="0.4"/>`];
  rows.forEach((r, i) => {
    const y = y0 + pad + i * LH + 9;
    if(r.head){ out.push(`<text x="${x0 + pad}" y="${y}" font-size="9" font-weight="bold" fill="${ST().ink}">${esc(r.head)}</text>`); return; }
    const sx = x0 + pad + 4, s = r.svg;
    if(s.kind === 'fill') out.push(`<rect x="${sx}" y="${y - 7}" width="16" height="8" fill="${s.fill}"${s.opacity != null && s.opacity < 1 ? ` fill-opacity="${s.opacity}"` : ''}/>`);
    else out.push(`<path d="M${sx} ${y - 3}H${sx + 16}" stroke="${s.stroke}" stroke-width="${Math.min(s.width || 1, 5)}"${s.dash ? ` stroke-dasharray="${s.dash.map(v => v * Math.max(1, s.width || 1)).join(' ')}"` : ''} fill="none"/>`);
    out.push(`<text x="${sx + 22}" y="${y}" font-size="8.5" fill="${ST().ink}" fill-opacity="0.8">${esc(r.text || '')}</text>`);
  });
  out.push('</g>');
  SITE.legendBox = { x0, y0, w:boxW, h:boxH };                       // 방위·축척을 오른쪽 아래에 둘 때 이 위로 비킵니다
  return out.join('');
}

/* 거점 원 세분화 */
$('stgrain').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  SITE.peakGrain = b.dataset.v; segSync('stgrain', SITE.peakGrain);
  if(typeof registerBizLayers === 'function') registerBizLayers();
  if(typeof registerPopLayers === 'function') registerPopLayers();
  if(typeof registerTrafficLayers === 'function') registerTrafficLayers();
  apply();
  if(typeof summarizeBiz === 'function') summarizeBiz();
});
segSync('stgrain', SITE.peakGrain);

/* 원 투명도 — 거점 원·교통 결절점·정류장 도보권에 함께 적용 */
const CA = () => (SITE.circleAlpha == null ? 0.7 : SITE.circleAlpha);
$('stalpha').addEventListener('input', e => {
  SITE.circleAlpha = +e.target.value; $('stalphav').textContent = Math.round(SITE.circleAlpha * 100) + '%';
  clearTimeout(SITE._at); SITE._at = setTimeout(() => {
    if(typeof registerBizLayers === 'function') registerBizLayers();
    if(typeof registerPopLayers === 'function') registerPopLayers();
    if(typeof registerTrafficLayers === 'function') registerTrafficLayers();
    if(typeof registerBusLayers === 'function') registerBusLayers();
    if(typeof registerHubLayers === 'function') registerHubLayers();
    apply();
  }, 120);
});

/* ---------- 색 바꾸기 칸 ---------- */
function currentColor(k){
  const st = ST();
  if(k === 'flowBase') return st.flow[4];
  if(k === 'roadBase') return st.road[1];
  if(k === 'shadowBase') return st.shadow[st.shadow.length - 1];
  return st[k] || '#000000';
}
const colorRow = (k, n) => `<label class="row" style="justify-content:space-between;align-items:center;font-size:12px;margin:3px 0">
    <span>${n}${(COLOR_OV[SITE.style] || {})[k] ? ' <b style="color:var(--blue)">•</b>' : ''}</span><input type="color" data-k="${k}" value="${currentColor(k)}" style="width:44px;height:22px;border:1px solid var(--rule);padding:0;background:none"></label>`;
function renderCardColors(){
  const names = Object.fromEntries(COLOR_KEYS);
  document.querySelectorAll('.cardcolors').forEach(box => {
    const keys = (box.dataset.keys || '').split(',').filter(Boolean);
    box.innerHTML = '<div style="font-size:11.5px;color:var(--ink-soft);margin-bottom:2px">색 (지금 스타일)</div>' + keys.map(k => { const [kk, label] = k.split(':'); return colorRow(kk, label || names[kk] || kk); }).join('');
  });
}
function renderColorPickers(){
  renderCardColors();
  renderStyleCards();                                   // 바꾼 색이 미리보기에도
  const box = $('stcolors'); if(!box) return;
  box.innerHTML = COLOR_KEYS.map(([k, n]) => `<label class="row" style="justify-content:space-between;align-items:center;font-size:12px;margin:3px 0">
    <span>${n}${(COLOR_OV[SITE.style] || {})[k] ? ' <b style="color:var(--blue)">•</b>' : ''}</span><input type="color" data-k="${k}" value="${currentColor(k)}" style="width:44px;height:22px;border:1px solid var(--rule);padding:0;background:none"></label>`).join('');
}
let colorTimer = null;
function redrawAll(){
  registerSiteLayers(); registerSunLayers();
  for(const f of ['registerTrafficLayers', 'registerBusLayers', 'registerBizLayers', 'registerKictLayers', 'registerPopLayers', 'register3d', 'registerHubLayers', 'registerWindLayers', 'registerLifeLayers', 'registerTourLayers']) if(typeof window[f] === 'function') window[f]();
  apply();
}
function onColorInput(e){
  const k = e.target.dataset && e.target.dataset.k; if(!k || e.target.type !== 'color') return;
  (COLOR_OV[SITE.style] = COLOR_OV[SITE.style] || {})[k] = e.target.value;
  try{ localStorage.setItem('cleanmapColorOv', JSON.stringify(COLOR_OV)); }catch(err){}
  invalidateST();
  clearTimeout(colorTimer); colorTimer = setTimeout(() => { redrawAll(); renderColorPickers(); }, 150);
}
$('stcolors').addEventListener('input', onColorInput);
document.addEventListener('input', e => { if(e.target.closest && e.target.closest('.cardcolors')) onColorInput(e); });
/* 그림자 투명도 */
$('sunalpha').addEventListener('input', e => {
  SITE.shadowAlpha = +e.target.value; $('sunalphav').textContent = Math.round(SITE.shadowAlpha * 100) + '%';
  clearTimeout(SITE._sa); SITE._sa = setTimeout(() => { registerSunLayers(); apply(); }, 100);
});
$('stcolorreset').addEventListener('click', () => {
  delete COLOR_OV[SITE.style];
  try{ localStorage.setItem('cleanmapColorOv', JSON.stringify(COLOR_OV)); }catch(err){}
  invalidateST(); redrawAll(); renderColorPickers(); toast('이 스타일의 색을 원래대로 돌렸습니다');
});
$('stcolorcopy').addEventListener('click', async () => {
  const out = { style:SITE.style, colors:COLOR_OV[SITE.style] || {} };
  try{ await navigator.clipboard.writeText(JSON.stringify(out, null, 2)); toast('바꾼 색을 JSON으로 복사했습니다'); }catch(e){ toast('복사 실패'); }
});
renderColorPickers();

/* ============================================================
   3D 매스 보기 — 브이월드 건물을 층수 × 층고로 세워 스케치업 같은 흰 매스로
   분석 레이어(축·원·등고)는 바닥에 깔린 채로 함께 보입니다.
   ============================================================ */
SITE.view3d = false;
function massColors(){
  const st = ST(), dark = (() => { const c = st.paper.replace('#', ''); return (parseInt(c.slice(0, 2), 16) + parseInt(c.slice(2, 4), 16) + parseInt(c.slice(4, 6), 16)) / 3 < 110; })();
  // 화면 3D는 모서리선을 그릴 수 없어서, 매스 색이 바탕과 거의 같으면(흰 매스 + 흰 바탕) 보이지 않습니다.
  // 그럴 때만 바탕에서 조금 떨어진 색으로 바꿔 씁니다 (축측 SVG 는 고른 색 그대로).
  const lum = h => { const c = h.replace('#', ''); return 0.299 * parseInt(c.slice(0, 2), 16) + 0.587 * parseInt(c.slice(2, 4), 16) + 0.114 * parseInt(c.slice(4, 6), 16); };
  let m = st.mass;
  if(Math.abs(lum(m) - lum(st.paper)) < 22) m = dark ? hexMix(st.paper, '#FFFFFF', 0.28) : hexMix(st.paper, st.ink, 0.1);
  return { mass:m, site:st.site, edge:hexMix(st.paper, st.ink, dark ? 0.55 : 0.35) };
}
function register3d(){
  extraRemove('d3-');
  if(!SITE.view3d || SITE.mode !== 'site') return;
  const fc = VW.data && VW.data.building_kr;
  if(!fc || !fc.features.length){ setStatus('3D: 건물_국내를 아직 받지 못했습니다 — 줌 15 이상으로 확대하세요'); return; }
  const fh = S.bldFH || 3, mc = massColors();
  const useOn = typeof useActive === 'function' && useActive();       // 켠 용도만 용도 색, 나머지는 매스 색
  const feats = [];
  for(const f of fc.features){
    const fl = floorsOf(f.properties) || 1;
    const u = useOn ? useHi(f.properties) : null;
    feats.push({ type:'Feature', properties:useOn ? { h:fl * fh, c:u ? useColor(u) : mc.mass } : { h:fl * fh }, geometry:f.geometry });
  }
  extraSet('d3-mass', { label:'분석_3D매스', stage:'fill', type:'fill-extrusion', nomerge:true,   // 거점 원·결절점(선·위 단계)이 매스 위에 보이도록
    fc:{ type:'FeatureCollection', features:feats },
    paint:{ 'fill-extrusion-color':useOn ? ['get', 'c'] : mc.mass, 'fill-extrusion-height':['get', 'h'], 'fill-extrusion-base':0,
            'fill-extrusion-opacity':0.96, 'fill-extrusion-vertical-gradient':true },
    svg:{ kind:'fill', fill:mc.mass, opacity:1 } });
  // 바닥 윤곽선 — 매스가 서는 자리를 또렷하게
  extraSet('d3-foot', { label:'분석_3D매스바닥_세부', stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:fc.features.map(f => ({ type:'Feature', properties:{}, geometry:{ type:'MultiLineString', coordinates:asMulti(f.geometry).map(poly => poly[0]) } })) },
    paint:{ 'line-color':mc.edge, 'line-width':0.6 }, svg:{ kind:'line', stroke:mc.edge, width:0.4 } });
}
function dropTerrain(){ try{ if(map && map.getTerrain && map.getTerrain()) map.setTerrain(null); }catch(e){} }
function set3d(on){
  if(!on) dropTerrain();
  SITE.view3d = on;
  $('st3d').checked = on;
  if(map && map.setLight) try{ map.setLight({ anchor:'viewport', color:'#FFFFFF', intensity:0.45, position:[1.4, 210, 40] }); }catch(e){}
  register3d(); apply();                                    // 매스부터 (지형 없이)
  if(!on){ if(map) map.easeTo({ pitch:0, bearing:0, duration:500 }); }
  else{
    // 지형은 매스 스타일이 다 그려지고, 기울이기가 끝난 뒤에 켭니다.
    // (스타일을 바꾸는 중에 지형을 같이 넣으면 지도 엔진이 그리기를 멈춰 화면이 하얘집니다)
    const idle = () => new Promise(res => { let done = false; const f = () => { if(!done){ done = true; res(); } }; setTimeout(() => { map.once('idle', f); setTimeout(f, 5000); }, 30); });
    const moved = () => new Promise(res => { let done = false; const f = () => { if(!done){ done = true; res(); } }; map.once('moveend', f); setTimeout(f, 2000); });
    (async () => {
      await idle();
      if(!SITE.view3d) return;
      map.easeTo({ pitch:58, bearing:map.getBearing() || -18, duration:700 });
      await moved(); await idle();
      if(SITE.view3d && SITE.terrain) applyTerrain();
    })();
  }
  $('st3dnote').textContent = on ? '오른쪽 버튼(또는 Ctrl+드래그)으로 돌리고 기울일 수 있습니다. SVG는 지금 구도 그대로(입체 매스·지형 포함) 나가고, DXF는 평면으로 나갑니다.' : '';
}
$('st3d').addEventListener('change', e => set3d(e.target.checked));

let LAST_BLD = null;
let HUB_KEY = '';
function beforeBuildStyle(){
  // 거점 연결망: 바탕이 되는 분석이 바뀌었을 때만 다시 계산
  if(typeof HUB !== 'undefined' && HUB.on){
    const k = [BIZ.items && BIZ.items.length, BIZ.form, POP.dongs && POP.dongs.length, POP.form, TR.nodes && TR.nodes.length, BUS.stops && BUS.stops.length, BUS.wide && BUS.wide.stops.length, SITE.peakGrain, SITE.style, LOC && LOC.lng, BIZ.on, POP.on, TR.on, BUS.on].join('|');
    if(k !== HUB_KEY){ HUB_KEY = k; registerHubLayers(); }
  }
  if(!SITE.view3d) return;
  const fc = VW.data && VW.data.building_kr;
  if(fc && fc !== LAST_BLD){ LAST_BLD = fc; register3d(); }
}

/* ---------- 3D 지형 — 등고선에 쓰는 것과 같은 표고 타일(Terrarium)을 지형으로 ---------- */
SITE.terrain = true; SITE.exag = 1.3; SITE.terrainOK = null;   // null: 아직 확인 전 · true: 표고 타일 정상 · false: 못 받음
/* 지형은 표고 타일이 실제로 받아지는 걸 확인한 뒤에만 켭니다.
   표고 타일이 안 오면 지도 엔진이 아무것도 그리지 못해 화면이 하얗게 되기 때문입니다. */
async function checkTerrain(){
  if(SITE.terrainOK !== null) return SITE.terrainOK;
  try{
    const c = map.getCenter(), z = 12, n = 2 ** z;
    const x = Math.floor((c.lng + 180) / 360 * n), r = c.lat * Math.PI / 180;
    const y = Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n);
    const t = await fetchDemTile(z, x, y);
    SITE.terrainOK = !!(t && t.length);
  }catch(e){ console.warn('[대지분석] 표고 타일 확인 실패', e); SITE.terrainOK = false; }
  return SITE.terrainOK;
}
function onMapError(e){
  // 지형 소스에서 오류가 나면 바로 지형을 끄고 매스만 남깁니다
  if(SITE.view3d && SITE.terrain && e && (e.sourceId === 'dem' || e.sourceId === 'demShade')){
    dropTerrain(); SITE.terrain = false; SITE.terrainOK = false; $('st3dterrain').checked = false;
    setStatus('지형 타일 오류로 지형을 껐습니다 — 매스만 보여줍니다', true); apply();
  }else if(SITE.view3d && e && e.error){
    console.warn('[대지분석] 3D 오류', e);
    setStatus('3D 표시 오류 — ' + esc(String(e.error.message || e.error).slice(0, 120)), true);   // 원인 파악용
  }
}
async function applyTerrain(){
  if(SITE.view3d && SITE.terrain){
    setStatus('지형(표고 타일) 확인 중…');
    const ok = await checkTerrain();
    if(!ok){
      dropTerrain(); SITE.terrain = false; $('st3dterrain').checked = false;
      setStatus('표고 타일을 받지 못해 지형 없이 매스만 보여줍니다', true);
    }else setStatus('3D · 지형 반영');
  }
  apply();
}

/* 하얀 화면 방지 — 지형을 켠 뒤 15초 안에 지도가 한 번도 다 그려지지 않으면 지형을 끕니다 */
function terrainWatch(){
  clearTimeout(SITE._tw);
  if(!(SITE.view3d && SITE.terrain && SITE.terrainOK === true) || !map) return;
  SITE._tw = setTimeout(() => {
    if(!(SITE.view3d && SITE.terrain)) return;
    dropTerrain(); SITE.terrain = false; $('st3dterrain').checked = false;
    setStatus('지형을 그리는 데 너무 오래 걸려 지형을 껐습니다 (그래픽 메모리 부족 가능) — 매스만 보여줍니다', true);
    apply();
  }, 15000);
  map.once('idle', () => clearTimeout(SITE._tw));
}
function disable3dHard(msg){
  SITE.terrain = false; $('st3dterrain').checked = false;
  setStatus(msg, true);
  try{ if(map.setTerrain) map.setTerrain(null); }catch(e){}
  apply();
}
function styleExtras(st){
  if(!SITE.view3d || !SITE.terrain || SITE.terrainOK !== true || SITE.mode !== 'site') return;
  setTimeout(terrainWatch, 0);
  // 표고 원자료가 약 30m 간격이라 z15 까지 확대해 쓰면 계단처럼 깨져 보입니다 — 한 단계 낮춰 부드럽게
  st.sources.dem = { type:'raster-dem', tiles:[DEM_URL], tileSize:256, encoding:'terrarium', maxzoom:13 };
  st.sources.demShade = { type:'raster-dem', tiles:[DEM_URL], tileSize:256, encoding:'terrarium', maxzoom:12 };
  st.terrain = { source:'dem', exaggeration:SITE.exag };
  // 지형의 굴곡이 보이도록 아주 옅은 음영 — 바닥 레이어 바로 위
  const dark = (() => { const c = ST().paper.replace('#', ''); return (parseInt(c.slice(0, 2), 16) + parseInt(c.slice(2, 4), 16) + parseInt(c.slice(4, 6), 16)) / 3 < 110; })();
  const shade = { id:'d3-hillshade', type:'hillshade', source:'demShade',
    paint:{ 'hillshade-shadow-color':dark ? '#000000' : '#8C8C88', 'hillshade-highlight-color':dark ? '#3A3D44' : '#FFFFFF',
            'hillshade-accent-color':dark ? '#000000' : '#9A9A96', 'hillshade-exaggeration':0.35, 'hillshade-illumination-direction':315 } };
  if(SITE.shade3d === false) return;
  shade.paint['hillshade-exaggeration'] = 0.22;
  const at = st.layers.findIndex(l => l.id === 'water');
  st.layers.splice(at >= 0 ? at + 1 : 1, 0, shade);
}
$('st3dterrain').addEventListener('change', e => { SITE.terrain = e.target.checked; if(!SITE.terrain) dropTerrain(); if(SITE.terrain && SITE.terrainOK === false) SITE.terrainOK = null; applyTerrain(); });
$('st3dshade').addEventListener('change', e => { SITE.shade3d = e.target.checked; apply(); });
$('st3dexag').addEventListener('input', e => { SITE.exag = +e.target.value; $('st3dexagv').textContent = SITE.exag.toFixed(1) + '배'; clearTimeout(SITE._ex); SITE._ex = setTimeout(apply, 150); });

/* ---------- 분석 이름표 켜고 끄기 ---------- */
SITE.labels = { all:true, front:true };
function siteLabelHidden(id){
  if(SITE.mode !== 'site') return false;
  if(!SITE.labels.all) return true;
  if(id === 'tr-front-label' && !SITE.labels.front) return true;
  return false;
}
$('stlabels').addEventListener('change', e => { SITE.labels.all = e.target.checked; apply(); });
$('trfrontlabel').addEventListener('change', e => { SITE.labels.front = e.target.checked; apply(); });

