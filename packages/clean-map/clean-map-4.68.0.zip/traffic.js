/* ============================================================
   교통·가로망 — site.js 다음에 읽힙니다.
   1) 도로 위계  2) 대지 접도 조건  3) 통과 잠재량(추정)
   도로망은 Overpass(OSM 원본)에서 받아 교차점 그래프로 만듭니다.
   ============================================================ */

const TR = { on:false, form:'hier', mode:'car', scope:800, hideBase:true, flowView:'diagram', under:'full',
             raw:null, rawKey:'', graph:null, res:null, front:null, busy:false, savedVis:null };

/* 도로 종류 → 위계(c), 설계속도(v km/h), 추정 폭(w m) */
/* 위계: 0 고속·자동차전용 / 1 주간선(국도·주요 시가로) / 2 보조간선 / 3 집산 / 4 국지 / 5 이면·서비스 / 6 보행 */
const HW = {
  motorway:{c:0,v:80,w:25}, motorway_link:{c:0,v:50,w:10},
  trunk:{c:1,v:70,w:25}, trunk_link:{c:1,v:40,w:10}, primary:{c:1,v:50,w:25}, primary_link:{c:1,v:35,w:10},
  secondary:{c:2,v:45,w:20}, secondary_link:{c:2,v:30,w:8},
  tertiary:{c:3,v:40,w:15}, tertiary_link:{c:3,v:30,w:8},
  unclassified:{c:4,v:30,w:8}, residential:{c:4,v:25,w:8}, living_street:{c:4,v:15,w:6},
  service:{c:5,v:15,w:6},
  pedestrian:{c:6,v:5,w:6,ped:true}, footway:{c:6,v:5,w:3,ped:true}, path:{c:6,v:5,w:2,ped:true}, steps:{c:6,v:3,w:2,ped:true}
};
const CLASS_NAME = ['고속·자동차전용', '주간선', '보조간선', '집산도로', '국지도로', '이면·서비스', '보행로'];
const NC = CLASS_NAME.length;
const TR_COLORS = {
  road:['#8A2B1E', '#111111', '#555555', '#8C8C8C', '#B4B4B4', '#D2D2D2', '#7FA870'],   // 고속은 적갈색으로 따로
  flow:['#FFE7A1', '#FDBB5A', '#F4873A', '#DD4F2A', '#A8231A'],
  front:'#E0782B'
};
const trStyle = () => ({ road:ST().road, flow:ST().flow, front:ST().front });
const OVERPASS = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter'];

/* ---------- UI ---------- */
$('tron').addEventListener('change', e => {
  TR.on = e.target.checked;
  $('tropts').hidden = !TR.on;
  $('card-tr').classList.toggle('on', TR.on);
  if(TR.on && hasRef()) runTraffic(); else { registerTrafficLayers(); applyBaseRoads(); apply(); }
});
$('trform').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  TR.form = b.dataset.v; segSync('trform', TR.form);
  $('trflowopts').hidden = TR.form !== 'flow';
  if(TR.form === 'flow' && !TR.res && TR.raw) runFlow(); else { registerTrafficLayers(); apply(); }
});
$('trmode').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  TR.mode = b.dataset.v; segSync('trmode', TR.mode); TR.res = null; TR.diff = null;
  if(TR.form === 'flow' && TR.raw) runFlow(); else if(TR.form === 'diff'){ registerTrafficLayers(); apply(); }
});
$('trscope').addEventListener('click', e => {
  const b = e.target.closest('button'); if(!b) return;
  TR.scope = +b.dataset.v; segSync('trscope', TR.scope); TR.res = null;
  if(TR.form === 'flow') runTraffic();
});
$('trbase').addEventListener('change', e => { TR.hideBase = e.target.checked; applyBaseRoads(); apply(); });
$('trrun').addEventListener('click', () => { TR.cache = {}; TR.raw = null; runTraffic(); });
segSync('trform', TR.form); segSync('trmode', TR.mode); segSync('trscope', TR.scope);

/* 분석 중에는 바탕 지도의 도로를 숨겨 겹침을 없앱니다 */
function applyBaseRoads(){
  const want = TR.on && TR.hideBase && SITE.mode === 'site' && hasRef();
  if(want && !TR.savedVis){
    TR.savedVis = { major:S.vis['road-major'], minor:S.vis['road-minor'] };
    S.vis['road-major'] = false; S.vis['road-minor'] = false;
  }else if(!want && TR.savedVis){
    for(const [k, id] of [['major', 'road-major'], ['minor', 'road-minor']]){
      if(TR.savedVis[k] === undefined) delete S.vis[id]; else S.vis[id] = TR.savedVis[k];
    }
    TR.savedVis = null;
  }
}
/* site.js 가 모드를 바꾸거나 대지를 바꿀 때 부릅니다 */
function trafficOnSiteChange(){
  TR.res = null; TR.front = null; TR.graph = null; TR.compare = null; TR.iso = null; TR.diff = null;
  extraRemove('tr-');
  if(typeof KT !== 'undefined' && KT.on && hasRef() && SITE.mode === 'site') runKict();
  if(SITE.mode !== 'site'){ applyBaseRoads(); return; }
  if(TR.on && hasRef()) runTraffic(); else applyBaseRoads();
}

/* ---------- 도로망 받기 ---------- */
/* OSM 서버가 응답하지 않을 때 — 지금 화면에 받아 둔 바탕 지도 타일의 도로를 씁니다.
   타일 경계에서 끊긴 선은 좌표를 0.5m 격자에 맞춰 이어 붙입니다 (교차점 판정용). */
const OMT_CLASS = { motorway:'motorway', trunk:'trunk', primary:'primary', secondary:'secondary', tertiary:'tertiary',
                    minor:'residential', service:'service', path:'footway', pedestrian:'pedestrian' };
/* 타일 도로 피처([{p, lines}]) → Overpass 와 같은 모양의 way 목록 */
function waysFromTileFeatures(feats, types, names){
  const want = types ? new Set(types) : null, nodeId = new Map(), out = [], seen = new Set();
  let nid = 1, wid = -1;
  const key = ([lng, lat]) => { const [x, y] = toM([lng, lat]); return Math.round(x * 2) + ',' + Math.round(y * 2); };
  for(const { p, lines } of feats){
    let hw = OMT_CLASS[p.class]; if(!hw) continue;
    if(p.class === 'path' && /steps/.test(p.subclass || '')) hw = 'steps';
    if(p.class === 'path' && /cycleway|bridleway/.test(p.subclass || '')) continue;
    if(p.ramp === 1 && ['motorway', 'trunk', 'primary', 'secondary', 'tertiary'].includes(hw)) hw += '_link';
    if(want && !want.has(hw)) continue;
    for(const ln of lines){
      if(ln.length < 2) continue;
      const sig = hw + '|' + key(ln[0]) + '|' + key(ln[ln.length - 1]) + '|' + ln.length;
      if(seen.has(sig)) continue; seen.add(sig);                       // 타일 여백 때문에 겹친 같은 선
      const nodes = ln.map(c => { const k = key(c); if(!nodeId.has(k)) nodeId.set(k, nid++); return nodeId.get(k); });
      // 이름 층과 꼭짓점이 여럿 겹칠 때만 이름을 붙입니다 (교차점 하나만 같으면 옆 도로 이름이 붙으므로)
      let nm = null;
      if(names){
        const cnt = new Map();
        for(const c of ln){ const hit = names.get(key(c)); if(hit){ const k = (hit.name || '') + '|' + (hit.ref || ''); cnt.set(k, { hit, n:((cnt.get(k) || {}).n || 0) + 1 }); } }
        let best = null; for(const v of cnt.values()) if(!best || v.n > best.n) best = v;
        if(best && best.n >= Math.max(2, Math.ceil(ln.length * 0.3))) nm = best.hit;
      }
      out.push({ type:'way', id:wid--, nodes, geometry:ln.map(([lon, lat]) => ({ lon, lat })),
        tags:{ highway:hw, ...(p.oneway === 1 ? { oneway:'yes' } : p.oneway === -1 ? { oneway:'-1' } : {}), ...(p.service ? { service:p.service } : {}),
               ...(nm && nm.name ? { name:nm.name } : {}), ...(nm && nm.ref ? { ref:nm.ref } : {}) } });
    }
  }
  return out;
}
const linesOf = g => g.type === 'LineString' ? [g.coordinates] : g.type === 'MultiLineString' ? g.coordinates : [];
function tileRoads(types){
  if(!map || !map.querySourceFeatures) return [];
  const feats = map.querySourceFeatures('omt', { sourceLayer:'transportation' }).map(f => ({ p:f.properties || {}, lines:linesOf(f.geometry) }));
  return waysFromTileFeatures(feats, types, null);
}

/* 화면과 관계없이 z14 지도 타일을 직접 받아 읽습니다 — 정적 파일이라 빠르고, 모든 도로가 들어 있습니다 */
const VT_CACHE = new Map();
/* opt: zMax(가장 자세한 줌, 기본 14) · zMin(가장 거친 줌, 기본 11) · maxTiles(기본 120) · progress(done, total, z)
   넓은 범위는 낮은 줌 타일을 씁니다 — 낮은 줌 타일은 큰 길만 들어 있고 모양도 이미 간소화돼 있습니다 */
async function hiResRoads(S0, W0, N0, E0, types, opt = {}){
  if(typeof VTLib === 'undefined' || typeof TILES === 'undefined') throw new Error('타일 해석기가 없습니다');
  const t2x = (lng, z) => Math.floor((lng + 180) / 360 * 2 ** z);
  const t2y = (lat, z) => { const r = lat * Math.PI / 180; return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 2 ** z); };
  const zLow = opt.zMin || 11, cap = opt.maxTiles || 120;
  let z = Math.min(14, opt.zMax || 14), xs, ys;
  for(;; z--){
    xs = [t2x(W0, z), t2x(E0, z)]; ys = [t2y(N0, z), t2y(S0, z)];
    if((xs[1] - xs[0] + 1) * (ys[1] - ys[0] + 1) <= cap || z <= zLow) break;    // (전에는 11에서 넘치면 10 으로 내려가며 11 의 번호를 써서 엉뚱한 타일을 받았음)
  }
  const tiles = [];
  for(let x = xs[0]; x <= xs[1]; x++) for(let y = ys[0]; y <= ys[1]; y++) tiles.push([z, x, y]);
  const feats = [], names = new Map();
  const key = ([lng, lat]) => { const [x, y] = toM([lng, lat]); return Math.round(x * 2) + ',' + Math.round(y * 2); };
  let done = 0;
  const one = async ([tz, tx, ty]) => {
    const k = tz + '/' + tx + '/' + ty;
    let vt = VT_CACHE.get(k);
    if(!vt){
      const url = TILES[0].replace('{z}', tz).replace('{x}', tx).replace('{y}', ty);
      const res = await fetch(url); if(!res.ok) throw new Error('타일 HTTP ' + res.status);
      vt = new VTLib.VectorTile(new VTLib.Protobuf(new Uint8Array(await res.arrayBuffer())));
      VT_CACHE.set(k, vt);
    }
    const L = vt.layers.transportation, N = vt.layers.transportation_name;
    if(L) for(let i = 0; i < L.length; i++){ const f = L.feature(i), gj = f.toGeoJSON(tx, ty, tz); feats.push({ p:f.properties, lines:linesOf(gj.geometry) }); }
    if(N) for(let i = 0; i < N.length; i++){
      const f = N.feature(i), pr = f.properties; if(!pr.name && !pr.ref) continue;
      for(const ln of linesOf(f.toGeoJSON(tx, ty, tz).geometry)) for(const c of ln) names.set(key(c), { name:pr['name:ko'] || pr.name, ref:pr.ref, cls:pr.class });
    }
    done++;
    if(opt.progress) opt.progress(done, tiles.length, tz); else $('trsum').textContent = `지도 타일 읽는 중 ${done}/${tiles.length} (z${tz})`;
  };
  for(let i = 0; i < tiles.length; i += 6) await Promise.all(tiles.slice(i, i + 6).map(one));   // 6장씩 동시에
  TR.tileZoom = z;
  return waysFromTileFeatures(feats, types, names);
}

/* 지도 타일의 물(water) 면 — 영역 ISO 의 바다·강·호수와 해안선용.
   hiResRoads 와 같은 줌·같은 타일을 고르므로 방금 도로를 받았으면 받아 둔 타일(VT_CACHE)을 그대로 씁니다.
   돌려주는 것: [{ cls:'ocean'|'lake'|'river'|…, mp:[경위도 MultiPolygon] }] */
async function tileWater(S0, W0, N0, E0, opt = {}){
  if(typeof VTLib === 'undefined' || typeof TILES === 'undefined') throw new Error('타일 해석기가 없습니다');
  const t2x = (lng, z) => Math.floor((lng + 180) / 360 * 2 ** z);
  const t2y = (lat, z) => { const r = lat * Math.PI / 180; return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 2 ** z); };
  const zLow = opt.zMin || 11, cap = opt.maxTiles || 120;
  let z = Math.min(14, opt.zMax || 14), xs, ys;
  for(;; z--){
    xs = [t2x(W0, z), t2x(E0, z)]; ys = [t2y(N0, z), t2y(S0, z)];
    if((xs[1] - xs[0] + 1) * (ys[1] - ys[0] + 1) <= cap || z <= zLow) break;
  }
  const tiles = [];
  for(let x = xs[0]; x <= xs[1]; x++) for(let y = ys[0]; y <= ys[1]; y++) tiles.push([z, x, y]);
  const out = [];
  const one = async ([tz, tx, ty]) => {
    const k = tz + '/' + tx + '/' + ty;
    let vt = VT_CACHE.get(k);
    if(!vt){
      const url = TILES[0].replace('{z}', tz).replace('{x}', tx).replace('{y}', ty);
      const res = await fetch(url); if(!res.ok) throw new Error('타일 HTTP ' + res.status);
      vt = new VTLib.VectorTile(new VTLib.Protobuf(new Uint8Array(await res.arrayBuffer())));
      VT_CACHE.set(k, vt);
    }
    const L = vt.layers.water;
    if(L) for(let i = 0; i < L.length; i++){
      const f = L.feature(i), g = f.toGeoJSON(tx, ty, tz).geometry;
      if(!g || f.properties.brunnel === 'tunnel') continue;                    // 땅속 물길은 빼고
      const mp = g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : null;
      if(mp) out.push({ cls:f.properties.class || 'water', mp });
    }
  };
  for(let i = 0; i < tiles.length; i += 6) await Promise.all(tiles.slice(i, i + 6).map(one));
  return out;
}

/* 넓은 범위는 3km 안팎의 조각으로 나눠 받습니다 — 공용 서버가 큰 요청을 504 로 끊기 때문 */
const OP_SLOW = new Set();              // 이번 실행에서 시간 초과난 서버는 뒤로
async function overpassOnce(q){
  let lastErr;
  const order = OVERPASS.filter(u => !OP_SLOW.has(u)).concat(OVERPASS.filter(u => OP_SLOW.has(u)));
  for(const url of order){
    for(let tryN = 0; tryN < 2; tryN++){
      try{
        const ac = new AbortController(), tm = setTimeout(() => ac.abort(), 20000);
        const res = await fetch(url, { method:'POST', body:'data=' + encodeURIComponent(q), signal:ac.signal,
          headers:{'Content-Type':'application/x-www-form-urlencoded'} }).finally(() => clearTimeout(tm));
        if(res.status === 429 || res.status === 504){ lastErr = new Error('HTTP ' + res.status + ' (서버 혼잡)'); await sleep(2000 * (tryN + 1)); continue; }
        if(!res.ok) throw new Error('HTTP ' + res.status);
        const js = await res.json();
        if(js.remark && /timed out|out of memory/i.test(js.remark) && !(js.elements || []).length) throw new Error('서버 처리 시간 초과');
        return js.elements || [];
      }catch(e){
        lastErr = (e.name === 'AbortError' || /abort/i.test(e.message)) ? new Error('응답 시간 초과 (20초)') : e;
        if(/시간 초과/.test(lastErr.message)) OP_SLOW.add(url);
        break;
      }
    }
  }
  throw new Error('OSM 서버 응답 없음 — ' + (lastErr && lastErr.message));
}
function bboxInView(S0, W0, N0, E0){
  if(!map || !map.getBounds) return false;
  const b = map.getBounds(), padX = (b.getEast() - b.getWest()) * 0.02, padY = (b.getNorth() - b.getSouth()) * 0.02;
  return W0 >= b.getWest() - padX && E0 <= b.getEast() + padX && S0 >= b.getSouth() - padY && N0 <= b.getNorth() + padY;
}
async function fetchRoads(R, types){
  const dLat = R / 110540, dLng = R / LOC.kx;
  const [lng, lat] = SITE.center;
  const S0 = lat - dLat, W0 = lng - dLng, N0 = lat + dLat, E0 = lng + dLng;
  // 1순위: z14 지도 타일을 직접 받아 읽기 (빠르고 안정적, 축척과 관계없이 모든 도로)
  try{
    const hr = await hiResRoads(S0, W0, N0, E0, types);
    if(hr.length){ TR.fromTiles = 'hires'; return (TR.raw = hr); }
  }catch(e){ console.warn('[대지분석] 타일 직접 읽기 실패', e); }
  // 2순위: 범위가 화면 안이면 지금 그려진 화면 타일
  if(bboxInView(S0, W0, N0, E0) || (SITE.range === 'view' && SITE.viewLL && R <= focusR() + 600)){
    const tr = tileRoads(types);
    if(tr.length){ TR.fromTiles = true; return (TR.raw = tr); }
  }
  const kinds = types || Object.keys(HW);
  const key = [S0, W0, N0, E0].map(v => v.toFixed(5)).join(',') + '|' + kinds.length;
  TR.cache = TR.cache || {};
  if(TR.cache[key]) return (TR.raw = TR.cache[key]);
  const n = Math.max(1, Math.ceil((2 * R) / (kinds.length > 10 ? 1200 : 3000)));   // 모든 도로면 1.2km, 간선만이면 3km 조각
  const byId = new Map();
  for(let j = 0; j < n; j++) for(let i = 0; i < n; i++){
    const s = S0 + (N0 - S0) * j / n, nn = S0 + (N0 - S0) * (j + 1) / n, w = W0 + (E0 - W0) * i / n, e = W0 + (E0 - W0) * (i + 1) / n;
    if(n > 1) $('trsum').textContent = `도로망 받는 중 · 조각 ${j * n + i + 1}/${n * n}`;
    const bb = [s, w, nn, e].map(v => v.toFixed(6)).join(',');
    const q = `[out:json][timeout:25];way["highway"~"^(${kinds.join('|')})$"](${bb});out tags geom qt;`;
    let els;
    try{ els = await overpassOnce(q); }
    catch(e){
      // 서버가 안 되면 화면 타일로 — 범위 전체가 화면에 들어와 있어야 합니다
      const tr = tileRoads(types);
      if(tr.length){ TR.fromTiles = true; $('trsum').textContent = '(OSM 서버 응답이 없어 화면 타일의 도로로 계산합니다)'; return (TR.raw = tr); }
      throw e;
    }
    for(const el of els) if(!byId.has(el.id)) byId.set(el.id, el);
  }
  TR.fromTiles = false;
  TR.cache[key] = [...byId.values()];
  return (TR.raw = TR.cache[key]);
}

/* ---------- 도로 정리: 종류·일방·폭 ---------- */
function wayInfo(el){
  const t = el.tags || {}, hw = HW[t.highway];
  if(!hw) return null;
  if(t.highway === 'service' && /parking_aisle|driveway|drive-through/.test(t.service || '')) return null;
  if(t.area === 'yes') return null;
  let w = parseFloat(t.width);
  if(!isFinite(w)){ const l = parseFloat(t.lanes); w = isFinite(l) ? l * 3.25 + 2 : hw.w; }
  const ow = t.oneway === 'yes' || t.oneway === '1' || t.oneway === 'true' || t.junction === 'roundabout' || t.highway === 'motorway' ? 1
           : t.oneway === '-1' ? -1 : 0;
  return { id:el.id, hw:t.highway, c:hw.c, v:hw.v, w, ped:!!hw.ped, oneway:ow,
           name:t.name || t.ref || '', ref:t.ref || '', nodes:el.nodes, pts:el.geometry.map(g => toM([g.lon, g.lat])) };
}

/* ---------- 교차점 그래프 ---------- */
function buildGraph(ways, mode){
  const use = ways.filter(w => mode === 'car' ? !w.ped : (w.c > 0 || w.ped));   // 보행: 고속·자동차전용은 뺍니다
  const cnt = new Map();
  for(const w of use){
    w.nodes.forEach((n, i) => cnt.set(n, (cnt.get(n) || 0) + ((i === 0 || i === w.nodes.length - 1) ? 2 : 1)));
  }
  const idx = new Map(), nodes = [];
  const nodeOf = (id, p) => { if(!idx.has(id)){ idx.set(id, nodes.length); nodes.push(p); } return idx.get(id); };
  const edges = [], out = [];
  for(const w of use){
    let start = 0;
    for(let i = 1; i < w.nodes.length; i++){
      if(cnt.get(w.nodes[i]) < 2 && i !== w.nodes.length - 1) continue;
      const pts = w.pts.slice(start, i + 1);
      let len = 0; for(let k = 1; k < pts.length; k++) len += Math.hypot(pts[k][0] - pts[k-1][0], pts[k][1] - pts[k-1][1]);
      if(len > 0.5){
        const a = nodeOf(w.nodes[start], w.pts[start]), b = nodeOf(w.nodes[i], w.pts[i]);
        const cost = mode === 'car' ? len / (w.v / 3.6) : len;
        const e = edges.length;
        edges.push({ a, b, len, cost, pts, way:w });
        const one = mode === 'car' ? w.oneway : 0;
        (out[a] = out[a] || []); (out[b] = out[b] || []);
        if(one >= 0) out[a].push({ to:b, e, cost });
        if(one <= 0) out[b].push({ to:a, e, cost });
      }
      start = i;
    }
  }
  for(let i = 0; i < nodes.length; i++) out[i] = out[i] || [];
  return { nodes, edges, out };
}

/* ---------- 통과 잠재량: 반경 제한 간선 매개중심성 (Brandes) ---------- */
function heapPush(h, d, u){ h.push([d, u]); let i = h.length - 1; while(i > 0){ const p = (i - 1) >> 1; if(h[p][0] <= h[i][0]) break; [h[p], h[i]] = [h[i], h[p]]; i = p; } }
function heapPop(h){ const top = h[0], last = h.pop(); if(h.length){ h[0] = last; let i = 0; for(;;){ const l = 2 * i + 1, r = l + 1; let m = i; if(l < h.length && h[l][0] < h[m][0]) m = l; if(r < h.length && h[r][0] < h[m][0]) m = r; if(m === i) break; [h[m], h[i]] = [h[i], h[m]]; i = m; } } return top; }

async function edgeBetweenness(G, sources, cutoff, progress){
  const n = G.nodes.length, bc = new Float64Array(G.edges.length);
  const dist = new Float64Array(n).fill(Infinity), sigma = new Float64Array(n), delta = new Float64Array(n);
  const done = new Uint8Array(n), preds = new Array(n);
  for(let si = 0; si < sources.length; si++){
    const s = sources[si], touched = [s], order = [], h = [];
    dist[s] = 0; sigma[s] = 1; preds[s] = [];
    heapPush(h, 0, s);
    while(h.length){
      const [d, u] = heapPop(h);
      if(done[u] || d > dist[u]) continue;
      done[u] = 1; order.push(u);
      for(const arc of G.out[u]){
        const v = arc.to, nd = d + arc.cost;
        if(nd > cutoff || done[v]) continue;
        if(dist[v] === Infinity){ dist[v] = nd; sigma[v] = sigma[u]; preds[v] = [[u, arc.e]]; touched.push(v); heapPush(h, nd, v); }
        else if(nd < dist[v] - 1e-6){ dist[v] = nd; sigma[v] = sigma[u]; preds[v] = [[u, arc.e]]; heapPush(h, nd, v); }
        else if(Math.abs(nd - dist[v]) <= 1e-6){ sigma[v] += sigma[u]; preds[v].push([u, arc.e]); }
      }
    }
    for(let i = order.length - 1; i >= 0; i--){
      const w = order[i];
      for(const [v, e] of preds[w]){ const c = sigma[v] / sigma[w] * (1 + delta[w]); bc[e] += c; delta[v] += c; }
    }
    for(const t of touched){ dist[t] = Infinity; sigma[t] = 0; delta[t] = 0; done[t] = 0; preds[t] = null; }
    if(si % 60 === 0){ progress(si / sources.length); await sleep(0); }
  }
  return bc;
}

/* ---------- 원 안으로 선 자르기 ---------- */
function clipToCircle(pts, R){
  const parts = []; let cur = null;
  const inside = p => Math.hypot(p[0], p[1]) <= R;
  const cross = (a, b) => {          // a→b 선분과 원의 교점 (t 0~1)
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const A = dx * dx + dy * dy, B = 2 * (a[0] * dx + a[1] * dy), C = a[0] * a[0] + a[1] * a[1] - R * R;
    const D = B * B - 4 * A * C; if(D < 0 || !A) return [];
    const s = Math.sqrt(D);
    return [(-B - s) / (2 * A), (-B + s) / (2 * A)].filter(t => t > 0 && t < 1).sort((x, y) => x - y)
      .map(t => [a[0] + dx * t, a[1] + dy * t]);
  };
  for(let i = 0; i < pts.length; i++){
    const p = pts[i];
    if(i === 0){ if(inside(p)) cur = [p]; continue; }
    const q = pts[i - 1], xs = cross(q, p);
    if(cur){
      if(inside(p)) cur.push(p);
      else { cur.push(xs[xs.length - 1] || p); parts.push(cur); cur = null; }
    }else{
      if(inside(p)){ cur = [xs[0] || q, p]; }
      else if(xs.length === 2){ parts.push([xs[0], xs[1]]); }
    }
  }
  if(cur && cur.length > 1) parts.push(cur);
  return parts;
}
const lineFeat = (parts, props) => ({ type:'Feature', properties:props || {},
  geometry:{ type:'MultiLineString', coordinates:parts.map(p => p.map(toLL)) } });

/* ---------- 대지 접도 조건 ---------- */
const DIR8 = ['북', '북동', '동', '남동', '남', '남서', '서', '북서'];
const dir8 = deg => DIR8[Math.round(((deg % 360) + 360) % 360 / 45) % 8];
function frontage(ways){
  const siteM = mapRings(SITE.geom, toM);
  let bb = [1e9, 1e9, -1e9, -1e9];
  for(const poly of siteM) for(const [x, y] of poly[0]) bb = [Math.min(bb[0], x), Math.min(bb[1], y), Math.max(bb[2], x), Math.max(bb[3], y)];
  const near = ways.filter(w => !w.ped || w.hw === 'pedestrian').filter(w => w.pts.some(([x, y]) =>
    x > bb[0] - 60 && x < bb[2] + 60 && y > bb[1] - 60 && y < bb[3] + 60));
  const segDist = (p, a, b) => {
    const dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy || 1e-9;
    const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L));
    return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy);
  };
  const runs = [];
  for(const poly of siteM){
    let ring = poly[0];
    if(ringArea(ring) < 0) ring = ring.slice().reverse();              // 반시계 → 바깥 법선이 (dy, -dx)
    let cur = null;
    for(let i = 0; i < ring.length - 1; i++){
      const a = ring[i], b = ring[i + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if(L < 0.01) continue;
      const nx = (b[1] - a[1]) / L, ny = -(b[0] - a[0]) / L;
      const bearing = Math.atan2(nx, ny) * 180 / Math.PI;
      const steps = Math.max(1, Math.round(L));
      for(let k = 0; k <= steps; k++){
        const p = [a[0] + (b[0] - a[0]) * k / steps, a[1] + (b[1] - a[1]) * k / steps];
        let best = null, bd = 1e9;
        const ex = (b[0] - a[0]) / L, ey = (b[1] - a[1]) / L;
        for(const w of near){
          const lim = w.w / 2 + 6;                                          // 중심선에서 반폭 + 6m 안
          for(let j = 1; j < w.pts.length; j++){
            const q0 = w.pts[j - 1], q1 = w.pts[j], d = segDist(p, q0, q1);
            if(d >= lim || d - w.w / 2 >= bd) continue;
            // 대지 경계와 나란한 길만 접도 — 경계를 가로지르는 길(교차 도로)은 빼기 (각도 차 40° 이내)
            const sl = Math.hypot(q1[0] - q0[0], q1[1] - q0[1]) || 1, cos = Math.abs(((q1[0] - q0[0]) * ex + (q1[1] - q0[1]) * ey) / sl);
            if(cos < 0.76) continue;
            bd = d - w.w / 2; best = w;
          }
        }
        const id = best ? best.id : null;
        if(cur && cur.id === id){ cur.pts.push(p); cur.len += L / steps; cur.bear.push(bearing); }
        else { if(cur) runs.push(cur); cur = { id, way:best, pts:[p], len:0, bear:[bearing] }; }
      }
    }
    if(cur) runs.push(cur);
  }
  // 교차로 모서리처럼 몇 m만 스치는 길은 빼고, 지도 타일에서 잘게 나뉜 같은 길은 (방위 · 위계 · 이름)으로 묶습니다
  const hits = runs.filter(r => r.id && r.len >= 8);
  const byWay = new Map();
  for(const r of hits){
    let sx = 0, sy = 0; for(const b of r.bear){ sx += Math.sin(b * Math.PI / 180); sy += Math.cos(b * Math.PI / 180); }
    const k = dir8(Math.atan2(sx, sy) * 180 / Math.PI) + '|' + r.way.c + '|' + (r.way.name || '');
    if(!byWay.has(k)) byWay.set(k, { way:r.way, len:0, runs:[], sx:0, sy:0 });
    const g = byWay.get(k); g.len += r.len; g.runs.push(r); g.sx += sx; g.sy += sy;
    if(r.way.w > g.way.w) g.way = r.way;
  }
  const list = [...byWay.values()].map(g => ({
    side: dir8(Math.atan2(g.sx, g.sy) * 180 / Math.PI), cls: CLASS_NAME[g.way.c], c:g.way.c, name: g.way.name,
    length_m: Math.round(g.len), est_width_m: Math.round(g.way.w), oneway: !!g.way.oneway, runs:g.runs
  })).sort((a, b) => a.c - b.c || b.length_m - a.length_m);
  // 가장 가까운 간선·보조간선
  let major = null;
  for(const w of ways) if(w.c <= 2 && !w.ped){
    for(const [x, y] of w.pts){
      let d = 1e9;
      for(const poly of siteM) for(const q of poly[0]) d = Math.min(d, Math.hypot(x - q[0], y - q[1]));
      if(!major || d < major.d) major = { d, w, x, y };
    }
  }
  return { list, major: major ? { cls:CLASS_NAME[major.w.c], name:major.w.name, distance_m:Math.round(major.d),
    direction: dir8(Math.atan2(major.x, major.y) * 180 / Math.PI) } : null };
}

/* ---------- 실행 ---------- */
async function runTraffic(){
  if(!hasRef()){ $('trsum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(TR.busy) return;
  TR.busy = true; $('trrun').disabled = true;
  try{
    const FR = focusR(), wide = isWide();
    const R = wide ? Math.min(FR + 500, 16000) : Math.min(FR + TR.scope + 300, 3500);
    const MAJOR = ['motorway', 'motorway_link', 'trunk', 'trunk_link', 'primary', 'primary_link', 'secondary', 'secondary_link', 'tertiary', 'tertiary_link'];
    $('trsum').textContent = `도로망 받는 중 · 반경 ${(R / 1000).toFixed(1)}km (OSM${wide ? ', 간선·보조간선·집산도로만' : ''})`;
    const raw = await fetchRoads(R, wide ? MAJOR : null);
    TR.ways = raw.filter(e => e.type === 'way' && e.geometry).map(wayInfo).filter(Boolean);
    TR.iso = null; TR.diff = null;
    // 접도는 대지 주변 좁은 범위를 모든 도로로 따로 봅니다
    let near = TR.ways;
    if(wide && SITE.geom){
      let m = 0; for(const poly of SITE.geom) for(const p of poly[0]){ const q = toM(p); m = Math.max(m, Math.hypot(q[0], q[1])); }
      const rawN = await fetchRoads(m + 150, null);
      near = rawN.filter(e => e.type === 'way' && e.geometry).map(wayInfo).filter(Boolean);
    }
    TR.wide = wide;
    TR.front = SITE.geom ? frontage(near) : { list:[], major:null };
    if(TR.form === 'flow') await runFlow(true);
    else { registerTrafficLayers(); applyBaseRoads(); apply(); summarizeTraffic(); }
  }catch(err){
    console.error('[대지분석] 교통 실패', err);
    $('trsum').textContent = '실패 — ' + err.message;
    setStatus('교통 분석 실패 — ' + esc(err.message), true);
  }
  TR.busy = false; $('trrun').disabled = false;
}
async function runFlow(inside){
  if(!TR.ways) return runTraffic();
  const G = buildGraph(TR.ways, TR.mode);
  const FR = focusR();
  const cutoff = TR.mode === 'car' ? TR.scope / (30 / 3.6) : TR.scope;   // 차량은 시속 30km 기준 시간으로 환산
  let sources = [];
  G.nodes.forEach((p, i) => { if(Math.hypot(p[0], p[1]) <= FR + TR.scope) sources.push(i); });
  // 교차점이 많으면 고르게 표본을 뽑아 근사합니다 (순위만 쓰므로 비율은 유지됩니다)
  const MAXS = TR.scope > 1000 ? 1200 : 2500, all = sources.length;
  if(sources.length > MAXS){ const st = sources.length / MAXS; sources = Array.from({length:MAXS}, (_, k) => sources[Math.floor(k * st)]); }
  const t0 = performance.now();
  const bc = await edgeBetweenness(G, sources, cutoff,
    f => { $('trsum').textContent = `통과 잠재량 계산 중 ${Math.round(f * 100)}% · 교차점 ${sources.length}개`; });
  TR.graph = G;
  TR.res = { bc, ms:Math.round(performance.now() - t0), sources:sources.length, all };
  registerTrafficLayers(); applyBaseRoads(); apply(); summarizeTraffic();
  if(!inside) TR.busy = false;
}

/* ---------- 레이어 ---------- */
function registerTrafficLayers(){
  extraRemove('tr-');
  if(!TR.on || !hasRef() || !TR.ways) return;
  const C = trStyle(), FR = focusR();
  const PX = [6, 6, 3.6, 2.2, 1.2, 0.7, 0.8];          // 단계마다 굵기 차이를 크게
  // 도로 위계 — 단독일 때는 원래 굵기, 축·결절점과 함께일 때는 가늘고 옅게 바탕으로
  const drawHier = (wMul, op, stage, neutral) => {
    // 흐름과 겹쳐 그릴 때는 스타일 색 대신 종이색–잉크색 사이 회색 단계로 (흐름 색과 섞이지 않게)
    // 진하게: 도로 위계 탭과 같은 굵기·진하기 / 옅게: 가늘고 연하게
    const NT = TR.under === 'full' ? [0.9, 0.93, 0.68, 0.48, 0.32, 0.2, 0.35] : [0.8, 0.8, 0.6, 0.44, 0.3, 0.2, 0.3];
    // 바탕 위계 기준색: 사용자가 '도로 위계' 색을 바꿨으면 그 색, 아니면 잉크색(회색 단계)
    const baseCol = (typeof COLOR_OV !== 'undefined' && (COLOR_OV[SITE.style] || {}).roadBase) || ST().ink;
    const col = c => neutral ? hexMix(ST().paper, baseCol, NT[c]) : C.road[c];
    for(let c = 0; c < NC; c++){
      const parts = [];
      for(const w of TR.ways) if(w.c === c) parts.push(...clipToFocus(w.pts));
      if(!parts.length) continue;
      extraSet('tr-hier-' + c, { label:`분석_도로위계_${c + 1}_${CLASS_NAME[c]}`, stage, type:'line', nomerge:true,
        fc:{type:'FeatureCollection', features:[lineFeat(parts, {cls:c})]},
        layout:{'line-cap':'round', 'line-join':'round'},
        paint:{'line-color':col(c), 'line-width':PX[c] * wMul, 'line-opacity':op, ...(c === 6 ? {'line-dasharray':[1.5, 1.2]} : c === 0 ? {'line-dasharray':[4, 1.2]} : {})},
        svg:{kind:'line', stroke:col(c), width:PX[c] * 0.8 * wMul, ...(op < 1 ? {opacity:op} : {}), ...(c === 6 ? {dash:[1.5, 1.2]} : c === 0 ? {dash:[4, 1.2]} : {})} });
    }
  };
  if(TR.form === 'hier'){
    drawHier(1, 1, 'line');
  }else if(TR.form === 'iso' || TR.form === 'diff'){
    if(typeof drawExtraTraffic === 'function') drawExtraTraffic();
  }else if(TR.res && TR.graph){
    if(TR.flowView === 'combo') drawHier(TR.under === 'full' ? 1 : 0.6, TR.under === 'full' ? 1 : 0.7, 'fill', true);   // 축·선 아래에 깔리도록, 회색 단계로
    const G = TR.graph, bc = TR.res.bc;
    const shown = [];
    G.edges.forEach((e, i) => { if(bc[i] > 0 && e.pts.some(p => inFocus(p))) shown.push(i); });
    const vals = shown.map(i => bc[i]).sort((a, b) => a - b);
    const q = f => vals.length ? vals[Math.min(vals.length - 1, Math.floor(f * vals.length))] : 0;
    const cuts = [q(0.5), q(0.75), q(0.9), q(0.97)];
    TR.res.cuts = cuts;
    const W = [0.8, 1.6, 2.6, 4, 6];
    const bins = [[], [], [], [], []];
    for(const i of shown){
      const v = bc[i]; const k = v >= cuts[3] ? 4 : v >= cuts[2] ? 3 : v >= cuts[1] ? 2 : v >= cuts[0] ? 1 : 0;
      bins[k].push(...clipToFocus(G.edges[i].pts));
    }
    const names = ['하위 50%', '50–75%', '75–90%', '90–97%', '상위 3%'];
    if(TR.flowView === 'diagram' || TR.flowView === 'combo'){ flowDiagram(G, bc, shown, cuts, bins, C, TR.flowView === 'combo'); }
    else if(TR.flowView === 'linescombo'){ hierFlow(G, bc, cuts, C, PX); }
    else bins.forEach((parts, k) => {
      if(!parts.length) return;
      extraSet('tr-flow-' + k, { label:`분석_통과잠재량_${k + 1}_${names[k].replace('%', '')}`, stage:'line', type:'line', nomerge:true,
        fc:{type:'FeatureCollection', features:[lineFeat(parts, {rank:k})]},
        layout:{'line-cap':'round', 'line-join':'round'},
        paint:{'line-color':C.flow[k], 'line-width':W[k]},
        svg:{kind:'line', stroke:C.flow[k], width:W[k] * 0.8} });
    });
  }
  // 접도 — 대지 경계 위 굵은 선 + 이름표
  if(TR.front && TR.front.list.length){
    const parts = [], labels = [];
    const labelled = new Set();
    for(const f of TR.front.list.slice().sort((a, b) => b.length_m - a.length_m)){
      for(const r of f.runs) if(r.pts.length > 1) parts.push(r.pts);
      if(labelled.has(f.side)) continue;                              // 방위마다 가장 긴 접도 하나만 이름표
      labelled.add(f.side);
      const big = f.runs.slice().sort((a, b) => b.len - a.len)[0];
      const mid = big.pts[Math.floor(big.pts.length / 2)];
      labels.push({ type:'Feature', properties:{ label:`${f.side}측 ${f.cls} · 폭 약 ${f.est_width_m}m · 접도 ${f.length_m}m` },
                    geometry:{ type:'Point', coordinates:toLL(mid) } });
    }
    extraSet('tr-front', { label:'분석_접도', stage:'top', type:'line', nomerge:true,
      fc:{type:'FeatureCollection', features:[lineFeat(parts, {})]},
      layout:{'line-cap':'butt'}, paint:{'line-color':C.front, 'line-width':6, 'line-opacity':0.9},
      svg:{kind:'line', stroke:C.front, width:5} });
    extraSet('tr-front-label', { label:'분석_접도_라벨', stage:'top', type:'symbol', nomerge:true,
      fc:{type:'FeatureCollection', features:labels},
      layout:{'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':11, 'text-offset':[0, -1.4], 'text-allow-overlap':false},
      paint:{'text-color':ST().frontText, 'text-halo-color':ST().paper, 'text-halo-width':1.6},
      svg:{kind:'text', fill:ST().frontText, size:9} });
  }
}

function summarizeTraffic(){
  const f = TR.front;
  const parts = [];
  if(f && f.list.length) parts.push('접도 ' + f.list.map(x => `${x.side}측 ${x.cls}(약 ${x.est_width_m}m) ${x.length_m}m`).join(', '));
  else if(SITE.geom) parts.push('맞닿은 도로를 찾지 못했습니다 (OSM 누락이거나 맹지일 수 있음)');
  else parts.push('대지 없이 화면 범위 분석 — 접도는 대지를 정하면 계산합니다');
  if(f && f.major) parts.push(`가장 가까운 ${f.major.cls} ${f.major.direction}쪽 ${f.major.distance_m}m`);
  if(typeof extraTrafficSummary === 'function'){ const ex = extraTrafficSummary(); if(ex) parts.push(ex); }
  if(TR.fromTiles === 'hires') parts.push(`출처: 지도 타일 z${TR.tileZoom}` + (TR.tileZoom < 14 ? ` (범위가 넓어 z${TR.tileZoom}로 읽음 — 국지도로 일부 생략, 크게 확대하면 선이 실제 도로와 조금 어긋날 수 있음)` : ''));
  else if(TR.fromTiles) parts.push('출처: 화면 타일' + (SITE.range === 'view' ? '' : ' (화면 밖은 비어 있을 수 있음)'));
  if(TR.ways && TR.form === 'hier'){
    const L = new Array(NC).fill(0);
    for(const w of TR.ways) for(const p of clipToFocus(w.pts)) for(let i = 1; i < p.length; i++) L[w.c] += Math.hypot(p[i][0] - p[i-1][0], p[i][1] - p[i-1][1]);
    parts.push('위계별 길이 ' + CLASS_NAME.map((n, i) => L[i] ? `${n} ${(L[i] / 1000).toFixed(1)}km` : '').filter(Boolean).join(' · '));
    const z = map && map.getZoom ? map.getZoom() : 16;
    if(TR.fromTiles === true && z < 14) parts.push(`화면 타일(줌 ${z.toFixed(1)})로 계산해 국지·이면도로가 없고 선이 단순화돼 있습니다 — 확대하면 실제 도로와 어긋나 보일 수 있습니다`);

  }
  if(TR.form === 'flow' && TR.res) parts.push(`통과 잠재량 계산 ${(TR.res.ms / 1000).toFixed(1)}초 · 교차점 ${TR.res.all}개` + (TR.res.all > TR.res.sources ? ` 중 ${TR.res.sources}개 표본` : ''));
  $('trsum').textContent = parts.join(' · ');
}

/* AI 요약용 */
function trafficSummary(){
  if(!TR.on || !TR.ways || !hasRef()) return null;
  const FR = focusR(), f = TR.front || { list:[], major:null };
  const lenBy = new Array(NC).fill(0);
  for(const w of TR.ways) for(const p of clipToFocus(w.pts))
    for(let i = 1; i < p.length; i++) lenBy[w.c] += Math.hypot(p[i][0] - p[i-1][0], p[i][1] - p[i-1][1]);
  const out = {
    source: TR.fromTiles ? `OpenStreetMap 도로망 (OpenFreeMap 벡터 타일 z${TR.tileZoom || '화면'})` : 'OpenStreetMap 도로망 (Overpass)',
    frontage: f.list.map(({runs, c, ...x}) => x),
    nearest_arterial: f.major,
    road_length_in_area_m: Object.fromEntries(CLASS_NAME.map((n, i) => [n, Math.round(lenBy[i])])),
    note:'도로 폭은 OSM 태그가 없으면 도로 종류별 추정값입니다. 법정 접도 판단은 지적도·도시계획도로로 확인이 필요합니다.'
  };
  if(typeof kictSummary === 'function' && kictSummary()) out.measured_spots = kictSummary();
  if(TR.compare) out.through_movement_compare = TR.compare;
  if(TR.res && TR.graph){
    const G = TR.graph, bc = TR.res.bc, top = [];
    G.edges.forEach((e, i) => {
      const m = e.pts[Math.floor(e.pts.length / 2)], d = Math.hypot(m[0], m[1]);
      if(inFocus(m) && bc[i] > 0) top.push({ i, v:bc[i], d, e });
    });
    top.sort((a, b) => b.v - a.v);
    const seen = new Set(), best = [];
    for(const t of top){
      const key = t.e.way.name || t.e.way.id;
      if(seen.has(key)) continue; seen.add(key);
      best.push({ name:t.e.way.name || '(이름 없음)', cls:CLASS_NAME[t.e.way.c], distance_from_center_m:Math.round(t.d),
                  direction:dir8(Math.atan2(t.e.pts[0][0], t.e.pts[0][1]) * 180 / Math.PI) });
      if(best.length >= 5) break;
    }
    let frontRank = null;
    if(f.list.length){
      const ids = new Set(f.list.map(x => x.runs[0].id));
      const vals = top.map(t => t.v), frontVals = top.filter(t => ids.has(t.e.way.id)).map(t => t.v);
      if(frontVals.length){ const mx = Math.max(...frontVals); frontRank = Math.round(vals.filter(v => v > mx).length / vals.length * 100); }
    }
    out.through_movement = {
      estimated:true, mode: TR.mode === 'car' ? '차량(도로 종류별 속도 가중)' : '보행(거리)', radius_m:TR.scope,
      method:'반경 제한 최단경로 매개중심성 — 실측 교통량이 아닌 가로망 구조로 본 통과 가능성',
      key_junctions: TR.nodes || null,
      busiest_nearby:best, sampled_sources: TR.res.all > TR.res.sources ? `${TR.res.sources}/${TR.res.all}` : null,
      site_frontage_top_pct: frontRank    // 접한 도로가 범위 안 도로 중 상위 몇 %인지
    };
  }
  return out;
}


/* ============================================================
   실측 교통량 측정 지점 — 국토교통부·건설기술연구원 교통량 정보조회서비스
   개발계정은 하루 100건이라, 전국 지점 목록을 한 번 받아 1년간 저장합니다.
   (시간대별 교통량은 지점을 골라 받을 수 없어 전국 5만 줄을 넘겨야 하므로 쓰지 않습니다)
   ============================================================ */
const KICT = 'apis.data.go.kr/1613000/KictTms';
const KT = { on:false, busy:false, spots:null, year:null };
const DTYPE_NAME = { 1:'고속도로', 2:'일반국도', 3:'지방도', 5:'국가지원지방도' };
function kictBudget(){
  const k = 'kictCalls:' + new Date().toISOString().slice(0, 10);
  let n = 0; try{ n = +localStorage.getItem(k) || 0; }catch(e){}
  return { used:n, add(){ n++; try{ localStorage.setItem(k, String(n)); }catch(e){} } };
}
/* ---------- 지점 목록 쪽(page) 저장소 — 필요한 쪽만 받아 1년간 보관 ---------- */
function kictStore(year, dtype){
  const key = `kictPages:${year}:${dtype}`;
  let c = null; try{ c = JSON.parse(localStorage.getItem(key) || 'null'); }catch(e){}
  c = c || { pages:{}, end:null };
  return { c, save(){ try{ localStorage.setItem(key, JSON.stringify(c)); }catch(e){} } };
}
async function kictPage(st, year, dtype, p, budget, limit){
  if(st.c.pages[p]) return st.c.pages[p];
  if(st.c.end != null && p >= st.c.end) return [];
  if(budget.used >= limit){ const e = new Error('오늘 교통량 API 호출 한도를 다 썼습니다 — 내일 이어서 받습니다'); e.budget = true; throw e; }
  $('ktsum').textContent = `측정 지점 찾는 중 · ${DTYPE_NAME[dtype]} ${p + 1}쪽 · 오늘 ${budget.used + 1}/${limit}건`;
  const r = await dataGo(KICT + '/spotlist', { year:String(year), dtype:String(dtype), PageNo:String(p), numOfRows:'100', output:'json' });
  budget.add(); budget.used++;
  if(!r.ok) throw new Error(r.msg);
  const rows = [];
  for(const x of r.items){
    const lat = +x.xcode, lng = +x.ycode;                       // 이 API는 xcode 가 위도, ycode 가 경도입니다
    rows.push([x.spot, lat, lng, +x.hosun, x.stname, x.endname, (+x.laneup || 0) + (+x.lanedn || 0), x.id5, x.locate, dtype]);
  }
  if(!rows.length){ st.c.end = st.c.end == null ? p : Math.min(st.c.end, p); }
  else st.c.pages[p] = rows;
  st.save();
  return rows;
}
/* 목록은 노선 번호 순이라, 범위 안 국도 번호만 골라 이진 탐색으로 해당 쪽만 받습니다 */
async function kictRouteSpots(year, dtype, route, budget, limit){
  const st = kictStore(year, dtype);
  let hi = st.c.end;
  if(hi == null){                                                    // 끝 쪽 찾기
    hi = 32;
    while(hi < 1024){ const pg = await kictPage(st, year, dtype, hi, budget, limit); if(!pg.length) break; hi *= 2; }
    if(st.c.end != null) hi = st.c.end;
  }
  let lo = 0;
  while(lo < hi){
    const mid = (lo + hi) >> 1, pg = await kictPage(st, year, dtype, mid, budget, limit);
    if(!pg.length){ hi = mid; continue; }
    if(pg[pg.length - 1][3] < route) lo = mid + 1; else hi = mid;
  }
  const out = [];
  for(let p = lo; p < lo + 6; p++){
    const pg = await kictPage(st, year, dtype, p, budget, limit);
    if(!pg.length) break;
    out.push(...pg.filter(r => r[3] === route));
    if(pg[0][3] > route) break;
  }
  if(out.length) return out;
  // 못 찾았으면 이미 받아 둔 쪽에서 먼저 찾고, 그래도 없으면 처음부터 훑습니다
  KT.scanMode = true;
  const fromCache = Object.values(st.c.pages).flat().filter(r => r[3] === route);
  if(fromCache.length && st.c.end != null && Object.keys(st.c.pages).length >= st.c.end) return fromCache;
  const res = [];
  for(let p = 0; st.c.end == null || p < st.c.end; p++){
    const pg = await kictPage(st, year, dtype, p, budget, limit);           // 받아 둔 쪽은 호출하지 않습니다
    if(!pg.length) break;
    res.push(...pg.filter(r => r[3] === route));
  }
  return res;
}
/* 범위 안 국도·지방도 번호 — OSM 도로의 ref 에서 읽습니다 */
function tileRouteRefs(){
  if(!map || !map.querySourceFeatures) return null;
  const refs = { 2:new Set(), 3:new Set() };
  let n = 0;
  for(const f of map.querySourceFeatures('omt', { sourceLayer:'transportation_name' })){
    const p = f.properties || {};
    if(!['trunk', 'primary', 'secondary', 'motorway'].includes(p.class) || !p.ref) continue;
    const g = f.geometry, pts = g.type === 'LineString' ? g.coordinates : g.type === 'MultiLineString' ? g.coordinates.flat() : [];
    if(!pts.some(c => inFocus(toM(c)))) continue;
    for(const m of String(p.ref).split(/[;,]/)){ const k = parseInt(m.replace(/[^0-9]/g, ''), 10); if(!k) continue; (k < 100 ? refs[2] : refs[3]).add(k); n++; }
  }
  return n ? refs : null;
}
async function kictRouteRefs(){
  // 받아 둔 도로(타일 이름 층의 ref 포함)에서 먼저
  if(TR.ways && TR.ways.some(w => w.ref)){
    const refs = { 2:new Set(), 3:new Set() };
    for(const w of TR.ways){
      if(w.c > 2 || !w.ref || !w.pts.some(p => inFocus(p))) continue;
      for(const m of String(w.ref).split(/[;,]/)){ const k = parseInt(m.replace(/[^0-9]/g, ''), 10); if(k) (k < 100 ? refs[2] : refs[3]).add(k); }
    }
    if(refs[2].size || refs[3].size) return refs;
  }
  const fromTiles = tileRouteRefs();
  if(fromTiles) return fromTiles;
  let ways = TR.ways;
  if(!ways || !ways.length){
    const raw = await fetchRoads(Math.min(focusR() + 300, 16000), ['trunk', 'trunk_link', 'primary', 'primary_link', 'secondary']);
    ways = raw.filter(e => e.type === 'way' && e.geometry).map(el => ({ ...wayInfo(el), ref:(el.tags || {}).ref || '' })).filter(w => w.hw);
  }
  const refs = { 2:new Set(), 3:new Set() };
  const raw = TR.raw || [];
  const refOf = new Map(raw.map(e => [e.id, (e.tags || {}).ref || '']));
  for(const w of ways){
    if(!['trunk', 'primary', 'secondary'].includes((w.hw || '').replace('_link', ''))) continue;
    if(!w.pts.some(p => inFocus(p))) continue;
    const ref = String(w.ref || refOf.get(w.id) || '');
    for(const m of ref.split(/[;,]/)){
      const n = parseInt(m.replace(/[^0-9]/g, ''), 10); if(!n) continue;
      if(n < 100) refs[2].add(n); else refs[3].add(n);          // 두 자리는 국도, 세·네 자리는 지방도
    }
  }
  return refs;
}
async function runKict(){
  if(!hasRef()){ $('ktsum').textContent = '먼저 대지를 정하거나 화면 범위를 고정하세요'; return; }
  if(KT.busy) return;
  KT.busy = true;
  try{
    const budget = kictBudget(), LIMIT = 90;
    let year = new Date().getFullYear() - 2;
    KT.scanMode = false;
    const refs = await kictRouteRefs();
    const want = [[2, [...refs[2]].sort((a, b) => a - b)]];
    if($('ktlocal').checked) want.push([3, [...refs[3]].sort((a, b) => a - b)]);
    if(!want.some(([, r]) => r.length)){ $('ktsum').textContent = '범위 안 간선도로에서 국도·지방도 번호를 찾지 못했습니다 (OSM 도로 번호 누락)'; KT.spots = []; KT.busy = false; return; }
    const all = []; let pending = false; const perRoute = [];
    try{
      for(const [d, routes] of want) for(const rt of routes){
        let rows = await kictRouteSpots(year, d, rt, budget, LIMIT);
        perRoute.push(`${rt}호선 ${rows.length}`);
        all.push(...rows);
      }
    }catch(e){ if(e.budget) pending = true; else throw e; }
    KT.perRoute = perRoute;
    KT.year = year; KT.routes = want.map(([d, r]) => `${DTYPE_NAME[d]} ${r.join('·')}`).join(' / ');
    const conv = all.filter(r => isFinite(r[1]) && r[1]).map(r => ({ id:r[0], ll:[r[2], r[1]], m:toM([r[2], r[1]]), route:r[3], from:r[4], to:r[5], lanes:r[6], kind:r[7], at:r[8], dtype:r[9] }));
    KT.noCoord = all.length - conv.length;
    KT.spots = conv.filter(s => inFocus(s.m));
    // 범위 안에 없으면, 같은 노선에서 가장 가까운 지점 몇 곳을 기준점으로 함께 보여줍니다 (15km 이내)
    KT.outside = KT.spots.length ? [] : conv.map(s => ({ ...s, d:Math.hypot(...s.m) })).filter(s => s.d < 15000).sort((a, b) => a.d - b.d).slice(0, 4);
    KT.pending = pending;
    registerKictLayers(); apply(); summarizeKict();
  }catch(err){ $('ktsum').textContent = '실패 — ' + err.message; }
  KT.busy = false;
}
function summarizeKict(){
  if(!KT.spots) return;
  const n = KT.spots.length;
  const near = (n ? KT.spots : (KT.outside || [])).slice().sort((a, b) => Math.hypot(...a.m) - Math.hypot(...b.m))[0];
  $('ktsum').textContent = (KT.routes ? `찾은 노선: ${KT.routes} · ` : '') + (n ? `범위 안 측정 지점 ${n}곳 (${KT.year}년)` + (near ? ` · 가장 가까운 곳 ${DTYPE_NAME[near.dtype]} ${near.route}호선 ${near.from}–${near.to} ${(Math.hypot(...near.m) / 1000).toFixed(1)}km` : '')
    : `범위 안에 측정 지점이 없습니다 (${rangeLabel()})` + (near ? ` · 범위 밖 가장 가까운 곳 ${near.route}호선 ${near.from}–${near.to} ${(Math.hypot(...near.m) / 1000).toFixed(1)}km (지도에 함께 표시)` : ' · 15km 안에도 없음'))
    + (KT.perRoute && KT.perRoute.length ? ` · 노선별 전국 지점: ${KT.perRoute.join(', ')}` : '') + (KT.scanMode ? ' · 목록 순서가 예상과 달라 전국 목록을 차례로 훑었습니다' : '') + (KT.noCoord ? ` · 좌표 없는 지점 ${KT.noCoord}` : '') + (KT.pending ? ' · 오늘 호출 한도에 걸려 일부 노선만 받았습니다 — 내일 다시 누르면 이어서 받습니다' : '');
}
function registerKictLayers(){
  extraRemove('kt-');
  if(!KT.on || !KT.spots || !hasRef()) return;
  const shown = KT.spots.length ? KT.spots : (KT.outside || []);
  if(!shown.length) return;
  const col = ST().kict;
  const sq = s => { const r = Math.max(6, focusR() / 150); return [[[-r, -r], [r, -r], [r, r], [-r, r], [-r, -r]].map(([x, y]) => toLL([s.m[0] + x, s.m[1] + y]))]; };
  extraSet('kt-spots', { label:'분석_교통량측정지점', stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:shown.map(sq) } }] },
    paint:{ 'fill-color':col, 'fill-opacity':0.9, 'fill-outline-color':ST().paper }, svg:{ kind:'fill', fill:col, opacity:0.9 } });
  extraSet('kt-label', { label:'분석_교통량측정지점_라벨', stage:'top', type:'symbol', nomerge:true,
    fc:{ type:'FeatureCollection', features:shown.map(s => ({ type:'Feature', properties:{ label:`${s.route}호선 ${s.lanes}차로 · ${s.kind}` + (KT.spots.length ? '' : ` · ${(Math.hypot(...s.m) / 1000).toFixed(1)}km`) }, geometry:{ type:'Point', coordinates:s.ll } })) },
    layout:{ 'text-field':['get', 'label'], 'text-font':['Noto Sans Regular'], 'text-size':10, 'text-offset':[0, 1.2], 'text-allow-overlap':false },
    paint:{ 'text-color':ST().kictText, 'text-halo-color':ST().paper, 'text-halo-width':1.4 }, svg:{ kind:'text', fill:ST().kictText, size:8 } });
}
function kictSummary(){
  if(!KT.on || !KT.spots) return null;
  return { source:'국토교통부·한국건설기술연구원 교통량 측정 지점', year:KT.year, spots_in_range:KT.spots.length, complete:!KT.pending,
    nearest_outside_range: KT.spots.length ? [] : (KT.outside || []).map(s => ({ road:`${DTYPE_NAME[s.dtype]} ${s.route}호선`, section:`${s.from}–${s.to}`, lanes:s.lanes, survey:s.kind, distance_m:Math.round(s.d) })),
    spots: KT.spots.slice().sort((a, b) => Math.hypot(...a.m) - Math.hypot(...b.m)).slice(0, 8).map(s => ({
      road:`${DTYPE_NAME[s.dtype]} ${s.route}호선`, section:`${s.from}–${s.to}`, lanes:s.lanes, survey:s.kind, location:(s.at || '').trim(),
      distance_m:Math.round(Math.hypot(...s.m)) })),
    note:'측정 지점의 위치·차로 수·조사 종류(상시/수시)입니다. 지점별 교통량 값은 이 API 구조상 받지 않았습니다.' };
}
$('kton').addEventListener('change', e => { KT.on = e.target.checked; $('ktopts').hidden = !KT.on; if(KT.on && hasRef()) runKict(); else { registerKictLayers(); apply(); } });
$('ktlocal').addEventListener('change', () => { if(KT.on) runKict(); });


/* AI 해설용 — 근거리(800m)·광역(2km) 통과 잠재량을 같은 도로망에서 둘 다 계산해 비교합니다 */
async function flowCompare(){
  if(!TR.ways || !TR.ways.length) return null;
  const mode = TR.mode || 'car', G = buildGraph(TR.ways, mode), out = {};
  for(const scope of [800, 2000]){
    const cutoff = mode === 'car' ? scope / (30 / 3.6) : scope;
    let src = []; G.nodes.forEach((p, i) => { if(inFocus(p) || Math.hypot(p[0], p[1]) <= focusR() + scope) src.push(i); });
    const MAX = scope > 1000 ? 1000 : 2000;
    if(src.length > MAX){ const st = src.length / MAX; src = Array.from({ length:MAX }, (_, k) => src[Math.floor(k * st)]); }
    const bc = await edgeBetweenness(G, src, cutoff, f => { $('ainote').textContent = `통과 잠재량 ${scope === 800 ? '근거리' : '광역'} 계산 중 ${Math.round(f * 100)}%`; });
    const rows = [];
    G.edges.forEach((e, i) => { if(bc[i] > 0 && e.pts.some(p => inFocus(p))) rows.push({ v:bc[i], e }); });
    rows.sort((a, b) => b.v - a.v);
    const vals = rows.map(r => r.v);
    const seen = new Set(), top = [];
    for(const r of rows){ const k = r.e.way.name || r.e.way.id; if(seen.has(k)) continue; seen.add(k);
      const m = r.e.pts[Math.floor(r.e.pts.length / 2)];
      top.push({ name:r.e.way.name || '(이름 없음)', cls:CLASS_NAME[r.e.way.c], distance_from_center_m:Math.round(Math.hypot(m[0], m[1])), direction:dir8(Math.atan2(m[0], m[1]) * 180 / Math.PI) });
      if(top.length >= 5) break; }
    let frontPct = null;
    if(TR.front && TR.front.list.length){
      const ids = new Set(TR.front.list.map(x => x.runs[0].id));
      const fv = rows.filter(r => ids.has(r.e.way.id)).map(r => r.v);
      if(fv.length){ const mx = Math.max(...fv); frontPct = Math.round(vals.filter(v => v > mx).length / vals.length * 100); }
    }
    out[scope === 800 ? 'local_800m' : 'regional_2km'] = { busiest_roads:top, site_frontage_top_pct:frontPct };
  }
  TR.compare = { estimated:true, mode: mode === 'car' ? '차량' : '보행', ...out,
    note:'site_frontage_top_pct 는 대지에 맞닿은 도로가 범위 안 도로 중 상위 몇 %인지입니다 (작을수록 많이 지나감).' };
  return TR.compare;
}


/* ============================================================
   통과 잠재량 다이어그램 — 선 색칠이 아니라 "축과 결절점"으로
   · 상위 가로는 굵은 띠(축)로, 그 위에 가는 중심선
   · 많이 지나가는 교차점은 크기가 다른 원(결절점)
   · 나머지 도로는 옅은 바탕선
   ============================================================ */
function offsetLines(lines, d){
  const C = CL(); const co = new C.ClipperOffset(2, Math.max(0.05, d * 0.08) * CLS);
  const paths = lines.filter(l => l.length > 1).map(l => l.map(([x, y]) => ({ X:Math.round(x * CLS), Y:Math.round(y * CLS) })));
  co.AddPaths(paths, C.JoinType.jtRound, C.EndType.etOpenRound);
  const tree = new C.PolyTree(); co.Execute(tree, d * CLS);
  return fromTree(tree);
}
function flowDiagram(G, bc, shown, cuts, bins, Cc, withHier){
  const fl = Cc.flow, a = typeof CA === 'function' ? CA() : 0.7;
  // 화면 1px 이 몇 m 인지 — 원 크기를 화면 기준으로 정해 범위가 넓어도 커지지 않게
  const z = map && map.getZoom ? map.getZoom() : 15, lat = SITE.center ? SITE.center[1] : 35;
  const mpp = 156543.03 * Math.cos(lat * Math.PI / 180) / Math.pow(2, z);
  // 1) 바탕: 하위 두 단계는 옅은 가는 선 (도로망을 함께 깔 때는 생략)
  const thin = [...bins[0], ...bins[1]];
  if(thin.length && !withHier) extraSet('tr-flow-base', { label:'분석_통과잠재량_바탕도로', stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[lineFeat(thin, {})] }, layout:{ 'line-cap':'round', 'line-join':'round' },
    paint:{ 'line-color':fl[1], 'line-width':0.7, 'line-opacity':0.8 }, svg:{ kind:'line', stroke:fl[1], width:0.5 } });
  // 2) 축: 면 대신 굵기가 다른 선 — 가장 위 단계는 옅은 넓은 띠를 한 겹 깔아 강조
  if(bins[4].length) extraSet('tr-flow-glow', { label:'분석_통과잠재량축_강조띠', stage:'line', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:[lineFeat(bins[4], {})] }, layout:{ 'line-cap':'round', 'line-join':'round' },
    paint:{ 'line-color':fl[4], 'line-width':11, 'line-opacity':0.16 }, svg:{ kind:'line', stroke:fl[4], width:9, opacity:0.16 } });
  for(const [k, w, nm] of [[2, 1.8, '75–90'], [3, 3.0, '90–97'], [4, 4.6, '상위 3']]){
    if(!bins[k].length) continue;
    extraSet('tr-flow-ax' + k, { label:`분석_통과잠재량축_${k - 1}_${nm}%`, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[lineFeat(bins[k], {})] }, layout:{ 'line-cap':'round', 'line-join':'round' },
      paint:{ 'line-color':fl[k], 'line-width':w, 'line-opacity':0.95 }, svg:{ kind:'line', stroke:fl[k], width:w * 0.8 } });
  }
  // 3) 결절점: 칠하지 않은 고리 + 작은 점 — 아래 도로가 그대로 보이게
  const flow = new Float64Array(G.nodes.length), deg = new Uint16Array(G.nodes.length);
  for(const i of shown){ const e = G.edges[i]; flow[e.a] += bc[i]; flow[e.b] += bc[i]; deg[e.a]++; deg[e.b]++; }
  const cand = [];
  G.nodes.forEach((p, i) => { if(deg[i] >= 3 && flow[i] > 0 && inFocus(p)) cand.push({ i, p, v:flow[i] }); });
  cand.sort((x, y) => y.v - x.v);
  const grain = (typeof PEAK_GRAIN !== 'undefined' && PEAK_GRAIN[SITE.peakGrain]) || { max:14 };
  const N = Math.max(3, Math.round(grain.max * 0.4)), minD = Math.max(mpp * 40, focusR() * 2 / (N + 2));
  const nodes = [];
  for(const c of cand){ if(nodes.some(n => Math.hypot(n.p[0] - c.p[0], n.p[1] - c.p[1]) < minD)) continue; nodes.push(c); if(nodes.length >= N) break; }
  if(!nodes.length){ TR.nodes = []; return; }
  const vMax = nodes[0].v;
  const ring = (p, r) => circleM(r, 48)[0][0].map(([x, y]) => toLL([p[0] + x, p[1] + y]));
  const rOf = n => mpp * (7 + 7 * Math.sqrt(n.v / vMax));              // 화면에서 반지름 7~14px
  extraSet('tr-node-veil', { label:'분석_통과결절점_바탕', stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:nodes.map(n => [ring(n.p, rOf(n))]) } }] },
    paint:{ 'fill-color':ST().paper, 'fill-opacity':0.35 * a }, svg:{ kind:'fill', fill:ST().paper, opacity:0.35 * a } });
  extraSet('tr-node-ring', { label:'분석_통과결절점_결절점', stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:nodes.map(n => ({ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:ring(n.p, rOf(n)) } })) },
    paint:{ 'line-color':fl[4], 'line-width':1.6, 'line-opacity':Math.min(1, a + 0.3) }, svg:{ kind:'line', stroke:fl[4], width:1.3, opacity:Math.min(1, a + 0.3) } });
  extraSet('tr-node-outer', { label:'분석_통과결절점_영향권', stage:'top', type:'line', nomerge:true,
    fc:{ type:'FeatureCollection', features:nodes.map(n => ({ type:'Feature', properties:{}, geometry:{ type:'LineString', coordinates:ring(n.p, rOf(n) * 1.7) } })) },
    paint:{ 'line-color':fl[4], 'line-width':0.8, 'line-opacity':0.55 * a + 0.1, 'line-dasharray':[2, 2] }, svg:{ kind:'line', stroke:fl[4], width:0.6, dash:[2, 2], opacity:0.55 * a + 0.1 } });
  extraSet('tr-node-core', { label:'분석_통과결절점_중심', stage:'top', type:'fill', nomerge:true,
    fc:{ type:'FeatureCollection', features:[{ type:'Feature', properties:{}, geometry:{ type:'MultiPolygon', coordinates:nodes.map(n => [ring(n.p, mpp * 2.4)]) } }] },
    paint:{ 'fill-color':fl[4], 'fill-opacity':Math.min(1, a + 0.3) }, svg:{ kind:'fill', fill:fl[4], opacity:Math.min(1, a + 0.3) } });
  TR.nodes = nodes.map((n, k) => ({ rank:k + 1, x:n.p[0], y:n.p[1], distance_m:Math.round(Math.hypot(n.p[0], n.p[1])), direction:dir8(Math.atan2(n.p[0], n.p[1]) * 180 / Math.PI) }));
}
// 확대·축소하면 결절점 크기를 화면에 맞춰 다시
(function hookZoom(){
  if(typeof map === 'undefined' || !map || !map.on){ setTimeout(hookZoom, 400); return; }
  map.on('zoomend', () => { if(TR.on && TR.form === 'flow' && (TR.flowView === 'diagram' || TR.flowView === 'combo')){ registerTrafficLayers(); apply(); } });
})();
$('trflowview').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; TR.flowView = b.dataset.v; segSync('trflowview', TR.flowView); registerTrafficLayers(); apply(); });
segSync('trflowview', TR.flowView);

$('trunder').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; TR.under = b.dataset.v; segSync('trunder', TR.under); registerTrafficLayers(); apply(); });
segSync('trunder', TR.under);

/* 도로 위계 + 통과 잠재량 — 굵기는 도로 위계 그대로, 색은 통과 잠재량
   하위 두 단계(통과가 적은 길)는 위계 회색으로, 위 세 단계는 흐름 색으로 칠합니다. */
function hierFlow(G, bc, cuts, C, PX){
  const NT = TR.under === 'full' ? [0.9, 0.93, 0.68, 0.48, 0.32, 0.2, 0.35] : [0.8, 0.8, 0.6, 0.44, 0.3, 0.2, 0.3];
  const wMul = TR.under === 'full' ? 1 : 0.8;
  const bin = v => v >= cuts[3] ? 4 : v >= cuts[2] ? 3 : v >= cuts[1] ? 2 : v >= cuts[0] ? 1 : 0;
  const groups = new Map();                                           // 'k|c' → 선들
  G.edges.forEach((e, i) => {
    if(!e.pts.some(p => inFocus(p))) return;
    const k = bc[i] > 0 ? bin(bc[i]) : 0, c = e.way.c;
    const key = k + '|' + c;
    if(!groups.has(key)) groups.set(key, []);
    groups.get(key).push(...clipToFocus(e.pts));
  });
  const names = ['하위 50%', '50–75%', '75–90%', '90–97%', '상위 3%'];
  const shownLegend = new Set();
  // 낮은 단계부터 그려 진한 흐름이 위로
  [...groups.keys()].sort((a, b) => (+a.split('|')[0]) - (+b.split('|')[0]) || (+b.split('|')[1]) - (+a.split('|')[1])).forEach(key => {
    const [k, c] = key.split('|').map(Number), parts = groups.get(key);
    if(!parts.length) return;
    const baseCol = (typeof COLOR_OV !== 'undefined' && (COLOR_OV[SITE.style] || {}).roadBase) || ST().ink;
    const col = k >= 2 ? C.flow[k] : hexMix(ST().paper, baseCol, NT[c]);
    // 범례에는 흐름 단계마다 한 줄만 (같은 단계의 다른 굵기는 "_세부"로 숨김)
    const first = !shownLegend.has(k); shownLegend.add(k);
    const label = k >= 2 ? `분석_통과위계_${k - 1}_${names[k]}${first ? '' : '_세부'}` : `분석_통과위계_바탕_${CLASS_NAME[c]}_세부`;
    extraSet('tr-hf-' + k + '-' + c, { label, stage:'line', type:'line', nomerge:true,
      fc:{ type:'FeatureCollection', features:[lineFeat(parts, { k, c })] }, layout:{ 'line-cap':'round', 'line-join':'round' },
      paint:{ 'line-color':col, 'line-width':PX[c] * wMul, ...(c === 6 ? { 'line-dasharray':[1.5, 1.2] } : {}) },
      svg:{ kind:'line', stroke:col, width:PX[c] * 0.8 * wMul, ...(c === 6 ? { dash:[1.5, 1.2] } : {}) } });
  });
}
